namespace AppedoLT
{
    partial class frmExtractor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radTabStrip1 = new Telerik.WinControls.UI.RadTabStrip();
            this.tabiExtrator = new Telerik.WinControls.UI.TabItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbtnSimple = new System.Windows.Forms.RadioButton();
            this.rbtnAdvanced = new System.Windows.Forms.RadioButton();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.txtEndwith = new Telerik.WinControls.UI.RadTextBox();
            this.btnEndWith = new Telerik.WinControls.UI.RadButton();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.txtGroupIndex = new Telerik.WinControls.UI.RadTextBox();
            this.txtStartwith = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.btnStartWith = new Telerik.WinControls.UI.RadButton();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.txtRegEx = new Telerik.WinControls.UI.RadTextBox();
            this.btnShowResult = new Telerik.WinControls.UI.RadButton();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.rbtnSingleOccurrence = new System.Windows.Forms.RadioButton();
            this.rbtnRandomOccurrence = new System.Windows.Forms.RadioButton();
            this.rbtnAllOccurrence = new System.Windows.Forms.RadioButton();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.btnSave = new Telerik.WinControls.UI.RadButton();
            this.lblResult = new Telerik.WinControls.UI.RadLabel();
            this.txtResult = new Telerik.WinControls.UI.RadTextBox();
            this.lblOrdinal = new Telerik.WinControls.UI.RadLabel();
            this.lblName = new Telerik.WinControls.UI.RadLabel();
            this.txtOrdinal = new Telerik.WinControls.UI.RadTextBox();
            this.txtName = new Telerik.WinControls.UI.RadTextBox();
            this.tabiTest = new Telerik.WinControls.UI.TabItem();
            this.txtResponse = new Telerik.WinControls.UI.RadTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.radTabStrip1)).BeginInit();
            this.radTabStrip1.SuspendLayout();
            this.tabiExtrator.ContentPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEndwith)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEndWith)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroupIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStartwith)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnStartWith)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRegEx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnShowResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOrdinal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOrdinal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).BeginInit();
            this.tabiTest.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radTabStrip1
            // 
            this.radTabStrip1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.radTabStrip1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.radTabStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.radTabStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radTabStrip1.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.tabiExtrator,
            this.tabiTest});
            this.radTabStrip1.Location = new System.Drawing.Point(0, 0);
            this.radTabStrip1.Name = "radTabStrip1";
            this.radTabStrip1.ScrollOffsetStep = 5;
            this.radTabStrip1.Size = new System.Drawing.Size(456, 355);
            this.radTabStrip1.TabIndex = 0;
            this.radTabStrip1.TabScrollButtonsPosition = Telerik.WinControls.UI.TabScrollButtonsPosition.RightBottom;
            this.radTabStrip1.Text = "radTabStrip1";
            this.radTabStrip1.ThemeName = "Telerik";
            // 
            // tabiExtrator
            // 
            this.tabiExtrator.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tabiExtrator.ContentPanel
            // 
            this.tabiExtrator.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(239)))), ((int)(((byte)(249)))));
            this.tabiExtrator.ContentPanel.CausesValidation = true;
            this.tabiExtrator.ContentPanel.Controls.Add(this.panel1);
            this.tabiExtrator.ContentPanel.Controls.Add(this.radLabel3);
            this.tabiExtrator.ContentPanel.Controls.Add(this.radLabel4);
            this.tabiExtrator.ContentPanel.Controls.Add(this.txtEndwith);
            this.tabiExtrator.ContentPanel.Controls.Add(this.btnEndWith);
            this.tabiExtrator.ContentPanel.Controls.Add(this.radLabel5);
            this.tabiExtrator.ContentPanel.Controls.Add(this.txtGroupIndex);
            this.tabiExtrator.ContentPanel.Controls.Add(this.txtStartwith);
            this.tabiExtrator.ContentPanel.Controls.Add(this.radLabel2);
            this.tabiExtrator.ContentPanel.Controls.Add(this.btnStartWith);
            this.tabiExtrator.ContentPanel.Controls.Add(this.radLabel7);
            this.tabiExtrator.ContentPanel.Controls.Add(this.txtRegEx);
            this.tabiExtrator.ContentPanel.Controls.Add(this.btnShowResult);
            this.tabiExtrator.ContentPanel.Controls.Add(this.radLabel1);
            this.tabiExtrator.ContentPanel.Controls.Add(this.rbtnSingleOccurrence);
            this.tabiExtrator.ContentPanel.Controls.Add(this.rbtnRandomOccurrence);
            this.tabiExtrator.ContentPanel.Controls.Add(this.rbtnAllOccurrence);
            this.tabiExtrator.ContentPanel.Controls.Add(this.radButton2);
            this.tabiExtrator.ContentPanel.Controls.Add(this.btnSave);
            this.tabiExtrator.ContentPanel.Controls.Add(this.lblResult);
            this.tabiExtrator.ContentPanel.Controls.Add(this.txtResult);
            this.tabiExtrator.ContentPanel.Controls.Add(this.lblOrdinal);
            this.tabiExtrator.ContentPanel.Controls.Add(this.lblName);
            this.tabiExtrator.ContentPanel.Controls.Add(this.txtOrdinal);
            this.tabiExtrator.ContentPanel.Controls.Add(this.txtName);
            this.tabiExtrator.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabiExtrator.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabiExtrator.ContentPanel.Location = new System.Drawing.Point(1, 23);
            this.tabiExtrator.ContentPanel.Size = new System.Drawing.Size(454, 331);
            this.tabiExtrator.IsSelected = true;
            this.tabiExtrator.Margin = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.tabiExtrator.Name = "tabiExtrator";
            this.tabiExtrator.StretchHorizontally = false;
            this.tabiExtrator.Text = "Extrator";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rbtnSimple);
            this.panel1.Controls.Add(this.rbtnAdvanced);
            this.panel1.Location = new System.Drawing.Point(140, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(304, 21);
            this.panel1.TabIndex = 1;
            // 
            // rbtnSimple
            // 
            this.rbtnSimple.AutoSize = true;
            this.rbtnSimple.Checked = true;
            this.rbtnSimple.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnSimple.ForeColor = System.Drawing.Color.Black;
            this.rbtnSimple.Location = new System.Drawing.Point(3, 2);
            this.rbtnSimple.Name = "rbtnSimple";
            this.rbtnSimple.Size = new System.Drawing.Size(64, 17);
            this.rbtnSimple.TabIndex = 0;
            this.rbtnSimple.TabStop = true;
            this.rbtnSimple.Text = "Simple";
            this.rbtnSimple.UseVisualStyleBackColor = true;
            this.rbtnSimple.CheckedChanged += new System.EventHandler(this.rbtnSimple_CheckedChanged);
            // 
            // rbtnAdvanced
            // 
            this.rbtnAdvanced.AutoSize = true;
            this.rbtnAdvanced.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAdvanced.ForeColor = System.Drawing.Color.Black;
            this.rbtnAdvanced.Location = new System.Drawing.Point(86, 2);
            this.rbtnAdvanced.Name = "rbtnAdvanced";
            this.rbtnAdvanced.Size = new System.Drawing.Size(135, 17);
            this.rbtnAdvanced.TabIndex = 1;
            this.rbtnAdvanced.Text = "Regular expression";
            this.rbtnAdvanced.UseVisualStyleBackColor = true;
            // 
            // radLabel3
            // 
            this.radLabel3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel3.ForeColor = System.Drawing.Color.Black;
            this.radLabel3.Location = new System.Drawing.Point(12, 47);
            this.radLabel3.Name = "radLabel3";
            // 
            // 
            // 
            this.radLabel3.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel3.Size = new System.Drawing.Size(46, 17);
            this.radLabel3.TabIndex = 27;
            this.radLabel3.Text = "Mode :";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.ForeColor = System.Drawing.Color.Black;
            this.radLabel4.Location = new System.Drawing.Point(12, 101);
            this.radLabel4.Name = "radLabel4";
            // 
            // 
            // 
            this.radLabel4.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel4.Size = new System.Drawing.Size(65, 17);
            this.radLabel4.TabIndex = 10;
            this.radLabel4.Text = "End with :";
            // 
            // txtEndwith
            // 
            this.txtEndwith.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEndwith.Location = new System.Drawing.Point(140, 101);
            this.txtEndwith.Name = "txtEndwith";
            this.txtEndwith.Size = new System.Drawing.Size(287, 19);
            this.txtEndwith.TabIndex = 3;
            this.txtEndwith.TabStop = false;
            this.txtEndwith.ThemeName = "Office2010";
            this.txtEndwith.TextChanged += new System.EventHandler(this.txtEndwith_TextChanged);
            this.txtEndwith.Leave += new System.EventHandler(this.txtLeave);
            // 
            // btnEndWith
            // 
            this.btnEndWith.Location = new System.Drawing.Point(430, 102);
            this.btnEndWith.Name = "btnEndWith";
            this.btnEndWith.Size = new System.Drawing.Size(18, 20);
            this.btnEndWith.TabIndex = 4;
            this.btnEndWith.Text = "..";
            this.btnEndWith.ThemeName = "Telerik";
            this.btnEndWith.Click += new System.EventHandler(this.btnEndWith_Click);
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel5.ForeColor = System.Drawing.Color.Black;
            this.radLabel5.Location = new System.Drawing.Point(12, 72);
            this.radLabel5.Name = "radLabel5";
            // 
            // 
            // 
            this.radLabel5.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel5.Size = new System.Drawing.Size(72, 17);
            this.radLabel5.TabIndex = 9;
            this.radLabel5.Text = "Start with :";
            // 
            // txtGroupIndex
            // 
            this.txtGroupIndex.Enabled = false;
            this.txtGroupIndex.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGroupIndex.Location = new System.Drawing.Point(140, 159);
            this.txtGroupIndex.Name = "txtGroupIndex";
            this.txtGroupIndex.Size = new System.Drawing.Size(46, 19);
            this.txtGroupIndex.TabIndex = 5;
            this.txtGroupIndex.TabStop = false;
            this.txtGroupIndex.Text = "1";
            this.txtGroupIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtGroupIndex.ThemeName = "Office2010";
            this.txtGroupIndex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGroupIndex_KeyPress);
            this.txtGroupIndex.Leave += new System.EventHandler(this.txtLeave);
            // 
            // txtStartwith
            // 
            this.txtStartwith.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStartwith.Location = new System.Drawing.Point(140, 72);
            this.txtStartwith.Name = "txtStartwith";
            this.txtStartwith.Size = new System.Drawing.Size(287, 19);
            this.txtStartwith.TabIndex = 2;
            this.txtStartwith.TabStop = false;
            this.txtStartwith.ThemeName = "Office2010";
            this.txtStartwith.TextChanged += new System.EventHandler(this.txtStartwith_TextChanged);
            this.txtStartwith.Leave += new System.EventHandler(this.txtLeave);
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.ForeColor = System.Drawing.Color.Black;
            this.radLabel2.Location = new System.Drawing.Point(12, 159);
            this.radLabel2.Name = "radLabel2";
            // 
            // 
            // 
            this.radLabel2.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel2.Size = new System.Drawing.Size(86, 17);
            this.radLabel2.TabIndex = 25;
            this.radLabel2.Text = "Group Index :";
            // 
            // btnStartWith
            // 
            this.btnStartWith.Location = new System.Drawing.Point(430, 73);
            this.btnStartWith.Name = "btnStartWith";
            this.btnStartWith.Size = new System.Drawing.Size(18, 20);
            this.btnStartWith.TabIndex = 2;
            this.btnStartWith.Text = "..";
            this.btnStartWith.ThemeName = "Telerik";
            this.btnStartWith.Click += new System.EventHandler(this.btnStartWith_Click);
            // 
            // radLabel7
            // 
            this.radLabel7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel7.ForeColor = System.Drawing.Color.Black;
            this.radLabel7.Location = new System.Drawing.Point(12, 130);
            this.radLabel7.Name = "radLabel7";
            // 
            // 
            // 
            this.radLabel7.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel7.Size = new System.Drawing.Size(124, 17);
            this.radLabel7.TabIndex = 24;
            this.radLabel7.Text = "Regular Expression :";
            // 
            // txtRegEx
            // 
            this.txtRegEx.Enabled = false;
            this.txtRegEx.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegEx.Location = new System.Drawing.Point(140, 130);
            this.txtRegEx.Name = "txtRegEx";
            this.txtRegEx.Size = new System.Drawing.Size(308, 19);
            this.txtRegEx.TabIndex = 4;
            this.txtRegEx.TabStop = false;
            this.txtRegEx.Text = "(.*?)";
            this.txtRegEx.ThemeName = "Office2010";
            this.txtRegEx.Leave += new System.EventHandler(this.txtLeave);
            // 
            // btnShowResult
            // 
            this.btnShowResult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnShowResult.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowResult.Location = new System.Drawing.Point(140, 295);
            this.btnShowResult.Name = "btnShowResult";
            this.btnShowResult.Size = new System.Drawing.Size(80, 24);
            this.btnShowResult.TabIndex = 11;
            this.btnShowResult.Text = "Show &Result";
            this.btnShowResult.ThemeName = "Telerik";
            this.btnShowResult.Click += new System.EventHandler(this.btnShowResult_Click);
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.ForeColor = System.Drawing.Color.Black;
            this.radLabel1.Location = new System.Drawing.Point(12, 188);
            this.radLabel1.Name = "radLabel1";
            // 
            // 
            // 
            this.radLabel1.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel1.Size = new System.Drawing.Size(99, 17);
            this.radLabel1.TabIndex = 17;
            this.radLabel1.Text = "Selection Type :";
            // 
            // rbtnSingleOccurrence
            // 
            this.rbtnSingleOccurrence.AutoSize = true;
            this.rbtnSingleOccurrence.Checked = true;
            this.rbtnSingleOccurrence.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnSingleOccurrence.ForeColor = System.Drawing.Color.Black;
            this.rbtnSingleOccurrence.Location = new System.Drawing.Point(276, 188);
            this.rbtnSingleOccurrence.Name = "rbtnSingleOccurrence";
            this.rbtnSingleOccurrence.Size = new System.Drawing.Size(60, 17);
            this.rbtnSingleOccurrence.TabIndex = 8;
            this.rbtnSingleOccurrence.TabStop = true;
            this.rbtnSingleOccurrence.Text = "Single";
            this.rbtnSingleOccurrence.UseVisualStyleBackColor = true;
            this.rbtnSingleOccurrence.CheckedChanged += new System.EventHandler(this.txtLeave);
            this.rbtnSingleOccurrence.Leave += new System.EventHandler(this.txtLeave);
            // 
            // rbtnRandomOccurrence
            // 
            this.rbtnRandomOccurrence.AutoSize = true;
            this.rbtnRandomOccurrence.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnRandomOccurrence.ForeColor = System.Drawing.Color.Black;
            this.rbtnRandomOccurrence.Location = new System.Drawing.Point(198, 188);
            this.rbtnRandomOccurrence.Name = "rbtnRandomOccurrence";
            this.rbtnRandomOccurrence.Size = new System.Drawing.Size(72, 17);
            this.rbtnRandomOccurrence.TabIndex = 7;
            this.rbtnRandomOccurrence.Text = "Random";
            this.rbtnRandomOccurrence.UseVisualStyleBackColor = true;
            this.rbtnRandomOccurrence.CheckedChanged += new System.EventHandler(this.txtLeave);
            this.rbtnRandomOccurrence.Leave += new System.EventHandler(this.txtLeave);
            // 
            // rbtnAllOccurrence
            // 
            this.rbtnAllOccurrence.AutoSize = true;
            this.rbtnAllOccurrence.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnAllOccurrence.ForeColor = System.Drawing.Color.Black;
            this.rbtnAllOccurrence.Location = new System.Drawing.Point(140, 188);
            this.rbtnAllOccurrence.Name = "rbtnAllOccurrence";
            this.rbtnAllOccurrence.Size = new System.Drawing.Size(43, 17);
            this.rbtnAllOccurrence.TabIndex = 6;
            this.rbtnAllOccurrence.Text = "All ";
            this.rbtnAllOccurrence.UseVisualStyleBackColor = true;
            this.rbtnAllOccurrence.CheckedChanged += new System.EventHandler(this.txtLeave);
            // 
            // radButton2
            // 
            this.radButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.radButton2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.radButton2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radButton2.Location = new System.Drawing.Point(316, 295);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(80, 24);
            this.radButton2.TabIndex = 13;
            this.radButton2.Text = "&Cancel";
            this.radButton2.ThemeName = "Telerik";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSave.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(228, 295);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(80, 24);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "&Save";
            this.btnSave.ThemeName = "Telerik";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblResult
            // 
            this.lblResult.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.ForeColor = System.Drawing.Color.Black;
            this.lblResult.Location = new System.Drawing.Point(12, 213);
            this.lblResult.Name = "lblResult";
            // 
            // 
            // 
            this.lblResult.RootElement.ForeColor = System.Drawing.Color.Black;
            this.lblResult.Size = new System.Drawing.Size(51, 17);
            this.lblResult.TabIndex = 9;
            this.lblResult.Text = "Result :";
            // 
            // txtResult
            // 
            this.txtResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResult.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResult.Location = new System.Drawing.Point(140, 213);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            // 
            // 
            // 
            this.txtResult.RootElement.StretchVertically = true;
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResult.Size = new System.Drawing.Size(306, 75);
            this.txtResult.TabIndex = 10;
            this.txtResult.TabStop = false;
            this.txtResult.ThemeName = "Office2010";
            // 
            // lblOrdinal
            // 
            this.lblOrdinal.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrdinal.ForeColor = System.Drawing.Color.Black;
            this.lblOrdinal.Location = new System.Drawing.Point(401, 191);
            this.lblOrdinal.Name = "lblOrdinal";
            // 
            // 
            // 
            this.lblOrdinal.RootElement.ForeColor = System.Drawing.Color.Black;
            this.lblOrdinal.Size = new System.Drawing.Size(47, 17);
            this.lblOrdinal.TabIndex = 9;
            this.lblOrdinal.Text = "Ordinal";
            // 
            // lblName
            // 
            this.lblName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Black;
            this.lblName.Location = new System.Drawing.Point(12, 18);
            this.lblName.Name = "lblName";
            // 
            // 
            // 
            this.lblName.RootElement.ForeColor = System.Drawing.Color.Black;
            this.lblName.Size = new System.Drawing.Size(48, 17);
            this.lblName.TabIndex = 4;
            this.lblName.Text = "Name :";
            // 
            // txtOrdinal
            // 
            this.txtOrdinal.Location = new System.Drawing.Point(343, 188);
            this.txtOrdinal.Name = "txtOrdinal";
            this.txtOrdinal.Size = new System.Drawing.Size(50, 20);
            this.txtOrdinal.TabIndex = 9;
            this.txtOrdinal.TabStop = false;
            this.txtOrdinal.Text = "1";
            this.txtOrdinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOrdinal.ThemeName = "Office2010";
            this.txtOrdinal.Enter += new System.EventHandler(this.txtOrdinal_Enter);
            this.txtOrdinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrdinal_KeyPress);
            this.txtOrdinal.Leave += new System.EventHandler(this.txtLeave);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(140, 18);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(308, 19);
            this.txtName.TabIndex = 0;
            this.txtName.TabStop = false;
            this.txtName.ThemeName = "Office2010";
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtName_KeyPress);
            // 
            // tabiTest
            // 
            this.tabiTest.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tabiTest.ContentPanel
            // 
            this.tabiTest.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(239)))), ((int)(((byte)(249)))));
            this.tabiTest.ContentPanel.CausesValidation = true;
            this.tabiTest.ContentPanel.Controls.Add(this.txtResponse);
            this.tabiTest.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabiTest.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabiTest.ContentPanel.Location = new System.Drawing.Point(1, 23);
            this.tabiTest.ContentPanel.Size = new System.Drawing.Size(454, 331);
            this.tabiTest.Margin = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.tabiTest.Name = "tabiTest";
            this.tabiTest.StretchHorizontally = false;
            this.tabiTest.Text = "Response";
            // 
            // txtResponse
            // 
            this.txtResponse.AutoScroll = true;
            this.txtResponse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResponse.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResponse.Location = new System.Drawing.Point(0, 0);
            this.txtResponse.Multiline = true;
            this.txtResponse.Name = "txtResponse";
            // 
            // 
            // 
            this.txtResponse.RootElement.StretchVertically = true;
            this.txtResponse.Size = new System.Drawing.Size(454, 331);
            this.txtResponse.TabIndex = 0;
            this.txtResponse.TabStop = false;
            // 
            // frmExtrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 355);
            this.Controls.Add(this.radTabStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "frmExtrator";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Extrator";
            this.ThemeName = "Windows7";
            ((System.ComponentModel.ISupportInitialize)(this.radTabStrip1)).EndInit();
            this.radTabStrip1.ResumeLayout(false);
            this.tabiExtrator.ContentPanel.ResumeLayout(false);
            this.tabiExtrator.ContentPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEndwith)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEndWith)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGroupIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtStartwith)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnStartWith)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRegEx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnShowResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblOrdinal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOrdinal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).EndInit();
            this.tabiTest.ContentPanel.ResumeLayout(false);
            this.tabiTest.ContentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadTabStrip radTabStrip1;
        private Telerik.WinControls.UI.TabItem tabiExtrator;
        private Telerik.WinControls.UI.RadTextBox txtName;
        private Telerik.WinControls.UI.TabItem tabiTest;
        private Telerik.WinControls.UI.RadLabel lblOrdinal;
        private Telerik.WinControls.UI.RadLabel lblName;
        private Telerik.WinControls.UI.RadTextBox txtOrdinal;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadButton btnSave;
        private Telerik.WinControls.UI.RadLabel lblResult;
        private Telerik.WinControls.UI.RadTextBox txtResult;
        private Telerik.WinControls.UI.RadTextBox txtResponse;
        private Telerik.WinControls.UI.RadButton btnStartWith;
        private Telerik.WinControls.UI.RadButton btnEndWith;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private System.Windows.Forms.RadioButton rbtnSingleOccurrence;
        private System.Windows.Forms.RadioButton rbtnRandomOccurrence;
        private System.Windows.Forms.RadioButton rbtnAllOccurrence;
        private Telerik.WinControls.UI.RadButton btnShowResult;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadTextBox txtEndwith;
        private Telerik.WinControls.UI.RadTextBox txtStartwith;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadTextBox txtRegEx;
        private Telerik.WinControls.UI.RadTextBox txtGroupIndex;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private System.Windows.Forms.RadioButton rbtnAdvanced;
        private System.Windows.Forms.RadioButton rbtnSimple;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private System.Windows.Forms.Panel panel1;
    }
}

