namespace AppedoLT
{
    partial class frmTcpAssertion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new Telerik.WinControls.UI.RadLabel();
            this.txtRequestStartlength = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.txtRequestStartPosition = new Telerik.WinControls.UI.RadTextBox();
            this.ddlType = new Telerik.WinControls.UI.RadComboBox();
            this.radComboBoxItem3 = new Telerik.WinControls.UI.RadComboBoxItem();
            this.radComboBoxItem4 = new Telerik.WinControls.UI.RadComboBoxItem();
            this.radComboBoxItem1 = new Telerik.WinControls.UI.RadComboBoxItem();
            this.radComboBoxItem2 = new Telerik.WinControls.UI.RadComboBoxItem();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.grbRequest = new Telerik.WinControls.UI.RadGroupBox();
            this.pnlRequest = new System.Windows.Forms.Panel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.txtRequest = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.txtErrorMessage = new Telerik.WinControls.UI.RadTextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.grbResponse = new Telerik.WinControls.UI.RadGroupBox();
            this.pnlResponse = new System.Windows.Forms.Panel();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.txtResponseStartPosition = new Telerik.WinControls.UI.RadTextBox();
            this.txtResponseStartlength = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.txtResponse = new Telerik.WinControls.UI.RadTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.lblName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRequestStartlength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRequestStartPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grbRequest)).BeginInit();
            this.grbRequest.SuspendLayout();
            this.pnlRequest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRequest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorMessage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grbResponse)).BeginInit();
            this.grbResponse.SuspendLayout();
            this.pnlResponse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponseStartPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponseStartlength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.BackColor = System.Drawing.Color.White;
            this.lblName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(2, 31);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(84, 18);
            this.lblName.TabIndex = 36;
            this.lblName.Text = "Start Length";
            // 
            // txtRequestStartlength
            // 
            this.txtRequestStartlength.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtRequestStartlength.Location = new System.Drawing.Point(98, 31);
            this.txtRequestStartlength.Name = "txtRequestStartlength";
            this.txtRequestStartlength.Size = new System.Drawing.Size(74, 19);
            this.txtRequestStartlength.TabIndex = 35;
            this.txtRequestStartlength.TabStop = false;
            // 
            // radLabel3
            // 
            this.radLabel3.BackColor = System.Drawing.Color.White;
            this.radLabel3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel3.Location = new System.Drawing.Point(2, 2);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(90, 18);
            this.radLabel3.TabIndex = 34;
            this.radLabel3.Text = "Start Position";
            // 
            // txtRequestStartPosition
            // 
            this.txtRequestStartPosition.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtRequestStartPosition.Location = new System.Drawing.Point(98, 4);
            this.txtRequestStartPosition.Name = "txtRequestStartPosition";
            this.txtRequestStartPosition.Size = new System.Drawing.Size(74, 19);
            this.txtRequestStartPosition.TabIndex = 33;
            this.txtRequestStartPosition.TabStop = false;
            // 
            // ddlType
            // 
            this.ddlType.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.ddlType.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.radComboBoxItem3,
            this.radComboBoxItem4,
            this.radComboBoxItem1,
            this.radComboBoxItem2});
            this.ddlType.Location = new System.Drawing.Point(104, 10);
            this.ddlType.Name = "ddlType";
            // 
            // 
            // 
            this.ddlType.RootElement.AutoSizeMode = Telerik.WinControls.RadAutoSizeMode.WrapAroundChildren;
            this.ddlType.Size = new System.Drawing.Size(228, 21);
            this.ddlType.TabIndex = 41;
            this.ddlType.TabStop = false;
            this.ddlType.ThemeName = "Telerik";
            this.ddlType.SelectedIndexChanged += new System.EventHandler(this.ddlType_SelectedIndexChanged);
            // 
            // radComboBoxItem3
            // 
            this.radComboBoxItem3.Name = "radComboBoxItem3";
            this.radComboBoxItem3.Text = "Request-NotContain";
            // 
            // radComboBoxItem4
            // 
            this.radComboBoxItem4.Name = "radComboBoxItem4";
            this.radComboBoxItem4.Text = "Response-NotContain";
            // 
            // radComboBoxItem1
            // 
            this.radComboBoxItem1.Name = "radComboBoxItem1";
            this.radComboBoxItem1.Text = "Req-Res-Equal";
            // 
            // radComboBoxItem2
            // 
            this.radComboBoxItem2.Name = "radComboBoxItem2";
            this.radComboBoxItem2.Text = "Req-Res-NotEqual";
            // 
            // radLabel4
            // 
            this.radLabel4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.ForeColor = System.Drawing.Color.Black;
            this.radLabel4.Location = new System.Drawing.Point(64, 12);
            this.radLabel4.Name = "radLabel4";
            // 
            // 
            // 
            this.radLabel4.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel4.Size = new System.Drawing.Size(36, 18);
            this.radLabel4.TabIndex = 42;
            this.radLabel4.Text = "Type";
            // 
            // grbRequest
            // 
            this.grbRequest.Controls.Add(this.pnlRequest);
            this.grbRequest.Controls.Add(this.radLabel2);
            this.grbRequest.Controls.Add(this.txtRequest);
            this.grbRequest.Enabled = false;
            this.grbRequest.FooterImageIndex = -1;
            this.grbRequest.FooterImageKey = "";
            this.grbRequest.HeaderImageIndex = -1;
            this.grbRequest.HeaderImageKey = "";
            this.grbRequest.HeaderMargin = new System.Windows.Forms.Padding(0);
            this.grbRequest.HeaderText = "Request";
            this.grbRequest.Location = new System.Drawing.Point(3, 36);
            this.grbRequest.Name = "grbRequest";
            this.grbRequest.Padding = new System.Windows.Forms.Padding(10, 20, 10, 10);
            // 
            // 
            // 
            this.grbRequest.RootElement.Padding = new System.Windows.Forms.Padding(10, 20, 10, 10);
            this.grbRequest.Size = new System.Drawing.Size(329, 119);
            this.grbRequest.TabIndex = 45;
            this.grbRequest.Text = "Request";
            // 
            // pnlRequest
            // 
            this.pnlRequest.BackColor = System.Drawing.Color.White;
            this.pnlRequest.Controls.Add(this.radLabel3);
            this.pnlRequest.Controls.Add(this.lblName);
            this.pnlRequest.Controls.Add(this.txtRequestStartPosition);
            this.pnlRequest.Controls.Add(this.txtRequestStartlength);
            this.pnlRequest.Location = new System.Drawing.Point(15, 56);
            this.pnlRequest.Name = "pnlRequest";
            this.pnlRequest.Size = new System.Drawing.Size(303, 54);
            this.pnlRequest.TabIndex = 39;
            // 
            // radLabel2
            // 
            this.radLabel2.BackColor = System.Drawing.Color.White;
            this.radLabel2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.Location = new System.Drawing.Point(21, 32);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(34, 18);
            this.radLabel2.TabIndex = 36;
            this.radLabel2.Text = "Text";
            // 
            // txtRequest
            // 
            this.txtRequest.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtRequest.Location = new System.Drawing.Point(110, 32);
            this.txtRequest.Name = "txtRequest";
            this.txtRequest.Size = new System.Drawing.Size(208, 19);
            this.txtRequest.TabIndex = 35;
            this.txtRequest.TabStop = false;
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(3, 292);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(95, 18);
            this.radLabel1.TabIndex = 48;
            this.radLabel1.Text = "Error Message";
            // 
            // txtErrorMessage
            // 
            this.txtErrorMessage.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtErrorMessage.Location = new System.Drawing.Point(114, 291);
            this.txtErrorMessage.Name = "txtErrorMessage";
            this.txtErrorMessage.Size = new System.Drawing.Size(216, 19);
            this.txtErrorMessage.TabIndex = 47;
            this.txtErrorMessage.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSave.Location = new System.Drawing.Point(170, 316);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 49;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(251, 316);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 50;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // grbResponse
            // 
            this.grbResponse.Controls.Add(this.pnlResponse);
            this.grbResponse.Controls.Add(this.radLabel7);
            this.grbResponse.Controls.Add(this.txtResponse);
            this.grbResponse.Enabled = false;
            this.grbResponse.FooterImageIndex = -1;
            this.grbResponse.FooterImageKey = "";
            this.grbResponse.HeaderImageIndex = -1;
            this.grbResponse.HeaderImageKey = "";
            this.grbResponse.HeaderMargin = new System.Windows.Forms.Padding(0);
            this.grbResponse.HeaderText = "Response";
            this.grbResponse.Location = new System.Drawing.Point(3, 161);
            this.grbResponse.Name = "grbResponse";
            this.grbResponse.Padding = new System.Windows.Forms.Padding(10, 20, 10, 10);
            // 
            // 
            // 
            this.grbResponse.RootElement.Padding = new System.Windows.Forms.Padding(10, 20, 10, 10);
            this.grbResponse.Size = new System.Drawing.Size(329, 125);
            this.grbResponse.TabIndex = 51;
            this.grbResponse.Text = "Response";
            // 
            // pnlResponse
            // 
            this.pnlResponse.BackColor = System.Drawing.Color.White;
            this.pnlResponse.Controls.Add(this.radLabel5);
            this.pnlResponse.Controls.Add(this.radLabel6);
            this.pnlResponse.Controls.Add(this.txtResponseStartPosition);
            this.pnlResponse.Controls.Add(this.txtResponseStartlength);
            this.pnlResponse.Location = new System.Drawing.Point(13, 57);
            this.pnlResponse.Name = "pnlResponse";
            this.pnlResponse.Size = new System.Drawing.Size(305, 54);
            this.pnlResponse.TabIndex = 39;
            // 
            // radLabel5
            // 
            this.radLabel5.BackColor = System.Drawing.Color.White;
            this.radLabel5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel5.Location = new System.Drawing.Point(2, 2);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(90, 18);
            this.radLabel5.TabIndex = 34;
            this.radLabel5.Text = "Start Position";
            // 
            // radLabel6
            // 
            this.radLabel6.BackColor = System.Drawing.Color.White;
            this.radLabel6.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel6.Location = new System.Drawing.Point(2, 31);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(84, 18);
            this.radLabel6.TabIndex = 36;
            this.radLabel6.Text = "Start Length";
            // 
            // txtResponseStartPosition
            // 
            this.txtResponseStartPosition.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtResponseStartPosition.Location = new System.Drawing.Point(98, 4);
            this.txtResponseStartPosition.Name = "txtResponseStartPosition";
            this.txtResponseStartPosition.Size = new System.Drawing.Size(74, 19);
            this.txtResponseStartPosition.TabIndex = 33;
            this.txtResponseStartPosition.TabStop = false;
            // 
            // txtResponseStartlength
            // 
            this.txtResponseStartlength.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtResponseStartlength.Location = new System.Drawing.Point(98, 31);
            this.txtResponseStartlength.Name = "txtResponseStartlength";
            this.txtResponseStartlength.Size = new System.Drawing.Size(74, 19);
            this.txtResponseStartlength.TabIndex = 35;
            this.txtResponseStartlength.TabStop = false;
            // 
            // radLabel7
            // 
            this.radLabel7.BackColor = System.Drawing.Color.White;
            this.radLabel7.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel7.Location = new System.Drawing.Point(21, 32);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(34, 18);
            this.radLabel7.TabIndex = 36;
            this.radLabel7.Text = "Text";
            // 
            // txtResponse
            // 
            this.txtResponse.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtResponse.Location = new System.Drawing.Point(110, 32);
            this.txtResponse.Name = "txtResponse";
            this.txtResponse.Size = new System.Drawing.Size(207, 19);
            this.txtResponse.TabIndex = 35;
            this.txtResponse.TabStop = false;
            // 
            // frmTcpAssertion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(344, 350);
            this.Controls.Add(this.grbResponse);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.radLabel1);
            this.Controls.Add(this.txtErrorMessage);
            this.Controls.Add(this.grbRequest);
            this.Controls.Add(this.radLabel4);
            this.Controls.Add(this.ddlType);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.Name = "frmTcpAssertion";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TcpAssertion";
            this.ThemeName = "Vista";
            ((System.ComponentModel.ISupportInitialize)(this.lblName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRequestStartlength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRequestStartPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grbRequest)).EndInit();
            this.grbRequest.ResumeLayout(false);
            this.grbRequest.PerformLayout();
            this.pnlRequest.ResumeLayout(false);
            this.pnlRequest.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRequest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorMessage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grbResponse)).EndInit();
            this.grbResponse.ResumeLayout(false);
            this.grbResponse.PerformLayout();
            this.pnlResponse.ResumeLayout(false);
            this.pnlResponse.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponseStartPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponseStartlength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtResponse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadLabel lblName;
        private Telerik.WinControls.UI.RadTextBox txtRequestStartlength;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadTextBox txtRequestStartPosition;
        private Telerik.WinControls.UI.RadComboBox ddlType;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadGroupBox grbRequest;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadTextBox txtErrorMessage;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private Telerik.WinControls.UI.RadComboBoxItem radComboBoxItem1;
        private Telerik.WinControls.UI.RadComboBoxItem radComboBoxItem2;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadTextBox txtRequest;
        private System.Windows.Forms.Panel pnlRequest;
        private Telerik.WinControls.UI.RadComboBoxItem radComboBoxItem3;
        private Telerik.WinControls.UI.RadComboBoxItem radComboBoxItem4;
        private Telerik.WinControls.UI.RadGroupBox grbResponse;
        private System.Windows.Forms.Panel pnlResponse;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadTextBox txtResponseStartPosition;
        private Telerik.WinControls.UI.RadTextBox txtResponseStartlength;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadTextBox txtResponse;
    }
}

