﻿namespace AppedoLT
{
    partial class UCMonitor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.radSplitContainer1 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel1 = new Telerik.WinControls.UI.SplitPanel();
            this.tabsMonitor = new Telerik.WinControls.UI.RadTabStrip();
            this.tabiConfiguration = new Telerik.WinControls.UI.TabItem();
            this.radSplitContainer2 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel2 = new Telerik.WinControls.UI.SplitPanel();
            this.btnSave = new Telerik.WinControls.UI.RadButton();
            this.tvServers = new Telerik.WinControls.UI.RadTreeView();
            this.btnRemove = new Telerik.WinControls.UI.RadButton();
            this.btnAdd = new Telerik.WinControls.UI.RadButton();
            this.splitPanel3 = new Telerik.WinControls.UI.SplitPanel();
            this.tabiRun = new Telerik.WinControls.UI.TabItem();
            this.radSplitContainer3 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel4 = new Telerik.WinControls.UI.SplitPanel();
            this.tvServersWithCounters = new Telerik.WinControls.UI.RadTreeView();
            this.splitPanel5 = new Telerik.WinControls.UI.SplitPanel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.txtReportName = new Telerik.WinControls.UI.RadTextBox();
            this.btnRun = new Telerik.WinControls.UI.RadButton();
            this.tabItem1 = new Telerik.WinControls.UI.TabItem();
            this.radSplitContainer4 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel6 = new Telerik.WinControls.UI.SplitPanel();
            this.ddlReportName = new Telerik.WinControls.UI.RadComboBox();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.tvChart = new Telerik.WinControls.UI.RadTreeView();
            this.splitPanel7 = new Telerik.WinControls.UI.SplitPanel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.radGridView1 = new Telerik.WinControls.UI.RadGridView();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).BeginInit();
            this.radSplitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).BeginInit();
            this.splitPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabsMonitor)).BeginInit();
            this.tabsMonitor.SuspendLayout();
            this.tabiConfiguration.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer2)).BeginInit();
            this.radSplitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).BeginInit();
            this.splitPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tvServers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRemove)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).BeginInit();
            this.tabiRun.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer3)).BeginInit();
            this.radSplitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel4)).BeginInit();
            this.splitPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tvServersWithCounters)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel5)).BeginInit();
            this.splitPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReportName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRun)).BeginInit();
            this.tabItem1.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer4)).BeginInit();
            this.radSplitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel6)).BeginInit();
            this.splitPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ddlReportName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tvChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel7)).BeginInit();
            this.splitPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterGridViewTemplate)).BeginInit();
            this.SuspendLayout();
            // 
            // radSplitContainer1
            // 
            this.radSplitContainer1.Controls.Add(this.splitPanel1);
            this.radSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer1.Name = "radSplitContainer1";
            // 
            // 
            // 
            this.radSplitContainer1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer1.Size = new System.Drawing.Size(1109, 413);
            this.radSplitContainer1.TabIndex = 26;
            this.radSplitContainer1.TabStop = false;
            this.radSplitContainer1.Text = "radSplitContainer1";
            // 
            // splitPanel1
            // 
            this.splitPanel1.Controls.Add(this.tabsMonitor);
            this.splitPanel1.Location = new System.Drawing.Point(0, 0);
            this.splitPanel1.Name = "splitPanel1";
            // 
            // 
            // 
            this.splitPanel1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel1.Size = new System.Drawing.Size(1109, 413);
            this.splitPanel1.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(-0.2625821F, 0F);
            this.splitPanel1.SizeInfo.SplitterCorrection = new System.Drawing.Size(-240, 0);
            this.splitPanel1.TabIndex = 0;
            this.splitPanel1.TabStop = false;
            this.splitPanel1.Text = "splitPanel1";
            // 
            // tabsMonitor
            // 
            this.tabsMonitor.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.tabsMonitor.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.tabsMonitor.BackColor = System.Drawing.Color.Transparent;
            this.tabsMonitor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabsMonitor.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.tabiConfiguration,
            this.tabiRun,
            this.tabItem1});
            this.tabsMonitor.ItemsOffset = 100;
            this.tabsMonitor.Location = new System.Drawing.Point(0, 0);
            this.tabsMonitor.Name = "tabsMonitor";
            this.tabsMonitor.ScrollOffsetStep = 5;
            this.tabsMonitor.Size = new System.Drawing.Size(1109, 413);
            this.tabsMonitor.TabIndex = 0;
            this.tabsMonitor.TabScrollButtonsPosition = Telerik.WinControls.UI.TabScrollButtonsPosition.RightBottom;
            this.tabsMonitor.Text = "radTabStrip1";
            this.tabsMonitor.ThemeName = "ControlDefault";
            this.tabsMonitor.Resize += new System.EventHandler(this.tabsMonitor_Resize);
            // 
            // tabiConfiguration
            // 
            this.tabiConfiguration.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            this.tabiConfiguration.AutoSizeMode = Telerik.WinControls.RadAutoSizeMode.FitToAvailableSize;
            // 
            // tabiConfiguration.ContentPanel
            // 
            this.tabiConfiguration.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(239)))), ((int)(((byte)(249)))));
            this.tabiConfiguration.ContentPanel.CausesValidation = true;
            this.tabiConfiguration.ContentPanel.Controls.Add(this.radSplitContainer2);
            this.tabiConfiguration.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabiConfiguration.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabiConfiguration.ContentPanel.Location = new System.Drawing.Point(1, 36);
            this.tabiConfiguration.ContentPanel.Size = new System.Drawing.Size(1107, 376);
            this.tabiConfiguration.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.tabiConfiguration.ForeColor = System.Drawing.Color.Black;
            this.tabiConfiguration.Margin = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.tabiConfiguration.Name = "tabiConfiguration";
            this.tabiConfiguration.PositionOffset = new System.Drawing.SizeF(0F, 0F);
            this.tabiConfiguration.ScaleTransform = new System.Drawing.SizeF(1.2F, 1.2F);
            this.tabiConfiguration.StretchHorizontally = false;
            this.tabiConfiguration.Text = "Configuration";
            // 
            // radSplitContainer2
            // 
            this.radSplitContainer2.Controls.Add(this.splitPanel2);
            this.radSplitContainer2.Controls.Add(this.splitPanel3);
            this.radSplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer2.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer2.Name = "radSplitContainer2";
            // 
            // 
            // 
            this.radSplitContainer2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer2.Size = new System.Drawing.Size(1107, 376);
            this.radSplitContainer2.TabIndex = 0;
            this.radSplitContainer2.TabStop = false;
            this.radSplitContainer2.Text = "radSplitContainer2";
            // 
            // splitPanel2
            // 
            this.splitPanel2.Controls.Add(this.btnSave);
            this.splitPanel2.Controls.Add(this.tvServers);
            this.splitPanel2.Controls.Add(this.btnRemove);
            this.splitPanel2.Controls.Add(this.btnAdd);
            this.splitPanel2.Location = new System.Drawing.Point(0, 0);
            this.splitPanel2.Name = "splitPanel2";
            // 
            // 
            // 
            this.splitPanel2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel2.Size = new System.Drawing.Size(261, 376);
            this.splitPanel2.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(-0.2635869F, 0F);
            this.splitPanel2.SizeInfo.SplitterCorrection = new System.Drawing.Size(-299, 0);
            this.splitPanel2.TabIndex = 0;
            this.splitPanel2.TabStop = false;
            this.splitPanel2.Text = "splitPanel2";
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnSave.Location = new System.Drawing.Point(174, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 24);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Save";
            this.btnSave.ThemeName = "Telerik";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tvServers
            // 
            this.tvServers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tvServers.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvServers.Location = new System.Drawing.Point(3, 29);
            this.tvServers.Name = "tvServers";
            this.tvServers.Size = new System.Drawing.Size(256, 344);
            this.tvServers.TabIndex = 0;
            this.tvServers.Text = "radTreeView1";
            this.tvServers.ThemeName = "Telerik";
            this.tvServers.SelectedNodeChanged += new Telerik.WinControls.UI.RadTreeView.RadTreeViewEventHandler(this.tvServers_SelectedNodeChanged);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnRemove.Location = new System.Drawing.Point(88, 4);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(85, 24);
            this.btnRemove.TabIndex = 1;
            this.btnRemove.Text = "(-) Remove";
            this.btnRemove.ThemeName = "Telerik";
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnAdd.Location = new System.Drawing.Point(2, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(85, 24);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "(+) Add";
            this.btnAdd.ThemeName = "Telerik";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // splitPanel3
            // 
            this.splitPanel3.Location = new System.Drawing.Point(264, 0);
            this.splitPanel3.Name = "splitPanel3";
            // 
            // 
            // 
            this.splitPanel3.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel3.Size = new System.Drawing.Size(843, 376);
            this.splitPanel3.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(0.2635869F, 0F);
            this.splitPanel3.SizeInfo.SplitterCorrection = new System.Drawing.Size(299, 0);
            this.splitPanel3.TabIndex = 1;
            this.splitPanel3.TabStop = false;
            this.splitPanel3.Text = "splitPanel3";
            // 
            // tabiRun
            // 
            this.tabiRun.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tabiRun.ContentPanel
            // 
            this.tabiRun.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(239)))), ((int)(((byte)(249)))));
            this.tabiRun.ContentPanel.CausesValidation = true;
            this.tabiRun.ContentPanel.Controls.Add(this.radSplitContainer3);
            this.tabiRun.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabiRun.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabiRun.ContentPanel.Location = new System.Drawing.Point(1, 36);
            this.tabiRun.ContentPanel.Size = new System.Drawing.Size(1107, 376);
            this.tabiRun.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.tabiRun.ForeColor = System.Drawing.Color.Black;
            this.tabiRun.Margin = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.tabiRun.Name = "tabiRun";
            this.tabiRun.ScaleTransform = new System.Drawing.SizeF(1.2F, 1.2F);
            this.tabiRun.StretchHorizontally = false;
            this.tabiRun.Text = "Run";
            // 
            // radSplitContainer3
            // 
            this.radSplitContainer3.Controls.Add(this.splitPanel4);
            this.radSplitContainer3.Controls.Add(this.splitPanel5);
            this.radSplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer3.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer3.Name = "radSplitContainer3";
            // 
            // 
            // 
            this.radSplitContainer3.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer3.Size = new System.Drawing.Size(1107, 376);
            this.radSplitContainer3.TabIndex = 0;
            this.radSplitContainer3.TabStop = false;
            this.radSplitContainer3.Text = "radSplitContainer3";
            // 
            // splitPanel4
            // 
            this.splitPanel4.Controls.Add(this.tvServersWithCounters);
            this.splitPanel4.Location = new System.Drawing.Point(0, 0);
            this.splitPanel4.Name = "splitPanel4";
            // 
            // 
            // 
            this.splitPanel4.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel4.Size = new System.Drawing.Size(261, 376);
            this.splitPanel4.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(-0.2635869F, 0F);
            this.splitPanel4.SizeInfo.SplitterCorrection = new System.Drawing.Size(-291, 0);
            this.splitPanel4.TabIndex = 0;
            this.splitPanel4.TabStop = false;
            this.splitPanel4.Text = "splitPanel4";
            // 
            // tvServersWithCounters
            // 
            this.tvServersWithCounters.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tvServersWithCounters.CheckBoxes = true;
            this.tvServersWithCounters.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvServersWithCounters.ForeColor = System.Drawing.Color.Black;
            this.tvServersWithCounters.Location = new System.Drawing.Point(3, 2);
            this.tvServersWithCounters.Name = "tvServersWithCounters";
            // 
            // 
            // 
            this.tvServersWithCounters.RootElement.ForeColor = System.Drawing.Color.Black;
            this.tvServersWithCounters.Size = new System.Drawing.Size(256, 372);
            this.tvServersWithCounters.TabIndex = 0;
            this.tvServersWithCounters.Text = "radTreeView1";
            this.tvServersWithCounters.ThemeName = "Telerik";
            this.tvServersWithCounters.TriStateMode = true;
            // 
            // splitPanel5
            // 
            this.splitPanel5.Controls.Add(this.radLabel4);
            this.splitPanel5.Controls.Add(this.txtReportName);
            this.splitPanel5.Controls.Add(this.btnRun);
            this.splitPanel5.Location = new System.Drawing.Point(264, 0);
            this.splitPanel5.Name = "splitPanel5";
            // 
            // 
            // 
            this.splitPanel5.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel5.Size = new System.Drawing.Size(843, 376);
            this.splitPanel5.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(0.2635869F, 0F);
            this.splitPanel5.SizeInfo.SplitterCorrection = new System.Drawing.Size(291, 0);
            this.splitPanel5.TabIndex = 1;
            this.splitPanel5.TabStop = false;
            this.splitPanel5.Text = "splitPanel5";
            // 
            // radLabel4
            // 
            this.radLabel4.BackColor = System.Drawing.Color.Transparent;
            this.radLabel4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.ForeColor = System.Drawing.Color.Black;
            this.radLabel4.Location = new System.Drawing.Point(7, 22);
            this.radLabel4.Name = "radLabel4";
            // 
            // 
            // 
            this.radLabel4.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel4.Size = new System.Drawing.Size(90, 17);
            this.radLabel4.TabIndex = 21;
            this.radLabel4.Text = "Report Name :";
            // 
            // txtReportName
            // 
            this.txtReportName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReportName.Location = new System.Drawing.Point(106, 21);
            this.txtReportName.Name = "txtReportName";
            this.txtReportName.Size = new System.Drawing.Size(308, 21);
            this.txtReportName.TabIndex = 20;
            this.txtReportName.TabStop = false;
            this.txtReportName.ThemeName = "Office2010";
            // 
            // btnRun
            // 
            this.btnRun.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnRun.Location = new System.Drawing.Point(189, 48);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(85, 24);
            this.btnRun.TabIndex = 3;
            this.btnRun.Text = "&Run";
            this.btnRun.ThemeName = "Telerik";
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // tabItem1
            // 
            this.tabItem1.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tabItem1.ContentPanel
            // 
            this.tabItem1.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(239)))), ((int)(((byte)(249)))));
            this.tabItem1.ContentPanel.CausesValidation = true;
            this.tabItem1.ContentPanel.Controls.Add(this.radSplitContainer4);
            this.tabItem1.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabItem1.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabItem1.ContentPanel.Location = new System.Drawing.Point(1, 36);
            this.tabItem1.ContentPanel.Size = new System.Drawing.Size(1107, 376);
            this.tabItem1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.tabItem1.ForeColor = System.Drawing.Color.Black;
            this.tabItem1.IsSelected = true;
            this.tabItem1.Margin = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.tabItem1.Name = "tabItem1";
            this.tabItem1.ScaleTransform = new System.Drawing.SizeF(1.2F, 1.2F);
            this.tabItem1.StretchHorizontally = false;
            this.tabItem1.Text = "Report";
            // 
            // radSplitContainer4
            // 
            this.radSplitContainer4.Controls.Add(this.splitPanel6);
            this.radSplitContainer4.Controls.Add(this.splitPanel7);
            this.radSplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer4.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer4.Name = "radSplitContainer4";
            // 
            // 
            // 
            this.radSplitContainer4.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer4.Size = new System.Drawing.Size(1107, 376);
            this.radSplitContainer4.TabIndex = 0;
            this.radSplitContainer4.TabStop = false;
            this.radSplitContainer4.Text = "radSplitContainer4";
            // 
            // splitPanel6
            // 
            this.splitPanel6.Controls.Add(this.ddlReportName);
            this.splitPanel6.Controls.Add(this.radLabel1);
            this.splitPanel6.Controls.Add(this.tvChart);
            this.splitPanel6.Location = new System.Drawing.Point(0, 0);
            this.splitPanel6.Name = "splitPanel6";
            // 
            // 
            // 
            this.splitPanel6.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel6.Size = new System.Drawing.Size(285, 376);
            this.splitPanel6.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(-0.2418478F, 0F);
            this.splitPanel6.SizeInfo.SplitterCorrection = new System.Drawing.Size(-267, 0);
            this.splitPanel6.TabIndex = 0;
            this.splitPanel6.TabStop = false;
            this.splitPanel6.Text = "splitPanel6";
            // 
            // ddlReportName
            // 
            this.ddlReportName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ddlReportName.DisplayMember = "reportname";
            this.ddlReportName.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.ddlReportName.Location = new System.Drawing.Point(98, 13);
            this.ddlReportName.Name = "ddlReportName";
            // 
            // 
            // 
            this.ddlReportName.RootElement.AutoSizeMode = Telerik.WinControls.RadAutoSizeMode.WrapAroundChildren;
            this.ddlReportName.Size = new System.Drawing.Size(184, 20);
            this.ddlReportName.TabIndex = 23;
            this.ddlReportName.TabStop = false;
            this.ddlReportName.SelectedIndexChanged += new System.EventHandler(this.ddlReportName_SelectedIndexChanged);
            // 
            // radLabel1
            // 
            this.radLabel1.BackColor = System.Drawing.Color.Transparent;
            this.radLabel1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.ForeColor = System.Drawing.Color.Black;
            this.radLabel1.Location = new System.Drawing.Point(2, 13);
            this.radLabel1.Name = "radLabel1";
            // 
            // 
            // 
            this.radLabel1.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radLabel1.Size = new System.Drawing.Size(90, 17);
            this.radLabel1.TabIndex = 22;
            this.radLabel1.Text = "Report Name :";
            // 
            // tvChart
            // 
            this.tvChart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tvChart.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvChart.ForeColor = System.Drawing.Color.Black;
            this.tvChart.Location = new System.Drawing.Point(3, 37);
            this.tvChart.Name = "tvChart";
            // 
            // 
            // 
            this.tvChart.RootElement.ForeColor = System.Drawing.Color.Black;
            this.tvChart.Size = new System.Drawing.Size(279, 335);
            this.tvChart.TabIndex = 1;
            this.tvChart.Text = "radTreeView1";
            this.tvChart.ThemeName = "Telerik";
            this.tvChart.SelectedNodeChanged += new Telerik.WinControls.UI.RadTreeView.RadTreeViewEventHandler(this.tvChart_SelectedNodeChanged);
            // 
            // splitPanel7
            // 
            this.splitPanel7.Controls.Add(this.radGridView1);
            this.splitPanel7.Location = new System.Drawing.Point(288, 0);
            this.splitPanel7.Name = "splitPanel7";
            // 
            // 
            // 
            this.splitPanel7.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel7.Size = new System.Drawing.Size(819, 376);
            this.splitPanel7.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(0.2418478F, 0F);
            this.splitPanel7.SizeInfo.SplitterCorrection = new System.Drawing.Size(267, 0);
            this.splitPanel7.TabIndex = 1;
            this.splitPanel7.TabStop = false;
            this.splitPanel7.Text = "splitPanel7";
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            // 
            // radGridView1
            // 
            this.radGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radGridView1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radGridView1.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            this.radGridView1.MasterGridViewTemplate.AllowAddNewRow = false;
            this.radGridView1.MasterGridViewTemplate.AllowColumnReorder = false;
            this.radGridView1.Name = "radGridView1";
            this.radGridView1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.radGridView1.ReadOnly = true;
            // 
            // 
            // 
            this.radGridView1.RootElement.Padding = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.radGridView1.Size = new System.Drawing.Size(819, 376);
            this.radGridView1.TabIndex = 38;
            this.radGridView1.ThemeName = "Office2010";
            // 
            // UCMonitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.radSplitContainer1);
            this.Name = "UCMonitor";
            this.Size = new System.Drawing.Size(1109, 413);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).EndInit();
            this.radSplitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).EndInit();
            this.splitPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabsMonitor)).EndInit();
            this.tabsMonitor.ResumeLayout(false);
            this.tabiConfiguration.ContentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer2)).EndInit();
            this.radSplitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).EndInit();
            this.splitPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tvServers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRemove)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).EndInit();
            this.tabiRun.ContentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer3)).EndInit();
            this.radSplitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel4)).EndInit();
            this.splitPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tvServersWithCounters)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel5)).EndInit();
            this.splitPanel5.ResumeLayout(false);
            this.splitPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtReportName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRun)).EndInit();
            this.tabItem1.ContentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer4)).EndInit();
            this.radSplitContainer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel6)).EndInit();
            this.splitPanel6.ResumeLayout(false);
            this.splitPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ddlReportName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tvChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel7)).EndInit();
            this.splitPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterGridViewTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer1;
        private Telerik.WinControls.UI.SplitPanel splitPanel1;
        private System.Windows.Forms.Timer timer1;
        private Telerik.WinControls.UI.RadTabStrip tabsMonitor;
        private Telerik.WinControls.UI.TabItem tabiConfiguration;
        private Telerik.WinControls.UI.TabItem tabiRun;
        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer2;
        private Telerik.WinControls.UI.SplitPanel splitPanel2;
        private Telerik.WinControls.UI.RadTreeView tvServers;
        private Telerik.WinControls.UI.SplitPanel splitPanel3;
        private Telerik.WinControls.UI.RadButton btnRemove;
        private Telerik.WinControls.UI.RadButton btnAdd;
        private Telerik.WinControls.UI.RadButton btnSave;
        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer3;
        private Telerik.WinControls.UI.SplitPanel splitPanel4;
        private Telerik.WinControls.UI.RadTreeView tvServersWithCounters;
        private Telerik.WinControls.UI.SplitPanel splitPanel5;
        private Telerik.WinControls.UI.RadButton btnRun;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadTextBox txtReportName;
        private Telerik.WinControls.UI.TabItem tabItem1;
        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer4;
        private Telerik.WinControls.UI.SplitPanel splitPanel6;
        private Telerik.WinControls.UI.RadTreeView tvChart;
        private Telerik.WinControls.UI.SplitPanel splitPanel7;
        private Telerik.WinControls.UI.RadComboBox ddlReportName;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadGridView radGridView1;
    }
}
