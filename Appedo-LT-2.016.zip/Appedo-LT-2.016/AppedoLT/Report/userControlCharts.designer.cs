﻿namespace AppedoLT
{
    partial class userControlCharts
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Charting.ChartSeries chartSeries1 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.ChartSeries chartSeries2 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.ChartSeries chartSeries3 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.ChartSeries chartSeries4 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.ChartSeries chartSeries5 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.ChartSeries chartSeries6 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.Styles.Corners corners1 = new Telerik.Charting.Styles.Corners();
            Telerik.Charting.GradientElement gradientElement1 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement2 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement3 = new Telerik.Charting.GradientElement();
            Telerik.Charting.Styles.ChartMargins chartMargins1 = new Telerik.Charting.Styles.ChartMargins();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userControlCharts));
            Telerik.Charting.Styles.ChartMargins chartMargins2 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartMargins chartMargins3 = new Telerik.Charting.Styles.ChartMargins();
            Telerik.Charting.Styles.ChartPaddings chartPaddings1 = new Telerik.Charting.Styles.ChartPaddings();
            Telerik.Charting.ChartAxisItem chartAxisItem1 = new Telerik.Charting.ChartAxisItem();
            Telerik.Charting.ChartAxisItem chartAxisItem2 = new Telerik.Charting.ChartAxisItem();
            Telerik.Charting.ChartAxisItem chartAxisItem3 = new Telerik.Charting.ChartAxisItem();
            Telerik.Charting.ChartAxisItem chartAxisItem4 = new Telerik.Charting.ChartAxisItem();
            Telerik.Charting.ChartAxisItem chartAxisItem5 = new Telerik.Charting.ChartAxisItem();
            Telerik.Charting.ChartAxisItem chartAxisItem6 = new Telerik.Charting.ChartAxisItem();
            Telerik.Charting.ChartAxisItem chartAxisItem7 = new Telerik.Charting.ChartAxisItem();
            Telerik.Charting.ChartSeries chartSeries7 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement4 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement5 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement6 = new Telerik.Charting.GradientElement();
            Telerik.Charting.ChartSeries chartSeries8 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement7 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement8 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement9 = new Telerik.Charting.GradientElement();
            Telerik.Charting.ChartSeries chartSeries9 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement10 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement11 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement12 = new Telerik.Charting.GradientElement();
            Telerik.Charting.ChartSeries chartSeries10 = new Telerik.Charting.ChartSeries();
            Telerik.Charting.GradientElement gradientElement13 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement14 = new Telerik.Charting.GradientElement();
            Telerik.Charting.GradientElement gradientElement15 = new Telerik.Charting.GradientElement();
            this.btnShowReportReport = new Telerik.WinControls.UI.RadButton();
            this.ddlReportNameReport = new Telerik.WinControls.UI.RadComboBox();
            this.splitPanel1 = new Telerik.WinControls.UI.SplitPanel();
            this.radChart1 = new Telerik.WinControls.UI.RadChart();
            this.splitPanel2 = new Telerik.WinControls.UI.SplitPanel();
            this.radChart7 = new Telerik.WinControls.UI.RadChart();
            this.radChart3 = new Telerik.WinControls.UI.RadChart();
            this.ddlChartName = new Telerik.WinControls.UI.RadComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radSplitContainer1 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel3 = new Telerik.WinControls.UI.SplitPanel();
            this.pnlChart = new Telerik.WinControls.UI.RadPanel();
            this.chtName = new Telerik.WinControls.UI.RadChart();
            this.btnExport = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.btnShowReportReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlReportNameReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).BeginInit();
            this.splitPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radChart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).BeginInit();
            this.splitPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radChart7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radChart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlChartName)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).BeginInit();
            this.radSplitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).BeginInit();
            this.splitPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlChart)).BeginInit();
            this.pnlChart.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExport)).BeginInit();
            this.SuspendLayout();
            // 
            // btnShowReportReport
            // 
            this.btnShowReportReport.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowReportReport.Location = new System.Drawing.Point(457, 5);
            this.btnShowReportReport.Name = "btnShowReportReport";
            this.btnShowReportReport.Size = new System.Drawing.Size(84, 21);
            this.btnShowReportReport.TabIndex = 36;
            this.btnShowReportReport.Text = "&View Graph";
            this.btnShowReportReport.ThemeName = "Telerik";
            this.btnShowReportReport.Click += new System.EventHandler(this.btnShowReportReport_Click);
            // 
            // ddlReportNameReport
            // 
            this.ddlReportNameReport.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.ddlReportNameReport.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddlReportNameReport.Location = new System.Drawing.Point(10, 5);
            this.ddlReportNameReport.Name = "ddlReportNameReport";
            // 
            // 
            // 
            this.ddlReportNameReport.RootElement.AutoSizeMode = Telerik.WinControls.RadAutoSizeMode.WrapAroundChildren;
            this.ddlReportNameReport.Size = new System.Drawing.Size(215, 21);
            this.ddlReportNameReport.TabIndex = 35;
            this.ddlReportNameReport.TabStop = false;
            this.ddlReportNameReport.ThemeName = "Telerik";
            // 
            // splitPanel1
            // 
            this.splitPanel1.Controls.Add(this.radChart1);
            this.splitPanel1.Location = new System.Drawing.Point(0, 0);
            this.splitPanel1.Name = "splitPanel1";
            // 
            // 
            // 
            this.splitPanel1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel1.Size = new System.Drawing.Size(452, 300);
            this.splitPanel1.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(-0.003325939F, 0F);
            this.splitPanel1.SizeInfo.SplitterCorrection = new System.Drawing.Size(-3, 0);
            this.splitPanel1.TabIndex = 0;
            this.splitPanel1.TabStop = false;
            this.splitPanel1.Text = "splitPanel1";
            // 
            // radChart1
            // 
            this.radChart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radChart1.Location = new System.Drawing.Point(0, 0);
            this.radChart1.Name = "radChart1";
            this.radChart1.PlotArea.XAxis.MinValue = 1;
            this.radChart1.PlotArea.YAxis.MaxValue = 100;
            this.radChart1.PlotArea.YAxis.Step = 10;
            chartSeries1.Name = "Series 1";
            chartSeries2.Name = "Series 2";
            this.radChart1.Series.AddRange(new Telerik.Charting.ChartSeries[] {
            chartSeries1,
            chartSeries2});
            this.radChart1.Size = new System.Drawing.Size(452, 300);
            this.radChart1.TabIndex = 38;
            // 
            // splitPanel2
            // 
            this.splitPanel2.Controls.Add(this.radChart7);
            this.splitPanel2.Location = new System.Drawing.Point(455, 0);
            this.splitPanel2.Name = "splitPanel2";
            // 
            // 
            // 
            this.splitPanel2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel2.Size = new System.Drawing.Size(459, 300);
            this.splitPanel2.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(0.003325939F, 0F);
            this.splitPanel2.SizeInfo.SplitterCorrection = new System.Drawing.Size(3, 0);
            this.splitPanel2.TabIndex = 1;
            this.splitPanel2.TabStop = false;
            this.splitPanel2.Text = "splitPanel2";
            // 
            // radChart7
            // 
            this.radChart7.Location = new System.Drawing.Point(2, 1);
            this.radChart7.Name = "radChart7";
            this.radChart7.PlotArea.XAxis.MinValue = 1;
            this.radChart7.PlotArea.YAxis.MaxValue = 100;
            this.radChart7.PlotArea.YAxis.Step = 10;
            chartSeries3.Name = "Series 1";
            chartSeries4.Name = "Series 2";
            this.radChart7.Series.AddRange(new Telerik.Charting.ChartSeries[] {
            chartSeries3,
            chartSeries4});
            this.radChart7.Size = new System.Drawing.Size(448, 298);
            this.radChart7.TabIndex = 39;
            // 
            // radChart3
            // 
            this.radChart3.Location = new System.Drawing.Point(5, -19);
            this.radChart3.Name = "radChart3";
            this.radChart3.PlotArea.XAxis.MinValue = 1;
            this.radChart3.PlotArea.YAxis.MaxValue = 100;
            this.radChart3.PlotArea.YAxis.Step = 10;
            chartSeries5.Name = "Series 1";
            chartSeries6.Name = "Series 2";
            this.radChart3.Series.AddRange(new Telerik.Charting.ChartSeries[] {
            chartSeries5,
            chartSeries6});
            this.radChart3.Size = new System.Drawing.Size(400, 300);
            this.radChart3.TabIndex = 44;
            // 
            // ddlChartName
            // 
            this.ddlChartName.DropDownHeight = 300;
            this.ddlChartName.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            this.ddlChartName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddlChartName.Location = new System.Drawing.Point(236, 5);
            this.ddlChartName.Name = "ddlChartName";
            // 
            // 
            // 
            this.ddlChartName.RootElement.AutoSizeMode = Telerik.WinControls.RadAutoSizeMode.WrapAroundChildren;
            this.ddlChartName.Size = new System.Drawing.Size(215, 21);
            this.ddlChartName.TabIndex = 49;
            this.ddlChartName.TabStop = false;
            this.ddlChartName.ThemeName = "Telerik";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.radSplitContainer1);
            this.panel1.Location = new System.Drawing.Point(2, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(755, 592);
            this.panel1.TabIndex = 50;
            // 
            // radSplitContainer1
            // 
            this.radSplitContainer1.Controls.Add(this.splitPanel3);
            this.radSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer1.Name = "radSplitContainer1";
            // 
            // 
            // 
            this.radSplitContainer1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer1.Size = new System.Drawing.Size(755, 592);
            this.radSplitContainer1.TabIndex = 0;
            this.radSplitContainer1.TabStop = false;
            this.radSplitContainer1.Text = "radSplitContainer1";
            // 
            // splitPanel3
            // 
            this.splitPanel3.Controls.Add(this.pnlChart);
            this.splitPanel3.Location = new System.Drawing.Point(0, 0);
            this.splitPanel3.Name = "splitPanel3";
            // 
            // 
            // 
            this.splitPanel3.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel3.Size = new System.Drawing.Size(755, 592);
            this.splitPanel3.TabIndex = 0;
            this.splitPanel3.TabStop = false;
            this.splitPanel3.Text = "splitPanel3";
            // 
            // pnlChart
            // 
            this.pnlChart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlChart.Controls.Add(this.chtName);
            this.pnlChart.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlChart.Location = new System.Drawing.Point(0, 2);
            this.pnlChart.Name = "pnlChart";
            this.pnlChart.Size = new System.Drawing.Size(498, 568);
            this.pnlChart.TabIndex = 8;
            // 
            // chtName
            // 
            this.chtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.chtName.Appearance.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(221)))), ((int)(((byte)(222)))));
            corners1.BottomLeft = Telerik.Charting.Styles.CornerType.Round;
            corners1.BottomRight = Telerik.Charting.Styles.CornerType.Round;
            corners1.RoundSize = 7;
            corners1.TopLeft = Telerik.Charting.Styles.CornerType.Round;
            corners1.TopRight = Telerik.Charting.Styles.CornerType.Round;
            this.chtName.Appearance.Corners = corners1;
            gradientElement1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(253)))), ((int)(((byte)(255)))));
            gradientElement2.Color = System.Drawing.Color.White;
            gradientElement2.Position = 0.5F;
            gradientElement3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(253)))), ((int)(((byte)(255)))));
            gradientElement3.Position = 1F;
            this.chtName.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement1,
            gradientElement2,
            gradientElement3});
            this.chtName.Appearance.FillStyle.FillType = Telerik.Charting.Styles.FillType.ComplexGradient;
            chartMargins1.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins1.Left")));
            chartMargins1.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins1.Top")));
            this.chtName.ChartTitle.Appearance.Dimensions.Margins = chartMargins1;
            this.chtName.ChartTitle.Appearance.FillStyle.MainColor = System.Drawing.Color.Empty;
            this.chtName.ChartTitle.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(88)))), ((int)(((byte)(89)))));
            this.chtName.ChartTitle.TextBlock.Appearance.TextProperties.Font = new System.Drawing.Font("Verdana", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.chtName.ChartTitle.TextBlock.Text = "";
            this.chtName.DefaultType = Telerik.Charting.ChartSeriesType.Line;
            this.chtName.Legend.Appearance.Border.Color = System.Drawing.Color.Empty;
            chartMargins2.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins2.Bottom")));
            chartMargins2.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins2.Right")));
            this.chtName.Legend.Appearance.Dimensions.Margins = chartMargins2;
            this.chtName.Legend.Appearance.FillStyle.MainColor = System.Drawing.Color.Empty;
            this.chtName.Legend.Appearance.ItemMarkerAppearance.Figure = "Rectangle";
            this.chtName.Legend.Appearance.ItemTextAppearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(88)))), ((int)(((byte)(89)))));
            this.chtName.Legend.Appearance.Visible = false;
            this.chtName.Legend.TextBlock.Appearance.Position.AlignedPosition = Telerik.Charting.Styles.AlignedPositions.Top;
            this.chtName.Legend.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(88)))), ((int)(((byte)(89)))));
            this.chtName.Legend.Visible = false;
            this.chtName.Location = new System.Drawing.Point(59, 39);
            this.chtName.Name = "chtName";
            this.chtName.PlotArea.Appearance.Border.Color = System.Drawing.Color.WhiteSmoke;
            chartMargins3.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins3.Bottom")));
            chartMargins3.Left = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins3.Left")));
            chartMargins3.Right = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins3.Right")));
            chartMargins3.Top = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartMargins3.Top")));
            this.chtName.PlotArea.Appearance.Dimensions.Margins = chartMargins3;
            this.chtName.PlotArea.Appearance.FillStyle.MainColor = System.Drawing.Color.Transparent;
            this.chtName.PlotArea.Appearance.FillStyle.SecondColor = System.Drawing.Color.Transparent;
            this.chtName.PlotArea.XAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(134)))), ((int)(((byte)(134)))));
            this.chtName.PlotArea.XAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.chtName.PlotArea.XAxis.Appearance.MajorGridLines.Width = 0F;
            this.chtName.PlotArea.XAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(134)))), ((int)(((byte)(134)))));
            this.chtName.PlotArea.XAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            this.chtName.PlotArea.XAxis.Appearance.Visible = Telerik.Charting.Styles.ChartAxisVisibility.True;
            chartPaddings1.Bottom = ((Telerik.Charting.Styles.Unit)(resources.GetObject("chartPaddings1.Bottom")));
            this.chtName.PlotArea.XAxis.AxisLabel.Appearance.Dimensions.Paddings = chartPaddings1;
            this.chtName.PlotArea.XAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.chtName.PlotArea.XAxis.LayoutMode = Telerik.Charting.Styles.ChartAxisLayoutMode.Inside;
            this.chtName.PlotArea.XAxis.MinValue = 1;
            this.chtName.PlotArea.XAxis.Visible = Telerik.Charting.Styles.ChartAxisVisibility.True;
            this.chtName.PlotArea.YAxis.Appearance.Color = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(134)))), ((int)(((byte)(134)))));
            this.chtName.PlotArea.YAxis.Appearance.MajorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.chtName.PlotArea.YAxis.Appearance.MajorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.chtName.PlotArea.YAxis.Appearance.MinorGridLines.Color = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.chtName.PlotArea.YAxis.Appearance.MinorGridLines.Width = 0F;
            this.chtName.PlotArea.YAxis.Appearance.MinorTick.Color = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.chtName.PlotArea.YAxis.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            this.chtName.PlotArea.YAxis.AutoScale = false;
            this.chtName.PlotArea.YAxis.AxisLabel.TextBlock.Appearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(158)))), ((int)(((byte)(119)))));
            this.chtName.PlotArea.YAxis.AxisMode = Telerik.Charting.ChartYAxisMode.Extended;
            chartAxisItem2.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            chartAxisItem3.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            chartAxisItem4.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            chartAxisItem5.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            chartAxisItem6.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            chartAxisItem7.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.chtName.PlotArea.YAxis.Items.AddRange(new Telerik.Charting.ChartAxisItem[] {
            chartAxisItem1,
            chartAxisItem2,
            chartAxisItem3,
            chartAxisItem4,
            chartAxisItem5,
            chartAxisItem6,
            chartAxisItem7});
            this.chtName.PlotArea.YAxis.MaxValue = 120;
            this.chtName.PlotArea.YAxis.Step = 20;
            this.chtName.PlotArea.YAxis2.Appearance.Visible = Telerik.Charting.Styles.ChartAxisVisibility.True;
            this.chtName.PlotArea.YAxis2.AxisLabel.TextBlock.Text = "Sample";
            this.chtName.PlotArea.YAxis2.AxisMode = Telerik.Charting.ChartYAxisMode.Extended;
            this.chtName.PlotArea.YAxis2.LogarithmBase = 2;
            this.chtName.PlotArea.YAxis2.Visible = Telerik.Charting.Styles.ChartAxisVisibility.True;
            chartSeries7.Appearance.Border.Color = System.Drawing.Color.Empty;
            gradientElement4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            gradientElement5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(239)))), ((int)(((byte)(252)))));
            gradientElement5.Position = 0.5F;
            gradientElement6.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(217)))), ((int)(((byte)(238)))));
            gradientElement6.Position = 1F;
            chartSeries7.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement4,
            gradientElement5,
            gradientElement6});
            chartSeries7.Appearance.FillStyle.FillSettings.GradientMode = Telerik.Charting.Styles.GradientFillStyle.Vertical;
            chartSeries7.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(207)))), ((int)(((byte)(141)))));
            chartSeries7.Appearance.FillStyle.SecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(176)))), ((int)(((byte)(83)))));
            chartSeries7.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            chartSeries7.Name = "Series 1";
            chartSeries7.Type = Telerik.Charting.ChartSeriesType.Line;
            chartSeries8.Appearance.Border.Color = System.Drawing.Color.Empty;
            gradientElement7.Color = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(254)))), ((int)(((byte)(122)))));
            gradientElement8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(244)))), ((int)(((byte)(80)))));
            gradientElement8.Position = 0.5F;
            gradientElement9.Color = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(205)))), ((int)(((byte)(46)))));
            gradientElement9.Position = 1F;
            chartSeries8.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement7,
            gradientElement8,
            gradientElement9});
            chartSeries8.Appearance.FillStyle.FillSettings.GradientMode = Telerik.Charting.Styles.GradientFillStyle.Vertical;
            chartSeries8.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(140)))), ((int)(((byte)(104)))));
            chartSeries8.Appearance.FillStyle.SecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(110)))), ((int)(((byte)(90)))));
            chartSeries8.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            chartSeries8.Name = "Series 2";
            chartSeries8.Type = Telerik.Charting.ChartSeriesType.Line;
            chartSeries9.Appearance.Border.Color = System.Drawing.Color.Empty;
            gradientElement10.Color = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(221)))), ((int)(((byte)(246)))));
            gradientElement11.Color = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(203)))), ((int)(((byte)(234)))));
            gradientElement11.Position = 0.5F;
            gradientElement12.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(161)))), ((int)(((byte)(197)))));
            gradientElement12.Position = 1F;
            chartSeries9.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement10,
            gradientElement11,
            gradientElement12});
            chartSeries9.Appearance.FillStyle.FillSettings.GradientMode = Telerik.Charting.Styles.GradientFillStyle.Vertical;
            chartSeries9.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(192)))), ((int)(((byte)(225)))));
            chartSeries9.Appearance.FillStyle.SecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(129)))), ((int)(((byte)(189)))));
            chartSeries9.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            chartSeries9.Name = "Series 1";
            chartSeries9.Type = Telerik.Charting.ChartSeriesType.Line;
            chartSeries10.Appearance.Border.Color = System.Drawing.Color.Empty;
            gradientElement13.Color = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(222)))), ((int)(((byte)(78)))));
            gradientElement14.Color = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(207)))), ((int)(((byte)(27)))));
            gradientElement14.Position = 0.5F;
            gradientElement15.Color = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(181)))), ((int)(((byte)(3)))));
            gradientElement15.Position = 1F;
            chartSeries10.Appearance.FillStyle.FillSettings.ComplexGradient.AddRange(new Telerik.Charting.GradientElement[] {
            gradientElement13,
            gradientElement14,
            gradientElement15});
            chartSeries10.Appearance.FillStyle.FillSettings.GradientMode = Telerik.Charting.Styles.GradientFillStyle.Vertical;
            chartSeries10.Appearance.FillStyle.MainColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(182)))), ((int)(((byte)(80)))));
            chartSeries10.Appearance.FillStyle.SecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(162)))), ((int)(((byte)(83)))));
            chartSeries10.Appearance.TextAppearance.TextProperties.Color = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            chartSeries10.Name = "Series 2";
            chartSeries10.Type = Telerik.Charting.ChartSeriesType.Line;
            this.chtName.Series.AddRange(new Telerik.Charting.ChartSeries[] {
            chartSeries7,
            chartSeries8,
            chartSeries9,
            chartSeries10});
            this.chtName.Size = new System.Drawing.Size(385, 468);
            this.chtName.Skin = "Vista";
            this.chtName.TabIndex = 8;
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Location = new System.Drawing.Point(544, 5);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(84, 21);
            this.btnExport.TabIndex = 51;
            this.btnExport.Text = "&Export";
            this.btnExport.ThemeName = "Telerik";
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // userControlCharts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ddlChartName);
            this.Controls.Add(this.btnShowReportReport);
            this.Controls.Add(this.ddlReportNameReport);
            this.Name = "userControlCharts";
            this.Size = new System.Drawing.Size(757, 600);
            ((System.ComponentModel.ISupportInitialize)(this.btnShowReportReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlReportNameReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).EndInit();
            this.splitPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radChart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).EndInit();
            this.splitPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radChart7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radChart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlChartName)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).EndInit();
            this.radSplitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel3)).EndInit();
            this.splitPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pnlChart)).EndInit();
            this.pnlChart.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chtName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadButton btnShowReportReport;
        private Telerik.WinControls.UI.RadComboBox ddlReportNameReport;
        private Telerik.WinControls.UI.SplitPanel splitPanel1;
        private Telerik.WinControls.UI.SplitPanel splitPanel2;
        private Telerik.WinControls.UI.RadChart radChart1;
        private Telerik.WinControls.UI.RadChart radChart7;
        private Telerik.WinControls.UI.RadChart radChart3;
        private Telerik.WinControls.UI.RadComboBox ddlChartName;
        private System.Windows.Forms.Panel panel1;
        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer1;
        private Telerik.WinControls.UI.SplitPanel splitPanel3;
        private Telerik.WinControls.UI.RadButton btnExport;
        private Telerik.WinControls.UI.RadChart chtName;
        private Telerik.WinControls.UI.RadPanel pnlChart;
    }
}
