﻿namespace AppedoLT
{
    partial class userControlReports
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.radLabel32 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel35 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel38 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel39 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel40 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel41 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel42 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel43 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel44 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel45 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel46 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel47 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel48 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel49 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel50 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel51 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel52 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel53 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel54 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel55 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel56 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel57 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel58 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel59 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel60 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel61 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel62 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel63 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel64 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel65 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel66 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel67 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel68 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel69 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel70 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel71 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel72 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel73 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel74 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel75 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel76 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel77 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel78 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel79 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel80 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel81 = new Telerik.WinControls.UI.RadLabel();
            this.brwReportView = new System.Windows.Forms.WebBrowser();
            this.cntmSave = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabsReport = new Telerik.WinControls.UI.RadTabStrip();
            this.tabiHeader = new Telerik.WinControls.UI.TabItem();
            this.tabiParameters = new Telerik.WinControls.UI.TabItem();
            this.brwErrors = new System.Windows.Forms.WebBrowser();
            this.tabiVariables = new Telerik.WinControls.UI.TabItem();
            this.brwLogs = new System.Windows.Forms.WebBrowser();
            this.radSplitContainer1 = new Telerik.WinControls.UI.RadSplitContainer();
            this.splitPanel1 = new Telerik.WinControls.UI.SplitPanel();
            this.radPanel2 = new Telerik.WinControls.UI.RadPanel();
            this.radGridReport = new Telerik.WinControls.UI.RadGridView();
            this.gridViewTemplate1 = new Telerik.WinControls.UI.GridViewTemplate();
            this.splitPanel2 = new Telerik.WinControls.UI.SplitPanel();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel43)).BeginInit();
            this.radLabel43.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel48)).BeginInit();
            this.radLabel48.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel81)).BeginInit();
            this.cntmSave.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabsReport)).BeginInit();
            this.tabsReport.SuspendLayout();
            this.tabiHeader.ContentPanel.SuspendLayout();
            this.tabiParameters.ContentPanel.SuspendLayout();
            this.tabiVariables.ContentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).BeginInit();
            this.radSplitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).BeginInit();
            this.splitPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).BeginInit();
            this.radPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGridReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridReport.MasterGridViewTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTemplate1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).BeginInit();
            this.splitPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // radLabel32
            // 
            this.radLabel32.Location = new System.Drawing.Point(207, 223);
            this.radLabel32.Name = "radLabel32";
            this.radLabel32.Size = new System.Drawing.Size(2, 2);
            this.radLabel32.TabIndex = 24;
            // 
            // radLabel35
            // 
            this.radLabel35.Location = new System.Drawing.Point(207, 223);
            this.radLabel35.Name = "radLabel35";
            this.radLabel35.Size = new System.Drawing.Size(2, 2);
            this.radLabel35.TabIndex = 24;
            // 
            // radLabel38
            // 
            this.radLabel38.Location = new System.Drawing.Point(53, 223);
            this.radLabel38.Name = "radLabel38";
            this.radLabel38.Size = new System.Drawing.Size(87, 16);
            this.radLabel38.TabIndex = 22;
            this.radLabel38.Text = "Avg Throughput";
            // 
            // radLabel39
            // 
            this.radLabel39.Location = new System.Drawing.Point(165, 223);
            this.radLabel39.Name = "radLabel39";
            this.radLabel39.Size = new System.Drawing.Size(9, 16);
            this.radLabel39.TabIndex = 23;
            this.radLabel39.Text = ":";
            // 
            // radLabel40
            // 
            this.radLabel40.Location = new System.Drawing.Point(207, 293);
            this.radLabel40.Name = "radLabel40";
            this.radLabel40.Size = new System.Drawing.Size(2, 2);
            this.radLabel40.TabIndex = 32;
            // 
            // radLabel41
            // 
            this.radLabel41.Location = new System.Drawing.Point(165, 293);
            this.radLabel41.Name = "radLabel41";
            this.radLabel41.Size = new System.Drawing.Size(9, 16);
            this.radLabel41.TabIndex = 30;
            this.radLabel41.Text = ":";
            // 
            // radLabel42
            // 
            this.radLabel42.Location = new System.Drawing.Point(53, 293);
            this.radLabel42.Name = "radLabel42";
            this.radLabel42.Size = new System.Drawing.Size(83, 16);
            this.radLabel42.TabIndex = 28;
            this.radLabel42.Text = "Avg Pages/Sec";
            // 
            // radLabel43
            // 
            this.radLabel43.Controls.Add(this.radLabel44);
            this.radLabel43.Controls.Add(this.radLabel45);
            this.radLabel43.Controls.Add(this.radLabel46);
            this.radLabel43.Controls.Add(this.radLabel47);
            this.radLabel43.Location = new System.Drawing.Point(207, 271);
            this.radLabel43.Name = "radLabel43";
            this.radLabel43.Size = new System.Drawing.Size(2, 2);
            this.radLabel43.TabIndex = 27;
            // 
            // radLabel44
            // 
            this.radLabel44.Location = new System.Drawing.Point(0, 0);
            this.radLabel44.Name = "radLabel44";
            this.radLabel44.Size = new System.Drawing.Size(2, 2);
            this.radLabel44.TabIndex = 27;
            // 
            // radLabel45
            // 
            this.radLabel45.Location = new System.Drawing.Point(-154, -48);
            this.radLabel45.Name = "radLabel45";
            this.radLabel45.Size = new System.Drawing.Size(87, 16);
            this.radLabel45.TabIndex = 22;
            this.radLabel45.Text = "Avg Throughput";
            // 
            // radLabel46
            // 
            this.radLabel46.Location = new System.Drawing.Point(0, -48);
            this.radLabel46.Name = "radLabel46";
            this.radLabel46.Size = new System.Drawing.Size(2, 2);
            this.radLabel46.TabIndex = 24;
            // 
            // radLabel47
            // 
            this.radLabel47.Location = new System.Drawing.Point(-42, -48);
            this.radLabel47.Name = "radLabel47";
            this.radLabel47.Size = new System.Drawing.Size(9, 16);
            this.radLabel47.TabIndex = 23;
            this.radLabel47.Text = ":";
            // 
            // radLabel48
            // 
            this.radLabel48.Controls.Add(this.radLabel49);
            this.radLabel48.Controls.Add(this.radLabel50);
            this.radLabel48.Controls.Add(this.radLabel51);
            this.radLabel48.Controls.Add(this.radLabel52);
            this.radLabel48.Location = new System.Drawing.Point(207, 271);
            this.radLabel48.Name = "radLabel48";
            this.radLabel48.Size = new System.Drawing.Size(2, 2);
            this.radLabel48.TabIndex = 27;
            // 
            // radLabel49
            // 
            this.radLabel49.Location = new System.Drawing.Point(0, 0);
            this.radLabel49.Name = "radLabel49";
            this.radLabel49.Size = new System.Drawing.Size(2, 2);
            this.radLabel49.TabIndex = 27;
            // 
            // radLabel50
            // 
            this.radLabel50.Location = new System.Drawing.Point(-154, -48);
            this.radLabel50.Name = "radLabel50";
            this.radLabel50.Size = new System.Drawing.Size(87, 16);
            this.radLabel50.TabIndex = 22;
            this.radLabel50.Text = "Avg Throughput";
            // 
            // radLabel51
            // 
            this.radLabel51.Location = new System.Drawing.Point(-42, -48);
            this.radLabel51.Name = "radLabel51";
            this.radLabel51.Size = new System.Drawing.Size(9, 16);
            this.radLabel51.TabIndex = 23;
            this.radLabel51.Text = ":";
            // 
            // radLabel52
            // 
            this.radLabel52.Location = new System.Drawing.Point(0, -48);
            this.radLabel52.Name = "radLabel52";
            this.radLabel52.Size = new System.Drawing.Size(2, 2);
            this.radLabel52.TabIndex = 24;
            // 
            // radLabel53
            // 
            this.radLabel53.Location = new System.Drawing.Point(165, 271);
            this.radLabel53.Name = "radLabel53";
            this.radLabel53.Size = new System.Drawing.Size(9, 16);
            this.radLabel53.TabIndex = 26;
            this.radLabel53.Text = ":";
            // 
            // radLabel54
            // 
            this.radLabel54.Location = new System.Drawing.Point(53, 271);
            this.radLabel54.Name = "radLabel54";
            this.radLabel54.Size = new System.Drawing.Size(67, 16);
            this.radLabel54.TabIndex = 25;
            this.radLabel54.Text = "Total Pages";
            // 
            // radLabel55
            // 
            this.radLabel55.Location = new System.Drawing.Point(165, 223);
            this.radLabel55.Name = "radLabel55";
            this.radLabel55.Size = new System.Drawing.Size(9, 16);
            this.radLabel55.TabIndex = 23;
            this.radLabel55.Text = ":";
            // 
            // radLabel56
            // 
            this.radLabel56.Location = new System.Drawing.Point(53, 223);
            this.radLabel56.Name = "radLabel56";
            this.radLabel56.Size = new System.Drawing.Size(87, 16);
            this.radLabel56.TabIndex = 22;
            this.radLabel56.Text = "Avg Throughput";
            // 
            // radLabel57
            // 
            this.radLabel57.Location = new System.Drawing.Point(207, 179);
            this.radLabel57.Name = "radLabel57";
            this.radLabel57.Size = new System.Drawing.Size(2, 2);
            this.radLabel57.TabIndex = 20;
            // 
            // radLabel58
            // 
            this.radLabel58.Location = new System.Drawing.Point(207, 201);
            this.radLabel58.Name = "radLabel58";
            this.radLabel58.Size = new System.Drawing.Size(2, 2);
            this.radLabel58.TabIndex = 21;
            // 
            // radLabel59
            // 
            this.radLabel59.Location = new System.Drawing.Point(165, 179);
            this.radLabel59.Name = "radLabel59";
            this.radLabel59.Size = new System.Drawing.Size(9, 16);
            this.radLabel59.TabIndex = 18;
            this.radLabel59.Text = ":";
            // 
            // radLabel60
            // 
            this.radLabel60.Location = new System.Drawing.Point(165, 201);
            this.radLabel60.Name = "radLabel60";
            this.radLabel60.Size = new System.Drawing.Size(9, 16);
            this.radLabel60.TabIndex = 19;
            this.radLabel60.Text = ":";
            // 
            // radLabel61
            // 
            this.radLabel61.Location = new System.Drawing.Point(53, 179);
            this.radLabel61.Name = "radLabel61";
            this.radLabel61.Size = new System.Drawing.Size(69, 16);
            this.radLabel61.TabIndex = 16;
            this.radLabel61.Text = "Avg Hits/sec";
            // 
            // radLabel62
            // 
            this.radLabel62.Location = new System.Drawing.Point(53, 201);
            this.radLabel62.Name = "radLabel62";
            this.radLabel62.Size = new System.Drawing.Size(92, 16);
            this.radLabel62.TabIndex = 17;
            this.radLabel62.Text = "Total Throughput";
            // 
            // radLabel63
            // 
            this.radLabel63.Location = new System.Drawing.Point(207, 157);
            this.radLabel63.Name = "radLabel63";
            this.radLabel63.Size = new System.Drawing.Size(2, 2);
            this.radLabel63.TabIndex = 15;
            // 
            // radLabel64
            // 
            this.radLabel64.Location = new System.Drawing.Point(165, 157);
            this.radLabel64.Name = "radLabel64";
            this.radLabel64.Size = new System.Drawing.Size(9, 16);
            this.radLabel64.TabIndex = 14;
            this.radLabel64.Text = ":";
            // 
            // radLabel65
            // 
            this.radLabel65.Location = new System.Drawing.Point(53, 157);
            this.radLabel65.Name = "radLabel65";
            this.radLabel65.Size = new System.Drawing.Size(54, 16);
            this.radLabel65.TabIndex = 13;
            this.radLabel65.Text = "Total Hits";
            // 
            // radLabel66
            // 
            this.radLabel66.Location = new System.Drawing.Point(207, 135);
            this.radLabel66.Name = "radLabel66";
            this.radLabel66.Size = new System.Drawing.Size(2, 2);
            this.radLabel66.TabIndex = 12;
            // 
            // radLabel67
            // 
            this.radLabel67.Location = new System.Drawing.Point(165, 135);
            this.radLabel67.Name = "radLabel67";
            this.radLabel67.Size = new System.Drawing.Size(9, 16);
            this.radLabel67.TabIndex = 11;
            this.radLabel67.Text = ":";
            // 
            // radLabel68
            // 
            this.radLabel68.Location = new System.Drawing.Point(53, 135);
            this.radLabel68.Name = "radLabel68";
            this.radLabel68.Size = new System.Drawing.Size(72, 16);
            this.radLabel68.TabIndex = 10;
            this.radLabel68.Text = "Starting User";
            // 
            // radLabel69
            // 
            this.radLabel69.Location = new System.Drawing.Point(207, 91);
            this.radLabel69.Name = "radLabel69";
            this.radLabel69.Size = new System.Drawing.Size(2, 2);
            this.radLabel69.TabIndex = 9;
            // 
            // radLabel70
            // 
            this.radLabel70.Location = new System.Drawing.Point(207, 113);
            this.radLabel70.Name = "radLabel70";
            this.radLabel70.Size = new System.Drawing.Size(2, 2);
            this.radLabel70.TabIndex = 9;
            // 
            // radLabel71
            // 
            this.radLabel71.Location = new System.Drawing.Point(165, 91);
            this.radLabel71.Name = "radLabel71";
            this.radLabel71.Size = new System.Drawing.Size(9, 16);
            this.radLabel71.TabIndex = 8;
            this.radLabel71.Text = ":";
            // 
            // radLabel72
            // 
            this.radLabel72.Location = new System.Drawing.Point(165, 113);
            this.radLabel72.Name = "radLabel72";
            this.radLabel72.Size = new System.Drawing.Size(9, 16);
            this.radLabel72.TabIndex = 8;
            this.radLabel72.Text = ":";
            // 
            // radLabel73
            // 
            this.radLabel73.Location = new System.Drawing.Point(53, 91);
            this.radLabel73.Name = "radLabel73";
            this.radLabel73.Size = new System.Drawing.Size(74, 16);
            this.radLabel73.TabIndex = 7;
            this.radLabel73.Text = "Test Duration";
            // 
            // radLabel74
            // 
            this.radLabel74.Location = new System.Drawing.Point(53, 113);
            this.radLabel74.Name = "radLabel74";
            this.radLabel74.Size = new System.Drawing.Size(64, 16);
            this.radLabel74.TabIndex = 7;
            this.radLabel74.Text = "Total Users";
            // 
            // radLabel75
            // 
            this.radLabel75.Location = new System.Drawing.Point(207, 69);
            this.radLabel75.Name = "radLabel75";
            this.radLabel75.Size = new System.Drawing.Size(2, 2);
            this.radLabel75.TabIndex = 6;
            // 
            // radLabel76
            // 
            this.radLabel76.Location = new System.Drawing.Point(165, 69);
            this.radLabel76.Name = "radLabel76";
            this.radLabel76.Size = new System.Drawing.Size(9, 16);
            this.radLabel76.TabIndex = 5;
            this.radLabel76.Text = ":";
            // 
            // radLabel77
            // 
            this.radLabel77.Location = new System.Drawing.Point(53, 69);
            this.radLabel77.Name = "radLabel77";
            this.radLabel77.Size = new System.Drawing.Size(80, 16);
            this.radLabel77.TabIndex = 4;
            this.radLabel77.Text = "Test End Time";
            // 
            // radLabel78
            // 
            this.radLabel78.Location = new System.Drawing.Point(207, 47);
            this.radLabel78.Name = "radLabel78";
            this.radLabel78.Size = new System.Drawing.Size(2, 2);
            this.radLabel78.TabIndex = 3;
            // 
            // radLabel79
            // 
            this.radLabel79.Location = new System.Drawing.Point(165, 47);
            this.radLabel79.Name = "radLabel79";
            this.radLabel79.Size = new System.Drawing.Size(9, 16);
            this.radLabel79.TabIndex = 2;
            this.radLabel79.Text = ":";
            // 
            // radLabel80
            // 
            this.radLabel80.Location = new System.Drawing.Point(53, 47);
            this.radLabel80.Name = "radLabel80";
            this.radLabel80.Size = new System.Drawing.Size(83, 16);
            this.radLabel80.TabIndex = 1;
            this.radLabel80.Text = "Test Start Time";
            // 
            // radLabel81
            // 
            this.radLabel81.Location = new System.Drawing.Point(112, 12);
            this.radLabel81.Name = "radLabel81";
            this.radLabel81.Size = new System.Drawing.Size(114, 16);
            this.radLabel81.TabIndex = 0;
            this.radLabel81.Text = "SUMMARY REPORT";
            // 
            // brwReportView
            // 
            this.brwReportView.ContextMenuStrip = this.cntmSave;
            this.brwReportView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brwReportView.Location = new System.Drawing.Point(0, 0);
            this.brwReportView.MinimumSize = new System.Drawing.Size(20, 20);
            this.brwReportView.Name = "brwReportView";
            this.brwReportView.ScriptErrorsSuppressed = true;
            this.brwReportView.Size = new System.Drawing.Size(627, 679);
            this.brwReportView.TabIndex = 1;
            this.brwReportView.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.brwReportView_DocumentCompleted);
            // 
            // cntmSave
            // 
            this.cntmSave.BackColor = System.Drawing.SystemColors.ControlLight;
            this.cntmSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cntmSave.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.cntmSave.Name = "cntmUVScript";
            this.cntmSave.Size = new System.Drawing.Size(106, 26);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.AutoToolTip = true;
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.deleteToolStripMenuItem.Text = "&Save";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // tabsReport
            // 
            this.tabsReport.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.tabsReport.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.tabsReport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.tabsReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabsReport.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.tabiHeader,
            this.tabiParameters,
            this.tabiVariables});
            this.tabsReport.Location = new System.Drawing.Point(0, 0);
            this.tabsReport.Name = "tabsReport";
            this.tabsReport.ScrollOffsetStep = 5;
            this.tabsReport.Size = new System.Drawing.Size(627, 704);
            this.tabsReport.TabIndex = 46;
            this.tabsReport.TabScrollButtonsPosition = Telerik.WinControls.UI.TabScrollButtonsPosition.RightBottom;
            this.tabsReport.Text = "radTabStrip1";
            this.tabsReport.ThemeName = "Telerik";
            this.tabsReport.TabSelected += new Telerik.WinControls.UI.TabEventHandler(this.tabsReport_TabSelected);
            // 
            // tabiHeader
            // 
            this.tabiHeader.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tabiHeader.ContentPanel
            // 
            this.tabiHeader.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.tabiHeader.ContentPanel.CausesValidation = true;
            this.tabiHeader.ContentPanel.Controls.Add(this.brwReportView);
            this.tabiHeader.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabiHeader.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabiHeader.ContentPanel.Location = new System.Drawing.Point(0, 25);
            this.tabiHeader.ContentPanel.Size = new System.Drawing.Size(627, 679);
            this.tabiHeader.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabiHeader.IsSelected = true;
            this.tabiHeader.Margin = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.tabiHeader.Name = "tabiHeader";
            this.tabiHeader.StretchHorizontally = false;
            this.tabiHeader.Text = "Summary";
            // 
            // tabiParameters
            // 
            this.tabiParameters.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tabiParameters.ContentPanel
            // 
            this.tabiParameters.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.tabiParameters.ContentPanel.CausesValidation = true;
            this.tabiParameters.ContentPanel.Controls.Add(this.brwErrors);
            this.tabiParameters.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabiParameters.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabiParameters.ContentPanel.Location = new System.Drawing.Point(0, 25);
            this.tabiParameters.ContentPanel.Size = new System.Drawing.Size(627, 679);
            this.tabiParameters.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabiParameters.Margin = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.tabiParameters.Name = "tabiParameters";
            this.tabiParameters.StretchHorizontally = false;
            this.tabiParameters.Text = "Errors";
            // 
            // brwErrors
            // 
            this.brwErrors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brwErrors.Location = new System.Drawing.Point(0, 0);
            this.brwErrors.MinimumSize = new System.Drawing.Size(20, 20);
            this.brwErrors.Name = "brwErrors";
            this.brwErrors.ScriptErrorsSuppressed = true;
            this.brwErrors.Size = new System.Drawing.Size(627, 679);
            this.brwErrors.TabIndex = 2;
            // 
            // tabiVariables
            // 
            this.tabiVariables.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tabiVariables.ContentPanel
            // 
            this.tabiVariables.ContentPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.tabiVariables.ContentPanel.CausesValidation = true;
            this.tabiVariables.ContentPanel.Controls.Add(this.brwLogs);
            this.tabiVariables.ContentPanel.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.tabiVariables.ContentPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.tabiVariables.ContentPanel.Location = new System.Drawing.Point(0, 25);
            this.tabiVariables.ContentPanel.Size = new System.Drawing.Size(627, 679);
            this.tabiVariables.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabiVariables.Margin = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.tabiVariables.Name = "tabiVariables";
            this.tabiVariables.StretchHorizontally = false;
            this.tabiVariables.Text = "Logs";
            // 
            // brwLogs
            // 
            this.brwLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brwLogs.Location = new System.Drawing.Point(0, 0);
            this.brwLogs.MinimumSize = new System.Drawing.Size(20, 20);
            this.brwLogs.Name = "brwLogs";
            this.brwLogs.ScriptErrorsSuppressed = true;
            this.brwLogs.Size = new System.Drawing.Size(627, 679);
            this.brwLogs.TabIndex = 2;
            // 
            // radSplitContainer1
            // 
            this.radSplitContainer1.Controls.Add(this.splitPanel1);
            this.radSplitContainer1.Controls.Add(this.splitPanel2);
            this.radSplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radSplitContainer1.Location = new System.Drawing.Point(0, 0);
            this.radSplitContainer1.Name = "radSplitContainer1";
            // 
            // 
            // 
            this.radSplitContainer1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.radSplitContainer1.Size = new System.Drawing.Size(825, 704);
            this.radSplitContainer1.TabIndex = 47;
            this.radSplitContainer1.TabStop = false;
            this.radSplitContainer1.Text = "radSplitContainer1";
            // 
            // splitPanel1
            // 
            this.splitPanel1.Controls.Add(this.radPanel2);
            this.splitPanel1.Location = new System.Drawing.Point(0, 0);
            this.splitPanel1.Name = "splitPanel1";
            // 
            // 
            // 
            this.splitPanel1.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel1.Size = new System.Drawing.Size(195, 704);
            this.splitPanel1.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(-0.2627737F, 0F);
            this.splitPanel1.SizeInfo.SplitterCorrection = new System.Drawing.Size(-211, 0);
            this.splitPanel1.TabIndex = 0;
            this.splitPanel1.TabStop = false;
            this.splitPanel1.Text = "splitPanel1";
            // 
            // radPanel2
            // 
            this.radPanel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.radPanel2.Controls.Add(this.radGridReport);
            this.radPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radPanel2.Location = new System.Drawing.Point(0, 0);
            this.radPanel2.Name = "radPanel2";
            this.radPanel2.Size = new System.Drawing.Size(195, 704);
            this.radPanel2.TabIndex = 2;
            this.radPanel2.Text = "radPanel2";
            // 
            // radGridReport
            // 
            this.radGridReport.ForeColor = System.Drawing.Color.Black;
            this.radGridReport.Location = new System.Drawing.Point(4, 28);
            // 
            // 
            // 
            this.radGridReport.MasterGridViewTemplate.AllowAddNewRow = false;
            this.radGridReport.MasterGridViewTemplate.AllowDeleteRow = false;
            this.radGridReport.MasterGridViewTemplate.AllowEditRow = false;
            this.radGridReport.MasterGridViewTemplate.ChildGridViewTemplates.AddRange(new Telerik.WinControls.UI.GridViewTemplate[] {
            this.gridViewTemplate1});
            this.radGridReport.MasterGridViewTemplate.EnableFiltering = true;
            this.radGridReport.Name = "radGridReport";
            this.radGridReport.Padding = new System.Windows.Forms.Padding(0, 0, 0, 1);
            // 
            // 
            // 
            this.radGridReport.RootElement.ForeColor = System.Drawing.Color.Black;
            this.radGridReport.RootElement.Padding = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.radGridReport.Size = new System.Drawing.Size(306, 654);
            this.radGridReport.TabIndex = 2;
            // 
            // splitPanel2
            // 
            this.splitPanel2.Controls.Add(this.tabsReport);
            this.splitPanel2.Location = new System.Drawing.Point(198, 0);
            this.splitPanel2.Name = "splitPanel2";
            // 
            // 
            // 
            this.splitPanel2.RootElement.MinSize = new System.Drawing.Size(25, 25);
            this.splitPanel2.Size = new System.Drawing.Size(627, 704);
            this.splitPanel2.SizeInfo.AutoSizeScale = new System.Drawing.SizeF(0.2627738F, 0F);
            this.splitPanel2.SizeInfo.SplitterCorrection = new System.Drawing.Size(211, 0);
            this.splitPanel2.TabIndex = 1;
            this.splitPanel2.TabStop = false;
            this.splitPanel2.Text = "splitPanel2";
            // 
            // userControlReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.radSplitContainer1);
            this.Name = "userControlReports";
            this.Size = new System.Drawing.Size(825, 704);
            ((System.ComponentModel.ISupportInitialize)(this.radLabel32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel43)).EndInit();
            this.radLabel43.ResumeLayout(false);
            this.radLabel43.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel48)).EndInit();
            this.radLabel48.ResumeLayout(false);
            this.radLabel48.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel81)).EndInit();
            this.cntmSave.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tabsReport)).EndInit();
            this.tabsReport.ResumeLayout(false);
            this.tabiHeader.ContentPanel.ResumeLayout(false);
            this.tabiParameters.ContentPanel.ResumeLayout(false);
            this.tabiVariables.ContentPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radSplitContainer1)).EndInit();
            this.radSplitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel1)).EndInit();
            this.splitPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radPanel2)).EndInit();
            this.radPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.radGridReport.MasterGridViewTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewTemplate1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitPanel2)).EndInit();
            this.splitPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadLabel radLabel32;
        private Telerik.WinControls.UI.RadLabel radLabel35;
        private Telerik.WinControls.UI.RadLabel radLabel38;
        private Telerik.WinControls.UI.RadLabel radLabel39;
        private Telerik.WinControls.UI.RadLabel radLabel40;
        private Telerik.WinControls.UI.RadLabel radLabel41;
        private Telerik.WinControls.UI.RadLabel radLabel42;
        private Telerik.WinControls.UI.RadLabel radLabel43;
        private Telerik.WinControls.UI.RadLabel radLabel44;
        private Telerik.WinControls.UI.RadLabel radLabel45;
        private Telerik.WinControls.UI.RadLabel radLabel46;
        private Telerik.WinControls.UI.RadLabel radLabel47;
        private Telerik.WinControls.UI.RadLabel radLabel48;
        private Telerik.WinControls.UI.RadLabel radLabel49;
        private Telerik.WinControls.UI.RadLabel radLabel50;
        private Telerik.WinControls.UI.RadLabel radLabel51;
        private Telerik.WinControls.UI.RadLabel radLabel52;
        private Telerik.WinControls.UI.RadLabel radLabel53;
        private Telerik.WinControls.UI.RadLabel radLabel54;
        private Telerik.WinControls.UI.RadLabel radLabel55;
        private Telerik.WinControls.UI.RadLabel radLabel56;
        private Telerik.WinControls.UI.RadLabel radLabel57;
        private Telerik.WinControls.UI.RadLabel radLabel58;
        private Telerik.WinControls.UI.RadLabel radLabel59;
        private Telerik.WinControls.UI.RadLabel radLabel60;
        private Telerik.WinControls.UI.RadLabel radLabel61;
        private Telerik.WinControls.UI.RadLabel radLabel62;
        private Telerik.WinControls.UI.RadLabel radLabel63;
        private Telerik.WinControls.UI.RadLabel radLabel64;
        private Telerik.WinControls.UI.RadLabel radLabel65;
        private Telerik.WinControls.UI.RadLabel radLabel66;
        private Telerik.WinControls.UI.RadLabel radLabel67;
        private Telerik.WinControls.UI.RadLabel radLabel68;
        private Telerik.WinControls.UI.RadLabel radLabel69;
        private Telerik.WinControls.UI.RadLabel radLabel70;
        private Telerik.WinControls.UI.RadLabel radLabel71;
        private Telerik.WinControls.UI.RadLabel radLabel72;
        private Telerik.WinControls.UI.RadLabel radLabel73;
        private Telerik.WinControls.UI.RadLabel radLabel74;
        private Telerik.WinControls.UI.RadLabel radLabel75;
        private Telerik.WinControls.UI.RadLabel radLabel76;
        private Telerik.WinControls.UI.RadLabel radLabel77;
        private Telerik.WinControls.UI.RadLabel radLabel78;
        private Telerik.WinControls.UI.RadLabel radLabel79;
        private Telerik.WinControls.UI.RadLabel radLabel80;
        private Telerik.WinControls.UI.RadLabel radLabel81;
        private System.Windows.Forms.WebBrowser brwReportView;
        private Telerik.WinControls.UI.RadTabStrip tabsReport;
        private Telerik.WinControls.UI.TabItem tabiHeader;
        private Telerik.WinControls.UI.TabItem tabiParameters;
        private Telerik.WinControls.UI.TabItem tabiVariables;
        private Telerik.WinControls.UI.RadSplitContainer radSplitContainer1;
        private Telerik.WinControls.UI.SplitPanel splitPanel1;
        private Telerik.WinControls.UI.SplitPanel splitPanel2;
        private Telerik.WinControls.UI.RadPanel radPanel2;
        private System.Windows.Forms.WebBrowser brwErrors;
        private System.Windows.Forms.WebBrowser brwLogs;
        private System.Windows.Forms.ContextMenuStrip cntmSave;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private Telerik.WinControls.UI.RadGridView radGridReport;
        private Telerik.WinControls.UI.GridViewTemplate gridViewTemplate1;
    }
}
