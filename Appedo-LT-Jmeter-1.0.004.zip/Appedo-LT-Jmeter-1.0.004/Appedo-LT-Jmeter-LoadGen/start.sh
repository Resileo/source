nohup java -jar appedo_lt_jmeter_loadgen_*.jar > logs/appedo_lt_jmeter_loadgen_$(date +%Y-%m-%d_%H%M).log 2>&1 &
