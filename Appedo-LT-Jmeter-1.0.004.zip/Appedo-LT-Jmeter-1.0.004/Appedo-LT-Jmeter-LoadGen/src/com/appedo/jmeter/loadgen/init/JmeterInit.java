package com.appedo.jmeter.loadgen.init;

import java.util.Timer;
import java.util.TimerTask;

import com.appedo.jmeter.loadgen.common.Constants;
import com.appedo.loadgen.threads.JmeterQueueDrainingThread;

public class JmeterInit {

	public static TimerTask timerTaskJmeter = null;
	public static Timer timerJmeter = new Timer();
	
	public static void main(String[] args) {
		
		try {
			Constants.loadConstantsProperties();
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			
			timerTaskJmeter = new JmeterQueueDrainingThread();
			timerJmeter.schedule(timerTaskJmeter, 100, 20*1000);
			
		} catch (Exception e) {
			System.out.println("Exception in JmeterInit Main");
		}
	}
}
