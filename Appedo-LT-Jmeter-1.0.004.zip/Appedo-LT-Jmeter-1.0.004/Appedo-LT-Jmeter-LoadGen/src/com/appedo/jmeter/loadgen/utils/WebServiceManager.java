package com.appedo.jmeter.loadgen.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.PartSource;
import org.apache.commons.httpclient.methods.multipart.StringPart;

public class WebServiceManager {

	HashMap<String, String> hmHeaderPart = new HashMap<String, String>();
	HashMap<String, String> hmRequestParameters = new HashMap<String, String>();
	HashMap<String, String> hmMultiPart = new HashMap<String, String>();
	String strStringEntity = null, strStringEntityContentType = null, strStringEntityContentFormat = null;
	static String strMultiPartFileName = null, strMultiPartContent = null;
	
	private Integer nStatusCode = null;
	private String strResponse = null;
	
	private JSONObject joResponse = null;
	private JSONArray jaResponse = null;
	
	/**
	 * Send a HTTP request
	 * 
	 * @param URL
	 */
	public void sendRequest(String URL) {
		String strParamKey = null, strParamValue = null, strHeaderKey = null, strHeaderValue = null;
		
		HttpClient client = new HttpClient();
		PostMethod method = null;
		MultipartRequestEntity multiPartRequestEntity = null;
		StringRequestEntity stringRequestEntity = null;
		ArrayList<Part> alMulitPart = null;
		
		try{
			// Get the response from WebService
			method = new PostMethod(URL);
			System.out.println("URL: "+URL);
			
			
			// Header
			for(Map.Entry<String, String> itr : hmHeaderPart.entrySet()) {
				strHeaderKey = itr.getKey();
				strHeaderValue = itr.getValue();
				method.addRequestHeader(strHeaderKey, strHeaderValue);
				System.out.println("header param: "+strHeaderKey+" <> "+strHeaderValue.length()+" <> "+strHeaderValue.getBytes("UTF-8").length);
			}
			
			
			// Request Parameters
			if( hmMultiPart.size() > 0 ) {
				alMulitPart = new ArrayList<Part>();
				
				// Request parameters
				for(Map.Entry<String, String> itr : hmRequestParameters.entrySet()) {
					strParamKey = itr.getKey();
					strParamValue = itr.getValue();
					alMulitPart.add(new StringPart(strParamKey, strParamValue, "UTF-8"));
					System.out.println("Body param: "+strParamKey+" <> "+strParamValue.length()+" <> "+strParamValue.getBytes("UTF-8").length);
				}
			} else {
				for(Map.Entry<String, String> itr : hmRequestParameters.entrySet()) {
					strParamKey = itr.getKey();
					strParamValue = itr.getValue();
					method.setParameter(strParamKey, strParamValue);
					System.out.println("Body param: "+strParamKey+" <> "+strParamValue.length()+" <> "+strParamValue.getBytes("UTF-8").length);
				}
			}
			
			
			// MultiParts
			if( hmMultiPart.size() > 0 ) {
				int i=0;
				for(Map.Entry<String, String> itr : hmMultiPart.entrySet()) {
					strMultiPartFileName = itr.getKey();
					strMultiPartContent = itr.getValue();
					
					i++;
					
					PartSource fisPS = new PartSource() {
						public long getLength() {
							try {
								return strMultiPartContent.getBytes("UTF-8").length;
							} catch (UnsupportedEncodingException e) {
								e.printStackTrace();
								return 0;
							}
						}
						public String getFileName() {
							return strMultiPartFileName;
						}
						public InputStream createInputStream() throws IOException {
							return new ByteArrayInputStream(strMultiPartContent.getBytes("UTF-8"));
						}
					};
					alMulitPart.add(new FilePart("file_"+i, fisPS));
				}
				
				multiPartRequestEntity = new MultipartRequestEntity(alMulitPart.toArray( new Part[alMulitPart.size()] ), method.getParams());
				method.setRequestEntity(multiPartRequestEntity);
			}
			
			
			// StringEntity
			if( strStringEntity != null && ! strStringEntity.isEmpty() ) {
				stringRequestEntity = new StringRequestEntity(strStringEntity, strStringEntityContentType, strStringEntityContentFormat);
				method.setRequestEntity(stringRequestEntity);
			}
			
			
			method.setRequestHeader("Connection", "close");
			nStatusCode = client.executeMethod(method);
			
			if (nStatusCode != HttpStatus.SC_OK) {
				System.err.println("Excetion in URL call: "+URL);
				System.err.println("statusCode: "+nStatusCode);
				System.err.println("Method failed: " + method.getStatusLine());
				System.err.println("Response: "+method.getResponseBodyAsString());
			} else {
				
				strResponse = method.getResponseBodyAsString().trim();
				//System.out.println("strResponseJSONStream: "+strResponse);
				
				if( strResponse.length() > 0 ) {
					if( strResponse.startsWith("{") && strResponse.endsWith("}") ) {
						joResponse = JSONObject.fromObject( strResponse );
					} else if( strResponse.startsWith("[") && strResponse.endsWith("]") ) {
						jaResponse = JSONArray.fromObject( strResponse );
					}
				}
			}
		} catch (HttpException he) {
			System.out.println("Exception in WSM.sendRequest: "+he.getMessage());
			he.printStackTrace();
		} catch (IOException ie) {
			System.out.println("Exception in WSM.sendRequest: "+ie.getMessage());
			ie.printStackTrace();
		} catch (Throwable th) {
			System.out.println("Exception in WSM.sendRequest: "+th.getMessage());
			th.printStackTrace();
		} finally {
			method.releaseConnection();
			method = null;
			
			client.getHttpConnectionManager().closeIdleConnections(0);
			client = null;
		}
	}
	
	/**
	 * Add a parameter, which can be sent through sendRequest()
	 * 
	 * @param key
	 * @param value
	 */
	public void addHeader(String key, String value) {
		try{
			hmHeaderPart.put(key, value);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	/**
	 * Add a parameter, which can be sent through sendRequest()
	 * 
	 * @param key
	 * @param value
	 */
	public void addParameter(String key, String value) throws Exception {
		if( strStringEntity != null && ! strStringEntity.isEmpty() ) {
			throw new Exception("StringEntity is available. So unable to add request-parameter.");
		}
		
		hmRequestParameters.put(key, value);
	}
	
	/**
	 * Add a multi-part (i.e.) file-name & file-content, which has to be sent through sendRequest()
	 * 
	 * @param key
	 * @param value
	 */
	public void addMultiPart(String fileName, String fileContent) throws Exception {
		if( strStringEntity != null && ! strStringEntity.isEmpty() ) {
			throw new Exception("StringEntity is available. So unable to add Multipart.");
		}
		hmMultiPart.put(fileName, fileContent);
	}
	
	/**
	 * Add a String-Entity in Request's body, which has to be sent through sendRequest()
	 * 
	 * @param key
	 * @param value
	 */
	public void setStringEntity(String strStringEntityContent, String strStringEntityContentType, String strStringEntityContentFormat) throws Exception {
		if( ! hmMultiPart.isEmpty() ) {
			throw new Exception("Multipart is available. So unable to add StringEntity.");
		}
		if( ! hmRequestParameters.isEmpty() ) {
			throw new Exception("Request-Parameters are available. So unable to add StringEntity.");
		}
		
		this.strStringEntity = strStringEntityContent;
		this.strStringEntityContentType = strStringEntityContentType;
		this.strStringEntityContentFormat = strStringEntityContentFormat;
	}
	
	/**
	 * Convert the InputStream into Bytes.
	 * 
	 * @param is
	 * @return
	 * @throws IOException
	 */
	protected static byte[] getBytes(InputStream is) throws IOException {

		int len;
		int size = 1024;
		byte[] buf;

		if (is instanceof ByteArrayInputStream) {
			size = is.available();
			buf = new byte[size];
			len = is.read(buf, 0, size);
		} else {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			buf = new byte[size];
			while ((len = is.read(buf, 0, size)) != -1)
				bos.write(buf, 0, len);
			buf = bos.toByteArray();
		}
		return buf;
	}
	
	public Integer getStatusCode() {
		return nStatusCode;
	}
	
	public String getResponse() {
		return strResponse;
	}
	
	public JSONObject getJSONObjectResponse() {
		return joResponse;
	}
	
	public JSONArray getJSONArrayResponse() {
		return jaResponse;
	}
	
	public void destory() {
		strResponse = null;
		nStatusCode = null;
	}
	
	@Override
	protected void finalize() throws Throwable {
		destory();
		super.finalize();
	}
}
