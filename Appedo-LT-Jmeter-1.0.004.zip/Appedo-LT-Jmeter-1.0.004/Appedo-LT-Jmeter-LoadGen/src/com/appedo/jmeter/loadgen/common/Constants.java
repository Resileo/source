package com.appedo.jmeter.loadgen.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import com.appedo.jmeter.loadgen.utils.UtilsFactory;

public class Constants {

	public static String THIS_JAR_PATH = null;
	public static String RESOURCE_PATH = "";
	public static String APPEDO_CONFIG_FILE_PATH = "";
	
	public static boolean bConfigPropertiesLoaded = false;

	public static String LT_EXECUTION_SERVICES = "";
	
	public static String JMX_CSV_FOLDERPATH = "";
	public static String JMETER_EXECUTION_SCRIPT_FILEPATH = null;
//	public static String JTL_REPORT_GENERATION_SCRIPT_FILEPATH = null;

	public static String INFLUXDB_PROTOCAL = null;
	public static String INFLUXDB_PORT = null;
	public static String INFLUXDB_DATABASE_NAME = null;
	
	public static String GRAPHITE_BACKEND_LISTENER_XML_FILEPATH = null;
	public static String GRAFANA_DATASOURCE_NAME = null;
	public static String GRAFANA_SQLITE_DB_FILEPATH = null;
	public static String GRAFANA_DASHBOARD_DEFAULT_SLUG = null;
		
	public static int GRAFANA_APPEDO_ORG_ID;
	public static int GRAFANA_APPEDO_ORG_USER_ID;
	
//	public static String GRAFANA_NEW_USER_PASSWORD = null;
//	public static String GRAFANA_NEW_USER_PASSWORD_SALT = null;
//	public static String GRAFANA_NEW_USER_PASSWORD_RANDS = null;
	
	
	public static void loadConstantsProperties() throws Exception {
		Properties prop = new Properties();
		InputStream is = null;
		
		try {
			THIS_JAR_PATH = UtilsFactory.getThisJarPath();
			
			is = new FileInputStream(THIS_JAR_PATH+File.separator+"config.properties");
			prop.load(is);
			
			// Appedo application's resource directory path
			RESOURCE_PATH = prop.getProperty("RESOURCE_PATH");
			APPEDO_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("APPEDO_CONFIG_FILE_PATH");
			JMX_CSV_FOLDERPATH = prop.getProperty("JMX_CSV_FOLDERPATH");
			
			JMETER_EXECUTION_SCRIPT_FILEPATH = THIS_JAR_PATH+File.separator+prop.getProperty("JMETER_EXECUTION_SCRIPT_FILENAME");
//			JTL_REPORT_GENERATION_SCRIPT_FILEPATH = THIS_JAR_PATH+File.separator+prop.getProperty("JTL_REPORT_GENERATION_SCRIPT_FILENAME");
			
			INFLUXDB_PROTOCAL = prop.getProperty("INFLUXDB_PROTOCAL");
			INFLUXDB_PORT = prop.getProperty("INFLUXDB_PORT");
			INFLUXDB_DATABASE_NAME = prop.getProperty("INFLUXDB_DATABASE_NAME");
			
			GRAPHITE_BACKEND_LISTENER_XML_FILEPATH = THIS_JAR_PATH+File.separator+prop.getProperty("GRAPHITE_BACKEND_LISTENER_XML_FILENAME");
			GRAFANA_DATASOURCE_NAME = prop.getProperty("GRAFANA_DATASOURCE_NAME");
			GRAFANA_SQLITE_DB_FILEPATH = prop.getProperty("GRAFANA_SQLITE_DB_FILEPATH");
			GRAFANA_DASHBOARD_DEFAULT_SLUG = prop.getProperty("GRAFANA_SQLITE_DB_DEFAULT_SLUG");
			
			bConfigPropertiesLoaded = true;
		} catch(Exception e) {
			System.out.println(e);
			throw e;
		} finally {
			if(is != null){
				is.close();
			}
			is = null;
		}
	}
	
	public static void loadAppedoConfigProperties(String strAppedoConfigPath) throws Exception {
		Properties prop = new Properties();
		InputStream is = null;
		
		try {
			if( ! bConfigPropertiesLoaded ) {
				System.out.println("<AGENT_HOME>/config.properties must be read before appedo_config.properties reading.");
				throw new Exception("<AGENT_HOME>/config.properties must be read before appedo_config.properties reading.");
			}
			
			is = new FileInputStream(strAppedoConfigPath);
			prop.load(is);
			
			LT_EXECUTION_SERVICES = prop.getProperty("LT_EXECUTION_SERVICES");
			
			GRAFANA_APPEDO_ORG_ID = Integer.parseInt( prop.getProperty("GRAFANA_APPEDO_ORG_ID") );
			GRAFANA_APPEDO_ORG_USER_ID = Integer.parseInt( prop.getProperty("GRAFANA_APPEDO_ORG_USER_ID") );
			
			// Read the property if not mentioned in config.properties
			if( JMX_CSV_FOLDERPATH == null ) {
				JMX_CSV_FOLDERPATH = prop.getProperty("JMX_CSV_FOLDERPATH");
			}
			
			if( INFLUXDB_PROTOCAL == null ) {
				INFLUXDB_PROTOCAL = prop.getProperty("INFLUXDB_PROTOCAL");
			}
			
			if( INFLUXDB_PORT == null ) {
				INFLUXDB_PORT = prop.getProperty("INFLUXDB_PORT");
			}
			
			if( INFLUXDB_DATABASE_NAME == null ) {
				INFLUXDB_DATABASE_NAME = prop.getProperty("INFLUXDB_DATABASE_NAME");
			}

			if( GRAPHITE_BACKEND_LISTENER_XML_FILEPATH == null ) {
				GRAPHITE_BACKEND_LISTENER_XML_FILEPATH = RESOURCE_PATH+File.separator+prop.getProperty("GRAPHITE_BACKEND_LISTENER_XML_FILENAME");
			}
			
			if( GRAFANA_SQLITE_DB_FILEPATH == null ) {
				GRAFANA_SQLITE_DB_FILEPATH = prop.getProperty("GRAFANA_SQLITE_DB_FILEPATH");
			}
			
			if( GRAFANA_DATASOURCE_NAME == null ) {
				GRAFANA_DATASOURCE_NAME = prop.getProperty("GRAFANA_DATASOURCE_NAME");
			}
			
			if( GRAFANA_DASHBOARD_DEFAULT_SLUG == null ) {
				GRAFANA_DASHBOARD_DEFAULT_SLUG = prop.getProperty("GRAFANA_SQLITE_DB_DEFAULT_SLUG");
			}
						
		} catch(Exception e) {
			System.out.println(e);
			throw e;
		} finally {
			if(is != null){
				is.close();
			}
			is = null;
		}
	}
}
