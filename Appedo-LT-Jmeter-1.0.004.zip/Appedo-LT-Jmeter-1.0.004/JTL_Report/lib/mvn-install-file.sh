mvn install:install-file -DartifactId=jamon -DgroupId=com.jamonapi -Dversion=2.7 -Dpackaging=jar -Dfile=jamon-2.7.jar

