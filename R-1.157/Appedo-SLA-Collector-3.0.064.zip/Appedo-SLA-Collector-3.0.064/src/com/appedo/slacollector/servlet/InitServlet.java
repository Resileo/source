package com.appedo.slacollector.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appedo.commons.manager.AppedoMailer;
import com.appedo.manager.LogManager;
import com.appedo.slacollector.common.Constants;
import com.appedo.slacollector.connect.DataBaseManager;
import com.appedo.slacollector.controller.AVMCollectorThreadController;
import com.appedo.slacollector.controller.RUMCollectorThreadController;
import com.appedo.slacollector.controller.SUMCollectorThreadController;
import com.appedo.slacollector.controller.SlaCollectorThreadController;
import com.appedo.slacollector.controller.SlaSlaveDetailsThreadController;
import com.appedo.slacollector.timer.SlaveTimerTask;
import com.appedo.slacollector.utils.AppedoMobileManager;

/**
 * Servlet to handle one operation for the whole application
 * @author navin
 *
 */
public class InitServlet extends HttpServlet {
	// set log access
	
	private static final long serialVersionUID = 1L;
	public static String realPath = null;	
	public static Timer timerRumLog = new Timer();
	public static TimerTask timerTaskSlaveInactive = null;
	public static Timer timerSlaveInactive = new Timer(),timerSlaveDetails = new Timer();
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public void init() {
		//super();
		
		// declare servlet context
		ServletContext context = getServletContext();
		
		realPath = context.getRealPath("//");
		Connection con = null;
		
		try {
			String strConstantsFilePath = context.getInitParameter("CONSTANTS_PROPERTIES_FILE_PATH");
			String strLog4jFilePath = context.getInitParameter("LOG4J_PROPERTIES_FILE_PATH");
			
			
			Constants.CONSTANTS_FILE_PATH = InitServlet.realPath+strConstantsFilePath;
			Constants.LOG4J_PROPERTIES_FILE = InitServlet.realPath+strLog4jFilePath;
			// Loads log4j configuration properties
			LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
			
			// Loads Constant properties 
			Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Loads db config
			DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Loads mail config
			AppedoMailer.loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
			
			// load mobile properties from file
			AppedoMobileManager.loadPropertyFileConstants(Constants.MOBILE_CONFIG_FILE_PATH);
			
			// DataBase connection
			con = DataBaseManager.giveConnection();
			AppedoMobileManager.populateCountryISDCodes(con);
			
			// load appedo constants; say loads appedoWhiteLabels, 
			Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// To insert the breach counters 
			for( int i=0; i<10; i++ ) {
				(new SlaCollectorThreadController()).start();
			}
			
			// To insert the breach counters 
			for( int i=0; i<10; i++ ) {
				(new SUMCollectorThreadController()).start();
			}
			
			// To insert the Availability Breach details
			for( int i = 0; i < 10; i++ ) {
				(new AVMCollectorThreadController()).start();
			}
			
			// To insert the RUM breaches
			for(int i = 0; i < 10; i++) {
				(new RUMCollectorThreadController()).start();
			}
			
			// To update slave status
			for( int i=0; i<10; i++ ) {
				(new SlaSlaveDetailsThreadController()).start();
			}
			
			// Check & update inactive slaves for  Every 5 min 
			timerTaskSlaveInactive = new SlaveTimerTask();
			timerSlaveInactive.schedule(timerTaskSlaveInactive, 500, Constants.TIMER_PERIOD * 1000);
			
		} catch(Throwable e) {
			LogManager.errorLog(e);
			e.printStackTrace();
		} finally {
			DataBaseManager.close(con);
			con = null;
		}
	}
	
	public void aaa(){
		
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
