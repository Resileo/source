package com.appedo.slacollector.common;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import net.sf.json.JSONObject;

import com.appedo.manager.AppedoConstants;
import com.appedo.manager.LogManager;
import com.appedo.slacollector.utils.UtilsFactory;

/**
 * This class holds the application level variables which required through the application.
 * 
 * @author veeru
 *
 */
public class Constants {
	
	public static String CONSTANTS_FILE_PATH = "";
	
	public static String RESOURCE_PATH = "";
	
	public static String APPEDO_CONFIG_FILE_PATH = "";
	
	public static String APPEDO_SLA_COLLECTOR = "";
	
	public static String PATH = ""; 
	//log4j properties file path
	public static String LOG4J_PROPERTIES_FILE = "";
	
	public static String SMTP_MAIL_CONFIG_FILE_PATH = "";
	public static String MOBILE_CONFIG_FILE_PATH = "";
	
	public static String EMAIL_TO_ALERT_FOR_SUM_AGENT = "";
	
	public static String UPLOAD_URL = "";
	
	public static String ACTION_LOG_FILE_FOLDER = "";
	
	public static long TIMER_PERIOD;
	
	public static int INTERVAL;
	
	public static long COUNTER_CONTROLLER_REST_MILLESECONDS = 1000;
	
	public static String EMAIL_TEMPLATES_PATH = "";
	
	/**
	 * Loads constants properties 
	 * 
	 * @param srtConstantsPath
	 */
	public static void loadConstantsProperties(String srtConstantsPath) {
    	Properties prop = new Properties();
    	InputStream is = null;
    	
        try {
    		is = new FileInputStream(srtConstantsPath);
    		prop.load(is);
    		
     		// Appedo application's resource directory path
     		RESOURCE_PATH = prop.getProperty("RESOURCE_PATH");
     		
     		APPEDO_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("APPEDO_CONFIG_FILE_PATH");
     		
     		APPEDO_SLA_COLLECTOR = prop.getProperty("APPEDO_SLA_COLLECTOR");
     		
     		PATH = RESOURCE_PATH+prop.getProperty("Path");   		
			
			LOG4J_PROPERTIES_FILE = RESOURCE_PATH+prop.getProperty("LOG4J_CONFIG_FILE_PATH");
     		
			SMTP_MAIL_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("SMTP_MAIL_CONFIG_FILE_PATH");
			MOBILE_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("MOBILE_CONFIG_FILE_PATH");
			ACTION_LOG_FILE_FOLDER = RESOURCE_PATH+prop.getProperty("ACTION_LOG_FILE_FOLDER");
     		EMAIL_TEMPLATES_PATH = RESOURCE_PATH+prop.getProperty("EMAIL_TEMPLATES_PATH");
     		
			INTERVAL = Integer.parseInt(prop.getProperty("queryinterval"));
			TIMER_PERIOD = Long.parseLong(prop.getProperty("node_status__check_period_in_sec"));

			COUNTER_CONTROLLER_REST_MILLESECONDS = Integer.parseInt(prop.getProperty("COUNTER_CONTROLLER_REST_MILLESECONDS"));
        } catch(Exception e) {
        	LogManager.errorLog(e);
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        }	
	}
	
	public static void loadAppedoConfigProperties(String strAppedoConfigPath) throws Exception {
    	Properties prop = new Properties();
    	InputStream is = null;
    	
    	JSONObject joAppedoCollector = null;
    	
        try {
    		is = new FileInputStream(strAppedoConfigPath);
    		prop.load(is);
    		
     		UPLOAD_URL = prop.getProperty("UPLOAD_URL");
     		EMAIL_TO_ALERT_FOR_SUM_AGENT = prop.getProperty("EMAIL_TO_ALERT_FOR_SUM_AGENT");

     		// RUM related variables
     		//RUM_JS_SCRIPT_FILES_URL = prop.getProperty("RUM_JS_SCRIPT_FILES_URL");
        } catch(Exception e) {
        	LogManager.errorLog(e);
        	throw e;
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        	
        	UtilsFactory.clearCollectionHieracy(joAppedoCollector);
        	joAppedoCollector = null;
        }	
	}

	/**
	 * loads AppedoConstants, 
	 *   of loads Appedo whitelabels, replacement of word `Appedo` as configured in DB
	 * 
	 * @param strAppedoConfigPath
	 * @throws Exception
	 */
	public static void loadAppedoWhiteLabels(String strAppedoConfigPath) throws Exception {
		
		try {
			AppedoConstants.getAppedoConstants().loadAppedoConstants(strAppedoConfigPath);
		} catch (Exception e) {
			throw e;
		}
	}
}