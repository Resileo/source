package com.appedo.slacollector.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.manager.LogManager;
import com.appedo.slacollector.connect.DataBaseManager;
import com.appedo.slacollector.utils.UtilsFactory;
import com.appedo.utils.HumanReadableFormatter;

/**
 * To insert the ASD, SUM, AVM & RUM breaches
 * 
 * @author Veeru
 *
 */
public class SlaCollectorDBI {
	
	public void insertSlaBreachTable(Connection con, long lUserId, JSONObject joBreachedCounter, long lTimeAppedoQueuedOn) throws Throwable {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			// Eg: slaid":201,"userid":3,"counterid":8,"countertempid":738,"isabovethreshold":false,"warning_threshold_value":700000,"critical_threshold_value":8000000,"received_value":98875,breach_severity:"CRITICAL"}]
			sbQuery	.append("INSERT INTO so_threshold_breach_").append(lUserId).append(" ")
					.append("(sla_id, user_id, guid, counter_id, counter_template_id, is_above, ")
					.append(" warning_threshold_value, critical_threshold_value, received_value, received_on, breached_severity, ")
					.append(" thread_created, enterprise_id, uid) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ")
					.append(UtilsFactory.makeValidVarchar(UtilsFactory.formatTimeStampToyyyyMMddHHmmssSSS(lTimeAppedoQueuedOn))).append("::timestamp, ")
					.append("?, ?, ?, (SELECT uid FROM module_master WHERE guid = ?))");

			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, joBreachedCounter.getLong("slaid"));
			pstmt.setLong(2, joBreachedCounter.getLong("userid"));
			pstmt.setString(3, joBreachedCounter.getString("guid"));
			pstmt.setLong(4, joBreachedCounter.getLong("counterid"));
			pstmt.setLong(5, joBreachedCounter.getLong("countertempid"));
			pstmt.setBoolean(6, joBreachedCounter.getBoolean("isabovethreshold"));
			pstmt.setLong(7, joBreachedCounter.getLong("warning_threshold_value"));
			pstmt.setLong(8, joBreachedCounter.getLong("critical_threshold_value"));
			pstmt.setLong(9, joBreachedCounter.getLong("received_value"));
			pstmt.setString(10, joBreachedCounter.getString("breached_severity"));
			pstmt.setBoolean(11, false);
			pstmt.setLong(12, -1);
			pstmt.setString(13, joBreachedCounter.getString("guid"));

			pstmt.executeUpdate();
		} catch (Throwable t) {
			LogManager.errorLog(t, sbQuery);
			throw t;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	public void insertSUMBreachTable(Connection con, JSONObject joBreachCounters, long lTimeAppedoQueuedOn) throws Throwable {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			//slaid":201,"userid":3,"counterid":8,"countertempid":738,"isabovethreshold":false,"thresholdvalue":700000,"received_value":98875}]
			sbQuery .append("INSERT INTO so_sum_threshold_breach_")
					.append(joBreachCounters.getLong("userid"))
					.append("(sla_id, sla_sum_id, har_id, location, breached_severity, threshold_value, err_set_value, received_value, received_on )")
					.append(" VALUES(?, ?, ?, ?, ?, ?, ?, ?, ")
					.append(UtilsFactory.makeValidVarchar(UtilsFactory.formatTimeStampToyyyyMMddHHmmssSSS(lTimeAppedoQueuedOn))).append("::timestamp ) ");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);

			pstmt.setLong(1, joBreachCounters.getLong("sla_id"));
			pstmt.setLong(2, joBreachCounters.getLong("sla_sum_id"));

			if (joBreachCounters.getString("breached_severity").equals("WEBSITE_NOT_REACHABLE")) {
				pstmt.setNull(3, Types.INTEGER);
				pstmt.setString(4, joBreachCounters.getString("location"));
				pstmt.setString(5, joBreachCounters.getString("breached_severity"));
				pstmt.setNull(6, Types.INTEGER);
				pstmt.setNull(7, Types.INTEGER);
				pstmt.setNull(8, Types.INTEGER);
			} else {
				pstmt.setLong(3, joBreachCounters.getLong("har_id"));
				pstmt.setString(4, joBreachCounters.getString("location"));
				pstmt.setString(5, joBreachCounters.getString("breached_severity"));
				pstmt.setLong(6, joBreachCounters.getLong("threshold_set_value"));
				pstmt.setLong(7, joBreachCounters.getLong("err_set_value"));
				pstmt.setDouble(8, joBreachCounters.getDouble("received_value"));
			}

			pstmt.executeUpdate();
			
		} catch (Throwable t) {
			LogManager.errorLog(t, sbQuery);
			throw t;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			
			LogManager.logMethodEnd(dateLog);
		}
	}

	public void insertAVMBreachTable(Connection con, JSONObject joBreachCounters, long lTimeAppedoQueuedOn) throws Throwable {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();
		
		try {
			// Eg.: 
			sbQuery .append("INSERT INTO so_avm_breach_").append(joBreachCounters.getLong("userid"))
					.append("(sla_id, avm_test_id, agent_id, guid, country, state, city, region, zone, breached_severity, received_status, received_response_code, received_on)")
					.append(" VALUES(?, ?, (SELECT agent_id FROM avm_agent_master WHERE guid = ?), ?, ?, ?, ?, ?, ?, ?, ?, ?, to_timestamp( ? /1000) )");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			
			pstmt.setLong(1, joBreachCounters.getLong("sla_id"));
			pstmt.setLong(2, joBreachCounters.getLong("avm_test_id"));
			pstmt.setString(3, joBreachCounters.getString("guid"));
			pstmt.setString(4, joBreachCounters.getString("guid"));
			pstmt.setString(5, joBreachCounters.getString("country"));
			pstmt.setString(6, joBreachCounters.getString("state"));
			pstmt.setString(7, joBreachCounters.getString("city"));
			pstmt.setString(8, joBreachCounters.getString("region"));
			pstmt.setString(9, joBreachCounters.getString("zone"));
			pstmt.setString(10, joBreachCounters.getString("breached_severity"));
			pstmt.setString(11, joBreachCounters.getString("received_status"));
			pstmt.setInt(12, joBreachCounters.getInt("received_response_code"));
			pstmt.setLong(13, lTimeAppedoQueuedOn);
			
			pstmt.executeUpdate();
			
		} catch (Throwable t) {
			LogManager.errorLog(t, sbQuery);
			throw t;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	/**
	 * inserts uid's RUM breach data to `so_rum_threshold_breach_<user_id>`
	 * 
	 * @param con
	 * @param lUserId
	 * @param joRUMBreachedData
	 * @param lTimeAppedoQueuedOn
	 * @throws Throwable
	 */
	public void insertRUMBreach(Connection con, long lUserId, JSONObject joRUMBreachedData, long lTimeAppedoQueuedOn) throws Throwable {
		PreparedStatement pstmt = null;

		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery	.append("INSERT INTO so_rum_threshold_breach_").append(lUserId).append(" ")
					.append("  (sla_id, user_id, guid, uid, rum_id, is_above, warning_threshold_value, critical_threshold_value, received_value, received_on, breached_severity) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
					//.append(UtilsFactory.makeValidVarchar(UtilsFactory.formatTimeStampToyyyyMMddHHmmssS(lTimeAppedoQueuedOn))).append("::timestamp, ?) ");

			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, joRUMBreachedData.getLong("slaId"));
			pstmt.setLong(2, lUserId);
			pstmt.setString(3, joRUMBreachedData.getString("guid"));
			pstmt.setLong(4, joRUMBreachedData.getLong("uid"));
			pstmt.setLong(5, joRUMBreachedData.getLong("rum_id"));
			pstmt.setBoolean(6, joRUMBreachedData.getBoolean("is_above_threshold"));
			pstmt.setInt(7, joRUMBreachedData.getInt("warning_threshold_value"));
			pstmt.setInt(8, joRUMBreachedData.getInt("critical_threshold_value"));
			pstmt.setLong(9, joRUMBreachedData.getLong("received_value"));
			pstmt.setTimestamp(10, new Timestamp(lTimeAppedoQueuedOn));
			pstmt.setString(11, joRUMBreachedData.getString("breached_severity"));

			pstmt.executeUpdate();
		} catch (Throwable t) {
			LogManager.errorLog(t, sbQuery);
			throw t;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * to update sla_alert_log table when the action is taken 
	 * @param con
	 * @param lUserId
	 * @param lSlaid
	 * @param strEmailContent
	 * @param strSmsContent
	 * @param strEmailId
	 * @param strSms
	 * @param bIsSent
	 * @param bIsSuccess
	 * @throws Exception
	 */
	
	public void updateSlaAlertLog(Connection con, long lUserId, long lSlaid, long lTimeAppedoQueuedOn, String strEmailContent, String strSmsContent, String strEmailId, String strSms, boolean bIsSent, boolean bIsSuccess) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery .append("INSERT INTO sla_alert_log_").append(lUserId).append(" ")
					.append("(user_id, sla_id, alert_content_email, alert_content_sms, email_id, sms, is_sent, is_success, received_on) ")
					.append("VALUES(?, ?, ?, ?, ?, ?, ?, ?, ")
					.append(UtilsFactory.makeValidVarchar(UtilsFactory.formatTimeStampToyyyyMMddHHmmssSSS(lTimeAppedoQueuedOn))).append("::timestamp)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lSlaid);
			pstmt.setString(3, strEmailContent);
			pstmt.setString(4, strSmsContent);
			pstmt.setString(5, strEmailId);
			pstmt.setString(6, strSms);
			pstmt.setBoolean(7, bIsSent);
			pstmt.setBoolean(8, bIsSent);
			
			pstmt.execute();
		  } catch(Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		  } finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		  }
		  
	}
	
	/**
	 * Returns the UID of the Rum Module, for the given encrypted UID.
	 * 
	 * @param con
	 * @param strEncryptedUID
	 * @return
	 * @throws Exception
	 */
	public long getModuleUID(Connection con, String strGUID) throws Exception {
		long lUID = -1l;
		
		String strQuery = null;
		Statement stmt = null;
		ResultSet rst = null;
		
		try{
			strQuery = "SELECT uid FROM module_master WHERE guid = '"+strGUID+"'";
			
			//System.out.println("ff"+strQuery);
			stmt = con.createStatement();
			rst = stmt.executeQuery(strQuery);
			
			while( rst.next() ){
				lUID = rst.getLong("uid");
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			strQuery = null;
		}
		
		return lUID;
	}
	
	/**
	 * gets active SLAs counter(s)
	 * 
	 * @param strGUIDs
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> getActiveSLAsCounters(Connection con, String strGUIDs) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strGUID = "";

		HashMap<String, Object> hmGUIDsMappedToSLAs = new HashMap<String, Object>();
		ArrayList<JSONObject> alSLAs = null;

		JSONObject joSLACounter = null;

		try {
			sbQuery .append("SELECT ssc.sla_id, ss.user_id, ssc.counter_id, ssc.counter_template_id, ssc.guid, ")
					.append("  ssc.is_above_threshold, ssc.warning_threshold_value, ssc.critical_threshold_value, ssc.percentage_calculation, ssc.denominator_counter_id ")
					.append("FROM so_sla_counter ssc ")
					.append("INNER JOIN so_sla ss ON ss.sla_id = ssc.sla_id ")
					.append("  AND ssc.guid IN (").append(strGUIDs).append(") ")
					.append("  AND ss.is_active = TRUE ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joSLACounter = new JSONObject();
				strGUID = rst.getString("guid");

				joSLACounter.put("slaid", rst.getLong("sla_id"));
				joSLACounter.put("userid", rst.getLong("user_id"));
				joSLACounter.put("counterid", rst.getLong("counter_id"));
				joSLACounter.put("countertempid", rst.getLong("counter_template_id"));
				joSLACounter.put("isabovethreshold", rst.getBoolean("is_above_threshold"));
				joSLACounter.put("warning_threshold_value", rst.getLong("warning_threshold_value"));
				joSLACounter.put("critical_threshold_value", rst.getLong("critical_threshold_value"));
				joSLACounter.put("percentage_calculation", rst.getBoolean("percentage_calculation"));
				if (rst.getString("denominator_counter_id") != null) {
					joSLACounter.put("denominator_counter_id", rst.getInt("denominator_counter_id"));
				}

				if (hmGUIDsMappedToSLAs.containsKey(strGUID)) {
					alSLAs = (ArrayList<JSONObject>) hmGUIDsMappedToSLAs.get(strGUID);
				} else {
					alSLAs = new ArrayList<JSONObject>();

					// obj by ref
					hmGUIDsMappedToSLAs.put(strGUID, alSLAs);
				}
				alSLAs.add(joSLACounter);
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex, sbQuery);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strGUID = null;
		}

		return hmGUIDsMappedToSLAs;
	}
	
	public JSONArray getLatestBreachSummary(Connection con, long lUserId, long lSlaId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = null;
		
		JSONArray jaCounters = new JSONArray();
		JSONObject joCounter = null;
		
		Object[] objBreachDetails = null;
		
		String strThresholdOperator = null;
		
		try{
			// TODO: Child counters/mertics, SLAs configured need to get respective `counter_name`
			
			sbQuery = new StringBuilder();
			sbQuery .append("SELECT ct.module_name, ct.category, ct.display_name AS counter_name, CASE WHEN ssc.percentage_calculation THEN '%' ELSE ct.unit END AS unit, ")
					.append("ssc.module_detail_name, ssc.counter_template_id, ssc.warning_threshold_value, ssc.critical_threshold_value, ssc.is_above_threshold ")
					.append("FROM so_sla_counter ssc ")
					.append("INNER JOIN counter_template ct ON ct.counter_template_id = ssc.counter_template_id ")
					.append("WHERE sla_id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lSlaId);
			rst = pstmt.executeQuery();
			
			while( rst.next() ) {
				joCounter = new JSONObject();
				joCounter.put("module_code", rst.getString("module_name"));
				joCounter.put("module_detail_name", rst.getString("module_detail_name"));
				joCounter.put("category", rst.getString("category"));
				joCounter.put("counter_name", rst.getString("counter_name"));
				if( rst.getBoolean("is_above_threshold") ) {
					strThresholdOperator = "&gt;=";
				} else {
					strThresholdOperator = "&lt;=";
				}
				joCounter.put("threshold_operator", strThresholdOperator);
				
				// Get the latest breach details.
				// threshold_value will be critical_threshold_value (or) warning_threshold_value, based on the breached_severity
				objBreachDetails = getLatestBreachedDetails(con, lUserId, rst.getLong("counter_template_id"));
				joCounter.put("breached_severity", objBreachDetails[0]);
				joCounter.put("severity_color", objBreachDetails[1]);
				
				Object[] aryThreshold_value = HumanReadableFormatter.getHumanReadableFormat((double)objBreachDetails[2], rst.getString("unit"), false, false);
				
				joCounter.put("threshold_value", aryThreshold_value[0]);
				joCounter.put("threshold_unit", aryThreshold_value[1]);
				
				Object[] aryValueUnit = HumanReadableFormatter.getHumanReadableFormat((double)objBreachDetails[3], rst.getString("unit"), false, false);
				
				joCounter.put("received_value", aryValueUnit[0]);
				joCounter.put("breached_unit", aryValueUnit[1]);
				jaCounters.add(joCounter);
				
				joCounter = null;
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex, sbQuery);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return jaCounters;
	}
	
	public StringBuilder getBreachedCounterNames(Connection con, long lUserId, long lSlaId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = null, sbRtn = null;
		
		try{
			sbQuery = new StringBuilder();
			sbRtn = new StringBuilder();
			sbQuery .append("SELECT counter_type_name ")
					.append("FROM so_sla_counter ")
					.append("WHERE sla_id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lSlaId);
			rst = pstmt.executeQuery();
			while( rst.next() ){
				sbRtn.append(rst.getString("counter_type_name")).append(",");
			}
			sbRtn.setCharAt(sbRtn.length()-1, '.');
		} catch (Exception ex) {
			LogManager.errorLog(ex, sbQuery);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return sbRtn;
	}
	
	/**
	 * Return the last breached details for the given CounterId of the User.
	 * 
	 * @param lCounterTemplateId
	 * @param lUserId
	 * @return	Array: 0 - "Breach Severity"; 1 - "Breach Threshold Value"; 2 - "Received Value"
	 * 			"Breach Threshold Value" will be critical_threshold_value (or) warning_threshold_value, based on the breached_severity
	 * @throws Exception
	 */
	public Object[] getLatestBreachedDetails(Connection con, long lUserId, long lCounterTemplateId) throws Exception {
		StringBuilder sbQuery = null;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		double dReceivedValue = -1, dThreasholdValue = 0;
		
		String strBreachedSeverity = null, strSeverityColor = null;
		
		try{
			sbQuery = new StringBuilder();
			sbQuery .append("SELECT breached_severity, warning_threshold_value, critical_threshold_value, received_value FROM so_threshold_breach_").append(lUserId)
					.append(" WHERE counter_template_id = ? ")
					.append("ORDER BY received_on DESC limit 1");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lCounterTemplateId);
			rst = pstmt.executeQuery();
			
			if( rst.next() ) {
				dReceivedValue = rst.getLong("received_value");
				strBreachedSeverity = rst.getString("breached_severity");
				
				if( strBreachedSeverity.equals("CRITICAL") ) {
					dThreasholdValue = rst.getDouble("critical_threshold_value");
					strSeverityColor = "RED";
				} else if( strBreachedSeverity.equals("WARNING") ) {
					dThreasholdValue = rst.getDouble("warning_threshold_value");
					strSeverityColor = "ORANGE";
				}
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex, sbQuery);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return new Object[]{strBreachedSeverity, strSeverityColor, dThreasholdValue, dReceivedValue};
	}
	
	public JSONObject getSUMTestDetails(Connection con, long lSUMTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = null;
		
		JSONObject joSumDetails = null;
		
		try{
			sbQuery = new StringBuilder();
			sbQuery .append("SELECT email_id, telephone_code, mobile_no, testname, testtype, CASE WHEN testtype = 'URL' THEN testurl ELSE testtransaction END AS testurl, sms_alert, email_alert FROM sum_test_master st, usermaster u WHERE st.user_id = u.user_id AND test_id = ")
					.append(lSUMTestId);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if( rst.next() ){
				joSumDetails = new JSONObject();
				joSumDetails.put("sum_test_name", rst.getString("testname"));
				joSumDetails.put("test_type", rst.getString("testtype"));
				joSumDetails.put("url", rst.getString("testurl"));
				joSumDetails.put("email_alert", rst.getBoolean("email_alert"));
				joSumDetails.put("sms_alert", rst.getBoolean("sms_alert"));
				joSumDetails.put("email_id", rst.getString("email_id"));
				joSumDetails.put("mobile_no", rst.getString("mobile_no"));
				joSumDetails.put("isd_code", rst.getString("telephone_code"));
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex, sbQuery);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return joSumDetails;
	}
	
	public JSONObject getAVMTestDetails(Connection con, long lAVMTestId) throws Exception {
		StringBuilder sbQuery = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JSONObject joSumDetails = new JSONObject();
		
		try{
			sbQuery = new StringBuilder();
			sbQuery .append("SELECT testname, testurl ")
					.append("FROM avm_test_master st ")
					.append("INNER JOIN usermaster u ON st.user_id = u.user_id AND avm_test_id = ").append(lAVMTestId);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			
			if( rs.next() ){
				joSumDetails.put("avm_test_name", rs.getString("testname"));
				joSumDetails.put("url", rs.getString("testurl"));
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex, sbQuery);
			throw ex;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return joSumDetails;
	}
	
	public long getAVMTestUserId(Connection con, long lTestId) throws Exception {
		long lUserId = -1l;
		
		StringBuilder sbQuery = new StringBuilder();
		Statement stmt = null;
		ResultSet rst = null;
		
		try{
			sbQuery.append("SELECT user_id FROM avm_test_master WHERE avm_test_id = '").append(lTestId).append("'");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while( rst.next() ){
				lUserId = rst.getLong("user_id");
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
		}
		
		return lUserId;
	}
}
