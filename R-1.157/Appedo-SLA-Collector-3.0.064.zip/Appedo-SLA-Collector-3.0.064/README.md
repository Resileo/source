# Appedo-SLA-Collector

# to reload config, appedo_config & mail properties 
/<Appedo-SLA-Collector>/common/reloadConfigAndMailProperties