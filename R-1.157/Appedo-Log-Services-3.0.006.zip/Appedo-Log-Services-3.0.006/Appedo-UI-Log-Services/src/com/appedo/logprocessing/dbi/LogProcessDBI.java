package com.appedo.logprocessing.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.logprocessing.bean.LogViewBean;
import com.appedo.logprocessing.bean.ModuleBean;
import com.appedo.logprocessing.common.Constants;
import com.appedo.logprocessing.common.Constants.ELK_TYPE;
import com.appedo.logprocessing.connect.DataBaseManager;
import com.appedo.logprocessing.utils.CreateELK;
import com.appedo.logprocessing.utils.ProcessBuilderWrapper;
import com.appedo.logprocessing.utils.UtilsFactory;
import com.appedo.manager.LogManager;

public class LogProcessDBI {
	
	
	public long addLogMonitor(Connection con, ModuleBean moduleBean) throws Exception {
		PreparedStatement pstmt = null;
		String strQuery = null;
		long lModuleId = -1L;
		
		try {
			strQuery = "INSERT INTO module_master (user_id, guid, module_code, counter_type_version_id, module_name, description, client_unique_id, created_by, created_on) VALUES (?, ?, ?, ?, ?, ?, ?, ?, now()) ";
			
			pstmt = con.prepareStatement(strQuery, PreparedStatement.RETURN_GENERATED_KEYS);
			
			pstmt.setLong(1, moduleBean.getUserId());
			pstmt.setString(2, moduleBean.getGuid());
			pstmt.setString(3, moduleBean.getModuleType());
			pstmt.setInt(4, moduleBean.getAgentVersionId());
			pstmt.setString(5, moduleBean.getModuleName());
			pstmt.setString(6, moduleBean.getDescription());
			pstmt.setString(7, moduleBean.getClient_unique_id());
			pstmt.setLong(8, moduleBean.getUserId());
			pstmt.executeUpdate();
			
			lModuleId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		
		return lModuleId;
	}
	
	
	public boolean isLogModuleExists(Connection con, ModuleBean moduleBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		boolean bChartNameExists = false;
		
		try {
			//sbQuery	.append("SELECT uid, true from module_master where lower(module_name)=LOWER(?) ")
			//.append("AND user_id=? AND module_code=?");
			
			strQuery = "SELECT EXISTS (SELECT 1 FROM module_master WHERE UPPER(module_name) = UPPER(?) AND user_id = ? AND module_code = ?) AS log_module_exists";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, moduleBean.getModuleName());
			pstmt.setLong(2, moduleBean.getUserId());
			pstmt.setString(3, moduleBean.getModuleType());
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bChartNameExists = rst.getBoolean("log_module_exists");
			}
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		return bChartNameExists;
	}
	
	
	/**
	 * To check whether the given client unique id exits.
	 * @param con
	 * @param moduleBean
	 * @return boolean
	 * @throws Exception
	 */
	public boolean isClientUniqueIdExists(Connection con, ModuleBean moduleBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		boolean bUserMappingExists = false;

		try {
			strQuery = "SELECT EXISTS (SELECT 1 FROM module_master WHERE client_unique_id = ?) AS is_client_unique_id_exists ";

			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, moduleBean.getClient_unique_id());
			rst = pstmt.executeQuery();

			if (rst.next()) {
				bUserMappingExists = rst.getBoolean("is_client_unique_id_exists");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		return bUserMappingExists;
	}
	
	public String getGUID(Connection con, ModuleBean moduleBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		String strGuid = "";
		
		try {
			
			strQuery = "SELECT GUID FROM module_master WHERE client_unique_id = ? and user_id = ?";

			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, moduleBean.getClient_unique_id());
			pstmt.setLong(2, moduleBean.getUserId());
			rst = pstmt.executeQuery();
			
			if (rst.next()) {
				strGuid = rst.getString("GUID");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
		}
		
		return strGuid;
	}
	//select first_name, last_name from usermaster where user_id = (select user_id from module_master where uid = 20)
	public String getNameFromUUID(Connection con, ModuleBean moduleBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		String strGuid = "";
		StringBuilder sbResult = new StringBuilder();
		
		try {
			
			strQuery = "select first_name, last_name from usermaster where user_id = (select user_id from module_master where client_unique_id = ?)";

			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, moduleBean.getClient_unique_id());
			rst = pstmt.executeQuery();
			
			if (rst.next()) {
				//sbResult = rst.getString("first_name");
				sbResult.append(rst.getString("first_name")).append(" ").append(rst.getString("last_name"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
		}
		
		return sbResult.toString();
	}
	
	/**
	 * To get userId using the Encrypted User Id.
	 * 
	 * @param con
	 * @param strEncryptedUserId
	 * @return
	 * @throws Throwable
	 */
	public long getUserId(Connection con, String strEncryptedUserId) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		long lUserId = 0;
		
		try {
			sbQuery	.append("SELECT user_id FROM usermaster WHERE encrypted_user_id = '").append(strEncryptedUserId).append("'");			
			
			stmt = con.createStatement();
			rst = stmt.executeQuery( sbQuery.toString() );
			
			while( rst.next() ) {
				lUserId = rst.getLong("user_id");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return lUserId;
	}

	/**
	 * Log view
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLogTypes(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();

		LinkedHashMap<String, ArrayList<JSONObject>> hmOSLogTypes = new LinkedHashMap<String, ArrayList<JSONObject>>();
		ArrayList<JSONObject> alLogTypes = null;

		JSONObject joLogType = null, joOSLogType = null;
		JSONArray jaLogTypes = new JSONArray();

		String strOsType = "";
		try {

			jaLogTypes = new JSONArray();
			sbQuery.append("SELECT elk_log_id, os_type, log_type, display_name, log_path FROM elk_loglist ORDER BY os_type");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();

			while (rst.next()) {
				strOsType = rst.getString("os_type");

				joLogType = new JSONObject();
				joLogType.put("loglistId", rst.getLong("elk_log_id"));
				joLogType.put("logType", rst.getString("log_type"));
				joLogType.put("displayName", rst.getString("display_name"));
				joLogType.put("logPath", rst.getString("log_path"));

				if (hmOSLogTypes.containsKey(strOsType)) {
					alLogTypes = hmOSLogTypes.get(strOsType);
				} else {
					alLogTypes = new ArrayList<JSONObject>();
					hmOSLogTypes.put(strOsType, alLogTypes);
				}

				alLogTypes.add(joLogType);
			}

			Iterator<Entry<String, ArrayList<JSONObject>>> itrLogTypes = hmOSLogTypes.entrySet().iterator();

			while (itrLogTypes.hasNext()) {

				Map.Entry<String, ArrayList<JSONObject>> logType = itrLogTypes.next();

				joOSLogType = new JSONObject();
				joOSLogType.put("os_name", logType.getKey());
				joOSLogType.put("log_types", logType.getValue());
				jaLogTypes.add(joOSLogType);

				itrLogTypes.remove();
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
		return jaLogTypes;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean getLogViewLicenseDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		boolean isLicenseValidForLog = false;
		
		try {
			if( ! loginUserBean.getLicense().equals("level0") ) {
				// For PAID user
				sbQuery	.append("SELECT EXISTS ( SELECT user_id, start_date, end_date ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type = 'LOG' ")
						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ) AS is_user_has_license");
			} 
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				isLicenseValidForLog = rst.getBoolean("is_user_has_license");
			}

		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return isLicenseValidForLog;
	}
	
	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserLogViews(Connection con, LoginUserBean loginUserBean) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		JSONObject joLogView = null;
		JSONArray jaUserLogViews = null;

		try {
			jaUserLogViews = new JSONArray();
			/*sbQuery.append("SELECT id, elk_client_name, description, el.log_type, el.os_type, ecd.created_on, um.first_name ")
					.append("FROM elk_client_details ecd ")
					.append("INNER JOIN elk_user_mapping eum ON eum.elk_id = ecd.elk_id AND eum.userid = ? ")
					.append("INNER JOIN elk_loglist el ON el.elk_log_id = ecd.log_id ")
					.append("INNER JOIN usermaster um ON um.user_id = eum.userid");*/
			
			sbQuery	.append("SELECT mm.uid, mm.guid, mm.module_name, mm.description, mm.created_by, mm.created_on, mm.client_unique_id, um.first_name FROM module_master mm ")
					.append("INNER JOIN usermaster um ON um.user_id = mm.user_id AND mm.user_id = ? and module_code = 'LOG' ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());

			rst = pstmt.executeQuery();
			while (rst.next()) {
				joLogView = new JSONObject();
				joLogView.put("logViewId", rst.getLong("uid"));
				joLogView.put("logName", rst.getString("module_name"));
				joLogView.put("logViewDescription", rst.getString("description"));
				joLogView.put("logType", "log");
				joLogView.put("osType", "Linux");
				joLogView.put("createdOn", rst.getTimestamp("created_on").getTime());
				joLogView.put("createdBy", rst.getString("first_name"));
				jaUserLogViews.add(joLogView);
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaUserLogViews;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getUserIpAndPort(Connection con, LoginUserBean loginUserBean) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joUserIpAndPort = null;

		try {
			sbQuery.append("SELECT eum.is_enabled, eis.ipaddress nginxid_ip, eis.port nginxid_port, eis1.ipaddress as ki_ip, eis1.port as ki_port ")
					.append("FROM elk_user_mapping eum ")
					.append("INNER JOIN elk_ip_status eis ON eum.nginxid = eis.elk_ip_id ")
					.append("INNER JOIN elk_ip_status eis1 ON eum.kibid = eis1.elk_ip_id AND eum.userid = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());

			rst = pstmt.executeQuery();
			while (rst.next()) {
				joUserIpAndPort = new JSONObject();
				joUserIpAndPort.put("is_enabled", rst.getBoolean("is_enabled"));
				joUserIpAndPort.put("nginxIP", rst.getString("nginxid_ip"));
				joUserIpAndPort.put("nginxPort", rst.getLong("nginxid_port"));
				joUserIpAndPort.put("kiIP", rst.getString("ki_ip"));
				joUserIpAndPort.put("kiPort", rst.getLong("ki_port"));
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joUserIpAndPort;
	}

	/**
	 * Check whether the user has been already mapped in elk_user_mapping table
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isUserMappingExists(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		boolean bUserMappingExists = false;

		try {
			strQuery = "SELECT EXISTS (SELECT 1 FROM elk_user_mapping WHERE userid = ?) AS is_user_mapped ";

			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();

			if (rst.next()) {
				bUserMappingExists = rst.getBoolean("is_user_mapped");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		return bUserMappingExists;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param clientLogName
	 * @return
	 * @throws Exception
	 */
	public boolean validateLogViewName(Connection con, LoginUserBean loginUserBean, String clientLogName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bExists = false;
		StringBuilder sbQuery = new StringBuilder();

		try {

			sbQuery.append("SELECT EXISTS ( SELECT elk_client_name FROM elk_client_details ecd ")
					.append("INNER JOIN elk_user_mapping eum ON eum.elk_id = ecd.elk_id AND eum.userid = ? WHERE UPPER(elk_client_name) = UPPER(?)) AS log_view_exists;");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, clientLogName);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				bExists = rst.getBoolean("log_view_exists");
			}
			sbQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return bExists;
	}

	/**
	 * 
	 * @param con
	 * @param userid
	 * @param isUserMappingExists
	 * @param logViewBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject saveLogDetails(Connection con, String userid, boolean isUserMappingExists, LogViewBean logViewBean) throws Exception {

		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joELKDetail = null;
		JSONObject joElkCompleteDetails = null;
		JSONArray jaELKDetails = new JSONArray();

		try {
			// Fetch the latest elk ip from the table
			// Then transfer the scripts to that ip and start creating it.
			// Once created update it in db used_elk_setups
			// then update the user info too
			// return required values for single line installation
			if (!isUserMappingExists) {
				sbQuery.append("UPDATE elk_iplist SET Current_Port=Current_Port+1 WHERE From_Port <= Current_Port+1 AND To_Port >= Current_Port");
				System.out.println("Query updating elk_iplist : "+ sbQuery.toString());
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.executeUpdate();
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		try {
			sbQuery.setLength(0);
			sbQuery.append("SELECT eip.elk_name_id, en.elk_name , eip.ipaddress, eip.current_port, eip.os_type, eip.os_flavour, eip.os_user_name ")
					.append("FROM elk_iplist eip ")
					.append("INNER JOIN elk_namelist en ON eip.elk_name_id = en.elk_name_id ")
					.append("WHERE eip.From_Port <= eip.Current_Port+1 AND eip.To_Port >= eip.Current_Port ORDER BY eip.elk_name_id");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();

			while (rst.next()) {
				joELKDetail = new JSONObject();
				joELKDetail.put("elk_name_id", rst.getLong("elk_name_id"));
				joELKDetail.put("elk_name", ELK_TYPE.valueOf(rst.getString("elk_name")).getVendorName());
				joELKDetail.put("ipaddress", rst.getString("ipaddress"));
				joELKDetail.put("current_port", rst.getLong("current_port"));
				joELKDetail.put("os_type", rst.getString("os_type"));
				joELKDetail.put("os_flavour", rst.getString("os_flavour"));
				joELKDetail.put("os_user_name", rst.getString("os_user_name"));
				jaELKDetails.add(joELKDetail);
				if (isUserMappingExists) {
					// Check whether process is running or not
					checkForProcess(rst.getString("ipaddress"), Constants.ELK_ID_VS_NAME.get(rst.getLong("elk_name_id")));
				}
			}

			// Checking for db entries and creating the directories
			if (!isUserMappingExists) {
				Constants.ELK_USER_VS_DATA.put(userid, jaELKDetails);
				// Put it in a queue and process it using timer task
				// Inserting into elk_user_mapping table
				insertUserID(con, userid);

			}
			// Have to insert in elk_client_details
			insertClientDetails(con, userid, logViewBean);

			if (!isUserMappingExists) {
				// Need to send mail for the first time
				joElkCompleteDetails = new JSONObject();

				joElkCompleteDetails = getelkCompleteDetails(con,Long.parseLong(userid));

				if (joElkCompleteDetails != null) {

					for (int i = 0; i < jaELKDetails.size(); i++) {
						String key = jaELKDetails.getJSONObject(i).getString("elk_name").toLowerCase();
						String value = jaELKDetails.getJSONObject(i).getString("ipaddress")+" : "+jaELKDetails.getJSONObject(i).getString("current_port");
						joElkCompleteDetails.put(key, value);
					}
				}
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return joElkCompleteDetails;
	}

	/**
	 * 
	 * @param con
	 * @param userid
	 * @param logViewBean
	 * @throws Exception
	 */
	private void insertClientDetails(Connection con, String userid, LogViewBean logViewBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Long elkid = -1L;
		try {
			sbQuery.append("INSERT INTO elk_client_details (elk_client_name, description, elk_id, log_id, log_path, created_on) ")
					.append("VALUES (?, ?, (SELECT elk_id FROM elk_user_mapping WHERE userid = ? limit 1), ?, ?, now())");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, logViewBean.getStrName());
			pstmt.setString(2, UtilsFactory.makeValidVarchar(logViewBean.getStrDescription()));
			pstmt.setLong(3, Long.parseLong(userid));
			//pstmt.setString(4, logViewBean.getStrLogType());
			pstmt.setInt(4, logViewBean.getElkListId());
			pstmt.setString(5, logViewBean.getStrLogPath());
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	/**
	 * 
	 * @param con
	 * @param userid
	 * @throws Exception
	 */
	public void insertUserID(Connection con, String userid) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery.append("INSERT INTO elk_user_mapping (userid, gb_limit, is_limit_reached, esid, lsid, kibid, nginxid) VALUES ("+userid+",2,FALSE,-1,-1,-1,-1)");
			System.out.println("Query inserting into elk_user_mapping : "+sbQuery.toString());
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	/**
	 * 
	 * @param con
	 * @param jaELKDetails
	 * @param userid
	 * @throws Exception
	 */
	public void createELKDir(Connection con, JSONArray jaELKDetails, String userid) throws Exception {
		String esarg = "", lsarg = "", kibarg = "", ngxarg = "";
		String esip = "", lsip = "", kibip = "", ngxip = "";
		String esport = "", lsport = "", kibport = "", ngxport = "";
		Long esid = -1l, ldid = -1l, kibid = -1l, ngxid = 1l;
		String esOsType = "", lsOsType = "", kiOsType = "", ngxOsType = "";
		String esOsFlavour = "", lsOsFlavour = "", kiOsFlavour = "", ngxOsFlavour = "";
		String esOsUserName = "", lsOsUserName = "", kiOsUserName = "", ngxOsUserName = "";

		for (int i = 0; i < jaELKDetails.size(); i++) {
			JSONObject json = jaELKDetails.getJSONObject(i);
			System.out.println("JSON:" + json);
			Long elkNameID = json.getLong("elk_name_id");
			String name = Constants.ELK_ID_VS_NAME.get(elkNameID).toLowerCase();
			String downloadPath = Constants.ELK_DOWNLOAD_PATH;

			switch (name) {
			case "es":
				esip = json.getString("ipaddress");
				esport = json.getString("current_port");
				esarg = esport + " " + downloadPath;
				esOsType = json.getString("os_type");
				esOsFlavour = json.getString("os_flavour");
				esOsUserName = json.getString("os_user_name");
				esid = elkNameID;
				break;
			case "ls":
				lsip = json.getString("ipaddress");
				lsport = json.getString("current_port");
				lsarg = lsport + " " + esip + " " + esport + " " + downloadPath;
				lsOsType = json.getString("os_type");
				lsOsFlavour = json.getString("os_flavour");
				lsOsUserName = json.getString("os_user_name");
				ldid = elkNameID;
				break;
			case "kibana":
				kibip = json.getString("ipaddress");
				kibport = json.getString("current_port");
				kibarg = kibport + " " + esip + " " + esport + " "+ downloadPath;
				kiOsType = json.getString("os_type");
				kiOsFlavour = json.getString("os_flavour");
				kiOsUserName = json.getString("os_user_name");
				kibid = elkNameID;
				break;
			case "nginx":
				ngxip = json.getString("ipaddress");
				ngxport = json.getString("current_port");
				ngxarg = Integer.parseInt(ngxport) - 30 + " " + ngxport + " "+ kibport;
				ngxOsType = json.getString("os_type");
				ngxOsFlavour = json.getString("os_flavour");
				ngxOsUserName = json.getString("os_user_name");
				ngxid = elkNameID;
				break;
			default:
			}
		}
		System.out.println("Before creating elk");
		CreateELK createELK = new CreateELK(esip, esport, esarg, esid, esOsType, esOsFlavour, esOsUserName, userid);
		Thread t = new Thread(createELK);
		t.start();
		CreateELK createELK1 = new CreateELK(lsip, lsport, lsarg, ldid, lsOsType, lsOsFlavour, lsOsUserName, userid);
		Thread t1 = new Thread(createELK1);
		t1.start();
		CreateELK createELK2 = new CreateELK(kibip, kibport, kibarg, kibid, kiOsType, kiOsFlavour, kiOsUserName, userid);
		Thread t2 = new Thread(createELK2);
		t2.start();

		// To insert nginx ip address and port
			insertELKIP(con, ngxip, ngxport, ngxid, ngxOsType, ngxOsFlavour, ngxOsUserName, userid, true);
			
		/*CreateELK createELK3 = new CreateELK(ngxip, ngxport, ngxarg, ngxid, userid);
		Thread t3 = new Thread(createELK3);
		t3.start();*/
		
	}

	/**
	 * 
	 * @param con
	 * @param ip
	 * @param port
	 * @param id
	 * @param userid
	 * @param status
	 * @throws Exception
	 */
	public void insertELKIP(Connection con, String ip, String port, Long id, String OsType, String osFlavour, String osUserName, String userid, boolean status) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null;
		StringBuilder sbQuery = new StringBuilder();
		long newID;
		try {
			sbQuery.append("INSERT INTO elk_ip_status(ipaddress, port, elk_name_id, status, os_type, os_flavour, os_user_name) VALUES (?, ?, ?, ?, ?, ?, ?)");
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, ip);
			pstmt.setLong(2, Long.parseLong(port));
			pstmt.setLong(3, id);
			pstmt.setBoolean(4, status);
			pstmt.setString(5, OsType);
			pstmt.setString(6, osFlavour);
			pstmt.setString(7, osUserName);
			pstmt.executeUpdate();
			newID = DataBaseManager.returnKey(pstmt);

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		try {
			String name = Constants.ELK_ID_VS_NAME.get(id).toLowerCase();
			String colName = "";
			switch (name) {
			case "es":
				colName = "esid";
				break;
			case "ls":
				colName = "lsid";
				break;
			case "kibana":
				colName = "kibid";
				break;
			case "nginx":
				colName = "nginxid";
				break;
			default:
			}
			sbQuery.setLength(0);
			sbQuery.append("UPDATE elk_user_mapping SET " + colName + " = "+ newID + " WHERE userid =" + userid);
			System.out.println("sbQuery : to update : " + sbQuery);
			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.executeUpdate();
			System.out.println("Updated sucessfully..");
		} catch (Exception e) {
			System.out.println("Error in insertELKIP: " + e);
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmt1);
			pstmt1 = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param lLogViewId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getUserLsIpAndPort(Connection con, LoginUserBean loginUserBean, long lLogViewId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt1 = null, pstmt = null;
		ResultSet rst1 = null, rst = null;
		Long lsid = -1L;

		StringBuilder sbQuery = new StringBuilder();
		JSONObject joUserLsIpAndPort = null;

		try {
			sbQuery.append("SELECT lsid FROM elk_user_mapping WHERE userid = ? ");

			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.setLong(1, loginUserBean.getUserId());

			rst1 = pstmt1.executeQuery();
			while (rst1.next()) {
				lsid = rst1.getLong("lsid");
			}
			if (lsid != -1) {
				sbQuery.setLength(0);
				sbQuery.append("SELECT eis.ipaddress ls_ip, eis.port ls_port, eis.elk_name_id, ecd.log_path FROM elk_ip_status ")
						.append("eis INNER JOIN elk_user_mapping eum ON eum.lsid = eis.elk_ip_id AND eum.userid = ?")
						.append("INNER JOIN elk_client_details ecd ON ecd.elk_id = eum.elk_id AND ecd.id = ? ");

				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setLong(1, loginUserBean.getUserId());
				pstmt.setLong(2, lLogViewId);

				rst = pstmt.executeQuery();
				while (rst.next()) {
					joUserLsIpAndPort = new JSONObject();
					joUserLsIpAndPort.put("lsIP", rst.getString("ls_ip"));
					joUserLsIpAndPort.put("lsPort", rst.getLong("ls_port"));
					joUserLsIpAndPort.put("logPath", UtilsFactory.makeValidPath(rst.getString("log_path")));
				}
			} else {
				joUserLsIpAndPort = new JSONObject();
				joUserLsIpAndPort.put("lsIP", -1);
				joUserLsIpAndPort.put("lsPort", "NA");
				joUserLsIpAndPort.put("logPath", "NA");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst1);
			rst = null;
			DataBaseManager.close(pstmt1);
			pstmt = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joUserLsIpAndPort;
	}

	/**
	 * 
	 * @param con
	 * @param lLogViewId
	 * @param lUserId
	 * @throws Exception
	 */
	public void deleteLogView(Connection con, long lLogViewId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		String strQuery = "";

		try {
			strQuery = "DELETE FROM elk_client_details WHERE id = ? AND elk_id = (SELECT elk_id FROM elk_user_mapping WHERE userid = ? )";

			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lLogViewId);
			pstmt.setLong(2, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
	}

	/**
	 * 
	 * @param ip
	 * @param args
	 * @return
	 * @throws Exception
	 */
	private boolean checkForProcess(String ip, String args) throws Exception {
		boolean processExists = false;
		String cmd="ssh -o \"StrictHostKeyChecking no\" -i "+Constants.PEM_FILE_PATH+" fedora@"+ip+" \"ps aux | grep "+args+"| grep -v grep\"";
		try{
			String value = ProcessBuilderWrapper.executeCommandWithStringResult(cmd,false);
			System.out.println("Value :" + value);
			if (!value.isEmpty()) {
				processExists = true;
			}
		} catch (Exception e) {
			System.out.println(e);
			LogManager.errorLog(e);
			throw e;
		}
		return processExists;
	}

	/**
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getelkCompleteDetails(Connection con, long lUserId) throws Exception {

		StringBuilder sbQuery = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONObject joElkDetails = new JSONObject();
		try {
			sbQuery = new StringBuilder();
			sbQuery.append("SELECT eum.elk_id, ecd.elk_client_name, el.log_type, email_id, mobile_no ")
					.append("FROM elk_user_mapping eum ")
					.append("INNER JOIN usermaster um ON eum.userid = um.user_id AND eum.userid = ? ")
					.append("INNER JOIN elk_client_details ecd ON eum.elk_id = ecd.elk_id ")
					.append("INNER JOIN elk_loglist el ON ecd.log_id = el.elk_log_id limit 1");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				joElkDetails.put("elk_client_name", rs.getString("elk_client_name"));
				joElkDetails.put("log_type", rs.getString("log_type"));
				joElkDetails.put("email_id", rs.getString("email_id"));
				joElkDetails.put("mobile_no", rs.getString("mobile_no"));
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return joElkDetails;
	}
}