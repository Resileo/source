package com.appedo.logprocessing.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.logprocessing.bean.LogViewBean;
import com.appedo.logprocessing.bean.ModuleBean;
import com.appedo.logprocessing.connect.DataBaseManager;
import com.appedo.logprocessing.model.LogProcessManager;
import com.appedo.logprocessing.utils.UtilsFactory;
import com.appedo.manager.LogManager;

/**
 * Servlet implementation class LogProcessController
 */
@WebServlet("/LogProcessController")
public class LogProcessController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LogProcessController() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		LoginUserBean loginUserBean = null;
		Connection con = null;
		LogProcessManager logProcessManager = null;
		String strActionCommand = request.getRequestURI();

		if(strActionCommand.endsWith("/log/addLogMonitor")){
			JSONObject joRtn = null;
			String strRtn = "";
			ModuleBean moduleBean = null;

			try {
				con = DataBaseManager.giveConnection();
				moduleBean = new ModuleBean();
				logProcessManager = new LogProcessManager();
				con = DataBaseManager.giveConnection();
				
				moduleBean.setClient_unique_id(request.getParameter("client_unique_id"));
				moduleBean.setEncryptedUserId(request.getParameter("encryptedUserId"));
				moduleBean.setDescription(request.getParameter("description"));
				
				logProcessManager.addLogMonitor(con, moduleBean);
				
				strRtn = moduleBean.getGuid();
				
				DataBaseManager.commitConnection(con);
				logProcessManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				
				if( e.getMessage().equals("MODULE NAME EXISTS") ) {
					strRtn = "Log Module name already exists";
				} 
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to LogTypes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(strRtn);
			}
		} else if (strActionCommand.endsWith("/log/getLogTypes")) {
			JSONObject joRtn = null;
			JSONArray jaLogTypes = null;

			try {
				con = DataBaseManager.giveConnection();
				logProcessManager = new LogProcessManager();
				con = DataBaseManager.giveConnection();

				jaLogTypes = logProcessManager.getLogTypes(con);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaLogTypes);

				logProcessManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to LogTypes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/getLogCardsData")) {
			JSONArray jaUserLogViews = null;
			JSONObject joRtn = null;

			try {
				con = DataBaseManager.giveConnection();
				logProcessManager = new LogProcessManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));

				jaUserLogViews = logProcessManager.getUserLogViews(con, loginUserBean);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserLogViews);

			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Exception in getting Log Card Data " + e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/isUserMappedWithLog")) {
			JSONObject joRtn = null;
			boolean bUserMappingExists = false;

			try {
				con = DataBaseManager.giveConnection();
				logProcessManager = new LogProcessManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));

				bUserMappingExists = logProcessManager.isUserMappingExists(con, loginUserBean.getUserId());

				joRtn = UtilsFactory.getJSONSuccessReturn(bUserMappingExists + "");

				logProcessManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Exception in isUserMappedWithLog " + e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/validateLogViewName")) {
			JSONObject joRtn = null;
			boolean bexist = false;

			try {
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				String clientLogName = request.getParameter("logName");
				logProcessManager = new LogProcessManager();
				con = DataBaseManager.giveConnection();

				bexist = logProcessManager.validateLogViewName(con, loginUserBean, clientLogName);
				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("isNameExists", bexist);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to validate LogViewName.");

			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/getLogViewLicenseDetails")) {
			JSONObject joRtn = null;

			boolean isLicenseValidForLog = false;
			try {
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				logProcessManager = new LogProcessManager();
				con = DataBaseManager.giveConnection();

				isLicenseValidForLog = logProcessManager.getLogViewLicenseDetails(con, loginUserBean);

				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("islicenseValid", isLicenseValidForLog);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to validate log view license details.");

			} finally {
				DataBaseManager.close(con);
				con = null;

				logProcessManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/saveLogView")) {
			JSONObject joRtn = null;
			JSONObject jaLogTypes = null;
			LogViewBean logViewBean = null;

			loginUserBean = new LoginUserBean();
			logViewBean = new LogViewBean();
			loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
			String userid = new Long(loginUserBean.getUserId()).toString();

			logViewBean.setStrName(request.getParameter("logName"));
			logViewBean.setStrDescription(request.getParameter("logViewDescription").trim());
			logViewBean.setStrLogType(request.getParameter("logType"));
			logViewBean.setElkListId(Integer.parseInt(request.getParameter("logListId")));
			logViewBean.setStrLogPath(request.getParameter("logPath") == null ? "" : request.getParameter("logPath"));

			try {
				con = DataBaseManager.giveConnection();
				logProcessManager = new LogProcessManager();

				jaLogTypes = logProcessManager.saveLogDetails(con, userid, logViewBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaLogTypes);
				DataBaseManager.commitConnection(con);
				logProcessManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to save LogView. ");
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/getUserIpAndPort")) {
			JSONObject joUserIpAndPort = null;
			JSONObject joRtn = null;

			try {
				con = DataBaseManager.giveConnection();
				logProcessManager = new LogProcessManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));

				joUserIpAndPort = logProcessManager.getUserIpAndPort(con, loginUserBean);

				joRtn = UtilsFactory.getJSONSuccessReturn(joUserIpAndPort);

			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Exception in getting User Ips and Ports" + e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/getLogstashIPAndPort")) {
			JSONObject joUserLsIpAndPort = null;
			JSONObject joRtn = null;
			long lLogViewId = -1L;

			try {
				con = DataBaseManager.giveConnection();
				logProcessManager = new LogProcessManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				lLogViewId = Long.parseLong(request.getParameter("logViewId"));

				joUserLsIpAndPort = logProcessManager.getUserLsIpAndPort(con, loginUserBean, lLogViewId);

				joRtn = UtilsFactory.getJSONSuccessReturn(joUserLsIpAndPort);

			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Exception in getting user's logstash IP and port" + e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/log/deleteLogViewRecord")) {
			JSONObject joRtn = null;
			long lLogViewId = -1L;

			try {
				con = DataBaseManager.giveConnection();
				logProcessManager = new LogProcessManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				lLogViewId = Long.parseLong(request.getParameter("logViewId"));

				logProcessManager.deleteLogView(con, lLogViewId, loginUserBean.getUserId());

				joRtn = UtilsFactory.getJSONSuccessReturn("Log View deleted.");

				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Exception while deleting Log View " + e.getMessage());
			} finally {
				DataBaseManager.close(con);
				logProcessManager = null;
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}
