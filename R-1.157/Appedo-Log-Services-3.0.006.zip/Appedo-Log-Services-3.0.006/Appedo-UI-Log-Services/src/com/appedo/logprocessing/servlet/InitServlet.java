package com.appedo.logprocessing.servlet;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appedo.logprocessing.common.Constants;
import com.appedo.logprocessing.connect.DataBaseManager;
import com.appedo.manager.LogManager;
import com.appedo.logprocessing.timer.ELKInstallationTimer;
import com.appedo.logprocessing.model.AppedoMailer;

public class InitServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public static String realPath = null;
	public static TimerTask timerTaskELKInstaller = null;
	public static Timer timerELKInstaller = new Timer();
	public void init() {
		// super();
		
		// declare servlet context
		ServletContext context = getServletContext();
		
		realPath = context.getRealPath("//");
		
		String strConstantsFilePath = null, strLog4jFilePath = null;
		
		try {
			strConstantsFilePath = context.getInitParameter("CONSTANTS_PROPERTIES_FILE_PATH");
			strLog4jFilePath = context.getInitParameter("LOG4J_PROPERTIES_FILE_PATH");
			
			Constants.CONFIG_FILE_PATH = InitServlet.realPath + strConstantsFilePath;
			Constants.LOG4J_PROPERTIES_FILE = InitServlet.realPath + strLog4jFilePath;
			
			// Loads log4j configuration properties
			LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
			
			
			// Loads Constant properties
			Constants.loadConstantsProperties(Constants.CONFIG_FILE_PATH);
			
			// Loads Appedo config properties from the system path
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);

			
			// Loads db config
			DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Loads mail config
			AppedoMailer.loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
			
			Constants.loadELKID();
			
			timerTaskELKInstaller = new ELKInstallationTimer();
			timerELKInstaller.schedule(timerTaskELKInstaller, 150, Constants.ELK_TIMER_INTERVAL);
			
			
		} catch (Throwable th) {
			System.out.println("Exception in InitServlet.init: "+th.getMessage());
			th.printStackTrace();
			
			LogManager.errorLog(th);
		} finally {
			strConstantsFilePath = null;
			strLog4jFilePath = null;
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}

}
