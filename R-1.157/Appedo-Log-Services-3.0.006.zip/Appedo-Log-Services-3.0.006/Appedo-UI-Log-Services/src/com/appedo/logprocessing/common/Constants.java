package com.appedo.logprocessing.common;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import net.sf.json.JSONArray;

import com.appedo.logprocessing.connect.DataBaseManager;
import com.appedo.logprocessing.utils.UtilsFactory;
import com.appedo.manager.LogManager;

/**
 * This class holds the application level variables which required through the application.
 * 
 * @author navin
 *
 */
public class Constants {
	
	

	//public final static String CONFIGFILEPATH = InitServlet.realPath+"/WEB-INF/classes/com/softsmith/floodgates/resource/config.properties";
	public static String CONFIG_FILE_PATH = "";
	
	public static String RESOURCE_PATH = "";
	
	public static String APPEDO_CONFIG_FILE_PATH = "";
	
	public static String EMAIL_TEMPLATES_PATH = "";
	public static String SMTP_MAIL_CONFIG_FILE_PATH = "";
	public static String FROMEMAILADDRESS = "";
	public static String SHELL_FILE_PATH = "";
	public static String PEM_FILE_PATH = "";
	public static String APPEDO_PEM_FILE = "";
	public static String ELK_DOWNLOAD_URI = "";
	public static String ELK_DOWNLOAD_PATH = "";
	
	public static String APPEDO_UI_SLA_SERVICES = "";
	public static String MODULE_UI_SERVICES = "";
	
	public static HashMap<String, String> AGENT_LATEST_BUILD_VERSION = new HashMap<String, String>();
	public static HashMap<Long, String> ELK_ID_VS_NAME = new HashMap<Long, String>();
	//log4j properties file path
	public static String LOG4J_PROPERTIES_FILE = "";
	
	public static String HTTPS_CRT_NAME = null;
	
	public static boolean IS_ELK_THREAD_RUNNING = false;
	public static Map<String,JSONArray> ELK_USER_VS_DATA = new HashMap<String,JSONArray>();
	public static final long ELK_TIMER_INTERVAL = 2*60*1000; //Hardcoded as 2 min
	
	public static String EMAIL_TO_ALERT_FOR_LOG_VIEW = "";
	
	public enum ELK_TYPE {
		ES("Elasticsearch"), LS("Logstash"), KIBANA("Kibana"), NGINX("Nginx");
		
		private String name;
		
		private ELK_TYPE(String strName) {
			name = strName;
		}
		
		public String getVendorName() {
			return name;
		}
	}
	
		
	/**
	 * Loads constants properties 
	 * 
	 * @param srtConstantsPath
	 */
	public static void loadConstantsProperties(String srtConstantsPath) throws Exception {
    	Properties prop = new Properties();
    	InputStream is = null;
    	
        try {
    		is = new FileInputStream(srtConstantsPath);
    		prop.load(is);
    		
     		// Appedo application's resource directory path
     		RESOURCE_PATH = prop.getProperty("RESOURCE_PATH");
     		
     		APPEDO_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("APPEDO_CONFIG_FILE_PATH");

     		// Mail configuration
     		EMAIL_TEMPLATES_PATH = RESOURCE_PATH+prop.getProperty("EMAIL_TEMPLATES_PATH");
     		SMTP_MAIL_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("SMTP_MAIL_CONFIG_FILE_PATH");
     		FROMEMAILADDRESS = prop.getProperty("FromEmailAddress");
     		
     		LOG4J_PROPERTIES_FILE = RESOURCE_PATH+prop.getProperty("LOG4J_CONFIG_FILE_PATH");
    		SHELL_FILE_PATH = RESOURCE_PATH+prop.getProperty("SHELL_FILE_PATH");
    		PEM_FILE_PATH = RESOURCE_PATH+prop.getProperty("PEM_FILE_PATH");
    		ELK_DOWNLOAD_URI =  prop.getProperty("ELK_DOWNLOAD_URI");
     		
        } catch(Throwable th) {
        	System.out.println("Exception in loadConstantsProperties: "+th.getMessage());
			th.printStackTrace();
			LogManager.errorLog(th);
			
        	throw th;
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        }
	}
	
	/**
	 * Loads appedo config properties, from the system specifed path, 
	 * (Note.. loads other than db related)
	 *  
	 * @param strAppedoConfigPath
	 */
	public static void loadAppedoConfigProperties(String strAppedoConfigPath) throws Exception {
    	Properties prop = new Properties();
    	InputStream is = null;
    	
        try {
    		is = new FileInputStream(strAppedoConfigPath);
    		prop.load(is);
    		
     		// User's email address verification mail's URL link starter
     		//APPEDO_URL = prop.getProperty("APPEDO_URL");
     		
     		// Webservice collector
    		
    		// pem file name to execute scripts remotely
    		APPEDO_PEM_FILE = PEM_FILE_PATH+prop.getProperty("PEM_FILE_NAME");
    
    		APPEDO_UI_SLA_SERVICES = prop.getProperty("SLA_UI_SERVICES");
     		MODULE_UI_SERVICES = prop.getProperty("MODULE_UI_SERVICES");
     		
     		HTTPS_CRT_NAME = prop.getProperty("HTTPS_CRT_NAME");
     		ELK_DOWNLOAD_PATH =prop.getProperty("APPEDO_URL")+ELK_DOWNLOAD_URI;
     		
     		EMAIL_TO_ALERT_FOR_LOG_VIEW = prop.getProperty("EMAIL_TO_ALERT_FOR_LOG_VIEW");

        } catch(Exception e) {
        	LogManager.errorLog(e);
        	throw e;
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        }
	}

	public static void loadELKID() throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			con = DataBaseManager.giveConnection();
			sbQuery.append("SELECT * FROM elk_namelist");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				ELK_ID_VS_NAME.put(rst.getLong("elk_name_id"), rst.getString("elk_name"));
			}
			System.out.println("ELK_ID_VS_NAME" + ELK_ID_VS_NAME);
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
			DataBaseManager.close(con);
			con = null;
		}

	}
}
