package com.appedo.logprocessing.utils;

import java.sql.Connection;

import com.appedo.logprocessing.common.Constants;
import com.appedo.manager.LogManager;
import com.appedo.logprocessing.connect.DataBaseManager;
import com.appedo.logprocessing.dbi.LogProcessDBI;

public class CreateELK implements Runnable {

	String ip = null, port = null, args = null, userid = null, name = null, osType = null, osFlavour = null, osUserName = null;
	Long id = 0l;
	Connection con = null;

	public CreateELK(String ip, String port, String args, Long id, String osType, String osFlavour, String osUserName, String userid) {
		this.ip = ip;
		this.port = port;
		this.args = args + " " + userid;
		this.id = id;
		this.osType = osType;
		this.osFlavour = osFlavour;
		this.osUserName = osUserName;
		this.userid = userid;
		this.con = DataBaseManager.giveConnection();
	}

	// TODO: OS name should be fetched from config file / database 
	public void run() {
		StringBuilder sbCmd = new StringBuilder();
		try {
			name = Constants.ELK_ID_VS_NAME.get(id).toLowerCase();
			String exactFName = "install_" + name + ".sh";
			String fname = Constants.SHELL_FILE_PATH + exactFName;
			// scp -i /home/venkatesh/Appedo/keys/APP_DEMO_OREGON.pem /mnt/appedo/resource/elk/install_es.sh centos@54.244.235.69: && ssh  -i /home/venkatesh/Appedo/keys/APP_DEMO_OREGON.pem centos@54.244.235.69 "sh install_es.sh 9208 &"
			// String cmd = "sudo scp -i "+Constants.APPEDO_PEM_FILE+" "+fname+" "+userName+"@"+ip+": && sudo ssh -o \"StrictHostKeyChecking no\" -i "+Constants.APPEDO_PEM_FILE+" "+userName+"@"+ip+" \"sh "+exactFName+" "+args+" &\"";

			sbCmd.append("scp -i ").append(Constants.APPEDO_PEM_FILE).append(" ").append(fname).append(" ").append(osUserName).append("@").append(ip)
				.append(": && ssh -o \"StrictHostKeyChecking no\" -i ").append(Constants.APPEDO_PEM_FILE).append(" ").append(osUserName).append("@").append(ip)
				.append(" \"sh ").append(exactFName).append(" ").append(args).append(" &\"");

			LogManager.infoLog("Going to install using the following command :"+sbCmd);

			int status = ProcessBuilderWrapper.executeCommand(sbCmd.toString(), false);
			
			Thread.sleep(1000 * 60 * 5); // Sleep for 5 minutes
			// Instead of blinding sleeping check for process started or not.
			// Once process started come out of the loop and do an commit
			if (status == 0) {
				// insert the details in database.
				LogProcessDBI dbi = new LogProcessDBI();
				try {
					if (con == null) {
						con = DataBaseManager.reEstablishConnection(con);
					}
					dbi.insertELKIP(con, ip, port, id, osType, osFlavour, osUserName, userid, true);
					DataBaseManager.commitConnection(con);
				} catch (Exception e) {
					LogManager.errorLog("Exception while inserting the ELK IP Details:"+ e);
					DataBaseManager.rollbackConnection(con);
				} finally {
					DataBaseManager.close(con);
					con = null;
				}
			} else {
				LogManager.infoLog("Status in CreateELK:" + status);
			}

		} catch (Exception e) {
			LogManager.errorLog("We need to send a mail when we got an exception here!!!! Exception while creating ELK :"+ e);
			e.printStackTrace();
		} finally {
			UtilsFactory.clearCollectionHieracy(sbCmd);
			sbCmd = null;
			if (Constants.IS_ELK_THREAD_RUNNING == true) {
				Constants.IS_ELK_THREAD_RUNNING = false;
			}
		}
	}
}
