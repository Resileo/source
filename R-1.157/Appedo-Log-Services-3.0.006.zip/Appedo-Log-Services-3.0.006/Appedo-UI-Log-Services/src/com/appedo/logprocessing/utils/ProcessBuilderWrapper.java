package com.appedo.logprocessing.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;

public class ProcessBuilderWrapper {
	public static int executeCommand(String command, boolean waitForResponse) {
		String response = "";
		ProcessBuilder pb = new ProcessBuilder("bash", "-c", command);
		pb.redirectErrorStream(true);
		System.out.println("Linux command: \n" + command);
		int shellExitStatus = -1;
		try {
			Process shell = pb.start();
			if (waitForResponse) {
				// To capture output from the shell
				InputStream shellIn = shell.getInputStream();
				// Wait for the shell to finish and get the return code
				shell.waitFor();
				shellExitStatus = shell.exitValue(); 
				System.out.println("Exit status" + shellExitStatus);
				shellIn.close();
			}else{
				shellExitStatus = 0;
			}
		} catch (Exception e) {
			System.out.println("Error occured while executing Linux command. Error Description: "+ e.getMessage());
		}
		return shellExitStatus;
	}
	
	public static String executeCommandWithStringResult(String command, boolean waitForResponse) {
		String response = "";
		ProcessBuilder pb = new ProcessBuilder("bash", "-c", command);
		pb.redirectErrorStream(true);
		System.out.println("Linux command: " + command);
		int shellExitStatus = -1;
		try {
			Process shell = pb.start();
			if (waitForResponse) {
				// To capture output from the shell
				InputStream shellIn = shell.getInputStream();
				// Wait for the shell to finish and get the return code
				shell.waitFor();
				shellExitStatus = shell.exitValue(); 
				System.out.println("Exit status" + shellExitStatus);
				response = convertStreamToStr(shellIn);
				shellIn.close();
			}else{
				shellExitStatus = 0;
			}
		} catch (Exception e) {
			System.out.println("Error occured while executing Linux command. Error Description: "+ e.getMessage());
		}
		return response;
	}

	public static String convertStreamToStr(InputStream is) throws IOException {
		if (is != null) {
			Writer writer = new StringWriter();
			char[] buffer = new char[1024];
			try {
				Reader reader = new BufferedReader(new InputStreamReader(is,"UTF-8"));
				int n;
				while ((n = reader.read(buffer)) != -1) {
					writer.write(buffer, 0, n);
				}
			} finally {
				is.close();
			}
			return writer.toString();
		} else {
			return "";
		}
	}
}

