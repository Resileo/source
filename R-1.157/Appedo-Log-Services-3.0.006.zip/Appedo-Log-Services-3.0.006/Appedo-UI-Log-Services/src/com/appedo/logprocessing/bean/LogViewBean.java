package com.appedo.logprocessing.bean;

public class LogViewBean {
	private long lLogViewId, lUserId;
	private String strName, strDescription, strLogType, strLogPath;
	private int nElkListId;
	
	public long getlLogViewId() {
		return lLogViewId;
	}
	public void setlLogViewId(long lLogViewId) {
		this.lLogViewId = lLogViewId;
	}
	
	public long getlUserId() {
		return lUserId;
	}
	public void setlUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public String getStrName() {
		return strName;
	}
	public void setStrName(String strName) {
		this.strName = strName;
	}
	
	public String getStrDescription() {
		return strDescription;
	}
	public void setStrDescription(String strDescription) {
		this.strDescription = strDescription;
	}
	
	public String getStrLogType() {
		return strLogType;
	}
	public void setStrLogType(String strLogType) {
		this.strLogType = strLogType;
	}
	
	public String getStrLogPath() {
		return strLogPath;
	}
	public void setStrLogPath(String strLogPath) {
		this.strLogPath = strLogPath;
	}
	
	public int getElkListId() {
		return nElkListId;
	}
	public void setElkListId(int nElkListId) {
		this.nElkListId = nElkListId;
	}

}
