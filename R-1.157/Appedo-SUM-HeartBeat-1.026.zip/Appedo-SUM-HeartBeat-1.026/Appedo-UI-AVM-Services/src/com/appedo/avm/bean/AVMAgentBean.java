package com.appedo.avm.bean;

import net.sf.json.JSONObject;

public class AVMAgentBean {
	
	
	private long lAgentId;
	private long lEnterpriseId;
	private long lUserId;
	private boolean bPrivate = true;
	private String strMACAddress;
	private String strIPAddress;
	private String strCountry;
	private String strState;
	private String strCity;
	private String strRegion;
	private String strZone;
	private Integer nLatitude;
	private Integer nLongitude;
	private String strOSType;
	private String strOperatingSystem;
	private String strOSVersion;
	private String strRemarks;
	private String strAgentVersion;
	private String strStatus;
	private Long lLastRequestedOn;
	private Long lLastReceivedURLCnt;
	private Long lLastRespondedOn;
	private Long lLastErrorOn;
	private long lCreatedBy;
	private long lCreatedOn;
	private Long lModifiedBy;
	private Long lModifiedOn;
	private String strGUID;
	
	private String strLocationText;
	
	
	public long getAgentId() {
		return lAgentId;
	}
	public void setAgentId(long lAgentId) {
		this.lAgentId = lAgentId;
	}
	
	public long getEnterpriseId() {
		return lEnterpriseId;
	}
	public void setEnterpriseId(long lEnterpriseId) {
		this.lEnterpriseId = lEnterpriseId;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public boolean isPrivate() {
		return bPrivate;
	}
	public void setPrivate(boolean bPrivate) {
		this.bPrivate = bPrivate;
	}
	
	public String getMACAddress() {
		return strMACAddress;
	}
	public void setMACAddress(String strMACAddress) {
		this.strMACAddress = strMACAddress;
	}
	
	public String getIPAddress() {
		return strIPAddress;
	}
	public void setIPAddress(String strIPAddress) {
		this.strIPAddress = strIPAddress;
	}
	
	public String getCountry() {
		return strCountry;
	}
	public void setCountry(String strCountry) {
		this.strCountry = strCountry;
	}
	
	public String getState() {
		return strState;
	}
	public void setState(String strState) {
		this.strState = strState;
	}
	
	public String getCity() {
		return strCity;
	}
	public void setCity(String strCity) {
		this.strCity = strCity;
	}
	
	public String getRegion() {
		return strRegion;
	}
	public void setRegion(String strRegion) {
		this.strRegion = strRegion;
	}
	
	public String getZone() {
		return strZone;
	}
	public void setZone(String strZone) {
		this.strZone = strZone;
	}
	
	public Integer getLatitude() {
		return nLatitude;
	}
	public void setLatitude(Integer nLatitude) {
		this.nLatitude = nLatitude;
	}
	
	public Integer getLongitude() {
		return nLongitude;
	}
	public void setLongitude(Integer nLongitude) {
		this.nLongitude = nLongitude;
	}
	
	public String getOSType() {
		return strOSType;
	}
	public void setOSType(String strOSType) {
		this.strOSType = strOSType;
	}
	
	public String getOperatingSystem() {
		return strOperatingSystem;
	}
	public void setOperatingSystem(String strOperatingSystem) {
		this.strOperatingSystem = strOperatingSystem;
	}
	
	public String getOSVersion() {
		return strOSVersion;
	}
	public void setOSVersion(String strOSVersion) {
		this.strOSVersion = strOSVersion;
	}
	
	public String getRemarks() {
		return strRemarks;
	}
	public void setRemarks(String strRemarks) {
		this.strRemarks = strRemarks;
	}
	
	public String getAgentVersion() {
		return strAgentVersion;
	}
	public void setAgentVersion(String strAgentVersion) {
		this.strAgentVersion = strAgentVersion;
	}
	
	public String getStatus() {
		return strStatus;
	}
	public void setStatus(String strStatus) {
		this.strStatus = strStatus;
	}
	
	public Long getLastRequestedOn() {
		return lLastRequestedOn;
	}
	public void setLastRequestedOn(Long lLastRequestedOn) {
		this.lLastRequestedOn = lLastRequestedOn;
	}
	
	public Long getLastReceivedURLCnt() {
		return lLastReceivedURLCnt;
	}
	public void setLastReceivedURLCnt(Long lLastReceivedURLCnt) {
		this.lLastReceivedURLCnt = lLastReceivedURLCnt;
	}
	
	public Long getLastRespondedOn() {
		return lLastRespondedOn;
	}
	public void setLastRespondedOn(Long lLastRespondedOn) {
		this.lLastRespondedOn = lLastRespondedOn;
	}
	
	public Long getLastErrorOn() {
		return lLastErrorOn;
	}
	public void setLastErrorOn(Long lLastErrorOn) {
		this.lLastErrorOn = lLastErrorOn;
	}
	
	public long getCreatedBy() {
		return lCreatedBy;
	}
	public void setCreatedBy(long lCreatedBy) {
		this.lCreatedBy = lCreatedBy;
	}
	
	public long getCreatedOn() {
		return lCreatedOn;
	}
	public void setCreatedOn(long lCreatedOn) {
		this.lCreatedOn = lCreatedOn;
	}
	
	public Long getModifiedBy() {
		return lModifiedBy;
	}
	public void setModifiedBy(Long lModifiedBy) {
		this.lModifiedBy = lModifiedBy;
	}
	
	public Long getModifiedOn() {
		return lModifiedOn;
	}
	public void setModifiedOn(Long lModifiedOn) {
		this.lModifiedOn = lModifiedOn;
	}

	public String getGUID() {
		return strGUID;
	}
	public void setGUID(String strGUID) {
		this.strGUID = strGUID;
	}
	
	public String getLocationText() {
		return strLocationText;
	}
	public void setLocationText(String strLocationText) {
		this.strLocationText = strLocationText;
	}
	
	
	public JSONObject toJSON() {
		JSONObject joAgentLocation = new JSONObject();

		joAgentLocation.put("agentId", lAgentId);
		joAgentLocation.put("isPrivate", bPrivate);
		joAgentLocation.put("macAddress", strMACAddress);
		joAgentLocation.put("ipAddress", strIPAddress);
		joAgentLocation.put("country", strCountry);
		joAgentLocation.put("state", strState);
		joAgentLocation.put("city", strCity);
		joAgentLocation.put("region", strRegion);
		joAgentLocation.put("zone", strZone);
		joAgentLocation.put("locationText", strLocationText);
		joAgentLocation.put("latitude", nLatitude);
		joAgentLocation.put("longitude", nLongitude);
		joAgentLocation.put("osType", strOSType);
		joAgentLocation.put("operatingSystem", strOperatingSystem);
		joAgentLocation.put("osVersion", strOSVersion);
		joAgentLocation.put("status", strStatus);
		joAgentLocation.put("lastRequestedOn", lLastRequestedOn);
		joAgentLocation.put("lastReceivedUrlCnt", lLastReceivedURLCnt);
		joAgentLocation.put("lastRespondedOn", lLastRespondedOn);
		joAgentLocation.put("lastErrorOn", lLastErrorOn);
		joAgentLocation.put("guid", strGUID);
		
		return joAgentLocation;
	}
	
	
	public static void main(String[] args) {
		
		AVMAgentBean agentBean = null;
		
		try {
			agentBean = new AVMAgentBean();

			System.out.println("getUserId: "+agentBean.getUserId());
			System.out.println("getMACAddress: "+agentBean.getMACAddress());
			
			System.out.println("agentBean.getLatitude() == null: "+(agentBean.getLatitude() == null));
			System.out.println("agentBean.getLastRequestedOn() == null: "+(agentBean.getLastRequestedOn() == null));
			
			System.out.println("getLatitude: "+agentBean.getLatitude());
			System.out.println("getLastRequestedOn: "+agentBean.getLastRequestedOn());
			
			agentBean = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
