package com.appedo.avm.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appedo.avm.common.Constants;
import com.appedo.avm.connect.DataBaseManager;
import com.appedo.avm.model.AppedoMailer;
import com.appedo.manager.LogManager;

public class InitServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public static String realPath = null;
	
	public void init() {
		// super();
		
		// declare servlet context
		ServletContext context = getServletContext();
		
		realPath = context.getRealPath("//");
		
		String strConstantsFilePath = null, strLog4jFilePath = null;
		
		try {
			strConstantsFilePath = context.getInitParameter("CONSTANTS_PROPERTIES_FILE_PATH");
			strLog4jFilePath = context.getInitParameter("LOG4J_PROPERTIES_FILE_PATH");
			
			Constants.CONFIG_FILE_PATH = InitServlet.realPath + strConstantsFilePath;
			Constants.LOG4J_PROPERTIES_FILE = InitServlet.realPath + strLog4jFilePath;
			
			// Loads log4j configuration properties
			LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
			
			
			// Loads Constant properties
			Constants.loadConstantsProperties(Constants.CONFIG_FILE_PATH);
			
			// Loads Appedo config properties from the system path
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Loads db config
			DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);

			// Loads mail config
			AppedoMailer.loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
			
			// loads appedo constants; say loads appedoWhiteLabels, 
			Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
			
		} catch (Throwable th) {
			System.out.println("Exception in InitServlet.init: "+th.getMessage());
			th.printStackTrace();
			
			LogManager.errorLog(th);
		} finally {
			strConstantsFilePath = null;
			strLog4jFilePath = null;
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}

}
