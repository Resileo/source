package com.appedo.avm.model;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.amazonaws.services.simpleemail.AWSJavaMailTransport;
import com.appedo.avm.common.Constants;
import com.appedo.avm.utils.UtilsFactory;
import com.appedo.manager.AppedoConstants;
import com.appedo.manager.LogManager;
import com.sendwithus.SendWithUs;
import com.sendwithus.SendWithUsSendRequest;
import com.sendwithus.model.SendReceipt;

/**
 * Class which sends email using the standard JavaMail API for Amazon Simple Email Service or normal SMTP method.
 * For Amazon Simple Email Service:
 * <p>
 * <b>Prerequisites:</b> You must have a valid Amazon Web Services developer
 * account, and be signed up to use Amazon Simple Email Service. For more information
 * on Amazon Simple Email Service, see http://aws.amazon.com/ses .
 * <p>
 * <b>Important:</b> Be sure to fill in your AWS access credentials in the
 * AwsCredentials.properties file before you try to run this sample.
 * http://aws.amazon.com/security-credentials
 * 
 * Abbrevation:
 *   - SWU = SendWithUs
 */
public class AppedoMailer extends Thread {
	
	/*
	 * Important: Be sure to fill in an email address you have access to
	 *            so that you can receive the initial confirmation email
	 *            from Amazon Simple Email Service.
	 *
	private static AppedoMailer instance_ = new AppedoMailer();
	*/
	
	//public static String SMTP_MAIL_PROPERTIES_PATH = "SmtpCredentials.properties"; 
	
	boolean mailStatus = false;
	private static String strMailingOption = "";
	private static String smtp_server_ip = "";
	private static String smtp_port_number = "";
	private static String smtp_auth_user = "";
	// private static String smtp_host_name = "";
	private static String smtp_auth_pwd = "";
	private static String smtp_bounce_forwardto = "";
	private static boolean is_ssl_supported;
	
	private static Properties mailProps = null;
	boolean changed = false;
	
	// SendWithUs properties
	private static String SWU_API_KEY = null;
	private static String SWU_SENDER_NAME = null, SWU_SENDER_EMAILID = null, SWU_REPLY_TO = null, SWU_ESP_ACCOUNT = null;
	private static Map<String, Object> senderMap = new HashMap<String, Object>();
	
	
	// Private members, to be used for sending mail
	private StringBuilder sbBody = new StringBuilder();
	private boolean bMailSent = false;
	
	private Session session = null;
	private String[] recipients = null;
	
	// Declare SendWithUs Objects
	private SendWithUs sendwithusAPI = null;
	
	private MODULE_ID moduleId;
	private HashMap<String, Object> hmEmailMapData = null;
	private String subject = null;
	
	/**
	 * Get the object instance, which is created already.
	 * 
	 * @return
	 *
	private static AppedoMailer getInstance() {
		return instance_;
	}
	
	/**
	 * Enum class used to identify the module/operation for which mail subject will be formatted.
	 * 
	 * @author Ramkumar R
	 *
	 */
	public static enum MODULE_ID {
		VERIFY_USER_EMAIL("tem_sH4gPiSGuGcamc8nGXpPBV"), PASSWORD_RESET("tem_eFVK5SeXWD8MF77VMArD6J"), 
		VERIFY_SUM_NODE_REG_EMAIL(""), DOWNLOAD_SUM_AGENT("tem_BgfKvc3XQGHUPKh2Mtx9CH"), 
		PRIVELEGES_EMAIL("tem_peuwTjtENbdxfL4JvbvYVQ"), 
		INVITE_USERS_EMAIL("tem_r84TLWMFhbmnU2hjXmXgzf"), ENTERPRISE_EMAIL("tem_AHAmtre6AedeGGSADUL5Tc"),
		SLA_VERIFY_EMAIL("tem_EADyWAD4yaAxZ5YjHXY4oF"), SLA_ALERT_EMAIL("tem_tC6Xhvz98yeJvhzTkSbH2n");
		
		private String SWU_TEMPLATE_ID;
		
		private MODULE_ID(String SWU_TEMPLATE_ID) {
			this.SWU_TEMPLATE_ID = SWU_TEMPLATE_ID;
		}
		
		public String getSWUTemplateId() {
			return SWU_TEMPLATE_ID;
		}
	}
	
	/**
	 * Loads SMTP, AWS and SendWithUs mail configuration properties
	 * 
	 * @param strFilePath
	 * @return
	 * @throws Exception
	 */
	public static boolean loadPropertyFileConstants(String strFilePath) throws Exception {
		Properties prop = new Properties();
		
		try {
			mailProps = new Properties();
			
			InputStream is = new FileInputStream(strFilePath);
			prop.load(is);
			
			strMailingOption = prop.getProperty("mailing_system");
			
			if( strMailingOption.equalsIgnoreCase("SENDWITHUS") ) {
				SWU_API_KEY = prop.getProperty("SWU_API_KEY");
				SWU_SENDER_NAME = prop.getProperty("SWU_SENDER_NAME");
				SWU_SENDER_EMAILID = prop.getProperty("SWU_SENDER_EMAILID");
				SWU_REPLY_TO = prop.getProperty("SWU_REPLY_TO");
				SWU_ESP_ACCOUNT = prop.getProperty("SWU_ESP_ACCOUNT");
				
				// set sender details in Bean
				senderMap.put("name", SWU_SENDER_NAME);
				senderMap.put("address", SWU_SENDER_EMAILID);
				senderMap.put("reply_to", SWU_REPLY_TO);
			} else if( strMailingOption.equalsIgnoreCase("smtp") ) {
				smtp_server_ip = prop.getProperty("Smtpserver");
				smtp_port_number = prop.getProperty("portnumber");
				smtp_auth_user = prop.getProperty("smtpuserid");
				//this.smtp_host_name = prop.getProperty("DRIVER");
				smtp_auth_pwd = prop.getProperty("smtppassword");
				smtp_bounce_forwardto = prop.getProperty("smtp_bounce_forwardto");
				is_ssl_supported = Boolean.parseBoolean( prop.getProperty("is_ssl_supported") );
				
				mailProps.setProperty("mail.transport.protocol", "smtp");
				mailProps.setProperty("mail.smtp.port", smtp_port_number);
				mailProps.setProperty("mail.smtp.host", smtp_server_ip);
				mailProps.setProperty("mail.smtp.auth", "true");
				mailProps.setProperty("mail.smtp.from", smtp_bounce_forwardto);
				
				if( is_ssl_supported ){
					mailProps.setProperty("mail.smtp.starttls.enable", "true");
					mailProps.setProperty("mail.smtp.socketFactory.port", smtp_port_number);
					mailProps.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
					mailProps.setProperty("mail.smtp.socketFactory.fallback", "false");
				}
			}
			// TODO: Load AWS mail Properties, if mail send send through AWS 
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return true;
	}
	
	/**
	 * Send mail via configured SMTP/AWS/SendWithUs
	 * Start the Thread operation for the sending process, as it takes around 3 seconds.
	 * 
	 * @param moduleId
	 * @param hmEmailMapData
	 * @param from
	 * @param toAddress
	 * @param subject
	 * @return
	 * @throws Exception
	 */
	public boolean sendMail(MODULE_ID moduleId, HashMap<String, Object> hmEmailMapData, String[] toAddress, String subject) throws Exception {
		this.moduleId = moduleId;
		this.subject = subject;
		this.recipients = UtilsFactory.cleanArray(toAddress);
		
		if( recipients == null || recipients.length == 0 ) {
			throw new Exception("Recipient list is empty. Please add pass atlease one Email-Id.");
		}
		
		// HashMap data is copied, as HashMap loses its reference in local variable, after this function's scope
		this.hmEmailMapData = new HashMap(hmEmailMapData);
		
		// Add appedo-white-labels in email properties
		AppedoConstants.addAppedoWhitelabelsEmailReplacements(this.hmEmailMapData);
		

		// since if an exception occurred while sending, has to handle to show user, commented `this.start();` Thread mode operation
		// Sending a Email will take more time. So do the operation in a separate Thread mode.
		//this.start();
		this.run();
		
		// thinks, since mail send through thread avoided, would return, need to handle if mail isSent through Thread mode.
		return bMailSent;
	}
	
	/**
	 * Thread operation for the sending Email, as it takes around 3 seconds.
	 */
	public void run() {
		
		try{
			if( strMailingOption.equalsIgnoreCase("SENDWITHUS") ){
				sendwithusAPI = new SendWithUs(SWU_API_KEY);

				sendThroughSendWithUs(sendwithusAPI);
			} else if( strMailingOption.equalsIgnoreCase("smtp") ){
				Authenticator auth = new SMTPAuthenticator(smtp_auth_user, smtp_auth_pwd);
			    session = Session.getInstance(mailProps, auth);
				
			    sbBody = replaceMailVariables(moduleId, hmEmailMapData);
			    sendSMTPMail(session, recipients, subject, sbBody);
	        }else if( strMailingOption.equalsIgnoreCase("aws") ){
				session = Session.getInstance(mailProps);
				
				sbBody = replaceMailVariables(moduleId, hmEmailMapData);
				sendSMTPMail(session, recipients, subject, sbBody);
	        }
		} catch (Throwable th) {
			LogManager.errorLog(th);
		}
	}
	
	/**
	 * Replace the mail Variables (i.e. static String) with the value given in the map.
	 * 
	 * @param moduleId
	 * @param map
	 * @return
	 * @throws Throwable
	 */
	private StringBuilder replaceMailVariables(MODULE_ID moduleId, HashMap<String, Object> map) throws Throwable {
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		String strPath = "", line = null;
		StringBuilder sbBody = new StringBuilder();
		
		try {
			if( moduleId == MODULE_ID.SLA_ALERT_EMAIL ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/SLA_ALERT_EMAIL.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@BODY@", map.get("BODY").toString());
					sbBody.append(line);
				}
			} else if( moduleId == MODULE_ID.SLA_VERIFY_EMAIL ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/SLA_MODULE_EMAIL.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@LINK@", map.get("LINK").toString());
					sbBody.append(line);
				}
			} else if( moduleId == MODULE_ID.VERIFY_USER_EMAIL ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/SIGNUP_VERIFY_EMAIL.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@LINK@",map.get("LINK").toString());
					sbBody.append(line);
				}
			}else if( moduleId == MODULE_ID.PASSWORD_RESET ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/PASSWORD_RESET.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@LINK@",map.get("LINK").toString());
					sbBody.append(line);
				}
			} else if( moduleId == MODULE_ID.VERIFY_SUM_NODE_REG_EMAIL ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/VERIFY_SUM_NODE_REG_EMAIL.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@LINK@",map.get("LINK").toString());
					sbBody.append(line);
				}
			} else if( moduleId == MODULE_ID.DOWNLOAD_SUM_AGENT ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/DOWNLOAD_SUM_AGENT.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@VERSION@",map.get("VERSION").toString());
					line = line.replaceAll("@LINK@",map.get("LINK").toString());
					sbBody.append(line);
				}
			}else if( moduleId == MODULE_ID.INVITE_USERS_EMAIL ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/INVITE_USERS_EMAIL.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@ENTERPRISE@",map.get("ENTERPRISENAME").toString());
					line = line.replaceAll("@LINK@",map.get("LINK").toString());
					sbBody.append(line);
				}
			}else if( moduleId == MODULE_ID.ENTERPRISE_EMAIL ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/ENTERPRISE_EMAIL.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@ENTERPRISE@",map.get("ENTERPRISENAME").toString());
					sbBody.append(line);
				}
			}else if( moduleId == MODULE_ID.PRIVELEGES_EMAIL ){
				strPath = Constants.EMAIL_TEMPLATES_PATH+"/PRIVELEGES_EMAIL.htm";
				fileReader = new FileReader(strPath);
				bufferedReader = new BufferedReader(fileReader);
				while ((line = bufferedReader.readLine()) != null) {
					line = line.replaceAll("@USERNAME@",map.get("USERNAME").toString());
					line = line.replaceAll("@PRIVELEGES@",map.get("PRIVILEGES").toString());
					sbBody.append(line);
				}
			}
		} finally {
			UtilsFactory.close(bufferedReader);
			bufferedReader = null;
			UtilsFactory.close(fileReader);
			fileReader = null;
		}
		
		return sbBody;
	}
	
	/**
	 * Send the mail through SMTP or AWS (if AWS is configured)
	 * 
	 * @param session
	 * @param recipients
	 * @param subject
	 * @param sbBody
	 * @throws Throwable
	 */
	private void sendSMTPMail(Session session, String[] recipients, String subject, StringBuilder sbBody) throws Throwable {
		int nTotalRecipient = recipients.length;
		
		// create a message
		Message msg = new MimeMessage(session);
		msg.addFrom(InternetAddress.parse(smtp_auth_user));
		
		// set the from and to address
		InternetAddress addressFrom = new InternetAddress(smtp_auth_user);
		
		msg.setFrom(addressFrom);
		//msg.setReplyTo(new InternetAddress[]{addressFrom});
		
		InternetAddress[] addressTo = new InternetAddress[nTotalRecipient];

		/* AWS Verfication for test purpose.
		AmazonSimpleEmailService email = new AmazonSimpleEmailServiceClient(credentials);		
        ListVerifiedEmailAddressesResult verifiedEmails = email.listVerifiedEmailAddresses();
        */
		
		for (int i = 0; i < nTotalRecipient; i++) {
			/* AWS Verfication for test purpose.
            if (!verifiedEmails.getVerifiedEmailAddresses().contains(recipients[i])) {
                email.verifyEmailAddress(new VerifyEmailAddressRequest().withEmailAddress(recipients[i]));
            } */
			addressTo[i] = new InternetAddress(recipients[i]);
		}
		//msg.setRecipients(Message.RecipientType.TO, addressTo);
		
		
		Multipart multipart = new MimeMultipart();
		
		MimeBodyPart messagePart = new MimeBodyPart();
		//messagePart.setText("hi");
		messagePart.setContent(sbBody.toString(), "text/html");
		
		multipart.addBodyPart(messagePart);
		
		
		msg.setSentDate(Calendar.getInstance().getTime());
		
		msg.setContent( multipart );
		
		msg.addRecipients(Message.RecipientType.TO, addressTo);
		
		msg.setSubject(subject);
		msg.saveChanges();
		
		if( strMailingOption.equalsIgnoreCase("smtp") ){
			Transport.send(msg);
		} else if( strMailingOption.equalsIgnoreCase("aws") ){
			// To send mail using AWS credentials
			
			// Reuse one Transport object for sending all your messages
			// for better performance
			Transport t = null;
			try {
				t = new AWSJavaMailTransport(session, null);
				t.connect();
				t.sendMessage(msg, null);
			} catch(Exception e) {
				//map.put("exception", e.getMessage());
				LogManager.errorLog(e);
				throw e;
			} finally {
				// Close your transport when you're completely done sending
				// all your messages
				try{
					t.close();
				}catch(Exception e){
					LogManager.errorLog(e);
				}
			}
		}
		// thinks consider as mail, else exception is throws
		this.bMailSent = true;

		// clearing local variables 
		recipients = null;
		UtilsFactory.clearCollectionHieracy(sbBody);
	}
	
	/**
	 * Send the mail through SendWithUs.
	 * 
	 * @param sendwithusAPI
	 */
	private void sendThroughSendWithUs(SendWithUs sendwithusAPI) {
		Map<String, Object> recipientMap = new HashMap<String, Object>();
		Map[] ccRecipients = null;
		
		// Add the first email-id as TO user; others will be in CC list.
		recipientMap.put("address", recipients[0]);
		
		// Other than the first recipient all other email-ids should be in CC list.
		if( recipients.length > 1 ) {
			ccRecipients = new HashMap[recipients.length-1];
			
			for(int i=0; i<recipients.length-2; i++) {
				ccRecipients[i] = new HashMap<String, Object>();
				ccRecipients[i].put("address", recipients[i]);
			}
		}
		
		try {
			/* Sending the email using the legacy send() java API
			SendReceipt sendReceipt = sendwithusAPI.send(
			    EMAIL_ID_WELCOME_EMAIL,
			    recipientMap,
			    senderMap,
			    emailDataMap,
			    null,
			    null
			    //, attachments
			); */
			
			// Sending the same email using the new SendWithUsSendRequest class
			SendWithUsSendRequest request = new SendWithUsSendRequest()
			    .setEmailId(moduleId.getSWUTemplateId())
			    .setRecipient(recipientMap)
			    .setCcRecipients(ccRecipients)
			    .setSender(senderMap)
			    .setEmailData(hmEmailMapData)
			    .setEspAccount(SWU_ESP_ACCOUNT)
			    //.setAttachmentPaths(attachments)
			    ;

			SendReceipt sendReceipt = sendwithusAPI.send(request);
			this.bMailSent = sendReceipt.getSuccess();
		} catch (Throwable th) {
			LogManager.errorLog(th);
		}
	}
	
	/**
	 * SimpleAuthenticator is used to do simple authentication when the SMTP
	 * server requires it.
	 */
	private class SMTPAuthenticator extends Authenticator {

		private PasswordAuthentication authentication;

		/**
		 * Initialize PasswordAuthentication
		 * 
		 * @param login
		 * @param password
		 */
		public SMTPAuthenticator(String login, String password)
		{
			authentication = new PasswordAuthentication(login, password);
		}
		
		/**
		 * Return PasswordAuthentication
		 */
		public PasswordAuthentication getPasswordAuthentication() {
			return authentication;
		}
	}
}
