package com.appedo.sum.heartbeat.monitor.manager;

import java.util.ArrayList;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;

import com.appedo.sum.heartbeat.monitor.bean.HeartBeatResponseBean;
import com.appedo.sum.heartbeat.monitor.utils.Constants;

/**
 * Manager to do common activities for any agent.
 * Activities such as send first request, send counter values are defined here.
 * 
 * @author Ramkumar
 *
 */
public class AgentManager {
	
	private static HttpClient client = new HttpClient();
	
	private static boolean bFirstRequest = true;
	
	public static boolean validateAgentLocation() {
		String[] sa = null;
		
		if( Constants.AGENT_LOCATION == null || Constants.AGENT_LOCATION.length() == 0 || Constants.AGENT_LOCATION.equalsIgnoreCase("@LOCATION@") || Constants.AGENT_LOCATION.equalsIgnoreCase("LOCATION") ) {
			System.out.println("Location is invalid. Give proper location in the requested format.");
			return false;
		}
		
		// Split and 
		sa = Constants.AGENT_LOCATION.split("#", -1);
		
		if( sa.length != 5 ) {
			System.out.println("Location is invalid. Give proper location in the requested format.");
			return false;
		}
		
		sa[0] = sa[0].trim();
		sa[1] = sa[1].trim();
		sa[2] = sa[2].trim();
		sa[3] = sa[3].trim();
		sa[4] = sa[4].trim();
		
		Constants.AGENT_LOCATION = sa[0]+"#"+sa[1]+"#"+sa[2]+"#"+sa[3]+"#"+sa[4];
		
		
		if( sa[0] == null || sa[0].length() == 0 || sa[0].equalsIgnoreCase("country") ) {
			System.out.println("Country in given location is blank/invalid. It is mandatory.");
			return false;
		}
		if( sa[1].equalsIgnoreCase("state") ) {
			System.out.println("State in given location is not valid. It is optional. So you leave it");
			return false;
		}
		if( sa[2] == null || sa[2].length() == 0 || sa[0].equalsIgnoreCase("city") ) {
			System.out.println("City in given location is blank/invalid. It is mandatory.");
			return false;
		}
		if( sa[3].equalsIgnoreCase("region") ) {
			System.out.println("Region in given location is not valid. It is optional. So you leave it");
			return false;
		}
		if( sa[4].equalsIgnoreCase("zone") ) {
			System.out.println("Zone in given location is not valid. It is optional. So you leave it");
			return false;
		}
		
		return true;
	}
	/**
	 * 
	 * @param strAgentGUID
	 * @throws Throwable
	 */
	public static Object[] getConfigurationsFromCollector() throws Throwable {
		boolean bReturn =false;
		
		PostMethod method = null;
		
		int statusCode = 0;
		
		String responseStream = null;		
		
		try{
			method = new PostMethod(Constants.WEBSERVICE_URL+"/getHeartBeatURLs");
			method.setRequestHeader("Connection", "close");
			method.addParameter("user_id", Constants.ENCRYPTED_USER_ID);
			method.addParameter("guid", Constants.GUID);
			method.addParameter("location", Constants.AGENT_LOCATION);
			method.addParameter("mac_address", Constants.MACHNE_MAC_ADDRESS);
			// Indicate first time agent start
			if( bFirstRequest ) {
				method.addParameter("first_request", "true");
			}
			
			do {
				statusCode = client.executeMethod(method);
				
				if (statusCode != HttpStatus.SC_OK) {
					System.out.println("Method failed: " + method.getStatusLine());
					
					bReturn = false;
				} else {
					responseStream = method.getResponseBodyAsString();
					
					// reset, to indicate that hereafter, it is not first time request.
					bFirstRequest = false;
					
					bReturn = true;
				}
				
				// wait for proper response from Server
				if( ! bReturn ) {
					Thread.sleep(Constants.ONE_MINUTE_MILLISECONDS);
				}
			} while( ! bReturn );
			
		} catch(Throwable e) {
			e.printStackTrace();
			System.out.println("Exception in getConfigurationsFromCollector: "+e.getMessage());
		} finally {
			method.releaseConnection();
			method = null;
		}
		
		return new Object[]{statusCode, responseStream};
	}
	
	/**
	 * send the counter-sets available in the ArrayList to the configured WebService.
	 * 
	 * @param agent_type
	 * @return
	 */
	public static boolean sendHeartBeatResults(ArrayList<HeartBeatResponseBean> alHeartBeatResponseBeans) {
		boolean bReturn =false;
		
		PostMethod method = null;
		
		try{
			method = new PostMethod(Constants.WEBSERVICE_URL+"/collectHeartBeatResult");
			method.setRequestHeader("Connection", "close");
			method.addParameter("user_id", Constants.ENCRYPTED_USER_ID);
			method.addParameter("guid", Constants.GUID);
			method.addParameter("location", Constants.AGENT_LOCATION);
			method.addParameter("mac_address", Constants.MACHNE_MAC_ADDRESS);
			method.addParameter("heartbeat_results", alHeartBeatResponseBeans.toString());
			
			int statusCode = client.executeMethod(method);
			System.out.println("Sender statusCode: "+statusCode);
			
			if (statusCode != HttpStatus.SC_OK) {
				System.out.println("Method failed: " + method.getStatusLine());
			}
		} catch (Throwable th) {
			System.err.println("Unknown Exception in sendCounterToCollector: " + th);
			th.printStackTrace();
		} finally {
			method.releaseConnection();
			method = null;
		}
		
		return bReturn;
	}
	
	/**
	 * Run System.gc() for each configured period.
	 */
	public static void runGarbageCollectionRountine() {
		try{
			// Call garbage collection in a separate routine
			new Thread(
				new Runnable() {
					/**
					 * Call for System.gc()
					 */
					public void run() {
						while(true){
							try {
								Thread.sleep(Constants.FIVE_MINUTE_MILLISECONDS);
							} catch (InterruptedException e) {
								System.out.println("Exception in runGarbageCollectionRountine(): "+e.getLocalizedMessage());
							}
							
							System.gc();
							System.out.println("SUM HeartBeat Monitor called System.GC");
						}
					}
				}
			).start();
		} catch(Throwable e) {
			System.out.println("Exception in runGarbageCollectionRountine: "+e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Override
	protected void finalize() throws Throwable {
		
		super.finalize();
	}
}
