package com.appedo.sum.heartbeat.monitor.utils;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.Properties;
import java.util.UUID;

/**
 * This class holds the application level variables which required through the application.
 * 
 * @author Ramkumar R
 * 
 */
public class Constants {

	public static String THIS_JAR_HOMEPATH = "";
	public static String THIS_AGENT_VERSION = null;
	
	public static String OS ;
	public static String OS_VERSION ;
	public static String MACHNE_MAC_ADDRESS ;
	
	static {
		// Retrieve Appedo SUM HeartBeat Monitor filepath
		File jarPath = new File(Constants.class.getProtectionDomain().getCodeSource().getLocation().getPath());
		THIS_JAR_HOMEPATH = jarPath.getParentFile().getAbsolutePath();
		
		getThisAgentVersion();
		
		OS = System.getProperty("os.name").toLowerCase();
		OS_VERSION = System.getProperty("os.version").toLowerCase();
	}
	
	public static String WEBSERVICE_URL = "";
	public static String ENCRYPTED_USER_ID = "";
	public static String GUID = "";
	public static String AGENT_LOCATION = "";
	public static int TIMEOUT_IN_MILLISECONDS = 7000;
	
	public static int TEST_PER_MINUTE_IN_AGENT = 500;
	
	public static int ONE_MINUTE_MILLISECONDS = 1*60*1000;
	public static int FIVE_MINUTE_MILLISECONDS = 5*60*1000;
	
	public static int THREADPOOL_MIN_THREADS = 2;
	public static int THREADPOOL_MAX_THREADS = 10;
	public static int THREADPOOL_THREADS_ALIVE_TIME_MINUTES = 4;
	public static int THREADPOOL_QUEUE_THREADS = 100;
	
	
	public enum CURL_CONSTANTS {
		HEAD_REQ("HEAD_REQ"), GET_REQ("GET_REQ"), 
		HTTP_VERSION_PREFIX("HTTP/"), HTTP_FINAL_RESP_CODE("HTTP_FINAL_RESP_CODE"), HTTP_RESULT_TOTAL_TIME("HTTP_RESULT_TOTAL_TIME"), CURL("CURL");
		
		private String strSLABreachSeverity;
		
		private CURL_CONSTANTS(String sSLABreachSeverity) {
			strSLABreachSeverity = sSLABreachSeverity;
		}
		
		public String toString() {
			return strSLABreachSeverity;
		}
	}
	
	public static void loadConstants() throws Throwable {
		
		// Get Machine MAC Address, depending upon OS
		if(Constants.OS.indexOf("nix") >= 0 || Constants.OS.indexOf("nux") >= 0 || Constants.OS.indexOf("aix") > 0)
			MACHNE_MAC_ADDRESS = UtilsFactory.getLinuxMacAddress();
		else if(Constants.OS.indexOf("win") >= 0)
			MACHNE_MAC_ADDRESS = UtilsFactory.getWinMacAddress();
	}
	
	/**
	 * Loads constants properties 
	 * 
	 * @param srtConstantsPath
	 */
	public static void loadConstantsProperties(String srtConstantsPath) throws Exception {
		Properties prop = new Properties();
		InputStream is = null;
		
		try {
			is = new FileInputStream(srtConstantsPath);
			prop.load(is);
			
			WEBSERVICE_URL = prop.getProperty("COLLECTOR_URL");
			ENCRYPTED_USER_ID = prop.getProperty("USER_ID");	// To indicate that this agent is Private for this User-Id. Optional
			GUID = prop.getProperty("GUID");
			AGENT_LOCATION = prop.getProperty("AGENT_LOCATION");
			
			if( prop.containsKey("TIMEOUT_IN_MILLISECONDS") ) {
				TIMEOUT_IN_MILLISECONDS = Integer.parseInt( prop.getProperty("TIMEOUT_IN_MILLISECONDS") );
			}
			
			// Load ThreadPool properties if given, or else use the defaults.
			if( prop.containsKey("THREADPOOL_MIN_THREADS") ) {
				THREADPOOL_MIN_THREADS = Integer.parseInt( prop.getProperty("THREADPOOL_MIN_THREADS") );
			}
			if( prop.containsKey("THREADPOOL_MAX_THREADS") ) {
				THREADPOOL_MAX_THREADS = Integer.parseInt( prop.getProperty("THREADPOOL_MAX_THREADS") );
			}
			if( prop.containsKey("THREADPOOL_THREADS_ALIVE_TIME_MINUTES") ) {
				THREADPOOL_THREADS_ALIVE_TIME_MINUTES = Integer.parseInt( prop.getProperty("THREADPOOL_THREADS_ALIVE_TIME_MINUTES") );
			}
			if( prop.containsKey("THREADPOOL_QUEUE_THREADS") ) {
				THREADPOOL_QUEUE_THREADS = Integer.parseInt( prop.getProperty("THREADPOOL_QUEUE_THREADS") );
			}
		} catch(Throwable th) {
			System.out.println("Exception in loadConstantsProperties: "+th.getMessage());
			th.printStackTrace();
			
			throw th;
		} finally {
			UtilsFactory.close(is);
			is = null;
		}
	}
	
	private static void getThisAgentVersion() {
		Package aPackage = Constants.class.getPackage();
		THIS_AGENT_VERSION = aPackage.getSpecificationVersion()+ "-" +aPackage.getImplementationVersion();
	}
	
	public static void fillBlankGUID(String srtConstantsPath) {
		FileReader fr = null;
		BufferedReader br = null;
		String strLine = null;
		StringBuilder sb = new StringBuilder();
		
		FileWriter fw = null;
		BufferedWriter bw = null;
		
		boolean bGUIDRowNotPresent = false;
		
		if( GUID != null && ! GUID.equals("@GUID@") && GUID.length() > 0 ) {
			return ;
		}
		
		// if property is there then, need to add new line.
		if( GUID == null ) {
			bGUIDRowNotPresent = true;
		}
		
		GUID = UUID.randomUUID().toString();
		System.out.println("New GUID is assigned: "+GUID);
		
		// write the GUID in the file
		try{
			fr = new FileReader(srtConstantsPath);
			br = new BufferedReader(fr);
			
			while( (strLine = br.readLine()) != null ) {
				
				if( ! bGUIDRowNotPresent && strLine.replaceAll(" ", "").replaceAll("\t", "").startsWith("GUID=") ) {
					strLine = "GUID="+GUID;
				}
				
				sb.append(strLine).append("\r\n");
			}
			
			if( bGUIDRowNotPresent ) {
				sb.append("\r\nGUID="+GUID).append("\r\n");
			}
		} catch(Throwable th) {
			System.out.println("Exception in reading config.properties: "+th.getMessage());
			th.printStackTrace();
		} finally {
			UtilsFactory.close(br);
			UtilsFactory.close(fr);
		}
		
		// Write into file
		try{
			fw = new FileWriter(srtConstantsPath);
			bw = new BufferedWriter(fw);
			
			bw.write(sb.toString());
		} catch(Throwable th) {
			System.out.println("Exception in writing config.properties: "+th.getMessage());
			th.printStackTrace();
		} finally {
			UtilsFactory.close(bw);
			UtilsFactory.close(fw);
		}
	}
}
