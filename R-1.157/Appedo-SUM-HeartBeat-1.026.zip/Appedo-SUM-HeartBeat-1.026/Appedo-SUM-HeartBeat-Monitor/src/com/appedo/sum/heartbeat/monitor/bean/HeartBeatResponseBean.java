package com.appedo.sum.heartbeat.monitor.bean;

public class HeartBeatResponseBean {

	private Long lTestId = null;
	private String strTestURL, strGUID, strLocation, strResponseStatus, strResponseTotalTime;
	private Integer nResponseCode;
	private Boolean bAvailable; //, bCURLException;
	private Long lAgentTestedOn = null, lAppedoReceivedOn = null;
	
	public Long getTestId() {
		return lTestId;
	}
	public void setTestId(Long lTestId) {
		this.lTestId = lTestId;
	}
	
	public String getTestURL() {
		return strTestURL;
	}
	public void setTestURL(String strURL) {
		this.strTestURL = strURL;
	}
	
	public String getGUID() {
		return strGUID;
	}
	public void setGUID(String strGUID) {
		this.strGUID = strGUID;
	}
	
	public String getLocation() {
		return strLocation;
	}
	public void setLocation(String strLocation) {
		this.strLocation = strLocation;
	}
	
	public String getResponseStatus() {
		return strResponseStatus;
	}
	public void setResponseStatus(String strResponseStatus) {
		this.strResponseStatus = strResponseStatus;
	}
	
	public int getResponseCode() {
		return nResponseCode;
	}
	public void setResponseCode(int nResponseCode) {
		this.nResponseCode = nResponseCode;
	}
	public void setResponseCode(String strResponseCode) {
		this.nResponseCode = Integer.parseInt( strResponseCode );
	}
	
	public String getResponseTotalTime() {
		return strResponseTotalTime;
	}
	public void setResponseTotalTime(String strResponseTotalTime) {
		this.strResponseTotalTime = strResponseTotalTime;
	}
	
	public boolean isAvailable() {
		return bAvailable;
	}
	public void setAvailable(boolean bAvailable) {
		this.bAvailable = bAvailable;
	}
	
	public Long getAgentTestedOn() {
		return lAgentTestedOn;
	}
	public void setAgentTestedOn(Long lAgentTestedOn) {
		this.lAgentTestedOn = lAgentTestedOn;
	}
	
	public Long getAppedoReceivedOn() {
		return lAppedoReceivedOn;
	}
	public void setAppedoReceivedOn(Long lAppedoReceivedOn) {
		this.lAppedoReceivedOn = lAppedoReceivedOn;
	}
	
	/*
	public boolean gotCURLException() {
		return bCURLException;
	}
	public void setCURLException(boolean bCURLException) {
		this.bCURLException = bCURLException;
	}
	*/
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb	.append("{ ")
			.append("testId: ").append(lTestId).append(", ")
			.append("testURL: \"").append(strTestURL).append("\", ")
			.append("GUID: \"").append(strGUID).append("\", ")
			.append("location: \"").append(strLocation).append("\", ")
			.append("responseStatus: \"").append(strResponseStatus).append("\", ")
			.append("responseCode: ").append(nResponseCode).append(", ")
			.append("responseTotalTime: ").append(strResponseTotalTime).append(", ")
			.append("agentTestedOn: ").append(lAgentTestedOn).append(", ")
			.append("appedoReceivedOn: ").append(lAppedoReceivedOn).append(", ")
			.append("available: ").append(bAvailable)
//			.append("CURLException: ").append(bCURLException)
			.append(" }");
		
		return sb.toString();
	}
}
