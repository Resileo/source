package com.appedo.sum.heartbeat.monitor.manager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.concurrent.LinkedBlockingQueue;

import net.sf.json.JSONObject;

import com.appedo.sum.heartbeat.monitor.bean.HeartBeatResponseBean;
import com.appedo.sum.heartbeat.monitor.bean.SUMTestBean;
import com.appedo.sum.heartbeat.monitor.utils.UtilsFactory;

public class SUMManager {

	private static SUMManager sumManager = null;

	private LinkedHashMap< String, Vector<SUMTestBean> > lhmAllSUMTests = new LinkedHashMap< String, Vector<SUMTestBean> >();
	
	private Hashtable<String, TimerTask> htTimerTaskMonitor = new Hashtable<String, TimerTask>();
	
	
	// Result storage
	public static LinkedBlockingQueue<HeartBeatResponseBean> queueHeartBeatResults = new LinkedBlockingQueue<HeartBeatResponseBean>();
	
	
	/**
	 * Make the class as Singleton
	 */
	private SUMManager() {
		
	}
	
	public static SUMManager getInstance() {
		if( sumManager == null ) {
			sumManager = new SUMManager();
		}
		
		return sumManager;
	}
	
	public void startURLReceiver() {
		TimerTask ttDataReceiver = null;
		Timer timerManager = new Timer();
		
		ttDataReceiver = new HeartBeatReceiverTimerTask();
		timerManager.schedule(ttDataReceiver, 50l, 60 * 1000);
	}
	
	public void populateSUMTests() throws Throwable {
		Object[] oaSUMURLs;
		String strSUMURLs = null;
		JSONObject joResponse = null;
		
		try {
			oaSUMURLs = AgentManager.getConfigurationsFromCollector();
			
			// Check for messages from Server
			if( ((String) oaSUMURLs[1]).startsWith("{") ) {
				joResponse = JSONObject.fromObject( (String) oaSUMURLs[1] );
				if( joResponse.containsKey("errorMessage") ) {
					System.out.println("Exception while receiving URLs: "+joResponse.get("errorMessage"));
				} else {
					System.out.println("Message while receiving URLs: "+joResponse.get("message"));
				}
			} else {
				
				strSUMURLs = (String) oaSUMURLs[1];
				System.out.println("URLs from Server: " +strSUMURLs);
				
				parseSUMTests(strSUMURLs);
			}
		} catch (Throwable th) {
			System.out.println("Exception in populateSUMTests: "+th.getLocalizedMessage());
			throw th;
		}
	}
	
	public void populateSUMTestsFromFile(String strFile) {
		File f = new File(strFile);
		BufferedReader br = null;
		
		StringBuilder sbLines = new StringBuilder();
		String strLines;
		
		try {
			br = new BufferedReader(new FileReader(f));

			while ((strLines = br.readLine()) != null) {
//				System.out.println("strLines: "+strLines);
				sbLines.append(strLines).append("\n");
			}
			
			if( sbLines.length() > 1 ) {
				sbLines.delete(sbLines.length()-1, sbLines.length());
			}
			System.out.println("sbLines: "+sbLines);
			
			parseSUMTests(sbLines.toString());
			
			// formatted Data-Structure
//			System.out.println("lhmAllSUMTests: "+lhmAllSUMTests);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	public void parseSUMTests(String strSUMTestURLs) {
		String[] saLines, saSchduledSUMTests = null, saMinutes = null;
		String strInterval;
		SUMTestBean sumTestBean = null;
		Vector<SUMTestBean> alSUMTestBeans = null;
		
		try {
			// Reset the DataStructure
			UtilsFactory.clearCollectionHieracy(lhmAllSUMTests);
			
			// Loop through each line
			saLines = strSUMTestURLs.split("\n");
			for( String strLine: saLines) {
				if( strLine.length() > 0 ) {
//					System.out.println("strLines: "+strLines);
					alSUMTestBeans = new Vector<SUMTestBean>();
					
					saSchduledSUMTests = strLine.split("#M#");
					strInterval = saSchduledSUMTests[0];
//					System.out.println("strInterval: "+strInterval);
					
					saMinutes = saSchduledSUMTests[1].split("#T#");
					
					for(String strSUMTests: saMinutes){
						sumTestBean = (SUMTestBean) JSONObject.toBean( JSONObject.fromObject(strSUMTests), SUMTestBean.class );
						
						alSUMTestBeans.add(sumTestBean);
					}
					
					lhmAllSUMTests.put(strInterval, alSUMTestBeans);
				}
			}
			
			// formatted Data-Structure
			//System.out.println("lhmAllSUMTests: "+lhmAllSUMTests);
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}
	
	/**
	 * Retrieve the configured URLs, for the given Time-Interval.
	 * 
	 * @param strIntervalMinutes
	 * @return
	 */
	public Vector<SUMTestBean> getSUMTests(String strIntervalMinutes) {
		return lhmAllSUMTests.get(strIntervalMinutes);
	}
	
	/**
	 * Start the Scheduler for each Minute-Interval.
	 * i.e. a TimerTask for "1" minute scheduled SUMTests,
	 * and another TimerTask for "5" minutes scheduled SUMTests and etc.
	 */
	public void startSchedulers() {
		SUMManager sumManager = SUMManager.getInstance();
		String strMinuteInterval = null;
		
		TimerTask ttMonitor = null;
		Timer timerManager = null;
		
		// Iterate in the Minute-Intervals category
		// Schedule Timer for each Minute-Intervals category
		Iterator<String> iter = sumManager.lhmAllSUMTests.keySet().iterator();
		while( iter.hasNext() ) {
			strMinuteInterval = iter.next();
			
			if( ! htTimerTaskMonitor.containsKey(strMinuteInterval) ) {
				ttMonitor = new HeartBeatMonitorTimerTask( strMinuteInterval );
				timerManager = new Timer();
				timerManager.schedule(ttMonitor, 50l, Integer.parseInt(strMinuteInterval) * 60 * 1000);
				
				htTimerTaskMonitor.put(strMinuteInterval, ttMonitor);
			}
		}
	}
	
	public void startResponseSender() {
		TimerTask ttSender = null;
		Timer timerManager = new Timer();
		
		ttSender = new HeartBeatSenderTimerTask();
		timerManager.schedule(ttSender, 50l, 5 * 1000);
	}
	
	public static void queueHeartBeatResults(HeartBeatResponseBean hbResponseResult) {
		queueHeartBeatResults.add(hbResponseResult);
	}
	
	public static ArrayList<HeartBeatResponseBean> drainHeartBeatResults() {
		ArrayList<HeartBeatResponseBean> alHeartBeatResponseBeans = new ArrayList<HeartBeatResponseBean>();
		
		queueHeartBeatResults.drainTo(alHeartBeatResponseBeans, 500);
		
		
		return alHeartBeatResponseBeans;
	}
}
