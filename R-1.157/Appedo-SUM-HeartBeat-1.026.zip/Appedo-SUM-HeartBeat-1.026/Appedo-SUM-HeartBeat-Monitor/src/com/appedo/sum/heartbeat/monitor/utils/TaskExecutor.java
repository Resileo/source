package com.appedo.sum.heartbeat.monitor.utils;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import com.appedo.sum.heartbeat.monitor.manager.HeartBeatMonitorTimerTask;

public class TaskExecutor {
	
	private static ConcurrentHashMap<String, TaskExecutor> map = new ConcurrentHashMap<String, TaskExecutor>();
	private ThreadPoolExecutor executor;
	private AtomicLong counter = new AtomicLong(1);
	
	private TaskExecutor(final String name, int minthreadPoolSize, int maxthreadPoolSize, int waitThreadAliveTimeoutMinutes, int queueSize) {
		
		ThreadFactory tf = new ThreadFactory() {
			public Thread newThread(Runnable run) {
				return new Thread(run, name + "-" + counter.getAndIncrement());
			}
		};
		
		BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>(queueSize);
		executor = new ThreadPoolExecutor(minthreadPoolSize, maxthreadPoolSize, waitThreadAliveTimeoutMinutes, TimeUnit.MINUTES, queue, tf);
		executor.allowCoreThreadTimeOut(true);
	}
	
	public static void newExecutor(String name, int minthreadPoolSize, int maxthreadPoolSize, int waitThreadAliveTimeoutMinutes, int queueSize) throws Exception {
		if ( minthreadPoolSize <= 0 ) {
			throw new IllegalArgumentException("Min ThreadPoolSize must be greater than 0");
		}
		if ( maxthreadPoolSize <= 0 ) {
			throw new IllegalArgumentException("Max ThreadPoolSize must be greater than 0");
		}
		if ( waitThreadAliveTimeoutMinutes <= 0 ) {
			throw new IllegalArgumentException("Wait-Thread Alive Timeout must be greater 0");
		}
		if ( queueSize <= 0 ) {
			throw new IllegalArgumentException("Internal Queue Size must be greater 0");
		}
//		if (handler == null) 
//		{
//			throw new IllegalArgumentException("RejectedExecutionHandler must not be NULL");
//		}
		
		TaskExecutor executor = new TaskExecutor(name, minthreadPoolSize, maxthreadPoolSize, waitThreadAliveTimeoutMinutes, queueSize);
		map.put(name, executor);
	}
	
	public static TaskExecutor getExecutor(String name) throws Exception {
		
		TaskExecutor executor=map.get(name);
		
		if ( executor == null ) {
			throw new IllegalArgumentException("TaskExecutor '"+name +"' not found");
		}
		
		return executor;
	}
	
	/**
	 * Execute the Thread/Runnable, with a Thread available from the ThreadPool.
	 * 
	 * @param runnable
	 * @throws Exception
	 */
	public void submit(Runnable runnable) throws Exception {
		
		executor.execute(runnable);
		
		System.out.println("No. of Threads in Use: "+executor.getActiveCount() +" getLargestPoolSize() :" +executor.getLargestPoolSize());
	}
	
	/**
	 * Prints the Executor's status
	 */
	public void status() {
		System.out.println("Executor Status: "+executor+" ; Active HeartBeaters = "+HeartBeatMonitorTimerTask.alActiveHeartBeaters.size());
	}
	
	/**
	 * Prints the all items in the Array, which are waiting for execution.
	 */
	public void extendedStatus() {
		if( HeartBeatMonitorTimerTask.alActiveHeartBeaters.size() > 0 ) {
			System.out.println("Active HeartBeaters: "+HeartBeatMonitorTimerTask.alActiveHeartBeaters);
		}
	}
	
	public void shutdown() {
		executor.shutdown();
	}
}
