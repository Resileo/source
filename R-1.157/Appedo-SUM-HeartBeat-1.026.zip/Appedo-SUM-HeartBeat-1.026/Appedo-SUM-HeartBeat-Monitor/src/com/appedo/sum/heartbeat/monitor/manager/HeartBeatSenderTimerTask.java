package com.appedo.sum.heartbeat.monitor.manager;

import java.util.ArrayList;
import java.util.TimerTask;

import com.appedo.sum.heartbeat.monitor.bean.HeartBeatResponseBean;

public class HeartBeatSenderTimerTask extends TimerTask {

	@Override
	public void run() {
		ArrayList<HeartBeatResponseBean> alHeartBeatResponseBeans = null;
		
		alHeartBeatResponseBeans = SUMManager.drainHeartBeatResults();
		
		if( alHeartBeatResponseBeans.size() > 0 ) {
			System.out.println("drained alHeartBeatResponseBeans: "+alHeartBeatResponseBeans);
			AgentManager.sendHeartBeatResults(alHeartBeatResponseBeans);
		}
	}
}
