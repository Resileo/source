package com.appedo.sum.heartbeat.monitor.manager;

import java.util.Date;
import java.util.TimerTask;
import java.util.Vector;

import com.appedo.sum.heartbeat.monitor.bean.SUMTestBean;
import com.appedo.sum.heartbeat.monitor.utils.Constants;
import com.appedo.sum.heartbeat.monitor.utils.TaskExecutor;

public class HeartBeatMonitorTimerTask extends TimerTask {
	
	private String strIntervalMinutes = null;
	
	private HeartBeater hb = null;
	public static Vector<HeartBeater> alActiveHeartBeaters = new Vector<HeartBeater>();
	
	private static TaskExecutor taskExecutor = null;
	
	/**
	 * Initialize the ThreadPool to be used to test the URLs.
	 * 
	 * @param strIntervalMinutes
	 */
	public HeartBeatMonitorTimerTask(String strIntervalMinutes) {
		this.strIntervalMinutes = strIntervalMinutes;
		
		try {
			TaskExecutor.newExecutor("HEART_BEAT_MONITOR_TIMER_TASK", 
					Constants.THREADPOOL_MIN_THREADS, Constants.THREADPOOL_MAX_THREADS, Constants.THREADPOOL_THREADS_ALIVE_TIME_MINUTES, Constants.THREADPOOL_QUEUE_THREADS);
			
			taskExecutor = TaskExecutor.getExecutor("HEART_BEAT_MONITOR_TIMER_TASK");
		} catch (Exception e) {
			System.out.println("Exception in creating ThreadPool in HeartBeatMonitorTimerTask: "+e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		System.out.println("Starting the interval for '"+strIntervalMinutes+" minutes' <> "+new Date());
		taskExecutor.status();
		taskExecutor.extendedStatus();
		
		Vector<SUMTestBean> alSUMTestBeans = null;
		
		alSUMTestBeans = SUMManager.getInstance().getSUMTests(strIntervalMinutes);
		
		// TODO if the Array is blank or NULL. Kill this Timer.
		if( alSUMTestBeans != null && alSUMTestBeans.size() > 0 ) {
			for(int i = 0; i < alSUMTestBeans.size(); i++ ) {
				hb = new HeartBeater( alSUMTestBeans.get(i) );
				alActiveHeartBeaters.add(hb);
				
				try {
					// using TaskExecutor class
					taskExecutor.submit(hb);
					
					// using HeartBeatThreadPoolManager, newCachedThreadPool()
					//HeartBeatThreadPoolManager.execute( hb );
					
					// using normal Thread creation, without ThreadPool
					//new Thread( hb ).start();
				} catch (Exception e) {
					System.out.println("Exception in task exection: "+e.getMessage());
					e.printStackTrace();
				}
			}
		}
	}
}
