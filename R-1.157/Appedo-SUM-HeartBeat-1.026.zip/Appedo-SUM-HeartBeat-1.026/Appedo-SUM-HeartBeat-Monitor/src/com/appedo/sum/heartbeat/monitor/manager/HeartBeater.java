package com.appedo.sum.heartbeat.monitor.manager;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.sum.heartbeat.monitor.bean.HeartBeatResponseBean;
import com.appedo.sum.heartbeat.monitor.bean.SUMTestBean;
import com.appedo.sum.heartbeat.monitor.utils.Constants;

public class HeartBeater implements Runnable {
	
	private SUMTestBean sumTestBean = null;
	
//	private static int nCount = 0, nSuccess, nFailure;
	
	// private HashMap<String, ProcessBuilder> hmURLsProcessBuilder = new HashMap<String, ProcessBuilder>();
	
	// Enable the redirection of the request.
	// Eg.: http://apm.appedo.com will return 302 and redirection-location as https://apm.appedo.com
	// But the operation will stop till 302, So need to set this as TRUE to enable HTTPS redirection.
	static {
		HttpURLConnection.setFollowRedirects(true);
	}
	
	public HeartBeater(SUMTestBean sumTestBean) {
		this.sumTestBean = sumTestBean;
	}
	
	@Override
	public void run() {
		
//		boolean isAlive = isWebSiteAlive(sumTestBean);
		HeartBeatResponseBean hbResponseResult = isWebSiteAliveUsingHTTPURL();
//		boolean isAlive = isWebSiteAliveUsingURL(sumTestBean);
		
//		boolean isAlive = isWebSiteAliveUsingCURL();
		
//		if( hbResponseResult.isAvailable() ){
//			nSuccess++;
//		} else {
//			nFailure++;
//		}
		
		SUMManager.queueHeartBeatResults(hbResponseResult);
		
//		++nCount;
		
//		if( nCount%100 == 0 ) {
//			nSuccess = 0;
//			nFailure = 0;
//			HeartBeatThreadPoolManager.status();
//			HeartBeatThreadPoolManager.extendedStatus();
//			System.out.println(nCount+" URLs are end : "+new Date()+" <> Success: "+nSuccess+" <> Failure: "+nFailure);
//		}
//		if( nCount%500 == 0 ) {
//			nCount = 0;
//		}
		
		HeartBeatMonitorTimerTask.alActiveHeartBeaters.remove( this );
	}
	
	/**
	 * Get the Response Header using CURL Linux command.
	 * First try for HEAD request, if it is not responding 200 status, 
	 * then try GET request.
	 * 
	 * Complexities:
	 * 1. As this has to be executed through ProcessBuilder, the OS is unable to create required Threads. Already each URL is running through each Threads.
	 * 
	 * So this is not used.
	 * 
	 * Advantage:
	 * 1. We can get time taken for each activity like namelookup, connect, redirect, pre-transfer, start-transfer and Total-Time.
	 * 
	 * @return
	 *
	private boolean isWebSiteAliveUsingCURL() {
		boolean bReturn = false;
		HeartBeatResponseBean hbResponseResult = new HeartBeatResponseBean();
		int nResponseCode;
		
		try {
			// First try to get the HEAD method's response
			// if it is not returning 200 then try for GET method's response
			hbResponseResult = executeCURL(CURL_CONSTANTS.HEAD_REQ);
			
			if( hbResponseResult.gotCURLException() ) {
				bReturn = false;
			} else {
				nResponseCode = hbResponseResult.getResponseCode();
				if( nResponseCode == 200 ) {
					bReturn = true;
				} else {
					// On non-200, for HEAD request
					// call the GET method's response
					hbResponseResult = executeCURL(CURL_CONSTANTS.GET_REQ);
				}
			}
			
			if( hbResponseResult.getResponseCode() == 200 ) {
				bReturn = true;
			}
		} catch(Throwable th) {
			System.out.println("Exception in isWebSiteAliveUsingCURL: "+th.getMessage());
			th.printStackTrace();
		} finally {
		}
		
		return bReturn;
	}
	*/
	
	/**
	 * Get the Response Header using CURL Linux command.
	 * 
	 * Complexities:
	 * 1. As this has to be executed through ProcessBuilder, the OS is unable to create required Threads. Already each URL is running through each Threads.
	 * 
	 * So this is not used.
	 * 
	 * Advantage:
	 * 1. We can get time taken for each activity like namelookup, connect, redirect, pre-transfer, start-transfer and Total-Time.
	 *
	 * @param reqMethod
	 * @return
	 *
	private HeartBeatResponseBean executeCURL(CURL_CONSTANTS reqMethod) {
		HeartBeatResponseBean hbResponseResult = new HeartBeatResponseBean();
		ProcessBuilder pbHeadResponse = null;
		
		Process pCURLResponse = null;
		InputStreamReader isrCURLResponse = null;
		BufferedReader rCURLResponse = null;
		
		String strLine = null, strURLAndMethod = null;
		
		try {
			hbResponseResult.setURL( sumTestBean.getURL() );
			
			strURLAndMethod = sumTestBean.getURL()+"_"+reqMethod.toString();
			
			// First try to get the HEAD method's response
			// if it is not returning 200 then try for GET method's response
			if( hmURLsProcessBuilder.containsKey( strURLAndMethod ) ) {
				pbHeadResponse = hmURLsProcessBuilder.get( strURLAndMethod );
			} else {
				if( reqMethod == CURL_CONSTANTS.HEAD_REQ ) {
					pbHeadResponse = new ProcessBuilder("bash", "-c", "curl -s -w \"HTTP_FINAL_RESP_CODE %{http_code}\\nHTTP_RESULT_TOTAL_TIME %{time_total}\\n\" -I -L --connect-timeout 7 --show-error \""+sumTestBean.getURL()+"\" | grep \"HTTP\" | tail -n3");
					hmURLsProcessBuilder.put( strURLAndMethod, pbHeadResponse );
				} else if( reqMethod == CURL_CONSTANTS.GET_REQ ) {
					pbHeadResponse = new ProcessBuilder("bash", "-c", "curl -s -w \"HTTP_FINAL_RESP_CODE %{http_code}\\nHTTP_RESULT_TOTAL_TIME %{time_total}\\n\" -D - -L -o /dev/null --connect-timeout 7 --show-error \""+sumTestBean.getURL()+"\" | grep \"HTTP\" | tail -n3");
					hmURLsProcessBuilder.put( strURLAndMethod, pbHeadResponse );
				}
			}
			
			pCURLResponse = pbHeadResponse.start();
			isrCURLResponse = new InputStreamReader(pCURLResponse.getInputStream());
			rCURLResponse = new BufferedReader(isrCURLResponse);
			while( (strLine = rCURLResponse.readLine()) != null ) {
//				System.out.println("o/p: "+strLine);
				
				// Parse the output
				if( strLine.startsWith(CURL_CONSTANTS.HTTP_VERSION_PREFIX.toString()) ) {
					hbResponseResult.setResponseStatus(strLine);
				}
				else if( strLine.startsWith(CURL_CONSTANTS.HTTP_FINAL_RESP_CODE.toString()) ) {
					hbResponseResult.setResponseCode( strLine.substring("HTTP_FINAL_RESP_CODE ".length()) );
				}
				else if( strLine.startsWith(CURL_CONSTANTS.HTTP_RESULT_TOTAL_TIME.toString()) ) {
					hbResponseResult.setResponseTotalTime( strLine.substring("HTTP_RESULT_TOTAL_TIME ".length()) );
				}
				else if( strLine.startsWith(CURL_CONSTANTS.CURL.toString()) ) {
					hbResponseResult.setCURLException( true );
					hbResponseResult.setResponseStatus( strLine.substring( strLine.indexOf(')') ) );
				}
			}
			
//			System.out.println("hbResponseResult: "+hbResponseResult);
		} catch(Throwable th) {
			System.out.println("Exception in executeCURL: "+th.getMessage());
			th.printStackTrace();
		} finally {
			close(rCURLResponse);
			rCURLResponse = null;
			
			close(isrCURLResponse);
			isrCURLResponse = null;
			
			close(pCURLResponse);
			pCURLResponse = null;
		}
		
		return hbResponseResult;
	}
	*/
	
	/**
	 * Get the Response Header using URLConnection method.
	 * 
	 * Complexities:
	 * 1. Need to parse the output map's NULL key's value to get Response-Code
	 * 2. If more than 200 URLs are given then, Internet hangs. Even browser is not working.
	 * 3. IMP: URL redirections done are not getting re-directed. So more failure reported.
	 * 
	 * So this is not used.
	 * 
	 * @param sumTestBean
	 * @return
	 *
	private boolean isWebSiteAlive(SUMTestBean sumTestBean) {
		boolean bReturn = false;
		URL obj;
		URLConnection conn = null;
		Map<String, List<String>> map = null;
		
		try {
			obj = new URL( sumTestBean.getURL() );
			conn = obj.openConnection();
			
			// Get all headers
			conn.setConnectTimeout(5000);
			map = conn.getHeaderFields();
			if( map.size() > 0 ) {
				bReturn = false;
			} else {
				bReturn = true;
			}
		} catch (Throwable th) {
			System.out.println("Exception in isWebsiteAlive: "+th.getLocalizedMessage());
			th.printStackTrace();
		}
		
		return bReturn;
	}
	*/
	
	/**
	 * Get the Response Header using URLConnection method.
	 * 
	 * 1) Try HEAD method.
	 * 2) Try GET method.
	 * 
	 * Complexities:
	 * 1. URL redirections done are not getting re-directed. So more failure reported.
	 * 
	 * So this is not used.
	 * 
	 * @param sumTestBean
	 * @return
	 */
	private HeartBeatResponseBean isWebSiteAliveUsingHTTPURL() {
		int nResponseCode = -1;
		URL obj;
		HttpURLConnection conn = null;
		String strURL = null, strRedirectURL = null;
		HeartBeatResponseBean hbResponseResult = new HeartBeatResponseBean();
		JSONArray jaRequest = null;
		JSONObject joRequest = null;
		StringBuilder sbURLParameters = null;
		
		try {
			strURL = sumTestBean.getURL();
			hbResponseResult.setTestId(sumTestBean.getTestId());
			hbResponseResult.setTestURL(strURL);
			hbResponseResult.setLocation( Constants.AGENT_LOCATION );
			hbResponseResult.setGUID( Constants.GUID );
			
			// 1) Try HEAD method, if permitted
			if( sumTestBean.isTestHeadFirst() ) {
				obj = new URL( strURL );
				conn = (HttpURLConnection) obj.openConnection();
				conn.setConnectTimeout( Constants.TIMEOUT_IN_MILLISECONDS );
				conn.setReadTimeout( Constants.TIMEOUT_IN_MILLISECONDS );
				
				conn.setRequestMethod("HEAD");
				
				// set Request Header
				jaRequest = sumTestBean.getRequestHeaders();
				for(int i=0; i < jaRequest.size(); i++ ) {
					joRequest = jaRequest.getJSONObject(i);
					conn.setRequestProperty(joRequest.getString("name"), joRequest.getString("value"));
				}
				
				nResponseCode = conn.getResponseCode();
				//System.out.println("HEAD ResponseCode: "+nResponseCode);
				conn.disconnect();
			}
			
			// 2) Try GET method; with redirection URLs.
			strRedirectURL = strURL;
			
			while( nResponseCode != HttpURLConnection.HTTP_OK && strRedirectURL != null ) {
				obj = new URL( strRedirectURL );
				conn = (HttpURLConnection) obj.openConnection();
				conn.setConnectTimeout( Constants.TIMEOUT_IN_MILLISECONDS );
				conn.setReadTimeout( Constants.TIMEOUT_IN_MILLISECONDS );
				
				conn.setRequestMethod( sumTestBean.getRequestMethod() );
				
				// set Request Header
				jaRequest = sumTestBean.getRequestHeaders();
				for(int i=0; i < jaRequest.size(); i++ ) {
					joRequest = jaRequest.getJSONObject(i);
					conn.setRequestProperty(joRequest.getString("name"), joRequest.getString("value"));
				}
				
				// set Request Parameter, only for POST & PUT
				if( sumTestBean.getRequestMethod().equals("POST") || sumTestBean.getRequestMethod().equals("PUT") ) {
					sbURLParameters = new StringBuilder();
					jaRequest = sumTestBean.getRequestParameters();
					for(int i=0; i < jaRequest.size(); i++ ) {
						joRequest = jaRequest.getJSONObject(i);
						if( joRequest.getString("name").length() > 0 ) {
							if( sbURLParameters.length() != 0 ) sbURLParameters.append('&');
							sbURLParameters.append(joRequest.getString("name")).append("=").append( URLEncoder.encode(joRequest.getString("value"),"UTF-8") );
						}
					}
					String urlParameters = sbURLParameters.toString();
					byte[] postData = urlParameters.getBytes( StandardCharsets.UTF_8 );
					conn.setDoOutput(true);
					try( DataOutputStream wr = new DataOutputStream( conn.getOutputStream() ) ) {
						wr.write( postData );
						wr.flush();
					}
				}
				
				// Send request
				nResponseCode = conn.getResponseCode();
				//System.out.println("GET ResponseCode: "+nResponseCode);
				//System.out.println("GET ResponseMsg: "+conn.getResponseMessage());
				
				strRedirectURL = conn.getHeaderField("Location");
				conn.disconnect();
			}
			
			hbResponseResult.setAgentTestedOn( new Date().getTime() );
			hbResponseResult.setResponseCode(nResponseCode);
			hbResponseResult.setResponseStatus( (String)conn.getHeaderField(null) );
			hbResponseResult.setAvailable( 200 <= nResponseCode && nResponseCode <= 399 );
			
			//System.out.println("conn.getHeaderFields(): "+conn.getHeaderFields());
			//System.out.println("responseCode: "+nResponseCode+" <> "+(200 <= nResponseCode && nResponseCode <= 399)+" <> "+sumTestBean.getURL());
		} catch (java.net.UnknownHostException uhe) {
			System.out.println("Exception in isWebSiteAliveUsingHTTPURL: UnknownHostException: "+uhe.getLocalizedMessage()+" <> "+sumTestBean.getURL()+" <> redirction: "+strRedirectURL);
			
			hbResponseResult.setAgentTestedOn( new Date().getTime() );
			hbResponseResult.setResponseCode(0);
			hbResponseResult.setResponseStatus( "Could not resolve host - "+hbResponseResult.getTestURL() );
			hbResponseResult.setAvailable( false );
		} catch (Throwable th) {
			System.out.println("Exception in isWebSiteAliveUsingHTTPURL: "+th.getLocalizedMessage()+" <> "+sumTestBean.getURL()+" <> redirction: "+strRedirectURL);
			th.printStackTrace();
			
			hbResponseResult.setAgentTestedOn( new Date().getTime() );
			hbResponseResult.setResponseCode(0);
			hbResponseResult.setResponseStatus( th.getLocalizedMessage() );
			hbResponseResult.setAvailable( false );
		} finally {
			// Disconnect the last opened connection.
			conn.disconnect();
			conn = null;
		}
		
//		System.out.println("hbResponseResult: "+hbResponseResult);
		return hbResponseResult;
	}
	
	/**
	 * Get the Response Header using URLConnection method.
	 * 
	 * Complexities:
	 * 1. IMP: URL redirections done are not getting re-directed. So more failure reported.
	 * 
	 * So this is not used.
	 * 
	 * @param sumTestBean
	 * @return
	 *
	private boolean isWebSiteAliveUsingURL(SUMTestBean sumTestBean) {
		boolean bReturn = false;
		
		try {
			URL url = new URL(sumTestBean.getURL());
			InputStream i = null;
			
			i = url.openStream();

			if (i != null) {
				bReturn = true;
			}
			
		} catch (Throwable th) {
			System.out.println("Exception in isWebSiteAliveUsingURL: "+th.getLocalizedMessage()+" <> "+sumTestBean.getURL());
		} 
		
		return bReturn;
	}
	*/
	
	/**
	 * Close/Destroy the BufferedReader.
	 * 
	 * @param br
	 *
	private void close(BufferedReader br) {
		try{
			br.close();
		} catch(Exception e) {
			System.out.println("Exception in br.close(): "+e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * Close/Destroy the InputStreamReader.
	 * 
	 * @param isr
	 *
	private void close(InputStreamReader isr) {
		try{
			isr.close();
		} catch(Exception e) {
			System.out.println("Exception in isr.close(): "+e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * Close/Destroy the Process.
	 * 
	 * @param process
	 *
	private void close(Process process) {
		try{
			process.destroy();
		} catch(Exception e) {
			System.out.println("Exception in process.destroy(): "+e.getMessage());
			e.printStackTrace();
		}
	}
	*/
	
	@Override
	public String toString() {
		return this.sumTestBean.getURL();
	}
	
	public static void main(String[] args) {
		SUMTestBean stb = new SUMTestBean();
		stb.setTestId( 100 );
		stb.setURL("http://www.appedo.com");
		stb.setRequestMethod("HEAD");
		stb.setTestHeadFirst(false);
		stb.setRequestHeaders(new JSONArray());
		stb.setRequestParameters(new JSONArray());
		
		HeartBeater hb = new HeartBeater(stb);
		System.out.println( hb.isWebSiteAliveUsingHTTPURL() );
		
		/*
		URL obj;
		HttpURLConnection conn = null;
		int nResponseCode = 0;
		
		try{
			obj = new URL( "http://www.appedo.com" );
			conn = (HttpURLConnection) obj.openConnection();
			
			conn.setRequestMethod("GET");
//			conn.setRequestProperty("method", "GET");
			conn.setConnectTimeout( Constants.TIMEOUT_IN_MILLISECONDS );
			conn.setReadTimeout( Constants.TIMEOUT_IN_MILLISECONDS );
			
			nResponseCode = conn.getResponseCode();
			System.out.println("HEAD ResponseCode: "+nResponseCode);
			
			conn.disconnect();
			
			
//			conn.connect();
			conn = (HttpURLConnection) obj.openConnection();
			conn.setRequestMethod("HEAD");

			conn.setRequestProperty("method", "HEAD");
			nResponseCode = conn.getResponseCode();
			System.out.println("GET ResponseCode: "+nResponseCode);

		} catch (Throwable th) {
			System.out.println("Exception in isWebSiteAliveUsingHTTPURL: "+th.getLocalizedMessage());
			th.printStackTrace();
		} finally {
			conn.disconnect();
			conn = null;
		}
		*/
	}
}
