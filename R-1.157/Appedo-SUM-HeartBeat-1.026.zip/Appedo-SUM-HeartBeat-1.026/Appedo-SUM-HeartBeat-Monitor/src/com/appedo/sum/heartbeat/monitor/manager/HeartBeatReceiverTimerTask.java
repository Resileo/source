package com.appedo.sum.heartbeat.monitor.manager;

import java.util.TimerTask;

public class HeartBeatReceiverTimerTask extends TimerTask {

	@Override
	public void run() {
		try{
			SUMManager sumManager = SUMManager.getInstance();
			sumManager.populateSUMTests();
			
			// Start the Thread Manager
			sumManager.startSchedulers();
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}
}
