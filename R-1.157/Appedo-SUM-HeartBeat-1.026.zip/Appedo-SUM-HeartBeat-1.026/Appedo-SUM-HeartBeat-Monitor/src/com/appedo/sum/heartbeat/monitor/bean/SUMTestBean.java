package com.appedo.sum.heartbeat.monitor.bean;

import net.sf.json.JSONArray;

public class SUMTestBean {

	private long lTestId;
	private String strURL;
	private String strRequestMethod;
	private boolean bTestHeadFirst;
	private JSONArray jaRequestHeaders;
	private JSONArray jaRequestParameters;
	private Integer nTestFrequency;
	
	public long getTestId() {
		return lTestId;
	}
	public void setTestId(long lTestId) {
		this.lTestId = lTestId;
	}
	
	public String getURL() {
		return strURL;
	}
	public void setURL(String strURL) {
		this.strURL = strURL;
	}
	
	public String getRequestMethod() {
		return strRequestMethod;
	}
	public void setRequestMethod(String strRequestMethod) {
		this.strRequestMethod = strRequestMethod;
	}
	
	public boolean isTestHeadFirst() {
		return bTestHeadFirst;
	}
	public void setTestHeadFirst(boolean bTestHeadFirst) {
		this.bTestHeadFirst = bTestHeadFirst;
	}
	
	public JSONArray getRequestHeaders() {
		return jaRequestHeaders;
	}
	public void setRequestHeaders(JSONArray jaRequestHeaders) {
		this.jaRequestHeaders = jaRequestHeaders;
	}
	
	public JSONArray getRequestParameters() {
		return jaRequestParameters;
	}
	public void setRequestParameters(JSONArray jaRequestParameters) {
		this.jaRequestParameters = jaRequestParameters;
	}
	
	public Integer getTestFrequency() {
		return nTestFrequency;
	}
	public void setTestFrequency(Integer nTestFrequency) {
		this.nTestFrequency = nTestFrequency;
	}
	
	@Override
	public String toString() {
		
		return "{ id:"+lTestId+", url: "+strURL+" }";
	}
}
