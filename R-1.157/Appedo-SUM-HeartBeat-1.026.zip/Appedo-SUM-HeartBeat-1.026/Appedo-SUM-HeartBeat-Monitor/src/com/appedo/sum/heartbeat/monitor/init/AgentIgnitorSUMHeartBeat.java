package com.appedo.sum.heartbeat.monitor.init;

import java.io.File;

import com.appedo.sum.heartbeat.monitor.manager.AgentManager;
import com.appedo.sum.heartbeat.monitor.manager.SUMManager;
import com.appedo.sum.heartbeat.monitor.utils.Constants;

/**
 * Availability Monitor Agent's starting point.
 * 
 * @author Ramkumar R
 * 
 */
public class AgentIgnitorSUMHeartBeat {
	
	public static void main(String[] args) {
		String srtConstantsPath = Constants.THIS_JAR_HOMEPATH+File.separator+"config.properties";
		
		try {
			System.out.println("Starting AVM Agent...");
			System.out.println("Agent Version: "+Constants.THIS_AGENT_VERSION);
			System.out.println();
			
			Constants.loadConstants();
			
        	System.out.println("Reading properties from : "+srtConstantsPath);
			Constants.loadConstantsProperties(srtConstantsPath);	// for Server-URL, ThreadPool-length, Timeout
			System.out.println();
			
			// Stop the agent if location is not valid.
			if( ! AgentManager.validateAgentLocation() ) {
				return ;
			}
			
			
			Constants.fillBlankGUID(srtConstantsPath);
    		
			System.out.println("Machine Details:");
			System.out.println("MAC-Address: "+Constants.MACHNE_MAC_ADDRESS);
			System.out.println("Location: "+Constants.AGENT_LOCATION);
			System.out.println();
			
			if ( args.length == 0 ) {
				SUMManager sumManager = SUMManager.getInstance();
				sumManager.startURLReceiver();
				// For testing purpose, use this "E:/Ramkumar/Projects/Appedo/SUM-HeartBeat/SUM_Tests.txt"
				// sumManager.populateSUMTestsFromFile( "SUM_Tests.txt" );
				
				// Start response Sender
				sumManager.startResponseSender();
			} else {
				System.out.println("Invalid options.");
			}
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}
}