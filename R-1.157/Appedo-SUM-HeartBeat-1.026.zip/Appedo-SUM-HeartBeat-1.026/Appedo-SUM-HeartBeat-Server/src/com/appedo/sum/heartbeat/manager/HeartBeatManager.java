package com.appedo.sum.heartbeat.manager;

import java.sql.Connection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import com.appedo.sum.heartbeat.bean.SUMTestBean;
import com.appedo.sum.heartbeat.dbi.HeartBeatDBI;
import com.appedo.sum.heartbeat.utils.UtilsFactory;

public class HeartBeatManager {
	
	private static HeartBeatManager heartBeatManager = null;
	
	// List of SUM-Tests; Interval-wise
							// Test-Frequency, SUMTestBeans
	private static LinkedHashMap<String, LinkedList<SUMTestBean> > hmFreqSUMTestBeans = null;
	
	/**
	 * Make the Class as Singleton
	 */
	private HeartBeatManager() {
	}
	
	/**
	 * Return the single Object of this class.
	 * 
	 * @return
	 */
	public static HeartBeatManager getInstance() {
		if( heartBeatManager == null ) {
			heartBeatManager = new HeartBeatManager();
		}
		
		return heartBeatManager;
	}
	
	public void populateAllSUMHeartBeatList(Connection con) throws Throwable {
		try{
			UtilsFactory.clearCollectionHieracy(hmFreqSUMTestBeans);
			
			hmFreqSUMTestBeans = HeartBeatDBI.getHeartBeatURLs(con);
			
		} catch (Throwable th) {
			throw th;
		} finally {
		
		} 
	}
	
	/*
	public long getRecursiveSize( HashMap<String, LinkedList<SUMTestBean> > hmFreqSUMTestBeans ) throws Throwable {
		Iterator<String> iterFreq = null;
		String strFrequency = null;
		long lTests = 0;
		
		try{
			iterFreq = hmFreqSUMTestBeans.keySet().iterator();
			while( iterFreq.hasNext() ) {
				strFrequency = iterFreq.next();
				
				lTests = hmFreqSUMTestBeans.get(strFrequency).size();
			}
		} catch(Throwable th) {
			throw th;
		}
		
		return lTests;
	}
	*/
	
	public StringBuilder getAllHearBeatTests() {
		Iterator<String> iterFreq = null;
		LinkedList<SUMTestBean> llSUMTestBeans = null;
		SUMTestBean sumTestBean = null;
		String strFrequency = null;
		
		StringBuilder sbTests = new StringBuilder();
		int idx = 0;
		
		try{
			iterFreq = hmFreqSUMTestBeans.keySet().iterator();
			
			while( iterFreq.hasNext() ) {
				strFrequency = iterFreq.next();
				
				sbTests.append(strFrequency).append("#M#");
				
				llSUMTestBeans = hmFreqSUMTestBeans.get(strFrequency);
				
				for( idx = 0; idx < llSUMTestBeans.size(); idx++ ) {
					sumTestBean = llSUMTestBeans.get(idx);
					sbTests.append(sumTestBean.toJSON()).append("#T#");
				}
				
				if( idx > 0 ) {
					// remove last #T#
					sbTests.delete( sbTests.length() - 3, sbTests.length() );
				}
				
				sbTests.append("\n");
			}
			
			if( hmFreqSUMTestBeans.size() > 0 ) {
				sbTests.delete( sbTests.length() - 1, sbTests.length() );
			}
		} catch(Throwable th) {
			throw th;
		}
		
		return sbTests;
	}
	
	public Object[] getAllHearBeatTests(Connection con, String strEncryptedUserId, String strCountry, String strState, String strCity, String strRegion, String strZone) throws Throwable {
		HeartBeatDBI hbDBI = null;
		long lUserId;
		
		Iterator<String> iterFreq = null;
		LinkedList<SUMTestBean> llSUMTestBeans = null;
		LinkedHashMap<String, LinkedList<SUMTestBean> > hmAVMTestBeansFreq = null;
		SUMTestBean sumTestBean = null;
		String strFrequency = null;
		
		StringBuilder sbTests = new StringBuilder();
		int idx = 0;
		
		try{
			// Get the tests to be monitored, for the given User-ID & Location, according to its monitor frequency
			hbDBI = new HeartBeatDBI();
			lUserId = hbDBI.getUserId(con, strEncryptedUserId);
			
			hmAVMTestBeansFreq = hbDBI.getHeartBeatURLs(con, lUserId, strCountry, strState, strCity, strRegion, strZone);
			
			
			// Format the Tests collected above.
			iterFreq = hmAVMTestBeansFreq.keySet().iterator();
			
			while( iterFreq.hasNext() ) {
				strFrequency = iterFreq.next();
				
				sbTests.append(strFrequency).append("#M#");
				
				llSUMTestBeans = hmAVMTestBeansFreq.get(strFrequency);
				
				for( idx = 0; idx < llSUMTestBeans.size(); idx++ ) {
					sumTestBean = llSUMTestBeans.get(idx);
					sbTests.append(sumTestBean.toJSON()).append("#T#");
				}
				
				if( idx > 0 ) {
					// remove last #T#
					sbTests.delete( sbTests.length() - 3, sbTests.length() );
				}
				
				sbTests.append("\n");
			}
			
			if( hmAVMTestBeansFreq.size() > 0 ) {
				sbTests.delete( sbTests.length() - 1, sbTests.length() );
			}
			
		} catch(Throwable th) {
			throw th;
		}
		
		return new Object[]{sbTests, lUserId, hmAVMTestBeansFreq.size()};
	}
}
