package com.appedo.sum.heartbeat.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.bean.HeartBeatAgent;
import com.appedo.sum.heartbeat.bean.HeartBeatResponseBean;
import com.appedo.sum.heartbeat.bean.SUMTestBean;
import com.appedo.sum.heartbeat.connect.DataBaseManager;
import com.appedo.sum.heartbeat.utils.UtilsFactory;

public class HeartBeatDBI {
	
	/**
	 * Get all the Availability URLs
	 * 
	 * @param con
	 * @return
	 * @throws Throwable
	 */
	public static LinkedHashMap<String, LinkedList<SUMTestBean> > getHeartBeatURLs(Connection con) throws Throwable {
		Statement stmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		LinkedHashMap<String, LinkedList<SUMTestBean> > hmFreqSUMTestBeans = new LinkedHashMap<String, LinkedList<SUMTestBean> >();
		LinkedList<SUMTestBean> llSUMTestBeans = null;
		SUMTestBean sumTestBean = null;
		
		String strTestFrequency = null;
		
		try {
			sbQuery	.append("SELECT * FROM get_all_avm_urls()");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while( rst.next() ) {
				sumTestBean = new SUMTestBean();
				sumTestBean.setTestId( rst.getLong("avm_test_id") );
				sumTestBean.setURL( rst.getString("testurl") );
				sumTestBean.setTestFrequency( rst.getInt("frequency") );
				sumTestBean.setRequestMethod( rst.getString("request_method") );
				sumTestBean.setTestHeadFirst( rst.getBoolean("test_head_method_first") );
				sumTestBean.setRequestHeaders( JSONArray.fromObject( rst.getString("request_headers") ) );
				sumTestBean.setRequestParameters( JSONArray.fromObject( rst.getString("request_parameters") ) );
				
				// TODO Keep all Test in a ArrayList, for Update verification purpose.
				//alSUMTestBeans.add(sumTestBean);
				
				strTestFrequency = sumTestBean.getTestFrequency()+"";
				
				if( hmFreqSUMTestBeans.containsKey( strTestFrequency ) ) {
					llSUMTestBeans = hmFreqSUMTestBeans.get( strTestFrequency );
				} else {
					llSUMTestBeans = new LinkedList<SUMTestBean>();
					hmFreqSUMTestBeans.put(strTestFrequency, llSUMTestBeans);
				}
				llSUMTestBeans.add(sumTestBean);
			}
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
	 	return hmFreqSUMTestBeans;
	}
	
	/**
	 * Get all the Availability URLs, mapped to particular Location
	 * 
	 * @param con
	 * @param lUserId
	 * @param strLocation
	 * @return
	 * @throws Throwable
	 */
	public LinkedHashMap<String, LinkedList<SUMTestBean> > getHeartBeatURLs(Connection con, long lUserId, String strCountry, String strState, String strCity, String strRegion, String strZone) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		LinkedHashMap<String, LinkedList<SUMTestBean> > hmFreqSUMTestBeans = new LinkedHashMap<String, LinkedList<SUMTestBean> >();
		LinkedList<SUMTestBean> llSUMTestBeans = null;
		SUMTestBean sumTestBean = null;
		
		String strTestFrequency = null;
		
		try {
			sbQuery	.append("SELECT * FROM get_avm_urls(?,?,?,?,?,?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strCountry);
			pstmt.setString(3, strState);
			pstmt.setString(4, strCity);
			pstmt.setString(5, strRegion);
			pstmt.setString(6, strZone);
			
			rst = pstmt.executeQuery();
			
			while( rst.next() ) {
				sumTestBean = new SUMTestBean();
				sumTestBean.setTestId( rst.getLong("avm_test_id") );
				sumTestBean.setURL( rst.getString("testurl") );
				sumTestBean.setTestFrequency( rst.getInt("frequency") );
				sumTestBean.setRequestMethod( rst.getString("request_method") );
				sumTestBean.setTestHeadFirst( rst.getBoolean("test_head_method_first") );
				sumTestBean.setRequestHeaders( JSONArray.fromObject( rst.getString("request_headers") ) );
				sumTestBean.setRequestParameters( JSONArray.fromObject( rst.getString("request_parameters") ) );
				
				// TODO Keep all Test in a ArrayList, for Update verification purpose.
				//alSUMTestBeans.add(sumTestBean);
				
				strTestFrequency = sumTestBean.getTestFrequency()+"";
				
				if( hmFreqSUMTestBeans.containsKey( strTestFrequency ) ) {
					llSUMTestBeans = hmFreqSUMTestBeans.get( strTestFrequency );
				} else {
					llSUMTestBeans = new LinkedList<SUMTestBean>();
					hmFreqSUMTestBeans.put(strTestFrequency, llSUMTestBeans);
				}
				llSUMTestBeans.add(sumTestBean);
			}
		} catch (Throwable th) {
			LogManager.errorLog(th, sbQuery);
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
	 	return hmFreqSUMTestBeans;
	}
	
	/**
	 * Get the User-Id, for the given SUM Test-Id.
	 * 
	 * @param con
	 * @param lAVMTestId
	 * @return
	 * @throws Throwable
	 */
	public long getUserId(Connection con, long lAVMTestId) throws Throwable {
		Statement stmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		long lUserId = 0;
		
		try {
			sbQuery	.append("SELECT user_id FROM avm_test_master WHERE avm_test_id = ").append(lAVMTestId);			
			
			stmt = con.createStatement();
			rst = stmt.executeQuery( sbQuery.toString() );
			
			while( rst.next() ) {
				lUserId = rst.getLong("user_id");
			}
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return lUserId;
	}
	
	/**
	 * Get the User-Id, for the given Encrypted User-Id.
	 * 
	 * @param con
	 * @param strEncryptedUserId
	 * @return
	 * @throws Throwable
	 */
	public long getUserId(Connection con, String strEncryptedUserId) throws Throwable {
		Statement stmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		long lUserId = 0;
		
		try {
			sbQuery	.append("SELECT user_id FROM usermaster WHERE encrypted_user_id = '").append(strEncryptedUserId).append("'");			
			
			stmt = con.createStatement();
			rst = stmt.executeQuery( sbQuery.toString() );
			
			while( rst.next() ) {
				lUserId = rst.getLong("user_id");
			}
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return lUserId;
	}
	
	public Object[] getUserDetails(Connection con, String strEncryptedUserId) throws Throwable {
		Statement stmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		long lUserId = 0, lEnterpriseId = 0;
		
		try {
			sbQuery	.append("SELECT user_id, enterprise_id FROM usermaster WHERE encrypted_user_id = '").append(strEncryptedUserId).append("'");			
			
			stmt = con.createStatement();
			rst = stmt.executeQuery( sbQuery.toString() );
			
			while( rst.next() ) {
				lUserId = rst.getLong("user_id");
				lEnterpriseId = rst.getLong("enterprise_id");
			}
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return new Object[]{lUserId, lEnterpriseId};
	}
	
	/**/
	public boolean isExistingAgent(Connection con, String strEncryptedUserId, String strGUID) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		boolean bExists = false;
		
		try {
			sbQuery	.append("SELECT true FROM avm_agent_master ")
					.append("WHERE user_id = ( SELECT user_id FROM usermaster WHERE encrypted_user_id = ? ) ")
					.append("AND guid = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strEncryptedUserId);
			pstmt.setString(2, strGUID);
			
			rst = pstmt.executeQuery();
			
			bExists = rst.next();
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return bExists;
	}
	
	public int updateAgentLocation(Connection con, long lUserId, String strGUID, String strCountry, String strState, String strCity, String strRegion, String strZone) throws Throwable {
		PreparedStatement pstmt = null;
		int nIns = 0;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE avm_agent_master SET ")
					.append("country = ?, state = ?, city = ?, region = ?, zone = ? ")
					.append("WHERE user_id = ? AND guid = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strCountry);
			pstmt.setString(2, strState);
			pstmt.setString(3, strCity);
			pstmt.setString(4, strRegion);
			pstmt.setString(5, strZone);
			pstmt.setLong(6, lUserId);
			pstmt.setString(7, strGUID);
			
			nIns = pstmt.executeUpdate();
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}

		return nIns;
	}
	
	public int updateLastRequestDetails(Connection con, long lUserId, String strGUID, int nRespondedTestCount, String strMACAddress, String strIPAdress) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		int nUpdates = 0;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT update_avm_agent_status_on_response(?,?,?,?,?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strGUID);
			pstmt.setString(3, strMACAddress);
			pstmt.setString(4, strIPAdress);
			pstmt.setInt(5, nRespondedTestCount);
			
			rst = pstmt.executeQuery();
			
			while(rst.next()) {
				nUpdates = rst.getInt(1);
			}
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return nUpdates;
	}
	
	/**
	 * Insert the heartbeat entry in the log table.
	 * 
	 * @param con
	 * @param lUserId
	 * @param hbRespBean
	 * @return
	 * @throws Throwable
	 */
	public int insertHeartBeatEntries(Connection con, long lUserId, HeartBeatResponseBean hbRespBean) throws Throwable {
		PreparedStatement pstmt = null;
		int nIns = 0;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("INSERT INTO sum_heartbeat_log_").append(lUserId)
					.append("(sum_test_id, user_id, testurl, country, state, city, region, zone, agent_id, guid, response_status, response_code, availability, agent_tested_on, appedo_received_on) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, (SELECT agent_id FROM avm_agent_master WHERE guid = ?), ?, ?, ?, ?, ?, ?)");
			pstmt = con.prepareStatement( sbQuery.toString() );
			
			pstmt.setLong(1, hbRespBean.getTestId() );
			pstmt.setLong(2, lUserId);
			pstmt.setString(3, hbRespBean.getTestURL());
			pstmt.setString(4, hbRespBean.getCountry());
			pstmt.setString(5, hbRespBean.getState());
			pstmt.setString(6, hbRespBean.getCity());
			pstmt.setString(7, hbRespBean.getRegion());
			pstmt.setString(8, hbRespBean.getZone());
			pstmt.setString(9, hbRespBean.getGUID());
			pstmt.setString(10, hbRespBean.getGUID());
			pstmt.setString(11, hbRespBean.getResponseStatus());
			pstmt.setInt(12, hbRespBean.getResponseCode());
			pstmt.setBoolean(13, hbRespBean.isAvailable());
			pstmt.setLong(14, hbRespBean.getAgentTestedOn());
			pstmt.setLong(15, hbRespBean.getAppedoReceivedOn());
			
			nIns = pstmt.executeUpdate();
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}

		return nIns;
	}
	
	public int updateLastResponseDetails(Connection con, long lUserId, String strGUID, long lAppedoReceivedOn, String strMACAddress, String strIPAdress) throws Throwable {
		PreparedStatement pstmt = null;
		int nIns = 0;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE avm_agent_master SET status = 'ACTIVE', last_responded_on = ?, ")
					.append("mac_address = ?, ip_address = ? ")
					.append("WHERE user_id = ? ")
					.append("AND guid = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lAppedoReceivedOn);
			pstmt.setString(2, strMACAddress);
			pstmt.setString(3, strIPAdress);
			pstmt.setLong(4, lUserId);
			pstmt.setString(5, strGUID);
			
			nIns = pstmt.executeUpdate();
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}

		return nIns;
	}

	/**
	 * Get SLA's mapped to the given SUM Test.
	 * 
	 * @param hbRespBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getSUMSLADetails(Connection con, long lTestId) throws Exception {
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joSlaSettings = null;
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		try {
			sbQuery.append("SELECT s.sla_id, s.user_id, atm.avm_test_id, min_breach_count ")
					.append("FROM so_sla s ")
					.append("INNER JOIN avm_test_master atm ON atm.sla_id = s.sla_id AND avm_test_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lTestId);
			
			rst = pstmt.executeQuery();
			if (rst.next()) {
				joSlaSettings = new JSONObject();
				
				joSlaSettings.put("sla_id", rst.getLong("sla_id"));
				joSlaSettings.put("userid", rst.getLong("user_id"));
				joSlaSettings.put("avm_test_id", rst.getLong("avm_test_id"));
				joSlaSettings.put("min_breach_count", rst.getInt("min_breach_count"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return joSlaSettings;
	}
	
	/**
	 * Get the list of Agent, which are not responding for particular time.
	 * 
	 * @param con
	 * @return
	 * @throws Throwable
	 */
	public ArrayList<HeartBeatAgent> getDownHBAgents(Connection con) throws Throwable {
		StringBuilder sbQuery = new StringBuilder();
		Statement stmt = null;
		ResultSet rst = null;
		
		ArrayList<HeartBeatAgent> alHBAgents = new ArrayList<HeartBeatAgent>();
		HeartBeatAgent hbAgent = null;
		
		try {
			sbQuery.append("SELECT * FROM get_avm_inactive_agents();");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				hbAgent = new HeartBeatAgent();
				
				hbAgent.setAgentId(rst.getLong("agent_id"));
				hbAgent.setUserId(rst.getLong("user_id"));
				hbAgent.setGUID(rst.getString("guid"));
				hbAgent.setCountry(rst.getString("country"));
				hbAgent.setState(rst.getString("state"));
				hbAgent.setCity(rst.getString("city"));
				hbAgent.setRegion(rst.getString("region"));
				hbAgent.setZone(rst.getString("zone"));
				hbAgent.setMACAddress(rst.getString("mac_address"));
				hbAgent.setIPAddress(rst.getString("ip_address"));
				hbAgent.setLastRequestedOn(rst.getLong("last_requested_on"));
				hbAgent.setLastReceivedURLCount(rst.getLong("last_received_url_cnt"));
				hbAgent.setLastRespondedOn(rst.getLong("last_responded_on"));
				
				alHBAgents.add(hbAgent);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return alHBAgents;
	}
	
	/**
	 * Mark the inactive agents as "DOWN" in `avm_agent_master` table.
	 * 
	 * @param con
	 * @param sbAgentIds
	 * @return
	 * @throws Throwable
	 */
	public int updateDownHBAgents(Connection con, StringBuilder sbAgentIds) throws Throwable{
		Statement stmt = null;
		int nUpdate = 0;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE avm_agent_master SET status = 'DOWN' ")
					.append("WHERE agent_id IN (").append(sbAgentIds).append(")");
			stmt = con.createStatement();
			
			nUpdate = stmt.executeUpdate(sbQuery.toString());
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}

		return nUpdate;
	}
	
	/**
	 * 
	 * @return
	 */
	public ArrayList< JSONObject > getSUMSLAsMappedToLocation(Connection con, long lAgentId) throws Exception {
		StringBuilder sbQuery = new StringBuilder();
		Statement stmt = null;
		ResultSet rst = null;
		
		ArrayList< JSONObject > alHBAgents = new ArrayList< JSONObject >();
		JSONObject joSlaSettings = null;
		
		try {
			sbQuery.append("SELECT * FROM get_avm_location_sum_slas(").append(lAgentId).append(")");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				joSlaSettings = new JSONObject();
				
				joSlaSettings.put("user_id", rst.getLong("user_id"));
				joSlaSettings.put("avm_test_id", rst.getLong("avm_test_id"));
				joSlaSettings.put("sla_id", rst.getLong("sla_id"));
				joSlaSettings.put("min_breach_count", rst.getLong("min_breach_count"));
				
				alHBAgents.add( joSlaSettings );
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return alHBAgents;
	}
}
