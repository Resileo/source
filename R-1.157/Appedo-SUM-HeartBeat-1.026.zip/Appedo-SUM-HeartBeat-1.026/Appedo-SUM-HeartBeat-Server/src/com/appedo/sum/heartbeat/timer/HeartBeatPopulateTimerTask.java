package com.appedo.sum.heartbeat.timer;

import java.sql.Connection;
import java.sql.SQLException;

import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.connect.DataBaseManager;
import com.appedo.sum.heartbeat.manager.HeartBeatManager;

public class HeartBeatPopulateTimerTask extends Thread {
	
	private static HeartBeatPopulateTimerTask hbResultTimerTask = null;
	
	private Connection con = null;
	
	private HeartBeatPopulateTimerTask() {
		try {
			con = DataBaseManager.giveConnection();
			con.setAutoCommit(true);
		} catch (SQLException e) {
			LogManager.errorLog(e);
		}
	}
	
	/**
	 * Start the processing Thread.
	 * This will create the Single possible object, if not available.
	 * This will start the Thread if it is not already running.
	 * 
	 * @return
	 */
	public static void startDataPopulatingThread() {
		// Create SingleTon Object, if not exists
		if( hbResultTimerTask == null ) {
			hbResultTimerTask = new HeartBeatPopulateTimerTask();
		}
		
		// Start the Thread if not already running.
		if( ! hbResultTimerTask.isAlive() ) {
			hbResultTimerTask.start();
		}
	}
	
	@Override
	public void run() {
		
		while( true ) {
			try{
				con = DataBaseManager.reEstablishConnection(con);
				con.setAutoCommit(true);
				
				HeartBeatManager.getInstance().populateAllSUMHeartBeatList(con);
				
				Thread.sleep( 60 * 1000);
			} catch (Throwable th) {
				LogManager.errorLog(th);
			}
		}
	}
	
	@Override
	protected void finalize() throws Throwable {
		DataBaseManager.close(con);
		
		super.finalize();
	}
}
