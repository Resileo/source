package com.appedo.sum.heartbeat.timer;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.connect.DataBaseManager;
import com.appedo.sum.heartbeat.manager.HeartBeatResultManager;

public class HeartBeatResultTimerTask extends Thread {
	
	private static HeartBeatResultTimerTask hbResultTimerTask = null;
	
	private Connection con = null;
	
	private HeartBeatResultTimerTask() {
		try {
			con = DataBaseManager.giveConnection();
			con.setAutoCommit(true);
		} catch (SQLException e) {
			LogManager.errorLog(e);
		}
	}
	
	/**
	 * Start the processing Thread.
	 * This will create the Single possible object, if not available.
	 * This will start the Thread if it is not already running.
	 * 
	 * @return
	 */
	public static void startProcessingThread() {
		// Create SingleTon Object, if not exists
		if( hbResultTimerTask == null ) {
			hbResultTimerTask = new HeartBeatResultTimerTask();
		}
		
		// Start the Thread if not already running.
		if( ! hbResultTimerTask.isAlive() ) {
			hbResultTimerTask.start();
		}
	}
	
	@Override
	public void run() {
		ArrayList<Object[]> alHeartBeatResults = null;
		HeartBeatResultManager hbResultManager = new HeartBeatResultManager();
		
		while( true ) {
			try{
				while( (alHeartBeatResults = HeartBeatResultManager.drainHeartBeatResults()).size() > 0 ) {
					con = DataBaseManager.reEstablishConnection(con);
					con.setAutoCommit(true);
					
					LogManager.infoLog("SUM HeartBeat drained size: "+alHeartBeatResults.size());
					hbResultManager.processHeartBeatResults(con, alHeartBeatResults);
				} 
				
				LogManager.infoLog("No results found in Queue. Going to wait... ThreadId: "+Thread.currentThread().getId());
				Thread.sleep( 5 * 1000);
			} catch (Throwable th) {
				LogManager.errorLog(th);
			}
		}
	}
	
	@Override
	protected void finalize() throws Throwable {
		DataBaseManager.close(con);
		
		super.finalize();
	}
}
