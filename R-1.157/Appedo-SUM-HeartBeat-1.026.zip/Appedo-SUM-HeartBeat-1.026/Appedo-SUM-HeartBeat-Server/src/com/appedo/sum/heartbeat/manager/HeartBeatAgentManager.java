package com.appedo.sum.heartbeat.manager;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;

import net.sf.json.JSONObject;

import com.appedo.heartbeat.model.WebServiceManager;
import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.bean.HeartBeatAgent;
import com.appedo.sum.heartbeat.common.Constants;
import com.appedo.sum.heartbeat.dbi.HeartBeatDBI;
import com.appedo.sum.heartbeat.utils.UtilsFactory;

public class HeartBeatAgentManager {
	
	private static HeartBeatAgentManager heartBeatManager = null;
	
	/**
	 * Make the Class as Singleton
	 */
	private HeartBeatAgentManager() {
	}
	
	/**
	 * Return the single Object of this class.
	 * 
	 * @return
	 */
	public static HeartBeatAgentManager getInstance() {
		if( heartBeatManager == null ) {
			heartBeatManager = new HeartBeatAgentManager();
		}
		
		return heartBeatManager;
	}
	
	public void monitorHeartBeatAgentSoul(Connection con) {
		ArrayList<HeartBeatAgent> alHBAgents = null;
		ArrayList< JSONObject > alSLAs = null;
		HeartBeatDBI heartBeatDBI = null;
		
		StringBuilder sbAgentIds = new StringBuilder();
		int nInactives = 0;
		long lAppedoReceivedOn = 0;
		
		try{
			// Get all DOWN HB/AVM agents list
			heartBeatDBI = new HeartBeatDBI();
			alHBAgents = heartBeatDBI.getDownHBAgents(con);
			
			
			// Update all the DOWN HB/AVM agents status as "DOWN"
			for(HeartBeatAgent hbAgent: alHBAgents) {
				sbAgentIds.append(hbAgent.getAgentId()).append(",");
			}
			
			if( sbAgentIds.length() > 0 ) {
				sbAgentIds.deleteCharAt( sbAgentIds.length()-1 );
				
				nInactives = heartBeatDBI.updateDownHBAgents(con, sbAgentIds);
				lAppedoReceivedOn = (new Date()).getTime();
				
				LogManager.infoLog(nInactives+" agents are marked as DOWN: "+sbAgentIds);
			}
			
			
			// Insert SLA alert for all the AVM Tests which are mapped to this location
			for(HeartBeatAgent hbAgent: alHBAgents) {
				alSLAs = heartBeatDBI.getSUMSLAsMappedToLocation(con, hbAgent.getAgentId());
				
				// Send request to SLA-Collector
				for( JSONObject joSlaSettings: alSLAs ){
					joSlaSettings.put("userid",hbAgent.getUserId());
					joSlaSettings.put("guid",hbAgent.getGUID());
					joSlaSettings.put("appedoReceivedOn",lAppedoReceivedOn);
					joSlaSettings.put("country", hbAgent.getCountry());
					joSlaSettings.put("state", hbAgent.getState());
					joSlaSettings.put("city", hbAgent.getCity());
					joSlaSettings.put("region", hbAgent.getRegion());
					joSlaSettings.put("zone", hbAgent.getZone());
					joSlaSettings.put("is_Down", true);
					joSlaSettings.put("breached_severity", "AGENT_DOWN");
					joSlaSettings.put("received_status", "Agent is not responding");
					joSlaSettings.put("received_response_code", "-2");
					
					HeartBeatResultManager.sendDowntimeDetailsToSla(joSlaSettings);	
				}
			}
			
		} catch(Throwable th) {
			LogManager.errorLog(th);
		}
	}
	
	/**/
	public static JSONObject getOrAddAgent(Connection con, String strEncryptedUserId, String strGUID, String strCountry, String strState, String strCity, String strRegion, String strZone) throws Throwable {
		Object[] oaAgent = null;
		boolean bExists = false;
		long lUserId = 0, lEnterpriseId = 0;
		JSONObject joReturn = null;
		
		HeartBeatDBI heartBeatDBI = null;
		WebServiceManager wsm = null;
		
		try{
			heartBeatDBI = new HeartBeatDBI();
			bExists = heartBeatDBI.isExistingAgent(con, strEncryptedUserId, strGUID);
			
			// if User-GUID is not there then, Add the agent
			if( bExists ) {
				return UtilsFactory.getJSONSuccessReturn("Agent already exists");
			}
			
			// Get the other required details
			oaAgent = heartBeatDBI.getUserDetails(con, strEncryptedUserId);
			
			lUserId = (long) oaAgent[0];
			lEnterpriseId = (long) oaAgent[1];
			
			// Send request to UI-AVM-Services, to create Agent-Location
			LogManager.infoLog("New GUID found for UserId "+lUserId+" <> "+strGUID+". So sending request to "+Constants.APPEDO_UI_AVM_SERVICES+Constants.AVM_ADD_AGENT_SERVLET);
			wsm = new WebServiceManager();
			
			wsm.addParameter("from_avm_controller_20160629", "true");
			wsm.addParameter("enterprise_id", lEnterpriseId+"");
			wsm.addParameter("user_id", lUserId+"");
			wsm.addParameter("country", strCountry);
			wsm.addParameter("state", strState);
			wsm.addParameter("city", strCity);
			wsm.addParameter("region", strRegion);
			wsm.addParameter("zone", strZone);
			wsm.addParameter("GUID", strGUID);
			
			wsm.sendRequest(Constants.APPEDO_UI_AVM_SERVICES+Constants.AVM_ADD_AGENT_SERVLET);
			
			if( wsm.getStatusCode() == 200 ) {
				joReturn = UtilsFactory.getJSONSuccessReturn( wsm.getResponse() );
			} else {
				joReturn = UtilsFactory.getJSONFailureReturn( wsm.getResponse() );
			}
			
			LogManager.infoLog("/avm/addAVMAgent response for "+strGUID+" : "+joReturn);
		} catch(Throwable th) {
			LogManager.errorLog(th);
		}
		
		return joReturn;
	}
	
	public static int updateAgentLocation(Connection con, long lUserId, String strGUID, String strCountry, String strState, String strCity, String strRegion, String strZone) throws Throwable {
		HeartBeatDBI heartBeatDBI = null;
		int nUpdates = 0;
		
		try{
			heartBeatDBI = new HeartBeatDBI();
			nUpdates = heartBeatDBI.updateAgentLocation(con, lUserId, strGUID, strCountry, strState, strCity, strRegion, strZone);
			
		} catch(Throwable th) {
			LogManager.errorLog(th);
		}
		
		return nUpdates;
	}
	
	/**
	 * Update the last request & response details in Agent-Master.
	 * 
	 * @param con
	 * @param strEncryptedUserId
	 * @param strLocation
	 * @return
	 * @throws Throwable
	 */
	public static int updateLastRequestOn(Connection con, long lUserId, String strGUID, int nTestCount, String strMACAddress, String strIPAdress) throws Throwable {
		HeartBeatDBI heartBeatDBI = null;
		int nUpdates = 0;
		
		try{
			heartBeatDBI = new HeartBeatDBI();
			nUpdates = heartBeatDBI.updateLastRequestDetails(con, lUserId, strGUID, nTestCount, strMACAddress, strIPAdress);
			
		} catch(Throwable th) {
			LogManager.errorLog(th);
		}
		
		return nUpdates;
	}
}
