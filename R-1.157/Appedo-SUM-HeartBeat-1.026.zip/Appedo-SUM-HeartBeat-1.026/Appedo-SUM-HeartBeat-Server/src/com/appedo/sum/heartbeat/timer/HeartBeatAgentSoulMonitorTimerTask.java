package com.appedo.sum.heartbeat.timer;

import java.sql.Connection;
import java.sql.SQLException;

import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.connect.DataBaseManager;
import com.appedo.sum.heartbeat.manager.HeartBeatAgentManager;

public class HeartBeatAgentSoulMonitorTimerTask extends Thread {
	
	private static HeartBeatAgentSoulMonitorTimerTask hbAgentSoulMonitoringTimerTask = null;
	
	private Connection con = null;
	
	public long lDelayINMilliSeconds = 0;
	
	private HeartBeatAgentSoulMonitorTimerTask(long lDelay) {
		try {
			this.lDelayINMilliSeconds = lDelay;
			
			con = DataBaseManager.giveConnection();
			con.setAutoCommit(true);
		} catch (SQLException e) {
			LogManager.errorLog(e);
		}
	}
	
	/**
	 * Start the processing Thread.
	 * This will create the Single possible object, if not available.
	 * This will start the Thread if it is not already running.
	 * 
	 * @param lDelay in MilliSeconds
	 */
	public static void startAgentSoulMonitoringThread(long lDelay) {
		// Create SingleTon Object, if not exists
		if( hbAgentSoulMonitoringTimerTask == null ) {
			hbAgentSoulMonitoringTimerTask = new HeartBeatAgentSoulMonitorTimerTask(lDelay);
		}
		
		// Start the Thread if not already running.
		if( ! hbAgentSoulMonitoringTimerTask.isAlive() ) {
			hbAgentSoulMonitoringTimerTask.start();
		}
	}
	
	@Override
	public void run() {
		// Delay the Thread's start
		// If the Tomcat is stopped for more than 3 minutes, then this Thread would mark all the Agents as DOWN.
		// So, better, delay this process for same 3 minutes.
		if( lDelayINMilliSeconds > 0 ) {
			try {
				Thread.sleep(lDelayINMilliSeconds);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		while( true ) {
			try{
				con = DataBaseManager.reEstablishConnection(con);
				con.setAutoCommit(true);
				
				HeartBeatAgentManager.getInstance().monitorHeartBeatAgentSoul(con);
				
				Thread.sleep( 60 * 1000);
			} catch (Throwable th) {
				LogManager.errorLog(th);
			}
		}
	}
	
	@Override
	protected void finalize() throws Throwable {
		DataBaseManager.close(con);
		
		super.finalize();
	}
}
