package com.appedo.sum.heartbeat.bean;

import java.util.Date;

public class HeartBeatAgent {
	
	private long lAgentId, lUserId;
	private String strGUID, strCountry = "", strState = "", strCity = "", strRegion = "", strZone = "", strMACAddress = "", strIPAddress = "";
	private Long lLastRequestedOn, lLastReceivedURLCount, lLastRespondedOn;
	
	
	public long getAgentId() {
		return lAgentId;
	}
	public void setAgentId(long lAgentId) {
		this.lAgentId = lAgentId;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public String getGUID() {
		return strGUID;
	}
	public void setGUID(String strGUID) {
		this.strGUID = strGUID;
	}
	
	public String getCountry() {
		return strCountry;
	}
	public void setCountry(String strCountry) {
		this.strCountry = strCountry;
	}
	
	public String getState() {
		return strState;
	}
	public void setState(String strState) {
		this.strState = strState;
	}
	
	public String getCity() {
		return strCity;
	}
	public void setCity(String strCity) {
		this.strCity = strCity;
	}
	
	public String getRegion() {
		return strRegion;
	}
	public void setRegion(String strRegion) {
		this.strRegion = strRegion;
	}
	
	public String getZone() {
		return strZone;
	}
	public void setZone(String strZone) {
		this.strZone = strZone;
	}
	
	public String getMACAddress() {
		return strMACAddress;
	}
	public void setMACAddress(String strMACAddress) {
		this.strMACAddress = strMACAddress;
	}
	
	public String getIPAddress() {
		return strIPAddress;
	}
	public void setIPAddress(String strIPAddress) {
		this.strIPAddress = strIPAddress;
	}
	
    public Long getLastRequestedOn() {
		return lLastRequestedOn;
	}
    public Date getLastRequestedOnDate() {
		return new Date(lLastRequestedOn);
	}
	public void setLastRequestedOn(Long lLastRequestedOn) {
		this.lLastRequestedOn = lLastRequestedOn;
	}
	
	public Long getLastReceivedURLCount() {
		return lLastReceivedURLCount;
	}
	public void setLastReceivedURLCount(Long lLastReceivedURLCount) {
		this.lLastReceivedURLCount = lLastReceivedURLCount;
	}
	
	public Long getLastRespondedOn() {
		return lLastRespondedOn;
	}
	public Date getLastRespondedOnDate() {
		return new Date(lLastRespondedOn);
	}
	public void setLastRespondedOn(Long lLastRespondedOn) {
		this.lLastRespondedOn = lLastRespondedOn;
	}
}
