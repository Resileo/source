package com.appedo.sum.heartbeat.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.appedo.heartbeat.model.WebServiceManager;
import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.connect.DataBaseManager;
import com.appedo.sum.heartbeat.dbi.HeartBeatDBI;
import com.appedo.sum.heartbeat.manager.HeartBeatAgentManager;
import com.appedo.sum.heartbeat.manager.HeartBeatManager;
import com.appedo.sum.heartbeat.manager.HeartBeatResultManager;
import com.appedo.sum.heartbeat.utils.UtilsFactory;

public class HeartBeatController extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();
		Connection con = null;
		
		if(strActionCommand.endsWith("/getHeartBeatURLs")) {
			StringBuilder sbTests = new StringBuilder();
			Object objHBResponse[] = null;
			String strEncryptedUserId = null, strGUID = null, strMACAddress = null, strIPAddress = null, strLocation = null;
			String[] saLocation = null;
			JSONObject joAgent = null;
			long lUserId = 0;
			int nTestCount = 0;
			boolean bFirstRequest = false;
			
			try {
				strEncryptedUserId = request.getParameter("user_id");
				strGUID = request.getParameter("guid");
				strMACAddress = request.getParameter("mac_address");
				strIPAddress = WebServiceManager.getClientIpAddr(request);
				strLocation = request.getParameter("location");
				bFirstRequest = ( request.getParameter("first_request") != null );
				
				// Location should come as country#state#city#region#zone
				saLocation = strLocation.split("#", -1);
				
				con = DataBaseManager.giveConnection();
				
				// Add new Agent, if new GUID is found. This is done on the very-first request from the agent.
				if( bFirstRequest ) {
					joAgent = HeartBeatAgentManager.getOrAddAgent(con, strEncryptedUserId, strGUID, saLocation[0], saLocation[1], saLocation[2], saLocation[3], saLocation[4]);
				}

				// Not first request from Agent (or) new Agent added successfully.
				if( ! bFirstRequest || joAgent.getBoolean("success") ) {
					
					if( strEncryptedUserId == null ) {
						sbTests = HeartBeatManager.getInstance().getAllHearBeatTests();
						
						// Considering the agent as Global one, so user as SYSAdmin.
						lUserId = 1;
					} else {
						objHBResponse = HeartBeatManager.getInstance().getAllHearBeatTests(con, strEncryptedUserId, saLocation[0], saLocation[1], saLocation[2], saLocation[3], saLocation[4]);
						sbTests = (StringBuilder)objHBResponse[0];
						lUserId = (long)objHBResponse[1];
						nTestCount = (int)objHBResponse[2];
					}
					
					// Update the location, on first request from the agent.
					if( bFirstRequest ) {
						HeartBeatAgentManager.updateAgentLocation(con, lUserId, strGUID, saLocation[0], saLocation[1], saLocation[2], saLocation[3], saLocation[4]);
					}
					
					HeartBeatAgentManager.updateLastRequestOn(con, lUserId, strGUID, nTestCount, strMACAddress, strIPAddress);
				} else {
					sbTests.append( joAgent );
				}
			} catch(Throwable th) {
				LogManager.errorLog(th);
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(sbTests.toString());
			}
		}
		// Receive the HeartBeat list from agent and Queue it.
		else if(strActionCommand.endsWith("/collectHeartBeatResult")) {
			String strEncryptedUserId = null, strGUID = null, strMACAddress = null, strIPAddress = null, strHeartBeatResults = null;
			long lUserId = 0;
			JSONObject joReturn = null;
			
			HeartBeatDBI hbDBI = null;
			
			try {
				strEncryptedUserId = request.getParameter("user_id");
				strGUID = request.getParameter("guid");
				strMACAddress = request.getParameter("mac_address");
				strIPAddress = WebServiceManager.getClientIpAddr(request);
				//strLocation = request.getParameter("location");
				strHeartBeatResults = request.getParameter("heartbeat_results");
				
				con = DataBaseManager.giveConnection();
				
				// Queue the received array with received Time.
				HeartBeatResultManager.queueHeartBeatResults( new Object[]{strHeartBeatResults, new Date().getTime()} );
				
				hbDBI = new HeartBeatDBI();
				
				lUserId = hbDBI.getUserId(con, strEncryptedUserId);
				
				// Update the Agent's last-response details
				hbDBI.updateLastResponseDetails(con, lUserId, strGUID, (new Date()).getTime(), strMACAddress, strIPAddress);
				
				joReturn = UtilsFactory.getJSONSuccessReturn("Data is queued.");
			} catch(Throwable th) {
				LogManager.errorLog(th);
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joReturn.toString());
			}
		}
	}
}
