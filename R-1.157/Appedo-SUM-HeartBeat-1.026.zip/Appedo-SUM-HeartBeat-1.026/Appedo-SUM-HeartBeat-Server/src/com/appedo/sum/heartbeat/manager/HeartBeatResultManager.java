package com.appedo.sum.heartbeat.manager;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.heartbeat.model.WebServiceManager;
import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.bean.HeartBeatResponseBean;
import com.appedo.sum.heartbeat.common.Constants;
import com.appedo.sum.heartbeat.dbi.HeartBeatDBI;

public class HeartBeatResultManager {

	// private static HeartBeatResultManager hbResultManager = null;
	
	private static LinkedBlockingQueue<Object[]> qHeartBeatResults = new LinkedBlockingQueue<Object[]>();
	
	/**
	 * Make the Class as Singleton
	 *
	private HeartBeatResultManager() {
	}
	*/
	
	/*
	public static HeartBeatResultManager getInstance() {
		if( hbResultManager == null ) {
			hbResultManager = new HeartBeatResultManager();
		}
		
		return hbResultManager;
	}
	*/
	
	public static void queueHeartBeatResults(Object[] oaHeartBeatResults) {
		qHeartBeatResults.add(oaHeartBeatResults);
	}
	
	public static ArrayList<Object[]> drainHeartBeatResults() {
		ArrayList<Object[]> alHeartBeatResults = new ArrayList<Object[]>();
		
		qHeartBeatResults.drainTo(alHeartBeatResults, 100);
		
		return alHeartBeatResults;
	}
	
	public static long getHeartBeatQueueSize() {
		return qHeartBeatResults.size();
	}
	
	public void processHeartBeatResults(Connection con, ArrayList<Object[]> alHeartBeatResults) {
		JSONArray jaHeartBeatResults = null;
		JSONObject joHeartBeatResult = null;
		
		HeartBeatResponseBean hbRespBean = null;
		HeartBeatDBI hbDBI = null;
		
		Object[] oaHeartBeatResponse = null;
		long lUserId = 0;
		
		try{
			hbDBI = new HeartBeatDBI();
			
			for(int idxMultipleResults = 0; idxMultipleResults <alHeartBeatResults.size(); idxMultipleResults++) {
				oaHeartBeatResponse = alHeartBeatResults.get(idxMultipleResults);
				
				jaHeartBeatResults = JSONArray.fromObject( oaHeartBeatResponse[0] );
				
				for(int idxResults = 0; idxResults < jaHeartBeatResults.size(); idxResults++ ) {
					joHeartBeatResult = jaHeartBeatResults.getJSONObject(idxResults);
					joHeartBeatResult.put("appedoReceivedOn", oaHeartBeatResponse[1]);
					
					// adds location parts, as country, state, city, region, zone    
					addLocationParts(joHeartBeatResult.getString("location"), joHeartBeatResult);
					
					hbRespBean = (HeartBeatResponseBean) JSONObject.toBean(joHeartBeatResult, HeartBeatResponseBean.class);
					
					lUserId = hbDBI.getUserId(con, hbRespBean.getTestId());
					
					try{
						insertHeartBeatEntries(con, lUserId, hbRespBean);
					} catch(Throwable th) {
						LogManager.errorLog("Exception while inserting HeartBeat entries.");
						LogManager.errorLog(th);
					}
				}
			}
		} catch(Throwable th) {
			LogManager.errorLog(th);
		}
	}
	
	public void insertHeartBeatEntries(Connection con, long lUserId, HeartBeatResponseBean hbRespBean) throws Throwable {
		HeartBeatDBI hbDBI = null;
		JSONObject joSlaSettings = null;
		
		try {
			hbDBI = new HeartBeatDBI();
			
			// Insert the HeartBeat entries
			hbDBI.insertHeartBeatEntries(con, lUserId, hbRespBean);
			
			// If URL is not [properly] available then, call SLA insert
			if (!hbRespBean.isAvailable()) {
				joSlaSettings = hbDBI.getSUMSLADetails(con, hbRespBean.getTestId());
				
				if(joSlaSettings != null){
					joSlaSettings.put("guid", hbRespBean.getGUID());
					joSlaSettings.put("country", hbRespBean.getCountry());
					joSlaSettings.put("state", hbRespBean.getState());
					joSlaSettings.put("city", hbRespBean.getCity());
					joSlaSettings.put("region", hbRespBean.getRegion());
					joSlaSettings.put("zone", hbRespBean.getZone());
					joSlaSettings.put("received_status", hbRespBean.getResponseStatus());
					joSlaSettings.put("received_response_code", hbRespBean.getResponseCode());
					joSlaSettings.put("appedoReceivedOn",hbRespBean.getAppedoReceivedOn());
					joSlaSettings.put("is_Down", true);
					joSlaSettings.put("breached_severity", "WEBSITE_UNREACHABLE");
					
					// call SLA insert
					sendDowntimeDetailsToSla(joSlaSettings);
				} else {
					LogManager.errorLog("Unable to find SLA for HBRespBean: "+hbRespBean);
				}
			}
		} catch (Throwable th) {
			LogManager.errorLog(th);
			throw th;
		}
	}

	public static void sendDowntimeDetailsToSla(JSONObject joSlaSettings) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		try {
			// send to SLA collector, by web service request
			wsm = new WebServiceManager();
			wsm.addParameter("command", "collectAVMBreaches");
			wsm.addParameter("avmBreachSet", joSlaSettings.toString());
			
			wsm.sendRequest(Constants.APPEDO_SLA_COLLECTOR);
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {		// Success
				joResp = JSONObject.fromObject(wsm.getResponse());
			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {												// Success
				LogManager.infoLog("Downtime details sent to sla collector.");
			} else {																			// exception in SLA
				throw new Exception("Unable to send Downtime details to sla collector.");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	/**
	 * adds location parts, as country, state, city, region, zone
	 * DON'T use joResult = null, obj. by ref
	 * 
	 * @param strLocation
	 * @param joResult
	 * @throws Exception
	 */
	public static void addLocationParts(String strLocation, JSONObject joResult) throws Exception {
		String[] saLocation = null;
		
		try {
			saLocation = strLocation.split("#", -1);
			
			joResult.put("country", saLocation[0]);
			joResult.put("state", saLocation[1]);
			joResult.put("city", saLocation[2]);
			joResult.put("region", saLocation[3]);
			joResult.put("zone", saLocation[4]);
		} catch (Exception e) {
			throw e;
		}
	}
}
