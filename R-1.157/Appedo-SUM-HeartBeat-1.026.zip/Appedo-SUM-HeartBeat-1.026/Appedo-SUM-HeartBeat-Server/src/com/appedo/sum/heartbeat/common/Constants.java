package com.appedo.sum.heartbeat.common;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import net.sf.json.JSONObject;

import com.appedo.manager.LogManager;
import com.appedo.sum.heartbeat.utils.UtilsFactory;

/**
 * This class holds the application level variables which required through the application.
 * 
 * @author navin
 *
 */
public class Constants {
	
	//public final static String CONFIGFILEPATH = InitServlet.realPath+"/WEB-INF/classes/com/softsmith/floodgates/resource/config.properties";
	public static String CONSTANTS_FILE_PATH = "";
	
	public static String RESOURCE_PATH = "";
	
	public static String APPEDO_CONFIG_FILE_PATH = "";
	public static String SMTP_MAIL_CONFIG_FILE_PATH = "";
	
	public static String PATH = ""; 
	
	//log4j properties file path
	public static String LOG4J_PROPERTIES_FILE = "";
	
	public static int TEST_PER_MINUTE_IN_AGENT = 500;
	public static String APPEDO_SLA_COLLECTOR = null;
	public static String APPEDO_UI_AVM_SERVICES = null;
	public static String AVM_ADD_AGENT_SERVLET = null;
	
	public static int THREE_MINUTE_MILLISECONDS = 3*60*1000;
	
	/**
	 * Loads constants properties 
	 * 
	 * @param srtConstantsPath
	 */
	public static void loadConstantsProperties(String srtConstantsPath) throws Exception {
    	Properties prop = new Properties();
    	InputStream is = null;

        try {
    		is = new FileInputStream(srtConstantsPath);
    		prop.load(is);

     		// Appedo application's resource directory path
     		RESOURCE_PATH = prop.getProperty("RESOURCE_PATH");

     		APPEDO_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("APPEDO_CONFIG_FILE_PATH");
     		PATH = RESOURCE_PATH+prop.getProperty("Path");

     		// Mail configuration 
     		SMTP_MAIL_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("SMTP_MAIL_CONFIG_FILE_PATH");

     		LOG4J_PROPERTIES_FILE = RESOURCE_PATH+prop.getProperty("LOG4J_CONFIG_FILE_PATH");
        } catch(Throwable th) {
        	System.out.println("Exception in loadConstantsProperties: "+th.getMessage());
			th.printStackTrace();

			LogManager.errorLog(th);

        	throw th;
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        }
	}
	
	/**
	 * Loads appedo config properties, from the system specifed path, 
	 * (Note.. loads other than db related)
	 *
	 * @param strAppedoConfigPath
	 */
	public static void loadAppedoConfigProperties(String strAppedoConfigPath) throws Exception {
    	Properties prop = new Properties();
    	InputStream is = null;

    	JSONObject joAppedoCollector = null;

        try {
    		is = new FileInputStream(strAppedoConfigPath);
    		prop.load(is);

    		TEST_PER_MINUTE_IN_AGENT = Integer.parseInt( UtilsFactory.replaceNull(prop.getProperty("TEST_PER_MINUTE_IN_AGENT"), "500") );
    		APPEDO_SLA_COLLECTOR = prop.getProperty("APPEDO_SLA_COLLECTOR");
    		APPEDO_UI_AVM_SERVICES = prop.getProperty("AVM_UI_SERVICES");
    		AVM_ADD_AGENT_SERVLET = prop.getProperty("AVM_ADD_AGENT_SERVLET");
        } catch(Exception e) {
        	LogManager.errorLog(e);
        	throw e;
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        	UtilsFactory.clearCollectionHieracy(joAppedoCollector);
        	joAppedoCollector = null;
        }
	}
}
