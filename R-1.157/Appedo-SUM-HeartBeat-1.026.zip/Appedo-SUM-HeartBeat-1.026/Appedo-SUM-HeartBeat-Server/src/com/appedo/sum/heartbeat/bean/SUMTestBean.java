package com.appedo.sum.heartbeat.bean;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class SUMTestBean {
	
	private long lTestId;
	private int nTestFrequency;
	private String strURL;
	private String strRequestMethod;
	private boolean bTestHeadFirst = true;
	private JSONArray jaRequestHeaders;
	private JSONArray jaRequestParameters;
	
	public long getTestId() {
		return lTestId;
	}
	public void setTestId(long lTestId) {
		this.lTestId = lTestId;
	}
	
	public int getTestFrequency() {
		return nTestFrequency;
	}
	public void setTestFrequency(int nTestFrequency) {
		this.nTestFrequency = nTestFrequency;
	}
	
	public String getURL() {
		return strURL;
	}
	public void setURL(String strURL) {
		this.strURL = strURL;
	}
	
	public String getRequestMethod() {
		return strRequestMethod;
	}
	public void setRequestMethod(String strRequestMethod) {
		this.strRequestMethod = strRequestMethod;
	}
	
	public boolean isTestHeadFirst() {
		return bTestHeadFirst;
	}
	public void setTestHeadFirst(boolean bTestHeadFirst) {
		this.bTestHeadFirst = bTestHeadFirst;
	}
	
	public JSONArray getRequestHeaders() {
		return jaRequestHeaders;
	}
	public void setRequestHeaders(JSONArray jaRequestHeaders) {
		this.jaRequestHeaders = jaRequestHeaders;
	}
	
	public JSONArray getRequestParameters() {
		return jaRequestParameters;
	}
	public void setRequestParameters(JSONArray jaRequestParameters) {
		this.jaRequestParameters = jaRequestParameters;
	}
	
	public JSONObject toJSON() {
		JSONObject joAVMTest = new JSONObject();
		
		joAVMTest.put("URL", strURL);
		joAVMTest.put("testId", lTestId);
		joAVMTest.put("testFrequency", nTestFrequency);
		joAVMTest.put("requestMethod", strRequestMethod);
		joAVMTest.put("testHeadFirst", bTestHeadFirst);
		joAVMTest.put("requestHeaders", jaRequestHeaders);
		joAVMTest.put("requestParameters", jaRequestParameters);
		
		return joAVMTest;
	}
	
	@Override
	public String toString() {
		return this.toJSON().toString();
	}
}
