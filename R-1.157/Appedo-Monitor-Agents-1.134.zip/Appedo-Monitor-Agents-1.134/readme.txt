# build file execution
# build.xml is the main build file

# While running the build.xml from the windows command line we have to mention like below:

# Changed to the build.xml location

ant -D1=arg1 -D2=arg2

Here arg1="Specification-Version"
     arg2="Implementation-Version"

(Pre-requisite is ANT should be configured in the Windows/Linux machine)