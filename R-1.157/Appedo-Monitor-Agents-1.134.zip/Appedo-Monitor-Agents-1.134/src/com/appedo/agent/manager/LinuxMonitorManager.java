package com.appedo.agent.manager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.agent.bean.AgentCounterBean;
import com.appedo.agent.bean.SlaCounterBean;
import com.appedo.agent.utils.Constants;
import com.appedo.agent.utils.Constants.AGENT_TYPE;

/**
 * Linux OS monitoring class. This has the functionalities to get the counter values of Linux OS.
 * 
 * @author veeru
 *
 */
public class LinuxMonitorManager extends AgentManager {
	
	public static LinuxMonitorManager linuxMonitorManager = null;
	
	private ProcessBuilder pbProcStat = null;
	private ProcessBuilder pbTopProcStat = null;
	
	/**
	 * Avoid the object creation for this Class from outside.
	 */
	private LinuxMonitorManager() {
		
		pbProcStat = new ProcessBuilder("bash", "-c", "tail /proc/stat | grep '^cpu '");
		
	}
	
	/**
	 * Returns the only object(singleton) of this Class.
	 * 
	 * @return
	 */
	public static LinuxMonitorManager getLinuxMonitorManager(){
		if( linuxMonitorManager == null ){
			linuxMonitorManager = new LinuxMonitorManager();
		}
		
		return linuxMonitorManager;
	}
	
	/**
	 * Monitor the server and collect the counters
	 */
	public void monitorLinuxServer(){
		getCounters();
	}
	
	/**
	 * Send it to the Collector WebService
	 */
	public void sendLinuxCounters(){
		sendCounters();
	}
	
	/**
	 * Collect the counter with agent's types own logic or native methods
	 * 
	 */
	public void getCounters(){
		
		int nCounterId ;
		String query = "", topProcessQuery = "", strTopProc_Mem_IO = "", line = null;
		StringBuilder sbErrors = null;
		boolean bIsDelta = false, bDoTopProcess = false, bIsTopProcess = false, is_static_counter = false;
		Double dCounterValue = 0.0;
		
		Process pProcstat = null;
		InputStreamReader isrProcstat = null;
		BufferedReader rProcstat = null;
		
		JSONObject joSelectedCounter = null;
		ArrayList<JSONObject> alSLACounters = null;
		
		try {
		
			// reset the counter collector variable in AgentManager.
			resetCounterMap(Constants.LINUX_AGENT_GUID);
			JSONArray joSelectedCounters = AgentCounterBean.getJoCountersBean(Constants.LINUX_AGENT_GUID);
			for(int i=0; i<joSelectedCounters.size(); i++){
				
				dCounterValue = 0.0;
				nCounterId = 0;
				query = "";
				bDoTopProcess = false;
				
				joSelectedCounter = joSelectedCounters.getJSONObject(i);			
				nCounterId = Integer.parseInt(joSelectedCounter.getString("counter_id")) ;
				query = joSelectedCounter.getString("query");
				bIsDelta = joSelectedCounter.getBoolean("isdelta");
				// Get the check top cpu/mem/io 
				bIsTopProcess = joSelectedCounter.getBoolean("isTopProcess");
				//strExecutionType = joSelectedCounter.getString("executiontype");
				bDoTopProcess = bIsTopProcess && joSelectedCounter.containsKey("top_process_query");
				is_static_counter = joSelectedCounter.getBoolean("isStaticCounter");
				
				if(bDoTopProcess){
					topProcessQuery = joSelectedCounter.getString("top_process_query");
					query = query+";"+topProcessQuery;
				}
	
				if (!is_static_counter || is_first) {
				//Make a process to execute counter query
				pbProcStat = new ProcessBuilder("bash", "-c", query);
				
				//strTopProc_Mem_IO = getTopProcess();
				
				/**
				 * calculate System CPU 
				 */
				try{
					pProcstat = pbProcStat.start();
					isrProcstat = new InputStreamReader(pProcstat.getInputStream());
					rProcstat = new BufferedReader(isrProcstat);
					
					// only one line should get returned. So used IF instead of WHILE
					if ((line = rProcstat.readLine()) != null) {
						
						dCounterValue = Double.parseDouble(line);
						if(bDoTopProcess) {
	
							strTopProc_Mem_IO = formatTopProcess(rProcstat);
	
							addTopProcessCounter(nCounterId+"_TOP", strTopProc_Mem_IO);
							
							addCounterValue(nCounterId, dCounterValue);
						} else {
							if(bIsDelta) {
								dCounterValue = addDeltaCounterValue(nCounterId, dCounterValue);					
							}else {
								addCounterValue(nCounterId, dCounterValue);
							}
						}
						
						// Update latest value if the counter is used as Denominator in SLA alert calculation
						updateQuickViewCounterValues(nCounterId, dCounterValue);
						
						// If is_first then send the counter_id's of static counters to collector
						if(is_first && is_static_counter){
							updateStaticCounterIds(nCounterId);
						}
					}
					
					
					sbErrors = getErrorString( pProcstat.getErrorStream() );
					if( sbErrors.length() > 0 ) {
						System.out.println("Command execution failed: "+query);
						System.out.println(sbErrors);
						System.out.println();
					}
				} catch(Throwable th) {
					System.out.println("Exception in getLinuxCounters-CPU: "+th.getMessage());
					th.printStackTrace();
					reportCounterError(nCounterId, th.getMessage());
				} finally {
					try{
						rProcstat.close();
					} catch(Exception e) {
						System.out.println("Exception in rProcstat.close(): "+e.getMessage());
						e.printStackTrace();
					}
					rProcstat = null;
					try{
						isrProcstat.close();
					} catch(Exception e) {
						System.out.println("Exception in isrProcstat.close(): "+e.getMessage());
						e.printStackTrace();
					}
					isrProcstat = null;
					try{
						pProcstat.destroy();
					} catch(Exception e) {
						System.out.println("Exception in pIostat.destroy(): "+e.getMessage());
						e.printStackTrace();
					}
					pProcstat = null;
				}
			  }
			}
	
			// Check sla breach after monitoring all the configured counters
			for (int i = 0; i < joSelectedCounters.size(); i++) {
				joSelectedCounter = null;
				alSLACounters = null;
				nCounterId = 0;
				dCounterValue = 0.0;
	
				joSelectedCounter = joSelectedCounters.getJSONObject(i);
				nCounterId = Integer.parseInt(joSelectedCounter.getString("counter_id"));
				is_static_counter = joSelectedCounter.getBoolean("isStaticCounter");
				
				if (is_static_counter) {
					// If it static counters get value from Hash reference, 
					// because it is not being monitored for each twenty seconds.
					dCounterValue = hmQuickViewCounterValues.get(joSelectedCounter.getString("counter_id"));
				}else{
					dCounterValue = (Double) hmCounters.get(joSelectedCounter.getString("counter_id"));
				}
				
				alSLACounters = verifySLABreach(Constants.LINUX_AGENT_GUID, SlaCounterBean.getSLACountersBean(Constants.LINUX_AGENT_GUID), nCounterId, dCounterValue);
				
				// If breached then add it to Collector's collection
				addSlaCounterValue(alSLACounters);
			}
		} catch (Throwable e) {
			System.out.println("Exception in getLinuxCounters: "+e.getMessage());
			e.printStackTrace();
			reportGlobalError(e.getMessage());
		} finally {
			// queue the counter
			try {
				queueCounterValues();
			} catch (Exception e1) {
				System.out.println("Exception in queueCounterValues(): "+e1.getMessage());
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * This is to get the top 3 cpu process 
	 * @return
	 */
	public String getTopProcess() {
		
		Process pProcstat = null;
		InputStreamReader isrProcstat = null;
		BufferedReader rProcstat = null;
		
		JSONObject joTopProcess = null; 
		JSONArray jaTopProcess = new JSONArray();
		JSONObject joResult = new JSONObject(); 
		String line = null;
		
		try {
			
			pbTopProcStat = new ProcessBuilder("bash", "-c", Constants.TOP_PROCESS_QUERY);
			
			pProcstat = pbTopProcStat.start();
			isrProcstat = new InputStreamReader(pProcstat.getInputStream());
			rProcstat = new BufferedReader(isrProcstat);
			
			while ( (line = rProcstat.readLine()) != null ) {
				joTopProcess = new JSONObject();
				
				joTopProcess.put("category", line.trim().split("#@#")[0].trim());
				joTopProcess.put("process_value", line.trim().split("#@#")[1].trim());
				joTopProcess.put("process_name", line.trim().split("#@#")[2].trim());
				
				jaTopProcess.add(joTopProcess);
			}
			joResult.put("TOP", jaTopProcess.toString());
			
		}catch(Exception e) {
			System.out.println("Exception in getTopProcess() : "+ e.getMessage());
			e.printStackTrace();
			
		}finally {
			
			try{
				rProcstat.close();
			} catch(Exception e) {
				System.out.println("Exception in rProcstat.close(): "+e.getMessage());
				e.printStackTrace();
			}
			rProcstat = null;
			try{
				isrProcstat.close();
			} catch(Exception e) {
				System.out.println("Exception in isrProcstat.close(): "+e.getMessage());
				e.printStackTrace();
			}
			isrProcstat = null;
			try{
				pProcstat.destroy();
			} catch(Exception e) {
				System.out.println("Exception in pIostat.destroy(): "+e.getMessage());
				e.printStackTrace();
			}
			pProcstat = null;		
			
		}
		return joResult.toString();
		
	}
	
	/**
	 * This is to get the top 3 cpu process 
	 * @return
	 */
	public String formatTopProcess(BufferedReader rProcstat) {
		
		JSONObject joTopProcess = null; 
		JSONArray jaTopProcess = new JSONArray();
		JSONObject joResult = new JSONObject(); 
		String line = null;
		
		try {
			while ( (line = rProcstat.readLine()) != null ) {
					joTopProcess = new JSONObject();
					String strTopProcess[] = new String[3];
					strTopProcess = line.replaceAll(" ", "").split("#@#");
					joTopProcess.put("category",strTopProcess[0]);
					joTopProcess.put("process_value", strTopProcess[1]);
					joTopProcess.put("process_name", strTopProcess[2]);
					
					jaTopProcess.add(joTopProcess);
				}
			joResult.put("TOP", jaTopProcess.toString());
			
		}catch(Exception e) {
			System.out.println("Exception in formatTopProcess() : "+ e.getMessage());
			e.printStackTrace();
			
		}finally {
			try{
				rProcstat.close();
			} catch(Exception e) {
				System.out.println("Exception in rProcstat.close(): "+e.getMessage());
				e.printStackTrace();
			}
			rProcstat = null;
		}
		return joResult.toString();
		
	}
	
	/**
	 * Send the collected counter-sets to Collector WebService, by calling parent's sendCounter method
	 */
	public void sendCounters() {
		
		// send the collected counters to Collector WebService through parent sender function
		sendCounterToCollector(Constants.LINUX_AGENT_GUID, AGENT_TYPE.LINUX);
		sendSlaCounterToCollector(Constants.LINUX_AGENT_GUID,AGENT_TYPE.LINUX);
	}
	
	
	private StringBuilder getErrorString(InputStream errorStream) {
		InputStreamReader isrError = null;
		BufferedReader rError = null;
		String line = null;
		StringBuilder sbError = new StringBuilder();
		
		try{
			isrError = new InputStreamReader(errorStream);
			rError = new BufferedReader(isrError);
			sbError.setLength(0);
			while ((line = rError.readLine()) != null) {
				sbError.append(line).append("\n");
			}
			if( sbError.length() > 0 ){
				sbError.deleteCharAt(sbError.length()-1);
			}
		} catch ( Exception e ) {
			System.out.println("Exception in getErrorString: "+e.getMessage());
			e.printStackTrace();
		} finally {
			try{
				isrError.close();
			} catch(Exception e) {
				System.out.println("Exception in isrError.close(): "+e.getMessage());
				e.printStackTrace();
			}
			isrError = null;
			try{
				rError.close();
			} catch(Exception e) {
				System.out.println("Exception in rError.destroy(): "+e.getMessage());
				e.printStackTrace();
			}
			rError = null;
		}
		
		return sbError;
	}
	
	@Override
	protected void finalize() throws Throwable {
		clearCounterMap();
		
		super.finalize();
	}
	
	public static void main(String[] args) {
		System.out.println( (1.2d < 49l) );
	}
}
