package com.appedo.agent.manager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.agent.bean.AgentCounterBean;
import com.appedo.agent.bean.SlaCounterBean;
import com.appedo.agent.connect.OracleConnector;
import com.appedo.agent.utils.Constants;
import com.appedo.agent.utils.Constants.AGENT_TYPE;
import com.appedo.agent.utils.UtilsFactory;


public class OracleMonitorManager extends AgentManager {
	
	public static OracleMonitorManager OracleMonitorManager = null;
	
	private Connection con = null;
	
	double lCounterValue = 0l;
	
	/**
	 * Avoid the object creation for this Class from outside.
	 */
	private OracleMonitorManager() {
	}
	
	/**
	 * Returns the only object(singleton) of this Class.
	 * 
	 * @return
	 */
	public static OracleMonitorManager getOracleMonitorManager(){
		if( OracleMonitorManager == null ){
			OracleMonitorManager = new OracleMonitorManager();
		}
		
		return OracleMonitorManager;
	}
	
	/**
	 * Monitor the server and collect the counters
	 */
	public void monitorOracleServer(String strGUID,String strDbName){
			getCounters(strGUID,strDbName);
	}
	
	/**
	 * Send it to the Collector WebService
	 */
	public void sendOracleCounters(String strGUID){
		sendCounters(strGUID);
	}
	
	/**
	 * Collect the counter with agent's types own logic or native methods
	 */
	public void getCounters(String strGUID,String strDbName){
		
		int nCounterId ;		
		Statement stmt = null;
		ResultSet rst = null;
		Statement stmtSlowQry = null;
		ResultSet rstSlowQry = null;
		String query = null;
		// create variable's to capture execution_type & is_delta
		boolean bIsDelta = false;
		//String strExecutionType = "";

		StringBuilder sbSlowQuery = null;
		
		try{
			// reset the counter collector variable in AgentManager.
			resetCounterMap(strGUID);
			
			// Singleton Connection will be returned. If that is not exists or expired then, Recreate the connection.
			con = OracleConnector.getmyOracleConnector(strDbName).getConnetion(strDbName);
			
			stmt = con.createStatement();
			JSONArray joSelectedCounters = AgentCounterBean.getJoCountersBean(strGUID);
			//System.out.println("joSelectedCounters : " + joSelectedCounters.toString());
			
			for(int i=0; i<joSelectedCounters.size(); i++){
				lCounterValue = 0l;
				query = null;
				
				JSONObject joSelectedCounter = joSelectedCounters.getJSONObject(i);				
				nCounterId = Integer.parseInt(joSelectedCounter.getString("counter_id"));
				// added prefix `QUERY_COMMENT_PREFIX`, since in slow query log, to avoid APPEDO queries used for monitoring
				query = Constants.QUERY_COMMENT_PREFIX+joSelectedCounter.getString("query");
				bIsDelta = joSelectedCounter.getBoolean("isdelta");
				//strExecutionType = joSelectedCounter.getString("executiontype");
				
				// get execution type & is_delta
				
				if(query.contains("#DB_NAME#")) {
					query = query.replace("#DB_NAME#", strDbName);
				}
				
				rst = stmt.executeQuery(query);
				while ( rst.next() ){
					
					lCounterValue = Double.parseDouble((rst.getString(1)));
					
					if(bIsDelta) {
						lCounterValue = addDeltaCounterValue(nCounterId, lCounterValue);
					}else {
						addCounterValue(nCounterId, lCounterValue);
					}
					// TODO: Static Counter correction required.

	            	// Verify SLA Breach
					// JSONObject joSLACounter = null;
					ArrayList<JSONObject> joSLACounter = null; // Need to change variable name as alSLACounters
					joSLACounter = verifySLABreach(strGUID, SlaCounterBean.getSLACountersBean(strGUID), nCounterId, lCounterValue);
					
					// if breached then add it to Collector's collection
					if( joSLACounter != null ) {
						addSlaCounterValue(joSLACounter);
					}
				}
			}
			
			// Get the slow queries
			JSONObject joSlowQry = new JSONObject();
			JSONObject joQry = null;
			JSONArray  jaSlowQry = new JSONArray();
			
			if(checkSqlAreaView(con)){
				sbSlowQuery = new StringBuilder();
				stmtSlowQry = con.createStatement();
				
				// added prefix `QUERY_COMMENT_PREFIX`, since in slow query log, to avoid APPEDO queries used for monitoring
				sbSlowQuery	.append(Constants.QUERY_COMMENT_PREFIX)
							.append("SELECT * FROM ( ")
							.append("  SELECT sql_fulltext, round((a.elapsed_time/1000/a.executions),2) elapsedtime, a.executions ")
							.append("  FROM v$sqlarea a ")
							.append("  WHERE sql_fulltext NOT LIKE '").append(Constants.QUERY_COMMENT_PREFIX).append("%' ")
							.append("  ORDER BY 2 DESC ")
							.append(") WHERE executions > 0 and rownum <= 10 ");
				rstSlowQry = stmtSlowQry.executeQuery(sbSlowQuery.toString());
				while ( rstSlowQry.next() ){
					joQry = new JSONObject();					
					joQry.put("query", rstSlowQry.getString("SQL_FULLTEXT").replaceAll("'", ""));
					joQry.put("calls", rstSlowQry.getInt("EXECUTIONS"));
					joQry.put("duration_ms", rstSlowQry.getInt("ELAPSEDTIME"));
					jaSlowQry.add(joQry);
				}
				joSlowQry.put("1001", strGUID);// guid
				joSlowQry.put("slowQueries", jaSlowQry.toString());// all queries
				addSlowQryCounterValue(joSlowQry.toString());
			} else {
				throw new Exception("Oracle Slow query table does not have permission (or) not configuered.");
			}
		} catch(Throwable th) {
			System.out.println("Exception in monitorMyOracleServer: "+th.getMessage());
			th.printStackTrace();
			reportGlobalError(th.getMessage());
		} finally {
			// queue the counter
			try {
				queueCounterValues();
			} catch (Exception e) {
				System.out.println("Exception in queueCounterValues(): "+e.getMessage());
				e.printStackTrace();
			}
			OracleConnector.close(rst);
			rst = null;
			OracleConnector.close(stmtSlowQry);
			stmtSlowQry = null;
			OracleConnector.close(stmt);
			stmt = null;

			UtilsFactory.clearCollectionHieracy(sbSlowQuery);
			sbSlowQuery = null;
		}
		
	}
	
	public boolean checkSqlAreaView(Connection con) {
		Statement stmtQry = null;
		
		/**
		 * user_views - All views owned by Current-User.
		 * all_views - All views accessible to the current user. Means, except "sys" user's views.
		 * dba_views - All views in the database, including "sys" user's views.
		 */
		// added prefix to avoid in slow query log
		String strQry = Constants.QUERY_COMMENT_PREFIX+"SELECT count(*) as isExists FROM dba_views where view_name = 'V_$SQLAREA'";
		ResultSet rstQry = null;
		boolean bReturn = false;
		
		try {
			stmtQry = con.createStatement();
			rstQry = stmtQry.executeQuery(strQry);
			if(rstQry.next()){
				bReturn = rstQry.getInt("isExists")>0;
			}	
		}catch(Exception e) {
			System.out.println("Exception in checkSqlAreaView :" + e.getMessage());
		}finally {
			OracleConnector.close(rstQry);
			rstQry = null;
			OracleConnector.close(stmtQry);
			stmtQry = null;
		}
		return bReturn;
	}
	
	/**
	 * Send the collected counter-sets to Collector WebService, by calling parent's sendCounter method
	 */
	public void sendCounters(String strGUID) {
		
		// send the collected counters to Collector WebService through parent sender function
		sendCounterToCollector(strGUID, AGENT_TYPE.ORACLE);
		sendSlowQryToCollector(strGUID,AGENT_TYPE.ORACLE);
		sendSlaCounterToCollector(strGUID,AGENT_TYPE.ORACLE);
	}
	
	
	private String getErrorString(InputStream errorStream) {
		InputStreamReader isrError = null;
		BufferedReader rError = null;
		String line = null;
		StringBuilder sbError = new StringBuilder();
		
		try{
			isrError = new InputStreamReader(errorStream);
			rError = new BufferedReader(isrError);
			sbError.setLength(0);
			while ((line = rError.readLine()) != null) {
				sbError.append(line).append(" ");
			}
			if( sbError.length() > 0 ){
				sbError.deleteCharAt(sbError.length()-1);
				
				System.out.println("sbError in CPU: "+sbError);
			}
		} catch ( Exception e ) {
			System.out.println("Exception in getErrorString: "+e.getMessage());
			e.printStackTrace();
		} finally {
			try{
				isrError.close();
			} catch(Exception e) {
				System.out.println("Exception in isrError.close(): "+e.getMessage());
				e.printStackTrace();
			}
			isrError = null;
			try{
				rError.close();
			} catch(Exception e) {
				System.out.println("Exception in rError.destroy(): "+e.getMessage());
				e.printStackTrace();
			}
			rError = null;
		}
		
		return sbError.toString();
	}
	
	
	@Override
	protected void finalize() throws Throwable {
		clearCounterMap();
		
		super.finalize();
	}
}

