package com.appedo.agent.manager;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Properties;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.sasl.RealmCallback;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.jboss.as.controller.client.ModelControllerClient;
import org.jboss.dmr.ModelNode;

import com.appedo.agent.bean.AgentCounterBean;
import com.appedo.agent.bean.SlaCounterBean;
import com.appedo.agent.utils.Constants;
import com.appedo.agent.utils.Constants.AGENT_TYPE;

/**
 * Linux OS monitoring class. This has the functionalities to get the counter values of Linux OS.
 * 
 * @author veeru
 *
 */
public class JbossMonitorManager extends AgentManager {
	
	public static JbossMonitorManager jbossMonitorManager = null;
	
	String host = "localhost";
	int port = 0;
	String userid = null;
	String password = null;
	String hostControllerName = "master";
	String serverName = "JayServer";
	
	boolean standaloneMode = true;	// If you are running your Servers in Domain Mode then set this to false.
	
	ModelControllerClient client = null;
	JMXConnector jmxConnector = null;
	MBeanServerConnection connection = null;
	
	private String strGlobalException = null;
	
	/**
	 * Avoid the object creation for this Class from outside.
	 */
	private JbossMonitorManager() throws Throwable {
		loadConfigProperties();
	}
	
	/**
	 * Returns the only object(singleton) of this Class.
	 * 
	 * @return
	 */
	public static JbossMonitorManager getJbossMonitorManager() throws Throwable {
		if( jbossMonitorManager == null ){
			jbossMonitorManager = new JbossMonitorManager();
		}
		
		return jbossMonitorManager;
	}
	
	private void recreateClientConnection() throws Throwable {
		
		if( client == null ) {
			createClientConnection();
		}
		
		// Use the established connection
		// if connection is not available, then exception will be thrown. 
		// Establish a new connection and retry 
		// If still connection exception persists, then need to handle it further.
		try{
			connection.getDefaultDomain();
		} catch(Throwable th) {
			System.out.println("Retrying JBoss-JMX connection.");
			createClientConnection();
			
			try{
				connection.getMBeanCount();
			} catch(Throwable th1) {
				throw new Exception("JBoss-JMX connection is failed.");
			}
		}
	}
	
	private void createClientConnection() throws Throwable {
		
		// Close objects if exists
		closeObjects();
		
		try{
			// Simple connection to the client, without credentials.
			if( userid == null || password == null ) {
				// NOTE: For hostname as "localhost", there is no need to pass the username & password
				client = ModelControllerClient.Factory.create(host, port, null);
			}
			// To monitor remotely, need to pass the credentials.
			else {
				client = createClient(InetAddress.getByName(host), port, userid, password.toCharArray(), "ManagementRealm" );
			}
			
			// Connect JMX
			String urlString ="service:jmx:remoting-jmx://" + host + ":" + port;
			
			JMXServiceURL serviceURL = new JMXServiceURL(urlString);
			jmxConnector = JMXConnectorFactory.connect(serviceURL, null);
			connection = jmxConnector.getMBeanServerConnection();
		} catch(Throwable th) {
			System.out.println("Unable to establish JBoss's JMX Connection."+th.getMessage());
			System.out.println("Check for \"boundPort\" in JConsole in the below path:\njboss.as -> standard-sockets -> management-native -> Attribute :: boundPort");
			
			throw th;
		}
	}
	
	private ModelControllerClient createClient(final InetAddress host, final int port, final String username, final char[] password, final String securityRealmName) {
		
		final CallbackHandler callbackHandler = new CallbackHandler() {
			public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
				for (Callback current : callbacks) {
					 if (current instanceof NameCallback) {
						NameCallback ncb = (NameCallback) current;
						System.out.println("\n\t\tncb.setName() = "+new String(password));
						ncb.setName(new String(password));
					} else if (current instanceof PasswordCallback) {
						PasswordCallback pcb = (PasswordCallback) current;
						System.out.println("\n\t\tpcb.setPassword() = "+username);
						pcb.setPassword(username.toCharArray());
					} else if (current instanceof RealmCallback) {
						RealmCallback rcb = (RealmCallback) current;
						System.out.println("\n\t\trcb.getDefaulttest() = "+rcb.getDefaultText());
						rcb.setText(securityRealmName);
					} else {
						throw new UnsupportedCallbackException(current);
					}
				}
			}
		};
		
	 	return ModelControllerClient.Factory.create(host, port, callbackHandler);
  	}
	
	/**
	 * Monitor the server and collect the counters
	 */
	public boolean monitorJbossServer(String strGUID,String strApp){
		try {
			// reset the counter collector variable in AgentManager.
			resetCounterMap(strGUID);
			strGlobalException = null;

			recreateClientConnection();
			
		} catch (Throwable th) {
			System.out.println("\n\nUnable to Connect to the Host: "+host+" or Port: "+port+" :: " + th.getMessage());
			th.printStackTrace();
			
			strGlobalException = th.getMessage();
			reportGlobalError("Unable to Connect to the Host: "+host+" or Port: "+port+" :: " + th.getMessage());
			
			// Stop the process from collecting counters.
			return false;
		}
		
		try {
			getCounters(strGUID,strApp);
		}catch (Exception e){
			System.out.println ("Exception in getCounters(): " + e.getMessage());
			e.printStackTrace();
		}
		
		return true;
	}
	
	/**
	 * Send it to the Collector WebService
	 */
	public void sendJbossCounters(String strGUID){
		sendCounters(strGUID);
	}
	
	/**
	 * Collect the counter with agent's types own logic or native methods
	 */
	private void getCounters(String strGUID,String strApp){
		
		String strCounterId = null;
		String [] strQuery = null;
		Double dCounterValue = 0D;
		ModelNode requestProcessorVal = null, transactionsVal = null;
		// create variable's to capture execution_type & is_delta
		boolean bIsDelta = false;
		String strExecutionType = "";

		ArrayList<String> alCommandOutput = null;
		
		try{
			try {
				if(standaloneMode==true){
					
					// FOR STANDALONE MODE use the "StandaloneModel" class as following:
					StandaloneModel objStandaloneModel = new StandaloneModel();

//					objStandaloneModel.runCommands(client);
					
					// Getting Web Subsystem runtime Details */
					requestProcessorVal = objStandaloneModel.getWebSubsystemRuntimeDetails(client);
					
					// cond. `requestProcessorVal != null` added, to avoid exception shown, since `getCounters` called even JMX not connected, 
					if ( requestProcessorVal != null ) {
						String runtimeResult = requestProcessorVal.get("result").toString();
						String path = "/subsystem=web/connector=http";
						/*
//						System.out.println("Result in console:");
						// working 
						/*PrintWriter pw = new PrintWriter(new File("E:/Ramkumar/jboss_counters.log"));
						requestProcessorVal.get("result").writeJSONString(pw, false);
						pw.flush();
						pw.close();*
						requestProcessorVal.get("result").writeExternal(new DataOutputStream(System.out));
//						System.out.println("Result printed in console.");
						
						*/
						
						if( runtimeResult.equals("undefined") ) {
							System.out.println("\n\tCheck ["+path+"] ** Server may not be Running");
						}
						
						// Testing Non XA DataSource ExampleDS */
						//objStandaloneModel.testNonXADataSource(client,"ExampleDS");
						
						// Monitoring Transactions
						transactionsVal = objStandaloneModel.monitorTransactionStatistics(client);
						
						// get the jvm status
						//HashMap hmJsonCounters=objStandaloneModel.getPlatformJvm(client);
					}
				}
				else if(standaloneMode==false){
					DomainModeModel objDomainModeModel= new DomainModeModel();
					
					// Getting Web Subsystem runtime Details */
					objDomainModeModel.getWebSubsystemRuntimeDetails(client,hostControllerName,serverName);
					
					// Testing Non XA DataSource ExampleDS */
					objDomainModeModel.testNonXADataSource(client,hostControllerName,serverName,"test");
					
					// Monitoring Application Statistics where application name is "Log4jDemo.war" */
					objDomainModeModel.monitorApplicationStatistics(client,hostControllerName,serverName,"Log4jDemo.war");
				}
			} catch(Exception e) {
				System.out.println("Excpetion in connect: "+e.getMessage());
				e.printStackTrace();
			}
			
			
			// get selected config counters 
			
			JSONArray joSelectedCounters = AgentCounterBean.getJoCountersBean(strGUID);
			
			for(int i=0; i<joSelectedCounters.size(); i++){
				try{
					dCounterValue = 0D;
					JSONObject joSelectedCounter = joSelectedCounters.getJSONObject(i);				
					strCounterId = joSelectedCounter.getString("counter_id");
					String query = joSelectedCounter.getString("query");
					bIsDelta = joSelectedCounter.getBoolean("isdelta");
					strExecutionType = joSelectedCounter.getString("executiontype");
					
					if ( strExecutionType.equals("cmd") ) {
						// counter value from command
						alCommandOutput = CommandLineExecutor.execute(query);
						if ( alCommandOutput.size() == 0 ) {
							throw new Exception("Metric doesn't return value");
						}
						dCounterValue = convertToDouble(alCommandOutput.get(0));
					} else if ( requestProcessorVal == null ) {
						dCounterValue = -1D;
						System.out.println("Unable to get the metric `"+strCounterId+"` due to "+strGlobalException);
						reportCounterError(Integer.parseInt(strCounterId), strGlobalException);
					} else if ( requestProcessorVal != null ) {	// cond. `requestProcessorVal != null` added, to avoid exception shown, since `getCounters` called even JMX not connected,
						if(query.contains("#APP_NAME#")) {
							query = query.replace("#APP_NAME#", strApp);
						}
//						query = query.replace("default-host", "my-personnal-host");
						strQuery = query.split("#@#");
						
						if(strQuery[0].toString().trim().equalsIgnoreCase("RequestProcessor")) {
							dCounterValue = convertToDouble(requestProcessorVal.get("result").get(strQuery[1].toString()).asString());
						} else if (strQuery[0].toString().trim().equalsIgnoreCase("Transactions")) {
							dCounterValue = convertToDouble(transactionsVal.get("result").get(strQuery[1].toString()).asString());
						} else {
							ObjectName objectName=new ObjectName(strQuery[0].toString());
							dCounterValue = convertToDouble(connection.getAttribute(objectName, strQuery[1].toString()).toString());
						}
					}
					if(bIsDelta) {
						dCounterValue = addDeltaCounterValue(Integer.parseInt(strCounterId), dCounterValue);					
					} else {
						addCounterValue(Integer.parseInt(strCounterId), dCounterValue);
					}
					// TODO: Static Counter correction required

					// Verify SLA Breach
					// JSONObject joSLACounter = null;
					ArrayList<JSONObject> joSLACounter = null; // Need to change variable name as alSLACounters
					joSLACounter = verifySLABreach(strGUID, SlaCounterBean.getSLACountersBean(strGUID), Integer.parseInt(strCounterId), dCounterValue);
					
					// if breached then add it to Collector's collection
					if( joSLACounter != null ) {
						addSlaCounterValue(joSLACounter);
					}

				} catch(Throwable th) {
					System.out.println("Exception in monitorJbossServer.counters: "+th.getMessage());
					th.printStackTrace();
					reportCounterError(Integer.parseInt(strCounterId), th.getMessage());
				}
				
				strCounterId = null;
				strQuery = null;
				dCounterValue = 0D;
			}
		} catch(Throwable th) {
			System.out.println("Exception in monitorJbossServer: "+th.getMessage());
			th.printStackTrace();
			reportGlobalError(th.getMessage());
		} finally {
			try {
				queueCounterValues();
			} catch (Exception e) {
				System.out.println("Exception in queueCounterValues(): "+e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Send the collected counter-sets to Collector WebService, by calling parent's sendCounter method
	 */
	private void sendCounters(String strGUID) {
		
		// send the collected counters to Collector WebService through parent sender function
		sendCounterToCollector(strGUID, AGENT_TYPE.JBOSS);
		sendSlaCounterToCollector(strGUID,AGENT_TYPE.JBOSS);
	}
	
	private Double convertToDouble(Object obj){
		Double dReturn = 0D;
		
		if( obj instanceof Long ) {
			dReturn = ((Long) obj).doubleValue();
		} else if( obj instanceof Integer ){
			dReturn = ((Integer) obj).doubleValue();
		} else if( obj instanceof Double ){
			dReturn = ((Double) obj).doubleValue();
		} else if ( obj instanceof String ) {
			dReturn = Double.parseDouble(obj.toString());
		}
		
		return dReturn;
	}
	
	/**
	 * List all applications which can be monitored under the given params (Host, Port).
	 * 
	 */
	public void listAllApplications() {
		try {
			createClientConnection();
			
			if( standaloneMode == true ) {
				StandaloneModel objStandaloneModel = new StandaloneModel();
				
				objStandaloneModel.listAllApplications(client);
			}
		} catch (Throwable th) {
			System.out.println("Exception in listAllApplications: "+th.getMessage());
			th.printStackTrace();
		}
	}
	
	/**
	 * Print application statistics for the given application
	 * 
	 * @param strAppName
	 */
	public void monitorApplicationStatistics(String strAppName) {
		try {
			createClientConnection();
			
			if( standaloneMode == true ) {
				StandaloneModel objStandaloneModel = new StandaloneModel();
				
				System.out.println("Monitoring the application: "+strAppName);
				objStandaloneModel.monitorApplicationStatistics(client, strAppName);
			}
		} catch (Throwable th) {
			System.out.println("Exception in monitorApplicationStatistics: "+th.getMessage());
			th.printStackTrace();
		}
	}
	
	/**
	 * Print the JNDI details
	 */
	public void printJNDIDetails() {
		try {
			createClientConnection();
			
			if( standaloneMode == true ) {
				StandaloneModel objStandaloneModel = new StandaloneModel();
				
				objStandaloneModel.printJNDIDetails(client);
			}
		} catch (Throwable th) {
			System.out.println("Exception in printJNDIDetails: "+th.getMessage());
			th.printStackTrace();
		}
	}
	
	/**
	 * Load jboss_config.properties file, which is located near this JAR
	 * 
	 * @throws Exception
	 */
	public void loadConfigProperties() throws Exception {
		Properties prop = new Properties();
		
		try{
			InputStream is = new FileInputStream(Constants.THIS_JAR_PATH+File.separator+"jboss_config.properties");
			prop.load(is);
			
			host = prop.getProperty("HOST");
			port =Integer.parseInt(prop.getProperty("PORT"));
			userid = prop.getProperty("USERID");
			password = prop.getProperty("PASSWORD");	
			
		} catch (Exception ex) {
			System.out.println("Exception in loadConfigProperties: "+ex.getMessage());
			throw ex;
		}
	}
	
	/**
	 * Close objects if exists
	 */
	private void closeObjects() {
		try{
			if (jmxConnector != null )	jmxConnector.close();
		} catch(Throwable th) {}
		
		try{
			if (client != null ) client.close();
		} catch(Throwable th) {}
	}
	
	@Override
	protected void finalize() throws Throwable {
		clearCounterMap();
		
		closeObjects();
		
		super.finalize();
	}
}
