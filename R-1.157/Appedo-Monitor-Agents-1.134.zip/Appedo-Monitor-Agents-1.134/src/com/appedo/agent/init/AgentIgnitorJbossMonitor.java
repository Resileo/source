package com.appedo.agent.init;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.agent.manager.JbossMonitorManager;
import com.appedo.agent.utils.Constants;
import com.appedo.agent.utils.Constants.COMMAND_LINE_OPTIONS;
import com.appedo.agent.utils.UtilsFactory;

public class AgentIgnitorJbossMonitor {
	public static void main(String[] args) {
		String strGUID = null, strApp = null;
		JSONObject joRecord = null;
		int nIndex = -1;
		
		try{
			// load config parameters
			Constants.loadConfigProperties();
			
			if (args.length > 0 ) {
				
				// list all deployed projects, command line args
				if( UtilsFactory.contains(args, COMMAND_LINE_OPTIONS.LIST_APPLICATIONS_1.toString()) || UtilsFactory.contains(args, COMMAND_LINE_OPTIONS.LIST_APPLICATIONS_2.toString()) ) {
					JbossMonitorManager.getJbossMonitorManager().listAllApplications();
				}
				// Print application statistics for the given application
				else if( (nIndex = UtilsFactory.contains(args, COMMAND_LINE_OPTIONS.APPLICATION_STATISTICS_1.toString(), Integer.class)) > 0 || (nIndex = UtilsFactory.contains(args, COMMAND_LINE_OPTIONS.APPLICATION_STATISTICS_2.toString(), Integer.class)) > 0 ) {
					if ( args.length <= nIndex+1 ) {
						System.out.println("Application name is missing in the command-line.");
					} else {
						JbossMonitorManager.getJbossMonitorManager().monitorApplicationStatistics( args[nIndex+1]);
					}
				}
				// Print the JNDI details
				else if( UtilsFactory.contains(args, COMMAND_LINE_OPTIONS.PRINT_JNDI_DETAILS_1.toString()) || UtilsFactory.contains(args, COMMAND_LINE_OPTIONS.PRINT_JNDI_DETAILS_2.toString()) ) {
					JbossMonitorManager.getJbossMonitorManager().printJNDIDetails();
				}
				else {
					System.out.println("Invalid option");
				}
			} else {
				// Monitor JBoss Server
				if( Constants.AGENT_CONFIG!=null ) {
					
					JSONArray jaConfig = JSONArray.fromObject(Constants.AGENT_CONFIG);
					for(int i=0; i<jaConfig.size(); i++) {
						
						joRecord = jaConfig.getJSONObject(i);
						strGUID = joRecord.getString("guid");
						//String strPort = joRecord.getString("port");
						strApp = joRecord.getString("app");
						
						new AgentIgnitorJbossThread(strGUID, strApp).start();
					}
				} else {
					System.out.println("Configuration problem");
				}
				//AgentManager.runGarbageCollectionRountine();
			}
		} catch(Throwable e) {
			System.out.println("Exception in InitServlet.init: "+e.getMessage());
			e.printStackTrace();
		}
	}
}
