package com.appedo.agent.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class UtilsFactory{
	
	/**
	 * Returns the current date-time in the format of yyyy-MM-dd HH:mm:ss.S
	 * 
	 * @return
	 */
	public static String nowFormattedDate(){
		String opDate = "";
		try{
			Calendar calNow = Calendar.getInstance();
			DateFormat opFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			opDate = opFormatter.format(calNow.getTime());
		}catch(Exception e){
			System.out.println("Exception in nowFormattedDate(): "+e.getMessage());
			e.printStackTrace();
		}
		return opDate;
	}
	
	/**
	 * Round up the given decimal digits.
	 * 
	 * @param value
	 * @param places
	 * @return
	 */
	public static Double round(Double value, int places) {
		if (places < 0) throw new IllegalArgumentException();
		
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	
	/**
	 * This method checks whether 'val1' is null OR length of val1 = 0, 
	 * if so, it will return val2 String, irrespective of val2's value.
	 * Otherwise, it will return val1.
	 * 
	 * @param val1 
	 * @param val2 
	 * @return String
	 */
	public static String replaceNull(Object val1, String val2) {
		if (val1 == null || val1.toString().length() == 0)
			return val2;
		else
			return val1.toString();
	}
	
	/**
	 * Returns Properties object for the file given.
	 * 
	 * @param configFilePath
	 * @return
	 * @throws Exception
	 */
	public static Properties getPropertiesFile(String configFilePath)throws Exception{
		Properties prop = null;
		try{
			prop = new Properties();
			InputStream is = new FileInputStream( configFilePath );
			prop.load(is);
		}catch(Exception e){
			System.out.println("Exception in Property file load: "+e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return prop;
	}
	
	/**
	 * Find the absolute path of the JAR.
	 * 
	 * If the execution is done through IDE, then the "bin" folder's home path is returned.	
	 * 
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String getThisJarPath() throws UnsupportedEncodingException {
		String strThisJARPath = null;
		
		strThisJARPath = UtilsFactory.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		String OS = System.getProperty("os.name").toLowerCase();
		if (OS.contains("wind")) {
			strThisJARPath = strThisJARPath.substring(1);
		} else if (OS.contains("nix") || OS.contains("nux") || OS.contains("aix")) {
			strThisJARPath = strThisJARPath.substring(0);
		}
		
		// While executing JAR through command-prompt, need to trim till last /File-Separator
		// Eg.: C:/Users/ram/Downloads/appedo_mysql_monitor/appedo_mysql_agent_pvt.jar
		if( strThisJARPath.endsWith(".jar") ) {
			strThisJARPath = strThisJARPath.substring(0, strThisJARPath.lastIndexOf("/"));
		}
		// Otherwise considering that the execution is from some IDE like Eclipse, trim the last folder, which is suppose to be 'bin' folder
		// Eg.: E:/Ramkumar/workspace_github/Appedo-Monitor-Agents/bin/
		else {
			System.out.println("Assuming this is started from IDE. Removed 'bin' from the path");
			strThisJARPath = strThisJARPath.substring(0, strThisJARPath.length()-5);
		}
		
		strThisJARPath = new File(URLDecoder.decode(strThisJARPath, "UTF-8")).getAbsolutePath();
		
		return strThisJARPath;
	}
	
	/**
	 * Closes the nested collection variable.
	 * 
	 * @param objCollection
	 */
	public static void clearCollectionHieracy(Object objCollection){
		try{
			if( objCollection == null ){
				
			}else if( objCollection instanceof Map ) {
				Map mapCollection = (Map)objCollection;
				Iterator it = mapCollection.keySet().iterator();
				while( it.hasNext() ){
					Object str = it.next();
					clearCollectionHieracy( mapCollection.get(str) );
				}
				mapCollection.clear();
				// mapCollection = null;
			}else if( objCollection instanceof List ) {
				List listCollection = (List)objCollection;
				for( int i=0; i < listCollection.size(); i++ ){
					clearCollectionHieracy( listCollection.get(i) );
				}
				listCollection.clear();
				// listCollection = null;
			}else if( objCollection instanceof StringBuilder ) {
				StringBuilder sbCollection = (StringBuilder)objCollection;
				sbCollection.setLength(0);
			}else if( objCollection instanceof StringBuffer ) {
				StringBuffer sbCollection = (StringBuffer)objCollection;
				sbCollection.setLength(0);
			}
			
			// objCollection = null;
		}catch(Throwable t){
			System.out.println("Exception while clearCollectionHieracy: "+t.getMessage());
			t.printStackTrace();
		}
	}
	
	/**
	 * Returns true if given value is present in the array
	 * 
	 * @param saArray
	 * @param strValue
	 * @return
	 */
	public static boolean contains(String[] saArray, String strValue) {
		for (int i = 0; i < saArray.length; i++) {
			if (saArray[i].equals(strValue)) return true;
		}
		
		return false;
	}
	
	/**
	 * Returns the index of the value.
	 * if given value is not present in the array, returns -1.
	 * 
	 * @param saArray
	 * @param strValue
	 * @return
	 */
	
	public static int contains(String[] saArray, String strValue, Class classObject) {
		for (int i = 0; i < saArray.length; i++) {
			if (saArray[i].equals(strValue)) return i;
		}
		
		return -1;
	}
	
	public static void close(InputStream inputStream) {
		try {
			if (inputStream != null) {
				inputStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public static void close(Reader reader) {
		try {
			if (reader != null) {
				reader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Returns the given bytes unit into KiloBytes unit
	 * 
	 * @param lByte
	 * @return
	 *
	public static long convertByteToKB(long lByte) {
		return lByte / 1024;
	}
	
	/**
	 * Returns the given bytes unit into MegaBytes unit
	 * 
	 * @param lByte
	 * @return
	 *
	public static long convertByteToMB(long lByte) {
		return lByte / 1024 / 1024;
	}
	
	/**
	 * Returns the given KiloBytes unit into MegaBytes unit
	 * 
	 * @param lByte
	 * @return
	 *
	public static long convertKByteToMB(long lKiloByte) {
		return lKiloByte / 1024;
	}*/
	
}
