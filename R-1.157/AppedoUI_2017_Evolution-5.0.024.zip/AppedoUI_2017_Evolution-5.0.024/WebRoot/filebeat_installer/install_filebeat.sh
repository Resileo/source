#!/bin/bash
filebeat_home="";
ipaddress=`ip addr | grep 'state UP' -A2 | tail -n1 | awk '{print $2}' | cut -f1  -d'/'`
echo $ipaddress;
checkExitStatus()
{
	if [ "x$1" != "x0" ]; then
		echo "";
		echo "#############################################################################";
		echo "@appln_heading@ Agent failed to install. Exiting with non zero status $1. Root Cause: $2."
		echo "Please follow the manual instruction for installation or contact @support_emailid@ for assistance"
		echo "#############################################################################";
		exit $1
	fi
}

main()
{
	read -p 'Enter the file path of the log: ' logPath
	#read -p 'Enter the Description: ' description
	#echo  $modulename , $description
	OSNAME=$(sudo cat /etc/*-release | grep 'PRETTY_NAME' | cut -d '"' -f 2 | cut -d ' ' -f 1,2)
	echo "OS NAME: $OSNAME"
    varlen=${#OSNAME}
	sudo dmidecode
    isdmidecodeExist=$?
    echo "dmidecode exist : $isdmidecodeExist"
	if [ $varlen -eq 0 -a $isdmidecodeExist -gt 0 ] ; then
         checkExitStatus 1 "OS name not found in -release file. Install 'dmidecode' manually."
    fi
	if [ $isdmidecodeExist -gt 0 ] ; then
		echo $OSNAME | grep -i 'ubuntu'
		if [ $? -eq 0 ] ; then
			 sudo apt-get install dmidecode
		else
			 sudo yum install dmidecode
		fi
	fi
    checkExitStatus $? "dmidecode installation failed. Install 'dmidecode' manually."
    uuid=$(dmidecode -s system-uuid)
    echo "System UUID: $uuid"
    description=$(dmidecode -s system-Manufacturer)' | '$(dmidecode -s system-Product-Name)' | '$(dmidecode -s system-Serial-Number)' | '$(dmidecode -s system-Version)
    echo "description : $description"
    
	httpUrl="@MODULE_UI_SERVICES@/log/addLogMonitor"
	GUID=$(curl -s -X POST -d "client_unique_id=$uuid&encryptedUserId=$3&description=$description" "$httpUrl")

	echo "LOG-Monitior GUID: $GUID"

	if [ "$GUID" = "Log Module name already exists" ]; then
            1=1
            checkExitStatus $? "Log Module name already exists, try with different log module name"
	fi
	
	#To check whether GUID returned correctly
	varlen=${#GUID}
	if [ $varlen -eq 0 ] ; then  
		checkExitStatus 1 "GUID returned Blank"
	fi
	
	echo $GUID | grep -i 'UUID already exist'
	if [ $? -eq 0 ] ; then
		checkExitStatus 1 $GUID
	fi

	filename="filebeat-1.2.3-x86_64_$2.tar.gz";
	dir=`cat _@download_appln_name_lowercase@_usrhome.log`
	rm -f _@download_appln_name_lowercase@_usrhome.log 
	cd $dir
	checkExitStatus $? "cd to the $dir failed"
	# add timeout for wget
	if [ -f $filename ];then
		echo "Do you want to delete the existing file? y/n"
		read choice
		if [ "x$choice" == "xy" ] || [ "x$choice" == "xY" ];then
			echo "Deleting the existing agent tar.gz and folder from $dir."
			rm -rf $filename;
			checkExitStatus $? "Removing existing tar.gz file failed.."
			echo "Downloaded the file at $dir."
			curl -o $filename -m 600 --connect-timeout 60 -k "@APPEDO_URL@apm/downloadAgent?type=FILEBEAT_LINUX" > /dev/null 2>&1
			checkExitStatus $? "Failed to download the filebeat from server.."
		else
			echo "Existing downloaded file from $dir will be used...";
		fi
	  else
		curl -o $filename -m 600 --connect-timeout 60 -k "@APPEDO_URL@apm/downloadAgent?type=FILEBEAT_LINUX" > /dev/null 2>&1
		checkExitStatus $? "Failed to download the filebeat from server.."
        	echo "Downloaded the file at $dir"
	fi
	mkdir $2
	checkExitStatus $? "Failed to create directory as the same already exist."
	echo "Extracting the file at $dir";
	tar -xzf $filename -C $2;
	checkExitStatus $? "Failed to extract the @appln_heading@ Filebeat Agent.."
	chmod -R u+rw $filename
	checkExitStatus $? "Failed to change the permission.."
	filebeat_home="$dir/$2/filebeat-1.2.3-x86_64";
	# wget and download the crt file from our ui server
	
	curl -o logstash-forwarder.crt -m 600 --connect-timeout 60 -k $1 > /dev/null 2>&1
	checkExitStatus $? "Failed to download the crt file"
	sudo mkdir /etc/pki/tls/certs/;
	sudo mv logstash-forwarder.crt  /etc/pki/tls/certs/logstash-forwarder.crt;
	checkExitStatus $? "Failed to move the crt file."
}

updateconfig()
{
	if [ -z $logPath ];then 
		sed -i 's/\/var\/log\/\*.log/\/var\/log\/syslog/' $filebeat_home/filebeat.yml
		checkExitStatus $? "@appln_heading@ filebeat config(0) failed .."
	else
		logPath=$(echo $logPath|sed -e 's/\//\\\//g')
		sed -i "s/\/var\/log\/\*.log/$logPath/" $filebeat_home/filebeat.yml
		checkExitStatus $? "@appln_heading@ filebeat config(0) failed .."
	fi
	sed -i "s/#document_type: log/document_type: log/" $filebeat_home/filebeat.yml
	checkExitStatus $? "@appln_heading@ filebeat config(6) failed .."
	sed -i "s/#fields:/fields: {os: \"$OSNAME\"\, guid: \"$GUID\"}/" $filebeat_home/filebeat.yml
	checkExitStatus $? "Softsmith filebeat config(7) failed .."
	sed -i "s/#fields_under_root: false/fields_under_root: true/" $filebeat_home/filebeat.yml
	checkExitStatus $? "Softsmith filebeat config(8) failed .."
	sed -i 's/elasticsearch:/#elasticsearch:/' $filebeat_home/filebeat.yml
	checkExitStatus $? "@appln_heading@ filebeat config(1) failed .."
	sed -i 's/hosts: \[\"localhost:9200\"\]/#hosts: \[\"localhost:9200\"\]/' $filebeat_home/filebeat.yml
	checkExitStatus $? "@appln_heading@ filebeat config(2) failed .."
	sed -i 's/#logstash:/logstash:/' $filebeat_home/filebeat.yml
	checkExitStatus $? "@appln_heading@ filebeat config(3) failed .."
	sed -i "s/#ignore_older: 0/ignore_older: 5m/" $filebeat_home/filebeat.yml
	checkExitStatus $? "@appln_heading@ filebeat config(9) failed .."
	#sed -i 's/#hosts: \[\"localhost:5044\"\]/hosts: \[\"'$1':'$2'\"\]/' $filebeat_home/filebeat.yml
	#checkExitStatus $? "@appln_heading@ filebeat config(4) failed .."
	sed -i '0,/#tls/! {0,/#tls/ s/#tls/tls/}' $filebeat_home/filebeat.yml
	checkExitStatus $? "@appln_heading@ filebeat config(5) failed .."
	sed -i '0,/#certificate_authorities: \[\"\/etc\/pki\/root\/ca.pem\"\]/! {0,/#certificate_authorities: \[\"\/etc\/pki\/root\/ca.pem\"\]/ s/#certificate_authorities: \[\"\/etc\/pki\/root\/ca.pem\"\]/certificate_authorities: \[\"\/etc\/pki\/tls\/certs\/logstash-forwarder.crt\"\]/}' $filebeat_home/filebeat.yml
	#sed -i 's/#certificate_authorities: \[\"\/etc\/pki\/root\/ca.pem\"\]/certificate_authorities: \[\"\/etc\/pki\/tls\/certs\/logstash-forwarder.crt\"\]/2' $filebeat_home/filebeat.yml
	checkExitStatus $? "@appln_heading@ filebeat config(6) failed .."
	echo "@appln_heading@ filebeat config updated sucessfully...";
}
startfilebeat()
{
	chmod +x $filebeat_home/filebeat
	$filebeat_home/filebeat -e -c $filebeat_home/filebeat.yml &
	checkExitStatus $? "@appln_heading@ Filebeat didnt start.."
	echo "@appln_heading@ Filebeat started sucessfully.."
}
main $1 $2 $3
updateconfig $@
startfilebeat

