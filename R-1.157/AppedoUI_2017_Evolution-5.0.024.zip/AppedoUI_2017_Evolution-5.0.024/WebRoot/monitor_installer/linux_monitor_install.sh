#! /bin/bash
# New auto installer for linux monitor agent.
checkExitStatus()
{
	if [ "x$1" != "x0" ]; then
		echo "";
		echo "#############################################################################";
		echo "Agent failed to start. Exiting with non zero status $1. Root Cause: $2." 
		echo "Please follow the manual instruction for installation or contact @support_emailid@ for assistance"
		echo "#############################################################################";
		exit $1
	fi
}

checkProcessExistAlready()
{
	pid=`ps aux | grep java | grep @download_appln_name_lowercase@_linux_agent*.jar | awk '{ print $2 }'`
    if [ "x$pid" != "x" ];then
    	echo "";
        echo "#############################################################################";
        echo "Aleady @download_appln_name_lowercase@_linux_agent*.jar is running. Kill that process and try again";
        echo "#############################################################################";

        echo "Do you want to kill the running process($pid)? y/n";
        read choice
        if [ "x$choice" == "xy" ] || [ "x$choice" == "xY" ];then
        	kill -9 $pid;
        	checkExitStatus $? "Cannot kill the running process with pid $pid"
        else
            echo "Exiting from auto installation. Already @download_appln_name_lowercase@_linux_agent*.jar is running."
            exit 101;
        fi
	fi

}

main()
{

	user=`whoami`
	echo $user
	#For solaries check the os flavor and change /export/home/$user
	cat /etc/release | grep -i solaris
	if [ "x$?" != "x0" ];then
		dir="/home/$user/@download_appln_name_lowercase@_linux_monitor_agent";	
	else
		dir="/export/home/$user/@download_appln_name_lowercase@_linux_monitor_agent";
	fi 
	
	if [ ! -d "$dir" ]; then
		echo "@download_appln_name_camelcase@ agent directory creation started..."
		mkdir -p $dir
		checkExitStatus $? "Directory creation failed."
		echo "@download_appln_name_camelcase@ agent directory ($dir) created sucessfully!!!"
	fi
	cd $dir
	checkExitStatus $? "cd to the $dir failed"
	# add timeout for wget
	if [ -f @download_appln_name_lowercase@_linux_monitor_agent.tar.gz ];then
		echo "Do you want to delete the existing file? y/n"
		read choice
		if [ "x$choice" == "xy" ] || [ "x$choice" == "xY" ];then
			echo "Deleting the existing agent tar.gz and folder from $dir."
			rm -rf @download_appln_name_lowercase@_linux_monitor_agent.tar.gz @download_appln_name_lowercase@_linux_monitor;
			checkExitStatus $? "Removing existing tar.gz file failed.."
			echo "Downloaded the file at $dir."
			curl -o @download_appln_name_lowercase@_linux_monitor_agent.tar.gz -m 600 --connect-timeout 60 -k "$1" > /dev/null 2>&1
	 		#wget -O @download_appln_name_lowercase@_linux_monitor_agent.tar.gz -T 600 -q --connect-timeout=60 --no-check-certificate "@APPEDO_URL@apm/downloadAgent?type=Ubuntu&guid=b4e34e98-1caf-459a-898b-a75202fc69e4&modulename=karthick"
			checkExitStatus $? "Failed to download the monitor agent from server.."
		else
			echo "Existing downloaded file from $dir will be used...";
		fi
	  else
      	curl -o @download_appln_name_lowercase@_linux_monitor_agent.tar.gz -m 600 --connect-timeout 60 -k "$1" > /dev/null 2>&1
        #wget -O @download_appln_name_lowercase@_linux_monitor_agent.tar.gz -T 600 -q --connect-timeout=60 --no-check-certificate "@APPEDO_URL@apm/downloadAgent?type=Ubuntu&guid=b4e34e98-1caf-459a-898b-a75202fc69e4&modulename=karthick"
        checkExitStatus $? "Failed to download the monitor agent from server.."
        echo "Downloaded the file at $dir."
	fi
	echo "Extracting the file at $dir...";
	tar -xzmf @download_appln_name_lowercase@_linux_monitor_agent.tar.gz
	checkExitStatus $? "Failed to extract the monitor agent.."
}

installSSL()
{
        cacert_path=$javapath/lib/security/cacerts
        #echo $cacert_path
        cp $cacert_path cacerts_@download_appln_name_lowercase@_agent
        checkExitStatus $? "Security file copy failed."
        storepass="changeit";
        $javapath/bin/keytool -import -alias apm.@download_appln_name_lowercase@.com -keystore cacerts_@download_appln_name_lowercase@_agent -storepass $storepass -file $dir/@download_appln_name_lowercase@_linux_monitor/apm.@download_appln_name_lowercase@.com.crt -noprompt
        if [ $? != 0 ];then
                echo "Ener a password for the cacerts:"
                read storepass
                $javapath/bin/keytool -import -alias apm.@download_appln_name_lowercase@.com -keystore cacerts_@download_appln_name_lowercase@_agent -storepass $storepass -file $dir/@download_appln_name_lowercase@_linux_monitor/apm.@download_appln_name_lowercase@.com.crt -noprompt
                checkExitStatus $? "Seems wrong password or something wrong when copying the certificate."
        fi
}

startMon()
{
	chmod 777 start_linux_monitor.sh
	checkExitStatus $?
	sh start_linux_monitor.sh 
	checkExitStatus $?
	echo "----------------------------------------------------------------------------";
	echo "@download_appln_name_camelcase@ Linux monitoring agent started successfully..."
	echo "For more details, you can check the logs at $dir/@download_appln_name_lowercase@_linux_monitor/logs";
	echo "----------------------------------------------------------------------------";
}

echo "Download the @download_appln_name_lowercase@_linux_monitor_install.sh in `pwd`"
checkProcessExistAlready
main $@
cd @download_appln_name_lowercase@_linux_monitor
javapath=`java -cp . JREHome`
if [ $? != 0 ];then
	echo "Ener the full path for JRE Home:"
	read javapath
fi
#checkExitStatus $? "Java not found."
#echo $javapath
installSSL
startMon
