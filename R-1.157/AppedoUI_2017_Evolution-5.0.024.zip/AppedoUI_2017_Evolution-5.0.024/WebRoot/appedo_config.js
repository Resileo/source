// var appedoApp = angular.module('appedoApp', ['ui.router', 'ui.bootstrap', 'd3', 'ngSlider', 'ngToast']);//'rzModule', 
var appedoApp = angular.module('appedoApp', ['ui.router','ui.bootstrap','d3','ngSlider','ngToast'], 
	function($httpProvider) {
		// Use x-www-form-urlencoded Content-Type
		$httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
		
		/**
		* The converts an [JSON]object to x-www-form-urlencoded serialization.
		* @param {Object} obj
		* @return {String}
		*/
		var param = function(obj) {
			var query = '', name, value, fullSubName, subName, subValue, innerObj, i;
			
			for(name in obj) {
				value = obj[name];
				
				if(value instanceof Array) {
					for(i=0; i<value.length; ++i) {
						subValue = value[i];
						fullSubName = name + '[' + i + ']';
						innerObj = {};
						innerObj[fullSubName] = subValue;
						query += param(innerObj) + '&';
					}
				} else if(value instanceof Object) {
					for(subName in value) {
						subValue = value[subName];
						fullSubName = name + '[' + subName + ']';
						innerObj = {};
						innerObj[fullSubName] = subValue;
						query += param(innerObj) + '&';
					}
				} else if(value !== undefined && value !== null) {
					query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
				}
			}
			
			return query.length ? query.substr(0, query.length - 1) : query;
		};
		
		// Override $http service's default transformRequest
		$httpProvider.defaults.transformRequest = [function(data) {
			return angular.isObject(data) && ( String(data) !== '[object File]' ) ? param(data) : data;
		}];
	}
);

appedoApp.config(['$stateProvider',
	function($stateProvider) {
		$stateProvider
			.state( '/dashboard', {
				url: "/dashboard",
				templateUrl: 'view/html/dashboard.html',
				controller: 'appedoChartsController'
			})
			.state( '/login', {
				url: '/login',
				templateUrl: 'view/html/login.html',
				controller: 'login_controller'
			})
			.state( '/loginResponse', {
				url: '/loginResponse',
				controller: 'login_response_controller'
			})
			.state( '/forgotPassword', {
				url: '/forgotPassword',
				templateUrl: 'view/html/forgot_password.html',
			})
			.state( '/signup', {
				url: '/signup',
				templateUrl: 'view/html/signup.html',
				controller: 'signup_controller'
			})
			.state( '/changePassword', {
				url: '/changePassword',
				controller: 'changePasswordController',
				templateUrl: 'view/html/changePassword.html'
			})
			.state( '/changePasswordResponse', {
				url: '/changePasswordResponse',
				controller: 'changePasswordResponseController'
			})
			.state( '/profileSettings', {
				url: '/profileSettings',
				controller: 'userProfileController',
				templateUrl: 'view/html/userProfileSettings.html'
			})
	        .state( '/resetPassword', {
	            url: '/resetPassword',
	            controller: 'resetPassword_controller',
                templateUrl: 'view/html/reset_password.html'
	        })
			.state( '/profileSettingsResponse', {
				url: '/profileSettingsResponse',
				controller: 'userProfileResponseController'
			})
			.state( '/moduleDetails', {
				url: '/moduleDetails',
				controller: 'moduleDetailsController',
				templateUrl: 'view/html/moduleDetails.html'
			})
			.state( '/moduleDetails/:_dc', {
				url: '/moduleDetails/:_dc',
				controller: 'moduleDetailsController',
				templateUrl: 'view/html/moduleDetails.html'
			})
			.state( '/apm_details', {
                url: '/apm_details',
                templateUrl: 'common/views/oad/apm_details.html'
            })
            .state( '/sla_alert_details', {
                url: '/sla_alert_details',
                templateUrl: 'common/views/sla/sla_alert_details.html'
            })
			.state( '/ltScenarioReports/:loadTestType/:scenarioName/:moduleType', {
	            url: '/ltScenarioReports/:loadTestType/:scenarioName/:moduleType',
		        templateUrl : 'common/views/load_test/loadTestScenarioReports.html'
	        })
	        .state( '/ltRunningScenarioStauts/:loadTestType/:scenarioName', {
	            url: '/ltRunningScenarioStauts/:loadTestType/:scenarioName',
	            templateUrl: 'common/views/load_test/loadTestRunnningScenario.html'
	        })
	        .state( '/log_details', {
                url: '/log_details',
                templateUrl: 'common/views/log/log_details.html'
            }).state( '/rum_details', {
                url: '/rum_details',
                templateUrl: 'common/views/rum/rum_details.html'
            }).state( '/admin', {
                url: '/admin',
                templateUrl: 'common/views/accounts/admin_details.html',
                controller: 'adminController'
            });
	}
])
.run(['$state', function($state) {
	$state.transitionTo('/login');
}]);

//constants
appedoApp.constant('ONE_DAY_IN_MILLIS', 1000 * 60 * 60 * 24);


//When the application is being bootstrapped, it will run the configuration
//phase first and then it will execute the "Run" phase. At that point, all of
//the run() blocks are executed. During this phase, we no longer have access
//to any of the provider; but, we can finally access the services.

//thinks, the run phase executes after config phase, the services/factory can be injected in `run`, where as while provider thinks we can't inject 
appedoApp.run(['$rootScope', 'appedoCommonsService', 'sessionServices', 'messageService', function($rootScope, appedoCommonsService, sessionServices, messageService) {
	var d3ChartTimeFormat = ["%H : %M", "%H : %M", "%d %b", "%d %b", "%d %b", "%d %b", "%d %b"];
	//	 var d3ChartTimeFormatForASDPdf = ["dd MMM HH:mm", "dd MMM HH:mm", "dd MMM yy", "dd MMM yy", "dd MMM yy", "dd MMM yy", "dd MMM yy"];
	var d3ChartTimeFormatForASDPdf = ["dd MMM HH:mm", "dd MMM HH:mm", "dd MMM HH:mm", "dd MMM HH:mm", "dd MMM HH:mm", "dd MMM HH:mm", "dd MMM HH:mm"];
	var d3ChartTimeFormatForMyChartPdf = ["dd MMM HH:mm:ss", "dd MMM HH:mm:ss", "dd MMM HH:mm:ss", "dd MMM HH:mm:ss", "dd MMM HH:mm:ss", "dd MMM HH:mm:ss", "dd MMM HH:mm:ss", "dd MMM HH:mm:ss"];
	var sliderServerSideScale = ["1 hour", "1 day", "7 days", "15 days", "30 days", "60 days", "120 days"];
	var sliderServerSideScaleForHotSpot = ["1 hour", "2 hours", "3 hours"];
	var sliderServerSideScaleInHour = ["1", "24", "168", "360", "720", "1440", "2880"];
	var noRecordForDonut = [{"label":"NA","value":0}];
	 
	var d3ChartTimeFormatForLT = ["%d %b %H:%M", "%H : %M", "%H : %M : %S"];
	var d3ChartTimeFormatForLTPdf = ["dd MMM HH:mm", "HH : mm", "HH : mm : ss"];
	var d3ChartTypeForLT = [ "Hours", "Mins", "Secs"];
	//var webUrlValidationFormat="^(?:(?:https?|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?!(?:10|127)(?:\\.\\d{1,3}){3})(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?)(?::\\d{2,5})?(?:[/?#]\\S*)?$";

	var webUrlValidationFormat="^(?:(?:https?|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?)(?::\\d{2,5})?(?:[/?#]\\S*)?$";
	sessionServices.set("d3ChartTimeFormat", JSON.stringify(d3ChartTimeFormat));
	sessionServices.set("d3ChartTimeFormatForLTPdf", JSON.stringify(d3ChartTimeFormatForLTPdf));
	sessionServices.set("d3ChartTimeFormatForASDPdf", JSON.stringify(d3ChartTimeFormatForASDPdf));
	sessionServices.set("d3ChartTimeFormatForMyChartPdf", JSON.stringify(d3ChartTimeFormatForMyChartPdf));
			 
	sessionServices.set("sliderServerSideScale", JSON.stringify(sliderServerSideScale));
	sessionServices.set("sliderServerSideScaleForHotSpot", JSON.stringify(sliderServerSideScaleForHotSpot));
	sessionServices.set("noRecordForDonut", JSON.stringify(noRecordForDonut));
	sessionServices.set("sliderServerSideScaleInHour", JSON.stringify(sliderServerSideScaleInHour));
	sessionServices.set("textRefresh", 1000 * 60 * 2);
	sessionServices.set("cardRefreshTime", 59);
	sessionServices.set("secondaryCountersTextRefresh", 1000 * 60);
	sessionServices.set("graphRefresh", 1000 * 60);
	sessionServices.set("d3ChartTimeFormatForLT", JSON.stringify(d3ChartTimeFormatForLT));
	sessionServices.set("d3ChartTypeForLT", JSON.stringify(d3ChartTypeForLT));
	sessionServices.set("methodsTraceLimit", 10);
	sessionServices.set("webURLValidation", webUrlValidationFormat);
	
	// gets appedo whitelabels, to replace in emails 
	function getAppedoWhiteLabels() {
		appedoCommonsService.getAppedoWhiteLabels(function(resp) {
			
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage( resp.errorMessage );
			} else {
				$rootScope.appedoWhiteLabels = resp.message;
				console.info("whiteLabel");
				console.log($rootScope.appedoWhiteLabels);
			}
		});
	}
	getAppedoWhiteLabels();
}]);

//constants
appedoApp.constant('ONE_DAY_IN_MILLIS', 1000 * 60 * 60 * 24);

// filters
appedoApp.filter("asDate", function() {
    return function (input) {
        return new Date(input);
    };
});

appedoApp.filter("millisecAsHoursMinSec", ['$appedoUtils', function($appedoUtils) {
    return function (input) {
        return $appedoUtils.convertMilliSecToHoursMinSec(input);
    };
}]);

appedoApp.filter('summaryReportIframeURL', function ($sce) {
	return function(runId) {
		return $sce.trustAsResourceUrl('./lt/summaryReport?runid=' + runId);
	};
});

appedoApp.filter('sumHarFileIframeURL', function ($sce) {
	return function(harFilePath) {
		return $sce.trustAsResourceUrl(harFilePath);
	};
});

// gets JSON obj's keys as in array
appedoApp.filter('joAsKeys', function() {
	return function(input) {
		if ( ! input ) {
			return [];
		}
		return Object.keys(input);
	}
});

// to convert the data in size human readable format, returns HTML format 
appedoApp.filter('sizeInHumanReadableAsHTML', function(appedoDataUtils) {
	return function(input, unit, classValue, classUnit, bRoundOfValue, bSecondaryCounter) {
		if ( input !== undefined && unit !== undefined ) {
			var aryFormmattedValue = appedoDataUtils.getHumanReadableFormat(input, unit, bRoundOfValue, bSecondaryCounter);
			return '<span class="'+classValue+'">'+aryFormmattedValue[0]+'</span>  <span class="'+classUnit+'">'+aryFormmattedValue[1]+'</span>';
		}
	};
});

// to convert the data in size human readable format, return text 
appedoApp.filter('sizeInHumanReadable', function(appedoDataUtils) {
	return function(input, unit, classValue, classUnit, bRoundOfValue, bSecondaryCounter) {
		if ( input !== undefined && unit !== undefined ) {
			var aryFormmattedValue = appedoDataUtils.getHumanReadableFormat(input, unit, bRoundOfValue, bSecondaryCounter);
			return aryFormmattedValue[0]+' '+aryFormmattedValue[1];
		}
	};
});

appedoApp.filter("durationTime", function() {
    return function (input) {
    	var dur = input.split(';'), hrminsec = '';
    	if ( dur[0] != 0 ) {
    		hrminsec += dur[0] + ' Hours ';
    	}
    	if ( dur[1] != 0 ) {
    		hrminsec += dur[1] + ' Minutes ';
    	}
    	if ( dur[2] != 0 ) {
    		hrminsec += dur[2] + ' Seconds';
    	}
    	
        return hrminsec;//dur[0] == 0 ? '' : dur[0]+' Hours' + dur[1] == 0 ? '' : dur[1]+ ' Minutes' + dur[2] == 0 ? '' : dur[2] + ' Seconds';
    };
});

appedoApp.filter('encodeURI', function() {
  return window.encodeURIComponent;
});
