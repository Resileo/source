// appedo-charts 
appedoApp.directive('appedoCharts', ['d3Service', 'appedoDirectiveChartUtils', 'appedoDataUtils', function(d3Service, appedoDirectiveChartUtils, appedoDataUtils){
	return {
		restrict: "AE",
		scope: {
			graphGroups: '=',
			loadevent: '&',
			// commented, yAxisCategoryKey: '='
			/*
			chartdata: '=',
			loadevent: '&',
			yaxiscategory: '=',
			sliderInterval: '@',
			// serverCurrentTime, used for last 1 hour data's min/max,(since client machine time varies from server chart data time, plotting of chart moves from axis )
			serverCurrentTime: '@'
			//yaxislabel: '@'*/
		},
		link: function(scope, element, attrs) {
			d3Service.d3().then(function(d3) {
				var data = [], joGraphModuleDetails = {};
				var x, y, xAxis, yAxis, svg;
				var tooltipTimeFormat = d3.time.format("%Y-%b-%d %H:%M:%S"), timeFormat;
				var divTooltip;
				var bHasSingleGroupChartData = false, bChartClickable = false /* clickable to have point hover tooltip, not clickable to have mousemove tooltip */,
					bMousemoveTooltip = false /* to have `true` of default mousemove tooltip */;
				
				/*
				 * directive graphdata format from `./common/data/chartData.json`
				 */
				
				/* commented corrections, 
				var yAxisPlotKey = scope.yAxisPlotKey;
				if (yAxisPlotKey == null || yAxisPlotKey == undefined) {
					yAxisPlotKey = 'V';
				}
				console.info('yAxisPlotKey: '+yAxisPlotKey);*/
				
				var expressionHandler = scope.loadevent();
				
				var aryColors = [ /* Brown - {"dark":"#a73f05", "light":"#d08f6b"}, Brown - {"dark":"#c55204", "light":"#e57b33"}, 
										Yellow - {"dark":"#837704", "light":"#ead61e"}, GREEN - {"dark":"#3d7200", "light":"#89c346"}, */ 
								{"dark":"#104a8d", "light":"#7aa1ce"}, {"dark":"#aa6c42", "light":"#e5d3c6"},
								{"dark":"#7b3e80", "light":"#d7c5d9"}, {"dark":"#E56361", "light":"#EED2D1"} 
								];
				var joThresholdColors = { critical: '#F00', warning: '#FFBF00' };
				// stacked bar chart data's datum key's, color & tooltip display name; for other than health datum keys, TODO add respective key's details, in below JSON
				var STACK_BAR_DETAILS = {
					'ok_cnt': { color: '#43a047', tooltip_display_name: 'Ok' },
					'warning_cnt': { color: '#ffc200', tooltip_display_name: 'Warning' }, 
					'critical_cnt': { color: 'red', tooltip_display_name: 'Critical' }, 
					'V': { color: '#03569a', tooltip_display_name: 'Page View(s)' } 
				};
				
				// parent element width, height
				var PARENT_WIDTH = element.parent()[0].offsetWidth, PARENT_HEIGHT = 150;
				
				// TODO Ask, hardcoded values to convert from %, thinks 
				// Fixed width does not go well with responsive design hence made as percentage of parent height
				var MARGINS = { top: PARENT_HEIGHT*6/100, right: PARENT_WIDTH*8/100, bottom: PARENT_HEIGHT*20/100, left: PARENT_WIDTH*8/100},
								width = PARENT_WIDTH - MARGINS.left - MARGINS.right,
								height = PARENT_HEIGHT - MARGINS.top - MARGINS.bottom; 
								//halfOfWidth = (width - MARGINS.right)/2;
				
				var bisectDate = d3.bisector(function(d) { return d.T; }).left;
				
				var joLegendScreenSize = {}, LEGEND_HEIGHT = 25;
				
				function drawChart() {
					// gets xmin, xmax 
					var aryXminXmax = appedoDirectiveChartUtils.getXminXmax(data);
					// TODO: adjust xmin, xmax like `<appedo-area-chart-directive-load-test`, thinks based on slider, datetime filter, currentTime 
					
					// gets ymin, ymax; Note: with data ymin ymax, thresholds (`Critical`, `Warning`)'s calculated  
					var aryYminYmax = appedoDirectiveChartUtils.getYminYmax(data);//, yAxisCategoryKey
					// Adjust the min & max with a 5% value, to avoid the data-point on chart's top-bottom borders
					aryYminYmax[1] = Math.ceil(aryYminYmax[1] + aryYminYmax[1] * 5 / 100); // adding 5% of max value to ensure graph is within boundry
					aryYminYmax[0] = aryYminYmax[0] - Math.ceil(aryYminYmax[0] * 5 / 100); // min value is reduced by 5% of min graph value to ensure boundry is intact
					
					// for single group chartdata true; multiple charts data 
					bHasSingleGroupChartData = (data.length === 1);//, bMousemoveTooltip = ;
					// TODO: check, ymin, ymax; xmin, xmax correctly coming
					joLegendScreenSize = appedoDirectiveChartUtils.calcChartLegendSettings(width, data.length);	// TODO variable name corection joLegendSettings to joLegendScreenSize 
					console.info('LEGEND settings <> joLegendScreenSize: '+JSON.stringify(joLegendScreenSize));
					
					//console.info('aryXminXmax: '+aryXminXmax);
					//console.info('aryYminYmax: '+aryYminYmax);
					
					x = d3.time.scale()
								.range([0, width])
								.domain(aryXminXmax);
					
					y = d3.scale.linear()
								.range([height, 0])
								.domain(aryYminYmax);
					
					// x-axis time format used, if sets in directive attr `xaxisformat` else based on x-axis's min, max shown
					timeFormat = d3.time.format( attrs.xaxisformat !== undefined ? attrs.xaxisformat : appedoDirectiveChartUtils.getD3XAxisTimeFormat(aryXminXmax[0], aryXminXmax[1]));
					
					xAxis = d3.svg.axis()
									.scale(x)
									.orient("bottom")
									.ticks(5)
									.tickFormat(timeFormat);
					
					yAxis = d3.svg.axis()
								.scale(y)
								.orient("left")
								.ticks(5);
					// TODO: tickformat of human readable to have of multi-line chart 
					// for single chartdata, tickFormat sets
					if ( bHasSingleGroupChartData ) {
						yAxis.tickFormat(function(d) {
							var unit = data[0].dataPoints.rawdata.unit || '';
							// tried, to format the value in human readable format based on unit, conversion is done for the unit in size 
							var aryFormattedValue = appedoDataUtils.getHumanReadableFormat(d, unit, true);
							return aryFormattedValue[0]+' '+aryFormattedValue[1];
						});
					}
					
					/*
					 * SVG tooltip using <text> tag, Appedo-VelocityUI available, 
					 *  from the following link http://www.d3noob.org/2014/07/my-favourite-tooltip-method-for-line.html
					 */
					// tooltip
					divTooltip = d3.select("body")
									.append("div")
									.attr("class", "apd-chart-tooltip")
									.style("opacity", 1e-6);
					
					console.info('PARENT_HEIGHT + (LEGEND_HEIGHT * joLegendScreenSize.totalLegendLines): '+(PARENT_HEIGHT + (LEGEND_HEIGHT * joLegendScreenSize.totalLegendLines)));
					
					// creates SVG 
					svg = d3.select(element[0])
								.append('svg')
								.attr('width', PARENT_WIDTH)
								.attr('height', PARENT_HEIGHT + (LEGEND_HEIGHT * joLegendScreenSize.totalLegendLines))
								/*.attr('width', width)
								.attr('height', height)*/
								.append("g")
								.attr('transform', 'translate('+MARGINS.left+', '+MARGINS.top+')');
					// draw xaxis 
					svg.append("g")
						.attr("class", "x axis")
						.attr("transform", "translate(0, "+height+")")
						.call(xAxis); // Rotates the text in the x - axis.
					// draw yaxis 
					svg.append("g")
						.attr("class", "y axis")
						.call(yAxis);
					
					/*
					 * TODO AsK group threshold lines, if area <path> is after threshold line, in UI threshold line is not visible,
					 * (i.e. inside SVG to have order area, line, threshold lines )
					 */
					//var svgThresholdLines = svg.append("g").attr("class", "svgThresholdLines");
					
					
					// draw chartdata 
					data.forEach(function(joSingleChartGroupData, i) {
					//for (var i = 0; i < data.length; i = i + 1) {
						var joSingleChartGroupData = data[i];
						// joChartDataPoints has keys `rawdata`, `Critical`, `Warning`; optional `Critical`, `Warning`;
						var joChartDataPoints = joSingleChartGroupData.dataPoints;
						
						// TODO: ASK for multi-line graph, each line y scale in `Appedo-VelocityUI` directive `<appedo-multi-area-chart-break-set-directive`
						
						var joRawData = joChartDataPoints.rawdata;
						if ( bChartClickable ) {	// as multi-charts available, single chart has clickable to have point hover tooltip 
						} else {
							bChartClickable = joRawData.clickable || false;
						}
						if ( bMousemoveTooltip ) {	// as multi-charts available, single chart has mouseMove tooltip to have, to sets mousemove tooltip
						} else {
							bMousemoveTooltip = joRawData.mouseMoveTooltip || false;
						}
						
						if ( joRawData.chartType === 'area' || joRawData.chartType === 'line' ) {	// area chart to draw area, line, circle; line chart to draw line, circle 
							
							// checks chartdata is array in array format of [ [{T: , V:}, {T: , V:}, ...], [{T: , V:}, ...], ... ]
							var bDataArrayInArrayFormat = appedoDirectiveChartUtils.isDataArrayInArrayFormat(joRawData.data);
							// TODO: for multi-line chart already selected color not to set 
							// sets color 
							if ( joRawData.color === undefined ) {	// color !== undefined for threshold line
								//joSettingsLineData.color = joColor;
								var nRandom = Math.floor(Math.random() * aryColors.length)//, joColor = aryColors[nRandom];
								joRawData.color = aryColors[nRandom];
							}
							
							drawLineChart(svg, joRawData, joChartDataPoints, joSingleChartGroupData, bDataArrayInArrayFormat);
						} else if ( joRawData.chartType.indexOf('bar') >= 0 ) {	// TODO draw bar chart vertical bar or vertical stacked bar
							// sets default color for bar chart 
							joRawData.color = STACK_BAR_DETAILS.V.color;
							drawBarChart(svg, joRawData, joChartDataPoints, joSingleChartGroupData);
						}
						
						// TODO for multi-line graph tickformat to set 
						/*// yaxis tickformat, unit available in `joRawData`, added tickformat 
						yAxis.tickFormat(function(d) {
							console.info('<<<<<<<<<< yaxis tickFormat >>>>>>');
							// tried, to format the value in human readable format based on unit, conversion is done for the unit in size 
							var aryFormattedValue = appedoDataUtils.getHumanReadableFormat(d, joRawData.unit, true);
							console.info('human readable <> aryFormattedValue: '+aryFormattedValue);
							return aryFormattedValue[0]+' '+aryFormattedValue[1];
						});
						svg.append("g")
							.attr("class", "y axis")
							.call(yAxis);*/
						
						// threshold line `CRITICAL`
						var joCriticalData = joChartDataPoints.critical;
						if ( joCriticalData !== undefined ) {
							//console.info('11111111 <> dotted-line');
							joCriticalData.color = joThresholdColors.critical;
							drawLineChart(svg, joCriticalData, joChartDataPoints, joSingleChartGroupData);
						}
						// threshold line `WARNING`
						var joWarningData = joChartDataPoints.warning;
						if ( joWarningData !== undefined ) {
							//console.info('11111111 <> dotted-line');
							joWarningData.color = joThresholdColors.warning;
							drawLineChart(svg, joWarningData, joChartDataPoints, joSingleChartGroupData);
						}
						// TODO: bar (horizontal, vertical, progress), multi-line
						/* 
						for (var keyDataPoints in joChartDataPoints) {
							var joSettingsChartData = joChartDataPoints[keyDataPoints];
							
							// TODO area, line, bar (horizontal, vertical, progress), multi-line
							if ( joSettingsChartData.chartType === 'area' || joSettingsChartData.chartType === 'line' ) {
								drawLineChart(svg, joSettingsChartData);
							} else if ( joSettingsChartData.chartType === 'DOTTED-LINE' ) {
								drawAreaChart(svg, joSettingsChartData);
							}
						}*/
					//}
					});
					
					// for multi-line chartdata, tried mousemove tootip; TODO thinks from chartData.json to have option for mousemove tooltip 
					//if ( ! bHasSingleGroupChartData ) {
					
					// sets mousemove tooltip, of chart not clickable of point details, based on from json chart settings 
					bMousemoveTooltip = bChartClickable ? false : bMousemoveTooltip;
					// sets mousemove tooltip, for not chart point clickable, 
					if ( bMousemoveTooltip ) {
						setMousemoveTooltip(svg);
					}
					
					// to draw legend 
					drawLegend(svg);
				}
				// TODO: functions to have below drawLineChart(), drawAreaChart(), 
				
				/*
				 * draws for chartType `line` to draw line, circle; `area` to draw area, line, circle;
				 *   for threshold line to draw line
				 * svg,
				 * joSettingsLineData has {"chartType": "area", "data": [{}, {}, ...], }
				 * joChartDataPoints has { "rawdata": {"chartType": "area", "data": [{}, ...], }, "critical": {"chartType": "dotted-line", "data": [{}, {}, ...], }, "warning": {...} }
				 * joSingleChartGroupData has {"module": "APM", "type": "APPLICATION", "cardName": "", "dataPoints": <joChartDataPoints> }
				 */
				function drawLineChart(svg, joSettingsLineData, joChartDataPoints, joSingleChartGroupData, bDataArrayInArrayFormat) {
					// TODO for multi-line for second line different random color to get
					/* commented corrections, 
					var nRandom = Math.floor(Math.random() * aryColors.length), joColor = aryColors[nRandom];
					if ( joSettingsLineData.color === undefined ) {	// color !== undefined for threshold line
						//var nRandom = Math.floor(Math.random() * aryColors.length), joColor = aryColors[nRandom];
						//joSettingsLineData.color = joColor;
						joSettingsLineData.color = { dark: joColor.dark, light: joColor.light };
					}*/
					var joColor = joSettingsLineData.color,
						prefixEleId = joSingleChartGroupData.metricId+"_"+joSingleChartGroupData.id;
					
					//console.info('------- line color: '+JSON.stringify(joSettingsLineData.color)+' <> joSingleChartGroupData.metricName: '+joSingleChartGroupData.metricName);
					var yAxisCategoryKey = appedoDirectiveChartUtils.getYaxisCategoryPlotKey(joSettingsLineData);// joSettingsLineData.defaultYAxisKey || 'V';
					
					var line, area;
					var nLineWidth = joSettingsLineData.lineWidth, nCircleWidth = joSettingsLineData.circleWidth;
					var aryChartData = joSettingsLineData.data;
					
					// to draw area; thinks, if required to add below in fn. 
					if ( joSettingsLineData.chartType === 'area'  ) {
						area = d3.svg.area()
									.interpolate("linear")
									.x(function(d) { return x(d.T); })
									.y0(height)
									.y1(function(d) { return y(d[yAxisCategoryKey]); });
						
						if ( bDataArrayInArrayFormat ) {	// for data format [ [{T: , V: }, {T: , V: }, ...], [{T: , V: }, {T: , V: }, ...], ... ]
							svg	.append("g")
								.attr("class", "areaBreakSets")
								.attr("id", function(d, i){ return 'pathArea_'+prefixEleId; })
								.selectAll("pathset")
								.data(aryChartData)
								.enter().append("path")
								.datum(function(aryDataSet) { return aryDataSet; })
								//.attr("transform", "translate("+margin.left*3/2+", "+(0+5)+")")
								.style("fill", joColor.light)
								.attr("d", area)
								.attr("clip-path", "url(#clip)");
						} else {	// for data format [{T: , V: }, {T: , V: }, ...]
							svg.append("path")
								.attr("class", "area")
								.attr("id", function(d, i){ return 'pathArea_'+prefixEleId; })
								.datum(aryChartData)
								.style("fill", joColor.light)
								.attr("d", area)
								.attr("clip-path", "url(#clip)");
						}
					}
					
					line = d3.svg.line()//.interpolate("linear")
								.interpolate(joSettingsLineData.interpolate)
								.x(function(d) { return x(d.T); })
								.y(function(d) { return y(d[yAxisCategoryKey]); });
					
					// TODO: for discontinuous line, data array in array format [ [{T: , V}, {T: , V}], ... ]
					/* tried using variable, commented as data array in array format; future use 
					var pathLine = svg.append("path")
										.attr("class", "line")
										.attr("d", line(aryChartData))
										.style("stroke-width", nLineWidth);
					*/
					if ( joSettingsLineData.chartType === 'dotted-line' ) {	// threshold line,
						/* tried using variable, commented as data array in array format; future use  
						pathLine.attr("stroke", joSettingsLineData.color)
								.style("stroke-dasharray", "10,3");*/
						
						//svg.selectAll('g.svgThresholdLines')
						svg.append("path")
							.attr("class", "line")
							.attr("id", function(d, i){ return 'pathThresholdLine_'+prefixEleId; })
							.attr("d", line(aryChartData))
							.style("stroke-width", nLineWidth)
							.attr("stroke", joSettingsLineData.color)
							.style("stroke-dasharray", "10,3");
					} else {	// line plots, line + circle 
						// line 
						/* tried using variable, commented as data array in array format; future use  
						pathLine.attr("stroke", function(d) { return joColor.dark; });
						*/
						
						if ( bDataArrayInArrayFormat ) {	// for data format [ [{T: , V: }, {T: , V: }, ...], [{T: , V: }, {T: , V: }, ...], ... ]
							// TODO: thinks to use using variable as to reuse 
							svg	.append("g")
								.attr("class", "lineBreakSets")
								.attr("id", function(d, i){ return 'pathLine_'+prefixEleId; })
								.selectAll("pathset")
								.data(aryChartData)
								.enter().append("path")
								.attr("class", "line")
								.attr("d", function(aryDataSet){ return line(aryDataSet); } )
								.style("stroke-width", nLineWidth)
								.attr("stroke", function(d) { return joColor.dark; });
						} else {	// for data format [{T: , V: }, {T: , V: }, ...]
							svg	.append("path")
								.attr("class", "line")
								.attr("id", function(d, i){ return 'pathLine_'+prefixEleId; })
								.attr("d", line(aryChartData))
								.style("stroke-width", nLineWidth)
								.attr("stroke", function(d) { return joColor.dark; });
						}
						
						
						// circle
						if ( bDataArrayInArrayFormat ) {	// for data format [ [{T: , V: }, {T: , V: }, ...], [{T: , V: }, {T: , V: }, ...], ... ]
							// TODO: reuse from `.append('circle')`, as access from variable 
							
							svg	.append("g")
								.attr("class", "dotCicleSets")
								.attr("id", function(d, i){ return 'dotCricle_'+prefixEleId; })
								.selectAll("cicleset")
								.data(aryChartData)
								.enter().append("g")
								.attr("class", "dotset")
								.selectAll("dot")
								.data(function(aryDataSet) { return aryDataSet; })
								.enter().append('circle')
								.style("cursor", "pointer")
								.on("click", function(d) {
									// loads respective point details, calls controller fn. 
									loadPointDetails(d);
								})
								.attr("cx", function(d) { return x(d.T); })
								.attr("cy", function(d) { return y(d[yAxisCategoryKey]); })
								.attr("r", nCircleWidth+"px")
								.attr("fill", function(d) { return joColor.dark; })
								.on("mouseover", function(d) {
									// highlight on mouse over
									d3.select(this)
										.attr("r", 5)
										.style("opacity", 0.5);
									
									// divTooltip shown
									// after `transition`, attribute `style` or `...tween` only works, if `.html(toolTipText)` presents error throws; thinks 
									divTooltip.html(getTooltipText(d, yAxisCategoryKey, joSettingsLineData.unit, joChartDataPoints, joSingleChartGroupData, true))
											.style("top", (d3.event.pageY - 10)+"px")
								   			.style("left", (d3.event.pageX + 10)+"px")
								   			.transition()
											.duration(200)
											.style("opacity", 0.80);
								})
								.on("mouseout", function(d) {
									// un-highlight on mouse over 
									d3.select(this)
										.attr("r", nCircleWidth+"px")
										.style("opacity", 1);
									
									// tooltip hide
									divTooltip.transition()
											.duration(200)
											.style("opacity", 1e-6);
								})
								/* div tooltip, title 
								.append("title")
								.text(function(d) {
									return getTooltipText(d, joSettingsLineData, yAxisCategoryKey, joChartDataPoints);
								});*/
						} else {	// for data format [{T: , V: }, {T: , V: }, ...]
							// TODO: reuse from `.append('circle')`, as access from variable 
							
							svg	.append('g')
								.attr("class", "dot")
								.attr("id", function(d, i){ return 'dotCricle_'+prefixEleId; })
								.selectAll("dot")
								.data(aryChartData)
								.enter().append('circle')
								.style("cursor", "pointer")
								.on("click", function(d) {
									// loads respective point details, calls controller fn. 
									loadPointDetails(d);
								})
								.attr("cx", function(d) { return x(d.T); })
								.attr("cy", function(d) { return y(d[yAxisCategoryKey]); })
								.attr("r", nCircleWidth+"px")
								.attr("fill", function(d) { return joColor.dark; })
								.on("mouseover", function(d) {
									// highlight on mouse over
									d3.select(this)
										.attr("r", 5)
										.style("opacity", 0.5);
									
									// divTooltip shown
									divTooltip.transition()
											.duration(200)
											.style("opacity", 0.80);
									// added as separate; after `.transition()` thinks, style, attr, tween only works 
									divTooltip.html(getTooltipText(d, yAxisCategoryKey, joSettingsLineData.unit, joChartDataPoints, joSingleChartGroupData, true))
											.style("top", (d3.event.pageY - 10)+"px")
								   			.style("left", (d3.event.pageX + 10)+"px");
								})
								.on("mouseout", function() {
									// un-highlight on mouse over 
									d3.select(this)
										.attr("r", nCircleWidth+"px")
										.style("opacity", 1);
									
									// tooltip hide
									divTooltip.transition()
											.duration(200)
											.style("opacity", 1e-6);
								})
								/* title tooltip, 
								.append("title")
								.text(function(d) {
									return getTooltipText(d, joSettingsLineData, yAxisCategoryKey, joChartDataPoints);
								});*/
						}
						// TODO: point click to call function 
					}
				}
				
				// 
				function drawLegend(svg) {
					//console.info('1111111111111 drawLegend');
					var legendLineHeight = 20;
					var nIdxLegendLineNumber;// = 0;
					
					
					// adding legend 
					var legend = svg.selectAll('g.legend')
									.data(data)
									.enter()
									.append('g')
									.attr('class', 'legend');//legend font_14
					nIdxLegendLineNumber = 0;
					// rect 
					legend.append('rect')
						.attr('x', function(d, i){
							/*if( i>0 && i % 4 === 0){
								xFormatterRect = -1;
							}
							xFormatterRect += 1;
							return ((legendSpace/4)+xFormatterRect*legendSpace)-25;*/
							
							//return (joLegendScreenSize.width + ((i%4)+1) * joLegendScreenSize.width);
							//return ( ((i%4) + 1) * joLegendScreenSize.width);
							return (i%joLegendScreenSize.totalLegendInSingleLine) * joLegendScreenSize.width;
						})
						.attr('y', function(d, i){
							/*if( i>0 && i % 4 === 0){
								yFormatterRect += 20;
							}
							return (height + ((margin.bottom+10)/2)+ yFormatterRect);*/
							/* tried 
							var nIdxLineNumber = 0;
							if ( i > 0 && joLegendScreenSize.totalLegendLines > 1 && (i%joLegendScreenSize.totalLegendInSingleLine) === 0 ) {
								// added Math.floor(), say to return 1.9 as 1, 1.4 as 1; Math.floor(), rounded downwards to nearest integer 
								nIdxLineNumber = Math.floor(i/joLegendScreenSize.totalLegendLines);
							}*/
							
							// TODO: tell ask, find based on `i` idx, which line 
							
							if ( i > 0 && (i%joLegendScreenSize.totalLegendInSingleLine) === 0 ) {
								nIdxLegendLineNumber += 1;
							}
							return height + MARGINS.bottom + (nIdxLegendLineNumber * legendLineHeight);//+((i%joLegendScreenSize.totalLegendLines) * legendLineHeight);
						})
						.attr('width', 12)
						.attr('height', 10)
						.style("stroke", "black")
						.style("stroke-width", "0.5px")
						.style('fill', function(joSingleChartGroupData) { 
							//return color(d.label);
							// commented correction return joSingleChartGroupData.dataPoints.rawdata.color.dark;
							return appedoDirectiveChartUtils.getColorFromChartSettings(joSingleChartGroupData.dataPoints.rawdata);
						});
					
					nIdxLegendLineNumber = 0;
					// tick 
					legend.append('text')
						.attr('x', function(d, i){
							/*if( i>0 && i % 4 === 0){
								xFormatterCheck = -1;
							}
							xFormatterCheck += 1;
							return ((legendSpace/4)+xFormatterCheck*legendSpace)-22;*/
							return (i%joLegendScreenSize.totalLegendInSingleLine) * joLegendScreenSize.width+2;
						})
						.attr('y', function(d, i){
							/*if( i>0 && i % 4 === 0){
								yFormatterCheck += 20;
							}
							// added `-2`, since to the tick mark to come litle above `rect`
							return (10+ height + ((margin.bottom+10)/2)+ yFormatterCheck) - 2;*/
							
							/*var nIdxLineNumber = 0;
							if ( joLegendScreenSize.totalLegendLines > 1 ) {
								// added Math.floor(), say to return 1.9 as 1, 1.4 as 1; Math.floor(), rounded downwards to nearest integer 
								nIdxLineNumber = Math.floor(i/joLegendScreenSize.totalLegendLines);
							}*/
							
							// TODO: tell ask, find based on `i` idx, which line 
							
							if ( i > 0 && (i%joLegendScreenSize.totalLegendInSingleLine) === 0 ) {
								nIdxLegendLineNumber += 1;
							}
							return height + MARGINS.bottom + (nIdxLegendLineNumber * legendLineHeight)+8;
						})
						.style('fill', '#74c476')
						.style('font-size', '18px')
						.style('cursor', 'pointer')
						.attr("id", function(joSingleChartGroupData, i) { return "legendTick_"+joSingleChartGroupData.metricId+"_"+joSingleChartGroupData.id; })
						.html(' &#xf00c;')
						.on("click", function(d, i){ mouseclick(d, i); });
					
					nIdxLegendLineNumber = 0;
					// legend 
					legend.append('text')
						.attr('x', function(d, i){
							/*if( i>0 && i % 4 === 0){
								xFormatterText = -1;
								}
							xFormatterText += 1;
							return (legendSpace/4)+xFormatterText*legendSpace;*/
							
							// added `+ 20`(i.e. rect's width `12`, remaining `8` padding) to have space from legend `rect`
							return (i%joLegendScreenSize.totalLegendInSingleLine) * joLegendScreenSize.width + 20;
						})
						.attr('y', function(d, i){
							/*if( i>0 && i % 4 === 0){
								yFormatterText += 20;
								}
							return (10+ height + ((margin.bottom+10)/2)+ yFormatterText);*/
							
							/*var nIdxLineNumber = 0;
							if ( joLegendScreenSize.totalLegendLines > 1 ) {
								// added Math.floor(), say to return 1.9 as 1, 1.4 as 1; Math.floor(), rounded downwards to nearest integer 
								nIdxLineNumber = Math.floor(i/joLegendScreenSize.totalLegendLines);
							}*/
							
							// TODO: tell ask, find based on `i` idx, which line 
							
							if ( i > 0 && (i%joLegendScreenSize.totalLegendInSingleLine) === 0 ) {
								nIdxLegendLineNumber += 1;
							}
							// added `+ 10` to have space from legend `rect`
							return height + MARGINS.bottom + (nIdxLegendLineNumber * legendLineHeight) + 10;
						})
						.attr('width', 20)
						.attr('class', 'apd-text-overflow-ellipsis apd-chart-legend-text')
						.style('fill', function(joSingleChartGroupData) { return appedoDirectiveChartUtils.getColorFromChartSettings(joSingleChartGroupData.dataPoints.rawdata); /*joSingleChartGroupData.dataPoints.rawdata.color.dark;*/ /*return color(d.label);*/ })
						.style('cursor', 'pointer')
						.text(function(joSingleChartGroupData){
							//var legendText = joSingleChartGroupData.type+' :: '+joSingleChartGroupData.cardName+' :: '+joSingleChartGroupData.metricCategory+' :: '+joSingleChartGroupData.metricName,
							//console.info('joLegendScreenSize.lgTextWidth: '+joLegendScreenSize.lgTextWidth);
							var legendText = joSingleChartGroupData.metricName,
								outText = ""; if( legendText.length > joLegendScreenSize.lgTextWidth ){ outText = legendText.substring(0, joLegendScreenSize.lgTextWidth)+'...'; } else { outText = legendText; };
							return outText;
						})
						.on("mouseover", function(joSingleChartGroupData) {
							d3.select(this).style("font-weight", "bold");
							var tooltipText = '';
							tooltipText = joSingleChartGroupData.type+' :: '+joSingleChartGroupData.cardName+'<BR/>'+joSingleChartGroupData.metricCategory+' :: '+joSingleChartGroupData.metricName;
							// divTooltip shown
							// added as separate; after `.transition()` thinks, attribute `style`, `attr`, `tween` only works
							divTooltip.html(tooltipText)
									.style("top", (d3.event.pageY - 10)+"px")
						   			.style("left", (d3.event.pageX + 10)+"px")
						   			.transition()
									.duration(200)
									.style("opacity", 0.80);
						})
						.on("mouseout", function(d) {
							d3.select(this).style("font-weight", "");
							// tooltip hide
							divTooltip.transition()
									.duration(200)
									.style("opacity", 1e-6);
						})
						.on("click", function(d, i){ mouseclick(d, i); })
						.append("title")
						.text(function(joSingleChartGroupData){
							var legendText = joSingleChartGroupData.type+' :: '+joSingleChartGroupData.cardName+' :: '+joSingleChartGroupData.metricCategory+' :: '+joSingleChartGroupData.metricName;
							return legendText;
						});
					
					function mouseclick(joSingleChartGroupData, i){
						// Determine if current line is visible 
						var bHide = joSingleChartGroupData.hide ? false : true, 
								newOpacity = bHide ? 0 : 1,
								newEvent = bHide ? "none" : "all",
								prefixEleId = joSingleChartGroupData.metricId+"_"+joSingleChartGroupData.id;
						
						// hide or show, the check
						d3.select("#legendTick_"+prefixEleId)
								.transition().duration(100)
								.style("opacity", newOpacity);
						
						// Hide or show, the line, circle and setting pointer-events to none to hide title.
						d3.select('#pathLine_'+prefixEleId)
								.transition().duration(100) 
								.style("pointer-events", newEvent)
								.style("opacity", newOpacity);
						// Hide or show, area 
						d3.select('#pathArea_'+prefixEleId)
								.transition().duration(100) 
								.style("pointer-events", newEvent)
								.style("opacity", newOpacity);
						// Hide or show, circle 
						d3.select('#dotCricle_'+prefixEleId)
								.transition().duration(100) 
								.style("pointer-events", newEvent)
								.style("opacity", newOpacity);
						// Hide or show, threhold lines; Note `d3.selectAll` added as threshold lines `id` is same for waning, critical to hide both added `selectAll`
						d3.selectAll('#pathThresholdLine_'+prefixEleId)
								.transition().duration(100) 
								.style("pointer-events", newEvent)
								.style("opacity", newOpacity);
						// Hide or show, threhold lines; Note `d3.selectAll` added as threshold lines `id` is same for waning, critical to hide both added `selectAll`
						d3.selectAll('#rectBar_'+prefixEleId)
								.transition().duration(100) 
								.style("pointer-events", newEvent)
								.style("opacity", newOpacity);
						
						// Update whether or not the elements are active
						joSingleChartGroupData.hide = bHide;
					}
				}
				
				// 
				function drawBarChart(svg, joSettingsBarData, joChartDataPoints, joSingleChartGroupData) {
					var color = d3.scale.ordinal(),
						aryChartData = joSettingsBarData.data/*angular.copy(joSettingsBarData.data)*/, nBarWidth = joSettingsBarData.barWidth,
						prefixEleId = joSingleChartGroupData.metricId+"_"+joSingleChartGroupData.id;
					//console.info('>>>>>>>>>>>>>>> drawBarChart');
					
					// keys for stacked barchart
					//var aryKeys = d3.keys(joSettingsBarData.data[0]).filter(function(key) { return key !== "T" && key !== "V"; });
					// sets bar color for, default single bar chart OR stacked bar chart
					if ( joSettingsBarData.chartType === 'bar' ) {	// default bar chart 	
						// plot color
						color.domain(['V'])
							.range([ joSettingsBarData.color ]);
					} else if ( joSettingsBarData.chartType === 'bar-stack' ) {	// health wise, stacked bar chart 
						var aryPlotRange = [];
						// keys for stacked barchart 
						/* commented corrections 
						var aryKeys = d3.keys(aryChartData[0]).filter(function(key) { return key !== "T" && key !== "V"; });
						*/
						var aryKeys = d3.keys(aryChartData[0]).filter(function(key) { return key !== "V" && STACK_BAR_DETAILS[key] !== undefined; });
						joSettingsBarData.keys = aryKeys;
						// adds colors for respective datum keys
						for (var i = 0; i < aryKeys.length; i = i + 1) {
							var key = aryKeys[i];
							aryPlotRange.push(STACK_BAR_DETAILS[key].color);
						}
						
						// plot color 
						color.domain(aryKeys)
							.range(aryPlotRange);
					}
					// bars to have based on `color` scale
					aryChartData.forEach(function(d, i) {
						var y0 = 0;
						d.health = color.domain().map(function(code) {
							return {
								name: code,
								y0: y0,
								y1: y0 += (+d[code] || 0),
								color: color(code)
							};
						});
					});
					
					var bar = svg.append('g')
								.attr("class", "bars")
								.attr("id", "rectBar_"+prefixEleId)
								.selectAll(".bar")
								.data(aryChartData)
								.enter().append("g")
								.attr("class", "bar")
								.style("opacity", bMousemoveTooltip ? 0.65 : null)
								.on("click", function(d) {
									/* TODO: call event, 
									// loads fn.
									if ( expressionHandler !== undefined ) {
										expressionHandler(d);	
									}*/
									
									// loads respective point details, calls controller fn. 
									loadPointDetails(d);
								})
								.on("mouseover", function(d) {
									/*var xPos = parseFloat(d3.select(this).attr("x"));
									var yPos = parseFloat(d3.select(this).attr("y"));*/
									
									/*var aryDomain = color.domain();
									// formats, tooltip text
									var toolTipText = 'Time: '+tooltipTimeFormat(new Date(d.T))+'<BR>Page View(s): '+d.V;
									for(var i = 0; i < aryDomain.length; i = i + 1) {
										if ( aryDomain[i] !== 'V' && d[aryDomain[i]] !== undefined && d[aryDomain[i]] > 0 ) {
											toolTipText += '<BR>'+KEYS_DETAILS[aryDomain[i]].tooltip_display_name+': '+d[aryDomain[i]];
										}
									}*/
									
									// for highlight
									d3.select(this)
										.style("opacity", 0.65);
									
									// tooltip shown 
									// after `transition`, attribute `style` or `...tween` only works, if `.html(toolTipText)` presents error throws; thinks 
									divTooltip.html(getTooltipText(d, 'V', joSettingsBarData.unit, joChartDataPoints, joSingleChartGroupData, true))
											.style("top", (d3.event.pageY - 10)+"px")
											.style("left", (d3.event.pageX + 10)+"px")
											.transition()
											.duration(200)
											/* after transistion, position added `div` moves as animation
											.style("top", (d3.event.pageY - 10)+"px")
											.style("left", (d3.event.pageX + 10)+"px")*/
											.style("opacity", 0.8);
								})
								.on("mouseout", function(d) {
									// reset highlight
									d3.select(this)
										.style("opacity", 1);
									
									// hides tooltip 
									divTooltip.transition()
											.duration(200)
											.style("opacity", 1e-6);
								})
								.attr("transform", function(d) { return "translate(" + x(new Date(d.T)) + ",0)"; });
					// plots single or stacked bar chart
					bar.selectAll("rect")
						.data(function(d) { return d.health; })
						.enter().append("rect")
						.attr("width", nBarWidth)
						.attr("height", function(d) { return y(d.y0) - y(d.y1); })
						.attr("y", function(d) { return y(d.y1); })
						.style("fill", function(d) { return d.color;/*color(d.name);*/ });
				}
				
				// TODO mouse move tooltip
				function setMousemoveTooltip(svg) {
					var aryNearestGraphPoints = [], 
						aryCirclesPlot = ['line', 'area'],
						aryBarsPlot = ['bar', 'bar-stack'],
						nBarWidth = 5 /* TODO: have to get from JSON */;
					var chartData = svg .append('g')
										.attr('class', 'svgmousemove')
										.selectAll('g.svgmousemove')
										.data(data);
										//.filter(function(joSingleChartGroupData) { console.info('------------>>>>> circle filter'); console.info('joSingleChartGroupData: '+JSON.stringify(joSingleChartGroupData));  return joSingleChartGroupData; });
					
					var circleHighlight = //chartData.data().filter(function(d, i) { console.info('d: '+JSON.stringify(d)); return i % 2 === 1; })
										chartData.enter()
											/*.selectAll('g.gCircleNearestPoint')
											.data(function(joSingleChartGroupData) { console.info('joSingleChartGroupData: '+JSON.stringify(joSingleChartGroupData));  return d.breaches || []; })
											//.filter(function(joSingleChartGroupData) { console.info('------------>>>>> circle filter'); console.info('joSingleChartGroupData: '+JSON.stringify(joSingleChartGroupData));  return joSingleChartGroupData; })*/
											//.enter()
											.append('g')
											// append `circle` for line, area chart 
											.filter(function(joSingleChartGroupData){ return aryCirclesPlot.indexOf(joSingleChartGroupData.dataPoints.rawdata.chartType) >= 0; })
											//.attr('class', 'gCircleNearestPoint')
											.append('circle')
											.attr('cx', 0)
											.attr('cy', 0)
											.attr('opacity', 0)
											.attr('r', 4)
											.attr('fill', function(joSingleChartGroupData, i) {
												/* commented corrections,
												var color = joSingleChartGroupData.dataPoints.rawdata.color;
												// color sets in `drawLineChart`
												
												return color.dark;
												*/
												return appedoDirectiveChartUtils.getColorFromChartSettings(joSingleChartGroupData.dataPoints.rawdata);
												
												/*if ( typeof color === 'string' ) {
													return color;
												} else if ( color instanceof Object ) {
													return color.dark;
												}*/
											})
											.each(function(joSingleChartGroupData) {
												//console.info('11111222222233333334544555555 each each');
												//d3.select(this).remove();
											});
											//.attr("transform", "translate("+MARGINS.left*3/2+", "+(0+5)+")")
											// transform adds inside <g; .attr('transform', 'translate('+MARGINS.left+', '+MARGINS.top+')');
					
					// TODO bar, line in single chart mousemove tooltip, TODO highlight bar in Appedo-VelocityUI directive `<appedoMultiAreaChartBreakSetDirective`
					var barHighlight = chartData.enter()
												.append('g')
												.attr('class', 'gBarHighlight')
												//.filter(function(joSingleChartGroupData){ return aryBarsPlot.indexOf(joSingleChartGroupData.dataPoints.rawdata.chartType) >= 0; })
												.each(function(joSingleChartGroupData) {
													//console.info('11111222222233333334544555555 each each');
													// removes `g` element, other than bar chart 
													if ( aryBarsPlot.indexOf(joSingleChartGroupData.dataPoints.rawdata.chartType) === -1 ) {
														d3.select(this).remove();	
													}
												});
												/*.selectAll('g.gBarHighlight')
												.filter(function(joSingleChartGroupData){ return aryBarsPlot.indexOf(joSingleChartGroupData.dataPoints.rawdata.chartType) >= 0; })*/
												/* commented corrections, .append('rect')
												.attr("width", barWidth)
												.attr("height", height)
												//.attr("stroke-width", "2px")
												.attr("x", 0)
												.attr("y", 0)
												.style("opacity", 0);*/
					
					svg	.append("rect")
						.attr("class", "overlay")
						.style("fill", "none")
						.style("pointer-events", "all")
						//.attr("width", width - MARGINS.left)
						.attr("width", width)
						.attr("height", height)
						/* multi-line charts, mousemouse onclick of chart nearest filterd points available in click fn. `aryNearestGraphPoints` which is declared above 
						.on("click", function() {
							console.info('aryNearestGraphPoints: '+JSON.stringify(aryNearestGraphPoints));
						})*/
						// transform adds inside <g; .attr('transform', 'translate('+MARGINS.left+', '+MARGINS.top+')')
						.on("mouseover", function() {
							/* added to show of `circle`, `divTooltip` inside mousemove fn., as chartdata hide from legend selection, not to show the circle, divTooltip
							circle.attr('opacity', 1);
							
							// tooltip shown 
							divTooltip.transition()
									.duration(200)
									.style("opacity", 0.80);
							*/
						})
						.on("mouseout", function() {
							circleHighlight.attr('opacity', 0);
							
							barHighlight.attr('opacity', 0);
							
							/* TODO
							rectBreaches.transition().duration(50)
										.style ('opacity', 0)
										.attr("stroke-width", "2px");*/
							
							// tooltip hide 
							divTooltip.transition()
									.duration(200)
									.style("opacity", 1e-6);
							
							// |||ly oldUI tooltip, since not hided sometimes moves out of chart 
							// $("#tooltip").hide();
						})
						.on("mousemove", mousemove);
					
					function mousemove() {
						var x0 = x.invert(d3.mouse(this)[0]), toolTipText = '';
							aryNearestGraphPoints = data.map(function(joSingleChartGroupData, idx) {
								var bHideChartData = joSingleChartGroupData.hide || false;
								if ( bHideChartData ) {	// chart data to hide in tooltip 
									return;
								}
								
								var joRtn = {
									module: joSingleChartGroupData.module,
									type: joSingleChartGroupData.type,
									
									cardName: joSingleChartGroupData.cardName,
									metricCategory: joSingleChartGroupData.metricCategory,
									metricName: joSingleChartGroupData.metricName,
									metricId: joSingleChartGroupData.metricId,
									dataPoints: { rawdata: {} }// optional critical, warning 
								}, joChartDataPoints = {}, aryChartData = [], joDatumNearestPoint = {};
								// TODO: nearest datapoints to set 
								joChartDataPoints = joSingleChartGroupData.dataPoints;// has { rawdata: {}, critical: {}, warning: {} }
								
								// rawdata's nearest point 
								var joRawData = joChartDataPoints.rawdata;
								aryChartData = joRawData.mergedata || joRawData.data;
								// gets mousemove's nearest point from `aryChartData`
								joDatumNearestPoint = getNearestDatumBasedOnTime(aryChartData, x0);
								// sets `rawdata` joRtn of mousemove's nearest point 
								/* commented corrections, joRtn.dataPoints.rawdata.chartType = joRawData.chartType;
								joRtn.dataPoints.rawdata.defaultYAxisKey = appedoDirectiveChartUtils.getYaxisCategoryPlotKey(joRawData);//joRawData.defaultYAxisKey;
								joRtn.dataPoints.rawdata.color = joRawData.color;
								joRtn.dataPoints.rawdata.unit = joRawData.unit;*/
								// sets chart settings other than data 
								appedoDirectiveChartUtils.setChartSettingsOtherThanData(joRawData, joRtn.dataPoints.rawdata);
								joRtn.dataPoints.rawdata.dataNearestPoint = joDatumNearestPoint;// in JSON
								
								//console.info('x0: '+x0+' <> joRawData: joDatumNearestPoint: ');
								//console.info(joDatumNearestPoint);
								
								
								// threshold line `WARNING`, nearest point 
								var joWarningData = joChartDataPoints.warning;
								if ( joWarningData !== undefined ) {
									aryChartData = joWarningData.data;
									joDatumNearestPoint = getNearestDatumBasedOnTime(aryChartData, x0);
									joRtn.dataPoints.warning = {};
									/* commented corrections, joRtn.dataPoints.warning.chartType = joWarningData.chartType;
									joRtn.dataPoints.warning.color = joWarningData.color;
									joRtn.dataPoints.warning.unit = joWarningData.unit;*/
									// sets chart settings other than data 
									appedoDirectiveChartUtils.setChartSettingsOtherThanData(joWarningData, joRtn.dataPoints.warning);
									joRtn.dataPoints.warning.dataNearestPoint = joDatumNearestPoint;// in JSON
								}
								// threshold line `CRITICAL`, nearest point 
								var joCriticalData = joChartDataPoints.critical;
								if ( joCriticalData !== undefined ) {
									aryChartData = joCriticalData.data;
									joDatumNearestPoint = getNearestDatumBasedOnTime(aryChartData, x0);
									joRtn.dataPoints.critical = {};
									/* commented corrections, joRtn.dataPoints.critical.chartType = joCriticalData.chartType;
									joRtn.dataPoints.critical.color = joCriticalData.color;
									joRtn.dataPoints.critical.unit = joCriticalData.unit;*/
									// sets chart settings other than data 
									appedoDirectiveChartUtils.setChartSettingsOtherThanData(joCriticalData, joRtn.dataPoints.critical);
									joRtn.dataPoints.critical.dataNearestPoint = joDatumNearestPoint;// in JSON
								}
								//aryChartData
								
								//console.info('1111111 joRtn: ');
								//console.info(joRtn);
								
								return joRtn;
							});
						//console.info('----->>> aryNearestGraphPoints ');
						//console.info(aryNearestGraphPoints);
						
						// filters undefined values 
						aryNearestGraphPoints = aryNearestGraphPoints.filter(function(d) { return d !== undefined });
						for (var i = 0; i < aryNearestGraphPoints.length; i = i + 1) {
							var joSingleChartNearestPoint = aryNearestGraphPoints[i],
								joChartDataPoints = joSingleChartNearestPoint.dataPoints, 
								joSettingsLineData = joChartDataPoints.rawdata,
								yAxisCategoryKey = appedoDirectiveChartUtils.getYaxisCategoryPlotKey(joSettingsLineData),//joSettingsLineData.defaultYAxisKey/* || 'V'*/, 
								newLine = '<BR/>';
							
							toolTipText += /*(i !== 0 ? newLine : '')+*/getTooltipText(joSettingsLineData.dataNearestPoint, yAxisCategoryKey, joSettingsLineData.unit, joChartDataPoints, joSingleChartNearestPoint, true);
						}
						chartData = chartData.data(aryNearestGraphPoints);
						circleHighlight.data( /* gets line, area chart points */ aryNearestGraphPoints.filter(function(joSingleChartGroupData){ return aryCirclesPlot.indexOf(joSingleChartGroupData.dataPoints.rawdata.chartType) >= 0; }) )
									.attr('opacity', 1)
									.attr('cx', function(joSingleChartGroupData) {
										return x(joSingleChartGroupData.dataPoints.rawdata.dataNearestPoint.T);
									})
									.attr('cy', function(joSingleChartGroupData) {
										var yAxisCategoryKey = appedoDirectiveChartUtils.getYaxisCategoryPlotKey(joSingleChartGroupData.dataPoints.rawdata);//joSingleChartGroupData.dataPoints.rawdata.defaultYAxisKey/* || 'V'*/;
										
										/* yaxis of each line 
										return d.y(d[yaxiscategory]);
										*/
										return y(joSingleChartGroupData.dataPoints.rawdata.dataNearestPoint[yAxisCategoryKey]);
									});
						
						barHighlight.selectAll("rect").remove();
						
						// gets bar chart points 
						var aryBarsNearestPoints = aryNearestGraphPoints.filter(function(joSingleChartGroupData){ return aryBarsPlot.indexOf(joSingleChartGroupData.dataPoints.rawdata.chartType) >= 0; });
						// add 
						/*var bars = */barHighlight.data(aryBarsNearestPoints)
											.attr('opacity', 1)
											.attr("transform", function(joSingleChartGroupData) { return "translate("+ x(joSingleChartGroupData.dataPoints.rawdata.dataNearestPoint.T) +",0)"; })
											/* comment corrections as bar width to set,
											.selectAll("rect")
											.data(function(joSingleChartGroupData) { return joSingleChartGroupData.dataPoints.rawdata.dataNearestPoint.health; })
											.enter().append("rect")
											//.datum(function(d) { console.info('d: '+JSON.stringify(d)); return d; })
											.attr("class", "rectBarHighlight")
											.attr("height", function(d) { return y(d.y0) - y(d.y1); })
											.attr("y", function(d) { return y(d.y1); })
											.style("fill", function(d) { return d.color; });*/
						
						aryBarsNearestPoints.forEach(function(joSingleChartGroupData, i) {
							var aryHealth = joSingleChartGroupData.dataPoints.rawdata.dataNearestPoint.health,
								nBarWidth = joSingleChartGroupData.dataPoints.rawdata.barWidth;
							
							barHighlight.selectAll("rect.rectBarHighlight")
									.data(aryHealth)
									.enter().append("rect")
									.attr("class", "rectBarHighlight")
									.attr('width', nBarWidth)
									.attr("height", function(d) { return y(d.y0) - y(d.y1); })
									.attr("y", function(d) { return y(d.y1); })
									.style("fill", function(d) { return d.color; });
						});
						
						/* working for single bar in stacked of 3 bars of ok, warning, critical 
						barHighlight.selectAll("rect.rectBarHighlight")
								.data(aryBarsNearestPoints)
								.attr('width', function(joSingleChartGroupData) { return joSingleChartGroupData.dataPoints.rawdata.barWidth; });
						*/
						/*barHighlight.data(aryBarsNearestPoints)
								.selectAll("rect.rectBarHighlight")
								.datum(function(joSingleChartGroupData) { return joSingleChartGroupData.dataPoints.rawdata.barWidth; })
								.attr("width", function(d) { return d; } );*/
						
											//.attr("width", function(joSingleChartGroupData) { return joSingleChartGroupData.dataPoints.rawdata.barWidth || nBarWidth; })	// TODO bar width to set from JSON chart settings
											/*
											.each(function(joSingleChartGroupData) {
												var aryHealth = joSingleChartGroupData.dataPoints.rawdata.dataNearestPoint.health, joHealth = {};
												
												for (var i = 0; i < aryHealth.length; i = i + 1) {
													joHealth = aryHealth[i];
													
													d3.select(this)
														.attr("height", y(joHealth.y0) - y(joHealth.y1))
														.attr("y", y(joHealth.y1) )
														.style("fill", joHealth.color );
												}
											})*/
						/* commented corrections, 
						//bars//.selectAll("rect.barMouseMove")
							.datum(function(joSingleChartGroupData) { return joSingleChartGroupData.dataPoints.rawdata.dataNearestPoint.health; })
							
							// TODO thinks in .each( d3.select(this).attr('heigth' <>) )
							
							//.enter()//.append("rect")
							.attr("height", function(d) { return y(d.y0) - y(d.y1); })
							//.attr('opacity', 1)
							.attr("y", function(d) { return y(d.y1); })
							.style("fill", function(d) { return d.color; });
						*/
						
						// tried, using d3 
						divTooltip.html(toolTipText)
								.style("top", (d3.event.pageY - 10)+"px")
					   			.style("left", (d3.event.pageX + 10)+"px");
						if ( toolTipText.length > 0 ) {
							// tooltip shown
							divTooltip.transition()
									.duration(200)
									.style("opacity", 0.80);
						}
					}
				}
				
				
				// gets nearest datum from the aryChartData for the given time 
				function getNearestDatumBasedOnTime(aryChartData, nTime) {
					var i = bisectDate(aryChartData, nTime, 1) /* gets idx, nearest point of line's datum(i.e.joDatum.T) from chartdata */,
						d0 = aryChartData[i - 1],
						d1 = aryChartData[i],
						d = ((d0 === undefined || d1 === undefined) ? d0 || d1 : (nTime - d0.T > d1.T - nTime ? d1 : d0));
					
					return d;
				}
				
				/*
				 * joChartDataPoints = {rawdata: {chartType: 'line', data: [{T: , V}]}, critical: {...}, warning: {...}}
				 */
				function getTooltipText(joDatum, yAxisCategoryKey, unit, joChartDataPoints, joSingleChartGroupData, bTextHTML) {
					var tooltipText = '', newLine = (bTextHTML?'<BR />':'\n'), aryFormattedValue = [];
					var unitChartData = unit || '';
					var joRawData = joChartDataPoints.rawdata, aryDatumKeys, colorChart = appedoDirectiveChartUtils.getColorFromChartSettings(joRawData);
					
					// TODO value human readable,
					// TODO: ASK add separate fn. for HTML tooltip text
					
					// line data; to format the value based on unit, roundOfValue is ignored goven as false
					aryFormattedValue = appedoDataUtils.getHumanReadableFormat(joDatum[yAxisCategoryKey], unitChartData, false);
					
					tooltipText += '<div class="apd-counterText" > ';
					tooltipText += 'Time: '+tooltipTimeFormat(new Date(joDatum.T));					
					if ( bTextHTML ) {
						tooltipText += newLine+'<span class="apd-toolTip-category" >'+joSingleChartGroupData.metricCategory+'</span>';
						tooltipText += newLine+'<span style="color:'+colorChart+';">'+(yAxisCategoryKey !== 'V' ? '<span style="font-size: 12px;">('+yAxisCategoryKey+'.)</span> ' : '')+joSingleChartGroupData.metricName+'</span>: '+(aryFormattedValue[0]+' <span class="apd-chartValueUnits">'+aryFormattedValue[1]+'</span>');
					} else {
						tooltipText += newLine+joSingleChartGroupData.metricCategory;
						tooltipText += newLine+(yAxisCategoryKey !== 'V' ? '('+yAxisCategoryKey+'.)' : '')+joSingleChartGroupData.metricName+': '+(aryFormattedValue[0]+' '+aryFormattedValue[1]);
					}
					
					if ( joRawData.chartType.indexOf('bar') >= 0 && (aryDatumKeys = joRawData.keys || []).length > 0 ) {
						// formats, tooltip text
						// = joRawData.keys;
						for(var i = 0; i < aryDatumKeys.length; i = i + 1) {
							var keyDatum = aryDatumKeys[i];
							if ( joDatum[keyDatum] !== undefined && joDatum[keyDatum] > 0 ) {
								tooltipText += newLine+STACK_BAR_DETAILS[keyDatum].tooltip_display_name+': '+joDatum[keyDatum];
							}
						}
					} else {
						// TODO ASK, Min, Avg, Max to show for mousemove multi-line chart tooltip 
						// 
						if ( bHasSingleGroupChartData && (joDatum.Min !== undefined || joDatum.Max !== undefined || joDatum.Avg !== undefined ) ) {	//! bMousemoveTooltip &&
							// to format the value based on unit, roundOfValue is ignored goven as false
							aryFormattedValue = appedoDataUtils.getHumanReadableFormat(joDatum.Min, unitChartData, false);
							if ( bTextHTML ) {
								tooltipText += newLine+'Min: '+(aryFormattedValue[0]+' <span class="apd-chartValueUnits">'+aryFormattedValue[1]+'</span>');
							} else {
								tooltipText += newLine+'Min: '+(aryFormattedValue[0]+' '+aryFormattedValue[1]);
							}
							
							// to format the value based on unit, roundOfValue is ignored goven as false
							aryFormattedValue = appedoDataUtils.getHumanReadableFormat(joDatum.Avg, unitChartData, false);
							if ( bTextHTML ) {
								tooltipText += newLine+'Avg: '+(aryFormattedValue[0]+' <span class="apd-chartValueUnits">'+aryFormattedValue[1]+'</span>');
							} else {
								tooltipText += newLine+'Avg: '+(aryFormattedValue[0]+' '+aryFormattedValue[1]);
							}
							
							// to format the value based on unit, roundOfValue is ignored goven as false
							aryFormattedValue = appedoDataUtils.getHumanReadableFormat(joDatum.Max, unitChartData, false);
							if ( bTextHTML ) {
								tooltipText += newLine+'Max: '+(aryFormattedValue[0]+' <span class="apd-chartValueUnits">'+aryFormattedValue[1]+'</span>');
							} else {
								tooltipText += newLine+'Max: '+(aryFormattedValue[0]+' '+aryFormattedValue[1]);
							}
						}
					}
					
					
					// TOOD: ASK  aryThereshold = [{dataKey: 'warning', displayName: 'Warning'}, {dataKey: 'critical', displayName: 'Critical'}], for loop form threshold tootlip 
					// Warning tooltip text 
					var joWarningData = joChartDataPoints.warning;
					if ( joWarningData !== undefined ) {
						var aryChartData = [], joWarningDatum = {};
						if ( joWarningData.dataNearestPoint === undefined ) {	// circle point, hover tooltip, filter neareset point 
							aryChartData = joWarningData.data;
							// gets idx, nearest point of line's datum(i.e.joDatum.T) from warning chartdata 
							joWarningDatum = getNearestDatumBasedOnTime(aryChartData, joDatum.T);
						} else {	// mousemove tooltip point, nearest point is filtered  
							joWarningDatum = joWarningData.dataNearestPoint;
						}
						
						// to format the value based on unit, roundOfValue is ignored goven as false
						aryFormattedValue = appedoDataUtils.getHumanReadableFormat(joWarningDatum.V, joWarningData.unit || '', false);
						if ( bTextHTML ) {
							tooltipText += newLine+'<span style="color: '+joThresholdColors.warning+'" >Warning</span>: '+(aryFormattedValue[0]+' <span class="apd-chartValueUnits">'+aryFormattedValue[1]+'</span>');
						} else {
							tooltipText += newLine+'Warning: '+(aryFormattedValue[0]+' '+aryFormattedValue[1]);	
						}
					}
					// Critical tooltip text 
					var joCriticalData = joChartDataPoints.critical;
					if ( joCriticalData !== undefined ) {
						var aryChartData = [], joCriticalDatum = {};
						if ( joCriticalData.dataNearestPoint === undefined ) {	// circle point, hover tooltip, filter neareset point 
							aryChartData = joCriticalData.data;
							// gets idx, nearest point of line's datum(i.e.joDatum.T) from critical chartdata 
							joCriticalDatum = getNearestDatumBasedOnTime(aryChartData, joDatum.T);
						} else {	// mousemove tooltip point, nearest point is filtered 
							joCriticalDatum = joCriticalData.dataNearestPoint;
						}
						
						// to format the value based on unit, roundOfValue is ignored goven as false
						aryFormattedValue = appedoDataUtils.getHumanReadableFormat(joCriticalDatum.V, joCriticalData.unit || '', false);
						if ( bTextHTML ) {
							tooltipText += newLine+'<span style="color: '+joThresholdColors.critical+'" >Critical</span>: '+(aryFormattedValue[0]+' <span class="apd-chartValueUnits">'+aryFormattedValue[1]+'</span>');
						} else {
							tooltipText += newLine+'Critical: '+(aryFormattedValue[0]+' '+aryFormattedValue[1]);
						}
					}
					tooltipText += '</div>';
					
					return tooltipText;
				}
				
				// load point click details 
				function loadPointDetails(joDatum) {
					if ( expressionHandler !== undefined ) {
						expressionHandler(joDatum);
					}
				}
				
				
				// TODO: $watch
				
				scope.$watch("graphGroups", function(newValue, oldValue, scope) {
					//console.info('$watch graphs');
					
					//console.info('----------------- $watch ------------------');
					
					if( newValue != undefined) {
						// plots chart data
						plotData(newValue, oldValue, scope);
					}
				}, true);
				
				scope.$watchCollection("graphGroups", function(newValue, oldValue, scope) {
					//console.info('$watchCollection graphs');
					
					//console.info('----------------- $watchCollection ------------------');
					
					if( newValue != undefined) {
						// plots chart data
						plotData(newValue, oldValue, scope);
					}
				}, true);
				
				
				function plotData(newValue, oldValue, scope) {
					/*
					 * formats to have as 
					 * [ { rawdata: { chartType: 'line', data: [{T: , V: }, , ] }, 'Critical': { ... }, 'Warning': { ... } }, // single graph TODO as (line OR bar OR area)
					 * 	 { rawdata: { chartType: 'line', data: [{T: , V: }, , ] } }, ...] // optional threshold (`Critical`, `Warning`) data
					 */
					/*console.info('plotData <> plotData');
					console.info('newValue: '+JSON.stringify(newValue[0]));*/
					
					/* commented corrections, added in array; 
					// gets graph data, graphs's module details 
					var aryGraphDetails = appedoDirectiveChartUtils.formatGraphSettingsData(newValue[0]);
					//console.info('------------------ plotData -------------------');
					//console.info('aryGraphDetails: '+JSON.stringify(aryGraphDetails));
					joGraphModuleDetails = aryGraphDetails[0];
					data = aryGraphDetails;
					*/
					
					// added in array 
					data = appedoDirectiveChartUtils.formatGraphSettingsData(newValue[0]);
					//console.info('data: '+JSON.stringify(data));
					
					var svg = d3.select(element[0]).select("svg").remove();
					drawChart();
				}
			});
			
			// TODO: Ask, graph single line with breaks, as [ [{T: , V: }, {T: , V: }, ...], ... {} ]
		}
	};
}]);

/**
 * Make the slider look like "selected-from-first-point".
 * This is used when slider's mid-point is selected as default poistion.
 * 
 */
/*appedoApp.directive('makedefault', function($timeout) {
	return {
		priority: 1001,
		restrict: 'A',
		link: function(scope, ele, attrs) {
			function startSliderFromFirstPoint(){
				if( document.getElementsByClassName("apdo-slider01") ) {
					var sld = document.getElementsByClassName("apdo-slider01")[0].getElementsByClassName("jslider")[0].getElementsByClassName("p")[0];
					if ( sld !== undefined ) {
						sld.style["background-color"] = "#42a6db";	
					}
				} else {
					$timeout(startSliderFromFirstPoint, 1000);
				}
			};
			
			$timeout(startSliderFromFirstPoint, -1);
		}
	};
});
*/
appedoApp.directive('checkPasswordMatch', function() {
	return {
		restrict: "A",
		require: 'ngModel',
		scope: {
			match: '='
		},
		link: function(scope, element, attrs, ctrl) {
			//var matchGetter = attrs.match;
			element.bind('blur', function () {
				ctrl.$validators.match = function() {
					// thinks to set error message for respective field ngMode;
					var isValid = (ctrl.$viewValue === scope.match);
					ctrl.$setValidity('match', isValid);
					return isValid;
				};
				
				/*
				scope.$watch(attrs.ngModel, function(){
					ctrl.$$parseAndValidate();
				});*/
				scope.$watch(attrs.ngModel, function() {
					ctrl.$validate();
				});
				scope.$watch('match', function() {
					ctrl.$validate();
				});
			});
		}
	};
});


appedoApp.directive('dropdownMultiselect', ['$document',function($document){
	   return {
		   restrict: 'E',
		   scope:{		   
				model: '=',
				options: '=',
				pre_selected: '=preSelected'
		   },
		   template: "<div class ='dropdownMultiselect'><div class='' data-ng-class='{open: open}'>"+
			"<div class='apd-multiSelect dropdown-toggle apd-curpnt' data-ng-click='open=!open; openDropdown()'><span style='width:100%'>{{model.length > 0 ? model.length +' Selected':'Select Browser'}}</span></div>"+
					"<ul class='dropdown-menu apd-multiSelectul' aria-labelledby='dropdownMenu'>" + 
						"<li class = 'apd-multiSelectli' ng-model='sumTestData.option' data-ng-repeat='option in options'> <a data-ng-click='setSelectedItem()' class='apd-curpnt'><i data-ng-class='isChecked(option.dobId)'></i>{{option.browserName}}</a></li>" +										
					"</ul>" +
				"</div></div>" ,
		   controller: function($scope){
			   	var selectedCount = 0;
			   	$scope.closeOnBlur = true;
			   	$scope.sumTestData = {};
			   	$scope.model=[];
			   	$scope.modelBrowserName=[];
				$scope.openDropdown = function(){	   
				};
			   
				$scope.setSelectedItem = function(){
					var id = this.option.dobId;
					var browserName = this.option.browserName;
					if (_.contains($scope.model, id)) {
						$scope.model = _.without($scope.model, id);
						$scope.modelBrowserName = _.without($scope.modelBrowserName, browserName);
					} else {
						$scope.model.push(id);
						$scope.modelBrowserName.push(browserName);
					}
					$scope.sumTestData.browser = $scope.model;
					return false;
				};
				
				$scope.isChecked = function (id) {   
					if (_.contains($scope.model, id)) {
						return 'fa fa-check pull-right';
					} 
					return false;
				};				 
				if ($scope.closeOnBlur) {
					$document.on('click', function (e) {
						var target = e.target.parentElement;
						var parentFound = false;

						while (angular.isDefined(target) && target !== null && !parentFound) {
							if (_.contains(target.className.split(' '), 'dropdownMultiselect') && !parentFound) {
								parentFound = true;
							}
							target = target.parentElement;
						}
						
						if (!parentFound) {
							$scope.$apply(function () {
								$scope.open = false;
							});
						}
					});
				}
		   } 
	   }
	}]);

appedoApp.directive('focus', function($timeout) {
	  return {
		link: function(scope, element, attrs) {
			scope.$watch(attrs.focus, function(value) {
			if(value === true) { 
				element[0].focus(); 
			}
		  });
		}
	  };
	});

appedoApp.directive('validUrl',['sessionServices', function(sessionServices) {
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, ele, attrs, controller) {
//			var urlRegExp = /(http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/;
			var urlRegExp = new RegExp(sessionServices.get("webURLValidation"),"i");
			function dovalidation() {
				scope.sumAddForm.$valid = urlRegExp.test(controller.$modelValue);
			}
			scope.$on('triggerURLValidation', dovalidation);
		}
	};
}]);

appedoApp.directive('textareaFitToContent', function() {

	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, ele, attrs, controller) {
			// thinks to apply fefault style for the element
			ele[0].style.height = 'auto';
			
			function resizeTextarea() {
				// tried due to not reflected after edit
				$(ele[0]).height('');
				var nBRCount = ele[0].value.split('\n').length;
				ele[0].rows = nBRCount + 1; //++ To remove twitching
			}
			
			ele.bind('keyup', resizeTextarea);
			ele.bind('keydown', resizeTextarea);
			ele.bind('copy', resizeTextarea);
			ele.bind('cut', resizeTextarea);
			ele.bind('paste', resizeTextarea);
			ele.bind('change', resizeTextarea);
			
			// when model value changes `$watch(attrs.ngModel...` is called
			scope.$watch(function() { controller.$modelValue }, function(value){
				resizeTextarea();
			});
			scope.$watch(attrs.ngModel, function(value){
				//console.info('$watch attrs.ngModel');
				resizeTextarea();
			});
			
			controller.$viewChangeListeners.unshift(resizeTextarea);
			
			//
			//scope.$on('textareaFitToContent', resizeTextarea);
		}
	};
});

appedoApp.directive('selectText', ['$document', function($document){
	return {
		restrict: 'A',
		link: function(scope, element, attrs){
			element.bind('click', function (e) {
				selectText(attrs.idToSelect);
				
				// TODO: handle in try catch to Copy or if exception occured to Select the text
			});
			
			// select the text
			function selectText( containerid ) {
				var node = document.getElementById( containerid );
				
				if ( document.selection ) {
					var range = document.body.createTextRange();
					range.moveToElementText( node  );
					range.select();
				} else if ( window.getSelection ) {
					var range = document.createRange();
					range.selectNodeContents( node );
					window.getSelection().removeAllRanges();
					window.getSelection().addRange( range );
				}
			}
		}
	};
}]);
appedoApp.directive('appedoChartsv01', ['d3Service', function(d3Service)
                                        {
	return {
		restrict: "AE",
		scope: {
			graphGroups: '=',
			loadevent: '&',
			graphIdSelGraphVal : '=',
		},
		link: function(scope, element, attrs) {
			d3Service.d3().then(function(d3) {
//				var expressionHandler = scope.loadevent();
//				console.info(scope.graphGroups);
				var xAxisLabel,yAxisLabel,xaxisLabelWidth,yAxisScale,xAxisScale,x,y,xAxis,yAxis, svg1,svg; 
				var xAxisTimeScale = scope.graphGroups[0]["xAxisTimeScale"];
				var yAxisTimeScale = false; //future implementation
				var enableYaxis=scope.graphGroups[0]["enableYaxis"]; 
				var axisLabel = scope.graphGroups[0]["axisLabel"];
				var graphId = scope.graphGroups[0]["graphId"];
				
				var chartType,selGraphValue,xAxisRotate=0,hDisplayLabel=false,nameMaxLength=0, valMaxLength=0,graphIdSelGraphVal;
				var timeFormat = "%d-%b %H:%M"; //from slider
				var tickFormat = d3.time.format(timeFormat);  //depending on slider setting 1 hour must have date without year and time
				var itrMulti ; //opacity of the ovarlapping vertical bar with xAxis Label is changed 
				var color;
				var totalRows=0;
				
				var legendWidthTotal=5,lineWidth=5, legendLine=1; //toadjust height for legend display
				var graphMinMax=[], criticalMinMax =[], warningMinMax =[],dataMax=[],legendText;
				var data =[],chartArr=[];
				var cnt,legendLine,legendX,circleRadius,metricId;
				var focus;
				var tooltipHtml=[];
				var conValue, outUnit, dispUnit;
				var PARENT_WIDTH, PARENT_HEIGHT, width, height;
				var margin;
				var charts = scope.graphGroups[0]["charts"];
//				console.info(charts);
				var aryColors = [
							{"dark":"#9b61a7", "light":"#e2aded"}, {"dark":"#98cb65", "light":"#b8e888"},
							{"dark":"#f06c53", "light":"#ed9989"}, {"dark":"#f0ca4d", "light":"#f2d77d"}, 
							{"dark":"#00b9d9", "light":"#65e1f7"} 
							];
				function drawCharts(charts){
					PARENT_WIDTH = element.parent()[0].offsetWidth, PARENT_HEIGHT = 125;
					margin = {top: 10, right: 30, bottom: 25, left: 35},
					width = PARENT_WIDTH - margin.left - margin.right,
					height = PARENT_HEIGHT - margin.top - margin.bottom;

					legendWidthTotal=5,lineWidth=5, legendLine=1; //toadjust height for legend display
					nameMaxLength=0, valMaxLength=0;
					charts.forEach(function (chart,i){
						var grMinMax=[], crMinMax=[],waMinMax=[];
						chartArr=chart["chart"+(i+1)];
						chartType = chartArr["chartType"];

						/* Based on width of legend text, line number is assigned to the legend */
						chartArr.legendX = lineWidth;
						lineWidth+=chartArr["legendText"].length*6+5;
						legendWidthTotal+=chartArr["legendText"].length*6+5;
						chartArr.legendLine = Math.ceil(legendWidthTotal/(width));
						if (legendLine< chartArr.legendLine){lineWidth=chartArr["legendText"].length*6+5; legendLine=chartArr.legendLine; chartArr.legendX=5;}

						if (charts.length>1 || selGraphValue == null){selGraphValue=chartArr["selGraphValue"];}
						graphIdSelGraphVal = graphId+"-"+selGraphValue;
//						scope.graphIdSelGraphVal=graphIdSelGraphVal; // on inclusion watch is not getting called hence commented
						var grMax;
						if (selGraphValue =="count") {selGraphValue="graphValue"; grMax="max";}
						else {grMax=selGraphValue;}
						data = chartArr["data"];
						/* Manage Time format for datetime earlier than current date will be shown as datetime format otherwise hour min format */
						if (xAxisTimeScale || yAxisTimeScale){
							var timeDiff = d3.extent(data,function(d,i){return Number(d3.values(data[i])[0]);});
							var stDate = (new Date(new Date().toDateString())).getTime();
//							console.info("timeDiff[0]:"+timeDiff[0]+" stDate:"+stDate);
							if (timeDiff[0]>stDate){timeFormat="%H:%M";}else{timeFormat = "%d-%b %H:%M";}
							tickFormat = d3.time.format(timeFormat); 
						}

						/* unit conversion */
						var chartUnit = (chartArr["unit"]).toLowerCase();
						if (chartUnit=="bytes" || chartUnit=="bps" || chartUnit=="kbps" || chartUnit=="mbps" || chartUnit=="gbps"||chartUnit=="kb"|| chartUnit=="mb"||chartUnit=="gb"){ 
							grMinMax = d3.extent(data,function(d){return +d[grMax];});
							if (grMinMax[0]>0){sizeConv(chartArr["unit"],grMinMax[0]);}
							else {sizeConv(chartArr["unit"],grMinMax[1]);}
						}
						else if(chartUnit=="ms" || chartUnit=="sec" || chartUnit=="min" || chartUnit=="hour"){
							grMinMax = d3.extent(data,function(d){return +d[grMax];});
							if (grMinMax[0]>0){timeConv(chartArr["unit"],grMinMax[0]);}
							else {timeConv(chartArr["unit"],grMinMax[1]);} 
						}
						else{
							conValue=1;
							outUnit=dispUnit=chartUnit;
						}
						data.forEach(function (d,i){
							if (selGraphValue != "graphValue"){
								d.value = (d[grMax]*conValue).toFixed(3);
								d.disCol = chartArr["selGraphValue"];
								d.criticalMod=(d.critical*conValue).toFixed(3);
								d.warningMod=(d.warning*conValue).toFixed(3);
								axisLabel=outUnit;
								grMinMax = d3.extent(data,function(d){return +d.value;});
								crMinMax = d3.extent(data,function(d){return +d.criticalMod;});
								waMinMax = d3.extent(data,function(d){return +d.warningMod;});
							}
							else {
								d.value = d[grMax];
								d.disCol = chartArr["selGraphValue"];
								d.criticalMod=d.critical;
								d.warningMod=d.warning;
							}
							d.maxMod = (d.max*conValue).toFixed(3);
							d.minMod = (d.min*conValue).toFixed(3);
							d.avgMod = (d.avg*conValue).toFixed(3);

						});

						if (selGraphValue == "graphValue"){
							grMinMax[1] = d3.max(data, function(d) {return +d[chartArr["selGraphValue"]]; });
							grMinMax[0] = 0;
						}
						if (graphMinMax.length ==0){graphMinMax[0]=grMinMax[0]; graphMinMax[1]=grMinMax[1];}
						else{
							if (graphMinMax[0]>grMinMax[0]){graphMinMax[0]=grMinMax[0];}
							if (graphMinMax[1]<grMinMax[1]){graphMinMax[1]=grMinMax[1];}
						}
						if (criticalMinMax.length ==0){criticalMinMax[0]=crMinMax[0]; criticalMinMax[1]=crMinMax[1];}
						else{
							if (criticalMinMax[0]>crMinMax[0]){criticalMinMax[0]=crMinMax[0];}
							if (criticalMinMax[1]<crMinMax[1]){criticalMinMax[1]=crMinMax[1];}
						}
						if (warningMinMax.length ==0){warningMinMax[0]=waMinMax[0]; warningMinMax[1]=waMinMax[1];}
						else{
							if (warningMinMax[0]>waMinMax[0]){warningMinMax[0]=waMinMax[0];}
							if (warningMinMax[1]<waMinMax[1]){warningMinMax[1]=waMinMax[1];}
						}
						var totRow =0;
	
						color = d3.scale.ordinal().range(["hsl(100,100%,40%)", "hsl(50,100%,50%)", "hsl(0,100%,50%)"]);
						color.domain(d3.keys(data[0]).filter(function(key) { if (key == "critical" || key == "warning" || key=="count"){ return key; }}));
	
						var k=0; // to avoid the duplication of name if the length is curtailed by code
						data.forEach(function (d,i){
							var y0 = 0;
							d.criticalMod = d3.keys(data[0])[6]=="critical" ? +d.criticalMod : 0 ;
							d.warningMod = d3.keys(data[0])[5]=="warning" ? +d.warningMod : 0 ;
							d.colName = (xAxisTimeScale || yAxisTimeScale) ? tickFormat(new Date(Number(d3.values(data[i])[0]))) : d3.values(data[i])[0]; //to set the first column header to the colName variable
							
							d.label = (hDisplayLabel)? d.colName : "" ;
							if (chartType=='line' || chartType == 'area'){
								d.graphValue = +d.count;
							}
							d.count = (selGraphValue!="graphValue")?d.count : +d.count-d.critical-d.warning; //reassigning total count
							//for each color domain, setting name, y0, y1 value. y1=y0+y1 status is an array with name, y0 and y1 values set to draw the stacked bar chart
							if (chartType=='vbar' || chartType=='hbar'){
								d.status = color.domain().map(function(name) {return {name: name, y0: y0, y1: y0 += +d[name], critical:+d.critical, warning:+d.warning, healthy:+d.count, max: +d.max, min: +d.min, avg:+d.avg, xAxisValue:d.colName}; });
								d.graphValue = d.status[d.status.length-1].y1; 
							}	
							if (!xAxisTimeScale && !yAxisTimeScale){
								if (d.colName.length > nameMaxLength && d.colName!=undefined) {
									if (d.colName.length >=17){
										d.colName=d.colName.substring(0,12)+".."+k;
										k++;
									}
									nameMaxLength=d.colName.length;
								}

							}
							totRow++;
							chartArr.itrCheck =  d.status != undefined ? d.status.length : 1;
							chartArr.itrSubtracter = chartArr.itrCheck -1; // to ensure the no. of stacked items to be covered for opacity
						});
						chartArr.totRows=totRow;
						if (totalRows<totRow){totalRows=totRow;}
					});

					//Based on last chart setting the below portion of the code works. This require correction in future - 09-Feb-2017 by Sriraman K
					if (chartType=='hbar'){yAxisScale ='ordinal'; xAxisScale ='linear';}
					else if (chartType=='vbar'){yAxisScale ='linear'; xAxisScale ='ordinal';}
					else if (chartType=='line' || chartType=='area'){yAxisScale ='linear'; xAxisScale ='ordinal';}
	
					if (selGraphValue != "graphValue"){
						//Getting the max min value from selected graph
							dataMax[1]=graphMinMax[1];
							//commented based on nagarajan's chart comment - dated : 6/4/2017
							//if (dataMax[1] < criticalMinMax[1]) {dataMax[1]=criticalMinMax[1];}
							//if (dataMax[1] < warningMinMax[1]){dataMax[1]=warningMinMax[1];}
							dataMax[0]=graphMinMax[0];
							//commented based on nagarajan's chart comment - dated : 6/4/2017
							if (dataMax[0] > criticalMinMax[0]) {dataMax[0]=criticalMinMax[0];}
							if (dataMax[0] > warningMinMax[0]){dataMax[0]=warningMinMax[0];}
					}
					else if (yAxisScale == 'linear' || xAxisScale == 'linear') {
						dataMax[1] = d3.max(data, function(d) {return d.graphValue; });
						dataMax[0] =0;
					}
					if (dataMax[1]!=undefined){
						valMaxLength=(dataMax[1].toString()).length; //get the max length of the value to set the margin appropriately
					}
					else {valMaxLength=0;}
				//sorting only if scale is not timescale
					if (!xAxisTimeScale && !yAxisTimeScale){data.sort(function(a, b) {return b.graphValue - a.graphValue; });}
		
					if (xAxisTimeScale||yAxisTimeScale){
						if (timeFormat=="%d-%b %H:%M"){nameMaxLength = 13;}
						else if(timeFormat=="%H:%M") {nameMaxLength=6;}
						else {nameMaxLength=15;}
					}
		
					if (chartType=="hbar"){height = totalRows>5 ? 12*totalRows : height;}
					else if (chartType=="vbar" || chartType=="line" || chartType=="area"){
						var totalWidth = totalRows>15? nameMaxLength*15*6 : nameMaxLength*totalRows*6; 
						if (totalWidth>width){xAxisRotate=-30; margin.left=margin.left+10+Math.ceil(nameMaxLength*0.25);}
					}
				
	
				//setting scale for x axis and y axis -- for horizontal bar chart without time stamp in x axis
				//Setting range and this varies based on the graph x and y axis.   
					if (xAxisScale == 'linear') {
						xAxisLabel=axisLabel;
						xaxisLabelWidth = xAxisLabel.length;
						if (Math.abs(xAxisRotate) > 0){
							height = height+10+Math.ceil(valMaxLength/2,0);
							margin.bottom = margin.bottom+10+7*Math.ceil(valMaxLength/2,0);
						}
					}
					else {
						xAxisLabel=d3.keys(data[0])[0];
						xaxisLabelWidth = xAxisLabel.length;
						if (Math.abs(xAxisRotate) > 0){
							height = height+20+Math.ceil(nameMaxLength/2,0);
							margin.bottom = margin.bottom+10+1*Math.ceil(nameMaxLength*0.5,0);
						}
					}
					//implemented to increase the height for legends
					height = height+Math.ceil(legendWidthTotal/width)*15;
					margin.bottom = margin.bottom+Math.ceil(legendWidthTotal/width)*15;

					//Realign the graph height to ensure proper alighnment to the best possible
					PARENT_HEIGHT = height+margin.top+margin.bottom;
					var dftHt = 150;
					if (PARENT_HEIGHT%dftHt>0){
						var phUnit = Math.round(PARENT_HEIGHT/dftHt);
						if (phUnit >1){PARENT_HEIGHT = phUnit*dftHt+(phUnit-1)*43.5;}
						else {PARENT_HEIGHT = phUnit*dftHt;}
						height = PARENT_HEIGHT-margin.top-margin.bottom;
					}
					var axisLabelxPos;
					if  (yAxisScale == 'linear') {
						yAxisLabel = axisLabel;
						axisLabelxPos=(axisLabel.length-1)*6;
						margin.left = enableYaxis ? margin.left + 4 * valMaxLength : margin.left;
						width = width - margin.left +10;
						y = d3.scale.linear().range([height, 0]);
						y.domain([dataMax[0],dataMax[1]]);

					}
					else {
						yAxisLabel=d3.keys(data[0])[0];
						axisLabelxPos= yAxisLabel!=undefined ?(yAxisLabel.length-1)*6:0;
						margin.left = enableYaxis ? margin.left+ 4 * nameMaxLength : margin.left;
						width = width - margin.left;
						y = d3.scale.ordinal().rangeRoundBands([0, height], .15);
						y.domain(data.map(function(d) { return d.colName; }));

					}
		
					if (xAxisScale=='ordinal'){
						x=d3.scale.ordinal().rangeBands([0, width], .15);
						x.domain(data.map(function(d) { return d.colName; }));
					}
					else{
						x = d3.scale.linear().range([0, width]);
						x.domain([dataMax[0], dataMax[1]]);
					}
	
//					itrMulti=0; //Multiple iterator - to get no. of bar's to be made opacity 0.5 -- not used now 01-04-2017
					if (xAxisScale=='ordinal'){
//						itrMulti = Math.round((xaxisLabelWidth*6)/x.rangeBand()-1); 	//to get no. of bar's to be made opacity 0.5
//						if (itrMulti<0){itrMulti=0;}
						xAxis = d3.svg.axis()
							.scale(x)
							.orient("bottom")
							.tickValues(x.domain().filter(function(d, i) {return !(i % (Math.ceil(totalRows/15))); }));
					}
					else{
						xAxis = d3.svg.axis()
							.scale(x)
							.orient("bottom");
					}
					yAxis = d3.svg.axis()
						.scale(y)
						.orient("left")
						.ticks(5);
					
					//setting base svg common for all graphs
					svg1 = d3.select("#" + attrs.id).append("svg")
						.attr("width", width + margin.left + margin.right)
					    .attr("height", height + margin.top + margin.bottom);
		
					svg = svg1
							  .append("g")
								.attr("transform", "translate(" + margin.left + "," + margin.top  + ")");
		
		
					//Setting xaxis and y axis
 				  svg.append("g")
					      .attr("class", "x axis")
						  .attr("id","xaxis")
					      .attr("transform", "translate(0," + height + ")")
					      .call(xAxis);
		
					// required in case x-axis label to be rotated 
					   svg.select("g").selectAll("text")
					      .attr("transform", "rotate("+xAxisRotate+")" );
						
					if (xAxisRotate == -30) {
						svg.select("g").selectAll("text")
							.attr("y","0")
							.attr("x","-5")
							.attr("dy",".55em")
							.style("text-anchor", "end");
					}
		
					//function xAxisLabel(){
						svg.selectAll("#xaxis").append("text")
						  .attr("transform", "rotate(0)")
						  .attr("x", width+margin.left+margin.right-xaxisLabelWidth*7)
						  .attr("y", margin.bottom-10)
						  .style("text-anchor", "end")
						  .style("opacity","1")
						  .text(xAxisLabel);
					//}
					if (enableYaxis) {
					  svg.append("g")
					      .attr("class", "y axis")
						  .attr("id","yaxis")
					      .call(yAxis);
		
					   svg.selectAll("#yaxis").append("text")
					      .attr("transform", "rotate(0)")
					      .attr("y", -10)
					      .attr("x",axisLabelxPos)
					      .attr("dy", ".71em")
					      .style("text-anchor", "end")
					      .text(yAxisLabel);
					}
					else
					{
					  svg.append("g")
					      .attr("class", "y axis")
					    .append("text")
					      .attr("transform", "rotate(0)")
					      .attr("y", -10)
					      .attr("x",axisLabelxPos)
					      .attr("dy", ".71em")
					      .style("text-anchor", "end")
					      .text(yAxisLabel);
					}
//Tool tip function					
					function tooltip(data, ct) {
						focus = svg.append('g').style('display', 'none');
			                
			            focus.append('line')
			                .attr('id', 'focusLineX')
			                .attr('class', 'focusLine');
			            focus.append('line')
			                .attr('id', 'focusLineY')
			                .attr('class', 'focusLine');
			            focus.append('circle')
			                .attr('id', 'focusCircle')
			                .attr('r', 5)
			                .attr('class', 'circle focusCircle')
			            	.attr('opacity',"0.9");
			            
			            
			            tooltipHtml[attrs.idx] = d3.select("body")
										.append("div")
										.attr("class", "apd-chart-tooltip")
										.attr("id", "tooltip"+attrs.idx)
										.style("opacity", "0")
			            				.style("display","none");
						
			            svg.append('rect')
		                .attr('class', 'overlay')
		                .attr('width', width)
		                .attr('height', height)
		                .on('mouseover',function(data) { focus.style('display', null); tooltipHtml[attrs.idx].style("display",null);})
		                .on('mouseout', function() { focus.style('display', 'none');tooltipHtml[attrs.idx].style("display","none");  })
						.on('mousemove',function() {
							var xyCord = ct!="hbar" ? 0 : 1; // to get the x or y movement 0 -x-movement, 1- y movement from mouse
							var mouse = d3.mouse(this)[xyCord];
		                    var leftEdges = ct!= "hbar"? x.range(): y.range();
		                    var width1 = ct!= "hbar" ? x.rangeBand() : y.rangeBand();
		                    var j;
		                    for(j=0; mouse > (leftEdges[j] + width1); j++) {}; //replaces the bisect command
		                        //do nothing, just increment j until case fails

		                    var ttd = data[j]; //tooltip data
		                    if (ttd !=undefined){
			                    var x3,y3, x1a,x2a;
			                    var aggCnt,tooltip1,tooltip2,tooltip3,grUnit, grAgg;

	
			                    if (outUnit==null){outUnit='';dispUnit='';}
			                    
			                    if (selGraphValue!='graphValue'){
			                    	selGraphValue='value'; aggCnt=ttd.count;
			                    	grUnit=dispUnit;
			                    	grAgg="AggCnt";
			                    }
			                    else {
			                    	aggCnt=ttd.graphValue;
			                    	ttd.criticalMod=ttd.critical;
			                    	ttd.warningMod=ttd.warning;
			                    	grUnit=grAgg=axisLabel;
			                    }
	
			                    if (ct!="hbar"){x3= x(ttd.colName)+width1/2; y3 = y(data[j][selGraphValue]); x1a=y(dataMax[0]); x2a=0;  }
			                    else { y3 = y(ttd.colName)+width1/2; x3=x(data[j][selGraphValue]);x1a=0; x2a=height; }
			                    

			                    
			                    
			                    tooltip1 = "<span style ='color:darkblue'><strong>"+ttd.colName+"</strong> | </span><span><em>"+grAgg+": </em></span><span style='color:#d37700'>&nbsp"+aggCnt+"</span>";
			                    tooltip3 = "<br/><span> Critical: </span><span style='color:red'><strong>"+ttd.criticalMod+"</strong></span><span class='font_10'> "+grUnit+"</span><span> | Warning: </span><span style='color:#fa8405'><strong>"+ttd.warningMod+"</strong></span><span class='font_10'> "+grUnit+"</span>";
			                    if (ttd.min!=0 || ttd.max!=0||ttd.avg!=0){
				                    tooltip2 = "<br/><span> Min:</span><span style='color:green'> "+ttd.minMod+"</span><span class='font_10'> "+dispUnit+"</span><span> | Avg: </span><span style='color:#fa8405'> "+ttd.avgMod+"</span><span class='font_10'> "+dispUnit+"</span><span> | Max:</span><span style='color:red'> "+ttd.maxMod+"</span><span class='font_10'> "+dispUnit+"</span>";
			                    }
			                    else {tooltip2 = "";}
			                    
			                    if (selGraphValue=='graphValue'){
			                    	tooltip1 += "<span> | Healthy: </span><span style='color:green'> "+ttd.count+" </span><span class='font_10'>"+grUnit+"</span>"
			                    }
			                    focus.select('#focusCircle')
			                        .attr('cx', x3)
			                        .attr('cy', y3);
			                    focus.select('#focusLineX')
			                        .attr('x1', x3).attr('y1', x1a)
			                        .attr('x2', x3).attr('y2', x2a);
			                    focus.select('#focusLineY')
			                        .attr('x1', 0).attr('y1', y3) 
			                        .attr('x2', width).attr('y2', y3);
	
			                    tooltipHtml[attrs.idx].html(tooltip1 + tooltip2+ tooltip3)
						            		.style("top", (d3.event.pageY - 10)+"px")
						            		.style("left",(d3.event.pageX + 10)+"px")
						            		.transition()
						            		.duration(200)
						            		.style("opacity", 0.90);
		                    }
						});
					}
//drawing of charts					
					charts.forEach(function (chart,i){
						chartArr=chart["chart"+(i+1)];
						chartType=chartArr["chartType"];
						legendText = chartArr["legendText"];	
						legendLine = chartArr["legendLine"];
						legendX = chartArr["legendX"];
						metricId = chartArr["metricId"];
						circleRadius = chartArr["totRows"] > 3 ? 1 : 5;
						data = chartArr["data"];
						selGraphValue=chartArr["selGraphValue"];
						
						if (selGraphValue =="count") {selGraphValue="graphValue";}
						else {selGraphValue="value";}
						if (data.length>0 && dataMax[1]>0){
							cnt = metricId;
							if (chartType =='area'){arealine(data,selGraphValue);}
							else if (chartType=='hbar'){hbar(data);	callLegend(0,cnt);}
							else if (chartType=='vbar'){vbar(data); callLegend(0,cnt);}
							else if (chartType == 'line'){line(data,selGraphValue,0,0,50,50); }
		
							if (charts.length==1 ){
//								if (xAxisTimeScale && selGraphValue!="graphValue" ){if (criticalMinMax[1]>0){line(data,"criticalMod",1,3,100,50); if (warningMinMax[1]>0){line(data,"warningMod",0.09445,3,100,25);}}}
								if (xAxisTimeScale && selGraphValue!="graphValue" ){if (criticalMinMax[1]>0){line(data,"criticalMod",2,3,100,50); if (warningMinMax[1]>0){line(data,"warningMod",3,3,100,25);}}}
							}
							tooltip(data, chartType);
						}
						else{
							noChartText();
						}
						//xAxisLabel();	

					});
				}
//Horizontal Bar Chart - Both stack and normal bar				
				function hbar(data){
				  var location = svg.selectAll(".location")
					  .data(data)
					  .enter().append("g")
					  .attr("class", "g")
					  .attr("transform", function(d) { return "translate(0," + (y(d.colName)+y.rangeBand()/4) + ")"; });
					
				  location.selectAll("rect")
					  .data(function(d) {return d.status; })
					  .enter().append("rect")
					  .attr("id",chartType+"hbar"+cnt)
					  .attr("height",y.rangeBand()*0.5) //y.rangeBand()-y.rangeBand()
					  .attr("x", function(d) { if (d.y0==0){return 3 ;} else { return x(d.y0);}})
					  .attr("width", function(d) { return x(d.y1) - x(d.y0); })
					  .style("fill", function(d) {if (d.name=="count") return "hsl(" + Math.random() * 360 + ",50%,50%)"; else return color(d.name); });
					
				  //placing label for each bar
					if (hDisplayLabel){
						svg.selectAll(".bartext")
						.data(data)
						.enter()
						.append("text")
						.attr("id",chartType+"hbar"+cnt)
						.attr("class", "bartext")
						.attr("font-size","10px")
						.attr("y", function(d) { return y(d.colName)-1 })
						.attr("x", function(d) { return 5; })
						.text(function(d){
							 return d.label;
						});
					}
				}
//drawing vertical stacked bar chart
					function vbar(data){
					  var location = svg.selectAll(".location")
					      .data(data)
					      .enter().append("g")
					      .attr("class", "g")
					      .attr("transform", function(d) { return "translate(" + (+x(d.colName)+x.rangeBand()/4) + ",0)"; });

						var itr =1; // this is to change the opacity for the last bar when totalrows exceeds 5
						location.selectAll("rect")
						  .data(function(d) { return d.status; })
						  .enter().append("rect")
						  .attr("id",chartType+"vbar"+cnt)
//						  .attr("opacity", function () {if (chartArr["totRows"]>4) {if (itr >= (chartArr["totRows"]*chartArr["itrCheck"])-chartArr["itrSubtracter"]-chartArr["itrCheck"]*itrMulti){itr++; return "0.6";}else{itr++; return "1";}} else {return "1";}})
						  .attr("width",x.rangeBand()*0.5) 
						  .attr("y", function(d) { if(d.name=="count"){return (+y(d.y1)-0.6);} else {return y(d.y1);}}) 
						  .attr("height", function(d) { return y(d.y0) - y(d.y1); })
						  .style("fill", function(da) { if (da.name=="count") return "hsl(" + Math.random() * 360 + ",50%,50%)"; else return color(da.name); });
					}
//Area line chart
					function arealine(data,legend){
						//var randNum = Math.floor(Math.random() * aryColors.length);
						var randNum = attrs.idx%(aryColors.length);
						var chartColor = aryColors[randNum];
						//var randNum = Math.random();
						var svgArea = d3.svg.area().x(function(d){return x(d.colName)+x.rangeBand()/2;}).y0(height-1).y1(function (d){return y(d[legend]);});
						svg.append("path")
							.data(data)
					        .attr("class", "area")
							.attr("id",chartType+cnt)
//							.style("fill","hsl(" + randNum * 360 + ",50%,75%)")
							.style("fill",chartColor.light)
					        .attr("d", svgArea(data))
							.attr("opacity","0.95");
							
						line(data, legend, randNum,0,50,50);
						callLegend(randNum,cnt);				
					}
//Line Chart					
					function line(data, legend, randNum,dash,saturation,lightness){
						var drawLegend = false;
						var chartColor = aryColors[randNum];
						//if (randNum == 0){drawLegend=true;} //randNum = Math.random(); 
						var svgline = d3.svg.line().x(function(d){return x(d.colName)+x.rangeBand()/2;}).y(function (d){return y(d[legend]);});
						svg.append("path")
							.data(data)
					        .attr("class", "line")
							.attr("id",chartType+"line"+cnt)
//							.attr("stroke", "hsl(" + randNum * 360 + ",50%,50%)")
							.attr("stroke", chartColor.dark)
							.style("stroke-dasharray", "5,"+dash)
							.attr("fill","none")
					        .attr("d", svgline(data));
						
						if (dash==0){
							svg.selectAll("dot")	
						        .data(data)			
						    .enter().append("circle")								
						        .attr("r", circleRadius)		
								.attr("id",chartType+"dot"+cnt)
//								.style("fill", "hsl(" + randNum * 360 + ","+saturation+"%,"+lightness+"%)")
								.style("fill", chartColor.dark)
						        .attr("cx", function(d) { return x(d.colName)+x.rangeBand()/2; })		 
						        .attr("cy", function(d) { return y(d[legend]); })
								.attr("opacity","0.8");
						}
						if (drawLegend){callLegend(randNum,cnt);}
					}
//Legend Call
					function callLegend(randNum,cnt){
						var chartColor = aryColors[randNum];
//						if (randNum == 0){randNum = Math.random();}
						svg1
							.append("text")
							.attr("class", "text")
							.attr("id","legendText"+cnt)
							.attr("font-size","12px")
//							.attr("fill","hsl(" + randNum * 360 + ",50%,50%)")
							.attr("fill",chartColor.dark)
							.style("text-transform", "capitalize")
							.attr("y", height+margin.top+margin.bottom*0.72+legendLine*15)
							.attr("x", legendX)
							.attr("opacity",1)
							.text(legendText)
							.on ("click", function(){
								var active = line.active ? false:true;
								newOpacityArea = active ? 0 : 1;
								newOpacityLine = active ? 0 : 1;
								newOpacityDot = active ? 0 : 0.9 ;
								newOpacityVbar = active ? 0 : 0.9 ;
								newOpacityHbar = active ? 0 : 0.9 ;
								var opacitylegend=active? 0.3 : 1 ; 
								d3.selectAll("#"+chartType+cnt).style("opacity",newOpacityArea);
								d3.selectAll("#"+chartType+"line"+cnt).style("opacity",newOpacityLine);
								d3.selectAll("#"+chartType+"dot"+cnt).style("opacity",newOpacityDot);
								d3.selectAll("#"+chartType+"vbar"+cnt).style("opacity",newOpacityVbar);
								d3.selectAll("#"+chartType+"hbar"+cnt).style("opacity",newOpacityHbar);
								d3.select("#legendText"+cnt).style("opacity",opacitylegend)
								line.active=active;
								//xAxisLabel();
							});
					}
					
					function noChartText(){
						svg1
							.append("text")
							.attr("class", "text")
							.attr("font-size","16px")
							.attr("fill","hsl(" + Math.random() * 360 + ",50%,50%)")
							.style("text-transform", "capitalize")
							.attr("y", height/2)
							.attr("x", width*0.4)
							.attr("opacity",1)
							.text("No Data to display this Chart");
					}
//Watch call for change of data in UI
					scope.$watch("graphIdSelGraphVal", function(newValue, oldValue, scope) {
//						console.info("newval:" + newValue);
//						console.info("oldval:" + oldValue);
//						console.info("graphval:" + graphId);
						if (newValue != undefined ){
							if(graphId==newValue.substr(0,newValue.length-4) ) {
								if(newValue != oldValue){
									selGraphValue = newValue.substr(newValue.length-3);
								}else{
									selGraphValue=null;
								}
								drawWatchChart()
							}else if(graphId != newValue.substr(0,newValue.length-4) && newValue == oldValue){
								selGraphValue=null;
								drawWatchChart()
							}
						}
						/*else if (oldValue == undefined || newValue == undefined || oldValue != newValue) {*/
						else{
//							console.info("inside else");

							selGraphValue=null; 
							drawWatchChart()}
					},true);
					
					scope.$watch("graphGroups", function(newValue, oldValue, scope) {
						if (newValue != undefined ){
							if(graphId==newValue[0].graphId ){ //}&& newValue !=oldValue ) {
							//	drawWatchChart()
							} 
						}
					},true);
					
					function drawWatchChart(){								
						var svg = d3.select("#" + attrs.id).select("svg").remove();
				          if (document.querySelector('#tooltip'+attrs.idx) !== null) {
				            	d3.select("#tooltip"+attrs.idx).remove();
				            }
						graphMinMax=[], criticalMinMax =[], warningMinMax =[],dataMax=[],legendText;
						drawCharts(charts);
					}
//Size conversion function					
					function sizeConv(inUnit,inVal){
						
						var inUn = inUnit.toLowerCase();
						var unit = inUn.substring(0,1);
						
						if (inUn=="bytes" || inUn=="bps" || inUn=="kbps" || inUn=="mbps" || inUn=="gbps"||inUn=="kb"|| inUn=="mb"||inUn=="gb"){
							//converting to base unit before conversion
							if (unit=="b"){inVal=inVal;}
							else if (unit=="k" ){inVal=inVal*1024;}
							else if (unit=="m"){inVal=inVal*1024*1024;}
							else {inVal=inVal*1024*1024*1024;}
								
							if (inVal<1024){
								outUnit= "Bytes" ; dispUnit="Bytes";
								conValue= unit=="b"? 1 : unit=="k" ? 1024 : unit=="m" ? 1024*1024 : 1024*1024*1024 ;
							}
							else if (inVal>1024 && inVal<=1048576){
								outUnit="KB" ; dispUnit="KB";
								conValue= unit=="b"? 1/1024 : unit=="k" ? 1 : unit=="m" ? 1024 : 1024*1024 ;
							}
							else if (inVal>1048576 && inVal<=1073741824){
								outUnit="MB" ; dispUnit="MB"
								conValue= unit=="b"? 1/(1024*1024) : unit=="k" ? 1/1024 : unit=="m" ? 1 : 1024 ;
							}
							else if (inVal>1073741824){
								outUnit="GB" ; dispUnit="GB";
								conValue= unit=="b"? 1/(1024*1024*1024) : unit=="k" ? 1/(1024*1024) : unit=="m" ? 1/1024 : 1 ;
							}
						}
					}
//Time conversion					
					function timeConv(inUnit,inVal){
						var inUn = inUnit.toLowerCase();
						if (inUn=="ms" || inUn=="sec" || inUn=="min" || inUn=="hour"){
							//convert to base unit
							if (inUn=='ms'){inVal=inVal;}
							else if (inUn=='sec'){inVal=inVal*1000;}
							else if (inUn=='min'){inVal=inVal*60*1000;}
							else if (inUn=='hour'){inVal=inVal*60*60*1000;}
							else {inVal=inVal*24*60*60*1000;}

							if (inVal<1000){
								outUnit ='ms'; dispUnit="ms";
								conValue = inUn=='ms'?1 : inUn=='sec' ? 1000 : inUn=='min' ? 1000*60 : inUn=='hour'? 1000*60*60 : 1000*60*60*24;
							}
							else if (inVal>=1000 && inVal<60000){
								outUnit ='Seconds'; dispUnit="sec";
								conValue = inUn=='ms'?1/1000 : inUn=='sec' ? 1 : inUn=='min' ? 60 : inUn=='hour'? 60*60 : 60*60*24;
							}
							else if (inVal>=60000 && inVal<3600000){
								outUnit ='Minutes'; dispUnit="min";
								conValue = inUn=='ms'?1/(60*1000) : inUn=='sec' ? 1/60 : inUn=='min' ? 1 : inUn=='hour'? 60 : 60*24;
							}
							else if (inVal>=3600000 && inVal<216000000){
								outUnit ='Hours'; dispUnit="hrs";
								conValue = inUn=='ms'?1/(60*60*1000) : inUn=='sec' ? 1/(60*60) : inUn=='min' ? 1/60 : inUn=='hour'? 1 : 24;
							}
							else if (inVal>=216000000){
								outUnit ='Days'; dispUnit="days";
								conValue = inUn=='ms'?1/(24*60*60*1000) : inUn=='sec' ? 1/(24*60*60) : inUn=='min' ? 1/(24*60) : inUn=='hour'? 1/24 : 1;
							}
						}
					}
	});}};
}]);

appedoApp.directive("uiFileUpload",[function(){
	return{
		restrict:"A",
		link:function(scope,ele){
			return ele.bootstrapFileInput()
		}
	};
}]);

appedoApp.directive('backButton', function() {
	return {
		restrict: "AE",
		link: function(scope, element, attrs) {
			$(element[0]).on('click', function() {
				history.back();
				scope.$apply();
			});
		}
	};
});

appedoApp.filter('capitalize', function() {
	  return function(input, scope) {
		if (input!=null)
		input = input.toLowerCase();
		return input.substring(0,1).toUpperCase()+input.substring(1);
	  }
});