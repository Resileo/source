// Directive appedo-area-chart-directive -- removed getURLService from appedo area chart directive
appedoApp.directive('appedoAreaChartDirective',['d3Service', 'ajaxCallService',  'appedoDirectiveChartUtils', function(d3Service, ajaxCallService, appedoDirectiveChartUtils){
	return {
		restrict: "AE",
		scope: {
			chartdata: '=',
			pushdata: '=',
			loadevent: '&'
			//yaxislabel: '@'
		},
		link: function(scope, element, attrs) {
			d3Service.d3().then(function(d3) {
				var divisor;
				var path, data, xAxis, yAxis, area;
				/* old color data set */
//				var colorData = [{"dark":"#9bc2cf", "light":"#d7e6eb"},{"dark":"#c7c7ff", "light":"#e8e8ff"},{"dark":"#19e7e7", "light":"#baf7f7"},
//								 {"dark":"#93dca3", "light":"#c9edd1"},{"dark":"#94ccea", "light":"#d4eaf6"},{"dark":"#e9ad8d", "light":"#f6ded1"},
//								 {"dark":"#b9a2d0", "light":"#e3d9ec"},{"dark":"#afca95", "light":"#d7e4ca"},{"dark":"#ebc9bd", "light":"#f7e9e4"},
//								 {"dark":"#b6b6ff", "light":"#e0e0ff"}];

//				var colorData = [{"dark":"#83a9cc", "light":"#dae5f0"},{"dark":"#a0d2a3", "light":"#e2f1e3"},{"dark":"#e09495", "light":"#f6dfdf"},
//								 {"dark":"#c792e1", "light":"#eedef6"},{"dark":"#d6c283", "light":"#f3edda"},{"dark":"#25989c", "light":"#bde0e1"},
//								 {"dark":"#458549", "light":"#c7dac8"},{"dark":"#954849", "light":"#dfc8c8"},{"dark":"#7b3e80", "light":"#d7c5d9"},
//								 {"dark":"#aa6c42", "light":"#e5d3c6"}];
			   
//				var colorData = [{"dark":"#6dc066", "light":"#cdffb0"},{"dark":"#c1a7a3", "light":"#f2d1cc"},{"dark":"#e29a8f", "light":"#f7e3e0"},
//								 {"dark":"#8fe29a", "light":"#ccf2d1"},{"dark":"#7584f6", "light":"#ebedf9"},{"dark":"#4adbd0", "light":"#c9f0ed"},
//								 {"dark":"#68b030", "light":"#d8f9bf"},{"dark":"#d3dd3e", "light":"#f7f9d8"},{"dark":"#31d2ce", "light":"#9bfbf8"},
//								 {"dark":"#1ad6d2", "light":"#2cfdf8"},{"dark":"#eac011", "light":"#ffe577"},{"dark":"#c3a62d", "light":"#ffeea6"},
//								 {"dark":"#fdf2c2", "light":"#d4ae11"},{"dark":"#df473f", "light":"#ffeae9"},{"dark":"#c52f27", "light":"#fff6f5"}];
				
				/*
				var colorData = [{"dark":"#499f17", "light":"#6dff19"},{"dark":"#ba490c", "light":"#ff7c35"},{"dark":"#047c8d", "light":"#14e0fd"},
								 {"dark":"#0b16a1", "light":"#5b66ff"},{"dark":"#05ae2a", "light":"#12ff46"},{"dark":"#a50515", "light":"#fd4b5d"},
								 {"dark":"#bcc703", "light":"#effd0e"},{"dark":"#ccb900", "light":"#fde60a"},{"dark":"#7b3e80", "light":"#d7c5d9"},
								 {"dark":"#aa6c42", "light":"#e5d3c6"}];
			   */

				var colorData = [{"dark":"#a73f05", "light":"#d08f6b"}, {"dark":"#104a8d", "light":"#7aa1ce"}, {"dark":"#837704", "light":"#ead61e"}, 
								 {"dark":"#7b3e80", "light":"#d7c5d9"}, {"dark":"#aa6c42", "light":"#e5d3c6"}, {"dark":"#3d7200", "light":"#89c346"}, 
								 {"dark":"#c55204", "light":"#e57b33"} ];
				
				
				var rand = Math.floor(Math.random() * colorData.length);
				var timeFormat;
				/* Not used below added by Divami hence commented */
/*				 
				function myRound(value, places) {
					var multiplier = Math.pow(10, places);
					return (Math.round(value * multiplier) / multiplier);
				}
				
*/
				var tooltipTimeFormat = d3.time.format("%Y-%b-%d %H:%M:%S");

				var tooltipLabel = attrs.tooltipLabel != undefined ? attrs.tooltipLabel : 'Value';
				
				var expressionHandler = scope.loadevent();
				
				function generateAreaChartAsArrayInJSONFormart() {

					var parentWidth ;
					var rightM = 8;
					var leftM = 8;
					var dotSize;
					var lineWidth;
					if (attrs.dotsize==null || attrs.dotsize==undefined)
					{
						dotSize = 1.5;
					}else{
						dotSize=attrs.dotsize;
					}

					if (attrs.linewith==null || attrs.linewith==undefined)
					{
						lineWidth = 2;
					}else{
						lineWidth=attrs.linewith;
					}
					
					if (attrs.parrentnodeid==null || attrs.parrentnodeid=="undefined")
					{
						parentWidth=300;
					}
					else 
					{
						parentWidth=document.getElementById(attrs.parrentnodeid).offsetWidth;
						if(parentWidth>800){
							rightM = 15;
							leftM = 3;
						}
					}
					
					var parentHt = 150;
					//Fixed width does not go well with responsive design hence made as percentage of parent heigth
					var margin = {top: parentHt*6/100, right: parentWidth*rightM/100, bottom: parentHt*20/100, left: parentWidth*leftM/100},
							width = parentWidth - margin.left - margin.right,
							height = parentHt - margin.top - margin.bottom, halfOfWidth = (width - margin.right) /2;
					
					if(data.length==1){
						var dummyData={};
						//dummyData["T"] = d3.min(data, function(d) { return d.T; }) - (1000 * 2);
						dummyData["T"] = data[0].T  - (1000 * 2);
						dummyData["V"] = 0;
						
						data.unshift(dummyData);
						//data.push(dummyData);
						//data = data.sort(function(a,b) { return a.T - b.T; });
					}
					
					//data = data.sort(function(a,b) { return a.T - b.T; });
					
					var bisectDate = d3.bisector(function(d) { return d.T; }).left;

					var minData = d3.min(data, function(d) { return d.V; });
					var maxData = d3.max(data, function(d) { return d.V; });
					
					
					maxData=Math.ceil(maxData + maxData *5/100); // adding 5% of max value to ensure graph is within boundry
					minData=Number(minData)-Math.ceil(Number(minData)*5/100); // min value is reduced by 5% of min graph value to ensure boundry is intact
					
				  //This is to ensure reading of values are clear in area chart having background color and area color					
//					if (maxData==0 && minData==0){minData= -1; maxData=1;} 
					
					var x = d3.time.scale()
							//.range([0, width]);
							.range([0, width - margin.right]);

					var y = d3.scale.linear()
						.range([height, 0]);
					
					var aryXminXmax = d3.extent(data, function(d) { return d.T; });
					//var aryXminXmax = [data[0].T, data[data.length - 1].T];
					x.domain(aryXminXmax);
					y.domain([minData, maxData]);
					
					// x-axis time format used, if sets in directive attr `xaxisformat` else based on x-axis's min, max shown
					timeFormat = d3.time.format( attrs.xaxisformat !== undefined ? attrs.xaxisformat : appedoDirectiveChartUtils.getD3XAxisTimeFormat(aryXminXmax[0], aryXminXmax[1]));
					
				   xAxis = d3.svg.axis()
						.scale(x)
						.orient("bottom")
						.ticks(5)
						.tickFormat(timeFormat)
						//.tickValues(data.map(function(d) { return d.date;}));;

				   yAxis = d3.svg.axis()
						.scale(y)
						.orient("left").ticks(5);

					area = d3.svg.area()
						.interpolate("linear")
						.x(function(d) { return x(d.T); })
						.y0(height)
						.y1(function(d) { return y(d.V); });
						
					var areaTop = d3.svg.area()
						.interpolate("linear")
						.x(function(d) { return x(d.T); })
						.y0(0)
						.y1(function(d) { return y(d.V); });

					var line = d3.svg.line()
						.interpolate("linear")
						.x(function(d) {return x(d.T);})
						.y(function(d){return y(d.V);});
					
					var svg = d3.select("#" + attrs.id).append("svg")
						.attr("width", width + margin.left + margin.right)
						.attr("height", height + margin.top + margin.bottom)
						.append("g")
						//.attr("transform","translate(" + margin.left*2 + "," + margin.top + ")")
						.attr("transform","translate(" + margin.left * 3 / 2+ "," + margin.top + ")")
						.attr("onload","LoadHandler(evt)");
					
					svg.append("g")
						.attr("class", "axis")
						.attr("transform", "translate(0," + height + ")")
						.call(xAxis);

					svg.append("g")
						.attr("class", "axis")
						.call(yAxis)
						.append("text")
						.attr("transform", "rotate(-90)")
						.attr("y", (0-margin.left-margin.right))
						.attr("x", (0-(height / 2)))
						.style("text-anchor", "middle")
						.text('');

					svg.append("path")
								.datum(data)
								.style("fill", colorData[rand].light)
								.attr("d", area);
					
					svg.append("path")
				  	.attr("class", "line")
				  	.attr("d", line(data))
				  	.attr("stroke", function(d) {return colorData[rand].dark;})
					.style("stroke-width", lineWidth);
				  
				  if( attrs.linkstatus == "true" ){
					  
					  svg.selectAll("dot")
						.data(data)
						.enter().append('circle')
						.style("cursor","pointer")
						.attr("cx",function(d) {return x(d.T);})
						.attr("cy",function(d){return y(d.V);})
						.attr("r", dotSize)
						.attr("fill",function(d) {return colorData[rand].dark;})
						.on("mouseover", function(d) {
							// highlight on mouse over
							d3.select(this)
								.attr("r", 5)
								.style("opacity", 0.5);
						})
						.on("mouseout", function() {
							// un-highlight on mouse over 
							d3.select(this)
								.attr("r", dotSize)
								.style("opacity", 1);
						})
						.append("title")
						.text(function(d) {
							return 'Time : '+tooltipTimeFormat(new Date(d.T))+'\nValue : '+d.V;  
						});
		  		
						svg.selectAll("circle").on("click", function (d) {
							if(attrs.linkstatus=="true"){
								expressionHandler(d.T, d.V, attrs.hiddenparamkey != undefined ? d[attrs.hiddenparamkey]: '');
							}
						});
				  } else {
					  	if(data.length>0){
							var focus = svg.append("g")
							.attr("class", "focus")
							.style("display", "none");
						
							focus.append("circle")
								.attr("class", "y") 
								.attr("r", 4.5)
								.style("fill", colorData[rand].dark)
								.style("stroke", function(d) {return colorData[rand].dark;});
		
							// place the value at the intersection
							focus.append("text")
								.attr("class", "y1")
								.style("stroke", "white")
								.style("stroke-width", "3.5px")
								.style("opacity", 0.8)
								//.attr("dx", 8)
								//.attr("dy", "-.3em");
							focus.append("text")
								.attr("class", "y2")
								//.attr("dx", 8)
								//.attr("dy", "-.3em");

							// place the date at the intersection
							focus.append("text")
								.attr("class", "y3")
								.style("stroke", "white")
								.style("stroke-width", "3.5px")
								.style("opacity", 0.8)
								//.attr("dx", 8)
								//.attr("dy", "1em");
							focus.append("text")
								.attr("class", "y4")
								//.attr("dx", 8)
								//.attr("dy", "1em");

							svg.append("rect")
							  .attr("class", "overlay")
								.style("fill", "none")
								.style("pointer-events", "all")
							   .attr("width", width)
							   .attr("height", height)
							  .on("mouseover", function() { focus.style("display", null); })
							  .on("mouseout", function() { focus.style("display", "none"); })
							  .on("mousemove", mousemove);
					  	}
				  }
				  
				  function mousemove() {
						var x0 = x.invert(d3.mouse(this)[0]),
							i = bisectDate(data, x0, 1),
							d0 = data[i - 1],
							d1 = data[i];/*,
							d = x0 - d0.T > d1.T - x0 ? d1 : d0;*/


						if ( d0 != undefined && d1 != undefined ) {
							d = x0 - d0.T > d1.T - x0 ? d1 : d0;	
						}
						
						var dxFocus = x(d.T) > halfOfWidth ? -158 : 8, dy12Focus = y(d.V) > 30 ? -21 : 18, dy34Focus = y(d.V) > 30 ? -3 : 34;
						var xTooltipValue = 'Time : '+timeFormat(new Date(d.T)), yTooltipValue = tooltipLabel+' : '+d.V;
							
						focus.select("circle.y")
							.attr("transform", "translate(" + x(d.T) + "," + y(d.V) + ")");


						focus.select("text.y1")
							.attr("dx", dxFocus)
							.attr("dy", dy12Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d.V) + ")")
							.text(yTooltipValue);


						focus.select("text.y2")
							.attr("dx", dxFocus)
							.attr("dy", dy12Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d.V) + ")")
							.text(yTooltipValue);


						focus.select("text.y3")
							.attr("dx", dxFocus)
							.attr("dy", dy34Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d.V) + ")")
							.text(xTooltipValue);


						focus.select("text.y4")
							.attr("dx", dxFocus)
							.attr("dy", dy34Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d.V) + ")")
							.text(xTooltipValue);

				  	}
				}
				
				
				scope.$watch("chartdata", function(newValue, oldValue, scope) {
					if( newValue != undefined) {
						data = newValue;
						
						var svg = d3.select("#" + attrs.id).select("svg").remove();
						
						generateAreaChartAsArrayInJSONFormart();
						/* avoided to show `No Data` if data not there, since graph is not showing proper due to width 
						 * if(data.length>0){
							generateAreaChartAsArrayInJSONFormart();
						}else{
							noData(attrs.id,parentWidth,parentHt);
						}*/
					}
				});
		   });
		}
	};
}]);
/*appedo-barchart-without-axis*/ 
appedoApp.directive('appedoBarchartWithoutAxis',['d3Service', 'appedoDirectiveChartUtils', function(d3Service, appedoDirectiveChartUtils){
	return {
		restrict: 'AE',
		scope: {
			//loadevent: '&'
		},
		link: function(scope, element, attrs) {
			var margin = parseInt(attrs.margin) || 20;
			
			//var width = 500, height = 60;
			//width = document.getElementById(attrs.parentid).offsetWidth - margin;
			var width = element.parent()[0].offsetWidth;
			var height = element.parent()[0].offsetHeight;
			
			var barheight = parseInt(attrs.barheight);
			
			var label = attrs.label || '';
			
			// data
			var bardata = [parseInt(attrs.bardata)];
			console.info(bardata);
			var defaultColor = attrs.color != undefined ? attrs.color : '#31c0be', bCanAcceptDiffColors = attrs.canAcceptDiffColors != undefined && attrs.canAcceptDiffColors == 'true' ? true : false;
			
			// 
			//var expressionHandler = scope.loadevent();
			
			d3Service.d3().then(function(d3) {
				var svg = d3.select(element[0])
							.append("svg")
							.attr("width", width)
							.attr("height", height)
							/*.on("click",  function(d, i) {
								expressionHandler(label);
							});*/
				
				svg.selectAll("rect")
				//svg.select("rect")		
					.data(bardata)
					.enter()
					.append("rect")
					.attr("id", attrs.barId != undefined ? attrs.barId : '')
					.attr("width", function(d) {						
						// tried based value bar width to adjust
						return width * (d/100);
					})
					.attr("height", barheight)
					.attr("x", 0)
					.attr("y", 0)
					.attr("fill", function(d) {return "hsl(" + Math.random() * 360 + ",50%,50%)";
//						//return color(d);
//						
//						if ( ! bCanAcceptDiffColors ) {
//							return defaultColor;
//						} else {
//							//return color(d);
//							
//							if ( d > 75 ) {
//								return appedoDirectiveChartUtils.barColorsBasedOnPercentage[0]; 
//							} else if ( d > 50 && d <= 75 ) {
//								return appedoDirectiveChartUtils.barColorsBasedOnPercentage[1];
//							} else if ( d > 25 && d <= 50 ) {
//								return appedoDirectiveChartUtils.barColorsBasedOnPercentage[2];
//							} else if ( d > 0 && d <= 25 ) {
//								return appedoDirectiveChartUtils.barColorsBasedOnPercentage[3];
//							}
//						}
					})
					/* when rectangle bar clicked only reflected when text clicked not reflected
					 * .on("click",  function(d, i) {
						console.info('label: '+label);
						alert('label: '+label);
					})*/
					//.transition().ease("elastic")
					.transition();
					// thinks, transistion to place respective order either of attr(x)
					//.delay(function(d, i) { return i * 100; })
					//.duration(200)
					//.attr("transform", "translate(50, 100)")
					//.attr("transform", "translate(0," + (height - padding) + ")")
					//.attr("transform", "translate("+padding+"," + (height - padding) + ")");
					

				// label at start
				svg.selectAll("text.label")
					.data(bardata)
					.enter()
					.append("text")
					.text(label)
					.attr("x", 4)
					.attr("y", (barheight/2)+3)
					//.attr("transform", "translate(50, 100)")
					//.attr("transform", "translate("+padding+"," + (height - padding) + ")")
					//.attr("text-anchor", "middle")
					.attr("font-size", "12px")
					.attr("fill", "black");
					
			});
		}
	};
}]);

appedoApp.directive('appedoiframe', [function(){
	return {
		scope: {
			callBack: '&iframeOnload'
		},
		link: function(scope, element, attrs){
			element.on('load', function(){
				var iframe = element[0];
				return scope.callBack();
			});
		}
	}
}])

appedoApp.directive('appedoLoading',['d3Service', function(d3Service){
	return {
		restrict: "AE",
		link: function(scope, element, attrs) {
		d3Service.d3().then(function(d3) {
			var parentWidth ;
			var rightM = 8;
			var leftM = 8;
			if (attrs.parrentnodeid==null || attrs.parrentnodeid=="undefined")
			{
				parentWidth=300;
			}
			else 
			{
				parentWidth=document.getElementById(attrs.parrentnodeid).offsetWidth;
			}
			var parentHt = 150;

			var svg = d3.select("#" + attrs.id).append("svg")
			.attr("width", parentWidth)
			.attr("height", parentHt);
			
			svg.append('image')
			/*.attr('x', (parentWidth)/4)*/
			.attr('x', 500)
			.attr('y', (parentHt)/3)
			.attr("width", 150)
			.attr("height", 20)
			.attr("xlink:href","assets/images/loading.gif");

	   });
	}};
}]);

function noData(id, width, height, noDataMsg){
	var svg = d3.select("#" + id).append("svg")
	.attr("width", width)
	.attr("height", height);
	
	svg.append('text').text(noDataMsg || 'No Data')
	.attr('x', (width)/4)
	.attr('y', (height)/3)
	.attr("class","apd-rbtrgfnfmly font_18 clr3569a");
}

//appedo-area-chart-directive-load-test//
appedoApp.directive('appedoAreaChartDirectiveLoadTest',['d3Service', 'sessionServices', 'appedoDataUtils', 'appedoDirectiveChartUtils', '$appedoUtils', function(d3Service, sessionServices, appedoDataUtils, appedoDirectiveChartUtils, $appedoUtils){
return {
	restrict: "AE",
	scope: {
		chartdata: '=',
		thresholdlimits: '=',
		pushdata: '=',
		loadevent: '&',
		loadapmevent: '&',
		loadpopupevent: '&',
		unit: '=',
		yaxiscategory : '=',
		// serverCurrentTime, used for last 1 hour data's min/max,(since client machine time varies from server chart data time, plotting of chart moves from axis )
		serverCurrentTime: '@'
		//yaxislabel: '@'
	},
	link: function(scope, element, attrs) {
		d3Service.d3().then(function(d3) {
			var data, xAxis, yAxis, area;
			var yaxiscategory = scope.yaxiscategory;
			if (yaxiscategory == null || yaxiscategory == undefined) {
				yaxiscategory = 'V';
			}
			var d3ChartTimeFormatForLT = JSON.parse(sessionServices.get("d3ChartTimeFormatForLT"));
			var colorData = [ /* Brown - {"dark":"#a73f05", "light":"#d08f6b"}, Brown - {"dark":"#c55204", "light":"#e57b33"}, 
								Yellow - {"dark":"#837704", "light":"#ead61e"}, GREEN - {"dark":"#3d7200", "light":"#89c346"}, */ 
							{"dark":"#104a8d", "light":"#7aa1ce"}, {"dark":"#aa6c42", "light":"#e5d3c6"},
							{"dark":"#7b3e80", "light":"#d7c5d9"}, {"dark":"#E56361", "light":"#EED2D1"} 
							];
			var FIVE_MIN = 1000 * 60 * 5;
			
			var rand = Math.floor(Math.random() * colorData.length);

			var tooltipLabel = attrs.tooltipLabel != undefined ? attrs.tooltipLabel : 'Value';
			
			// to convert data into human readable format
			var unit = scope.unit !== undefined ? scope.unit : '';
			
			// show plot's circle OR mousemove tooltip
			var bPlotCircle = attrs.linkstatus === "true";
			var bNoAggregation = (attrs.removeaggregation == "true");
			
			//var timeFormat = d3.time.format(attrs.xaxisformat);
			var labelTimeFormat = bNoAggregation ? d3.time.format("%d %b %H:%M:%S") : d3.time.format("%d %b %H:%M"), timeFormat;
				
			var expressionHandler = scope.loadevent();
			var expressionAPMHandler = scope.loadapmevent();
			var expressionPopupHandler = scope.loadpopupevent();
			
			var parentWidth ;
			var rightM = 8;
			var leftM = 8;
			var dotSize;
			var lineWidth;
			if (attrs.dotsize==null || attrs.dotsize==undefined)
			{
				dotSize = 1.5;
			}else{
				dotSize=attrs.dotsize;
			}
			
			if (attrs.linewith==null || attrs.linewith==undefined)
			{
				lineWidth = 2;
			}else{
				lineWidth=attrs.linewith;
			}
			
			if (attrs.parrentnodeid==null || attrs.parrentnodeid=="undefined")
			{
				parentWidth=300;
			}
			else 
			{
				parentWidth=document.getElementById(attrs.parrentnodeid).offsetWidth;
				if(parentWidth>800){
					rightM = 15;
					leftM = 3;
				}
			}
			var parentHt = 150;
			//Fixed width does not go well with responsive design hence made as percentage of parent heigth
			var margin = {top: parentHt*6/100, right: parentWidth*rightM/100, bottom: parentHt*20/100, left: parentWidth*leftM/100},
							width = parentWidth - margin.left - margin.right,
							height = parentHt - margin.top - margin.bottom, halfOfWidth = (width - margin.right) /2;
			
			function generateAreaChartAsArrayInJSONFormart() {
				var warning_threshold_value, critical_threshold_value;
				
				if( scope.thresholdlimits ) {
					warning_threshold_value = scope.thresholdlimits.warning_threshold_value;
					critical_threshold_value = scope.thresholdlimits.critical_threshold_value;
				}
				
				var bisectDate = d3.bisector(function(d) { return d.T; }).left;
				
				// returns `true`, if data in format of `[ [{T: 1462511914244, V: 0}, ...], ..., [..., {T: 1462515488947, V: 0}] ]`, to have discontinuous lines 
				var bDataArrayInArrayFormat = appedoDirectiveChartUtils.isDataArrayInArrayFormat(data);
				
				var aryXminXmax, aryYminYmax;
				
				// gets xmin, xmax & yMin, yMax
				if ( bDataArrayInArrayFormat ) {	// in format `[[{T: , V: }, {T: , V: },], [{T: , V: }]]`
					aryXminXmax = appedoDirectiveChartUtils.getXminXmaxAsArray(data);
					aryYminYmax = appedoDirectiveChartUtils.getYminYmaxAsArrayWCategory(data, yaxiscategory);
				} else {	// in format `[{T: , V: }, {T: , V: }, {T: , V: }]`
					aryXminXmax = appedoDirectiveChartUtils.getXminXmaxAsObject(data);
					aryYminYmax = appedoDirectiveChartUtils.getYminYmaxAsObjectWCategory(data, yaxiscategory);
				}
				/* alerts xMin, xMax; based on browser or server's current time */ 
				if ( attrs.modtype != 'sum' ) {
					var minX, maxX;
					
					// Slider Selection
					if(attrs.sliderIntervalInHours != undefined && attrs.sliderIntervalInHours != ''){
						//var now = scope.serverCurrentTime != undefined ? new Date(parseInt(scope.serverCurrentTime)) : new Date();
						var now = new Date();
//						var ONE_MIN = 1000 * 60 * 1;
						var TWO_MIN = 1000 * 60 * 2;
						var currentTimeinMillis = now.getTime(); 
						// seconds trunc
						maxX = (currentTimeinMillis - (currentTimeinMillis%(1000*60)));
						minX = $appedoUtils.getTimeInMillsBeforeSpecifiedHours(maxX, attrs.sliderIntervalInHours);
						
						//Round off to seconds
/*							var minXRoundedOff = (minX - (minX%(1000*60)))+ONE_MIN;
						minX = minXRoundedOff;*/
						
						/* commented; need to verify, whether commented is correct, 
						// Added two minute to the domain
						var minXInData = d3.min(data, function (d) { return d.T; });
						if(minX < minXInData){
							if(minXInData-minX < TWO_MIN){
								minX = minXInData;				
							}
						}*/
					} else {
						// for custom date filter
						minX = attrs.epochStartDate;
						maxX = attrs.epochEndDate;
					}
					
					/*
					 * since, chartdata plot's point is beyond OR after, 
					 * the browser time based on slider hrs. OR datepicker, set the chartdata point's min/max
					 */
					if ( minX > aryXminXmax[0] ) {
						minX = aryXminXmax[0];
					}
					if ( maxX < aryXminXmax[1] ) {
						maxX = aryXminXmax[1];
					}
					
					aryXminXmax[0] = minX || aryXminXmax[0];
					aryXminXmax[1] = maxX || aryXminXmax[1];
				}
				// alter minX, maxX, reduce & add 5 min 
				if ( aryXminXmax[0] === aryXminXmax[1] ) {
					aryXminXmax[0] = aryXminXmax[0] - (FIVE_MIN);
					aryXminXmax[1] = aryXminXmax[1] + (FIVE_MIN);
				}
				
				/* alters Y-Axis min & max */
				// Compare the Data-Array values with Threshold-Limits
				// if all the data points are above Critical
				// TODO if( is_above_threshold ) {
				if( aryYminYmax[0] > critical_threshold_value ) {
					aryYminYmax[0] = critical_threshold_value ;
				} else if( aryYminYmax[0] > warning_threshold_value ) {
					aryYminYmax[0] = warning_threshold_value;
				}
				// }
				// TODO if( ! is_above_threshold ) {
				if( aryYminYmax[1] < warning_threshold_value ) {
					aryYminYmax[1] = warning_threshold_value;
				} else if( aryYminYmax[1] < critical_threshold_value ) {
					aryYminYmax[1] = critical_threshold_value;
				}
				// Adjust the min & max with a 5% value, to avoid the data-point on chart's top-bottom borders
				aryYminYmax[1] = Math.ceil( aryYminYmax[1] + aryYminYmax[1] * 5 / 100); // adding 5% of max value to ensure graph is within boundry
				aryYminYmax[0] = aryYminYmax[0] - Math.ceil( aryYminYmax[0] * 5 / 100); // min value is reduced by 5% of min graph value to ensure boundry is intact
				
				
				var x = d3.time.scale().range([0, width - margin.right]);
				
				var y = d3.scale.linear().range([height, 0]);
				
				x.domain(aryXminXmax);
				y.domain(aryYminYmax);
				
				//if ( attrs.xaxisformat !== undefined && attrs.xaxisformat.length > 0 ) {
				/*if ( attrs.xaxisformat !== undefined ) {
					timeFormat = d3.time.format(attrs.xaxisformat);	
				} else {
					timeFormat = d3.time.format(appedoDirectiveChartUtils.getD3XAxisTimeFormat(aryXminXmax[0], aryXminXmax[1]));
				}*/
				// x-axis time format used, if sets in directive attr `xaxisformat` else based on x-axis's min, max shown
				timeFormat = d3.time.format( attrs.xaxisformat !== undefined ? attrs.xaxisformat : appedoDirectiveChartUtils.getD3XAxisTimeFormat(aryXminXmax[0], aryXminXmax[1]));
				
				xAxis = d3.svg.axis()
							.scale(x)
							.orient("bottom")
							.ticks(5)
							.tickFormat(timeFormat);

				yAxis = d3.svg.axis()
							.scale(y)
							.orient("left")
							.ticks(5)
							.tickFormat(function(d) {
								// tried, to format the value in human readable format based on unit, conversion is done for the unit in size 
								var aryFormattedValue = appedoDataUtils.getHumanReadableFormat(d, unit, true);
								return aryFormattedValue[0]+' '+aryFormattedValue[1];
							});
				
				area = d3.svg.area()
							.interpolate("linear")
							.x(function(d) { return x(d.T); })
							.y0(height)
							.y1(function(d) { return y(d[yaxiscategory]); });
				
				var areaTop = d3.svg.area()
								.interpolate("linear")
								.x(function(d) { return x(d.T); })
								.y0(0)
								.y1(function(d) { return y(d[yaxiscategory]); });
				
				var line = d3.svg.line()
							.interpolate("linear")
							.x(function(d) {return x(d.T);})
							.y(function(d){return y(d[yaxiscategory]);});
				
				var svg = d3.select("#" + attrs.id).append("svg")
							.attr("width", width + margin.left + margin.right)
							.attr("height", height + margin.top + margin.bottom)
							.append("g")
							.attr("transform","translate(" + margin.left * 3 / 2+ "," + margin.top + ")")
							.attr("onload","LoadHandler(evt)");
				
				svg.append("g")
					.attr("class", "axis")
					.attr("transform", "translate(0," + height + ")")
					.call(xAxis);
				
				svg.append("g")
					.attr("class", "axis")
					.call(yAxis)
					.append("text")
					.attr("transform", "rotate(-90)")
					.attr("y", (0-margin.left-margin.right))
					.attr("x", (0-(height / 2)))
					.style("text-anchor", "middle")
					.text('');
				
				// plots line chart
				var randNum = Math.random();
				if ( bDataArrayInArrayFormat ) {	// in format `[[{T: , V: }, {T: , V: },], [{T: , V: }]]`
					// plots line for discontinous line, (i.e. to have gap between line, for agent not sent data) 
					data.forEach(function(aryDataSet, i) {
						svg	.append("path")
							.datum(aryDataSet)
							//.attr("transform", "translate("+margin.left*3/2+", "+(0+5)+")")
							//.style("fill", colorData[rand].light) hsl(" + randNum * 360 + ",50%,75%)
							.style("fill","hsl(" + randNum * 360 + ",50%,75%)")
							.attr("d", area)
							.attr("clip-path", "url(#clip)")
							.attr("opacity","0.2");
						
						svg	.append("path")
							.attr("class", "line")
							//.attr("transform", "translate("+margin.left*3/2+", "+(0+5)+")")
							.attr("d", line(aryDataSet))
							.attr("clip-path", "url(#clip)")
//							.attr("stroke", colorData[rand].dark)
							.attr("stroke", "hsl(" + randNum * 360 + ",50%,50%)")
							.style("stroke-width", lineWidth);
						
						if( bPlotCircle || aryDataSet.length === 1 ) {
							svg.selectAll("dot")
								.data(aryDataSet)
								.enter().append('circle')
								.style("cursor","pointer")
								.attr("cx", function(d) { return x(d.T); })
								.attr("cy", function(d) { return y(d[yaxiscategory]); })
								.attr("r", dotSize)
//								.attr("fill", function(d) { return colorData[rand].dark; })
								.attr("fill","hsl(" + randNum * 360 + ",50%,75%)")
								.append("title")
								.text(getCircleTooltipText);
						}
					});
				} else {	// in format `[{T: , V: }, {T: , V: }, {T: , V: }]`
					svg.append("path")
						.datum(data)
//						.style("fill", colorData[rand].light)
						.style("fill","hsl(" + randNum * 360 + ",50%,75%)")
						.attr("d", area)
						.attr("opacity","0.2");
					
					svg.append("path")
						.attr("class", "line")
						.attr("d", line(data))
//						.attr("stroke", function(d) {return colorData[rand].dark;})
						.attr("stroke", "hsl(" + randNum * 360 + ",50%,50%)")
						.style("stroke-width", lineWidth);
					
					// plots circle, if given from attribure OR data has only one point
					if( bPlotCircle || data.length === 1 ) {
						svg.selectAll("dot")
							.data(data)
							.enter().append('circle')
							.style("cursor","pointer")
							.attr("cx",function(d) {return x(d.T);})
							.attr("cy",function(d){return y(d[yaxiscategory]);})
							.attr("r", dotSize)
//							.attr("fill",function(d) {return colorData[rand].dark;})
							.attr("fill","hsl(" + randNum * 360 + ",50%,75%)")
							.append("title")
							.text(getCircleTooltipText);
					}
				}
				
				// plots circle, if given from attribure OR data has only one point; 
				// on-click of circle, fn. called
				if( bPlotCircle && expressionHandler !== undefined ) {
					svg.selectAll("circle").on("click", function (d) {
						if(Number(attrs.chartdurationtype) < (d3ChartTimeFormatForLT.length-1)){
							expressionHandler(attrs.chartdurationtype, d.T);
						}
					});
				}
				
				function getCircleTooltipText(joDatum) {
					var returnValue;
					for (var key in joDatum) {
						if(key != yaxiscategory) {
							if(returnValue==undefined) {
								if(key == "T"){
									returnValue = 'Time : ' + labelTimeFormat(new Date(joDatum[key]));
								}else{
									returnValue = key + ' : ' + joDatum[key];
								}
							}else{
								if(key == "T"){
									returnValue = returnValue + '\n' +'Time : ' + labelTimeFormat(new Date(joDatum[key]));
								}else{
									returnValue = returnValue + '\n' + key + ' : ' + joDatum[key];
								}
							}
						}
					}
					return returnValue;
				}
				
				// Plot the Warning Threshold Limit as dotted-line
				if( aryYminYmax[1] > warning_threshold_value ) {
					svg	.append("line")
					.attr("x1", function(d) { return x(aryXminXmax[0]);})	// x position of the first end of the line
					.attr("y1", y(warning_threshold_value) )		// y position of the first end of the line
					.attr("x2", function(d) { return x(aryXminXmax[1]);})	// x position of the second end of the line
					.attr("y2", y(warning_threshold_value) )		// y position of the second end of the line
					.style("stroke", "#FFBF00")
					.style("stroke-width", "2px")
					.style("stroke-dasharray", "10,3")
					.style("cursor", "pointer")
					.append("title")
					.text('Warning Limit: '+warning_threshold_value);
				}

				// Plot the Critical Threshold Limit as dotted-line
				if( aryYminYmax[1] > critical_threshold_value ) {
					svg	.append("line")
					.attr("x1", function(d) { return x(aryXminXmax[0]);})	// x position of the first end of the line
					.attr("y1", y(critical_threshold_value) )		// y position of the first end of the line
					.attr("x2", function(d) { return x(aryXminXmax[1]);})	// x position of the second end of the line
					.attr("y2", y(critical_threshold_value) )		// y position of the second end of the line
					.style("stroke", "#F00")
					.style("stroke-width", "1px")
					.style("stroke-dasharray", "10,3")
					.style("cursor", "pointer")
					.append("title")
					.text('Critical Limit: '+critical_threshold_value);
				}
				
				// mousemove tooltip
				if ( ! bPlotCircle ) {
					// if(data.length>0){
						var focus = svg.append("g")
										.attr("class", "focus")
										.style("display", "none");
						
						focus.append("circle")
							.attr("class", "y") 
							.attr("r", 4.5)
							.style("fill", colorData[rand].dark)
							.style("stroke", function(d) {return colorData[rand].dark;});
						
						// place the value at the intersection
						focus.append("text")
							.attr("class", "y1")
							.style("stroke", "white")
							.style("stroke-width", "3.5px")
							.style("opacity", 0.8);
						focus.append("text")
							.attr("class", "y2");
						
						// place the date at the intersection
						focus.append("text")
							.attr("class", "y3")
							.style("stroke", "white")
							.style("stroke-width", "3.5px")
							.style("opacity", 0.8);
						focus.append("text")
							.attr("class", "y4");
						
						focus.append("text")
							.attr("class", "y5")
							.style("stroke", "white")
							.style("stroke-width", "3.5px")
							.style("opacity", 0.8);
						focus.append("text")
							.attr("class", "y6");
						
						focus.append("text")
							.attr("class", "y7")
							.style("stroke", "white")
							.style("stroke-width", "3.5px")
							.style("opacity", 0.8);
						focus.append("text")
							.attr("class", "y8");
						
						focus.append("text")
							.attr("class", "y9")
							.style("stroke", "white")
							.style("stroke-width", "3.5px")
							.style("opacity", 0.8);
						focus.append("text")
							.attr("class", "y10");
						
						focus.append("text")
							.attr("class", "y11")
							.style("stroke", "white")
							.style("stroke-width", "3.5px")
							.style("opacity", 0.8);
						focus.append("text")
							.attr("class", "y12");
						
						focus.append("text")
							.attr("class", "y13")
							.style("stroke", "white")
							.style("stroke-width", "3.5px")
							.style("opacity", 0.8);
						focus.append("text")
							.attr("class", "y14");
						
						svg.append("rect")
							.attr("class", "overlay")
							.style("fill", "none")
							.style("pointer-events", "all")
							.attr("width", width)
							.attr("height", height)
							.on("mouseover", function() { focus.style("display", null); })
							.on("mouseout", function() { focus.style("display", "none"); })
							.on("mousemove", mousemove);
						
						if(attrs.popupstatus=="true"){
							svg.attr("class", "apd-curpnt");
							svg.selectAll("rect").on("click", function (d) {
								var x0 = x.invert(d3.mouse(this)[0]),
								i = bisectDate(data, x0, 1),
								d0 = data[i - 1],
								d1 = data[i],
								aryFormattedValue = [];
								
								if ( d0 != undefined && d1 != undefined ) {
									d = x0 - d0.T > d1.T - x0 ? d1 : d0;	
								}
								expressionPopupHandler(d.T,attrs.popupcounterid,attrs.popupcountercategory);
							});
						}
					//}
				}
				
				if(attrs.linktodetailspage=="true"){
					svg.attr("class", "apd-curpnt");
					svg.on("click", function (d) {
						expressionAPMHandler();
					});
				}
				
				function mousemove() {
					var x0 = x.invert(d3.mouse(this)[0]), aryChartData = bDataArrayInArrayFormat ? d3.merge(data) : data,
						i = bisectDate(aryChartData, x0, 1),
						d0 = aryChartData[i - 1],
						d1 = aryChartData[i],
						aryFormattedValue = [],
						d = ((d0 === undefined || d1 === undefined) ? d0 || d1 : (x0 - d0.T > d1.T - x0 ? d1 : d0));
					
					var dy56Focus = y(d[yaxiscategory]) > 41 ? -11 : 50;
					var dy78Focus = y(d[yaxiscategory]) > 41 ? 5 : 66;
					var dy100Focus = y(d[yaxiscategory]) > 41 ? 21 : 84;
					var dy122Focus = y(d[yaxiscategory]) > 41 ? 37 : 100;
					var dy144Focus = y(d[yaxiscategory]) > 41 ? 53 : 116;
					var xTooltipValue = 'Time: '+labelTimeFormat(new Date(d.T));
					// to format the value based on unit, conversion is done for the unit in size, roundOfValue is ignored goven as false
					aryFormattedValue = appedoDataUtils.getHumanReadableFormat(d[yaxiscategory], unit, false);
					var yTooltipValue = aryFormattedValue[0]==undefined?tooltipLabel+' : -':tooltipLabel+' : '+aryFormattedValue[0]+' '+aryFormattedValue[1];
					
					d.Min = d.Min==undefined?0:d.Min;
					aryFormattedValue = appedoDataUtils.getHumanReadableFormat(d.Min, unit, false);
					var yTooltipMin = aryFormattedValue[0]==undefined?'Min: -':'Min: '+aryFormattedValue[0]+' '+aryFormattedValue[1];
					
					d.Avg = d.Avg==undefined?0:d.Avg;
					aryFormattedValue = appedoDataUtils.getHumanReadableFormat(d.Avg, unit, false);
					var yTooltipAvg = aryFormattedValue[0]==undefined?'Avg: -':'Avg: '+aryFormattedValue[0]+' '+aryFormattedValue[1];
					
					d.Max = d.Max==undefined?0:d.Max;
					aryFormattedValue = appedoDataUtils.getHumanReadableFormat(d.Max, unit, false);
					var yTooltipMax = aryFormattedValue[0]==undefined?'Max: -':'Max: '+aryFormattedValue[0]+' '+aryFormattedValue[1];		
					
					var yTooltipWarningThreshold;
					if( warning_threshold_value ) {
						aryFormattedValue = appedoDataUtils.getHumanReadableFormat(warning_threshold_value, unit, false);
						yTooltipWarningThreshold = aryFormattedValue[0]==undefined?'Warning: -':'Warning: '+aryFormattedValue[0]+' '+aryFormattedValue[1];
					}
					
					var yTooltipCriticalThreshold;
					if( critical_threshold_value ) {
						aryFormattedValue = appedoDataUtils.getHumanReadableFormat(critical_threshold_value, unit, false);
						yTooltipCriticalThreshold = aryFormattedValue[0]==undefined?'Critical: -':'Critical: '+aryFormattedValue[0]+' '+aryFormattedValue[1];
					}
					
					
					if( bNoAggregation ){
						var dxFocus = x(d.T) > halfOfWidth ? -158 : 8, dy12Focus = y(d[yaxiscategory]) > 30 ? -21 : 18, dy34Focus = y(d[yaxiscategory]) > 30 ? -3 : 34;
						
						focus.select("text.y1")
							.attr("dx", dxFocus)
							.attr("dy", dy12Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipValue);
						
						focus.select("text.y2")
							.attr("dx", dxFocus)
							.attr("dy", dy12Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipValue);
						
						focus.select("text.y3")
							.attr("dx", dxFocus)
							.attr("dy", dy34Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(xTooltipValue);
						
						focus.select("text.y4")
							.attr("dx", dxFocus)
							.attr("dy", dy34Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(xTooltipValue);
						
						if( warning_threshold_value ) {
							focus.select("text.y5")
								.attr("dx", dxFocus)
								.attr("dy", dy56Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipWarningThreshold);
							focus.select("text.y6")
								.attr("dx", dxFocus)
								.attr("dy", dy56Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipWarningThreshold);
						}
						
						if( critical_threshold_value ) {
							focus.select("text.y7")
								.attr("dx", dxFocus)
								.attr("dy", dy56Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipCriticalThreshold);
							focus.select("text.y8")
								.attr("dx", dxFocus)
								.attr("dy", dy56Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipCriticalThreshold);
						}
					} else {
						var dxFocus = x(d.T) > halfOfWidth ? -158 : 8, dy12Focus = y(d[yaxiscategory]) > 41 ? -45 : 18, dy34Focus = y(d[yaxiscategory]) > 41 ? -27 : 34;
						focus.select("text.y1")
							.attr("dx", dxFocus)
							.attr("dy", dy12Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipValue);
						
						focus.select("text.y2")
							.attr("dx", dxFocus)
							.attr("dy", dy12Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipValue);
						
						focus.select("text.y3")
							.attr("dx", dxFocus)
							.attr("dy", dy34Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipMin);
						
						focus.select("text.y4")
							.attr("dx", dxFocus)
							.attr("dy", dy34Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipMin);
						
						focus.select("text.y5")
							.attr("dx", dxFocus)
							.attr("dy", dy56Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipAvg);
						
						focus.select("text.y6")
							.attr("dx", dxFocus)
							.attr("dy", dy56Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipAvg);
						
						focus.select("text.y7")
							.attr("dx", dxFocus)
							.attr("dy", dy78Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipMax);
						
						focus.select("text.y8")
							.attr("dx", dxFocus)
							.attr("dy", dy78Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(yTooltipMax);
						
						focus.select("text.y9")
							.attr("dx", dxFocus)
							.attr("dy", dy100Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(xTooltipValue);
						
						focus.select("text.y10")
							.attr("dx", dxFocus)
							.attr("dy", dy100Focus)
							.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
							.text(xTooltipValue);
						
						if( warning_threshold_value ) {
							focus.select("text.y11")
								.attr("dx", dxFocus)
								.attr("dy", dy122Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipWarningThreshold);
							focus.select("text.y12")
								.attr("dx", dxFocus)
								.attr("dy", dy122Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipWarningThreshold);
						}
						
						if( critical_threshold_value ) {
							focus.select("text.y13")
								.attr("dx", dxFocus)
								.attr("dy", dy144Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipCriticalThreshold);
							focus.select("text.y14")
								.attr("dx", dxFocus)
								.attr("dy", dy144Focus)
								.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")")
								.text(yTooltipCriticalThreshold);
						}
					}

					focus.select("circle.y")
						.attr("transform", "translate(" + x(d.T) + "," + y(d[yaxiscategory]) + ")");
				}
			}
			
			scope.$watch("chartdata", function(newValue, oldValue, scope) {
				if( newValue != undefined) {
					data = [];
					data = newValue;
					//timeFormat = d3.time.format(attrs.xaxisformat);
					var svg = d3.select("#" + attrs.id).select("svg").remove();
					if( data.length > 0 ){
						generateAreaChartAsArrayInJSONFormart();
					}else{
						noData(attrs.id,parentWidth,parentHt,attrs.nodatamsg);
					}
				} 
			});
			
			scope.$watch("yaxiscategory", function(newValue, oldValue, scope) {
				if( newValue != undefined) {
					//yaxiscategory = [];
					yaxiscategory = newValue;
					//timeFormat = d3.time.format(attrs.xaxisformat);
					var svg = d3.select("#" + attrs.id).select("svg").remove();
					if( data.length > 0 ){
						generateAreaChartAsArrayInJSONFormart();
					}else{
						noData(attrs.id,parentWidth,parentHt,attrs.nodatamsg);
					}
				} 
			});
		});
	}
};
}]);

/* dropdown-multiselect-sum */
appedoApp.directive('dropdownMultiselectSum', ['$document',function($document){
   return {
	   restrict: 'E',
	   scope:{		   
			model: '=',
			options: '=',
			pre_selected: '=preSelected',
			loadevent: '&',
			customtitle: '@'
	   },
	   template: "<div class ='dropdownMultiselectSum'><div class='' data-ng-class='{open: open}'>"+
				"<div class='apd-multiSelect1 dropdown-toggle apd-curpnt' data-ng-click='open=!open; openDropdown()'><span>{{model.length > 0 ? model.length +' '+customtitle:'Select Atleast One'}}</span></div>"+
				"<ul class='dropdown-menu apd-multiSelectul ' aria-labelledby='dropdownMenu'>" + 
					"<li ng-model='selectedValues.option' data-ng-repeat='option in options' ng-click='getSelectedItem()' class='apd-multiSelectli'> <a data-ng-click='setSelectedItem()' class='apd-curpnt'><i data-ng-class='isChecked(option.label)'></i>{{(option.label1==undefined || option.label2==undefined)?option.label:''}}<div ng-hide='(option.label1==undefined || option.label2==undefined)' style='padding-right:25px'>{{option.label1}}<br/><span style='font-size: 12px'>{{option.label2}}<span></div></a></li>" +
				"</ul>" +
				"</div></div>" ,
	   controller: function($scope){
		   	var expressionHandler = $scope.loadevent();
		   	var selectedCount = 0;
		   	$scope.closeOnBlur= true;
		   	$scope.selectedValues = {};
		   	$scope.model=[];
			$scope.openDropdown = function(){	   
			};
		   
			$scope.getSelectedItem = function(){
				expressionHandler();
			};
			
			$scope.setSelectedItem = function(){
				var id = this.option.label;
				if (_.contains($scope.model, id)) {
					$scope.model = _.without($scope.model, id);
				} else {
					$scope.model.push(id);
				}
				$scope.selectedValues = $scope.model;
				return false;
			};
						
			$scope.isChecked = function (id) {   
				if (_.contains($scope.model, id)) {
					return 'fa fa-check pull-right';
				} 
				return false;
			};   
			
			/*	if ($scope.closeOnBlur) {
				$document.on('click', function (e) {
					var target = e.target.parentElement;
					var parentFound = false;

					while (angular.isDefined(target) && target !== null && !parentFound) {
						if (_.contains(target.className.split(' '), 'dropdownMultiselectSum') && !parentFound) {
							parentFound = true;
						}
						target = target.parentElement;
					}
					
					if (!parentFound) {
						$scope.$apply(function () {
							$scope.open = false;
						});
					}
				});
			}*/
	   } 
   } 
}]);

/*appedo-multi-line-chart-vertical-notification-directive*/
appedoApp.directive('appedoMultiLineChartVerticalNotificationDirective',['$window', '$timeout', 'd3Service', '$appedoUtils', function($window, $timeout, d3Service, $appedoUtils){
	return {
		restrict: "AE",
		scope: {
			chartdata: '=',
			loadevent: '&'
		},
		link: function(scope, element, attrs) {
			var expressHandler = scope.loadevent();
			
			d3Service.d3().then(function(d3) {
				var timeFormat = d3.time.format(attrs.xaxisformat);
				var tooltipTimeFormat = d3.time.format("%Y-%b-%d %H:%M:%S");
				
				var data = [];
				var failureResults = [];
				var failureXAxisDataIndex = '';
				var bDisplayAvailabilityMonitorChart = false;
				
				var parentWidth ;
				var dotSize;
				if (attrs.dotsize==null || attrs.dotsize==undefined)
				{
					dotSize = 3.5;
				}else{
					dotSize=attrs.dotsize;
				}
				if (attrs.parrentnodeid==null || attrs.parrentnodeid=="undefined")
				{
					parentWidth=300;
				}
				else 
				{
					parentWidth=document.getElementById(attrs.parrentnodeid).offsetWidth;
				}
				var parentHt;
				
				if(scope.chartdata.length>0 && scope.chartdata.length>7){
					parentHt = 20*scope.chartdata.length; //dynamic height based on the length of the data
				}else{
					parentHt = 150;	
				}
				
				//Fixed width does not go well with responsive design hence made as percentage of parent heigth
				var margin = {top: parentHt*6/100, right: parentWidth*10/100, bottom: parentHt*20/100, left: parentWidth*5/100},
						width = parentWidth - margin.left - margin.right,
						height = parentHt - margin.top - margin.bottom ;
				
				function generateMultiLineChart()
				{
						var x = d3.time.scale()
									.range([0, width]);
	
						var y = d3.scale.linear()
									.range([height, 0]);
	
						var color = d3.scale.category10();
	
	//					var xAxis = d3.svg.axis()
	//						.scale(x)
	//						.orient("bottom");
	
						xAxis = d3.svg.axis()
								.scale(x)
								.orient("bottom")
								.ticks(5)
								.tickFormat(timeFormat);
						
						var yAxis = d3.svg.axis()
									.scale(y)
									.orient("left")
									.ticks(5);
	
						var line = d3.svg.line()
									.interpolate("linear")
									.x(function (d) {
										return x(d.Date);
									})
									.y(function (d) {
										return y(d.Value);
									});
						
						var svg = d3.select("#" + attrs.id).append("svg")
							.attr("width", width + margin.left + margin.right)
							.attr("height", height + margin.top + margin.bottom + 30) //increased height 60 to display legend below
							.append("g")
							.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
						
						color.domain(data.map(function (d) { return d.City; }));
						
						// From Epoch time, create Date object
						data.forEach(function (kv) {
							kv.Data.forEach(function (d) {
								d.Time = new Date(d.Date);
								d.Name = kv.City;
							});
						});
						failureResults.forEach(function (d) {
							d.Time = new Date(d[failureXAxisDataIndex]);
						});
						
						var cities = data;
						var minX, maxX =null;
						var minY, maxY =null;
						
						if ( data.length === 0 && failureResults.length === 0 && bDisplayAvailabilityMonitorChart ) {
							// since URL is available all time, `failureResults` would be 0, to show the green line as URL alive, m-
							var now = new Date();
							minX = $appedoUtils.getTimeInMillsBeforeSpecifiedHours(now.getTime(), attrs.sliderIntervalInHours);
							maxX = now.getTime();
						} else {
							// Get the earliest TimeStamp from both ChartData & failureResults
							var minDataTime = d3.min(data, function (kv) { if( kv.Data.length > 0 ){ return kv.Data[0].Time; } });
							var minFailureTime = ( failureResults.length > 0 ) ? failureResults[0].Time:undefined;
							
							if( minFailureTime == undefined ) {
								minX = minDataTime;
							} else {
								minX = (minDataTime < minFailureTime)?minDataTime:minFailureTime;
							}
							
							// Get the earliest TimeStamp from both ChartData & failureResults
							var maxDataTime = d3.max(data, function (kv) { if( kv.Data.length > 0 ){ return kv.Data[ kv.Data.length-1 ].Time; } });
							var maxFailureTime = ( failureResults.length > 0 ) ? failureResults[ failureResults.length-1 ].Time:undefined;
							
							if( maxFailureTime == undefined ) {
								maxX = maxDataTime;
							} else {
								maxX = (maxDataTime > maxFailureTime)?maxDataTime:maxFailureTime;
							}
							
							minY = d3.min(data, function (kv) { return d3.min(kv.Data, function (d) { return d.Value; }); });
							maxY = d3.max(data, function (kv) { return d3.max(kv.Data, function (d) { return d.Value; }); });
							
							maxY = Math.ceil(maxY + maxY * 5 / 100); // adding 5% of max value to ensure graph is within boundry
							minY = minY - Math.ceil(minY * 5 / 100); // min value is reduced by 5% of min graph value to ensure boundry is intact
						}
	
						// Slider Selection
						if(attrs.sliderIntervalInHours != undefined && attrs.sliderIntervalInHours != ''){
							var nowMinX, nowMaxX = null;
							var now = new Date();
							nowMinX = $appedoUtils.getTimeInMillsBeforeSpecifiedHours(now.getTime(), attrs.sliderIntervalInHours);
							nowMaxX = now.getTime();
	
							/*
							 * since, chartdata plot's point is beyond OR after, 
							 * the browser time based on slider hrs. OR datepicker, set the chartdata point's min/max
							 */
							if ( nowMinX < minX ) {
								minX = nowMinX;
							}
							if ( nowMaxX > maxX ) {
								maxX = nowMaxX;
							}
						}
						
						x.domain([minX, maxX]);
						y.domain([minY, maxY]);
						
						var legend = svg.selectAll('g')
										.data(cities)
										.enter()
										.append('g')
										.attr('class', 'legend');
						
						// to show legend below the x axis
						legendSpace = width/4;
						
						// for focus tooltip
						var focus = svg	.append("g")
										.attr("class", "focus")
										.style("display", "none");
						
						// remove div, to avoid multiple times to have, thinks chart one minute refresh multiple div.apd-chart-tooltip is available, thinks below line to add in $watch
						d3.selectAll('div.apd-chart-tooltip').remove();
						
						// tooltip
						var tooltip = d3.select("body")
										.append("div")
										.attr("class", "apd-chart-tooltip")
										.style("opacity", 1e-6);
						
						var xFormatterRect = -1, yFormatterRect = 5;
						legend.append('rect')
							.style("stroke", "black")
							.style("stroke-width", "0.5px")
							.style('cursor', 'pointer')
							.attr('x', function(d, i){
								if( i>0 && i % 4 === 0){
									xFormatterRect = -1;
								}
								xFormatterRect += 1;
								return ((legendSpace/4)+xFormatterRect*legendSpace)-25;
							})
							.attr('y', function(d, i){
								if( i>0 && i % 4 === 0){
									yFormatterRect += 20;
								}
								return (height + ((margin.bottom+10)/2)+ yFormatterRect);
							})
							.attr('width', 12)
							.attr('height', 10)
							.style('fill', function(d) {
								return color(d.City);
							})
							.on("click", function(d, i){ mouseclick(d, i); });
						
						var xFormatter = -1, yFormatter = 5, xFormatterCheck = -1, yFormatterCheck = 5;
						
						// tick
						legend.append('text')
							.attr('x', function(d, i){
								if( i>0 && i % 4 === 0){
									xFormatterCheck = -1;
								}
								xFormatterCheck += 1;
								return ((legendSpace/4)+xFormatterCheck*legendSpace)-22;
							})
							.attr('y', function(d, i){
								if( i>0 && i % 4 === 0){
									yFormatterCheck += 20;
								}
								// added `-2`, since to the tick mark to come litle above `rect`
								return (10+ height + ((margin.bottom+10)/2)+ yFormatterCheck) - 2;
							})
							.style('fill', '#74c476')
							.style('font-size', '18px')
							.style('cursor', 'pointer')
							.attr("id", function(d, i) { return 'dirNotifi_text_check_'+i; })
							.html('&#xf00c;')
							.on("click", function(d, i){ mouseclick(d, i); });
						
						// legend
						legend.append('text')
							.attr('x', function(d, i){
								if( i>0 && i % 4 === 0){
									xFormatter = -1;
								}
								xFormatter += 1;
								return (legendSpace/4)+xFormatter*legendSpace;
							})
							.attr('y', function(d, i){
								if( i>0 && i % 4 === 0){
									yFormatter += 20;
								}
								return (10+ height + ((margin.bottom+10)/2)+ yFormatter);
							})
							.attr('width', 20)
							.attr('height', 20)
							.attr('class', 'apd-text-overflow-ellipsis')
							.style('fill', function(d) {return color(d.City);})
							.style('cursor', 'pointer')
							.text(function(d){
								var outText = "";
								if( d.City.length > 28) {
									outText = d.City.substring(0, 28)+'...';
								} else {
									outText = d.City;
								}
								return outText;
							})
							.on("mouseover", function(d) {
								d3.select(this).style("font-weight", "bold");
								
								tooltip.transition()
									.duration(200)
									.style("opacity", 0.80);
								
								//tooltip text 
								var toolTipText = '', location = (d.City).split(":")[0], browserConnect = (d.City).split(":")[1];
								toolTipText += '<div class="apd-counterText" >';
								toolTipText += 	'Country: <b>'+ location.split("--")[0] +'</b> , ';
								toolTipText += 	'City: <b>'+ location.split("--")[1] +'</b><BR/>';
								toolTipText += 	'Browser: <b>'+ browserConnect.split(".")[0] +'</b> , ';
								toolTipText += 	'Connection: <b>'+ browserConnect.split(".")[1]+'</b>';
								toolTipText += '</div>';
								
								tooltip.html(toolTipText)
									.style("top", (d3.event.pageY + 10) + "px")
									.style("left", (d3.event.pageX + 10) + "px");
							})
							.on("mouseout", function(d) {
								d3.select(this).style("font-weight", "");
								
								focus.style("display", "none");
								tooltip.transition()
										.duration(200)
										.style("opacity", 0);
							})
							.on("click", function(d, i){ mouseclick(d, i); });
						
						function mouseclick(d,i){
							// Determine if current line is visible 
							var active = d.active ? false : true, 
									newOpacity = active ? 0 : 1,
									newEvent = active ? "none" : "all";
											
							// hide or show, the check
							d3.select("#dirNotifi_text_check_"+i)
								.transition().duration(100)
								.style("opacity", newOpacity);
							
							// Hide or show, the line, circle and setting pointer-events to none to hide title.
							d3.select("#dirNotifi_city_"+i)
									.transition().duration(100) 
									.style("pointer-events", newEvent)
									.style("opacity", newOpacity);
							
							// Update whether or not the elements are active
							d.active = active;
						}
						
						svg.append("g")
							.attr("class", "x axis")
							.attr("transform", "translate(0," + height + ")")
							.call(xAxis);
						
						svg.append("g")
							.attr("class", "axis")
							.call(yAxis)
							.append("text")
							.attr("transform", "rotate(-90)")
							.attr("y", (0-margin.left-margin.right))
							.attr("x", (0-(height / 2)))
							.style("text-anchor", "middle")
							.text('Count');
						
						var city = svg.selectAll(".city")
										.data(cities)
										.enter().append("g")
										.attr("class", "city")
										.attr("id", function(d, i) { return 'dirNotifi_city_'+i; });
						
						city.append("path")
							.attr("class", "line")
							.attr("d", function (d) {
								return line(d.Data);
							})
							.style("stroke", function (d) {
								return color(d.City);
							});
						
						/*
						city.append("text")
							.datum(function (d) {
								return {
									name: d.City,
									date: d.Data[d.Data.length - 1].Time,
									value: d.Data[d.Data.length - 1].Value
								};
							})
							.attr("transform", function (d) { return "translate(" + x(d.date) + "," + y(d.value) + ")"; });
						*/
						city.selectAll('circle')
							.data(function(d){ return d.Data;})
							.enter().append('circle')
							.style("cursor","pointer")
							.attr("cx", function(d) { return x(d.Time);})
							.attr("cy", function(d) { return y(d.Value);})
							.attr("r", dotSize)
							.style("fill", function(d) { return color(d.Name);})
							.append("title")
							.text(function(d) {
								return 'Date & Time : '+timeFormat(new Date(d.Time))+'\nResp Time(ms) : '+d.Value; 
							});
						
						city.selectAll("circle")
							.on("click", function (d) {
								if( attrs.linkstatus == "true" ){
									expressHandler(d.filename,timeFormat(new Date(d.Time)),d.Value,d.Name,d.id);
								}
							});
						
						
						// for availability monitor, to draw the line for, URL is available
	//					if ( bDisplayAvailabilityMonitorChart ) {
	//						svg	.append("line")
	//							.attr("x1", function(d) { return x(minX);})	// x position of the first end of the line
	//							.attr("y1", 0)								// y position of the first end of the line
	//							.attr("x2", function(d) { return x(maxX);})	// x position of the second end of the line
	//							.attr("y2", 0)								// y position of the second end of the line
	//							.style("stroke", "#74c476")
	//							.style("stroke-width", "2px")
	//							.style("cursor", "pointer")
	//							.append("title")
	//							.text('URL is available');	
	//					}
						
						// Breach Line plotting
				 		svg.selectAll("g.verticalLine")
							.data(failureResults)
							.enter()
							.append("rect")
							.attr("width", 2)
							.attr("height", height)
							.attr("class", 'verticalLine')
							.style("cursor", "pointer")
							.attr('stroke', 'RED')
							.attr("stroke-width", "2px")
							.style("pointer-events", "all")
							.style("opacity", 0.4)
							.attr("clip-path", "url(#clip)")
							.attr("x", function(d) {
								return x(d.Time);
							})
							.attr("y", 0)
							//.attr("transform", "translate("+margin.left*3/2+", "+(0+5)+")")
							.on("mouseover", function(d) {
								// highlight on mouse over
								d3.select(this)
									.attr("stroke-width", "5px")
									.style("opacity", 0.65);
							})
							.on("mouseout", function() {
								// un-highlight on mouse over 
								d3.select(this)
									.attr("stroke-width", "2px")
									.style("opacity", 0.4);
							})
							.append("title")
							.text(function(d) {
								// TODO: thinks intead of title show in div tag
								return 'URL was unavailable on '+tooltipTimeFormat(d.Time)+'\nin `'+d.location+'`\nreported as `'+d.response_status+'`';
							});
				}
				
				scope.$watch("chartdata", function(newValue, oldValue, scope) {
					if( newValue != undefined) {
						data = [];
						data = newValue[0].chartData || [];
						failureResults = newValue[0].failureResults || [];
						failureXAxisDataIndex = newValue[0].failureXAxisDataIndex;
						bDisplayAvailabilityMonitorChart = (attrs.enableAvailabilityMonitor === 'true' && attrs.availabilityTestStatus !== 'Scheduled');
						
						timeFormat = d3.time.format(attrs.xaxisformat);
						var svg = d3.select("#" + attrs.id).select("svg").remove();
						var isResponseMonitorRunning = attrs.enableResponseMonitor==='true'?true:false;
						var isInitialRun = attrs.testStatus==='true'?true:false;
	
						if( data.length > 0 || failureResults.length > 0){
							generateMultiLineChart();
						} else {
							var nodatamsg;
							if(isInitialRun){
								if(isResponseMonitorRunning){
									nodatamsg = 'SUM Test under process...';
								}else{
									nodatamsg = 'No data, as Response monitoring is disabled';
								}
							}else{
								nodatamsg = attrs.nodatamsg;
							}
							noData(attrs.id,parentWidth,parentHt,nodatamsg);
						}
					}
				});
		   });
		}
	};
}]);

//load Test Request Response charts
appedoApp.directive('appedoMultiLineChartDirectiveLoadTest',['d3Service', 'sessionServices', function(d3Service, sessionServices){
	return {
		restrict: "AE",
	scope: {
		chartdata: '=',
		loadevent: '&'
	},
	link: function(scope, element, attrs) {
		var expressionHandler = scope.loadevent();
	d3Service.d3().then(function(d3) {
		var timeFormat = d3.time.format(attrs.xaxisformat);
		var data=[];
		var d3ChartTimeFormatForLT = JSON.parse(sessionServices.get("d3ChartTimeFormatForLT"));
		var parentWidth ;
		var dotSize;
		if (attrs.dotsize==null || attrs.dotsize==undefined)
		{
			dotSize = 3.5;
		}else{
			dotSize=attrs.dotsize;
		}
		if (attrs.parrentnodeid==null || attrs.parrentnodeid=="undefined")
		{
			parentWidth=300;
		}
		else 
		{
			
			parentWidth=document.getElementById(attrs.parrentnodeid).offsetWidth;
		}
		
		var parentHt = 150;
		
		//Fixed width does not go well with responsive design hence made as percentage of parent heigth
		var margin = {top: parentHt*6/100, right: parentWidth*15/100, bottom: parentHt*20/100, left: parentWidth*8/100},
				width = parentWidth - margin.left - margin.right,
				height = parentHt - margin.top - margin.bottom ;
	
		function generateMultiLineChart()
		{   
				var x = d3.time.scale()
					.range([0, width]);
	
				var y = d3.scale.linear()
					.range([height, 0]);
	
				var color = d3.scale.category10();
	
				var xAxis = d3.svg.axis()
				.scale(x)
				.orient("bottom")
				.ticks(5)
				.tickFormat(timeFormat);
				
				var yAxis = d3.svg.axis()
					.scale(y)
					.orient("left");
	
				var line = d3.svg.line()
					.interpolate("linear")
					.x(function (d) {
					return x(d.Date);
				})
					.y(function (d) {
					return y(d.Value);
				});
	
				var svg = d3.select("#" + attrs.id).append("svg")
					.attr("width", width + margin.left + margin.right)
					.attr("height", height + margin.top + margin.bottom)
					.append("g")
					.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
	
				color.domain(data.map(function (d) { return d.City+'-'+d.loadgen_name; }));
	
				data.forEach(function (kv) {
					kv.Data.forEach(function (d) {
						d.Time = new Date(d.Date);
						d.Name = kv.City+'-'+kv.loadgen_name;
						d.IP = kv.loadgen_name;
					});
				});
				
				
				var cities = data;
	
				var minX = d3.min(data, function (kv) { return d3.min(kv.Data, function (d) { return d.Time; }) });
				var maxX = d3.max(data, function (kv) { return d3.max(kv.Data, function (d) { return d.Time; }) });
				var minY = d3.min(data, function (kv) { return d3.min(kv.Data, function (d) { return d.Value; }) });
				var maxY = d3.max(data, function (kv) { return d3.max(kv.Data, function (d) { return d.Value; }) });
	
				maxY=Math.ceil(Number(maxY)+Number(maxY)*5/100); // adding 5% of max value to ensure graph is within boundry
				minY=Number(minY)-Math.ceil(Number(minY)*5/100); // min value is reduced by 5% of min graph value to ensure boundry is intact
	
				x.domain([minX, maxX]);
				y.domain([minY, maxY]);
	
				var legend = svg.selectAll('g')
				  .data(cities)
				  .enter()
				.append('g')
				  .attr('class', 'legend')
	  			  .attr('class', 'font_14');
	
			  legend.append('rect')
				  .attr('x', width + 5)
				  .attr('y', function(d, i){ return i *  15;})
				  .attr('width', 10)
				  .attr('height', 10)
				  .style('fill', function(d) { 
					return color(d.City+'-'+d.loadgen_name);
				  });
				  
		  	  legend.append('text')
		  		  .attr('x', width + 15)
		  		  .attr('y', function(d, i){ return (i *  15) + 9;})
		  		  .attr('width', 20)
		  		  .attr('class', 'apd-text-overflow-ellipsis')
		  		  .style('fill', function(d) {return color(d.City+'-'+d.loadgen_name);})
		  		  .text(function(d){ var outText = ""; if(d.City.length>15){outText = d.City.substring(0, 15)+'...';} else { outText = d.City;} return outText;})
		  		  .append("title")
				  .text(function(d){ return d.City; });
	
	
	
				svg.append("g")
					.attr("class", "x axis")
					.attr("transform", "translate(0," + height + ")")
					.call(xAxis);
	
				svg.append("g")
					.attr("class", "axis")
					.call(yAxis)
					.append("text")
					.attr("transform", "rotate(-90)")
					.attr("y", (0-margin.left-margin.right))
					.attr("x", (0-(height / 2)))
					.style("text-anchor", "middle")
					.text('Count');
	
				var city = svg.selectAll(".city")
					.data(cities)
					.enter().append("g")
					.attr("class", "city");
	
				city.append("path")
					.attr("class", "line")
					.attr("d", function (d) {
						return line(d.Data);
					})
					.style("stroke", function (d) {
						return color(d.City+'-'+d.loadgen_name);
					});
	
				city.append("text")
					.datum(function (d) {
						return {
							name: d.City,
							date: d.Data[d.Data.length - 1].Time,
							value: d.Data[d.Data.length - 1].Value
						};
					})
					.attr("transform", function (d) {
					return "translate(" + x(d.date) + "," + y(d.value) + ")";
				});
	
				city.selectAll('circle')
					.data(function(d){ return d.Data})
					.enter().append('circle')
					.style("cursor","pointer")
					.attr("cx", function(d) { return x(d.Time)})
					.attr("cy", function(d) { return y(d.Value)})
					.attr("r", dotSize)
					.style("fill", function(d) { return color(d.Name)})
					.append("title")
					.text(function(d) {
						var returnValue;
						var checkKey = ["Value", "Time", "Name"]; 
						for (var key in d) {
							if(checkKey.indexOf(key)<0){
								if(returnValue==undefined){
									if(key == "Date"){
										returnValue = 'Time : ' + timeFormat(new Date(d[key]));
									}else{
										returnValue = key + ' : ' + d[key];
									}
								}else{
									if(key == "Date"){
										returnValue = returnValue + '\n' +'Time : ' + timeFormat(new Date(d[key]));
									}else{
										returnValue = returnValue + '\n' + key + ' : ' + d[key];
									}
								}
							}
						}
						return returnValue; 
					});
					
				city.selectAll("circle").on("click", function (d) {
					if(attrs.linkstatus=="true"){
						if(Number(attrs.chartdurationtype) < (d3ChartTimeFormatForLT.length-1)){
							expressionHandler(attrs.chartdurationtype,d.Date);
						}
					}
				});
		}
	
		scope.$watch("chartdata", function(newValue, oldValue, scope) {
			if( newValue != undefined) {
				data = [];
				data = newValue;
				timeFormat = d3.time.format(attrs.xaxisformat);
				var svg = d3.select("#" + attrs.id).select("svg").remove();
					if(data.length>0){
						var dataListCount=0;
						data.forEach(function (kv) {
							if(kv.Data!=null){
								dataListCount = Number(dataListCount)+1;
							}
						});
						if(Number(dataListCount)>0){
							generateMultiLineChart();
						}else{
							noData(attrs.id,parentWidth,parentHt);
						}
					}else{
						noData(attrs.id,parentWidth,parentHt);
					}
				}
			});
			
	   });
	}};
}]);

//<appedo-bar-chart-directive-rum />
appedoApp.directive('appedoBarChartDirectiveRum',['d3Service', '$appedoUtils', 'appedoDirectiveChartUtils', function(d3Service, $appedoUtils, appedoDirectiveChartUtils){
	return {
		restrict: "AE",
		scope: {
			chartdata: '=',
			pushdata: '=',
			loadevent: '&'
			//yaxislabel: '@'
		},
		link: function(scope, element, attrs) {
			d3Service.d3().then(function(d3) {
				var data, xAxis, yAxis;
				var parentWidth;
				var rightM = 8;
				var leftM = 8;
				var dotSize;
				var lineWidth;
				if (attrs.dotsize==null || attrs.dotsize==undefined) {
					dotSize = 1.5;
				}else{
					dotSize=attrs.dotsize;
				}

				if (attrs.linewith==null || attrs.linewith==undefined) {
					lineWidth = 2;
				}else{
					lineWidth=attrs.linewith;
				}
				
				if (attrs.parrentnodeid==null || attrs.parrentnodeid=="undefined") {
					parentWidth=300;
				} else {
					parentWidth=document.getElementById(attrs.parrentnodeid).offsetWidth;
					if(parentWidth>800){
						rightM = 15;
						leftM = 3;
					}
				}
				
				var FIVE_MINUTES = 1000 * 60 * 5;
				var parentHt = 220;
				//Fixed width does not go well with responsive design hence made as percentage of parent heigth
				var margin = {top: parentHt*6/100, right: parentWidth*rightM/100, bottom: parentHt*20/100, left: parentWidth*leftM/100},
						width = parentWidth - margin.left - margin.right,
						height = parentHt - margin.top - margin.bottom, halfOfWidth = (width - margin.right) /2;
				
				//var timeFormat = d3.time.format(attrs.xaxisformat);
				var tooltipTimeFormat = d3.time.format("%Y-%b-%d %H:%M:%S");
				
				// chartdata's datum key's, color & tooltip display name; for other than health datum keys, TODO add respective key's details, in below JSON
				var KEYS_DETAILS = {
					'ok_cnt': { color: '#43a047', tooltip_display_name: 'Ok' },
					'warning_cnt': { color: '#ffc200', tooltip_display_name: 'Warning' }, 
					'critical_cnt': { color: 'red', tooltip_display_name: 'Critical' }, 
					'V': { color: '#03569a', tooltip_display_name: 'Page View(s)' } 
				};
				
				var expressionHandler = scope.loadevent();
				
				function generateBarChartAsArrayInJSONFormart() {
					var x;
					var xAxis;
//					x = d3.time.scale()
//					.domain([new Date(data[0].T), d3.time.day.offset(new Date(data[data.length - 1].T), 0)])
//					.rangeRound([0, width - margin.left - margin.right]);
					
					var y = d3.scale.linear()
								.domain([0, d3.max(data, function(d) { return d.V; })])
								.range([height - margin.top - margin.bottom, 0]);
					
					var endDateLimit = new Date();
					var startDateLimit = new Date();
					var startLimit = 0;
					var endLimit = 0;
					var colorScale = ['#03569a','#81aacc'];
					var barwidth = 10;
					var xaxisRotate = "-65";
					
					var xMin, xMax;
					
					if (attrs.slidervalue == null || attrs.slidervalue == undefined || attrs.slidervalue.length === 0 || attrs.customdatestatus == "true" ) {
						xMin = data[0].T - FIVE_MINUTES;
						xMax = data[data.length - 1].T + FIVE_MINUTES;
						/*xMin = data[0].T;
						xMax = data[data.length - 1].T;
						
						// alter minX, maxX, reduce & add 5 min 
						if ( xMin === xMax ) {
							xMin = xMin - FIVE_MINUTES;
							xMax = xMax + FIVE_MINUTES;
						}*/
						timeFormat = d3.time.format( appedoDirectiveChartUtils.getD3BarChartXAxisTimeFormat(xMin, xMax) );
						//timeFormat = d3.time.format( attrs.xaxisformat !== undefined ? attrs.xaxisformat : appedoDirectiveChartUtils.getD3BarChartXAxisTimeFormat(xMin, xMax) );
						
						// ASK default xMax; instead of `d3.time.day.offset(<DateTime>, 1)`, increases +1 day with the given time
						
						x = d3.time.scale()
								//.domain([new Date(xMin), d3.time.day.offset(new Date(xMax), 1)])
								//.domain([new Date(xMin), d3.time.minute.offset(new Date(xMax), 5)])
								.domain([new Date(xMin), new Date(xMax)])
								.rangeRound([0, width - margin.left - margin.right]);
						
						xAxis = d3.svg.axis()
									.scale(x)
									.orient('bottom')
									.tickFormat(timeFormat);
									//.tickSize(0)
									//.tickPadding(5);
					} else {
						var now = new Date();
						xMax = now.getTime();
						xMin = $appedoUtils.getTimeInMillsBeforeSpecifiedInterval(xMax, attrs.slidervalue);
						
						/*
						 * since, chartdata plot's point is beyond OR after, 
						 * the browser time based on slider hrs. OR datepicker, set the chartdata point's min/max
						 * 
						 * xMin is NaN, for `attrs.slidervalue` not present in JSON `$appedoUtils.getTimeInMillsBeforeSpecifiedInterval`
						 */
						if ( isNaN(xMin) || xMin > data[0].T ) {
							xMin = data[0].T;
						}
						if ( xMax < data[data.length - 1].T ) {
							xMax = data[data.length - 1].T;
						}
						// alter minX, maxX, reduce & add 5 min 
						if ( xMin === xMax ) {
							xMin = xMin - FIVE_MINUTES;
							xMax = xMax + FIVE_MINUTES;
						}
						timeFormat = d3.time.format( appedoDirectiveChartUtils.getD3BarChartXAxisTimeFormat(xMin, xMax) );
						
						x = d3.time.scale()
								.domain([new Date(xMin), d3.time.minute.offset(new Date(xMax), 0)])
								.rangeRound([0, width - margin.left - margin.right]);
						
						xAxis = d3.svg.axis()
									.scale(x)
									.orient('bottom')
									/* tickSize, to have bottom small bottom line below x-axis, between x-axis and tickpoint */
									.tickSize(0)
									.tickFormat(timeFormat);
						
						if (attrs.slidervalue == "1 hour"){
							xAxis.ticks(d3.time.minutes, 5)
								.tickPadding(5);
						} else if (attrs.slidervalue == "1 day") {
							xAxis.ticks(d3.time.hours, 1)
								.tickPadding(5);
						} else if(attrs.slidervalue == "7 days") {
							xAxis.ticks(d3.time.days, 1)
								.tickPadding(25);	
						} else if (attrs.slidervalue == "15 days") {
							xAxis.ticks(d3.time.days, 1)
								.tickPadding(15);
						} else if(attrs.slidervalue == "30 days") {
							xAxis.ticks(d3.time.days, 1)
								.tickPadding(8);
						} else if(attrs.slidervalue == "60 days") {
							xAxis.ticks(d3.time.days, 2)
								.tickPadding(8);
						} else if(attrs.slidervalue == "120 days") {
							barwidth = 5;
							
							xAxis.ticks(d3.time.days, 4)
								.tickPadding(8);
						} else {
							xAxis.ticks(8)
								.tickPadding(5);	
						}
					}
					var yAxis = d3.svg.axis()
									.scale(y)
									.orient('left')
									.tickPadding(8);
					
					// ploting bar color
					var color = d3.scale.ordinal();
					
					// keys for stacked barchart
					var aryKeys = d3.keys(data[0]).filter(function(key) { return key !== "T" && key !== "V"; });
					// sets bar color for, default single bar chart OR stacked bar chart
					if ( aryKeys.length === 0 ) {
						// default bar chart 
						
						// plot color
						color.domain(['V'])
							.range([ KEYS_DETAILS.V.color ]);
					} else {
						// health wise, stacked bar chart 
						
						var aryPlotRange = [];
						// adds colors for respective datum keys
						for (var i = 0; i < aryKeys.length; i = i + 1) {
							var key = aryKeys[i];
							aryPlotRange.push(KEYS_DETAILS[key].color);
						}
						
						// plot color 
						color.domain(aryKeys)
							.range(aryPlotRange);
					}
					// bars to have based on `color` scale
					data.forEach(function(d, i) {
						var y0 = 0;
						d.health = color.domain().map(function(code) {
							return {
								name: code,
								y0: y0,
								y1: y0 += (+d[code] || 0)
							};
						});
					});
					
					var svg = d3.select("#" + attrs.id).append("svg")
								.attr("width", width + margin.left + margin.right)
								.attr("height", height + margin.top + margin.bottom)
								.append("g")
								.attr("transform","translate(" + margin.left * 3 / 2+ "," + margin.top + ")");
					
					svg.append("g")
						.attr("class", "x axis")
						.attr("transform", "translate(0," + (height - margin.top - margin.bottom) + ")")
						.call(xAxis)
						.selectAll("text")
						.style("text-anchor", "end")
						.attr("dx", "-.8em")
						.attr("dy", ".15em")
						.attr("transform", "rotate("+xaxisRotate+")" );
					
					svg.append("g")
						.attr("class", "y axis")
						.call(yAxis);
					
					// tooltip
					var tooltip = d3.select("body")
									.append("div")
									.attr("class", "apd-chart-tooltip rum-bar-chart-tooltip")
									.style("opacity", 1e-6);
					
					var bar = svg.selectAll(".bar")
								.data(data)
								.enter().append("g")
								.attr("class", "g")
								.on("click", function(d) {
									// loads fn.
									if ( expressionHandler !== undefined ) {
										expressionHandler(d);	
									}
								})
								.on("mouseover", function(d) {
									/*var xPos = parseFloat(d3.select(this).attr("x"));
									var yPos = parseFloat(d3.select(this).attr("y"));*/
									
									var aryDomain = color.domain();
									// formats, tooltip text
									var toolTipText = 'Time: '+tooltipTimeFormat(new Date(d.T))+'<BR>Page View(s): '+d.V;
									for(var i = 0; i < aryDomain.length; i = i + 1) {
										if ( aryDomain[i] !== 'V' && d[aryDomain[i]] !== undefined && d[aryDomain[i]] > 0 ) {
											toolTipText += '<BR>'+KEYS_DETAILS[aryDomain[i]].tooltip_display_name+': '+d[aryDomain[i]];
										}
									}
									
									// for highlight
									d3.select(this)
										.style("opacity", 0.65);
									
									// tooltip shown 
									// after `transition`, attribute `style` or `...tween` only works, if `.html(toolTipText)` presents error throws; thinks 
									tooltip	.html(toolTipText)
											.style("top", (d3.event.pageY - 10)+"px")
											.style("left", (d3.event.pageX + 10)+"px")
											.transition()
											.duration(200)
											/* after transistion, position added `div` moves as animation
											.style("top", (d3.event.pageY - 10)+"px")
											.style("left", (d3.event.pageX + 10)+"px")*/
											.style("opacity", 0.8);
								})
								.on("mouseout", function(d) {
									// reset highlight
									d3.select(this)
										.style("opacity", 1);
									
									// hides tooltip 
									tooltip	.transition()
											.duration(200)
											.style("opacity", 1e-6);
								})
								.attr("transform", function(d) { return "translate(" + x(new Date(d.T)) + ",0)"; });
					// plots single or stacked bar chart
					bar.selectAll("rect")
						.data(function(d) { return d.health; })
						.enter().append("rect")
						.attr("width", barwidth)
						.attr("y", function(d) { return y(d.y1); })
						.attr("height", function(d) { return y(d.y0) - y(d.y1); })
						.style("fill", function(d) { return color(d.name); });
					
					
					/* old bar single bar chart
					svg.selectAll(".bar")
						.data(data)
						.enter().append("rect")
						.style("cursor", "pointer")
						.style("fill", function(d,i){ return colorScale[i%2]; })
						.on("mouseover", function(d) {
							// highlight on mouse over
							d3.select(this)
								.style("fill", "red")
								.append("title")
								.text(function(d) {
									return titleDateTimeDesc+' : '+timeFormat(new Date(d.T))+'\nPage View(s) : '+d.V; 
									// return 'Page View(s) : '+d.V; 
								});
						})
						.on("mouseout", function(d,i) {
							// un-highlight on mouse over 
							d3.select(this)
								.style("fill", colorScale[i%2]);
						})
						.attr("x", function(d) { return x(new Date(d.T)); })
						.attr("width", barwidth)
						.attr("y", function(d) { return height - margin.top - margin.bottom - (height - margin.top - margin.bottom - y(d.V)) })
						.attr("height", function(d) { return height - margin.top - margin.bottom - y(d.V) });*/
				}
				
				scope.$watch("chartdata", function(newValue, oldValue, scope) {
					if( newValue != undefined) {
						data = [];
						data = newValue;
						//timeFormat = d3.time.format(attrs.xaxisformat);
						var svg = d3.select("#" + attrs.id).select("svg").remove();
						if(data.length>0){
							generateBarChartAsArrayInJSONFormart();
						}else{
							noData(attrs.id,parentWidth,parentHt);
						}
					}
				});
				
				scope.$on('$destroy', function() {
					/*
					 * removes `tooltip` on destory, 
					 * since in service map health dashboard page, while tooltip showing, 
					 *   click on the chart navigates to RUM details page & tooltip is not hidded,
					 *   so added on destory removes `tooltip` 
					 */
					d3.selectAll(".rum-bar-chart-tooltip").remove();
				});
			});
		}
	};
}]);

