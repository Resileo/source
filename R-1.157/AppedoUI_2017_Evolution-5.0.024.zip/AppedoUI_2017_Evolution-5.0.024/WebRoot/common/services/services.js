appedoApp.service('loginServices', ['$http', '$state', '$location', '$q',function($http, $state, $location, $q){
	
	this.validateLoginUser = function(){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'isSessionExist',
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};
	
	this.validateLoginUsers = function () {
		$http({
			method: 'GET',
			url: 'isSessionExist',
		}).success(function(data) {
			if(data.success){
				$state.transitionTo('/loginResponse');
			}else{
				if( $location.path() == '/login_downtime_restrictedAccess' ) {
					$state.transitionTo('/login_downtime_restrictedAccess');
				}else{
					$state.transitionTo('/login');
				}
			}
		});
	};
}]);


appedoApp.service('userServices', ['$http', '$q', function($http, $q){
	
	this.getCountryCodeDetails = function(callbackFn) {
		$http({
			method: 'POST',
			url: './customize/getCountryCodeDetails'
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	this.getMyProfileDetails = function($scope, callbackFn) {
		$http({
			method: 'POST',
			url: './getMyProfileDetails'
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	this.updateProfile = function(userProfileData, callbackFn) {
		$http({
			method: 'POST',
			url: './updateMyProfile',
			params: {
				emailId: userProfileData.emailId,
				firstName: userProfileData.firstName,
				lastName: userProfileData.lastName,
				phoneNo: userProfileData.mobile
			}
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	this.changePassword = function(userPasswordDetails, callbackFn) {
		$http({
			method: 'POST',
			url: './changePassword',
			params: {
				oldPassword: userPasswordDetails.oldPassword,
				newPassword: userPasswordDetails.newPassword,
				retypePassword: userPasswordDetails.retypePassword
			}
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	this.getIsAdmin = function(){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './isAdmin',
		}).success(deferredObject.resolve)
		   .error(deferredObject.resolve);
	
			return deferredObject.promise;
	};
			
	this.signOut = function() {
		window.location.href = './logoutSession';
	};
	
	this.getLoginUserDetails = function(callbackFn) {
	
		$http({
			method: 'POST',
			url: './getLoginUserDetails'
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	this.getEnterpriseLicense = function(callbackFn) {
		
		$http({
			method: 'POST',
			url: './getEnterpriseLicense'
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	this.isExistedUser = function(emailId, callbackFn) {
	
		$http({
			method: 'POST',
			url: './isExistedUser',
			params: {
				emailId: emailId
			}
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	this.resendEmailVerification = function(emailId, callbackFn) {
		$http({
			method: 'POST',
			url: './resendEmailVerfication',
			params: {
				emailId: emailId
			}
		}).success(function(response) {
			if(callbackFn instanceof Function) {
				callbackFn(response);
			}
		});
	};
	
	
	this.isExistedUser_Deferred = function(emailId){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './isExistedUser',
			params: {
				emailId: emailId
			}
		}).success(deferredObject.resolve)
		   .error(deferredObject.resolve);
	
		return deferredObject.promise;
	};
	
	this.uploadJmeterScript = function($scope, elem, url, callback) {//elem
		var files = elem.files;
		var formData = new FormData();
		
		for(var i = 0; i < files.length; i = i + 1) {
			formData.append('file_'+i, files[i]);
		}
		formData.append('upload_file_count', files.length);
		$http.post(url, formData, {
			transformRequest: angular.identity,
			headers: {'Content-Type': undefined },
		}).success(function(data, status){

				if(callback instanceof Function){
					callback(data);
				}
			
		}).error(function(data, status){
		});
	};
	
}]);

appedoApp.service('cardDetailsServices', ['$http', '$q', '$uibModal', 'sessionServices', function($http, $q, $uibModal, sessionServices){

	this.getModulesOptions = function( joUserDetails ) {
		var aryModuleOptions = [
		                        { id: 0, name: "OAD", value: "�peratingSyatem,Application,DataBase",displayName:"OAD", module_type: "OAD" },
		                        { id: 1, name: "Operating System", value: "OperatingSyatem",displayName:"SERVER", module_type: "OAD" },
		                        { id: 2, name: "Application", value: "Application",displayName:"APPLICATION", module_type: "OAD" },
		                        { id: 3, name: "DataBase", value: "DataBase",displayName:"DATABASE", module_type: "OAD" },
		                        { id: 4, name: "RUM", value: "RUM",displayName:"RUM", module_type: "RUM" },
		                        { id: 5, name: "LOG", value: "LOG",displayName:"LOG", module_type: "LOG" },
		                        { id: 6, name: "SUM", value: "SUM",displayName:"SUM", module_type: "SUM" },
		                        { id: 7, name: "Avl Monitoring", value: "Available Monitoring",displayName:"AVAILABILITY", module_type: "AVM" },
		                        { id: 8, name: "Avl Location", value: "Available Location",displayName:"Avl Location", module_type: "AVM" },
		                        { id: 9, name: "Service Map", value: "Service Map",displayName:"Service Map", module_type: "ServiceMap" },
		                        { id: 10, name: "Alert User", value: "Alert User",displayName:"Alert-User", module_type: "Alert" },
		                        { id: 11, name: "Alert System", value: "Alert System",displayName:"Alert-System", module_type: "Alert" },
		                        { id: 12, name: "Alert SUM", value: "Alert SUM",displayName:"Alert-SUM", module_type: "Alert" },
		                        { id: 13, name: "Alert RUM", value: "Alert RUM",displayName:"Alert-RUM", module_type: "Alert" }
		                        ];

		// for paid User, LT is added
		// Note: added LT at specific position, since to have module in the respective order)
		if( joUserDetails.License !== 'level0') {
			aryModuleOptions.splice(14, 0, { id: 14, name: "LT Scripts", value: "LoadTest Scripts",displayName:"AppedoLT Script", module_type: "LT" });
			aryModuleOptions.splice(15, 0, { id: 15, name: "LT Scenarios", value: "LoadTest Scenarios",displayName:"AppedoLT Scenario", module_type: "LT" });
			aryModuleOptions.splice(16, 0, { id: 16, name: "LT Variables", value: "LoadTest Variables",displayName:"AppedoLT Variables", module_type: "LT" });
		}
		
		if( joUserDetails.License == 'level3') {
			aryModuleOptions.splice(17, 0, { id: 17, name: "Enterprise", value: "Enterprise",displayName:"Enterprise", module_type: "Enterprise" });
		}
		
		return aryModuleOptions;
	};
	
	this.getCardData = function(callBackFn) {
		$http({
			method: 'POST',
			url: 'common/data/moduleDetails.json'
		}).success(function(resp) {
			if(callBackFn instanceof Function){
				callBackFn(resp);
			};
		});
	};
	
	this.getCardData1 = function(callBackFn) {
		$http({
			method: 'POST',
			url: 'common/data/moduleDetails1.json'
		}).success(function(resp) {
			if(callBackFn instanceof Function){
				callBackFn(resp);
			};
		});
	};
	
	this.setAsDefaultInCard = function($scope, moduleTypeName, callback) {
		$http({
			method: 'POST',
			url: 'apm/setAsDefaultInCard',
			params: {
				moduleType: moduleTypeName,
			}				
		}).success(function(cardData) {
			if(callback instanceof Function){
				callback(cardData);
			};
		});
	};
	
	this.populateCardData = function($scope, moduleTypeName, enterpriseData, callback) {
		var url = '';
		var isSystem = '';
		var moduleCode = '';
		if(moduleTypeName == 'Avl Monitoring') {
			url = './avm/getAVMUserTests';
		}else if(moduleTypeName == 'Avl Location') {
			url = './avm/getUserLocations';
		}else if(moduleTypeName == 'LT Scripts'){
			url = 'lt/getLTScripts';
		}else if(moduleTypeName == 'LT Scenarios'){
			url = 'lt/getLTScenarios';
		}else if(moduleTypeName == 'LT Variables') {
			url = './lt/getLTDataFiles';
		}else if(moduleTypeName == 'Service Map') {
			url = './service/getUserServiceMapsWithMapCountDetails_v1';
		}else if(moduleTypeName == 'Alert User' || moduleTypeName == 'Alert System' || moduleTypeName == 'Alert SUM' || moduleTypeName == 'Alert RUM') {
			url = 'sla/getSLAsCardLayout';
			isSystem = moduleTypeName==='Alert User'?false:true;
			moduleCode = (moduleTypeName === 'Alert SUM' || moduleTypeName === 'Alert RUM' ? moduleTypeName.substring(moduleTypeName.length-3,moduleTypeName.length) : 'ASD');
		}else{
			url = 'apm/getModulesData';
		}
		$scope.appcardscontent={};
		$http({
			method: 'POST',
			//url: 'apm/getModulesData',
			url: url,
			params: {
				moduleType: moduleTypeName,
				pageLimit: 10,
				pageOffset: 0,
				isSystem: isSystem,
				moduleCode: moduleCode,
				e_data: enterpriseData
				// testTypeScript: 'APPEDO_LT',
			}				
		}).success(function(cardData) {
			if(callback instanceof Function){
				callback(cardData);
			};
		});	
	};
	
	this.enableOrDisableSLAPolicy = function($scope, slaId, activePolicy, callback) {
		$http({
			method: 'POST',
			url: 'sla/enableOrDisableSLAPolicy',
			params: {
				slaId: slaId,
				activePolicy: activePolicy
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.openAddorEditSLAPolicy = function(isFrom, joSLAPolicyDetails, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/add_sla_policy.html',
			controller: 'addSlaPolicyController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				slaPolicyFormData: function() {
					return joSLAPolicyDetails;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	
	this.deleteSLAPolicy = function($scope, slaId, callback){
		$http({
			method: 'POST',
			url: 'sla/deleteSLAPolicy',	
			params: {	
				slaId: slaId
			}				
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	// has mapped counters for particular SLA, add/edit mapped counters
	this.openSLAViewMappedCounters = function(isFrom, joSLAPolicyDetails, nSLAId) {
		var modalInstance = $uibModal.open({
			// templateUrl: 'modules/sla/view/sla_policy_map_counter.html',
			// controller: 'slaPolicyMapCounter',
			templateUrl: 'common/views/sla/sla_policy_view_map_counter.html',
			controller: 'slaPolicyViewMapCounter',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				slaPolicyDetails: function() {
					return joSLAPolicyDetails;
				},
				slaId: function() {
					return nSLAId;
				}
			}
		});
	};
	
	// has mapped User for particular Enterprise, add/edit mapped User
	this.openEnterpriseViewMappedUser = function(isFrom, joEnterpriseUserDetails, e_Id) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/enterprise/view_user_mapping.html',
			controller: 'enterpriseViewMapUser',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				enterpriseUserDetails: function() {
					return joEnterpriseUserDetails;
				},
				e_Id: function() {
					return e_Id;
				}
			}
		});
	};
	
	this.getSLAAlerLog = function($scope, slaId, offSetValue, limit, callback) {	
		$http({
			method: 'POST',
			url: 'sla/getSlaAlertCardLayout',	
			params: {	
				slaid: slaId,
				limit: limit,
				offset: offSetValue,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}				
		}).success(function(slaSlaveCardData) {
			if(callback instanceof Function){
				callback(slaSlaveCardData);
			};
		});	
	};
	
	
	this.getSLAGrid = function($scope, bSystem, moduleCode, callback) {
		$http({
			method: 'POST',
			url: 'sla/getSLAsCardLayout',	
			params: {
				isSystem: bSystem,
				moduleCode: moduleCode
				/*
				moduleType: moduleType,
				pageLimit: 10,
				pageOffset: 0,
				*/
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});	
	};

	
	this.getUrlDownStatus = function($scope, callback) {
		$http({
			method: 'POST',
			url: './avm/getUrlDownLocations',			
		}).success(function(cardAvailableData) {
			if(callback instanceof Function){
				callback(cardAvailableData);
			};
		});	
	};
	
	this.getModuleCounterDataAndAgentStatusService = function(jsonObj) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getModuleCounterData',
			//headers: {'Content-Type': 'application/json'},
			data: { moduleCounter: JSON.stringify(jsonObj).replace(/\"/g,'\'') }
		  }).success(deferredObject.resolve)
		   .error(deferredObject.resolve);

		return deferredObject.promise;
	};
	
	this.populateCardAvailableData = function($scope, uid, callback) {
		$scope.appcardscontent={};
		$http({
			method: 'POST',
			url: 'apm/getModulesAvailableData',	
			params: {	
				uid: uid,
			}				
		}).success(function(cardAvailableData) {
			if(callback instanceof Function){
				callback(cardAvailableData);
			};
		});	
	};
	
	this.getLogStatusReport = function($scope, uid, callback) {
		$http({
			method: 'POST',
			url: 'apm/getLogRunningStatus',	
			params: {	
				uid: uid,
			}				
		}).success(function(Response) {
			if(callback instanceof Function){
				callback(Response);
			};
		});
	};
	
	this.updateOADModule = function ($scope, joValCard, callback) {
		var url = '', params = {};
		if(joValCard.col_1.var4 == "Service Map") {
			url = './service/updateServiceMap_v1';
			params = {
					serviceMapId: joValCard.serviceMapId,
					serviceName: joValCard.col_2.var1,
					serviceDescription: joValCard.col_3.var1,
					updateServiceMapDetails: false,
					e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			};
		}else if(joValCard.col_1.var4 == "Enterprise"){
			url = 'apm/updateEnterpriseModule';
			params = {
					e_id: joValCard.e_id,
					enterpriseName: joValCard.col_2.var1,
					enterpriseDescription: joValCard.col_3.var1
			};
		}else {
			url = 'apm/updateModule';
			params = {
					uid: joValCard.col_4.var3,
					guid: joValCard.col_3.var2,
					moduleName: joValCard.col_2.var1,
					moduleDescription: joValCard.col_3.var1,
					moduleType: joValCard.col_1.var4,
					e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			};
		}
		
		$http({
			method: 'POST',
			url: url,	
			params: params			
		}).success(function(responseData) {
			if(callback) {
				callback(responseData);
			}
		});	
	};

	this.getConfiguredCategories = function($scope, uid, agentVersion, callback) {
		$http({
			method: 'POST',
			url: 'apm/getCategories',
			params: {	
				uid: uid,
				agentVersion: agentVersion
			}
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.getMaxCounters = function(callBack) {
		$http({
			method: 'POST',
			url:"apm/getMaxCounters",
		}).success(function(data) {
			if(callBack instanceof Function){
				callBack(data);
			};
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.saveConfiguredCategories = function($scope, appcardcontent, selectedCounterIds, callback) {
		$http({
			method: 'POST',
			url: 'apm/updateCounters',
			params: {	
				uid: appcardcontent.col_4.var3,
				guid: appcardcontent.col_3.var2,
				moduleName: appcardcontent.col_2.var1,
				moduleCode: appcardcontent.col_1.var4,
				moduleCounters: selectedCounterIds.join()
			}
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.deleteModuleRow = function ($scope, joValCard, callback) {
		$http({
			method: 'POST',
			url: 'apm/deleteModule',	
			params: {
				moduleId: joValCard.col_4.var3, // uid
				guid: joValCard.col_3.var2,  // guid
				moduleType: joValCard.col_1.var4,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.deleteAVMLocation = function ($scope, joValCard, callback) {
		$http({
			method: 'POST',
			url: './avm/DeleteAVMUserLocations',	
			params: {
				agentId: joValCard.agentId,
				country: joValCard.country,
				state: joValCard.state,
				city: joValCard.city,
				region: joValCard.region,
				zone: joValCard.zone
				/*moduleId: joValCard.col_4.var3, // uid
				guid: joValCard.col_3.var2,  // guid
				moduleType: joValCard.col_1.var4*/ 
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	/*this.populateCardRUMPageView =  function($scope, uid, callback) {
		$scope.appcardscontent={};
		$http({
			method: 'POST',
			url: 'rum/getRUMSiteTransDetails',
		}).success(function(cardAvailableData) {
			if(callback instanceof Function){
				callback(cardAvailableData);
			};
		});	
	};*/
	
	this.getTransactionDataService = function($scope, enterpriseData) {
			var deferredObject = $q.defer();
			$http({
				method: 'POST',
				url: 'rum/getRUMSiteTransDetails',
				params: {
					e_data: enterpriseData
				}
			  }).success(deferredObject.resolve)
			   .error(deferredObject.resolve);

			return deferredObject.promise;
	};
	
	this.getJsonData = function(url, callback) {
		$http.get(url).
			success(function(data) {
				if (callback) {
					callback(data);
				}
			}).
			error(function(data) {
			  console.log("Error in Ajax Call");
			});
	};

	this.openAddorEditRUMModule = function(isFrom, moduleDescriptionContent, rumModuleData) {
		var modalInstance = $uibModal.open({
			//templateUrl: 'modules/rum/view/add_rum_module.html',
			templateUrl: 'common/views/rum/add_rum_module.html',
			controller: 'addRumController',
			size: 'lg',
			backdrop : 'static',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleDescriptionContent: function() {
					return moduleDescriptionContent;
				},
				rumModuleData: function() {
					return rumModuleData;
				}
			}
		});
	};
	
	this.getEditSumModules = function(testid, callback) {
		$http({
			method: 'POST',
			url:"./apm/getEditSUM",
			params: {
				testid: testid,
			}
		}).success(function(cardData) {
			if(callback instanceof Function){
				callback(cardData);
			};
		});
		/*.success(function(data) {
			console.info("service call!");
			console.log(data);
			if(callBack){
				callBack(data);
			};
		})
		.error(function(data) {
			console.log("Error in Ajax Call");
		});*/
	};
	
	this.deleteSumRecord = function($scope, testid, testtype, status, callback) {
		$http({
			method: 'POST',
			url: './sum/deleteSUMTest',
			params: {
				testid: testid,
				testtype : testtype,
				status : status
			}
		})
		.success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};
	
	this.deleteAVMRecord = function($scope, testid, callback) {
		$http({
			method: 'POST',
			url: './avm/deleteAVMTest',
			params: {
				testid: testid
			}
		})
		.success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};
	
	this.getEditAVMUserTests = function(testid, successCallBack) {
		$http({
			method: 'POST',
			url: './avm/getEditAVMUserTests',
				params: {
					testId: testid
				}
		})
		.success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		})
		.error(function(data) {
			console.log("Error in Ajax Call..");
		});
	};
	
	this.deleteScriptRecord = function ($scope, ltScriptData, /*loadTestType,*/ callback) {
		$http({
	        method: 'POST',
	        url: './ltScheduler/deleteScript',
	        params: {
				scriptId: ltScriptData.script_id,
				scriptName: ltScriptData.col_2.var1,
				testTypeScript: 'APPEDO_LT',
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.deleteScenarioRecord = function ($scope, scenario_id, scenarioName, callback) {
		$http({
	        method: 'POST',
	        url: './lt/deleteScenarios',
	        params: {
	        	testTypeScript: 'APPEDO_LT',
				scenarioId: scenario_id,
				scenarioName: scenarioName
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	// opens add or edit scenario/map scripts
	this.openAddorEditScenario = function(isFrom, moduleCardContent, mapScript, bOpenConfigureScenario) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/add_edit_lt.html',
			controller: 'addLTController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}, 
				ltScenarioData: function() {
					return mapScript;
				},
				openConfigureScenario: function() {
					return bOpenConfigureScenario;
				}
			}
		});
	};

	// opens configure scenario/mapped scripts for load test run 
	this.openConfigureScenario = function(isFrom, moduleCardContent, mapScript, loadTestType) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/ltrun_configure_script.html',
			controller: 'ltRunConfigureScript',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				},
				ltScenarioData: function() {
					return mapScript;
				}, 
				testTypeScript: function() {
					return loadTestType;
				}
			}
		});
	};

	this.uploadCSVFile = function($scope, elem, url, variableName, callback) {//elem
		var files = elem.files;
		var formData = new FormData();
		
		for(var i = 0; i < files.length; i = i + 1) {
			formData.append('file_'+i, files[i]);
		}
		formData.append('upload_file_count', files.length);
		formData.append('variableName', variableName);
		$http.post(url, formData, {
			transformRequest: angular.identity,
			headers: {'Content-Type': undefined },
		}).success(function(data, status){

				if(callback instanceof Function){
					callback(data);
				}
			
		}).error(function(data, status){
		});
	};
	
	this.deleteVariable = function ($scope, variableName, callback) {
		$http({
	        method: 'POST',
	        url: './lt/deleteVariable',
	        params: {
	        	variableName: variableName,
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.getLTScriptStatus = function ($scope, Script_id, callback) {
		$http({
			method: 'POST',
			url: './lt/getLTScriptStatus',
	        params: {
	        	scriptId: Script_id,
	        }
		}).success(function (Response){
			if(callback) {
				callback(Response);
			}
		});
	};
	
	this.updateVariable = function($scope, variableName, policy, startsFrom, callback) {
		$http({
	        method: 'POST',
	        url: './lt/updateVariable',
	        params: {
	        	variableName: variableName,
	        	policy: policy,
	        	startsFrom: startsFrom,
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.getUserApplicationsStatus = function(callback) {
		$http({
			method: 'POST',
			url: './avm/getUserApplicationsStatus',
			params: {
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
	        }
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.deleteServiceMapRecord = function($scope, serviceMapId, callback) {
		$http({
			method: 'POST',
			url: './service/deleteServiceMap',
			params: {
				serviceMapId: serviceMapId
			}
		}).success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};
	
	this.deleteEnterprise = function($scope, e_Id, callback) {
		$http({
			method: 'POST',
			url: 'apm/deleteEnterprise',
			params: {
				e_Id: e_Id
			}
		}).success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};
}]);

appedoApp.service('messageService', function($uibModal, $timeout){
	
	this.showSuccessMessage = function(message) {
		showMessage('success', message);
	};
	this.showInfoMessage = function(message) {
		showMessage('info', message);
	};
	this.showWarningMessage = function(message, joOption) {
		showMessage('warning', message);
	};
	this.showErrorMessage = function(message, joOption) {
		showMessage('danger', message);
	};
	
	function showMessage(mode, message) {
		var data = {
				      textAlert : message,
				      mode : mode
				    };
		$uibModal.open({
			templateUrl: 'view/alertMessageContent.html',
			controller: 'Message_controller',
			size: 'lg',
	//		backdrop : 'static'
			resolve: {
		        data: function () {
		          return data;
		        }
		      }
		});
	};
	
	this.open = function (mode, message) {
		var data = {
				      boldTextTitle: "Done",
				      textAlert : message,
				      mode : mode
				    };
		$uibModal.open({
			templateUrl: 'view/myModalContent.html',
			controller: 'Message_controller',
			size: 'lg',
//			backdrop : 'static'
			resolve: {
		        data: function () {
		          return data;
		        }
		      }
		});
	};
	
	this.loading = function (){
		$uibModal.open({
			templateUrl: 'common/views/loader.html',
			controller: 'loading_controller',
			size: 'sm',
			backdrop : 'static',
		});
	};
});

appedoApp.service('messageService01', ['ngToast', function(ngToast) {
		
	var defaultOption = {
		timeout: 3000,
		dismissOnTimeout: true,
		dismissButton: true,
		dismissOnClick: true,
		animation: 'fade',
	additionalClasses: ''
	};
	
	this.showSuccessMessage = function(message, joOption) {
		showMessage('success', message, joOption);
	};
	this.showInfoMessage = function(message, joOption) {
		showMessage('info', message, joOption);
	};
	this.showWarningMessage = function(message, joOption) {
		showMessage('warning', message, joOption);
	};
	this.showErrorMessage = function(message, joOption) {
		showMessage('danger', message, joOption);
	};
	
	function getOption(joOption) {
		var option = {
			timeout: defaultOption.timeout,
			dismissOnTimeout: defaultOption.dismissOnTimeout,
			dismissButton: defaultOption.dismissButton,
			dismissOnClick: defaultOption.dismissOnClick,
			animation: defaultOption.animation,
			additionalClasses: defaultOption.additionalClasses
		};
		if ( joOption !== undefined ) {
			for (var key in joOption) {
				option[key] = joOption[key];
			};
		};
		
		return option;
	}
	
	function showMessage(type, message, joOption) {
		console.info("create NGToast Function!");
		var option = getOption(joOption);
		
		ngToast.create({
			className: type,
			content: message,
			timeout: option.timeout,
			dismissOnTimeout: option.dismissOnTimeout,
			dismissButton: option.dismissButton,
			dismissOnClick: option.dismissOnClick,
			animation: option.animation,
			additionalClasses: option.additionalClasses
		});
	};
}]);

/*appedoApp.factory('refreshServices', ['$http', 'sessionServices', '$interval',function($http, sessionServices, $interval){
	return{
		set:function(key,value){
			return sessionStorage.setItem(key,value);
		},
		get:function(key){
			return sessionStorage.getItem(key);
		},		
		destroy:function(key){
			return sessionStorage.removeItem(key);
		}
	};
	

	this.startRefresh= function() {
		refreshTimer();
	};
	
	this.stopRefresh= function() {
		$interval.cancel(refreshTimerSet);
	};
	
	var refreshTimerSet;
	function refreshTimer() {
		var i = sessionServices.get("cardRefreshTime");
		refreshTimerSet = $interval(function(){
			 if(i===0){
				 $scope.getCardDetails();
				 //i=0;
				 $scope.refreshTime = i;
				 $interval.cancel($scope.refreshTimerSet);
			 }else{
				 $scope.refreshTime = i; 
			 }
			i--;
		},1000);
	};
	
}]);*/

appedoApp.factory('sessionServices', ['$http',function($http){
	return{
		set:function(key,value){
			return sessionStorage.setItem(key,value);
		},
		get:function(key){
			return sessionStorage.getItem(key);
		},		
		destroy:function(key){
			return sessionStorage.removeItem(key);
		}
	};
		
}]);

appedoApp.service('appedoChartsServices', ['$http', '$q', '$uibModal', 'sessionServices', function($http, $q, $uibModal, sessionServices){

	this.getChartData = function(callBackFn) {
		$http({
			method: 'POST',
			url: 'common/data/chartData.json'
		}).success(function(resp) {
			if(callBackFn instanceof Function){
				callBackFn(resp);
			};
		});
	};
	
	this.getAllMyCharts = function(callback) {
	    $http({
	        method: 'POST',
	        url: './chart/getAllMyCharts',
	        params: {
	        	e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
	        }
	    }).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
//addToMyChart
	
	this.addToMyChart = function(joChartData, myChartName, isNewMyChart, isMyChartExist, callback) {
	    $http({
	        method: 'POST',
	        url: './chart/addToMyChart',
	        params: {
	        	chartId: joChartData.chartId,
	        	moduleType: joChartData.type,
	        	refId: joChartData.refId,
	        	myChartName: myChartName,
	        	isNewMyChart: isNewMyChart,
	        	isMyChartExist: isMyChartExist,
	        	e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
	    }).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.removeFromMyChart = function(chartId, myChartName, callback) {
	    $http({
	        method: 'POST',
	        url: './chart/removeFromMyChart',
	        params: {
	        	chartId: chartId,
	        	myChartName: myChartName,
	        	e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
	    }).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.getChartIds = function(chartName, callback) {
	    $http({
	        method: 'POST',
	        url: './chart/getMyChartIds',
	        params: {
	        	chartName: chartName,
	        	e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
	    }).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.getChartVisualDataWithChartId = function(chartId, callback) {
	    $http({
	        method: 'POST',
	        url: './chart/getChartVisualDataWithChartId',
	        params: {
	        	chartId: chartId,
	        	e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
	    }).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.getChartDataPoints = function(refId, counterId, moduleType, sliderValue, startTime, endTime, metricId, xyAxisLabel, location, rumType, callback) {
	    $http({
	        method: 'POST',
	        url: './chart/getChartDataPoints',
	        params: {
	        	refId: refId,
	        	counterId: counterId,
	        	moduleType: moduleType,
	        	sliderValue: sliderValue,
	        	startTime: startTime,
	        	endTime: endTime,
	        	metricId: metricId,
	        	xyAxisLabel: xyAxisLabel,
	        	location: location,
	        	rumType: rumType,
	        	e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
	    }).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.openSLAMappedCounters = function(joChartDetail) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/view_sla_mapped_counters_chart.html',
			controller: 'slaViewMappedCountersChart',
			size: 'lg',
			resolve: {
				uid: function() {
					return joChartDetail.refId;
				},
				counterId: function() {
					return joChartDetail.counterId;
				},
				chartName: function() {
					return joChartDetail.origChartTitle;
				},
				unit: function() {
					return joChartDetail.unit;
				}
			}
		});
	};
	
	this.formatChartDataJSON = function(joCounterSummary, joRespCountersData, joChartRawData, joGraphData) {
		var graphDataLength = Object.keys(joGraphData).length;
		graphDataLength = graphDataLength + 1;
		
		var chartDataLength = 1;
		if (Array.isArray(joChartRawData.chart)) {
			// to add numbers to chart like chart1, chart2, chart3,... 
		}
		 
		joChartRawData.chartRawData.barWidth = 10;
		joChartRawData.chartRawData.data = [];
		joChartRawData.chartRawData.data = joRespCountersData.chartdata.data;
		// TODO : Array.isArray(tempArray) needed to add for more than one chart i.e graph1 : {chart1:{}, chrart2:{}}
		var joDataPoints = {};
		joDataPoints.dataPoints = {};	
		joDataPoints.dataPoints.rawdata = {};			//datapoint : {rawdata : {}}
		if (!joChartRawData.chartRawData.hasOwnProperty("unit")) {
			joChartRawData.chartRawData.unit = joCounterSummary.unit;
		}
		joDataPoints.dataPoints.rawdata = joChartRawData.chartRawData;
		if (joChartRawData.hasOwnProperty("critical"))
			{
			//TODO: add critical
			joDataPoints.datapoints.critical = {};
			}
		if (joChartRawData.hasOwnProperty("warning"))
			{
			//TODO: add warning
			joDataPoints.datapoints.warning = {};
			}
		joChartRawData.chart.dataPoints = {};
		joChartRawData.chart.dataPoints = joDataPoints.dataPoints;
		var topObject = 'graph'+graphDataLength;
		joGraphData[topObject] = {};
		//joGraphData[topObject].enableMinAvgMax = joChartRawData.chartRawData.enableMinAvgMax;
		var chartObject = 'chart'+chartDataLength;
		var temp = {};
		temp[chartObject] = joChartRawData.chart;
		joGraphData[topObject] = temp;
		joGraphData[topObject].enableMinAvgMax = joChartRawData.chartRawData.enableMinAvgMax;
		
		//console.log("complete JSON : "+JSON.stringify(joGraphData));
		
		return joGraphData;
	}
	
	this.formatChartDataJSON_v1 = function(joCounterSummary, joRespCountersData, joChartRawData, joGraphData) {
		var graphDataLength = Object.keys(joGraphData).length;
		graphDataLength = graphDataLength + 1;
		
		var chartDataLength = 1;
		if (Array.isArray(joChartRawData.chart)) {
			// to add numbers to chart like chart1, chart2, chart3,... 
		}
		var chartName = joChartRawData.chart.chartName+'-'+joChartRawData.chartRawData.legendText;
		//console.log("chartTitle : "+chartName);
		if (chartName.length > 40) {
			chartName = chartName.substr(0,38)+'...';
		}
		joChartRawData.chart.chartTitle = chartName;
		joChartRawData.chart.origChartTitle = joChartRawData.chart.chartName+'-'+joChartRawData.chartRawData.legendText;
		
		if (isNaN(joChartRawData.chart.refId) && !angular.isNumber(joChartRawData.chart.refId)) {
			var refId = joChartRawData.chart.refId.split("_");
			if (refId.length > 0) {
				joChartRawData.chart.refId = refId[refId.length - 1];
			}
		}
		if (!joChartRawData.chart.hasOwnProperty("isActive")) {
			joChartRawData.chart.isActive = false;
		}
		joChartRawData.chart.unit = joChartRawData.chartRawData.unit; 
		joChartRawData.chartRawData.data = [];
		joChartRawData.chartRawData.data = joRespCountersData.chartdata.data;
		// TODO : Array.isArray(tempArray) needed to add for more than one chart i.e graph1 : {chart1:{}, chrart2:{}}
		if (!joChartRawData.chartRawData.hasOwnProperty("unit")) {
			joChartRawData.chartRawData.unit = joCounterSummary.unit;
		}
		if (!joChartRawData.chart.hasOwnProperty("axisLabel")) {
			joChartRawData.chart.axisLabel = '-';
		}
		
		var topObject = 'graph'+graphDataLength;
		//to set unique graph id
		joChartRawData.chart.graphId = topObject;
		joGraphData[topObject] = {};
		//joGraphData[topObject].enableMinAvgMax = joChartRawData.chartRawData.enableMinAvgMax;
		var chartObject = 'chart'+chartDataLength;
		var temp = {};
		temp[chartObject] = joChartRawData.chartRawData;
		//temp[chartObject] = joChartRawData.chart;
		joGraphData[topObject] = joChartRawData.chart;
		
		joGraphData[topObject].charts = [];
		joGraphData[topObject].charts.push(temp);
		//console.log("complete JSON : "+JSON.stringify(joGraphData));
		return joGraphData;
	}
	
	this.formatChartDataJSON_v2 = function(joCounterSummary, joRespCountersData, joChartRawData, joGraphData) {
		var graphDataLength = Object.keys(joGraphData).length;
		graphDataLength = graphDataLength + 1;
		
		var eachGraphSet;
		
		var chartDataLength = 1;
		if (Array.isArray(joChartRawData.chart)) {
			// to add numbers to chart like chart1, chart2, chart3,... 
		}
		var chartName = joChartRawData.chart.chartName+'-'+joChartRawData.chartRawData.legendText;
		//console.log("chartTitle : "+chartName);
		if (chartName.length > 55) {
			chartName = chartName.substr(0,53)+'...';
		}
		joChartRawData.chart.chartTitle = chartName;
		joChartRawData.chart.origChartTitle = joChartRawData.chart.chartName+'-'+joChartRawData.chartRawData.legendText;
		joChartRawData.chartRawData.data = [];
		joChartRawData.chartRawData.data = joRespCountersData.chartdata.data;
		// TODO : Array.isArray(tempArray) needed to add for more than one chart i.e graph1 : {chart1:{}, chrart2:{}}
		if (!joChartRawData.chartRawData.hasOwnProperty("unit")) {
			joChartRawData.chartRawData.unit = joCounterSummary.unit;
		}
		if (!joChartRawData.chart.hasOwnProperty("axisLabel")) {
			joChartRawData.chart.axisLabel = '-';
		}
		var topObject = 'graph'+graphDataLength;
		//to set unique graph id
		joChartRawData.chart.graphId = topObject;
		//eachGraphSet[topObject] = {};
		//joGraphData[topObject].enableMinAvgMax = joChartRawData.chartRawData.enableMinAvgMax;
		var chartObject = 'chart'+chartDataLength;
		var temp = {};
		temp[chartObject] = joChartRawData.chartRawData;
		//temp[chartObject] = joChartRawData.chart;
		eachGraphSet = joChartRawData.chart;
		
		eachGraphSet.charts = [];
		eachGraphSet.charts.push(temp);
		//console.log("complete JSON : "+JSON.stringify(joGraphData));
		return eachGraphSet;
	}
	
	
	this.getChartDataPoints = function(refId, counterId, sliderValue, startTime, endTime, moduleType, metricId, xyAxisLabel, location, rumType) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './chart/getChartDataPoints',
			params: {
				refId: refId,
				counterId: counterId,
				moduleType: moduleType,
				sliderValue: sliderValue,
				startTime: startTime,
				endTime: endTime,
				metricId: metricId,
				xyAxisLabel: xyAxisLabel,
				location: location,
				rumType: rumType,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	
}]);

// appedo-charts directive utils fn.

appedoApp.factory('appedoDirectiveChartUtils', function(ONE_DAY_IN_MILLIS) {
var aryMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
var aryXAxisTimeFormats = ['%H : %M', '%d %b'], aryBarChartXAxisTimeFormats = ['%d %b %H:%M', '%d %b'];

return {
	months: aryMonths,
	formatDateHR: function(date) {
		// format's date to HummanReadable format (HR)
		var hours = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
		var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
		var seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
		
		//return date.getDate() +'-'+ this.months[date.getMonth()] +'-'+  date.getFullYear() +' '+ hours+':'+minutes+':'+seconds;
		// showing seconds is avoided, since group by minute
		return date.getDate() +'-'+ this.months[date.getMonth()] +'-'+  date.getFullYear() +' '+ hours+':'+minutes;
	},
	chartValueLabel: function(joDatum) {
		var strValueLabel = '';
		
		strValueLabel += joDatum.Count != undefined ? 'Count: '+joDatum.Count+'\n' : '';
		strValueLabel += joDatum.Min != undefined ? 'Min: '+joDatum.Min+'\n' : '';
		strValueLabel += joDatum.Max != undefined ? 'Max: '+joDatum.Max+'\n' : '';
		strValueLabel += joDatum.Avg != undefined ? 'Avg: '+joDatum.Avg+'\n' : '';
		
		// adds,  if jo doesn't has key `Count`, `Min`, `Max` & `Avg`
		strValueLabel += joDatum.V != undefined && strValueLabel.length === 0 ? 'Value: '+joDatum.V+'\n' : '';
		
		return strValueLabel;
	},
	//breachTypeColors: { 'Error': 'red'/*Err*/, 'Exception': '#f7b204'/*Warning*/, 'Threshold Breach': '#1b639e'/*Info*/ },
	
	// since having breach_types only `Threshold Breach` is available, not used Error & Exception, for `Threshold Breach` configured as 
	breachTypeColors: { 'CRITICAL': 'red'/*Err*/, 'WARNING': 'ORANGE'/*Warning*/, 'Threshold Breach': 'red'/*Info*/ },
	barColorsBasedOnPercentage: ['#31c0be'/*green*/, '#3182bd'/*blue*/, '#e7ba52'/*yellow*/, '#ff7f0e'/*red*/],// considered (ie, tried highest % green as starting), for profiler diff set to use.
	isDateTimeWithInOneDay: function(nTime1, nTime2) {
		return (nTime2 - nTime1) <= ONE_DAY_IN_MILLIS;
	},
	getD3XAxisTimeFormat: function(nTime1, nTime2) {
		return this.isDateTimeWithInOneDay(nTime1, nTime2) ? aryXAxisTimeFormats[0] : aryXAxisTimeFormats[1];
	},
	getD3BarChartXAxisTimeFormat: function(nTime1, nTime2) {
		return this.isDateTimeWithInOneDay(nTime1, nTime2) ? aryBarChartXAxisTimeFormats[0] : aryBarChartXAxisTimeFormats[1];
	},
	isDataArrayInArrayFormat: function(aryChartData) {
		return aryChartData[0] instanceof Array;
	},
	getXminXmaxAsArray: function(aryChartData) {
		/* gets xMin, xMax from data Array In Array, (i.e. format `[ [{T: 1462511914244, V: 0}, ...], ..., [..., {T: 1462515488947, V: 0}] ]`); 
		 * Note: data order by in ASC, based on time
		 */
		var xMin = aryChartData[0][0].T, aryLastDataSet = aryChartData[aryChartData.length - 1], xMax = aryLastDataSet[aryLastDataSet.length - 1].T;
		return [xMin, xMax];
	},
	getXminXmaxAsObject: function(aryChartData) {
		/* gets xMin, xMax from data Array In JSON, (i.e. format `[{T: 1462511914244, V: 0}, ..., {T: 1462515488947, V: 0}]` ); 
		 * Note: data order by in ASC, based on time
		 */
		return [aryChartData[0].T, aryChartData[aryChartData.length - 1].T];
	},
	getYminYmaxAsArray: function(aryChartData) {
		// gets yMin, yMax from data Array In Array, (i.e. format `[ [{T: 1462511914244, V: 0}, ...], ..., [..., {T: 1462515488947, V: 0}] ]`);
		var yMin = d3.min(aryChartData, function(aryDataSet) { return d3.min(aryDataSet, function (joDatum) { return joDatum.V; }); });
		var yMax = d3.max(aryChartData, function(aryDataSet) { return d3.max(aryDataSet, function (joDatum) { return joDatum.V; }); });
		return [yMin, yMax];
	},
	getYminYmaxAsObject: function(aryChartData) {
		// gets yMin, yMax from data Array In JSON, (i.e. format `[{T: 1462511914244, V: 0}, ..., {T: 1462515488947, V: 0}]` );
		var yMin = d3.min(aryChartData, function(joDatum) { return joDatum.V; });
		var yMax = d3.max(aryChartData, function(joDatum) { return joDatum.V; });
		return [yMin, yMax];
	},
	getYminYmaxAsArrayWCategory: function(aryChartData, yaxiscategory) {
		// gets yMin, yMax from data Array In Array, (i.e. format `[ [{T: 1462511914244, V: 0}, ...], ..., [..., {T: 1462515488947, V: 0}] ]`);
		var yMin = d3.min(aryChartData, function(aryDataSet) { return d3.min(aryDataSet, function (joDatum) { return joDatum[yaxiscategory]; }); });
		var yMax = d3.max(aryChartData, function(aryDataSet) { return d3.max(aryDataSet, function (joDatum) { return joDatum[yaxiscategory]; }); });
		return [yMin, yMax];
	},
	getYminYmaxAsObjectWCategory: function(aryChartData, yaxiscategory) {
		// gets yMin, yMax from data Array In JSON, (i.e. format `[{T: 1462511914244, V: 0}, ..., {T: 1462515488947, V: 0}]` );
		var yMin = d3.min(aryChartData, function(joDatum) { return joDatum[yaxiscategory]; });
		var yMax = d3.max(aryChartData, function(joDatum) { return joDatum[yaxiscategory]; });
		return [yMin, yMax];
	}
};
});


// appedo data value to human readable format for given unit 
appedoApp.factory('appedoDataUtils', function() {
	var aryUnits = [['B', 'Bps'], ['KB', 'KBps'], ['MB', 'MBps'], ['GB', 'GBps'], ['TB', 'TBps'], ['PB', 'PBps'], ['EB', 'EBps'], ['ZB', 'ZBps'], ['YB', 'YBps']];
	var aryTimeUnits = [
	    { unit: 'ns', conversionRate: 1000000},
		{ unit: 'ms', conversionRate: 1000 }, 
		{ unit: 'Sec', conversionRate: 60 }, 
		{ unit: 'Min', conversionRate: 60 }, 
		{ unit: 'Hrs', conversionRate: 24 }, 
		{ unit: 'Days', conversionRate: 30 }
	];
	
	
	var idx = -1, idxSub = -1;
	
	// ASK to divide unit, say Bytes = 1024, Bps = 1000
	var DEFAULT_LIMIT_SIZE = 1024;
	
	// converts size to human readable format
	function convertSizeToHumanReadableFormat(nValue, unit, bRoundOfValue) {
		
		// unit contains 
		if ( nValue > DEFAULT_LIMIT_SIZE ) {
			// say 1025 > 1024 units in 'MB' to convert as `1.0009765625 GB`
			do {
				nValue = nValue / DEFAULT_LIMIT_SIZE;
				idx = idx + 1;
				
				// to stop, if the formatted value is within the limit AND idx reaches the array size limit
			} while( nValue > DEFAULT_LIMIT_SIZE && idx < (aryUnits.length - 1) );
		} else if ( nValue < 1 && nValue !== 0 && idx > 0 ) {
			// say 0.000123 < 1 units in 'MB' to convert as `128.974848 Bytes`
			do {
				nValue = nValue * DEFAULT_LIMIT_SIZE;
				idx = idx - 1;
				
				// to stop, if the formatted value is > 1 AND idx reaches 0 of array's start limit
			} while( nValue < 1 && nValue !== 0 && idx > 0);
		}
		
		// round
		if ( bRoundOfValue ) {
			// to avoid round value added floor, say 1.5 is converted to 1
			nValue = Math.floor(nValue); 
		} else {
			// if value has first decimal, to have first two decimal places, +<number>.toFixed(2), avoid adding .00 if a <number> does not have decimal places
			nValue = +nValue.toFixed(2); 
		}
		
		// tried, Note: `idxSub` in do..while.. is not used, in array has respective order ([[Bytes, Bps], ...]) and respective `idxSub` selection at first is used 
		return [nValue, aryUnits[idx][idxSub]];
	}
	
	// converts time to human readable format
	function convertTimeToHumanReadableFormat(nValue, unit, bRoundOfValue, bSecondaryCounter) {
		var joFormattedTime = {}, formattedTime = '', formattedUnit = '', nFormattedValue = nValue;
		
		// added, since idx < (aryTimeUnits.length - 1) to avoid conversion for last limit
		if ( nValue > aryTimeUnits[idx].conversionRate && idx < (aryTimeUnits.length - 1) ) {
			do {
				// total value
				nValue = nValue / aryTimeUnits[idx].conversionRate;
				
				// to have as `days hh:min:sec`, added Math.floor 
				joFormattedTime[aryTimeUnits[idx].unit] = Math.floor(nFormattedValue % aryTimeUnits[idx].conversionRate);
				nFormattedValue = Math.floor((nFormattedValue - joFormattedTime[aryTimeUnits[idx].unit]) / aryTimeUnits[idx].conversionRate);
				
				idx = idx + 1;
				// to stop, conversion is < LIMIT and to avoid conversion for last limit, conversion till days configured to stop convert for days
			} while( nValue > aryTimeUnits[idx].conversionRate && idx < (aryTimeUnits.length - 1) );
		}
		// set last formatted value, if conversion is not done to set the repective unit value 
		joFormattedTime[aryTimeUnits[idx].unit] = nFormattedValue;
		
		// round
		if ( bRoundOfValue || bSecondaryCounter ) {
			//formattedTime = joFormattedTime[aryTimeUnits[idx].unit];
			//formattedUnit = aryTimeUnits[idx].unit;
			
			// to round value, say 1.5 is converted to 2
			nValue = Math.floor(nValue);//Math.round(nValue);
			formattedTime = nValue;
			formattedUnit = aryTimeUnits[idx].unit;
		} else {
			var formattedHrsMinSec = '', formattedYearMonDays = '', noValue = '00';
			
			// format hh:mm:sec.ms, `3` is considered in aryTimeUnits has `hh:mm:sec.ms`; since millisec not to show condition added as `i >= 1`
			for (var i = 3; i >= 0; i = i - 1) {
				var joTimeUnit = aryTimeUnits[i];
				
				if ( i !== 3 && i !== 0 ) {
					formattedHrsMinSec += ':';
				} else if ( i === 0 ) {
					if(joFormattedTime[joTimeUnit.unit]==0 || joFormattedTime[joTimeUnit.unit] === undefined){
						break;
					}
					formattedHrsMinSec += '.';
					//noValue = '0';
				}
				formattedHrsMinSec += joFormattedTime[joTimeUnit.unit] === undefined ? noValue : (joFormattedTime[joTimeUnit.unit] < 10 ? '0'+joFormattedTime[joTimeUnit.unit] : joFormattedTime[joTimeUnit.unit] );
			};
			
			// format years months days, note: we have config. to format till days
			if ( idx > 3 ) {
				// format to have years months days, i = idx from the last idx to have 
				for (var i = idx; i > 3; i = i - 1) {
					var joTimeUnit = aryTimeUnits[i];
					formattedYearMonDays += joFormattedTime[joTimeUnit.unit]+' '+joTimeUnit.unit+' ';
				};
			}
			
			formattedTime = formattedYearMonDays + formattedHrsMinSec;
			formattedUnit = '';
		}
		
		// 
		return [formattedTime, formattedUnit];
	}
	
	return {
		getHumanReadableFormat: function(nValue, unit, bRoundOfValue, bSecondaryCounter) {
			//var idx = -1, nFormattedVaule = nValue, idxSub = -1;
			var aryUnitSub = [];
			
			// convert unit in size to human readable format, selects the unit and unit's subIdx
			for (var i = 0; i < aryUnits.length; i = i + 1) {
				aryUnitSub = aryUnits[i];
				idxSub = aryUnitSub.indexOf(unit);
				//added Bytes check explicitly to pass the below condition to print Bytes as B
				if(unit == 'Bytes') {
					idxSub = 0;
				}
				if ( idxSub !== -1) {
					idx = i;
					//break;
					return convertSizeToHumanReadableFormat(nValue, unit, bRoundOfValue);
				};
			}
			
			// convert time in human readable format
			for(var i = 0; i < aryTimeUnits.length; i = i + 1) {
				var joTimeUnit = aryTimeUnits[i];
				if ( joTimeUnit.unit === unit ) {
					idx = i;
					return convertTimeToHumanReadableFormat(nValue, unit, bRoundOfValue, bSecondaryCounter);
				};
			}
			
			// no units matched with conversion
			return [nValue, unit];
		}
	};
});

appedoApp.service('appedoCommonsService', ['$http', '$q', function($http, $q) {
	
	this.getAppedoWhiteLabels = function(callback) {
		$http({
			method: 'POST',
			url: './getAppedoWhiteLabels'
		}).success(function(data) {
			if(callback instanceof Function) {
				callback(data);
			}
		});
	};
}]);

var HEADER_NAME = 'MyApp-Handle-Errors-Generically';
var specificallyHandleInProgress = false;

appedoApp.service('ajaxCallService', ['$http', 
	function($http) {
		this.getJsonData = function(url, callback) {
			$http.get(url).
				success(function(data) {
					if (callback) {
						callback(data);
					}
				}).
				error(function(data) {
				  console.log("Error in Ajax Call"+data);
				});
		};
	}
]);

appedoApp.service('moduleSelectorService', ['$http', 'sessionServices', function($http, sessionServices) {
	// In user modules options, emailIds to have SLA Action, Rule, 
	var emailIds = ["sales_test@appedo.com", "sales_test@softsmith.com"];
	
	this.populateModuleData = function($scope, callback) {
	//	alert("service..");
		$scope.moduleCardsContent={};
		$http({
			method: 'POST',
			url: 'common/data/module_content.json'
			//params: {	}
		}).success(function(moduleCardData) {
			$scope.moduleCardsContent = moduleCardData;
		});

	};
		
	this.getCounterTypes = function($scope, moduleCardContent, callBackFn) {
		$scope.moduleTypes = {};
		var url = "";
		var moduleParams = {};

		$http({
			method: 'POST',
			url: 'apm/getModuleVersions',
			params:{
				moduleName: moduleCardContent.module_name,
			}
		}).success(function(resp) {
			if(callBackFn instanceof Function){
				callBackFn(resp);
			};
		});
	};
		
	this.getCLRVersions = function($scope, callBackFn) {
		
		$http({
			method: 'POST',
			url: 'common/data/application_module_clrVersions.json'
		}).success(function(resp) {
			if(callBackFn instanceof Function){
				callBackFn(resp);
			};
		});
	};

	
	// add/edit counter for particular SLA
	this.openSLAMapToCounter = function(isFrom, joSLAPolicyDetails, joSLAActionForm, nSLAId) {
 		var modalInstance = $uibModal.open({
 			templateUrl: 'common/views/sla/sla_policy_map_counter.html',
 			controller: 'slaPolicyMapCounter',
 			size: 'lg',
 			resolve: {
 				isFrom: function() {
 					return isFrom;
 				},
 				slaPolicyDetails: function() {
					return joSLAPolicyDetails;
				},
				slaActionForm: function() {
 					return joSLAActionForm;
 				},
 				slaId: function() {
 					return nSLAId;
 				}
 			}
 		});
	};
	
	// add/edit counter for particular SLA
	this.openSLAAddAlterCounterChart = function(operation, joSLACounterDetails, chartName) {
 		var modalInstance = $uibModal.open({
 			templateUrl: 'common/views/sla/sla_add_alter_counter_chart.html',
 			controller: 'slaAddAlterCounterChart',
 			size: 'lg',
 			resolve: {
 				operation: function() {
					return operation;
				},
 				slaPolicyDetails: function() {
					return joSLACounterDetails;
				},
				chartName: function() {
					return chartName;
				}
 			}
 		});
	};

	this.saveModule = function($scope, moduleCardContent, callback) {
		$http({
			method: 'POST',
			url: 'apm/addModule',
			params: {
				moduleName: $scope.moduledata.moduleName,
				moduleDescription: $scope.moduledata.moduleDescription,
				moduleType: moduleCardContent.module_name,
				moduleVersion: $scope.moduledata.versionType.ctv_id,
				type: $scope.moduledata.selectModuleType.module_type,
				clrVersion: ($scope.moduledata.selectModuleType.module_type === 'MSIIS')?$scope.moduledata.clrVersion.clrVersionType:null,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(resultData) {
			if(callback) {
				callback(resultData);
			}
		});

	};
	
	this.checkModuleLimit = function($scope, callBackFn) {

		$http({
			method: 'POST',
			url: 'apm/checkModuleLimit'
		}).success(function(resp) {
			if(callBackFn instanceof Function){
				callBackFn(resp);
			};
		});
	};
	// To check whether the user has valid license for log view before adding in ui
	this.getLogViewLicenseDetails = function($scope, callBackFn) {

		$http({
			method: 'POST',
			url: 'log/getLogViewLicenseDetails'
		}).success(function(resp) {
			if(callBackFn instanceof Function){
				callBackFn(resp);
			};
		});
	}

	this.getModulesOptions = function( joUserDetails ) {
		var aryModuleOptions = [
			{ id: 0, name: "SUM", displayName:"User View - Synthetic", path: ["sum_metrics", "sum_details"], moduleContent: 'common/data/module_content_sum.json', title: 'Click here to create Synthetic User Monitor' },
			{ id: 1, name: "AVM", displayName:"User View - Availability", path: ["avm_metrics", "avm_details"], moduleContent: 'common/data/module_content_avm.json', title: 'Click here to create Availability Monitor' },
			{ id: 2, name: "RUM", displayName:"User View - Real", path: ["rum_metrics", "rum_details"], moduleContent: 'common/data/module_content_rum.json', title: 'Click here to create Real User Monitor' }, 
			{ id: 3, name: "OAD", displayName:"Ops View - OAD", path: ["apm_home", "apm_details", "apm_all_details"], moduleContent: 'common/data/module_content_apm.json', title: 'Click here to create monitor' }, // ignored /application, /server & /database after /apm_home 
			{ id: 4, name: "Service Map", displayName:"360 View - Service Map", path: ["service_map"], moduleContent: 'common/data/module_content_service_map.json', title: 'Click here to create Service Map' },
			{ id: 5, name: "Alerts", displayName:"Alerts", path: ["sla_home"], moduleContent: (emailIds.indexOf(joUserDetails.emailId) >= 0 ? 'common/data/module_content_sla.json' : 'common/data/module_content_sla_updated.json'), title: 'Click here to create User Policy' },
			
			/*{ id: 6, name: "Charts", displayName:"My Charts", path: ["charts_home", "chart_details"], moduleContent: 'common/data/module_content_charts.json', title: 'Create your own custom charts.' },*/
			/*{ id: 7, name: "Logs", displayName:"Logs", path: ["logHome", "log_details"], moduleContent: 'common/data/module_content_log.json', title: 'Manage your error and logs.' }*/
		];
		
		// for paid User, LT is added
		// Note: added LT at specific position, since to have module in the respective order)
		if( joUserDetails.License !== 'level0') {
			
			aryModuleOptions.splice(2, 0, { id: 7, name: "LT", displayName:"QA View - Load Test", path: ["load_test", "ltScenarioReports", "ltRunningScenarioStauts"], moduleContent: 'common/data/module_content_lt.json', title: 'Click here to map scripts' });
		}
		
		if( joUserDetails.License == 'level3') {
			aryModuleOptions.splice(7, 0, { id: 6, name: "Enterprise", displayName:"Enterprise", path: ["ent_home"], moduleContent: 'common/data/module_content_enterprise.json', title: 'Click here to create Enterprise' });
		}
		
		return aryModuleOptions;
	};
	
	// get user module options based on user in current module from URL location
	this.getModuleOptionBasedOnLocation = function(aryUserModulesOptions, currentURLLocation) {
		var joModule = {};
		for(var i = 0; i < aryUserModulesOptions.length; i = i + 1) {
			joModule = aryUserModulesOptions[i];
			if ( joModule.path.indexOf(currentURLLocation) != -1 ) {
				// break;
				return joModule;
			}
		}
	};
}]);
appedoApp.service('successMsgService', ['ngToast', 
    function(ngToast) { 
   	this.showSuccessOrErrorMsg = function (response) {
   		if(response.success == true){
   			ngToast.create({
   			className: 'success',
   			content: response.message,
   			timeout: 3000,
   			dismissOnTimeout: true,
   			dismissButton: true,
   			animation: 'fade'
   			});
   		} else {
   			ngToast.create({
   			className: 'warning',
   			content: response.errorMessage,
   			timeout: 3000,
   			dismissOnTimeout: true,
   			dismissButton: true,
   			animation: 'fade'
   			});
   		}
   	};
 }]);

appedoApp.service('ltService', ['$http', '$q', '$uibModal', function($http, $q, $uibModal) {
	/*
	this.getScenarioReportsForDropdown = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getScenarioReports',
			params: {
				dropdown : true
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};*/
	
	this.getDonutChartdata = function(type,runid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getLTDashDonut',
			params: {
				type: type,
				runid: runid
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getDashResponseArea = function(runid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getDashResponseArea',
			params: {
				runid: runid
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};

	this.getDashVUsersArea = function(runid,scenarioName) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getDashVUsersArea',
			params: {
				runid: runid,
				scenarioName: scenarioName
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};

	this.getLTLicense = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getLTLicense'
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getUserAgentDetails = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getUserAgentDetails'
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getRunningScenario = function(runId, loadTestType, successCallBack) {
		
		$http({
			method: 'POST',
			url: './lt/getScriptwiseData',
			//url: 'common/data/ltRunningScenarios.json',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getRunningScenarioForChart = function(runId, successCallBack) {
		
		$http({
			method: 'POST',
			url: './lt/getRunningScenarioForChart',
			params: {
				runid: runId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getLtScripts = function($scope, isFrom, scenarioId, successCallBack) {
		if(isFrom === "fromEdit") {
			$http({
		        method: 'POST',
		        url: './lt/editScenarios',
		        params: {
		        	testTypeScript: 'APPEDO_LT',
		        	scenarioId: scenarioId
		        }
		    }).success(function(data) {
		    	if (successCallBack instanceof Function) {
					successCallBack(data);
				}
		    });
		} else {
			$http({
		        method: 'POST',
		        url: './lt/getVUScripts',
		        params: {
		        	testTypeScript: 'APPEDO_LT'
		        }
		    }).success(function(data) {
		        if (successCallBack instanceof Function) {
					successCallBack(data);
				}
		    });
		}
	};
	
	this.deleteScenarioRecord = function ($scope, scenario_id, scenarioName, callback) {
		$http({
	        method: 'POST',
	        url: './lt/deleteScenarios',
	        params: {
	        	testTypeScript: 'APPEDO_LT',
				scenarioId: scenario_id,
				scenarioName: scenarioName
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.deleteVariable = function ($scope, variableName, callback) {
		$http({
	        method: 'POST',
	        url: './lt/deleteVariable',
	        params: {
	        	variableName: variableName,
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.updateVariable = function($scope, variableName, policy, startsFrom, callback) {
		$http({
	        method: 'POST',
	        url: './lt/updateVariable',
	        params: {
	        	variableName: variableName,
	        	policy: policy,
	        	startsFrom: startsFrom,
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	this.deleteJmeterScenarioRecord = function ($scope, scenarioId, scenarioName, testTypeScript, callback) {
		$http({
	        method: 'POST',
	        url: './ltScheduler/deleteJMeterScript',
	        params: {
	        	scenarioId: scenarioId,
	        	scenarioName: scenarioName,
	        	testTypeScript: testTypeScript
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.saveLtScripts = function ($scope, isFrom, arySelectedScriptDetails, callback) {
		  
		if(isFrom == "fromEdit") {
			$http({
			    method: 'POST',
			    url: './lt/updateScenarios',
			    params: {
			    	testTypeScript: 'APPEDO_LT',
			    	scenarioId: $scope.mapScript.scenarioId,
			    	scenarioName: $scope.mapScript.scenarioName,
			    	scriptDetails: arySelectedScriptDetails.length > 0 ? JSON.stringify(arySelectedScriptDetails) : null
			    	//scriptIds: selectedScriptsId.length>0 ? selectedScriptsId.join(): null,
			    	//scriptNames: selectedScriptnames.length>0 ? selectedScriptnames.join(): ''
			    }
			}).success(function(data) {
				if(callback){
					callback(data);
				}
			});
		} else {
			$http({
			    method: 'POST',
			    url: './lt/mappingScripts',
			    params: {
			    	testTypeScript: 'APPEDO_LT',
			    	scenarioName: $scope.mapScript.scenarioName,
			    	scriptDetails: arySelectedScriptDetails.length > 0 ? JSON.stringify(arySelectedScriptDetails) : null
			    	//scriptIds: selectedScriptsId.length>0 ? selectedScriptsId.join(): null,
			    	//scriptNames: selectedScriptnames.length>0 ? selectedScriptnames.join(): ''
			    }
			}).success(function(data) {
				if(callback){
					callback(data);
				}
			});
		}
	};
	
	this.getRunAgentMapping = function ($scope, selectedScenario, testTypeScript) {
	$scope.ltMonitorData = {};
		$http({
        method: 'POST',
        url:"./lt/getRunAgentMapping",
        params: {
        			testTypeScript: testTypeScript,
					apmGroup: 'APPLICATION,SERVER,DATABASE',
					scenarioId: selectedScenario.scenario_id
        		}
	    }).success(function(data) {
	        $scope.ltMonitors = data.message;
	        $scope.$watch('ltMonitorData.ltMonitor', function() {
	            $scope.userCities = {};
		        $scope.counters = {};
		        if ($scope.ltMonitorData.ltMonitor != undefined) {
		            if ($scope.ltMonitorData.ltMonitor.apm != undefined) {
		                $scope.agentsData = $scope.ltMonitorData.ltMonitor.agents;
		            }
		        }
	        });
	    });
	};
	
	this.getScenarioSettings = function ($scope, scenarioId, testTypeScript, callback) {
		$http({
        method: 'POST',
        url:"./lt/getScenarioSettings",
        params: {
        			testTypeScript: testTypeScript,
					scenarioId: scenarioId
        		}
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.getRunSettings = function ($scope, runId, callback) {
		$http({
        method: 'POST',
        url:"./lt/getRunSettings",
        params: {
        			runId: runId
        		}
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.updateScenarioSettings = function($scope, scriptIds, ltScenarioData, scriptNames, scriptConfigData, testTypeScript, callback) {
		var dh = $scope.ltRunSettingForm.durationHrs > 0 ? $scope.ltRunSettingForm.durationHrs : 0;
		var dm = $scope.ltRunSettingForm.durationMins > 0 ? $scope.ltRunSettingForm.durationMins : 0;
		var ds = $scope.ltRunSettingForm.durationSecs > 0 ? $scope.ltRunSettingForm.durationSecs : 0;
		var ih = $scope.ltRunSettingForm.forEveryHrs > 0 ? $scope.ltRunSettingForm.forEveryHrs : 0;
		var im = $scope.ltRunSettingForm.forEveryMins > 0 ? $scope.ltRunSettingForm.forEveryMins : 0;
		var is = $scope.ltRunSettingForm.forEverySecs > 0 ? $scope.ltRunSettingForm.forEverySecs : 0;
		var scenario_settings = {};
		scenario_settings.browsercache = $scope.ltRunSettingForm.clearBrowserCache;
		scenario_settings.durationtime = dh +";"+ dm +";"+ ds;
		scenario_settings.incrementtime = ih +";"+ im +";"+ is;
		scenario_settings.incrementuser = $scope.ltRunSettingForm.increamnetUser;
		scenario_settings.iterations = $scope.ltRunSettingForm.iterationCount > 0 ? $scope.ltRunSettingForm.iterationCount : 0;
		scenario_settings.maxuser = $scope.ltRunSettingForm.maxUserCount;
		scenario_settings.startuser = $scope.ltRunSettingForm.startUserCount;
		scenario_settings.currentloadgenid = scriptConfigData.currentloadgenid;
		scenario_settings.durationmode = scriptConfigData.durationmode;
		scenario_settings.startuserid = scriptConfigData.startuserid;
		scenario_settings.totalloadgen = scriptConfigData.totalloadgen;
		scenario_settings.parallelconnections = $scope.ltRunSettingForm.parallelconnections;
		if($scope.ltRunSettingForm.iterationDuration == "iteration") {
			scenario_settings.type = "1";
		} else {
			scenario_settings.type = "2";
		}
    	
		$http({
	        method: 'POST',
	        url:"./lt/updateScenarioSettings",
	        params: {
				testTypeScript: testTypeScript,
				scenarioId: ltScenarioData.scenario_id,
				scriptIds: scriptIds.join(),
				scenarioSettings: scenario_settings,
				scriptNames: scriptNames.join(),
				scenarioName: ltScenarioData.scenarioName
			}
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.runScenario = function ($scope, params, callback) {
		$http({
        method: 'POST',
        url:"./lt/runScenario",
        params: params
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	

	this.runJmeterScenario = function ($scope, params, callback) {
		$http({
        method: 'POST',
        url:"./ltScheduler/runScenario",
        params: params
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.agentLoadGenerator =function($scope, testTypeScript, callback) {
			$http({
			    method: 'POST',
			    url: './lt/readRegions',
			    params: {
			    	testTypeScript: testTypeScript
			    }
			}).success(function(data) {
				if(callback){
					callback(data);
				}
			});
	};

	this.getScenarios = function(successCallBack) {
		
		$http({
			method: 'POST',
			url: 'common/data/ltScenarios.json',
			params: {
				
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getScenarioReports = function(nScenarioId, loadTestType, successCallBack) {
		$http({
			method: 'POST',
			url: './lt/getScenarioReports',
			params: {
				scenarioid: nScenarioId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getselectedReportRunStartAndEndTime = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getselectedReportRunStartAndEndTime',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getselectedReportGuid = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getselectedReportGuid',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.runManualSummaryReport = function(runId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/runManualSummaryReport',
			params: {
				runid: runId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getMasterSummaryReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getMasterSummaryReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getScriptSummaryReport = function(runId, loadTestType, scriptIds, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getScriptSummaryReport',
			params: {
				runid: runId,
				scriptIds:scriptIds,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getChildSummaryReportScriptWise = function(runId, loadTestType,scriptIds,reportType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getChildSummaryReportScriptWise',
			params: {
				runid: runId,
				testTypeScript: loadTestType,
				scriptId : scriptIds,
				reportType : reportType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getSummaryReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getScriptwiseData',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getLogReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/logReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	
	this.getErrorReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/errorReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	

	this.getChartReport = function(runId, loadTestType, startTime, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/chartReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType,
				startTime : startTime
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getNewChartReport = function(runId, loadTestType, startTime, queryDuration, selectedTime, status, runTime, chartType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/chartReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType,
				startTime : startTime,
				queryDuration : queryDuration,
				selectedTime : selectedTime,
				status : status,
				runTime : runTime,
				chartType : chartType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.checkEndTimeFormatForExistingTest = function(runId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/checkEndTimeFormatForExistingTest',
			params: {
				runid: runId,
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.runEndTimeFormatForExistingTest = function(runId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/runEndTimeFormatForExistingTest',
			params: {
				runid: runId,
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.deleteScriptRecord = function ($scope, ltScriptData, loadTestType, callback) {
		$http({
	        method: 'POST',
	        url: './ltScheduler/deleteScript',
	        params: {
				scriptId: ltScriptData.script_id,
				scriptName: ltScriptData.scriptName,
				testTypeScript: loadTestType
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};


	//
	this.stopRunningScenario = function(runId, callback){
		$http({
		 	method: 'POST',
		 	url: './ltScheduler/stopRunningScenario',
		 	params:{
		 		runId: runId,
		 	}
	 	}).success(function(data, status){
	        if(callback) {
	        	callback(data);
	        }
	 	});
	};
	
	this.getModuleCountersChartdataForLoadTest = function(guid,counter_id,startTime,endTime,runTime) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getModuleCountersChartdataForLoadTest',
			params: {
				guid: guid,
				counterNames: counter_id,
				startTime: startTime,
				endTime: endTime,
				runTime : runTime
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
        return deferredObject.promise;
	};
	
	this.getNewModuleCountersChartdataForLoadTest = function(guid,counter_id,startTime,endTime,runTime,queryDuration,selectedTime,status,startMonitor,endMonitor) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getNewModuleCountersChartdataForLoadTest',
			params: {
				guid: guid,
				counterNames: counter_id,
				startTime: startTime+(startMonitor*60*1000),
				endTime: endTime+(endMonitor*60*1000),
				runTime : runTime,
				queryDuration : queryDuration,
				selectedTime : selectedTime,
				status : status,
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
        return deferredObject.promise;
	};
	
	// opens add or edit scenario/map scripts
	this.openAddorEditScenario = function(isFrom, moduleCardContent, mapScript, bOpenConfigureScenario) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/add_edit_lt.html',
			controller: 'addLTController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}, 
				ltScenarioData: function() {
					return mapScript;
				},
				openConfigureScenario: function() {
					return bOpenConfigureScenario;
				}
			}
		});
	};
	
	// opens configure scenario/mapped scripts for load test run 
	this.openConfigureScenario = function(isFrom, moduleCardContent, mapScript, loadTestType) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/ltrun_configure_script.html',
			controller: 'ltRunConfigureScript',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				},
				ltScenarioData: function() {
					return mapScript;
				}, 
				testTypeScript: function() {
					return loadTestType;
				}
			}
		});
	};
	
	this.openAddOrEditSummaryNotes = function(isFrom, joSelectedSummaryCategory, joSelectedReport, joScriptDetails, loadTestType, callbackFn) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/addEditSummaryReportNotes.html',
			controller: 'addEditSummaryReportNotesController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				selectedSummaryCategory: function() {
					return joSelectedSummaryCategory;
				},
				selectedReport: function() {
					return joSelectedReport;
				},
				selectedScript: function() {
					return joScriptDetails;
				},
				testTypeScript: function() {
					return loadTestType;
				}
			}
		});
		
		modalInstance.result.then(function (bNotesSaved) {
			// callback fn. for notes saved
			if ( bNotesSaved ) {
				if ( callbackFn instanceof Function) {
					callbackFn();
				}
			}
		});
	};
	
	this.getSummaryReportCategoryNote = function(nRunId, category, nScriptId, successCallBack) {
		$http({
			method: 'POST',
			url: './lt/getSummaryReportCategoryNote',
			params: {
				runid: nRunId,
				category: category,
				scriptId: nScriptId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.saveSummaryReportCategoryNote = function(joSummaryCategory, joReport, nScriptId, nNoteId, notes, successCallBack) {
		var url = '', joParams = {};
		
		joParams = {
			runid: joReport.reportId,
			category: joSummaryCategory.value,
			scriptId: nScriptId,
			notes: notes
		};
		
		if ( nNoteId === null ) {
			// insert
			url = './lt/insertSummaryReportCategoryNote';
		} else {
			// update
			url = './lt/updateSummaryReportCategoryNote';
			joParams.noteId = nNoteId;
		}
		
		$http({
			method: 'POST',
			url: url,
			params: joParams
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getLoadTestRunSummaryReportNotes = function(nRunId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getRunSummaryReportNotes',
			params: {
				runId: nRunId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
}]);

//appedoApp.service('apmModulesService', ['$http', '$q', 'messageService', 'apmModulesFactory', '$uibModal', function($http, $q, messageService, apmModulesFactory, $uibModal) {
appedoApp.service('apmModulesService', ['$http', '$q', 'messageService', '$uibModal','sessionServices', function($http, $q, messageService, $uibModal, sessionServices) {
	
	this.setAsDefaultDashboard = function($scope, healthCode, serviceMapId, callback) {
		$http({
			method: 'POST',
			url: 'apm/setAsDefaultDashboard',
			params: {
				healthCode: healthCode,
				serviceMapId: serviceMapId
			}				
		}).success(function(cardData) {
			if(callback instanceof Function){
				callback(cardData);
			};
		});
	};
	
	this.getUserAddedCounterModules = function(moduleCode) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getAPMDropDown',
			params: {
				moduleCode: moduleCode
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	

	this.getPrimaryCountersChartdata = function(guid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/getPrimaryCountersChartdata',
			params: {
				guid: guid
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getPrimaryCountersForAllDetailsPage = function(guid, bShowPrimaryCounters) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/getPrimaryCountersForAllDetailsPage',
			params: {
				guid: guid,
				showPrimaryCounters: bShowPrimaryCounters
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getSelectedCounterSummary = function(guid, agentVersion) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/getSelectedCounterSummary',
			params: {
				guid: guid,
				agentVersion: agentVersion
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getSecondaryCountersData = function(moduleCode,guid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getSecondaryCounter',
			params: {
				guid: guid,
				moduleCode:moduleCode
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getSecondaryCountersValues = function(moduleCode,guid,counterIds) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getSecondaryCounterValues',
			params: {
				guid: guid,
				moduleCode:moduleCode,
				counterIds:counterIds
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getModuleCountersChartdata = function(guid, counter_id, maxTimeStamp, is_above_threshold, sliderValue, startDate, endDate, bStaticCounter, nMaxValueCounterId) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/v1_getModuleCountersChartdata',
			params: {
				guid: guid,
				counterNames: counter_id,
				maxTimeStamp: maxTimeStamp,
				fromStartInterval: sliderValue,
				startDate: startDate,
				endDate: endDate,
				is_above_threshold : is_above_threshold,
				ispdf: false,
				isStaticCounter: bStaticCounter,
				maxValueCounterId: nMaxValueCounterId
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getModuleCountersChartdata_v1 = function(guid, counter_id, maxTimeStamp, is_above_threshold, sliderValue, startDate, endDate, query, defaultYAxisKey, bStaticCounter, nMaxValueCounterId) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/getModuleCountersChartdata_v1',
			params: {
				guid: guid,
				counterNames: counter_id,
				maxTimeStamp: maxTimeStamp,
				fromStartInterval: sliderValue,
				startDate: startDate,
				endDate: endDate,
				is_above_threshold : is_above_threshold,
				query : query, 
				defaultYAxisKey : defaultYAxisKey,
				isStaticCounter: bStaticCounter,
				maxValueCounterId: nMaxValueCounterId
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getModuleCountersChartdata_v2 = function(uid, counter_id, sliderValue, startDate, endDate, metricId, xyLabel) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/getModuleCountersChartdata_v1',
			params: {
				uid: uid,
				counterNames: counter_id,
				fromStartInterval: sliderValue,
				startDate: startDate,
				endDate: endDate,
				metricId : metricId, 
				xyLabel : xyLabel,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};

	this.getModuleStaticCountersData = function(guid, counterIds, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getModuleStaticCountersData',
			params: {
				guid: guid,
				counterIds: counterIds
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.getTopProcess = function(uid, counter_id, category, sliderValue, selectedTime) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/getTopProcess',
			params: {
				uid: uid,
				counter_id: counter_id,
				category: category,
				sliderValue: sliderValue,
				selectedTime : selectedTime
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};

	this.getDonutChartdata = function(moduleCode) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getAPMSummary',
			params: {
				moduleCode: moduleCode
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};
		 
	this.getAPMLicense = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getAPMLicense'
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};
	
	this.getProfilerSlowQueryData = function(guid, sliderValue, cardContentType) {
		var deferredObject = $q.defer();
		
		$http({
			method: 'POST',
			url: './apm/getSlowQuery',
			params: {
				guid: guid,
				fromStartInterval: sliderValue
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getDatabaseSlowQueryData = function(guid, sliderValue, cardContentType) {
		var deferredObject = $q.defer();
		
		$http({
			method: 'POST',
			url: './apm/getDatabaseSlowQuery',
			params: {
				guid: guid,
				fromStartInterval: sliderValue,
				databaseType: cardContentType
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	
	this.getProfilerSlowQueryDataWithDateRange = function(guid, startDate, endDate, cardContentType) {
		var deferredObject = $q.defer();
		
		$http({
		method: 'POST',
		url: './apm/getSlowQueryWithDateRange',
		params: {
			guid: guid,
			startDate: startDate,
			endDate: endDate
		}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getDatabaseSlowQueryDataWithDateRange = function(guid, startDate, endDate, cardContentType) {
		var deferredObject = $q.defer();
		
		$http({
			method: 'POST',
			url: './apm/getDatabaseSlowQueryWithDateRange',
			params: {
				guid: guid,
				startDate: startDate,
				endDate: endDate,
				databaseType: cardContentType
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getSlowProcedureData = function(guid,sliderValue, cardContentType) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getDatabaseSlowProcedure',
			params: {
				guid: guid,
				fromStartInterval: sliderValue,
				databaseType: cardContentType
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSlowProcedureDataWithDateRange = function(guid, startDate,endDate, cardContentType) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/getDatabaseSlowProcedureWithDateRange',
			params: {
				guid: guid,
				startDate: startDate,
				endDate: endDate,
				databaseType: cardContentType
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getProfilerTransactions = function (guid, counterTypeName, fromStartInterval, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getProfilerTransactions',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				fromStartInterval: fromStartInterval
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.getProfilerTransactionsWithDateRange = function (guid, counterTypeName, startDate, endDate, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getProfilerTransactionsWithDateRange',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				startDate: startDate,
				endDate: endDate
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.getKeyProfilerTransactions = function (guid, counterTypeName, fromStartInterval, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getKeyProfilerTransactions',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				fromStartInterval: fromStartInterval
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.getKeyProfilerTransactionsWithDateRange = function (guid, counterTypeName, startDate, endDate, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getKeyProfilerTransactionsWithDateRange',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				startDate: startDate,
				endDate: endDate
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.getProfilerTransactionTimeTaken = function (guid, counterTypeName, localhost_name_ip, transactionType, transactionName, fromStartInterval, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getProfilerTransactionTimeTaken',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				localhost_name_ip: localhost_name_ip,
				transactionType: transactionType,
				transactionName: transactionName,
				fromStartInterval: fromStartInterval
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.getProfilerTransactionTimeTakenWithDateRange = function (guid, counterTypeName, localhost_name_ip, transactionType, transactionName, startDate, endDate, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getProfilerTransactionTimeTakenWithDateRange',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				localhost_name_ip: localhost_name_ip,
				transactionType: transactionType,
				transactionName: transactionName,
				startDate: startDate,
				endDate: endDate
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.getProfilerMethodTrace = function (guid, counterTypeName, localhost_name_ip, transactionType, transactionName, time, duration, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getProfilerMethods',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				localhost_name_ip: localhost_name_ip,
				transactionType: transactionType,
				transactionName: transactionName,
				time: time,
				duration: duration
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.getProfilerTimeTakenMethods = function (guid, counterTypeName, localhost_name_ip, transactionType, transactionName, time, duration, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getProfilerTimeTakenMethods',
			params: {
				guid: guid,
				counterTypeName: counterTypeName,
				localhost_name_ip: localhost_name_ip,
				transactionType: transactionType,
				transactionName: transactionName,
				time: time,
				duration: duration
			}				
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.addChartToDashboard = function(guid,counterid) {
		
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/updateChartStausForDashboard',
			params: {
				guid: guid,
				counterid : counterid,
				status : true
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.removeChartToDashboard = function(guid,counterid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/updateChartStausForDashboard',
			params: {
				guid: guid,
				counterid : counterid,
				status : false
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.updateApmKeyTransaction = function ($scope, transaction, status, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/updateApmKeyTransaction',	
			params: {	
				guid: transaction.guid,
				uri: transaction.transactionName,
				keyTransactionId: transaction.keyTransactionId,
				keyTransactionName: transaction.keyTransactionName,
				keyTransactionDescription: transaction.keyTransactionDescription,
				status : status
			}				
		}).success(function(responseData) {
			if(callback) {
				callback(responseData);
			}
		});
	};
	

	this.downloadProfiler = function(joModule) {
		window.open('./apm/downloadAgent?downloadtype=profiler&type='+joModule.type+'&guid='+joModule.guid+'&modulename='+joModule.moduleName+(joModule.type === 'MSIIS' ?'&clrVersion='+joModule.clrVersion:''));
	};
	
	// opens download window 
	this.openDownloadWindow = function(moduleDownloadData, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/oad/download_module.html',
			controller: 'download_form_controller',
			size: 'lg',
			backdrop: 'static',
			resolve: {/*
				moduleAddData: function() {
					return moduledata;
				},*/
				moduleDownloadData: function() {
					return moduleDownloadData;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	
	
	this.getModuleCountersBreaches = function($scope, guid, slaIdsForAnalytics, counterIds, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getModuleCountersBreaches',	
			params: {	
				guid: guid,
				counterIds: counterIds,
				slaIdsForAnalytics: slaIdsForAnalytics,
				fromStartInterval: '1 hour'
			}				
		}).success(function(resp) {
			if(callback instanceof Function) {
				callback(resp);
			}
		});
	};
	
	
	// gets primary counters chartdata with breaches for particular module's guid
	this.getPrimaryCountersChartdataWithBreaches = function($scope, guid, callback) {
		$http({
			method: 'POST',
			url: './apmCounters/getPrimaryCountersChartdataWithBreaches',	
			params: {
				guid: guid
			}				
		}).success(function(resp) {
			if(callback instanceof Function) {
				callback(resp);
			}
		});
	};
	
	// for `apmDashboardAnalyticsController` sets the resp ChartData in selected module 
	this.setSelectedModuleChartData = function($scope, respGUID, joModuleCodesActiveModules, aryRespChartData, callback) {
		
		// sets the resp chartdata in the selected module's guid matches with respGUID
		for ( var keyModuleCode in joModuleCodesActiveModules ) {
			var joModule = joModuleCodesActiveModules[keyModuleCode];// || {};
			
			var joSelectedModuleDetails = joModule.selectedModule || {};
			if ( joSelectedModuleDetails.guid === respGUID ) {
				var aryChartData = joSelectedModuleDetails['chartdata'] || [];
				
				if ( aryChartData.length > 0 ) {
					// tried for second time refresh 
					
					// TODO: slice and push, if use of maxTimestamp
					
					/*
					 * tried, for second resp/refresh same service `./getPrimaryCountersChartdataWithBreaches` called,
					 *   the `aryChartData`'s and resp `aryRespChartData`'s respective counter's order thinks wont change,  
					 *   
					 */
					for (var i = 0; i < aryChartData.length; i = i + 1) {
						var joCounterDetails = aryChartData[i];
						
						// tried, since order not change, avoid for loop `aryChartData` inside for loop of `aryRespChartData`, used i's index of `aryRespChartData`
						var joRespCounterDetails = aryRespChartData[i];

						joCounterDetails.breaches = joRespCounterDetails.breaches;
						joCounterDetails.data = [ joRespCounterDetails.counterData ];
					}
				} else {
					// tried for first time resp,
					
					// changes `counterData` to `data` as desired format for chart
					aryChartData = apmModulesFactory.setChartConfigUtilsAndChangeDataDirFormat(aryRespChartData);
				}
				joSelectedModuleDetails['chartdata'] = aryChartData;
				
				// callbackFn
				if ( callback instanceof Function ) {
					callback(aryChartData);
				}
				break;
			}
		}
	};
	
	this.removeCounterFromMonitor = function(uid, counterId) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apm/removeCounterFromMonitor',
			params: {
				uid: uid,
				counterId : counterId
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getBreachedCountersDataForHotspot = function(sliderValue,startDateTime,endDateTime) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './apmCounters/getBreachedCountersDataForHotspot',
			params: {
				sliderValue: sliderValue,
				startDateTime : startDateTime,
				endDateTime : endDateTime
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getBreachedCountersForHotspot = function(interval, nCustomStartDateTime, nCustomEndDateTime, successCallBack) {
		$http({
		 	method: 'POST',
		 	url: './apmCounters/getBreachedCountersForHotspot',
			params: {
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime
			}
	 	}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
}]);

appedoApp.factory('$appedoUtils', function($http, $state) {
	var sliderValue, sumSliderValue;
	var sumColors = ["#0b62a4", "#1F8C2A", "#BB1C24", "#B847F5", "#7C7287", "#F59547", "#ADB554", "#229197", "#581464", "#142364"];
	
	// for timer
	var sec = 0, min = 0, hour = 0;
	var timerCountdown;
	
	var aryMonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	var INTERVAL_IN_HOURS = {'1 hour': 1, '1 day': 24, '7 days': 168, '15 days': 360, '30 days': 720, '60 days': 1440, '120 days': 2880, '180 days': 4320};
	
	
	return {
		MB: 1048576,
		KB: 1024,
		checkServerSession: function() {
			var promise = $http({
				url: './checkSessionExists',
				method: 'POST',
			}).success(function(data, status){
				if(data.success) {
					if(data.message == 'SESSION_EXPIRED') {
						//$state.transitionTo('/login');
						
						// since to show error message of HttpSession doesn't exsits, URL query string doesn't works with state params, tried `window.location.href`
						window.location.href = '#/loginResponse?_err=9';
					}
				} else {
				}
			});
			
			return promise;
		},
		changeFormatToArrayInJSON: function(aryChartData) {
			var aryNewChartData = [], joDatum = {};
			
			for(var i = 0; i < aryChartData.length; i = i + 1) {
				var aryDatum = aryChartData[i];
				joDatum = {};
				joDatum.T = aryDatum[0];
				joDatum.V = aryDatum[1];
				
				aryNewChartData.push(joDatum);
			}
			
			return aryNewChartData;
		},
		convertMilliSecToHoursMinSec: function(duration) {
			var format = '';
			if(parseInt(duration)>0){
				var seconds = parseInt((duration/1000)%60)
				, minutes = parseInt((duration/(1000*60))%60)
				, hours = parseInt((duration/(1000*60*60))%24)
				, days = parseInt((duration/(1000*60*60*24))%24);
	
				hours = (hours < 10) ? "0" + hours : hours;
				minutes = (minutes < 10) ? "0" + minutes : minutes;
				seconds = (seconds < 10) ? "0" + seconds : seconds;
	
				format = hours + ":" + minutes + ":" + seconds;
				if(days > 0){
					days = (days < 2) ? days +" day " : days +" days" ;
					format = days +" "+ format;
				}
			}
			
			return format;
		},
		timeDiffToHoursMinSec: function(nTime1, nTime2) {
			// calculates time diff to days:hours:minutes:seconds

			// thinks both `convertMilliSecToHoursMinSec` and `timeDiffToHoursMinSec` are same
			// Calculate the difference in milliseconds
			var nDiffMs = nTime2 - nTime1, joDiff = {};
			//take out milliseconds
			nDiffMs = nDiffMs/1000;
			
			joDiff.seconds = Math.floor(nDiffMs % 60);
			
			nDiffMs = nDiffMs/60;

			joDiff.minutes = Math.floor(nDiffMs % 60);
			nDiffMs = nDiffMs/60;

			joDiff.hours = Math.floor(nDiffMs % 24);  
			joDiff.days = Math.floor(nDiffMs/24);
			
			return joDiff;
		},
		timeDiffInMinutes: function(nTime1, nTime2) {
			// calculates time difference between two time in millseconds to minutes
			var nDiffMs = nTime2 - nTime1;
			var nMinutes = Math.round(nDiffMs / (1000 * 60));

			return nMinutes;
		},
		getLocalTimeInMills: function(date) {
			// date.getTime() returns epoch time in utc, converts utc epoch time   
			var nDateMillis = (date.getTime() + (date.getTimezoneOffset() * 60000));
			var nLocalMillis = nDateMillis - (date.getTimezoneOffset() * 60000);
			return nLocalMillis;
		},
		stopwatch: function () {
			sec++;
			
			if (sec == 60) {
				sec = 0;
				min = min + 1;
			} else {
				min = min; 
			}
			
			if (min == 60) {
				min = 0; 
				hour += 1;
			}

			if (sec<=9) {
				sec = "0" + sec;
			}
			
			return ((hour<=9)?"0"+hour:hour)+":"+((min<=9)?"0"+min:min)+":"+sec;
		},
		getLocationTillPathName: function() {
			return window.location.protocol +'//'+ window.location.host + window.location.pathname;
		},
		removeElementFromArray: function(ary, val) {
			for (var i = 0; i < ary.length; i++) {
				if (ary[i] === val) {
					ary.splice(i, 1);
					i--;
				};
			}
			return ary;
		},
		getTimeInMillsBeforeSpecifiedHours: function(nTimeInMills, nHours) {
			return nTimeInMills - (1000 * 60 * 60 * nHours);
		},
		getTimeInMillsBeforeSpecifiedInterval: function(nTimeInMills, interval) {
			return nTimeInMills - (1000 * 60 * 60 * INTERVAL_IN_HOURS[interval]);
		},
		filteredOptions: function(arySUMStatus) {
			// options=[{label: "Running", selected: true}, ...]
			// appedo-dropdown-multiselect, selected options's label is retruned, say ["Running, "Scheduled"], Note: "Running, "Scheduled" are selected from dropdown
			var arySelectedStatus = [];
			
			for (var i = 0; i < arySUMStatus.length; i = i + 1) {
				var joStatus = arySUMStatus[i];
				if ( joStatus.selected === undefined || joStatus.selected ) {
					arySelectedStatus.push( joStatus.label );
				};
			}
			
			return arySelectedStatus;
		},
		roundOfDecimalPlaces: function(nValue, nNoOfDecimalDigit) {
			// `+` added since avoid return in string, avoid adding .00 if a <number> does not have decimal places
			return +nValue.toFixed(nNoOfDecimalDigit);
		},
		isDate: function(value) {
			return (value instanceof Date) ;  
		},
		format_Date_To_ddMMMyyyy: function(date) {
			return date.getDate()+'-'+(aryMonths[date.getMonth()])+'-'+date.getFullYear();
		},
		parse_ddMMMyyyy_To_Date: function(strDate) {
			// converts string to date, say '01-Jan-2016' to js Date type
			var aryDateParts = strDate.split('-');
			return new Date(aryDateParts[2], aryMonths.indexOf(aryDateParts[1]), aryDateParts[0]);
		}
	};
});

appedoApp.factory('apmModulesFactory', ['$appedoUtils', function($appedoUtils){
	//var nIdxAddedMethods = 0, aryLimitedMethodsTrace = [], joIdxLimitedMethodsTrace = {};
	
	return {
		// 
		changeFormatToArrayInJSON: function(aryChartData) {
			var aryNewChartData = [], joDatum = {};
			
			for(var i = 0; i < aryChartData.length; i = i + 1) {
				var aryDatum = aryChartData[i];
				joDatum = {};
				 
				 
				joDatum.T = aryDatum[0];
				joDatum.V = aryDatum[1];
				
				aryNewChartData.push(joDatum);
			}
			
			return aryNewChartData;
		},
		getCounterSetsLength: function(aryData) {
			// each sets length
			var nCounterSetsLength = 0;
			
			for (var i = 0; i < aryData.length; i = i + 1) {
				nCounterSetsLength = nCounterSetsLength + aryData[i].length;
			}
			
			return nCounterSetsLength;
		},
		appendZeroAtFirst: function(aryChartData) {
			// for chart format in sets [[{'T': ..., 'V': ..}, {'T': ..., 'V': ..}], []], say apm chart format,  
			// append Zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
			var joDatum = aryChartData[0][0], now = new Date();
			var nDiffMinutes = $appedoUtils.timeDiffInMinutes(joDatum.T, now.getTime());
			
			//var joDiff = $appedoUtils.timeDiffToHoursMinSec(joDatum.T, now.getTime());
			//var joDiff = $appedoUtils.timeDiffToHoursMinSec(new Date(joDatum.T).getTime(), now.getTime());
			//var joDiff = $appedoUtils.timeDiffToHoursMinSec(new Date(joDatum.T).getTime(), $appedoUtils.getLocalTimeInMills(now));
			
			if ( nDiffMinutes < 60 ) {
				aryChartData.splice(0, 0, [{'T': new Date().setHours(now.getHours() - 1), 'V': 0}]);
			}
			
			return aryChartData;
		},
		sliceCounterSets: function(aryChartData, nRespCounterSetsLength) {
			var aryCounterSet = [];
			
			var joFirstDatum = aryChartData[0][0], now = new Date();
			var nDiffMinutes = $appedoUtils.timeDiffInMinutes(joFirstDatum.T, now.getTime());
			
			// tried, to slice if array's first time is > 1 hour
			if ( nDiffMinutes <= 60 ) {
				// avoid slice
				return aryChartData;
			} else {
				// slice

				// 
				for(var i = 0; i < aryChartData.length; i = i + 1) {
					aryCounterSet = aryChartData[i];
	
	
					// 
					if ( aryCounterSet.length === nRespCounterSetsLength ) {
						// tried, to slice entire set
						aryChartData = aryChartData.slice(i + 1);
						break;
					} else if ( aryCounterSet.length > nRespCounterSetsLength ) {
						// tried, to slice data from current set
						//aryCounterSet = aryCounterSet.slice(nRespCounterSetsLength);
						aryChartData[i] = aryChartData[i].slice(nRespCounterSetsLength);
						break;
					} else if ( aryCounterSet.length < nRespCounterSetsLength ) {
						// tried, to slice the set and to reduce `nRespCounterSetsLength` its length
						aryChartData = aryChartData.slice(i + 1);
						nRespCounterSetsLength = nRespCounterSetsLength - aryCounterSet.length;
	
						// thinks since array sliced, array size would be reduced, while next iteration index is reduced
						i = i - 1;
					}
				}
	
				return aryChartData;
			}
		},
		pushCounterSets: function(aryChartData, aryRespCounterChartData) {
			// push 
			var aryCounterSet = [], j = 0;
			// to push into last counter set, if diff between prev set's last datum time & current set first datum time is less than 1 min, `1` refers to 1 minute,
			if ( aryChartData.length > 0 ) {
				var aryLastCounterSet = aryChartData[aryChartData.length - 1];
				var nLastTime = aryLastCounterSet[aryLastCounterSet.length - 1].T, nCurrentFirstRespTime = aryRespCounterChartData[0][0].T;
				//var nDiffInMin = Math.round( (nCurrentFirstRespTime - nPrevTime) / (1000 * 60) );
				var nDiffMinutes = $appedoUtils.timeDiffInMinutes(nLastTime, nCurrentFirstRespTime);

				//var joDiff = $appedoUtils.timeDiffToHoursMinSec(nLastTime, nCurrentFirstRespTime);

				if ( nDiffMinutes < 1 ) {
					//
					j = 1;
					aryCounterSet = aryRespCounterChartData[0];
					aryChartData[aryChartData.length - 1] = aryLastCounterSet.concat(aryCounterSet);
				}
			}
			for (; j < aryRespCounterChartData.length; j = j + 1) {
				aryCounterSet = aryRespCounterChartData[j];
				aryChartData.push(aryCounterSet);
			}
			
			return aryChartData;
		},
		// for primary counters chartdata, to change `counterData` into `data` in jo, since to have desired format in directive, (ie.. [{label: '', data: [...]}, ...])
		setChartConfigUtilsAndChangeDataDirFormat: function(aryPrimaryCountersChartData) {
			// TODO: thinks, sets chart color to set

			// change directive format 
			for(var i = 0; i < aryPrimaryCountersChartData.length; i = i + 1) {
				var joCounterData = aryPrimaryCountersChartData[i];
				
				// since to have based on break sets, adds into array 
				joCounterData.data = [ joCounterData.counterData ];
				delete joCounterData.counterData;
			}
			
			return aryPrimaryCountersChartData;
		},
		limitMethodsTrace: function(aryMethodsTrace, nLimit) {
			var nIdxAddedMethods = 0, aryLimitedMethodsTrace = [];
			var isLengthExceeded = false;
			
			aryLimitedMethodsTrace = pushLimitedChildMethods(aryMethodsTrace);
			
			function pushLimitedChildMethods(aryChilds) {
				var joChildMethods = null, jaChildMethods = [];
				
				// (nlimit + 1) added, since to have `Show More Details` if more methods trace available than the specified limit
				for (var i = 0; i < aryChilds.length && nIdxAddedMethods < (nLimit + 1); i = i + 1) {
					joChildMethods = aryChilds[i];
					
					if ( nIdxAddedMethods < nLimit ) {
						nIdxAddedMethods = nIdxAddedMethods + 1;
						
						joChildMethods.items = pushLimitedChildMethods(joChildMethods.items);
					} else if ( nIdxAddedMethods == nLimit ) {
						isLengthExceeded = true;
						break;
					}
					
					jaChildMethods.push(joChildMethods);
				}
				
				return jaChildMethods;
			}
			
			return [isLengthExceeded, aryLimitedMethodsTrace];
		},
		hotSpotSliderOptions: {
			from: 1,
			to: 3,
			step: 1,
			scale: ["<div class='apd-xs-hide'>Last&nbsp;</div>1 hr", "<div class='apd-xs-hide'>Last&nbsp;</div>2 hrs", "<div class='apd-xs-hide'>Last&nbsp;</div>3 hrs"],
			qry_intervals: ["1 hour", "2 hours", "3 hours"],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			}
		}
	};
}]);

appedoApp.service('logService', ['$http', '$q','sessionServices', function($http, $q, sessionServices) {
	
	this.getLOGData_v1 = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, chartQuery) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'apmCounters/getLOGCountersChartdata_v1',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDate: nCustomStartDateTime,
				endDate: nCustomEndDateTime,
				query: chartQuery
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getLOGData_v2 = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, metricId, xyLabel, enterpriseData) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'apmCounters/getLOGCountersChartdata_v2',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDate: nCustomStartDateTime,
				endDate: nCustomEndDateTime,
				metricId: metricId,
				xyLabel: xyLabel,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	this.getLOGTypes = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'apmCounters/getLogTypes',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDate: nCustomStartDateTime,
				endDate: nCustomEndDateTime
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getLOGSData = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, logName, tableName, logLevel, enterpriseData) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'apmCounters/getLogsData',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDate: nCustomStartDateTime,
				endDate: nCustomEndDateTime,
				logName : logName,
				tableName: tableName,
				logLevel : logLevel,
				e_data : enterpriseData
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getSearchLOGSData = function(uid, logSearchText, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, logName, tableName, logLevel, enterpriseData) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'apmCounters/getSearchLOGSData',
			params: {
				uid: uid,
				logSearchText: logSearchText,
				fromStartInterval: fromStartInterval,
				startDate: nCustomStartDateTime,
				endDate: nCustomEndDateTime,
				logName : logName,
				tableName: tableName,
				logLevel : logLevel,
				e_data : enterpriseData
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
}]);

appedoApp.service('rumService', ['$http', '$q', '$uibModal', 'sessionServices', function($http, $q, $uibModal, sessionServices) { 		

	this.getModuleTypes = function(callback) {
		/*$scope.moduleTypes = {};
		this.getModuleTypes = function() {
			return $scope.moduleTypes;
		};*/

		$http({
			method: 'POST',
			url: 'apm/getModuleVersions',
			params:{
				moduleName: "RUM",
			}
		}).success(function(resp) {
			//$scope.moduleTypes = moduleSelectData;
			if(callback instanceof Function) {
				callback(resp);
			}
		});
	};
	
	this.saveRUM = function(bFromAdd, joModuleData, callback) {
		var url = '';
		
		var joParams = {
			moduleName: joModuleData.moduleName,
			moduleDescription: joModuleData.moduleDescription,
			moduleType: "RUM",
			moduleVersion: joModuleData.counterTypeVersionId,
			type: 'RUM',
			responseAlert: joModuleData.responseAlert
		};
		
		
		if ( bFromAdd ) {
			// add
			url = 'apm/addModule';
			
			joParams.moduleVersion = joModuleData.counterTypeVersionId;
			joParams.e_data = JSON.parse(sessionServices.get("selectedEnterprise"));
		} else {
			// edit/update
			url = 'apm/updateModule';

			joParams.uid = joModuleData.uid;
			joParams.guid = joModuleData.guid;
			joParams.e_data = JSON.parse(sessionServices.get("selectedEnterprise"));
		}
		
		// threshold 
		if ( joModuleData.responseAlert ) {
			joParams.warning = joModuleData.warning;
			joParams.critical = joModuleData.critical;
			joParams.breachCount = joModuleData.breachCount;
		}
		
		
		$http({
			method: 'POST',
			url: url,
			params: joParams
		}).success(function(resultData) {
			if(callback instanceof Function) {
				callback(resultData);
			}
		});
	};
	
	this.getDonutChartdata = function(moduleCode,uid,fromStartInterval) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getRUMDashDonut',
			params: {
				moduleCode: moduleCode,
				uid: uid,
				fromStartInterval:fromStartInterval
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};
	
	this.getRUMCards = function(enterpriseData) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getRUMCards',
			params: {
				e_data : enterpriseData
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};
	//rumService.getRUMFilters($scope.selectedRUM.value, $scope.selectedRUMFilterType.value, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedLogType.value, $scope.selectedLogType.tableName, $scope.selectedLogLevel.value );
	this.getRUMFilterValues = function(uid, filterType, sliderValue, startDate, endDate) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getRUMFilterValues',
			params : {
				uid: uid,
				filterType: filterType,
				fromStartInterval: sliderValue,
				startDateTime: startDate,
				endDateTime: endDate
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};

	//getRUMSearchDatas
	this.getRUMSearchDatas = function(uid, rumSearchText, filterType, filterValue, sliderValue, startDate, endDate) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getRUMSearchDatas',
			params : {
				uid: uid,
				rumSearchText: rumSearchText,
				filterType: filterType,
				filterValue: filterValue,
				fromStartInterval: sliderValue,
				startDateTime: startDate,
				endDateTime: endDate
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};
	
	this.getRUMDatas = function(uid, filterType, filterValue, sliderValue, startDate, endDate) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getRUMDatas',
			params : {
				uid: uid,
				filterType: filterType,
				filterValue: filterValue,
				fromStartInterval: sliderValue,
				startDateTime: startDate,
				endDateTime: endDate
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};
	
	this.getVisitorsCount = function(uid,fromStartInterval) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getVisitorsCount',
			params: {
				uid: uid,
				fromStartInterval:fromStartInterval
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};

	// dashboard visitors count graph
	this.getRUMDashArea = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/v1_getDailyVisitorsCount',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getRUMDashArea_v1 = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, legendText, chartQuery) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getDailyVisitorsCount_v1',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode,
				legendText: legendText, 
				query: chartQuery
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getRUMDashArea_v2 = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, metricId, xyLabel, rumType) {

		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getDailyVisitorsCount_v2',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				metricId: metricId,
				xyLabel: xyLabel,
				rumType: rumType,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getRUMDashCharts = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, legendText, chartQuery) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'rum/getRumAllCharts_v1',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode,
				legendText:legendText,
				chartQuery:chartQuery
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};

	this.getPagesLoadTime = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, successCallBack) {
		//var deferredObject = $q.defer();
		$http({
			method: 'POST',
			//url: 'common/data/rumPagesLoadTime.json',
			url: './rum/getPagesLoadTime',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getPagesLoadTimeWithDateRange = function(uid, startDate, endDate, successCallBack) {
		//var deferredObject = $q.defer();
		$http({
			method: 'POST',
			//url: 'common/data/rumPagesLoadTime.json',
			url: './rum/getPagesLoadTimeWithDateRange',
			params: {
				uid: uid,
				startDate: startDate,
				endDate: endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getSelectedPageLoadTime = function(uid, url, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, successCallBack) {
		$http({
			method: 'POST',
			//url: 'common/data/rumPageLoadTime.json',
			url: './rum/getPageLoadTimeChartData',
			params: {
				uid: uid,
				url: url,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getSelectedPageLoadTimeWithDateRange = function(uid, url, startDate, endDate, successCallBack) {
		$http({
			method: 'POST',
			//url: 'common/data/rumPageLoadTime.json',
			url: './rum/getPageLoadTimeChartDataWithDateRange',
			params: {
				uid: uid,
				url: url,
				startDate: startDate,
				endDate: endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	// gets RUM
	this.getRUMLastReceivedOn = function(uid, successCallBack) {
		$http({
			method: 'POST',
			//url: 'common/data/rumPageLoadTime.json',
			url: './rum/getRUMLastReceivedOn',
			params: {
				uid: uid
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	
	// CI event
	this.getEventsSummary = function(uid, fromStartInterval, agentType, environmnet, successCallBack) {
		
		$http({
			method: 'POST',
			url: './ci/getEventsSummary',
			params: {
				uid: uid,
				fromStartInterval: fromStartInterval,
				agentType: agentType,
				environmnet: environmnet
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getEventsSummaryWithDateRange = function(uid, startDate, endDate, agentType, environmnet, successCallBack) {
		$http({
			method: 'POST',
			url: './ci/getEventsSummaryWithDateRange',
			params: {
				uid: uid,
				startDate : startDate,
				endDate : endDate,
				agentType: agentType,
				environmnet: environmnet
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getsEventLoadTime = function(uid, eventId, fromStartInterval, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getEventLoadTime',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getsEventLoadTimeWithDateRange = function(uid, eventId, startDate, endDate, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getEventLoadTimeWithDateRange',
			params : {
				uid: uid,
				eventId: eventId,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getCIDailyVisitorsCount = function(uid, eventId, fromStartInterval, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getDailyVisitorsCount',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getCIDailyVisitorsCountWithDateRange = function(uid, eventId, startDate, endDate, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getDailyVisitorsCountWithDateRange',
			params : {
				uid: uid,
				eventId: eventId,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getBrowserWiseDonutData = function(uid, eventId, fromStartInterval, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getBrowserWiseDonutData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getDeviceTypeWiseDonutData = function(uid, eventId, fromStartInterval, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getDeviceTypeWiseDonutData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getOSWiseDonutData = function(uid, eventId, fromStartInterval, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getOSWiseDonutData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getDeviceNameWiseDonutData = function(uid, eventId, fromStartInterval, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getDeviceNameWiseDonutData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	// gets particular module agent types 
	this.getModuleAgentTypes = function(uid, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getModuleAgentTypes',
			params : {
				uid: uid
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	

	// gets particular module's environments
	this.getModuleEnvironments = function(uid, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getModuleEnvironments',
			params : {
				uid: uid
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	
	// gets event last receivedon
	this.getEventLastReceivedOn = function(uid, eventId, successCallBack) {

		$http({
			method : 'POST',
			url : './ci/getEventLastReceivedOn',
			params : {
				uid: uid,
				eventId: eventId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	

	// gets event last receivedon
	this.getPageBreakDownDetails = function(uid, rumId, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getPageBreakDownDetails',
			params : {
				uid: uid,
				rumId: rumId,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getPageBreakDownDetailsWithDateRange = function(uid, rumId, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getPageBreakDownDetailsWithDateRange',
			params : {
				uid: uid,
				rumId: rumId,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	// gets browser wise visitors counts
	this.getRUMBrowserWiseData = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getBrowserChartdata',
			params : {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	// gets browser wise visitors counts
	this.getRUMBrowserWiseDataWithDateRange = function(uid, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getBrowserChartdataWithDateRange',
			params : {
				uid: uid,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getRUMDeviceTypeWiseData = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getDeviceTypeChartdata',
			params : {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getRUMDeviceTypeWiseDataWithDateRange = function(uid, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getDeviceTypeChartdataWithDateRange',
			params : {
				uid: uid,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getRUMOSWiseData = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getOSChartdata',
			params : {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getRUMOSWiseDataWithDateRange = function(uid, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getOSChartdataWithDateRange',
			params : {
				uid: uid,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	/*this.getRUMDeviceNameWiseData = function(uid, fromStartInterval, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getDeviceNamesChartdata',
			params : {
				uid: uid,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};*/
	
	this.getRUMLocationWiseData = function(uid, fromStartInterval, nCustomStartDateTime, nCustomEndDateTime, healthCode, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getRUMLocationChartData',
			params : {
				uid: uid,
				fromStartInterval: fromStartInterval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getRUMLocationWiseDataForWorldMap = function(uid, fromStartInterval, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getRUMLocationWiseDataForWorldMap',
			params : {
				uid: uid,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getRUMLocationWiseDataWithDateRange = function(uid, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getRUMLocationChartDataWithDateRange',
			params : {
				uid: uid,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	// gets browser wise visitors counts
	this.getCIBrowserWiseData = function(uid, eventId, fromStartInterval, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getBrowserWiseData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getCIBrowserWiseDataWithDateRange = function(uid, eventId, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getBrowserWiseDataWithDateRange',
			params : {
				uid: uid,
				eventId: eventId,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	// gets device type visitors counts
	this.getCIDeviceTypeWiseData = function(uid, eventId, fromStartInterval, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getDeviceTypeWiseData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getCIDeviceTypeWiseDataWithDateRange = function(uid, eventId, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getDeviceTypeWiseDataWithDateRange',
			params : {
				uid: uid,
				eventId: eventId,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	// gets OS visitors counts
	this.getCIOSWiseData = function(uid, eventId, fromStartInterval, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getOSWiseData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getCIOSWiseDataWithDateRange = function(uid, eventId, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getOSWiseDataWithDateRange',
			params : {
				uid: uid,
				eventId: eventId,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	// gets Device Name visitors counts
	this.getCIDeviceNameWiseData = function(uid, eventId, fromStartInterval, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getDeviceNameWiseData',
			params : {
				uid: uid,
				eventId: eventId,
				fromStartInterval: fromStartInterval
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getCIDeviceNameWiseDataWithDateRange = function(uid, eventId, startDate, endDate, successCallBack) {
		$http({
			method : 'POST',
			url : './ci/getDeviceNameWiseDataWithDateRange',
			params : {
				uid: uid,
				eventId: eventId,
				startDate : startDate,
				endDate : endDate
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getRumAvgPageLoadTimeDonutCount = function(interval) {
	var deferredObject = $q.defer();
	$http({
		method: 'POST',
		url: './rum/getRumAvgPageLoadTimeDonutCount',
			params : {
				interval: interval
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getRumUrlWisePageView = function(interval) {
	var deferredObject = $q.defer();
	$http({
		method: 'POST',
		url: './rum/getRumUrlWisePageView',
		params : {
			interval: interval
		}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getRUMModuleDetails = function(uid, successCallBack) {
		
		$http({
			method : 'POST',
			url : './apm/getRUMModuleDetails',
			params : {
				uid: uid
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		});
	};
	
	this.openAddorEditRUMModule = function(isFrom, moduleDescriptionContent, rumModuleData) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/rum/add_rum_module.html',
			controller: 'addRumController',
			size: 'lg',
			backdrop : 'static',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleDescriptionContent: function() {
					return moduleDescriptionContent;
				},
				rumModuleData: function() {
					return rumModuleData;
				}
			}
		});
	};
	
	this.getTopRUMResponses = function(uid, type, typeValue, interval, nCustomStartDateTime, nCustomEndDateTime, healthCode, successCallBack) {
		$http({
			method : 'POST',
			url : './rum/getTopRUMResponses',
			params : {
				uid: uid,
				type: type,
				typeValue: typeValue,
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				healthCode: healthCode
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		});
	};
	
	this.openTopRUMResponses = function(selectedModule, joSiteAnalysisType, joTypeDatum, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/rum/rumTopResponses.html',
			controller: 'rumTopResponsesController',
			size: 'lg',
			//backdrop : 'static',
			resolve: {
				selectedModule: function() {
					return selectedModule;
				},
				siteAnalysisType: function() {
					return joSiteAnalysisType;
				},
				typeDatum: function() {
					return joTypeDatum;
				},
				interval: function() {
					return { sliderInterval: sliderSelectedValue, startDateTimeInMills: nStartDateTimeInMills, endDateTimeInMills: nEndDateTimeInMills };
				}, 
				healthCode: function() {
					return healthCode;
				}
			}
		});
	};
}]);

appedoApp.factory('rumModuleFactory', function($state, sessionServices) {
	var arySiteAnalysisTypes = [{ type: 'BROWSER', displayName: 'Browser', respDatumKey: 'browser', respDatumPageViewsKey: 'visitCount', isTimeSelection: false }, 
						{ type: 'CITY', displayName: 'City/Area', respDatumKey: 'city', respDatumPageViewsKey: 'count', isTimeSelection: false }, 
						{ type: 'DEVICE', displayName: 'Device Type', respDatumKey: 'device', respDatumPageViewsKey: 'visitCount', isTimeSelection: false }, 
						{ type: 'OS', displayName: 'OS', respDatumKey: 'os', respDatumPageViewsKey: 'visitCount', isTimeSelection: false }, 
						{ type: 'PAGE_VIEWS_GRAPH', displayName: 'Page views at', respDatumKey: 'T', respDatumPageViewsKey: 'V', isTimeSelection: true } ];
	
	var joRUMHealths = { 'WARNING': { healthCode: 'WARNING', displayName: 'Warning', cssClass: 'clrWarning ' },
						 'CRITICAL': { healthCode: 'CRITICAL', displayName: 'Critical', cssClass: 'clrCritical ' } };
	
	return {
		rumSliderOptions: {
			from: 1,
			to: 5,
			step: 1,
			//dimension: (function(){return ' '+this.sliderValueMapping[sliderValue]})(),
			dimension: '',
			scale: ['Last 24 hrs', 'Last 7 days', 'Last 15 days', 'Last 30 days', 'Last 60 days'],
			smooth: false,
			qry_intervals: ['24 hours', '7 days', '15 days', '30 days', '60 days']
		},
		rumSliderOptions_velocityui: {
			from: 1,
			to: 5,
			step: 1,
			scale: ["Last 24 hrs", "Last 7 days", "Last 15 days", "Last 30 days", "Last 60 days"],
			//serverSideScale: ["1 hour", "1 day", "7 days", "30 days", "60 days", "120 days"],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			},
			qry_intervals: ['24 hours', '7 days', '15 days', '30 days', '60 days']
		},
		siteAnalysisTypes: arySiteAnalysisTypes,
		viewRUMDetailsPage: function(joModule, type) {
			// to store for hidden params
			sessionServices.set("uid", joModule.uid);
			
			// for dynamic params in state 
			$state.transitionTo('/rum_details/:type/:moduleName', {'type': type, 'moduleName': joModule.moduleName});
		},
		GROUP_BY_MINUTE_INTERVALS: ["15 minutes", "30 minutes", "1 hour"],
		GROUP_BY_HOUR_INTERVALS: ["3 hours", "6 hours", "12 hours", "24 hours", "1 day"],
		ONE_MINUTE: 1000 * 60,
		ONE_HOUR: 1000 * 60 * 60,
		ONE_DAY: 1000 * 60 * 60 * 24,
		RUM_HEALTH_DETAILS: joRUMHealths
	};
});
appedoApp.factory('avmModuleFactory', ['$appedoUtils', function($appedoUtils){
	var AVM_STATUSES = {
		'Agent Down': { textColor: 'clrCritical', iconColor: 'apd-redicon', showLastResponse: true, allowEdit: false },
		'Processing Issue': { textColor: 'clrCritical', iconColor: 'apd-redicon', showLastResponse: true, allowEdit: false },
		'Partial URL': { textColor: 'clrWarning', iconColor: 'apd-yellowicon', showLastResponse: true, allowEdit: false },
		'No URLs mapped': { textColor: 'clrWarning', iconColor: 'apd-darkblueicon', showLastResponse: true, allowEdit: false },
		'Unreachable': { textColor: 'clrCritical', iconColor: 'apd-redicon', showLastResponse: true, allowEdit: false },
		'Active': { textColor: 'clrOk', iconColor: 'apd-greenicon', showLastResponse: false, allowEdit: false },
		'Just Added': { textColor: 'clrWarning', iconColor: 'apd-greyicon', showLastResponse: false, allowEdit: true }
	};
	
	return {
		AVM_STATUSES: AVM_STATUSES,
		defaultSliderOptions: {
			from: 1,
			to: 7,
			step: 1,
			scale: ["<div class='apd-xs-hide'>Last&nbsp;</div>15 mins","<div class='apd-xs-hide'>Last&nbsp;</div>30 mins", "<div class='apd-xs-hide'>Last&nbsp;</div>1 hr", "<div class='apd-xs-hide'>Last&nbsp;</div>3 hrs", "<div class='apd-xs-hide'>Last&nbsp;</div>6 hrs", "<div class='apd-xs-hide'>Last&nbsp;</div>12 hrs", "<div class='apd-xs-hide'>Last&nbsp;</div>1 day"],
			qry_intervals: ["15 minutes", "30 minutes", "1 hour", "3 hours", "6 hours", "12 hours", "1 day"],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			}
		}
	};
}]);

appedoApp.service('avmModuleServices', ['$http', '$q', 'ngToast', '$uibModal', 'messageService', 'sessionServices', function($http , $q, ngToast, $uibModal, messageService, sessionServices) {
	
	this.getAVMUserTests = function(successCallBack) {
		$http({
			method: 'POST',
			url: './avm/getAVMUserTests'
		})
		.success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		})
		.error(function(data) {
			console.log("Error in Ajax Call..");
		});
	};
	
	this.getUserAgents = function($scope, testid, callBack) {	
		this.getUserAgentsData = function() {
			return $scope.userAgents;
		};
		$http({
			method: 'POST',
			url:"./avm/getAVMAgents",
			params: {
				testid: testid,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		})
		.success(function(data) {
			if(callBack instanceof Function){
				callBack(data);
			};
		})
		.error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.validateAVMTestName = function($scope, avmTestName, testId, callback) {
		$http({
			method: 'POST',
			url: './avm/validateAVMTestName',
			params: {
				testName: avmTestName,
				testId: testId
			}
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.saveAVMData = function($scope, avmTestAddData, selectedCities, callback) {
		// ,/*d.getHours(),d.getMinutes()*/
		var joParams = {};
		var stDate = avmTestAddData.startdate;
		var d11 = new Date(avmTestAddData.enddate);
		var enDate = new Date(d11.getFullYear() , d11.getMonth(), d11.getDate(),23,59,59);
		var isEdit = avmTestAddData.testid?true:false;
		
		console.log('stDate');console.log(stDate);console.log('enDate');console.log(enDate);
		
		var startHourAndMins,endHourAndMins;
		
		if(avmTestAddData.startHour != undefined && avmTestAddData.startMins != undefined){
			//startHourAndMins = getUTCHourAndMins(avmTestAddData.startHour, avmTestAddData.startMins);
			startHourAndMins = avmTestAddData.startHour + ":" +( avmTestAddData.startMins == 0 ? '00' : avmTestAddData.startMins )+ ":00";
		}else{
			startHourAndMins = null;
		}
		if(avmTestAddData.endHour != undefined && avmTestAddData.endMins != undefined){
			//endHourAndMins = getUTCHourAndMins(avmTestAddData.endHour, avmTestAddData.endMins);
			endHourAndMins = avmTestAddData.endHour + ":" +( avmTestAddData.endMins == 0 ? '00' : avmTestAddData.endMins )+ ":00";
		}else{
			endHourAndMins = null;
		}

		function getUTCHourAndMins(hours, minute){
			var d = new Date();
		    d.setHours(hours);
		    d.setMinutes(minute);
		    d.setSeconds(0);
		    var timeInMillis = d.getTime();

			return timeInMillis;
		}

		if ( isdate(stDate) == 1 ){
			stDate = formatDate(stDate, 'st');
		} else {
			// else part check in chrome, no need, always comes isdate(stDate)==1 true in firefox 
			stDate = new Date(stDate.toString());
		}
		/* commented to avoid startdate sent with time
		var ctDate = new Date();
		// testId is null for Add AVMTest, So we are added below conditon. While edit we are not restting start date to current date.
		if(stDate < ctDate && !isEdit) {
			stDate = ctDate;
		}*/
		if (isdate(enDate)==1){
			enDate = formatDate(enDate, 'ed');}
		else {
			enDate = new Date(enDate.toString());
		}

		function formatDate(date, ct)
		{
			var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
			var splitDate = date.split("-");
			var convertedDate=new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
			/*if(ct == "st"){
				var ctDate = new Date();
				if(convertedDate < ctDate) {
					convertedDate = ctDate;
				}
			}*/

			return convertedDate;
		}
		function isdate(val)
		{
			var date = Date.parse(val);
			if(isNaN(date))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}

		joParams = {
			testName: avmTestAddData.testName,
			url: avmTestAddData.url,
			requestMethod: avmTestAddData.requestMethod,
			testHeadMethodFirst: avmTestAddData.testHeadMethodFirst,
			requestHeaders: JSON.stringify(avmTestAddData.requestHeaders),
			requestParameters: JSON.stringify(avmTestAddData.requestParameters),
			frequency: avmTestAddData.frequency,
			startDate: stDate,
			endDate: enDate,
			status: avmTestAddData.status,
			selectedCities: JSON.stringify(selectedCities),
			avmMinBreachCount: avmTestAddData.avmBreachCount,
			days: angular.toJson(avmTestAddData.days),
			startHourAndMins: startHourAndMins,
			endHourAndMins: endHourAndMins,
			timezoneOffset: avmTestAddData.timezoneOffset,
			
			// Bandwidth Alert parameters
			bandwidthAlert: avmTestAddData.bandwidthAlert,
			warningLimit: avmTestAddData.warning,
			errorLimit: avmTestAddData.error,
			bmMinBreachCount: avmTestAddData.bmBreachCount,
			e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
		};

		if(avmTestAddData && avmTestAddData.testid){
			// test id is set in edit 
			joParams.testid = avmTestAddData.testid;
			joParams.isStartDateChanged = avmTestAddData.isStartDateChanged != undefined ? avmTestAddData.isStartDateChanged : null;
			url = './avm/updateAVMTest';
		} else {
			url = './avm/addAVMTest';
		}

		// if Availability Monitor is disabled then, 
		// call the submit without verifing AVM-Locations
		if( ! avmTestAddData.status || ( selectedCities && selectedCities.length > 0 ) ) {
			$http({
				method: 'POST',
				url: url,
				params: joParams
			}).success(function(responseData) {
				if (callback) {
					callback(responseData);
				}
			});
		}
		// Don't raise exception, if Availability Monitor is disabled.
		else if( avmTestAddData.status ){
			messageService.showWarningMessage('Please select Region/Location.');
		}
	};

	this.deleteAVMRecord = function($scope, testid, callback) {
		$http({
			method: 'POST',
			url: './avm/deleteAVMTest',
			params: {
				testid: testid
			}
		})
		.success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};
	
	this.getAVMUserDashboardSummary = function(callback) {
		$http({
			method: 'POST',
			url: './avm/getAVMUserDashboardSummary'
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};

	this.getUserDownLocationsStatus = function($scope, offSetValue, limit, callback) {
		$http({
			method: 'POST',
			url: './avm/getUserDownLocationsStatus',
			params: {
				limit: limit,
				offset: offSetValue
			}
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.getUserApplicationsStatus = function(callback) {
		$http({
			method: 'POST',
			url: './avm/getUserApplicationsStatus'
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.openAddorEditMyLocations = function(isFrom, joLocationDetails, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/avm/add_avm_user_locations.html',
			controller: 'addAVMMyLocationsController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				locationDetails: function() {
					return joLocationDetails;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	

	this.saveAgentLocation = function(bFromAdd, joLocationData, callback) {
		var url = '';
		
		var joParams = {
			country: joLocationData.country,
			state: joLocationData.state,
			city: joLocationData.city,
			region: joLocationData.region,
			zone: joLocationData.zone,
			private: joLocationData.private,
			e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
		};
		
		
		if ( bFromAdd ) {
			// add
			url = './avm/addAgentLocation';
		} else {
			// edit/update
			url = './avm/updateAgentLocation';
			
			joParams.agentId = joLocationData.agentId;
		}
		
		$http({
			method: 'POST',
			url: url,
			params: joParams
		}).success(function(resultData) {
			if(callback instanceof Function) {
				callback(resultData);
			}
		});
	};
	
	this.getUserLocations = function(callback) {
		$http({
			method: 'POST',
			url: './avm/getUserLocations'
		}).success(function(resultData) {
			if(callback instanceof Function) {
				callback(resultData);
			}
		});
	};
	
	// open location down to alert email/SMS addresses 
	this.openLocationToAlertAddresses = function(agentId, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/avm/avm_location_to_alert_addresses.html',
			controller: 'avmLocationViewToAlertAddressesController',
			size: 'lg',
			resolve: {
				agentId: function() {
					return agentId;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	
	this.openLocationAddAlertAddress = function(joLocationDetails, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/avm/avm_location_add_alert_address.html',
			controller: 'avmLocationAddAlertAddressController',
			size: 'lg',
			resolve: {
				locationDetails: function() {
					return joLocationDetails;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	
	this.getLocationAlertAddresses = function(nLocationId) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './avm/getLocationAlertAddresses',
			params: {
				agentId: nLocationId,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.addLocationAlertAddress = function(nLocationId, guid, joAlertForm) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './avm/addLocationAlertAddress',
			params: {
				agentId: nLocationId,
				guid: guid,
				alertType: joAlertForm.alertType.value,
				emailOrMobileNumber: joAlertForm.emailOrMobileAddress,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};

	this.deleteLocationAlertAddress = function(nAgentAlertId, nLocationId) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './avm/deleteLocationAlertAddress',
			params: {
				agentAlertId: nAgentAlertId,
				agentId: nLocationId,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
		
		return deferredObject.promise;
	};
	
	this.getLocationDetails = function(nLocationId, callback) {
		$http({
			method: 'POST',
			url: './avm/getLocationDetails',
			params: {
				agentId: nLocationId,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(resultData) {
			if(callback instanceof Function) {
				callback(resultData);
			}
		});
	};
	
	this.getTestLocationsStatus = function(nTestId, offSetValue, limit, callback) {
		$http({
			method: 'POST',
			url: './avm/getTestLocationsStatus',
			params: {
				testId: nTestId,
				limit: limit,
				offset: offSetValue,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.getUserTestSummary = function(nTestId, callback) {
		$http({
			method: 'POST',
			url: './avm/getUserTestSummary',
			params: {
				testId: nTestId,
				e_data:JSON.parse(sessionServices.get("selectedEnterprise")) 
			}
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
}]);
appedoApp.factory('sumModuleFactory', function() {	
	return {
		sliderOptions: {
			from: 1,
			to: 8,
			step: 1,
			scale: ["Last 1 hr","Last 24 hrs", "Last 7 days", "Last 15 days", "Last 30 days", "Last 60 days", "Last 120 days", "Last 180 days"],
			qry_intervals: ["1 hour", "1 day", "7 days", "15 days", "30 days", "60 days", "120 days", "180 days"],
			interval_in_hours: [1, 24, 168, 360, 720, 1440, 2880, 4320],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			}
		}
	};
});


appedoApp.service('sumModuleServices', ['$http', '$q', 'ngToast', 'messageService', 'sessionServices', function($http , $q, ngToast, messageService, sessionServices) {

//	this.getSUMUserTests = function(successCallBack) {
//		//var deferredObject = $q.defer();
//		$http({
//			method: 'POST',
//			url: './sum/getUserTests'
//		}).success(function(data) {
//			if (successCallBack instanceof Function) {
//				successCallBack(data);
//			}
//		}).error(function(data) {
//			console.log("Error in Ajax Call");
//		});
//	};

	this.getSUMUserTests = function(successCallBack) {
		//var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getNewUserTests'
		})
		.success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		})
		.error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getPackages = function($scope) {
		this.getPackagesData = function() {
			return $scope.sumPackages;
		};
		$http({
			method: 'POST',
			url: './sum/getPackages'
		})
		.success(function(packageData) {
			$scope.sumPackages = packageData;
			$scope.sumTestData.tranasctionImports = $scope.sumPackages.packages;
			$scope.sumTestData.transaction = $scope.sumPackages.script;
		})
		.error(function(packageData) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.validateSUMTestName = function($scope, sumTestName, testId, callback) {
		$http({
			method: 'POST',
			url: 'sum/validateSUMTestName',
			params: {
				testName: sumTestName,
				testId: testId
			}
		})
		.success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});	
	};

	this.getUserNodes = function($scope, testid, dobId, callBack) {
		this.getUserNodesData = function() {
			return $scope.userNodes;
		};
		$http({
			method: 'POST',
			url:"./sum/getSUMNodes",
			params: {
				testid: testid,
				dobIds: dobId.join()
			}
		})
		.success(function(data) {
			if(callBack instanceof Function){
				callBack(data);
			};
		})
		.error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getMaxLocation = function(callBack) {
		$http({
			method: 'POST',
			url:"./sum/getMaxLocation"
		})
		.success(function(data) {
			if(callBack instanceof Function){
				callBack(data);
			};
		})
		.error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.saveSumData = function($scope, sumTestAddData, selectedCities, callback) {
		// 
		var joParams = {};
		var stDate = sumTestAddData.startdate ;
		var enDate = sumTestAddData.enddate+' 23:59:59';
		var isEdit = sumTestAddData.testid?true:false;
		if ( isdate(stDate) == 1){
			stDate=formatDate(stDate, 'st');
		} else {
			// else part check in chrome, no need, always comes isdate(stDate)==1 true in firefox 
			stDate = new Date(stDate.toString());
		}
		/* commented to avoid startdate sent with time
		var ctDate = new Date();
		// testId is null for Add SumTest, So we are added below conditon. While edit we are not restting start date to current date.
		if( stDate < ctDate && ! isEdit ) {
			stDate = ctDate;
		}*/
		if ( isdate(enDate) == 1 ){
			enDate = formatDate(enDate, 'ed');}
		else {
			enDate = new Date(enDate.toString());
		}

		/* var currentTime = new Date();
		var hours = currentTime.getHours();
		var minutes = currentTime.getMinutes();
		var seconds = currentTime.getSeconds();
		var milliseconds = currentTime.getMilliseconds();
		if (minutes < 10) minutes = "0" + minutes;

		var sdate = StartDate.getDate();
		var smonth = StartDate.getMonth();
		var syear = StartDate.getFullYear();

		var edate = EndDate.getDate();
		var emonth = EndDate.getMonth();
		var eyear = EndDate.getFullYear();

		var sdateToCompare = new Date(syear, smonth, sdate, hours, minutes, seconds, milliseconds);
		var edateToCompare = new Date(eyear, emonth, edate, 23, 59, 59, 00);*/
		function formatDate(date, ct)
		{
			var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
			var splitDate = date.split("-");
			var convertedDate=new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
			/*if(ct == "st"){
				var ctDate = new Date();
				if(convertedDate < ctDate) {
					convertedDate = ctDate;
				}
			}*/

			return convertedDate;
		}
		function isdate(val)
		{
			var date = Date.parse(val);
			if(isNaN(date))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}

		joParams = {
			testName: sumTestAddData.testName,
			url: sumTestAddData.url,
			runEveryMinutes: sumTestAddData.runEveryMinutes,
			startDate: stDate,
			endDate: enDate,
			seleniumScriptPackages: sumTestAddData.tranasctionImports,
			transaction: sumTestAddData.transaction || '',
			testtype: sumTestAddData.testType,
			status: sumTestAddData.status,
			selectedCities: JSON.stringify(selectedCities)
		};

		if( sumTestAddData && sumTestAddData.testid ){
			// set testid in edit
			joParams.testid = sumTestAddData.testid;
			joParams.slaId = sumTestAddData.slaId;
			url = './sum/updateSUMTest';
		} else {
			url = './sum/addSUMTest';
		}

		if(selectedCities && selectedCities.length > 0) {
			$http({
				method: 'POST',
				url: url,
				params: joParams
			}).success(function(responseData) {
				if (callback) {
					callback(responseData);
				}
			});
		} else {
			messageService.showWarningMessage('Please select Region/Location.');
		}
	};
	
	this.saveNewSumData = function($scope, sumTestAddData, selectedCities, callback) {
		// 
		var joParams = {};
		var stDate = sumTestAddData.startdate ;
		console.log("sum Test Data:"+ sumTestAddData.enddate);
		var d11 = new Date(sumTestAddData.enddate);
		console.log("dll:"+d11);
		var enDate = new Date(d11.getFullYear() , d11.getMonth(), d11.getDate(),23,59,59);
		//var enDate = sumTestAddData.enddate+' 23:59:59';
		var isEdit = sumTestAddData.testid?true:false;

		console.log("Res EnDate:"+ enDate);
		if ( isdate(stDate) == 1 ){
			stDate = formatDate(stDate, 'st');
		} else {
			// else part check in chrome, no need, always comes isdate(stDate)==1 true in firefox 
			stDate = new Date(stDate.toString());
		}
		/* commented to avoid startdate sent with time
		var ctDate = new Date();
		// testId is null for Add SumTest, So we are added below conditon. While edit we are not restting start date to current date.
		if(stDate < ctDate && !isEdit) {
			stDate = ctDate;
		}*/
		console.log("endate:"+ enDate);
		if (isdate(enDate)==1){
			
			enDate = formatDate(enDate, 'ed');}
		else {
			enDate = new Date(enDate.toString());
		}

		function formatDate(date, ct)
		{
			var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
			var splitDate = date.split("-");
			var convertedDate=new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
			/*if(ct == "st"){
				var ctDate = new Date();
				if(convertedDate < ctDate) {
					convertedDate = ctDate;
				}
			}*/

			return convertedDate;
		}
		function isdate(val)
		{
			var date = Date.parse(val);
			if(isNaN(date))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}

		joParams = {
			testName: sumTestAddData.testName,
			url: sumTestAddData.url,
			runEveryMinutes: sumTestAddData.runEveryMinutes,
			startDate: stDate,
			endDate: enDate,
			seleniumScriptPackages: sumTestAddData.tranasctionImports,
			transaction: sumTestAddData.transaction || '',
			testtype: sumTestAddData.testType,
			status: sumTestAddData.status,
			selectedCities: JSON.stringify(selectedCities),
			//dobIds: sumTestAddData.browser.dobId,
			dobIds: sumTestAddData.browser.join(),
			connectionId: sumTestAddData.connection.connectionId,
			downloadLimit: sumTestAddData.download,
			uploadLimit: sumTestAddData.upload,
			latencyLimit: sumTestAddData.latency,
			packetLoss: sumTestAddData.packetloss,
			responseAlert: sumTestAddData.responseAlert || '',
			downTimeAlert: sumTestAddData.downTimeAlert,
			//smsAlert: sumTestAddData.sms || '',
			//emailAlert: sumTestAddData.email || '',
			smsAlert: sumTestAddData.responseAlert? true : '',
			emailAlert: sumTestAddData.responseAlert? true : '',
			warningLimit: sumTestAddData.warning,
			errorLimit: sumTestAddData.error,
			rmMinBreachCount: sumTestAddData.rmBreachCount,
			repeatView: sumTestAddData.repeatView,
			e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
		};

		console.info('sumTestAddData');
		console.log(sumTestAddData);

		if(sumTestAddData && sumTestAddData.testid){
			// test id is set in edit 
			joParams.testid = sumTestAddData.testid;
			joParams.isStartDateChanged = sumTestAddData.isStartDateChanged != undefined ? sumTestAddData.isStartDateChanged : null;
			//joParams.e_data = JSON.parse(sessionServices.get("selectedEnterprise"));
			url = './sum/updateNewSUMTest';
		} else {
			if(sumTestAddData.testType === 'TRANSACTION'){
				joParams.dobIds = 1; //For TRANSACTION set Device type = DESKTOP , os_name = WINDOWS and browser = CHROME, dobid=1; 
				joParams.connectionId = 11; //For TRANSACTION set Connection = Native Connection (No Traffic Shaping) connectionId=11;
				joParams.downloadLimit = 0; //For TRANSACTION set downloadLimit = 0 For Native Connection (No Traffic Shaping) in DB is = 0;
				joParams.uploadLimit = 0; //For TRANSACTION set uploadLimit = 0 For Native Connection (No Traffic Shaping) in DB is = 0;
				joParams.latencyLimit = 0; //For TRANSACTION set latencyLimit = 0 For Native Connection (No Traffic Shaping) in DB is = 0;
				joParams.packetLoss = 0; //For TRANSACTION set packetLoss = 0 For Native Connection (No Traffic Shaping) in DB is = 0;
			}
			url = './sum/addNewSUMTest';
		}

		// if Response Monitor is disabled then, 
		// call the submit without verifing SUM-Locations
		if( ! sumTestAddData.status || ( selectedCities && selectedCities.length > 0 ) ) {
			$http({
				method: 'POST',
				url: url,
				params: joParams
			}).success(function(responseData) {
				if (callback) {
					callback(responseData);
				}
			});
		}
		// don't raise exception, if Response Monitor is disabled.
		else if( sumTestAddData.status ){
			messageService.showWarningMessage('Please select Region/Location.');
		}
	};
	
	this.deleteSumRecord = function($scope, testid, testtype, status, callback) {
		$http({
			method: 'POST',
			url: './sum/deleteSUMTest',
			params: {
				testid: testid,
				testtype : testtype,
				status : status
			}
		})
		.success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};

	this.getSUMLicense = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMLicense'
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getDonutChartdata = function(moduleCode) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMSummary',
			params: {
				moduleCode: moduleCode
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMDropdown = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMMultiDropDown'
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMWorldMap = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMWorldMap'
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMDetailsDropDown = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMDetailsDropDown',
			params: {
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getLicenseSUMDetails = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getLicenseSUMDetails'
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.checkVaildHarURL = function(harUrl) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/checkVaildHarURL',
			params: {
				harUrl: harUrl
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMMultiLine = function(testId, pageId, pageName, interval, nCustomStartDateTime, nCustomEndDateTime, metricId, location) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMMultiLine_v1',
			params: {
				testId: testId,
				pageId: pageId,
				pageName: pageName,
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				metricId : metricId,
				location : location,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMMultiLineWithLocationBrowserConnection = function(testId, pageId, pageName, interval) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMMultiLineWithLocationBrowserConnection',
			params: {
				testId: testId,
				interval: interval,
				pageId: pageId,
				pageName: pageName
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMMultiLineWithDateRange = function(testId, pageId, pageName, startDate, endDate) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMMultiLineWithDateRange',
			params: {
				testId: testId,
				startDate: startDate,
				endDate: endDate,
				pageId: pageId,
				pageName: pageName
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMTestsResults = function(callBack) {

		$http({
			method: 'POST',
			url: './sum/getSUMTestsResults'
		})
		.success(function(data, status) {
			if(callBack instanceof Function) {
				callBack(data);
			}
		});
	};

	this.getSUMTestPages = function(testId, callBack) {
		$http({
			method: 'POST',
			url: './sum/getSUMTestPages',
			params: {
				testId : testId
			}
		})
		.success(function(data, status) {
			if(callBack instanceof Function) {
				callBack(data);
			}
		});
	};

	this.getFirstByte = function(id, callBack) {
		$http({
			method: 'POST',
			url: './sum/getFirstByte',
			params: {
				har_Id : id
			}
		})
		.success(function(data, status) {
			if(callBack instanceof Function) {
				callBack(data);
			}
		});
	};


	this.fetchScreen = function(id, callBack) {
		$http({
			method: 'POST',
			url: './sum/fetchScreen',
			params: {
				har_Id : id
			}
		})
		.success(function(data, status) {
			if(callBack instanceof Function) {
				callBack(data);
			}
		});
	};

	this.getDemoSumData = function($scope, quickSumData, callBack) {
		$http({
			method: 'POST',
			url: './addDemoSUM',
			params: {
				demo_test_email_id: quickSumData.email,
				demo_test_pwd: quickSumData.pwd,
				sumurl: quickSumData.url,
				demo_test_company_name: quickSumData.companyName,
				demo_test_phone_number: quickSumData.phoneNumber
			}
		})
		.success(function(data) {
			if(callBack) {
				callBack(data);
			}
		});
	};

	this.getDemoSUMStatus = function($scope, testId, callBack) {
		$http({
			method: 'POST',
			url: './sum_viewer/getDemoSUMStatus',
			params: {
				sum_test_id: testId
			}
		})
		.success(function(status) {
			if(callBack) {
				callBack(status);
			}
		});
	};

	// gets particular SUM test details for the encrypted SUMTestId
	this.getSUMTestDetails = function($scope, encryptSUMTestId, callBack) {
		$http({
			method: 'POST',
			url: './sum/getSUMTestDetails',
			params: {
				encryptSUMTestId: encryptSUMTestId
			}
		})
		.success(function(data) {
			if(callBack instanceof Function) {
				callBack(data);
			}
		});
	};

	this.getSUMConnections = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sum/getSUMConnectivity'
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMDeviceTypes = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sum/getSUMDeviceTypes'
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMOSTypes = function(device_type) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sum/getSUMOsNames',
			params: {
				device_type: device_type
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSUMBrowserTypes = function(device_type, os_name) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sum/getSUMBrowserNames',
			params: {
				device_type: device_type,
				os_name: os_name
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

	this.getSumAvgPageLoadTimeDonutCount = function(interval) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSumAvgPageLoadTimeDonutCount',
			params: {
				interval:interval
			}
		})
		.success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};

/*	this.getSUMPageMultiLine = function(testId,pageId,interval) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './sum/getSUMPageMultiLine',
			params: {
				testId: testId,
				pageId:pageId,
				interval:interval
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);

		return deferredObject.promise;
	};
*/	
}]);
appedoApp.service('slaActionsService', ['$http', function($http) {

	this.getSLAActions = function($scope, callback) {
		$http({
			method: 'POST',
			url: 'sla/getActionsCardLayout',	
		}).success(function(slaActionCardData) {
			if(callback instanceof Function){
				callback(slaActionCardData);
			};
		});
	};
	
	this.isValidActionName = function($scope, actionName, actionId, callback) {
		$http({
			method: 'POST',
			url: 'sla/isValidActionName',
			params: {
				actionName: actionName,
				actionId: actionId,
			}
		}).success(function(slaActionCardData) {
			if(callback instanceof Function){
				callback(slaActionCardData);
			};
		});
	};
	
	this.addSLAAction = function($scope, slaActionForm, moduleCardContent, callback){
		$scope.slaActionForm = slaActionForm;
        $scope.moduleCardContent=moduleCardContent;
        $http({
			method: 'POST',
			url: 'sla/addAction',	
			params: {	
				actionName: $scope.slaActionForm.actionName,
				actionDescription: $scope.slaActionForm.actionDescription,
				isPublic: ($scope.slaActionForm.radioPublicORPrivate == undefined || $scope.slaActionForm.radioPublicORPrivate == 'pvt')?false:true,
				parameterFormat: $scope.slaActionForm.parameterType != undefined?$scope.slaActionForm.parameterType:'json',
				parameterValues: $scope.slaActionForm.scriptParameter,
				executionType: $scope.slaActionForm.scriptType,
				script: $scope.slaActionForm.actionScript,
			}
		}).success(function(slaActionCardData) {
			if(callback instanceof Function){
				callback(slaActionCardData);
			};
		});	
	};
	
	this.updateSLAAction = function($scope, slaActionForm, moduleCardContent, callback){
		$scope.slaActionForm = slaActionForm;
        $scope.moduleCardContent=moduleCardContent;
        $http({
			method: 'POST',
			url: 'sla/updateAction',	
			params: {	
				actionId: $scope.slaActionForm.actionId,
				actionName: $scope.slaActionForm.actionName,
				actionDescription: $scope.slaActionForm.actionDescription,
				isPublic: ($scope.slaActionForm.radioPublicORPrivate == undefined || $scope.slaActionForm.radioPublicORPrivate == 'pvt')?false:true,
				parameterFormat: $scope.slaActionForm.parameterType != undefined?$scope.slaActionForm.parameterType:'json',
				parameterValues: $scope.slaActionForm.scriptParameter,
				executionType: $scope.slaActionForm.scriptType,
				script: $scope.slaActionForm.actionScript,
			}
		}).success(function(slaActionCardData) {
			if(callback instanceof Function){
				callback(slaActionCardData);
			};
		});	
	};
	
	this.deleteAction = function($scope, actionId, callback) {
		$http({
			method: 'POST',
			url: 'sla/deleteAction',	
			params: {	
				actionId: actionId,
			}
		}).success(function(slaActionCardData) {
			if(callback instanceof Function){
				callback(slaActionCardData);
			};
		});	
	};
}]);

appedoApp.service('slaRuleService', ['$http', '$q', function($http, $q) {

	this.getSLARules = function($scope, callback) {
		$http({
			method: 'POST',
			url: 'sla/getRulesCardLayout',	
		}).success(function(slaRuleCardData) {
			if(callback instanceof Function){
				callback(slaRuleCardData);
			};
		});	
	};
	
	this.isValidRuleName = function($scope, ruleName, ruleId, callback) {
		$http({
			method: 'POST',
			url: 'sla/isValidRuleName',
			params: {
				ruleName: ruleName,
				ruleId: ruleId,
			}
		}).success(function(slaActionCardData) {
			if(callback instanceof Function){
				callback(slaActionCardData);
			};
		});	
	};
	
	this.getActionsForMapping = function($scope, callback) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getActionsForMapping',	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);

	    return deferredObject.promise;
	};
	
	this.addSLARule = function($scope, slaRuleForm, moduleCardContent, callback){
		
		$scope.slaRuleForm = slaRuleForm;
		$scope.actions = $scope.slaRuleForm.actions;
		$scope.selectedActions = [];
        $scope.moduleCardContent=moduleCardContent;
        for(var i=0; i<$scope.actions.length; i++){
        	if($scope.actions[i].isSelected == true){
        		$scope.selectedActions.push($scope.actions[i]);
			}
        }
        $http({
			method: 'POST',
			url: 'sla/addSlaRule',
			params: {	
				ruleName: $scope.slaRuleForm.ruleName,
				ruleDescription: $scope.slaRuleForm.ruleDescription,
				actionIds: JSON.stringify($scope.selectedActions),
			}
		}).success(function(slaRuleActions) {
			if(callback instanceof Function){
				callback(slaRuleActions);
			};
		});
	};
	
	this.updateSLARule = function($scope, slaRuleForm, moduleCardContent, callback){
		
		$scope.slaRuleForm = slaRuleForm;
		$scope.actions = $scope.slaRuleForm.actions;
		$scope.selectedActions = [];
        $scope.moduleCardContent=moduleCardContent;
        for(var i=0; i<$scope.actions.length; i++){
        	if($scope.actions[i].isSelected == true){
        		$scope.selectedActions.push($scope.actions[i]);
			}
        }
        $http({
			method: 'POST',
			url: 'sla/updateSlaRule',
			params: {	
				ruleName: $scope.slaRuleForm.ruleName,
				ruleId: $scope.slaRuleForm.ruleId,
				ruleDescription: $scope.slaRuleForm.ruleDescription,
				actionIds: JSON.stringify($scope.selectedActions),
			}
		}).success(function(slaRuleActions) {
			if(callback instanceof Function){
				callback(slaRuleActions);
			};
		});
	};
	this.getMappedRules = function(ruleId){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/sla/getMappedRuleActions',
			params: {	
				ruleId: ruleId,
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.deleteRule = function($scope, ruleId, callback) {
		$http({
			method: 'POST',
			url: 'sla/deleteRule',	
			params: {	
				ruleId: ruleId,
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
}]);

appedoApp.service('slacardService', ['$http', '$q', '$uibModal', 'sessionServices', function($http, $q, $uibModal, sessionServices) {

	this.getSLAGrid = function($scope, bSystem, moduleCode, callback) {
		$http({
			method: 'POST',
			url: 'sla/getSLAsCardLayout',	
			params: {
				isSystem: bSystem,
				moduleCode: moduleCode
				/*
				moduleType: moduleType,
				pageLimit: 10,
				pageOffset: 0,
				*/
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});	
	};
	
	this.getSLAAlerLog = function($scope, slaId, offSetValue, limit, callback) {	
		$http({
			method: 'POST',
			url: 'sla/getSlaAlertCardLayout',	
			params: {	
				slaid: slaId,
				limit: limit,
				offset: offSetValue
			}				
		}).success(function(slaSlaveCardData) {
			if(callback instanceof Function){
				callback(slaSlaveCardData);
			};
		});	
	};
	
	// add/edit counter for particular SLA
	this.openSLAAddAlterCounterChart = function(operation, joSLACounterDetails, chartName) {
 		var modalInstance = $uibModal.open({
 			templateUrl: 'common/views/sla/sla_add_alter_counter_chart.html',
 			controller: 'slaAddAlterCounterChart',
 			size: 'lg',
 			resolve: {
 				operation: function() {
					return operation;
				},
 				slaPolicyDetails: function() {
					return joSLACounterDetails;
				},
				chartName: function() {
					return chartName;
				}
 			}
 		});
	};
	
	this.getCounterMappedAlerts = function(uid, counterId){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getCounterMappedAlerts',
			params: {	
				uid: uid,
				counterId: counterId
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getSLAHealLog = function($scope, slaId, callback) {	
		$http({
			method: 'POST',
			url: 'sla/getSlaHealCardLayout',	
			params: {	
				slaid: slaId,
			}
		}).success(function(slaSlaveCardData) {
			if(callback instanceof Function){
				callback(slaSlaveCardData);
			};
		});	
	};

	this.isValidPolicyName = function($scope, policyName, policyId, callback) {
		$http({
			method: 'POST',
			url: 'sla/isValidPolicyName',
			params: {
				policyName: policyName,
				policyId: policyId,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(slaActionCardData) {
			if(callback instanceof Function){
				callback(slaActionCardData);
			};
		});	
	};
	
	this.getRulesForMapping = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getRulesForMapping',
			e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getMaxValueCounterIdDetail = function($scope, counterId, uid, callback) {
		$http({
			method: 'POST',
			url: 'sla/isMaxValueCounterIdSelected',
			params: {
				counterId: counterId,
				uid: uid,
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});	
	};

	this.addSLAPolicy = function($scope, slaPolicyForm, callback) {
		
		$http({
			method: 'POST',
			url: 'sla/addSLAPolicy',	
			params: {	
				policyName: slaPolicyForm.policyName,
				policyDesc: slaPolicyForm.policyDescription,
//				alertType: 'Alert',
				alertType: slaPolicyForm.type,
				mapRuleId: slaPolicyForm.mappedRule,
				configServFormat: slaPolicyForm.policySvr,
				policySvrType: slaPolicyForm.policySvrType,
				activePolicy: slaPolicyForm.activePolicy,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});	
	};
	
	this.updateSLAPolicy = function($scope, slaPolicyForm, callback) {	
		$scope.slaPolicyForm = slaPolicyForm;
		$http({
			method: 'POST',
			url: 'sla/updateSLAPolicy',
			params: {
				slaId: slaPolicyForm.slaId || slaPolicyForm.sla_id,
				policyName: slaPolicyForm.policyName || slaPolicyForm.sla_name,
				policyDesc: slaPolicyForm.policyDescription || slaPolicyForm.description,
//				alertType: 'Alert',
				alertType: slaPolicyForm.type,
				mapRuleId: slaPolicyForm.mappedRule,
				configServFormat: slaPolicyForm.policySvr,
				policySvrType: slaPolicyForm.policySvrType,
				activePolicy: slaPolicyForm.activePolicy,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.enableOrDisableSLAPolicy = function($scope, slaId, activePolicy, callback) {
		$http({
			method: 'POST',
			url: 'sla/enableOrDisableSLAPolicy',
			params: {
				slaId: slaId,
				activePolicy: activePolicy
			}
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.getModuleTypeValues = function(moduleType) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getModuleTypeValues',
			params: {	
				type: moduleType,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getBreachTypes = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getBreachType',
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getCounters = function(uid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getCounters',
			params: {	
				uid: uid,
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	//addAlertAndCounter
	
	this.addAlertAndCounter = function( slaPolicyMapCounterForm, counterDetails){
		
		//$scope.slaPolicyMapCounterForm = slaPolicyMapCounterForm;
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/addAlertAndCounter',
			params: {	
				breachId: slaPolicyMapCounterForm.breachType.breachId,
				policyName: slaPolicyMapCounterForm.policyName,
				policyDescription: slaPolicyMapCounterForm.policyDescription,
				mappedRule: slaPolicyMapCounterForm.mappedRule,
				counterId: counterDetails.counterId,
				uid: counterDetails.uid,
				guid: counterDetails.guid,
				inPercentage: false,
				isThresholdAbove: (slaPolicyMapCounterForm.thresholdabv == undefined || slaPolicyMapCounterForm.thresholdabv == 'lt')?false:true,
				minBreachCount: slaPolicyMapCounterForm.minBreachCount,
				warning_threshold_value: slaPolicyMapCounterForm.warning_threshold_value,
				critical_threshold_value: slaPolicyMapCounterForm.critical_threshold_value,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.mapToAlert = function( slaPolicyMapCounterForm, counterDetails){
		
		//$scope.slaPolicyMapCounterForm = slaPolicyMapCounterForm;
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/mapToAlert',
			params: {	
				breachId: slaPolicyMapCounterForm.breachType.breachId,
				counterId: slaPolicyMapCounterForm.counterId,
				uid: slaPolicyMapCounterForm.uid,
				guid: slaPolicyMapCounterForm.guid,
				inPercentage: false,
				isThresholdAbove: (slaPolicyMapCounterForm.thresholdabv == undefined || slaPolicyMapCounterForm.thresholdabv == 'lt')?false:true,
				minBreachCount: slaPolicyMapCounterForm.minBreachCount,
				warning_threshold_value: slaPolicyMapCounterForm.warning_threshold_value,
				critical_threshold_value: slaPolicyMapCounterForm.critical_threshold_value,
				slaId: slaPolicyMapCounterForm.alertDetails.slaId,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.addMapCounter = function($scope, slaPolicyMapCounterForm){
		
		//$scope.slaPolicyMapCounterForm = slaPolicyMapCounterForm;
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/addMapCounter',
			params: {	
				breachId: slaPolicyMapCounterForm.breachType.breachId,
				counterId: slaPolicyMapCounterForm.counterName.counterId,
				counterName: slaPolicyMapCounterForm.counterName.name,
				ctId: slaPolicyMapCounterForm.counterName.ctId,
				ctvId: slaPolicyMapCounterForm.agentName.ctvId,
				guid: slaPolicyMapCounterForm.agentName.guid,
				inPercentage: false,
				isThresholdAbove: (slaPolicyMapCounterForm.thresholdabv == undefined || slaPolicyMapCounterForm.thresholdabv == 'lt')?false:true,
				minBreachCount: slaPolicyMapCounterForm.minBreachCount,
				moduleName: slaPolicyMapCounterForm.moduleType.module_code,
				moduleValue: slaPolicyMapCounterForm.agentName.moduleName,
				warning_threshold_value: slaPolicyMapCounterForm.warning_threshold_value,
				critical_threshold_value: slaPolicyMapCounterForm.critical_threshold_value,
				uid: slaPolicyMapCounterForm.agentName.uid,
				category: slaPolicyMapCounterForm.counterName.category,
				slaId: slaPolicyMapCounterForm.slaId,
				denominator_counter_id : slaPolicyMapCounterForm.percentageVsTotal == 'PERCENTAGE' ? slaPolicyMapCounterForm.counterName.max_value_counter_id : 0,
				percentage_calculation : slaPolicyMapCounterForm.percentageVsTotal == 'PERCENTAGE' ? true : false
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.updateMapCounter = function($scope, slaPolicyMapCounterForm){
		
		$scope.slaPolicyMapCounterForm = slaPolicyMapCounterForm;
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/updateMapCounter',
			params: {	
				isThresholdAbove: ($scope.slaPolicyMapCounterForm.thresholdabv == undefined || $scope.slaPolicyMapCounterForm.thresholdabv == 'lt')?false:true,
				minBreachCount: $scope.slaPolicyMapCounterForm.minBreachCount,
				warning_threshold_value: $scope.slaPolicyMapCounterForm.warning_threshold_value,
				critical_threshold_value: $scope.slaPolicyMapCounterForm.critical_threshold_value,
				mapCounterId: $scope.slaPolicyMapCounterForm.mapCounterId,
				guid: $scope.slaPolicyMapCounterForm.guid,
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getAllSLAAlert = function(moduleType, uid, counterId){
		
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getAllSLAAlert',
			params: {	
				moduleType: moduleType,
				uid: uid,
				counterId: counterId,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getMapCounters = function(slaId){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getMapCounters',
			params: {	
				slaId: slaId,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.deleteMapCounter = function(slaId, counterId, guid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/deleteMapCounter',
			params: {	
				slaId: slaId,
				counterId: counterId,
				guid: guid,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);

        return deferredObject.promise;
	};
	
	this.getSLASettings = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getSLASettings',
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.setSlaSetting = function($scope, setSlaSetting){
		$scope.setSlaSetting = setSlaSetting;
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/setSlaSettings',
			params: {	
//				maxTryDuration: "60",
//				maxTry: "2",
				maxTryDuration: $scope.setSlaSetting.maxTryDuration,
				maxTry: $scope.setSlaSetting.maxTry,
				alertTriggerFrequency: $scope.setSlaSetting.alertTriggerFrequency
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.saveAlerts = function(slaPolicyViewAlertFrom){
		// $scope.slaPolicyViewAlertFrom = slaPolicyViewAlertFrom;
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/saveAlerts',
			params: {	
				type: slaPolicyViewAlertFrom.alertType.value,
				//emailornumber: slaPolicyViewAlertFrom.alertType=='Email'?slaPolicyViewAlertFrom.email:slaPolicyViewAlertFrom.sms,
				emailornumber: slaPolicyViewAlertFrom.emailOrMobileAddress,
				telephoneCode: slaPolicyViewAlertFrom.countryCode.telephone_code
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
 
        return deferredObject.promise;
	};
	
	this.getAlerts = function(){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/getAlertsSettings',
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.deleteAlert = function(alertId) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/deleteSlaAlert',
			params: {	
				alertId: alertId,
			}
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.deleteSLAPolicy = function($scope, slaId, callback){
		$http({
			method: 'POST',
			url: 'sla/deleteSLAPolicy',	
			params: {	
				slaId: slaId
			}				
		}).success(function(data) {
			if(callback instanceof Function){
				callback(data);
			};
		});
	};
	
	this.getExecLogFile = function(logFileName){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'sla/readLogData',
			params: {	
				logFile: logFileName,
			}
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.openAddorEditSLAPolicy = function(isFrom, joSLAPolicyDetails, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/add_sla_policy.html',
			controller: 'addSlaPolicyController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				slaPolicyFormData: function() {
					return joSLAPolicyDetails;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	
	// add/edit server details for the SLA, to perform heal action 
	this.openSLAHealMapToServer = function(isFrom, joSLAPolicyDetails, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/sla_policy_map_svr.html',
			controller: 'slaPolicyMapSvrController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				slaPolicyForm: function() {
					return joSLAPolicyDetails;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	
	// has mapped counters for particular SLA, add/edit mapped counters
	this.openSLAViewMappedCounters = function(isFrom, joSLAPolicyDetails, nSLAId) {
		var modalInstance = $uibModal.open({
			// templateUrl: 'modules/sla/view/sla_policy_map_counter.html',
			// controller: 'slaPolicyMapCounter',
			templateUrl: 'common/views/sla/sla_policy_view_map_counter.html',
			controller: 'slaPolicyViewMapCounter',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				slaPolicyDetails: function() {
					return joSLAPolicyDetails;
				},
				slaId: function() {
					return nSLAId;
				}
			}
		});
	};
	
	// add/edit counter for particular SLA
	this.openSLAMapToCounter = function(isFrom, joSLAPolicyDetails, joSLAActionForm, nSLAId) {
 		var modalInstance = $uibModal.open({
 			templateUrl: 'common/views/sla/sla_policy_map_counter.html',
 			controller: 'slaPolicyMapCounter',
 			size: 'lg',
 			resolve: {
 				isFrom: function() {
 					return isFrom;
 				},
 				slaPolicyDetails: function() {
					return joSLAPolicyDetails;
				},
				slaActionForm: function() {
 					return joSLAActionForm;
 				},
 				slaId: function() {
 					return nSLAId;
 				}
 			}
 		});
	};
	
	// open SLA policy success fully added or updated
	this.openSLAPolicySuccess = function(isFrom, joSLAPolicyDetails, nSLAId) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/sla_policy_success.html',
			controller: 'slaPolicySuccess',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				slaPolicyForm: function() {
					return joSLAPolicyDetails;
				},
				slaId: function() {
					return nSLAId;
				}
			}
		});
	};

	this.openSettingsPage = function(isFrom, moduleCardContent) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/sla_setting.html',
			controller: 'slaSettingController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return 'fromAdd';
				},
				slaActionFormData: function() {
					return null;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}
			}
		});
	};
	
	// open SLA settings to alert email/SMS addresses 
	this.openSettingsToAlertAddresses = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/sla_setting_view_alert.html',
			controller: 'slaSettingViewAlert',
			size: 'lg'
		});
	};
}]);

appedoApp.service('slaSlaveService', ['$http', function($http) {

	this.getSlaveStatus = function($scope, callback) {	
		$http({
			method: 'POST',
			url: 'sla/getSlaveStatusCardLayout',	
		}).success(function(slaSlaveCardData) {
			if(callback instanceof Function){
				callback(slaSlaveCardData);
			};
		});	
	};
}]);

appedoApp.service('SlaMenuBadgeService', ['$http', function($http) {

	this.getSlaMenuBadge = function($scope) {	
		$http({
			method: 'POST',
			url: 'sla/getSlaMenuBadge',	
		}).success(function(slaMenuData) {
			$scope.slaBadgeValues = slaMenuData;
		});	
	};
}]);
appedoApp.service('ltFactory', ['$state', 'sessionServices', function($state, sessionServices) {
	// notes is sets, on change of runId, get run_id's  notes 
	var arySummaryReportNotesCategories = [
		{ label: 'Summary', value: 'SUMMARY', hasScriptWiseNote: false, notes: '' },
		{ label: 'Settings', value: 'SETTINGS', hasScriptWiseNote: false, notes: '' },
		{ label: 'Script Wise', value: 'SCRIPT_WISE', hasScriptWiseNote: false, notes: '' },
		{ label: 'Container', value: 'CONTAINER_WISE', hasScriptWiseNote: true, notes: '' },
		{ label: 'Request', value: 'REQUEST_WISE', hasScriptWiseNote: true, notes: '' },
		{ label: 'Transaction', value: 'TRANSACTION_WISE', hasScriptWiseNote: true, notes: '' },
		{ label: 'Error', value: 'ERROR_DESCRIPTION', hasScriptWiseNote: true, notes: '' }
	];
	
	function saveReportPageHiddenParams(nRunId, nScenarioId) {
		sessionServices.set("runId", nRunId);
		sessionServices.set("scenarioId", nScenarioId);
	}
	
	return {
		summaryReportNotesCategories: arySummaryReportNotesCategories,
		viewScenarioRunningStatus: function(loadTestType, scenarioName, nRunId, nScenarioId) {
			// goes to running scenario status scenario screen, for the params
			
			saveReportPageHiddenParams(nRunId, nScenarioId);
			$state.transitionTo('/ltRunningScenarioStauts/:loadTestType/:scenarioName', {'loadTestType': loadTestType, 'scenarioName': scenarioName});
		},
		viewScenarioAllReports: function(loadTestType, scenarioName, nRunId, nScenarioId, moduleType) {
			// go to scenario's all reports, for the params
			
			saveReportPageHiddenParams(nRunId, nScenarioId);
			$state.transitionTo('/ltScenarioReports/:loadTestType/:scenarioName/:moduleType', {'loadTestType': loadTestType, 'scenarioName': scenarioName, 'moduleType':moduleType});
		}
	};
}]);

appedoApp.service('ltService', ['$http', '$q', '$uibModal', function($http, $q, $uibModal) {
	/*
	this.getScenarioReportsForDropdown = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getScenarioReports',
			params: {
				dropdown : true
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};*/
	
	this.getDonutChartdata = function(type,runid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getLTDashDonut',
			params: {
				type: type,
				runid: runid
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getDashResponseArea = function(runid) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getDashResponseArea',
			params: {
				runid: runid
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};

	this.getDashVUsersArea = function(runid,scenarioName) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getDashVUsersArea',
			params: {
				runid: runid,
				scenarioName: scenarioName
			}
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};

	this.getLTLicense = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getLTLicense'
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getUserAgentDetails = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getUserAgentDetails'
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.getRunningScenario = function(runId, loadTestType, successCallBack) {
		
		$http({
			method: 'POST',
			url: './lt/getScriptwiseData',
			//url: 'common/data/ltRunningScenarios.json',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getRunningScenarioForChart = function(runId, successCallBack) {
		
		$http({
			method: 'POST',
			url: './lt/getRunningScenarioForChart',
			params: {
				runid: runId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getLtScripts = function($scope, isFrom, scenarioId, successCallBack) {
		if(isFrom === "fromEdit") {
			$http({
		        method: 'POST',
		        url: './lt/editScenarios',
		        params: {
		        	testTypeScript: 'APPEDO_LT',
		        	scenarioId: scenarioId
		        }
		    }).success(function(data) {
		    	if (successCallBack instanceof Function) {
					successCallBack(data);
				}
		    });
		} else {
			$http({
		        method: 'POST',
		        url: './lt/getVUScripts',
		        params: {
		        	testTypeScript: 'APPEDO_LT'
		        }
		    }).success(function(data) {
		        if (successCallBack instanceof Function) {
					successCallBack(data);
				}
		    });
		}
	};
	
	this.deleteScenarioRecord = function ($scope, scenario_id, scenarioName, callback) {
		$http({
	        method: 'POST',
	        url: './lt/deleteScenarios',
	        params: {
	        	testTypeScript: 'APPEDO_LT',
				scenarioId: scenario_id,
				scenarioName: scenarioName
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.deleteVariable = function ($scope, variableName, callback) {
		$http({
	        method: 'POST',
	        url: './lt/deleteVariable',
	        params: {
	        	variableName: variableName,
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.updateVariable = function($scope, variableName, policy, startsFrom, callback) {
		$http({
	        method: 'POST',
	        url: './lt/updateVariable',
	        params: {
	        	variableName: variableName,
	        	policy: policy,
	        	startsFrom: startsFrom,
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	this.deleteJmeterScenarioRecord = function ($scope, scenarioId, scenarioName, testTypeScript, callback) {
		$http({
	        method: 'POST',
	        url: './ltScheduler/deleteJMeterScript',
	        params: {
	        	scenarioId: scenarioId,
	        	scenarioName: scenarioName,
	        	testTypeScript: testTypeScript
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.saveLtScripts = function ($scope, isFrom, arySelectedScriptDetails, callback) {
		  
		if(isFrom == "fromEdit") {
			$http({
			    method: 'POST',
			    url: './lt/updateScenarios',
			    params: {
			    	testTypeScript: 'APPEDO_LT',
			    	scenarioId: $scope.mapScript.scenarioId,
			    	scenarioName: $scope.mapScript.scenarioName,
			    	scriptDetails: arySelectedScriptDetails.length > 0 ? JSON.stringify(arySelectedScriptDetails) : null
			    	//scriptIds: selectedScriptsId.length>0 ? selectedScriptsId.join(): null,
			    	//scriptNames: selectedScriptnames.length>0 ? selectedScriptnames.join(): ''
			    }
			}).success(function(data) {
				if(callback){
					callback(data);
				}
			});
		} else {
			$http({
			    method: 'POST',
			    url: './lt/mappingScripts',
			    params: {
			    	testTypeScript: 'APPEDO_LT',
			    	scenarioName: $scope.mapScript.scenarioName,
			    	scriptDetails: arySelectedScriptDetails.length > 0 ? JSON.stringify(arySelectedScriptDetails) : null
			    	//scriptIds: selectedScriptsId.length>0 ? selectedScriptsId.join(): null,
			    	//scriptNames: selectedScriptnames.length>0 ? selectedScriptnames.join(): ''
			    }
			}).success(function(data) {
				if(callback){
					callback(data);
				}
			});
		}
	};
	
	this.getRunAgentMapping = function ($scope, selectedScenario) {
		$scope.ltMonitorData = {};
		
		$http({
	        method: 'POST',
	        url:"./lt/getRunAgentMapping",
	        params: {
				testTypeScript: selectedScenario.loadTestType,
				apmGroup: 'APPLICATION,SERVER,DATABASE',
				scenarioId: selectedScenario.scenario_id
			}
	    }).success(function(data) {
	        $scope.ltMonitors = data.message;
	        $scope.$watch('ltMonitorData.ltMonitor', function() {
	            $scope.userCities = {};
		        $scope.counters = {};
		        if ($scope.ltMonitorData.ltMonitor != undefined) {
		            if ($scope.ltMonitorData.ltMonitor.apm != undefined) {
		                $scope.agentsData = $scope.ltMonitorData.ltMonitor.agents;
		            }
		        }
	        });
	    });
	};
	
	this.getScenarioSettings = function ($scope, scenarioId, testTypeScript, callback) {
		$http({
        method: 'POST',
        url:"./lt/getScenarioSettings",
        params: {
        			testTypeScript: testTypeScript,
					scenarioId: scenarioId
        		}
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.getRunSettings = function ($scope, runId, callback) {
		$http({
        method: 'POST',
        url:"./lt/getRunSettings",
        params: {
        			runId: runId
        		}
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.updateScenarioSettings = function($scope, scriptIds, ltScenarioData, scriptNames, scriptConfigData, testTypeScript, callback) {
		var dh = $scope.ltRunSettingForm.durationHrs > 0 ? $scope.ltRunSettingForm.durationHrs : 0;
		var dm = $scope.ltRunSettingForm.durationMins > 0 ? $scope.ltRunSettingForm.durationMins : 0;
		var ds = $scope.ltRunSettingForm.durationSecs > 0 ? $scope.ltRunSettingForm.durationSecs : 0;
		var ih = $scope.ltRunSettingForm.forEveryHrs > 0 ? $scope.ltRunSettingForm.forEveryHrs : 0;
		var im = $scope.ltRunSettingForm.forEveryMins > 0 ? $scope.ltRunSettingForm.forEveryMins : 0;
		var is = $scope.ltRunSettingForm.forEverySecs > 0 ? $scope.ltRunSettingForm.forEverySecs : 0;
		var scenario_settings = {};
		scenario_settings.browsercache = $scope.ltRunSettingForm.clearBrowserCache;
		scenario_settings.durationtime = dh +";"+ dm +";"+ ds;
		scenario_settings.incrementtime = ih +";"+ im +";"+ is;
		scenario_settings.incrementuser = $scope.ltRunSettingForm.increamnetUser;
		scenario_settings.iterations = $scope.ltRunSettingForm.iterationCount > 0 ? $scope.ltRunSettingForm.iterationCount : 0;
		scenario_settings.maxuser = $scope.ltRunSettingForm.maxUserCount;
		scenario_settings.startuser = $scope.ltRunSettingForm.startUserCount;
		scenario_settings.currentloadgenid = scriptConfigData.currentloadgenid;
		scenario_settings.durationmode = scriptConfigData.durationmode;
		scenario_settings.startuserid = scriptConfigData.startuserid;
		scenario_settings.totalloadgen = scriptConfigData.totalloadgen;
		scenario_settings.parallelconnections = $scope.ltRunSettingForm.parallelconnections;
		if($scope.ltRunSettingForm.iterationDuration == "iteration") {
			scenario_settings.type = "1";
		} else {
			scenario_settings.type = "2";
		}
    	
		$http({
	        method: 'POST',
	        url:"./lt/updateScenarioSettings",
	        params: {
				testTypeScript: testTypeScript,
				scenarioId: ltScenarioData.scenario_id,
				scriptIds: scriptIds.join(),
				scenarioSettings: scenario_settings,
				scriptNames: scriptNames.join(),
				scenarioName: ltScenarioData.scenarioName
			}
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.runScenario = function ($scope, params, callback) {
		$http({
        method: 'POST',
        url:"./lt/runScenario",
        params: params
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	

	this.runJmeterScenario = function ($scope, params, callback) {
		$http({
        method: 'POST',
        url:"./ltScheduler/runScenario",
        params: params
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.agentLoadGenerator = function($scope, selectedScenario, callback) {
			$http({
			    method: 'POST',
			    url: './lt/readRegions',
			    params: {
			    	testTypeScript: selectedScenario.loadTestType
			    }
			}).success(function(data) {
				if(callback){
					callback(data);
				}
			});
	};

	this.getScenarios = function(successCallBack) {
		
		$http({
			method: 'POST',
			url: 'common/data/ltScenarios.json',
			params: {
				
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getScenarioReports = function(nScenarioId, loadTestType, successCallBack) {
		$http({
			method: 'POST',
			url: './lt/getScenarioReports',
			params: {
				scenarioid: nScenarioId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getselectedReportRunStartAndEndTime = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getselectedReportRunStartAndEndTime',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getselectedReportGuid = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getselectedReportGuid',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.runManualSummaryReport = function(runId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/runManualSummaryReport',
			params: {
				runid: runId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getMasterSummaryReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getMasterSummaryReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getScriptSummaryReport = function(runId, loadTestType, scriptIds, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getScriptSummaryReport',
			params: {
				runid: runId,
				scriptIds:scriptIds,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getChildSummaryReportScriptWise = function(runId, loadTestType,scriptIds,reportType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getChildSummaryReportScriptWise',
			params: {
				runid: runId,
				testTypeScript: loadTestType,
				scriptId : scriptIds,
				reportType : reportType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.getSummaryReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getScriptwiseData',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getLogReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/logReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	
	this.getErrorReport = function(runId, loadTestType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/errorReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	

	this.getChartReport = function(runId, loadTestType, startTime, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/chartReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType,
				startTime : startTime
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getNewChartReport = function(runId, loadTestType, startTime, queryDuration, selectedTime, status, runTime, chartType, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/chartReport',
			params: {
				runid: runId,
				testTypeScript: loadTestType,
				startTime : startTime,
				queryDuration : queryDuration,
				selectedTime : selectedTime,
				status : status,
				runTime : runTime,
				chartType : chartType
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.checkEndTimeFormatForExistingTest = function(runId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/checkEndTimeFormatForExistingTest',
			params: {
				runid: runId,
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.runEndTimeFormatForExistingTest = function(runId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/runEndTimeFormatForExistingTest',
			params: {
				runid: runId,
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};

	this.deleteScriptRecord = function ($scope, ltScriptData, loadTestType, callback) {
		$http({
	        method: 'POST',
	        url: './ltScheduler/deleteScript',
	        params: {
				scriptId: ltScriptData.script_id,
				scriptName: ltScriptData.scriptName,
				testTypeScript: loadTestType
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};


	//
	this.stopRunningScenario = function(runId, callback){
		$http({
		 	method: 'POST',
		 	url: './ltScheduler/stopRunningScenario',
		 	params:{
		 		runId: runId,
		 	}
	 	}).success(function(data, status){
	        if(callback) {
	        	callback(data);
	        }
	 	});
	};
	
	this.getModuleCountersChartdataForLoadTest = function(guid,counter_id,startTime,endTime,runTime) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getModuleCountersChartdataForLoadTest',
			params: {
				guid: guid,
				counterNames: counter_id,
				startTime: startTime,
				endTime: endTime,
				runTime : runTime
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
        return deferredObject.promise;
	};
	
	this.getNewModuleCountersChartdataForLoadTest = function(guid,counter_id,startTime,endTime,runTime,queryDuration,selectedTime,status,startMonitor,endMonitor) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './lt/getNewModuleCountersChartdataForLoadTest',
			params: {
				guid: guid,
				counterNames: counter_id,
				startTime: startTime+(startMonitor*60*1000),
				endTime: endTime+(endMonitor*60*1000),
				runTime : runTime,
				queryDuration : queryDuration,
				selectedTime : selectedTime,
				status : status,
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
        return deferredObject.promise;
	};
	
	// opens add or edit scenario/map scripts
	this.openAddorEditScenario = function(isFrom, moduleCardContent, mapScript, bOpenConfigureScenario) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/add_edit_lt.html',
			controller: 'addLTController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				}, 
				ltScenarioData: function() {
					return mapScript;
				},
				openConfigureScenario: function() {
					return bOpenConfigureScenario;
				}
			}
		});
	};
	
	// opens configure scenario/mapped scripts for load test run 
	this.openConfigureScenario = function(isFrom, moduleCardContent, mapScript, loadTestType) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/ltrun_configure_script.html',
			controller: 'ltRunConfigureScript',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				moduleCardContent: function() {
					return moduleCardContent;
				},
				ltScenarioData: function() {
					return mapScript;
				}, 
				testTypeScript: function() {
					return loadTestType;
				}
			}
		});
	};
	
	this.openAddOrEditSummaryNotes = function(isFrom, joSelectedSummaryCategory, joSelectedReport, joScriptDetails, loadTestType, callbackFn) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/addEditSummaryReportNotes.html',
			controller: 'addEditSummaryReportNotesController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return isFrom;
				},
				selectedSummaryCategory: function() {
					return joSelectedSummaryCategory;
				},
				selectedReport: function() {
					return joSelectedReport;
				},
				selectedScript: function() {
					return joScriptDetails;
				},
				testTypeScript: function() {
					return loadTestType;
				}
			}
		});
		
		modalInstance.result.then(function (bNotesSaved) {
			// callback fn. for notes saved
			if ( bNotesSaved ) {
				if ( callbackFn instanceof Function) {
					callbackFn();
				}
			}
		});
	};
	
	this.getSummaryReportCategoryNote = function(nRunId, category, nScriptId, successCallBack) {
		$http({
			method: 'POST',
			url: './lt/getSummaryReportCategoryNote',
			params: {
				runid: nRunId,
				category: category,
				scriptId: nScriptId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.saveSummaryReportCategoryNote = function(joSummaryCategory, joReport, nScriptId, nNoteId, notes, successCallBack) {
		var url = '', joParams = {};
		
		joParams = {
			runid: joReport.reportId,
			category: joSummaryCategory.value,
			scriptId: nScriptId,
			notes: notes
		};
		
		if ( nNoteId === null ) {
			// insert
			url = './lt/insertSummaryReportCategoryNote';
		} else {
			// update
			url = './lt/updateSummaryReportCategoryNote';
			joParams.noteId = nNoteId;
		}
		
		$http({
			method: 'POST',
			url: url,
			params: joParams
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
	
	this.getLoadTestRunSummaryReportNotes = function(nRunId, successCallBack) {

		$http({
			method: 'POST',
			url: './lt/getRunSummaryReportNotes',
			params: {
				runId: nRunId
			}
		}).success(function(data) {
			if (successCallBack instanceof Function) {
				successCallBack(data);
			}
		}).error(function(data) {
			console.log("Error in Ajax Call");
		});
	};
}]);
appedoApp.factory('serviceMapFactory', function() {
	return {
		defaultSliderOptions: {
			from: 1,
			to: 7,
			step: 1,
			scale: ["<div class='apd-xs-hide'>Last&nbsp;</div>15 mins","<div class='apd-xs-hide'>Last&nbsp;</div>30 mins", "<div class='apd-xs-hide'>Last&nbsp;</div>1 hr", "<div class='apd-xs-hide'>Last&nbsp;</div>3 hrs", "<div class='apd-xs-hide'>Last&nbsp;</div>6 hrs", "<div class='apd-xs-hide'>Last&nbsp;</div>12 hrs", "<div class='apd-xs-hide'>Last&nbsp;</div>1 day"],
			qry_intervals: ["15 minutes", "30 minutes", "1 hour", "3 hours", "6 hours", "12 hours", "1 day"],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			}
		}
	}
});

appedoApp.service('enterpriseService', ['$http', '$q', 'sessionServices', '$uibModal',  function($http, $q, sessionServices, $uibModal) {
	
	this.validateEnterpriseName = function($scope, enterpriseName, callback) {
		$http({
			method: 'POST',
			url: './apm/isValidEnterpriseName',
			params: {
				enterpriseName: enterpriseName,
				/*serviceMapId:serviceMapId*/
			}
		}).success(function(data) {
			if(callback) {
				callback(data);
			}
		});
	};
	
	this.addEnterpriseData = function($scope, enterpriseName, enterpriseDescription, callback) {
		$http({
			method: 'POST',
			url: './apm/addEnterpriseData',
			params: {
				enterpriseName: enterpriseName,
				enterpriseDescription: enterpriseDescription
			}
		}).success(function(data) {
			if(callback) {
				callback(data);
			}
		});
	};
	
	this.addUserEnterpriseMapping = function($scope, userDetails, EnterpriseId, enterpriseName, callback) {
		$http({
			method: 'POST',
			url: './apm/addUserEnterpriseMapping',
			params: {
				userDetails: userDetails,
				EnterpriseId: EnterpriseId,
				enterpriseName: enterpriseName
				/*serviceMapId:serviceMapId*/
			}
		}).success(function(data) {
			if(callback) {
				callback(data);
			}
		});
	};
	
	this.getMapUser = function(e_Id){
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'apm/getMappedUsers',
			params: {	
				e_Id: e_Id,
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);
  
        return deferredObject.promise;
	};
	
	this.deleteMapUser = function(e_Id, userName) {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: 'apm/deleteMapUser',
			params: {	
				e_id: e_Id,
				userName: userName
			}	
		}).success(deferredObject.resolve) 
		.error(deferredObject.resolve);

        return deferredObject.promise;
	};
	this.openUserEnterpriseMapping = function(e_Id, enterpriseData) {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/enterprise/user_mapping.html',
			controller: 'userEnterpriseMappingController',
			size: 'lg',
			resolve: {
				enterpriseId: function() {
					return e_Id;
				},
				enterpriseUserDetails: function() {
					return enterpriseData;
				}
			}
		});
	};
}]);

appedoApp.service('serviceMapService', ['$http', '$q', 'sessionServices',  function($http, $q, sessionServices) {
	
	this.myRootVar = {};
	
	this.getServiceMapData = function() {
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './service/getServiceMapData',
		}).success(deferredObject.resolve)
		.error(deferredObject.resolve);
  
		return deferredObject.promise;
	};
	
	this.getServicesData = function($scope, serviceAddData, callback) {
		$http({
			method: 'POST',
			//url: 'common/data/service_map.json'
			url: './service/getModulesTypesDetails',
			params: { 
				serviceMapId: serviceAddData.service_map_id || null,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(data) {
			$scope.servicesMap = data.message;
			$scope.$watch('serviceMapData.services', function() {
				if ($scope.serviceMapData.services != undefined) {
					if ($scope.serviceMapData.services.serviceType != undefined) {
						$scope.applicationData = $scope.serviceMapData.services.modules;
					}
				}
			});
		});
	};
	this.saveOrUpdateServiceMap = function($scope, params, url, callback) {
		$http({
			method: 'POST',
			url: url,
			params: params
		}).success(function(data) {
			if(callback) {
				callback(data);
			}
		});
	};
	
	this.getServiceMapCardData = function($scope, callback) {
		$http({
			method: 'POST',
			url: './service/getUserServiceMapsWithMapCountDetails'
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.deleteServiceMapRecord = function($scope, serviceMapId, callback) {
		$http({
			method: 'POST',
			url: './service/deleteServiceMap',
			params: {
				serviceMapId: serviceMapId
			}
		}).success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};
	
	this.validateServiceMapName = function($scope, serviceMapName, serviceMapId, callback) {
		$http({
			method: 'POST',
			url: './service/checkServiceNameExists',
			params: {
				serviceName: serviceMapName,
				serviceMapId:serviceMapId
			}
		}).success(function(data) {
			if(callback) {
				callback(data);
			}
		});
	};
	
	this.getUserServiceMaps = function($scope, callback) {
		$http({
			method: 'POST',
			url: './service/getUserServiceMaps'
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getServiceMapMappedModules = function($scope, nServiceMapId, callback) {
		$http({
			method: 'POST',
			url: './service/getServiceMapMappedModules',
			params: {
				serviceMapId: nServiceMapId
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getServiceMapMappedModuleSummaries = function(nServiceMapId, moduleCode, callback) {
		$http({
			method: 'POST',
			url: './service/getServiceMapMappedModuleSummaries',
			params: {
				serviceMapId: nServiceMapId,
				moduleCode: moduleCode
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getServiceMapsHealth = function(interval, nCustomStartDateTime, nCustomEndDateTime, callback) {
		$http({
			method: 'POST',
			url: './service/getServiceMapsHealth',
			params: {
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime 
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getServiceMaps = function(callback) {
		$http({
			method: 'POST',
			url: './service/getServiceMaps_v1',
			params: {
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getModuleCodeWiseHealth = function(nServiceMapId, interval, nCustomStartDateTime, nCustomEndDateTime, callback) {
		$http({
			method: 'POST',
			url: './service/getModuleCodeWiseHealth',
			params: {
				serviceMapId: nServiceMapId,
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime 
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getModulesCountersWiseHealth = function(nServiceMapId, moduleCode, healthCode, interval, nCustomStartDateTime, nCustomEndDateTime, callback) {
		$http({
			method: 'POST',
			url: './service/getModulesCountersWiseHealth',
			params: {
				serviceMapId: nServiceMapId,
				moduleCode: moduleCode,
				healthCode: healthCode,
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime 
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getModuleCounters = function(serviceMapId, referenceId, moduleCode, healthCode, interval, nCustomStartDateTime, nCustomEndDateTime, callback) {
		$http({
			method: 'POST',
			url: './service/getModuleCounters',
			params: {
				serviceMapId: serviceMapId,
				referenceId: referenceId,
				moduleCode: moduleCode,
				healthCode: healthCode,
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
	
	this.getModuleCountersData_v1 = function(serviceMapId, referenceId, moduleCode, healthCode, interval, nCustomStartDateTime, nCustomEndDateTime, callback) {
		$http({
			method: 'POST',
			url: './service/getModuleCounters_v1',
			params: {
				serviceMapId: serviceMapId,
				//referenceId: referenceId,
				moduleCode: moduleCode,
				healthCode: healthCode,
				interval: interval,
				startDateTime: nCustomStartDateTime,
				endDateTime: nCustomEndDateTime,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(function(data) {
			if(callback){
				callback(data);
			}
		});
	};
}]);
appedoApp.service('logViewService', ['$http', '$q', function($http, $q) {

	this.getLogCardsData = function(callback) {
		$http({
			method: 'POST',
			url: './log/getLogCardsData'
		}).success(function(data) {
			if (callback) {
				callback(data);
			}
		});
	};

	this.validateLogViewName = function($scope, logViewName, callback) {
		$http({
				method: 'POST',
				url: './log/validateLogViewName',
				params: {
					logName: logViewName
				}
			})
			.success(function(data) {
				if (callback instanceof Function) {
					callback(data);
				};
			});
	};

	this.getLogTypes = function($scope, callback) {
		$http({
			method: 'POST',
			url: './log/getLogTypes'
		}).success(function(data) {
			if (callback) {
				callback(data);
			}
		});
	};

	this.getUserIpAndPort = function($scope, callback) {
		$http({
			method: 'POST',
			url: './log/getUserIpAndPort'
		}).success(function(data) {
			if (callback) {
				callback(data);
			}
		});
	};

	this.getLogstashIPAndPort = function($scope, logViewId, callback) {
		$http({
			method: 'POST',
			url: './log/getLogstashIPAndPort',
			params: {
				logViewId: logViewId
			}
		}).success(function(data) {
			if (callback) {
				callback(data);
			}
		});
	};
	/*
	 *  to check whether a user already mapped a log
	 */
	this.ValidateBeforeAdd = function(callback) {
		$http({
			method: 'POST',
			url: './log/isUserMappedWithLog'
		}).success(function(data) {
			if (callback) {
				callback(data);
			}
		});
	};

	this.saveOrUpdateLogView = function($scope, params, url, callback) {
		$http({
			method: 'POST',
			url: url,
			params: params
		}).success(function(data) {
			if (callback) {
				callback(data);
			}
		});
	};

	this.deleteLogViewRecord = function($scope, logViewId, logName, callback) {
		$http({
			method: 'POST',
			url: './log/deleteLogViewRecord',
			params: {
				logViewId: logViewId,
				logName: logName
			}
		}).success(function(responseData) {
			if (callback) {
				callback(responseData);
			}
		});
	};

}]);
appedoApp.factory('chartModuleFactory', function() {
	
	return {
		sliderOptions: {
			from: 1,
			to: 7,
			step: 1,
			scale: ["Last 1 hr","Last 2 hrs", "Last 4 hrs", "Last 6 hrs", "Last 8 hrs", "Last 10 hrs", "Last 12 hrs"],
			qry_intervals: ["1 hour", "2 hours", "4 hours", "6 hours", "8 hours", "10 hours", "12 hours"],
			interval_in_hours: [1, 2, 4, 6, 8, 10, 12],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			}
		}
	};
});

appedoApp.service('chartViewService', ['$http', '$q','sessionServices', function($http, $q, sessionServices) {
	
/*	this.getServicesData = function($scope, serviceAddData) {
	    $http({
	        method: 'POST',
	        url: './chart/getModulesTypesDetails',
	        params: { 
	        	serviceMapId: serviceAddData.service_map_id || null
	        }
	    }).success(function(data) {
	        $scope.customizedCharts = data.message;
	        $scope.services=$scope.customizedCharts[0];
	        $scope.applicationData = $scope.customizedCharts[0].modules;
			$scope.module=$scope.applicationData[0];
			if( $scope.module != undefined ){
				 $scope.getAgentAllCategoryCounters();
			}
	    });
	};*/
	
	this.getServicesData = function($scope, serviceAddData, callback) {
	    $http({
	        method: 'POST',
	        url: './chart/getModulesTypesDetails',
	        params: { 
	        	serviceMapId: serviceAddData.service_map_id || null
	        }
	    }).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};

	this.getConfiguredCategories = function($scope, uid, type, callback) {
		$http({
			method: 'POST',
			url: 'chart/getCategories',
			params: {	
				uid: uid,
				type: type
			}
		}).success(function(responseData) {
			if(callback){
				callback(responseData);
			}
		});	
	};
	
	this.saveOrUpdateChartView = function($scope, params, url, callback) {
	    $http({
	        method: 'POST',
	        url: url,
	        params: params
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.deleteChartViewRecord = function($scope, chartViewId, callback) {
	    $http({
	        method: 'POST',
	        url: './chart/deleteChartView',
	        params: {
	        	chartViewId: chartViewId
	        }
	    }).success(function(responseData) {
	        if (callback) {
	            callback(responseData);
	        }
	    });
	};
	
	this.validateChartViewName = function($scope, chartViewName, chartViewId, callback) {
		$http({
	        method: 'POST',
	        url: './chart/checkChartViewNameExists',
	        params: {
	        	chartName: chartViewName,
	        	chartId:chartViewId
	        }
	    }).success(function(data) {
	        if(callback) {
	        	callback(data);
	        }
	    });
	};
	
	this.getChartCardData = function (callback){
		$http({
	        method: 'POST',
	        url: './chart/getChartCardData'
	    }).success(function(data) {
	    	if(callback){
	    		callback(data);
	    	}
	    });
	};
	
	this.getChartMultiLine = function(chartContent, interval, startDate, endDate) {
		//var t = JSON.parse(chartContent);
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './chart/getChartMultiLine',
			params: {
				chartContent: chartContent,
				interval: interval,
				startDate: startDate,
				endDate: endDate
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
        return deferredObject.promise;
	};
	
	this.getChartVisualizerData = function(uid, counterId, moduleType, counterTemplateId, moduleName, secRefId, secRefName) {
		//var t = JSON.parse(chartContent);
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './chart/getChartVisualData_v1',
			params: {
				uid : uid,
				counterId : counterId,
				moduleType : moduleType, 
				counterTemplateId : counterTemplateId,
				moduleName : moduleName,
				secRefId : secRefId,
				secRefName : secRefName
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
        return deferredObject.promise;
	};
	
	this.getChartVisualizerData_v1 = function(refId, counterId, moduleType, counterTemplateId, moduleName, secRefId, secRefName, category, interval, startDate, endDate, enterpriseData) {
		//var t = JSON.parse(chartContent);
		var deferredObject = $q.defer();
		$http({
			method: 'POST',
			url: './chart/getChartVisualizerData_v2',
			params: {
				refId : refId,
				counterId : counterId,
				moduleType : moduleType, 
				counterTemplateId : counterTemplateId,
				moduleName : moduleName,
				secRefId : secRefId,
				secRefName : secRefName,
				category : category,
				interval : interval,
				startDate : startDate,
				endDate : endDate,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			}
		}).success(deferredObject.resolve)
	 	.error(deferredObject.resolve);
		
        return deferredObject.promise;
	};
	
}]);

/*Accounts Modules services*/
appedoApp.service('userMetrics', ['$http', '$q', function($http, $q) {

    this.getUsageMetrics = function(code) {
        var deferredObject = $q.defer();
        $http({
			method: 'POST',
			url: 'credentials/getUsageMetrics',
			params: {
				code: code
			}
		}).success(deferredObject.resolve)
            .error(deferredObject.resolve);

        return deferredObject.promise;
    };

}]);

appedoApp.service('licenseServices', ['$http', '$q', function($http, $q) {
    this.getPricingDetails = function($scope, callback) {
        $http({
            method: 'POST',
            url: 'credentials/getAppedoPricing',
            params: {
                temp: -1
            }
        }).success(function(data) {
            if (callback) {
                callback(data);
            }
        });
    };

    this.getGatewayDetails = function($scope, callback, failureCallback) {
        $http({
            method: 'POST',
            url: './getGatewayDetails',
        }).success(function(data) {
            if (callback) {
                callback(data);
            }
        }).error(function(data) {
            if (failureCallback) {
                failureCallback(data);
            }
        });
    };
    
    this.getPricingCommonDetails = function($scope) {
        var promise = $http({
            method: 'POST',
            url: 'common/data/admin_pricing_common_data.json'
        }).success(function(data) {
            return data;
        });
        return promise;
    };

    this.getLicesingEmails = function($scope, callback) {
        var deferredObject = $q.defer();
        $http({
                method: 'POST',
                url: 'credentials/getLicesingEmails'
            }).success(deferredObject.resolve)
            .error(deferredObject.resolve);

        return deferredObject.promise;
    };
    
    this.updateUserLicese = function($scope, params, callback) {
    	$http({
            method: 'POST',
            url: 'credentials/updateLicesense',
            params: params
        }).success(function(data) {
            if (callback) {
                callback(data);
            }
        });
    };
    var formattedStartDate = '';
	var formattedEndDate = '';
	this.getFormattedStartDate = function() {
		return formattedStartDate;
    };
    this.getFormattedEndDate = function() {
		return formattedEndDate;
    };
    this.getformatedDate = function (startDate, endDate) {
    	var stDate = startDate+' 00:00:00';
	    var enDate = endDate+' 23:59:59';
	    if (isdate(stDate)==1){
	    	formattedStartDate=formatDate(stDate, 'st');
	    }
		else {
			formattedStartDate = stDate.toString();
			/*var ctDate = new Date();
	    	if(formattedStartDate < ctDate) {
	    		formattedStartDate = ctDate;
	    	}*/
		}
		if (isdate(enDate)==1){
			formattedEndDate=formatDate(enDate, 'ed');}
		else {
			formattedEndDate = enDate.toString();
		}

		function formatDate(date, ct)
		{
		    var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
		    var splitDate = date.split("-");
		    //var convertedDate=new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
		    var convertedDate=splitDate[0]+"/"+monthInNumber[splitDate[1]]+"/"+splitDate[2];
		    /*if(ct == "st"){
		    	var ctDate = new Date();
		    	if(convertedDate < ctDate) {
		    		convertedDate = ctDate;
		    	}
		    }*/
		    return convertedDate;
		}
		function isdate(val)
		{
			var date = Date.parse(val);
			if(isNaN(date))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
    };
    
    this.getLicesenseDetails = function($scope, emailId, callback) {
    	$http({
            method: 'POST',
            url: 'credentials/getLicesenseDetails',
            params: {
            	email_id: emailId
            }
        }).success(function(data) {
            if (callback) {
                callback(data);
            }
        });
    };

    
    // 
    this.updateUserAccessRights = function(emailId, useLiceseManagement, useUsageMetric) {
        var deferredObject = $q.defer();

        $http({
            method: 'POST',
            url: './updateUserAccessRights',
            params: {
            	emailId: emailId,
            	useLiceseManagement: useLiceseManagement,
            	useUsageMetric: useUsageMetric
            }
        }).success(deferredObject.resolve)
        .error(deferredObject.resolve);

        return deferredObject.promise;
	};
	

    this.getUsersAdminPrivilege = function() {
    	var deferredObject = $q.defer();

        $http({
            method: 'POST',
            url: './getUsersAdminPrivilege'
        }).success(deferredObject.resolve)
        .error(deferredObject.resolve);

        return deferredObject.promise;
	};
	
	this.getLicesenseMonthWiseDetails = function($scope, params, callback) {
    	$http({
            method: 'POST',
            url: 'credentials/getLicesenseMonthWiseDetails',
            params: params
        }).success(function(data) {
            if (callback) {
                callback(data);
            }
        });
    };
    
    this.getTopUpDetails = function($scope, params, callback) {
    	$http({
            method: 'POST',
            url: 'credentials/getTopUpDetails',
            params: params
        }).success(function(data) {
            if (callback) {
                callback(data);
            }
        });
    };
    
    var licenseData = {};
    this.setLicenseData = function(data) {
        licenseData = data;
    };
    this.getLicenseData = function() {
        return licenseData;
    };

	
	this.getLicenseExpiredUsers = function(callback) {
		
		$http({
			method: 'POST',
			url: './getLicenseExpiredUsers'
        }).success(function(data) {
            if (callback instanceof Function) {
                callback(data);
            }
        });
	};
	
	this.getLicenseWillExipreUsers = function(nExpireInNextDays, callback) {
		
		$http({
			method: 'POST',
			url: './getLicenseWillExipreUsers',
			params: {
				expireInNextDays: nExpireInNextDays
			}
        }).success(function(data) {
            if (callback instanceof Function) {
                callback(data);
            }
        });
	};
}]);
//end of Accounts Module Services

appedoApp.service('gsModuleMethod', function() {
	var setMethod ={};
	this.setM = function (setValue){
		console.info("SetValue: "+setValue)
		this.SetMethod=setValue;
		console.info("setMethod :"+this.setMethod);
	};
	this.getM = function(){return setMethod;};
});
appedoApp.factory('forDateTimeModuleMethod',['$rootScope', function($rootScope) {
	var moduleValue ={};
	return {
		getMethod : function(){
			return moduleValue.sv;
		},
		setMethod : function(sv){
			moduleValue.sv=sv;
			$rootScope.$broadcast("updateMethod");
		},
		setStDate : function(std) {
			moduleValue.std=std;
			$rootScope.$broadcast("updateMethod");
		},
		getStDate : function(){
			return moduleValue.std;
		},
		setEndDate : function(end_date) {
			moduleValue.endD=end_date;
			$rootScope.$broadcast("updateMethod");
		},
		getEndDate : function() {
			return moduleValue.endD;
		}
	};
}]);

appedoApp.factory('asdSliderFactory', function() {
	return {
		defaultSliderOptions: {
			from: 1,
			to: 7,
			step: 1,
			scale: ["Last 1 hr","Last 24 hrs", "Last 7 days", "Last 15 days", "Last 30 days", "Last 60 days", "Last 120 days"],
			qry_intervals: ["1 hour", "1 day", "7 days", "15 days", "30 days", "60 days", "120 days"],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			}
		},
		profilerSliderOptions: {
			from: 1,
			to: 4,
			step: 1,
			scale: ["Last 1 hr", "Last 24 hrs", "Last 7 days", "Last 15 days"],
			qry_intervals: ["1 hour", "1 day", "7 days", "15 days"],
			css: {
				after: {"background-color": "#42A6DB"},
				pointer: {"background-color": "#42A6DB"}
			}
		}
	};
});
