appedoApp.controller('login_controller', ['$scope', '$rootScope', 'sessionServices', 'loginServices', '$http', '$state', '$location', 'messageService', '$timeout', function($scope, $rootScope, sessionServices, loginServices, $http, $state, $location, messageService, $timeout) {
	$scope.issessinExist = function() {
		var session = loginServices.validateLoginUser();
		session.then(function(data) {
			if( data.success ) {
				$state.transitionTo('/loginResponse');
			} else {
				if( $location.path() == '/login_downtime_restrictedAccess' ) {
					$state.transitionTo('/login_downtime_restrictedAccess');
				}/*
				commented, thinks, `login_controller` is called for '/login', when session deosn't exists user already available in '/login', 
				 transition within same transition (ie.. `/login` within `/login`) is avoided, 
				else{
					$state.transitionTo('/login');
					// since to show error message of HttpSession doesn't exsits, URL query string doesn't works with state params, tried `window.location.href`
					//window.location.href = '#/loginResponse?_err=9';
				}*/
			}
		});
	};
	$scope.issessinExist();
	 
	$scope.loginData = {};
	$scope.showErrorMsg = false;
	$scope.showSuccessMsg = false;
	
	// 
	$scope.loginData.email = sessionServices.get("emailId") || '';
	sessionServices.destroy("emailId");
	
	if (sessionServices.get("errorMsg") != "" && sessionServices.get("errorMsg") != undefined){
		$scope.showErrorMsg = true;
		$scope.errorMsg = sessionServices.get("errorMsg");
		sessionServices.destroy("errorMsg");
		messageService.showErrorMessage($scope.errorMsg.replace('@appln_heading@', $rootScope.appedoWhiteLabels.appln_heading).replace('@support_emailid@', $rootScope.appedoWhiteLabels.support_emailid));

		/*
		$scope.loginData.email = sessionServices.get("emailId") || "";
		sessionServices.destroy("emailId");
		 */
	} else if (sessionServices.get("successMsg") != "" && sessionServices.get("successMsg") != undefined){
		$scope.showSuccessMsg = true;
		$scope.successMsg = sessionServices.get("successMsg");
		sessionServices.destroy("successMsg");
		messageService.showSuccessMessage($scope.successMsg.replace('@appln_heading@', $rootScope.appedoWhiteLabels.appln_heading).replace('@support_emailid@', $rootScope.appedoWhiteLabels.support_emailid));
	}
	$scope.alertCall = function() {
		$scope.show = true;
		$timeout(function(){
			$scope.show = false;
		}, 5000);
	};	
	
}]);

appedoApp.controller('Message_controller', function($scope, $uibModalInstance, $timeout, data){
	
	$scope.data = data;
	
	$timeout(function() {
		$uibModalInstance.close($scope.data);
	}, 6000);

	$scope.close = function(result){
		$uibModalInstance.close($scope.data);
	};
});

appedoApp.controller('loading_controller', function($scope, $rootScope, $uibModalInstance, $timeout/*, data*/){
	var Loader = $rootScope.$on("disable_Loader", function(event){
		$uibModalInstance.close($scope.data);
	});
});
appedoApp.controller('login_response_controller', ['$scope', '$rootScope', '$state', '$location', 'sessionServices', 'userServices',  function($scope, $rootScope, $state, $location, sessionServices, userServices) {
	var errorMesages = ["Invalid Email Id and Password", "Email Id and password do not match", "Please verify your inbox/spam/junk for the verification mail.\nClick on the link given in the email before you login. &nbsp;<a class='btn btn-success btn-sm' href='./resendEmailVerfication?emailId={{emailId}}&fromLogin=true' >Re-Send Verification Mail</a>", "Email doesn't exists", "Your account is inactive. Please contact @support_emailid@ for further clarifications.", "E-mail Verification failed", "Password mismatch.", "Link is expired.", "Session expired. Please re-login.", "Problem with services.", "Unable to send an email verfication.", "Verification link has been expired. &nbsp;<a class='btn btn-success btn-sm' href='./resendEmailVerfication?emailId={{emailId}}&fromLogin=true' >Re-Send Verification Mail</a>", "Password reset link has been expired. &nbsp;<a class='btn btn-success btn-sm' href='./forgotPassword?emailId={{emailId}}' >Re-Send</a>"];
	var arySuccessMessages = ["Email is sent with reset link. Check your inbox/spam/junk.", "Check your inbox/spam/junk for the verification mail.\nClick on the link given in the email.", "Your mail has been verified. Check your inbox/spam/junk, to download SUM agent.", "Your mail has been verified.", "Logged out Successfully.\nIt is better to close all other @appln_heading@ window(s).", "Password Changed Successfully"]; 
	
	if ( Object.keys($location.search()).length > 0 ) {
   		// redirects to login page
   		var emailId = $location.search().emailId;
   		sessionServices.set("emailId", emailId || "");
   		
   		if( $location.search()._err != undefined ){
   			var nErrIdx = $location.search()._err-1;
   	   		sessionServices.set("errorMsg", nErrIdx === 2 || nErrIdx === 11 || nErrIdx === 12 ? errorMesages[nErrIdx].replace('{{emailId}}', emailId) : errorMesages[nErrIdx]);
   	   		
   	   	    //sessionServices.set("emailId",$location.search().emailId || "");
   	   	} else if ( $location.search()._smsg != undefined ) {
   	   		var nSuccessIdx = $location.search()._smsg - 1;
   	   		sessionServices.set("successMsg", arySuccessMessages[nSuccessIdx]);
   	   		
   	   		// for logout successfull, clears loginUserSession from sessionStorage
   	   		if ( nSuccessIdx === 4 ) {
   	   			sessionServices.destroy("loginUser");
   	   			sessionServices.destroy("currentModule");
   	   			sessionServices.destroy("selectedEnterprise");
   	   			sessionServices.destroy("cardRefreshTime");
   	   		}
   	   	}
   		$state.transitionTo('/login');
   	} else {
   		// redirects to dashboard,
   		userServices.getLoginUserDetails(function(data) {
   			if ( ! data.success ) {
   				// err
   			} else {
   				var joLoginUserDetails = data.message;
   				
   				// to show message, license is expired and degraded as level0
   				if( joLoginUserDetails.hasLicenseDegradedToLevel0 ) {
   					//messageService.showWarningMessage('License got expired, so degraded as Lite.<BR/>Please contact <STRONG>'+$scope.appedoWhiteLabels.support_emailid+'</STRONG>', {dismissOnTimeout: false, dismissOnClick: false, additionalClasses: 'apd-alert-msg'});
   				}
   				
   				// sets loginuser details in sessionStorage
   				sessionServices.set('loginUser', JSON.stringify(joLoginUserDetails));
   			}
   		});
   		$state.transitionTo('/dashboard');
   	}

	// clears user signup data
	$scope.$on('$destroy', function() {
		sessionServices.destroy('signUpErrorMsg');
		sessionServices.destroy('userSignUpData');
	});
}]);

/*appedoApp.controller( 'dashBoard-controller', ['$scope', function( $scope ) {

	$scope.app_health="good";
    $scope.server_health="good";
    $scope.database_health="good";
}]);
*/ 

appedoApp.controller( 'header_controller', ['$scope', '$state', '$filter', '$rootScope', 'messageService', '$location', 'sessionServices', 'userServices', 'loginServices', function( $scope, $state, $filter, $rootScope, messageService, $location, sessionServices, userServices, loginServices) {

	//var i = 0;
	//loginServices.validateLoginUser();
	$scope.selectedEnterprise = {};
    var emailIds = ["sales_test@appedo.com", "sales_test@softsmith.com"];
    
    $rootScope.isEnterpriseSelected = false;
    
	$scope.user = { showRuleActionView: true };

	$scope.showSimpleToast = function() {
		messageService.showSuccessMessage("Testing Message Will process");

	};

	$scope.loginUser = JSON.parse(sessionServices.get('loginUser'));
	// loggedin user's to have defaults
	if ( $scope.loginUser != null ) {
		haveUserDefaults();
	}
	    
	$scope.issessinExist = function() {
		var session = loginServices.validateLoginUser();
		session.then(function(data) {
			if( ! data.success ) {
				// session doesn't exists
				if( $location.path() == '/login_downtime_restrictedAccess' ) {
					$state.transitionTo('/login_downtime_restrictedAccess');
				} else {
					//$state.transitionTo('/login');
					// since to show error message of HttpSession doesn't exsits, URL query string doesn't works with state params, tried `window.location.href`
					window.location.href = '#/loginResponse?_err=9';
					$rootScope.$emit('disable_Loader');
				}
			} else {
				// loads loginUserBean details 
				userServices.getLoginUserDetails(function(data) {
					if ( ! data.success ) {
						// err
					} else {
						$scope.loginUser = data.message;
						
						//console.log("in session Exist loginDetails "+ JSON.stringify($scope.loginUser));
						// sets loginUser details in sessionStorage
						sessionServices.set('loginUser', JSON.stringify($scope.loginUser));
						
						// loggedin user's to have defaults
						haveUserDefaults();
					}
				});
			}
		});
	};
	$scope.issessinExist();
	
	if ($location.path() == "/dashboard" || $location.path() == "/moduleDetails") {
		$scope.showDropdownEnt = true;
	}else{
		$scope.showDropdownEnt = false;
	}
	
	$scope.getEntDetails = function(){
		var enterpriseData = $scope.selectedEnterprise;
		console.log(enterpriseData);
		
		sessionServices.set("selectedEnterprise",JSON.stringify($scope.selectedEnterprise));
		if(JSON.parse(sessionServices.get("selectedEnterprise")).e_id !=0){
			$rootScope.isEnterpriseSelected = true; 
		}else{
			$rootScope.isEnterpriseSelected = false;
		}
		sessionServices.destroy('selectedAppCardContent');
		if ($location.path() == "/dashboard" ) {
			$rootScope.$emit('call_ent_Details_dashboard', enterpriseData);
		} else if ($location.path() == "/moduleDetails" ) {
			$rootScope.$emit('call_ent_Details', enterpriseData);
		}
	};
	
	/*console.log(sessionServices.get("selectedEnterprise"));
	if(sessionServices.get("selectedEnterprise") == null){
		sessionServices.set("selectedEnterprise", JSON.stringify({"e_id":0,"e_name":"Select Enterprise","e_user_id":"None","is_owner":true}));
		console.log(sessionServices.get("selectedEnterprise"));
	}*/
	
	
	function getEnterpriseLicense(){
		userServices.getEnterpriseLicense(function(data) {
			if ( ! data.success ) {
				// err
			} else {
				$scope.enterpriseLicense =[];
				if(data.message.length > 0){
					$scope.enterpriseLicense = data.message;
					$scope.enterpriseLicense.splice(0, 0, {"e_id":0,"e_name":"Select Enterprise","e_user_id":"None","is_owner":true});
					console.log(sessionServices.get("selectedEnterprise"));
					if(sessionServices.get("selectedEnterprise") == undefined){
						sessionServices.set("selectedEnterprise",JSON.stringify($scope.enterpriseLicense[0]));
					}
					var selected_e_id = JSON.parse(sessionServices.get("selectedEnterprise")).e_id;
					var arr_pos = $filter('filter')($scope.enterpriseLicense, {e_id: selected_e_id}, true)[0];
					$scope.selectedEnterprise = $scope.enterpriseLicense[$scope.enterpriseLicense.indexOf(arr_pos)];
					if (selected_e_id > 0) {
						$rootScope.isEnterpriseSelected = true;
					}
					console.info(JSON.parse(sessionServices.get("selectedEnterprise")).e_id);
					console.info("indexof");
					console.info(arr_pos);
				}else{
					sessionServices.set("selectedEnterprise", JSON.stringify({"e_id":0,"e_name":"Select Enterprise","e_user_id":"None","is_owner":true}));
					$rootScope.isEnterpriseSelected = false;
				}
				
			}
		}); 
	}
	getEnterpriseLicense();
	
	
	// user's defaults 
	function haveUserDefaults() {
		/*
		 * redirect to dashboard, if user is FREE and access `load_test` page,
		 *   since thinks `header_controller` is called on most html pages redirects
		 */
		if ( $scope.loginUser.License === 'level0' && $location.path() === '/load_test' ) {
			$state.transitionTo('/dashboard');
		}
		
		// thinks, for SLA Action & Rule are shown for `sales` emailids
		if( emailIds.indexOf( $scope.loginUser.emailId ) >= 0 ){
			$scope.user.showRuleActionView = true;
		} else {
			$scope.user.showRuleActionView = false;
		}
		
		// sets user details for CI (production use)
/*		Appedo_CI.setUserProps({
			user_first_name: $scope.loginUser.firstName, 
			user_last_name: $scope.loginUser.lastName,
			email_id: $scope.loginUser.emailId,
			mobile_no: ''
		});*/
	}
	
	//Jmeter Upload function
	$scope.uploadJmeterScript = function(elem) {
		userServices.uploadJmeterScript($scope, elem, './lt/uploadJmeterScript', function(data){

			if(data.success){
				messageService.showSuccessMessage(data.message);
				sessionServices.set("currentModule", "AppedoLT Script");
				$state.transitionTo('/moduleDetails/:_dc', {'_dc': (new Date().getTime())});
				//successMsgService.showSuccessOrErrorMsg(data);
			}else{
				//successMsgService.showSuccessOrErrorMsg(data);
				messageService.showErrorMessage(data.errorMessage);
			}
		});
	};

	/*$scope.downloadLog = function() {
		console.log("inside download log");
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/log/download_log_module.html',
			controller: 'log_module_controller',
			size: 'lg',
			backdrop : 'static'/*,
			resolve: {
				moduleCardContent: function() {
					return $scope.moduleCardContent;
				}
			}
		});
	} */
	
}]);

/*appedoApp.controller('log_module_controller','$uibModal', '$uibModalInstance', [function ($scope, $uibModal,$uibModalInstance) {

console.log("inside log module controller");

$scope.close = function () {
	$uibModalInstance.dismiss('cancel');
};

}]); */

appedoApp.controller('signup_controller', ['$scope', '$state', '$location', '$timeout', 'sessionServices', 'userServices', 'messageService', function($scope, $state, $location, $timeout, sessionServices, userServices, messageService) {

	$scope.signupData = {};
	
	$scope.showSignupErrorMsg = false;
	$scope.showSignupSuccessMsg = false;
	
	$scope.signupErrorMsg = '';
	$scope.signupSuccessMsg = '';
	
	var joUserSignUpData = {};
	$scope.countriesCode = [];
	
	$scope.alertCall = function() {
		$scope.show = true;
		$timeout(function(){
			$scope.show = false;
		}, 5000);
	};
	  
	// sets user sign up data in form ngModel
	if ( sessionServices.get("userSignUpData") != null ) {
		joUserSignUpData = JSON.parse(sessionServices.get("userSignUpData"));
		$scope.signupData.email = joUserSignUpData.emailId;
		$scope.signupData.firstName = joUserSignUpData.firstName;
		$scope.signupData.lastName = joUserSignUpData.lastName;
		$scope.signupData.phoneNumber = joUserSignUpData.mobileNo;
	}
	
	if ( sessionServices.get("signUpErrorMsg") != "" && sessionServices.get("signUpErrorMsg") != undefined){
		$scope.showSignupErrorMsg = true;
		$scope.signupErrorMsg = sessionServices.get("signUpErrorMsg");
	} else if ( sessionServices.get("signUpSuccessMsg") != null ) {
		$scope.showSignupSuccessMsg = true;
		$scope.signupSuccessMsg = sessionServices.get("signUpSuccessMsg");
	}

	// Checked Retype Password
	$scope.checkPassword = function() {
		if($scope.signupData.pwd != $scope.signupData.retypePwd) {
			messageService.showErrorMessage("Password doesn't match");
			$scope.signupForm.pwd = true;
		}else {
			$scope.signupForm.pwd = false;
		}
		
	};
	
	// check Email_id invalid format 
	$scope.showMessage = function() {
		messageService.showWarningMessage("Email Address in invalid format");
		
	};
	
	//alert Message first Name Filed
	$scope.firstNameAlert = function() {
		if($scope.signupData.firstName == null ) {
			messageService.showWarningMessage("First name must be mandatory");
		}
	};
	
	//alert Message for Last Name Filed
	$scope.lastNameAlert = function() {
		if($scope.signupData.lastName == null ) {
			messageService.showWarningMessage("Last name must be mandatory");
		}
	};
	
	$scope.fullNameAlert = function() {
		if($scope.signupData.lastName == null || $scope.signupData.firstName == null ) {
			messageService.showWarningMessage("firstname and lastname mandatory");
		}
	};
	
	$scope.onlyDigits = function() {
		$scope.signupData.phoneNumber = $scope.signupData.phoneNumber.replace(/[^0-9]/g, '');
	};
	
	// check weather the email is `valid` (Already exists), `invalid` (New Email) OR `notverified` (Exists but not verified)
	$scope.validateEmailExists = function() {
		if ( $scope.signupData.email ) {
			userServices.isExistedUser($scope.signupData.email, function(resp){
				if ( resp.success ) {
					$scope.signupData.emailStatus = resp.isUserExist;
					
					if($scope.signupData.emailStatus == 'valid') {
						messageService.showWarningMessage("Email-Id is already registered, login to sign in.");
					}else if($scope.signupData.emailStatus == 'notverfied'){
						messageService.showWarningMessage("Email-Id is already registered, check your email to verify.");
					}
				}else {
					messageService.showWarningMessage("Problem With Services");
				}
			});
		}
	};

	// To get phone numbers.
	userServices.getCountryCodeDetails(function(data) {
		if ( ! data.success ) {
			// Error
		} else {
			$scope.countriesCode = data.message;
			$scope.telephoneCode = $scope.countriesCode[1].telephone_code;
		}
	});	
	
	// resend verification mail for the user 
	$scope.resendEmailVerification = function() {
		userServices.resendEmailVerification($scope.signupData.email, function(resp) {
			if ( ! resp.success ) {
				//error
			} else {
				// success
				messageService.showSuccessMessage('');
			}
		});
	};
	
	//
	$scope.$on('$destroy', function() {
		sessionServices.destroy('signUpErrorMsg');
		sessionServices.destroy('signUpSuccessMsg');
		sessionServices.destroy('userSignUpData');
	});
}]);

appedoApp.controller('resetPassword_controller', ['$scope', '$state', '$location', 'sessionServices', function($scope, $state, $location, sessionServices) {

	$scope.userData = {
		uid: $location.search().uid,
		vh_id: $location.search().vh_id,
		email: $location.search().email
	};
	
	
	$scope.pwdSubmit = false;
	$scope.checkPassword = function(){
		if($scope.password != $scope.retype_password)
		{
			$scope.userAlert = "Password and re-entered password not matching.";
			$scope.pwdSubmit = true;
		}else{
			$scope.pwdSubmit = false;
		}
	};
}]);


appedoApp.controller('alert_controller',['$timeout', function ($scope, $timeout) {

		$scope.alertCall = function() {
			$scope.show = true;
			console.info("hello timeout!");
			$timeout(function(){
				$scope.show = false;
				console.info("timeout!");
				console.log($scope.show);
			}, 5000);
		};

	}]);

appedoApp.controller('userProfileController', ['$scope', 'userServices', 'sessionServices', '$timeout', function ($scope, userServices, sessionServices, $timeout) {
		$scope.userProfile = {};
		$scope.showErrorMsg = false;
		$scope.showSuccessMsg = false;
	    
		
		function getMyProfileDetailsSuccessCallback(response) {
			if(response.success) {
				$scope.userProfile = response.message;
			} 
		}

		userServices.getMyProfileDetails($scope, getMyProfileDetailsSuccessCallback);
		
	    
		if (sessionServices.get("errorMsg") != "" && sessionServices.get("errorMsg") != undefined){
			$scope.showErrorMsg = true;
			$scope.errorMsg = sessionServices.get("errorMsg");
			//$scope.loginData.email = sessionServices.get("emailId");
			sessionServices.destroy("errorMsg");
		} else if (sessionServices.get("successMsg") != "" && sessionServices.get("successMsg") != undefined){
			$scope.showSuccessMsg = true;
			$scope.successMsg = sessionServices.get("successMsg");
			sessionServices.destroy("successMsg");
		}
		
		$scope.alertCall = function() {
			$scope.show = true;
			console.info("hello timeout!");
			$timeout(function(){
				$scope.show = false;
				console.info("timeout!");
				console.log($scope.show);
			}, 5000);
		};

	}]);

	appedoApp.controller('userProfileResponseController', ['$scope', '$state', '$location', 'userServices', 'sessionServices', function ($scope, $state, $location, userServices, sessionServices) {
	   	var arySuccessMessages = ["Profile updated."];
		var aryErrorMesages = ["Unable to Update Profile.", "Problem with Services."];

		if(Object.keys($location.search()).length>0){
	   		$state.transitionTo('/profileSettings');
	   		
	   		if( $location.search()._err != undefined ){
	   			sessionServices.set("errorMsg", aryErrorMesages[$location.search()._err-1]);
	   	   	} else {
	   	   		sessionServices.set("successMsg", arySuccessMessages[$location.search()._smsg-1]);
	   	   	}
	   	}
	}]);

	appedoApp.controller('changePasswordController', ['$scope', 'sessionServices', 'userServices', '$timeout', 'messageService', function($scope, sessionServices, userServices, $timeout, messageService) {
		//$scope.loginData = {};
		$scope.showErrorMsg = false;
		$scope.showSuccessMsg = false;
		
	   	var arySuccessMessages = ["Password changed Successfully"];
		var aryErrorMesages = ["Old Password doesn't match.", "New & Retype Password doesn't match.", "Problem with Services."];

		// used in ng-model
		$scope.userPasswordDetails = {};
		
		//messageService.showInfoMessage("Payment Successfully");
		$scope.changePassword = function() {
			userServices.changePassword($scope.userPasswordDetails, function(data){
				if ( data.success ) {
					// password changed successfully 

					if ( ! isNaN( data.message )) {
						$scope.showSuccessMsg = true;
						$scope.successMsg = arySuccessMessages[parseInt(data.message) - 1];
						messageService.showSuccessMessage($scope.successMsg);
					}
					
					// signout
					userServices.signOut();
				} else {
					// err

					// is Not a Number
					if ( ! isNaN( data.errorMessage )) {
						$scope.showErrorMsg = true;
						$scope.errorMsg = aryErrorMesages[parseInt(data.errorMessage) - 1];
						messageService.showErrorMessage($scope.errorMsg);
					}
				}
			});
		};

		$scope.retypemsg = function() {
			messageService.showErrorMessage("Password doesn't match");
		};

		$scope.alertCall = function() {
			$scope.show = true;
			console.info("hello timeout!");
			$timeout(function(){
				$scope.show = false;
				console.info("timeout!");
				console.log($scope.show);
			}, 5000);
		};
		
		//messageService.showInfoMessage("Payment Successfully");
		//alertService.add('success', 'Your account information has been successfully updated');
		
		//alertService1.ShowAlert();

	}]);

appedoApp.controller('moduleDetailsController', ['$scope', '$rootScope', '$uibModal', 'cardDetailsServices', 'sessionServices', '$interval', '$state', 'avmModuleServices', 'messageService', 'ajaxCallService', 'ltFactory', '$filter', '$rootScope',
                                                 function($scope, $rootScope, $uibModal, cardDetailsServices, sessionServices, $interval, $state, avmModuleServices, messageService, ajaxCallService, ltFactory, $filter, $rootScope) {

	$scope.openAddModuleType = function () {
		$interval.cancel($scope.refreshTimerSet);
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
//			backdrop : 'static'
			resolve: {
				moduleType: function() {
					//return $scope.moduleType.name;
					return $scope.moduleType.module_type;
				}
			}
		});
	};
	
	$scope.enterpriseData = JSON.parse(sessionServices.get("selectedEnterprise"));
	$scope.loginUserData = JSON.parse(sessionServices.get('loginUser'));
	// appedo modules to have based on user license
	$scope.options = cardDetailsServices.getModulesOptions($scope.loginUserData);
	
	//clear chart tooltip
	if (document.querySelector('.apd-chart-tooltip') != null) {
		console.info("chart tooltip clear");
    	//d3.select("#tooltip"+attrs.idx).remove();
		$('.apd-chart-tooltip').remove();
    }
	
	$scope.cardDetails;
	$scope.testcard_details;
							
	$scope.aryCardFilter = $scope.options; 

	if(sessionServices.get("currentModule")){
		console.info("current Module");
		console.log(sessionServices.get("currentModule"));
		var arr_pos = $filter('filter')($scope.aryCardFilter, {displayName: sessionServices.get("currentModule")}, true)[0];
		console.info(arr_pos);
		if(arr_pos == undefined){
			$scope.moduleType = $scope.aryCardFilter[0];
		}else{
			$scope.moduleType = $scope.aryCardFilter[$scope.aryCardFilter.indexOf(arr_pos)];
		}
	}else{
		$scope.moduleType = $scope.aryCardFilter[0];
	}

	
	var moduleTypeName = 'OAD';
	$scope.testCardData;
	$scope.cardStatus;
	
	//$scope.currentModule = "Applications";
	$scope.openModuleDetailGrpahs = function(Type) {
		$scope.currentModule = this.joValCard.col_1.var4;
		sessionServices.set("selectedModule",$scope.currentModule);
		sessionServices.set("selectedAppCardContent", JSON.stringify(this.joValCard));
		sessionServices.set("RadioOption", Type);
		
		if ($scope.currentModule == 'LOG') {
			$state.transitionTo('/log_details');
		} else if ($scope.currentModule == 'RUM') {
			sessionServices.set("RadioOption", 'MONITOR');
			$state.transitionTo('/rum_details');
		} else if($scope.currentModule == 'Service Map') {
			$state.transitionTo('/dashboard');
		} else {
			$state.transitionTo('/apm_details');
		}
	};
	
	$scope.openSUMDetailGrpahs = function(Type) {
		$scope.currentModule = this.joValCard.col_1.var4;
		sessionServices.set("selectedModule",$scope.currentModule);
		sessionServices.set("selectedAppCardContent", JSON.stringify(this.joValCard));
		sessionServices.set("RadioOption", Type);
		
		if ($scope.currentModule == 'SUM') {
			$state.transitionTo('/apm_details');
		}else{
			$state.transitionTo('/moduleDetails');
		}
	};
	
	// loads module description content
	function getModuleDescriptionContent() {
		ajaxCallService.getJsonData('common/data/module_content_avm.json', function(responseData){
			aryModuleDescriptionContents = responseData;
		});
	};
	//getModuleDescriptionContent();
	
	//AlertPolicy
	// activate or deactivate SLA policy
	$scope.enableOrDisableSLAPolicy = function() {
		var joSLA = this.joValCard;
		var result = confirm("Are you sure you want to "+(joSLA.isActive ? 'disable' : 'enable' )+" the alert?");
		if(result == true) {
			cardDetailsServices.enableOrDisableSLAPolicy($scope, joSLA.sla_id, ! joSLA.isActive, function(data) {
				if( ! data.success ) {
					// error
					messageService.showErrorMessage(data.errorMessage);
				} else {
					messageService.showSuccessMessage(data.message);
					
					// reload SLA card data
					//$scope.getSlaPolicyCardData();
					$scope.getCardDetails();
				}
			});
		}
	};


	
	$scope.searchText;
	
	// Test for Card Layout data from DataBase.
	$scope.getCardDetails = function() {
		messageService.loading();
		cardDetailsServices.populateCardData($scope, $scope.moduleType.name, $scope.enterpriseData, function(response) {
			if(!response.success) {
				messageService.showErrorMessage(response.errorMessage);
				$rootScope.$emit('disable_Loader');
			}else {
				sessionServices.set("currentModule", $scope.moduleType.displayName);
				$interval.cancel($scope.refreshTimerSet);
				refreshTimer();
								
				var cardData = response.message;
				if($scope.moduleType.name == "Avl Monitoring" || $scope.moduleType.name == "Avl Location" || $scope.moduleType.name == "LT Scripts" || $scope.moduleType.name == "LT Scenarios" || $scope.moduleType.name == "LT Variables" || $scope.moduleType.name == "Service Map" || $scope.moduleType.name == "Alert User" || $scope.moduleType.name == "Alert System" ||  $scope.moduleType.name == "Alert RUM" ||  $scope.moduleType.name == "Alert SUM") {
					$scope.testCardData = cardData;
					//sessionServices.set("currentModule", $scope.testCardData.col_1.var4);
					//getModuleDescriptionContent();
					if($scope.moduleType.name == "Avl Monitoring") {
						$scope.getUserApplicationsStatus();
					} else if($scope.moduleType.name == "Avl Location") {
						$scope.getUrlDownStatus();
						getModuleDescriptionContent();
					}
				} else if($scope.moduleType.name == "RUM") {
					$scope.testCardData = cardData.moduleData;
					//sessionServices.set("currentModule", $scope.testCardData.col_1.var4);
					$scope.cardRUMStatus = cardData.moduleRUMStatus;
					getRUMRunningStatus();
				} else {
					$scope.testCardData = cardData.moduleData;
					//sessionServices.set("currentModule", $scope.testCardData.col_1.var4);
					$scope.cardStatus = cardData.moduleStatus;
					if($scope.moduleType.name != "SUM" && $scope.moduleType.name != "LOG" && $scope.moduleType.name != "Enterprise"){
						$scope.getModuleCounterDataAndAgentStatus();
					}
				}
				//$rootScope.$emit('disable_Loader');
				angular.element(document).ready(function () {
					$rootScope.$emit('disable_Loader');
			    });
			}
		});
		//timerRefresh = setTimeout($scope.getCardDetails, sessionServices.get("textRefresh"));
	};
	
	$scope.getCardDetails();
	
	//getEnterprise details based on select dropdown list.
	 $rootScope.$on("call_ent_Details", function(event, enterpriseData){
		 console.info("call ent details");
		 //console.log(enterpriseData);
		 //$scope.enterpriseData = enterpriseData;
		 $scope.enterpriseData = JSON.parse(sessionServices.get("selectedEnterprise"));
		 console.log($scope.enterpriseData);
		 $scope.getCardDetails();
	});
	
	//$rootScope.$on("call_ent_Details", $scope.getCardDetails);
//Auto refresh timer Edit function 
	$scope.isEditRefreshTime = false;
	
	$scope.editRefTime = function(){
		console.log("iseditrefresh");
		$scope.isEditRefreshTime = true;
	};
	
	$scope.doNotUpdateRefTime = function(){
		console.log("iseditrefresh");
		$scope.isEditRefreshTime = false;
	};
	
	$scope.UpdateRefTime = function(){
		console.log($scope.setRefreshTime);
		
		if($scope.setRefreshTime <= 0){
			messageService.showWarningMessage("Refresh Timer is stopped, Timer starts on refresh");
			$interval.cancel($scope.refreshTimerSet);
			$scope.isEditRefreshTime = false;
			$scope.refreshTime = 0;
		}else if($scope.setRefreshTime > 0 && $scope.setRefreshTime < 30){
			messageService.showSuccessMessage("Refresh Time Minimum 30 Sec");
		}else{
			if($scope.setRefreshTime > 900 || $scope.setRefreshTime == undefined){
				$scope.setRefreshTime = 900;
				messageService.showSuccessMessage("Max time 900 Sec, hence reset to 900 sec");
			}else{
				messageService.showSuccessMessage("Settings reset on page refresh.");
			}
			sessionServices.set("cardRefreshTime", $scope.setRefreshTime);
			$scope.isEditRefreshTime = false;
			$interval.cancel($scope.refreshTimerSet);
			refreshTimer();
		}
	};
	
	$scope.setRefreshTime = Number(sessionServices.get("cardRefreshTime"));
	//auto refresh timer 
	var refreshTimer = function() {
		var i = sessionServices.get("cardRefreshTime");
		$scope.refreshTimerSet = $interval(function(){
			 if(i===0){
				 $scope.getCardDetails();
				 //i=0;
				 $scope.refreshTime = i;
				 $interval.cancel($scope.refreshTimerSet);
			 }else{
				 $scope.refreshTime = i; 
			 }
			i--;
		},1000);
	};
//Refresh Time Edit closed.
	
	//set as Default
	$scope.setAsDefault = function() {		
		cardDetailsServices.setAsDefaultInCard($scope, $scope.moduleType.displayName, function(response) {
			if(!response.success) {
				messageService.showErrorMessage(response.errorMessage);
			}else {
				messageService.showSuccessMessage(response.message);
			}
		});
		console.log("setAsDefault");
	};
	
	var timerAgentStatus;
	$scope.getModuleCounterDataAndAgentStatus = function() {
		//clearTimeout(timerAgentStatus);
		var jsonObj = [];
		
		for (var i = 0; i < $scope.testCardData.length; i = i + 1 ) {
			var joModule = $scope.testCardData[i];
			guids = {};
			guids ["guid"] = joModule.guid;
			//guids ["counter_id"] = joModule.counter_id_1+','+joModule.counter_id_2;
			guids ["counter_id"] = null+','+null;
			jsonObj.push(guids);
		}
		
		if($scope.testCardData.length>0){
			var resultModuleCounterDataAndAgentStatus = cardDetailsServices.getModuleCounterDataAndAgentStatusService(jsonObj);
			resultModuleCounterDataAndAgentStatus.then(function(response ) {//moduleCounterDataAndAgentStatus
				if ( ! response.success ) {
					// err
					messageService.showErrorMessage(response.errorMessage);
				} else {
					var joGUIDWiseData = response.message;
					
					for (var i = 0; i < $scope.testCardData.length; i = i + 1 ) {
						var joModule = $scope.testCardData[i], aryFormattedValue = [];
						// var data = moduleCounterDataAndAgentStatus[i];
						
						var joCounterData = joGUIDWiseData[joModule.guid];
						
						if( joCounterData != undefined ){
				 			//joModule.value_1 = joCounterData.value_1;
				 			//joModule.value_2 = joCounterData.value_2;
				 			
				 			/* using filter, format the value in human readable format, avoided formatting and set
				 			// to format the value in human readable, since we have in cardlayout 2 counters data, limit is restricted 2
				 			for (var j = 1; j <= 2; j = j + 1) {
				 				aryFormattedValue = appedoDataUtils.getHumanReadableFormat(joModule['value_'+j], joModule['unit_'+j]);
				 				joModule['formatted_value_'+j] = aryFormattedValue[0];
				 				joModule['formatted_unit_'+j] = aryFormattedValue[1];
				 			}
				 			*/
				 			
				 			joModule.monitor_active = joCounterData.monitor_active;
				 			joModule.profiler_active = joCounterData.profiler_active;
						}else{
				 			joModule.value_1 = "NA";
				 			joModule.value_2 = "NA";
				 			joModule.monitor_active = false;
				 			joModule.profiler_active = false;
						}
			 		}
				}
				
	        });
		}
		//timerAgentStatus = setTimeout($scope.getModuleCounterDataAndAgentStatus, sessionServices.get("textRefresh"));
	};
	
	$scope.ResultRum = {};
	function getRUMRunningStatus() {
		var resultTransactionData = cardDetailsServices.getTransactionDataService($scope, $scope.enterpriseData);
		resultTransactionData.then(function(rumTransactionData) {
			$scope.rumTransactions = rumTransactionData;
			
			for(var i = 0 ; i < $scope.rumTransactions.length; i++  ) {
				if($scope.rumTransactions[i].visitor_count != 0) {
					console.log("NO Zero uid:" +$scope.rumTransactions[i].uid);
					if($scope.cardRUMStatus.length > 0){
						for(var cd = 0 ; cd < $scope.testCardData.length ; cd++ ) {
							if($scope.testCardData[cd].uid == $scope.rumTransactions[i].uid ) {
								for(var crs = 0 ; crs < $scope.cardRUMStatus.length ; crs++ ){
									if($scope.testCardData[cd].uid == $scope.cardRUMStatus[crs].uid && $scope.cardRUMStatus[crs].status_severity == "CRITICAL") {
										$scope.testCardData[cd].col_6.var2 = $scope.cardRUMStatus[crs].status_count;
										if($scope.testCardData[cd].col_6.var3 == '') {
											$scope.testCardData[cd].col_6.var3 = 0;
										}
									}
									if($scope.testCardData[cd].uid == $scope.cardRUMStatus[crs].uid && $scope.cardRUMStatus[crs].status_severity == "WARNING") {
										$scope.testCardData[cd].col_6.var3 = $scope.cardRUMStatus[crs].status_count;
										if($scope.testCardData[cd].col_6.var2 == '') {
											$scope.testCardData[cd].col_6.var2 = 0;
										}
									}
									if($scope.testCardData[cd].col_6.var2 != 0 || $scope.testCardData[cd].col_6.var3 != 0) {
										
										//$scope.testCardData[cd].col_6.var4 = $scope.testCardData[cd].col_5.var2 - ($scope.testCardData[cd].col_6.var2 + $scope.testCardData[cd].col_6.var3);
										$scope.testCardData[cd].col_6.var4 = $scope.rumTransactions[i].visitor_count - ($scope.testCardData[cd].col_6.var2 + $scope.testCardData[cd].col_6.var3);
									}
								}
							}
						}
					}else{
						for (var ci = 0 ; ci < $scope.testCardData.length ; ci++) {
							if($scope.rumTransactions[i].uid == $scope.testCardData[ci].uid) {
								$scope.testCardData[ci].col_6.var2 = 0;
								$scope.testCardData[ci].col_6.var3 = 0;
								$scope.testCardData[ci].col_6.var4 = $scope.rumTransactions[i].visitor_count;
							}
						}
					}					
				}
			}
		});
	};
	
	//get AVL_Moniter Down in status
	$scope.getUserApplicationsStatus = function() {
		cardDetailsServices.getUserApplicationsStatus(function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var avmMoniterStatus = data.message;
				for(var j = 0; j < avmMoniterStatus.length; j++) {
					for(var i = 0 ; i < $scope.testCardData.length; i++  ) {
						if($scope.testCardData[i].testid == avmMoniterStatus[j].avmTestId) {
							$scope.testCardData[i].col_7.var3 = avmMoniterStatus[j].downLocationCnt;
							$scope.testCardData[i].col_7.var4 = avmMoniterStatus[j].downAgentCnt;
						}
					}
				}
			}
		});
	};
	
	// AVM Location alert function
	$scope.openLocationToAlertAddresses = function(index) {
		
		// AVM location's description details; Note: `1` hardcoded since respective order known in `common/data/module_content_avm.json` 
		var joLocationDescContent = aryModuleDescriptionContents[1];
		// opens window, of location's view added alert addresses, when site is down or location_agent is down 
		avmModuleServices.openLocationToAlertAddresses(this.joValCard.agentId, joLocationDescContent);
	};

	
	/*cardDetailsServices.populateCardData($scope, $scope.moduleType.name.name, function(cardData) {
		$scope.testCardData = cardData.moduleData;
		$scope.cardStatus = cardData.moduleStatus;
		$scope.cardRUMStatus = cardData.moduleRUMStatus;
	});*/
	
	// set the All card Status 
	$scope.setStatusDisp = function() {
		for(var i = 0 ; i < $scope.testCardData.length; i++  ) {
			if($scope.testCardData[i].active_status == true) {
				$scope.testCardData[i].col_6.var2 = 0;
				$scope.testCardData[i].col_6.var3 = 0;
				$scope.testCardData[i].col_6.var4 = $scope.testCardData[i].col_5.var2;
					for (var j = 0 ; j < $scope.cardStatus.length; j++) {
						if($scope.testCardData[i].col_4.var3 == $scope.cardStatus[j].uid && $scope.cardStatus[j].status_severity == "CRITICAL") {
							
							$scope.testCardData[i].col_6.var2 = $scope.cardStatus[j].status_count;
							if($scope.testCardData[i].col_6.var3 == '') {
								$scope.testCardData[i].col_6.var3 = 0;
							}
						}
						if($scope.testCardData[i].col_4.var3 == $scope.cardStatus[j].uid && $scope.cardStatus[j].status_severity == "WARNING") {
							
							$scope.testCardData[i].col_6.var3 = $scope.cardStatus[j].status_count;
							if($scope.testCardData[i].col_6.var2 == '') {
								$scope.testCardData[i].col_6.var2 = 0;
							}
						}
						if($scope.testCardData[i].col_6.var2 != 0 || $scope.testCardData[i].col_6.var3 != 0) {
							
							$scope.testCardData[i].col_6.var4 = $scope.testCardData[i].col_5.var2 - ($scope.testCardData[i].col_6.var2 + $scope.testCardData[i].col_6.var3);
							//$scope.testCardData[i].col_6.var4 = $scope.testCardData[i].col_5.var2;
						}
					}
			}		
		}
	};
	
	$scope.setRUMStatusDisp = function() {
		for(var i = 0 ; i < $scope.testCardData.length; i++  ) {
			if($scope.testCardData[i].active_status == true) {
				if($scope.cardRUMStatus.length > 0) {
					for (var j = 0 ; j < $scope.cardRUMStatus.length; j++) {
						if($scope.testCardData[i].col_4.var3 == $scope.cardRUMStatus[j].uid && $scope.cardRUMStatus[j].status_severity == "CRITICAL") {
							
							$scope.testCardData[i].col_6.var2 = $scope.cardRUMStatus[j].status_count;
							if($scope.testCardData[i].col_6.var3 == '') {
								$scope.testCardData[i].col_6.var3 = 0;
							}
						}
						if($scope.testCardData[i].col_4.var3 == $scope.cardRUMStatus[j].uid && $scope.cardRUMStatus[j].status_severity == "WARNING") {
							
							$scope.testCardData[i].col_6.var3 = $scope.cardRUMStatus[j].status_count;
							if($scope.testCardData[i].col_6.var2 == '') {
								$scope.testCardData[i].col_6.var2 = 0;
							}
						}
						if($scope.testCardData[i].col_6.var2 != null && $scope.testCardData[i].col_6.var3 != null) {
							$scope.testCardData[i].col_6.var4 = $scope.testCardData[i].col_5.var2 - ($scope.testCardData[i].col_6.var2 + $scope.testCardData[i].col_6.var3);
							//$scope.testCardData[i].col_6.var4 = $scope.testCardData[i].col_5.var2;
						}
					}
				}else{
					$scope.testCardData[i].col_6.var2 = 0;
					$scope.testCardData[i].col_6.var3 = 0;
					$scope.testCardData[i].col_6.var4 = $scope.testCardData[i].col_5.var2;
					
				}
			}		
		}
	};

	//get The All Cards Available and Configured Datas 
	$scope.availableCardData = {};
	$scope.getAvailableData = function(uid,moduleType) {
		if(moduleType == "DATABASE" || moduleType == "APPLICATION" || moduleType == "SERVER") {
			cardDetailsServices.populateCardAvailableData($scope, uid, function(cardAvailableData) {
				
				for(var i = 0 ; i < $scope.testCardData.length; i++  ) {
					if($scope.testCardData[i].col_4.var3 == cardAvailableData.uid) {
						$scope.testCardData[i].col_4.var2 = cardAvailableData.available;
						$scope.testCardData[i].col_5.var2 = cardAvailableData.configured;
					}
				}
				$scope.setStatusDisp();
			});
		}else if(moduleType == "RUM"){
			var resultTransactionData = cardDetailsServices.getTransactionDataService($scope, $scope.enterpriseData);
			resultTransactionData.then(function(rumTransactionData) {
				$scope.rumTransactions = rumTransactionData;
				
				for(var i = 0 ; i < $scope.testCardData.length; i++  ) {
					if($scope.testCardData[i].col_1.var4 == "RUM") {
						for(var j=0 ; j < $scope.rumTransactions.length ; j++) {
							if($scope.testCardData[i].col_4.var3 == $scope.rumTransactions[j].uid) {
								$scope.testCardData[i].col_4.var2 = $scope.rumTransactions[j].visitor_count;
							}
						}
					}
				}
				$scope.setRUMStatusDisp();
			});
		}else if(moduleType == "SUM") {
			
			if(this.joValCard.col_4.var2 > 59) {
				
				this.joValCard.col_4.var2 = this.joValCard.col_4.var2/60 + " hrs";
			}else {
				
				this.joValCard.col_4.var2 = this.joValCard.col_4.var2 + " min";
			}
		}else if(moduleType == "LOG") {
			console.info("log service call");
			cardDetailsServices.getLogStatusReport($scope, uid, function(response){
				if(!response.success ){
					console.info("LOG Status report Geting problem.");
				}else{
					var response1 = response.message;
					for(var i = 0 ; i < $scope.testCardData.length; i++) {
						if($scope.testCardData[i].col_4.var3 == response1.uid) {
							if(response1.Log_Recived > 0){
								$scope.testCardData[i].log_active = true;
							}else{
								$scope.testCardData[i].log_active = false;
							}
							$scope.testCardData[i].col_4.var2 = response1.Log_Recived;
							$scope.testCardData[i].col_5.var2 = response1.Log_pattern;
							$scope.testCardData[i].col_6.var4 = response1.info;
							$scope.testCardData[i].col_6.var3 = response1.warning;
							$scope.testCardData[i].col_6.var2 = response1.critical;
							$scope.testCardData[i].col_8.var1 = response1.log_name;
						}
					}
				}
			});
		}
		//$scope.setStatusDisp();
	};
	
	// loads the RUM module description  content, 
	function loadModuleDescriptionContent() {
		// gets module content
		cardDetailsServices.getJsonData('common/data/module_content_rum.json', function(responseData){
			$scope.moduleDescription = responseData[0];
		});
	};
	loadModuleDescriptionContent();
	
	// card Edit Function
	$scope.moduleOriginalData = {};
	$scope.moduleCardEdit = function (index) {
		$scope.moduleOriginalData = JSON.parse(JSON.stringify(this.joValCard));
		$scope.module = this.joValCard;
		if($scope.module.col_1.var4 == "RUM") {
			cardDetailsServices.openAddorEditRUMModule('fromEdit', $scope.moduleDescription, $scope.module.col_4.var3);
		}else if($scope.module.col_1.var4 == "SUM"){
			cardDetailsServices.getEditSumModules(this.joValCard.testid , function(cardData){
				var testData = cardData;
				var modalInstance = $uibModal.open({
					templateUrl: 'common/views/sum/add_sum.html',
					controller: 'sumAddController',
					size: 'lg',
					resolve: {
						isFrom: function() {
							return 'fromEdit';
						},
						sumTestData: function() {
							return testData;
						}, moduleCardContent: function() {
							return null;
						}
					}
				});
			});
		}else if($scope.module.col_1.var4 == "AVAILABILITY"){
			cardDetailsServices.getEditAVMUserTests(this.joValCard.testid, function(data){
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					console.info("Avl Monitor response data!");
					console.log(data.message);
					var testData = data.message;
					var modalInstance = $uibModal.open({
						templateUrl: 'common/views/avm/add_avm.html',
						controller: 'avmAddController',
						size: 'lg',
						resolve: {
							isFrom: function() {
								return 'fromEdit';
							},
							avmTestData: function() {
								return testData;
							}, moduleCardContent: function() {
								return null;
							}
						}
					});
				}
			});
		
			//messageService.showInfoMessage("Work in Process!");
			}else if($scope.module.col_1.var4 == "AppedoLT Scenario") {
				$scope.mapScript = this.joValCard;
				cardDetailsServices.openAddorEditScenario('fromEdit', $scope.moduleCardContent, $scope.mapScript, false);
			}else if($scope.module.col_1.var4 == "AppedoLT Variables") {
				for(var i=0; i<$scope.testCardData.length; i++) {
					var moduleContent = $scope.testCardData[i];
					moduleContent.isLTEditEnabled = false;
				}
				$scope.module.isLTEditEnabled = true;
			}else if($scope.module.col_1.var4 == "Alert-User" || $scope.module.col_1.var4 == "Alert-System") {
				var joSelectedSLAPolicy = this.joValCard;
				cardDetailsServices.openAddorEditSLAPolicy('fromEdit', joSelectedSLAPolicy, $scope.moduleCardContent);
			}else{
			for(var i=0; i<$scope.testCardData.length; i++) {
				var moduleContent = $scope.testCardData[i];
				moduleContent.isEditEnabled = false;
			}
			$scope.module.isEditEnabled = true;
		}	
	};
	
	//close Edit box
	$scope.doNotUpdate = function() {
		$scope.module.isEditEnabled = false;
		this.joValCard = $scope.moduleOriginalData;
	};
	
	//Edit UpdateModule Function
	$scope.updateApmModule = function() {
		//$scope.module.isEditEnabled = false;		
			var isValid = true;
			var msg = '';
			if(this.joValCard.col_2.var1 == '' || this.joValCard.col_2.var1 == undefined) {
				var isValid = false;
				msg = "Please enter name";
			} else if(this.joValCard.col_3.var1 == '' || this.joValCard.col_3.var1 == undefined) {
				var isValid = false;
				msg = "Please enter description";
			}
			if(isValid) {
				cardDetailsServices.updateOADModule($scope, this.joValCard, function (data) {
					if(data.success == true) {
						$scope.module.isEditEnabled = false;
						messageService.showSuccessMessage(data.message);
					} else {
						$scope.module.isEditEnabled = true;
						messageService.showErrorMessage(data.errorMessage);
					}
					//successMsgService.showSuccessOrErrorMsg(data);
					//messageService.open(data.message,"success")
					//messageService.showSuccessMessage(data.errorMessage);
				});
			} else {
				messageService.showWarningMessage(msg);
			}
		};
		
		//after Edit Update LT Variables
		$scope.updateLTVariable = function() {
			cardDetailsServices.updateVariable($scope, this.joValCard.col_2.var1, this.joValCard.col_3.var1, this.joValCard.col_3.var2, function(data){
				if(data.success){
					$scope.getCardDetails();
					messageService.showSuccessMessage(data.message);
				}else{
					messageService.showErrorMessage(data.errorMessage);
				}
			});
		};
		
	//config OAD Modules
	var $ctrl = this;
	$ctrl.animationsEnabled = true;
	$scope.getConfiguredCounters = function() {
		if(this.joValCard.type && this.joValCard.type == "APPEDO_LT") {
			$scope.mapScript = this.joValCard;
			if($scope.mapScript.col_4.var2 == 0) {
				messageService.showErrorMessage("Map atleast one script.");
			}else {
				cardDetailsServices.openConfigureScenario('fromEdit', $scope.moduleCardContent, $scope.mapScript, 'APPEDO_LT'/*$scope.appedo.loadtestValue*/);
			}
			
		} else if(this.joValCard.serviceMapId && this.joValCard.serviceMapId > 0 ) {
			$scope.serviceMapData = {};
			$scope.serviceMapData.serviceMapName = this.joValCard.col_2.var1;
			$scope.serviceMapData.serviceMapDescription = this.joValCard.col_3.var1;
			$scope.serviceMapData.service_map_id = this.joValCard.serviceMapId;
			$uibModal.open({
		        templateUrl: 'common/views/dashboard/service_mapping.html',
		        controller: 'serviceMapSelectionController',
		        size: 'lg',
		        resolve: {
		        	serviceAddData: function() {
		        		return $scope.serviceMapData;
		        	}, 
		        	saveBtn: function() {
		            	return "UPDATE";
		            }
		        }
			});
		}else if (this.joValCard.col_1.var4 == "Alert-System" || this.joValCard.col_1.var4 == "Alert-User"){
			var joSelectedSLAPolicy = this.joValCard;
			
	  		// open SLA's mapped counters
			cardDetailsServices.openSLAViewMappedCounters('fromEdit', joSelectedSLAPolicy, joSelectedSLAPolicy.sla_id);
		}else if (this.joValCard.col_1.var4 == "Enterprise"){
			var joSelectedEnterpriseUser = this.joValCard;
			
	  		// open SLA's mapped counters
			cardDetailsServices.openEnterpriseViewMappedUser('fromEdit', joSelectedEnterpriseUser, joSelectedEnterpriseUser.e_id);
		}else{
			var currentOADCardContent = this.joValCard;
			$uibModal.open({
				animation: true,
				ariaLabelledBy: 'modal-title',
				ariaDescribedBy: 'modal-body',
				templateUrl: 'common/views/oad/configure_counters.html',
				controller: 'configure_counters_controller',
				size: 'lg',
				resolve: {
					appcardcontent: function() {
						return currentOADCardContent;
					}
				}
			});
		}
		
	};
	
	//Modules alert icon process 
	$scope.moduleAlerts = function() {
		messageService.showInfoMessage("Work In Process!");
	};
	
	//Delete Card Datas
	$scope.deleteSelectedRow = function(index) {
		var is_owner = JSON.parse(sessionServices.get("selectedEnterprise")).is_owner;
		if(!is_owner) {
			messageService.showWarningMessage("Don't have Delete permission");
		}else{
			if(this.joValCard.col_1.var4 == "RUM") {
				//$scope.deleteSelectedRUMRow(index);
				var result = confirm("You will lose agent records permanently!\nAre you sure you want to delete?");
				if(result == true) {
					var moduleName =  this.joValCard.col_2.var1;
					cardDetailsServices.deleteModuleRow($scope, this.joValCard, function (response) {
						if ( ! response.success ) {
							messageService.showWarningMessage(response.errorMessage);
						} else {
							messageService.showSuccessMessage('RUM `'+moduleName+'` has been deleted.');
								
							// $scope.appcardscontent.splice(index,1);
							//$scope.getRumCardData();
							$scope.getCardDetails();
						}
					});
				}
			}else if(this.joValCard.col_1.var4 == "SUM") {
				var result = confirm("You will lose sum records permanently!\nAre you sure you want to delete?");
				if(result == true) {
					cardDetailsServices.deleteSumRecord($scope, this.joValCard.testid, this.joValCard.testtype, true, function(response) {
						if( response.success ){
							messageService.showSuccessMessage(response.message);
							$scope.getCardDetails();
							//$scope.getSUMTests();
						} else {
							messageService.showWarningMessage(response.errorMessage);
						}
					});
				}
			}else if(this.joValCard.col_1.var4 == "AVAILABILITY") {
				var result = confirm("You will lose AVM records permanently!\nAre you sure you want to delete?");
				if(result == true) {
					cardDetailsServices.deleteAVMRecord($scope, this.joValCard.testid, function (response) {
						if( response.success ){
							messageService.showSuccessMessage(response.message);
							$scope.getCardDetails();
							//$scope.getAVMTests();
						} else {
							messageService.showWarningMessage(response.errorMessage);
						}
					});
				}
			}else if(this.joValCard.col_1.var4 == "Avl Location") {
				$scope.avm_location = this.joValCard;
				var result = confirm("You will lose some records permanently!\nAre you sure you want to delete?");
					if(result == true) {
						cardDetailsServices.deleteAVMLocation($scope, $scope.avm_location, function(response){
							if(response.success == true){
						  		//$scope.ltscenarioscontent.splice(index,1);
								$scope.testCardData.splice(index,1);
						  		messageService.showSuccessMessage(response.message);
						  	}else {
						  		messageService.showErrorMessage(response.errorMessage);
						  	}
						});
					}
			}else if(this.joValCard.col_1.var4 == "AppedoLT Script") {
				$scope.ltScriptData = this.joValCard;
				var result = confirm("You will lose some records permanently!\nAre you sure you want to delete?");
					if(result == true) {
						cardDetailsServices.deleteScriptRecord($scope, $scope.ltScriptData, $scope.appedo.loadtestValue, function (response) {
							//successMsgService.showSuccessOrErrorMsg(response);
						  	if(response.success == true){
						  		//$scope.ltscenarioscontent.splice(index,1);
						  		$scope.testCardData.splice(index,1);
						  		messageService.showSuccessMessage(response.message);
						  	}else {
						  		messageService.showErrorMessage(response.errorMessage);
						  	}
						});
					}
			}else if(this.joValCard.col_1.var4 == "AppedoLT Scenario") {
				$scope.joSelectedScenario = this.joValCard;
				var result = confirm("You will lose some LT records permanently!\nAre you sure you want to delete?");
					if(result == true) {					
						cardDetailsServices.deleteScenarioRecord($scope, $scope.joSelectedScenario.scenario_id, $scope.joSelectedScenario.col_2.var1, function (response) {
							//successMsgService.showSuccessOrErrorMsg(response);
						  	if(response.success == true){
						  		//$scope.ltscriptscontent.splice(index,1);
						  		$scope.testCardData.splice(index,1);
						  		messageService.showSuccessMessage(response.message);
						  	}else {
						  		messageService.showErrorMessage(response.errorMessage);
						  	}
						});
					}
			}else if(this.joValCard.col_1.var4 == "AppedoLT Variables") {
				var result = confirm("You will lose some records permanently!\nAre you sure you want to delete?");
				if(result == true) {
					cardDetailsServices.deleteVariable($scope, this.joValCard.col_2.var1, function(data){
	
						if(data.success){
							$scope.getCardDetails();
							messageService.showSuccessMessage(data.message);
						}else{
							messageService.showErrorMessage(data.errorMessage);
						}
					});
				}
			}else if(this.joValCard.col_1.var4 == "Service Map") {
				var result = confirm("Are you sure you want to delete?");
				if(result == true) {
					cardDetailsServices.deleteServiceMapRecord($scope, this.joValCard.serviceMapId, function (response) {
						if(response.success == true){
							$scope.testCardData.splice(index, 1);		
							messageService.showSuccessMessage(response.message);
							// to reload 
		            		//$rootScope.$emit('loadServiceMapSelectedTypePanel');
		            	}
					});
				}
			}else if(this.joValCard.col_1.var4 == "Enterprise") {
				var result = confirm("Are you sure you want to delete Enterprise?");
				if(result == true) {
					cardDetailsServices.deleteEnterprise($scope, this.joValCard.e_id, function (response) {
						if(response.success == true){
							$scope.testCardData.splice(index, 1);		
							messageService.showSuccessMessage(response.message);
							// to reload 
		            		//$rootScope.$emit('loadServiceMapSelectedTypePanel');
		            	}
					});
				}
			}else if(this.joValCard.col_1.var4 == "Alert-User"){
				var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
				if(result == true) {
					$scope.sla = this.joValCard;
					cardDetailsServices.deleteSLAPolicy($scope, $scope.sla.sla_id, function(data) {
						if( ! data.success ) {
							// err
							messageService.showErrorMessage(data.errorMessage);
						} else {
							messageService.showSuccessMessage(data.message);
							// reload SLA card data
							$scope.getCardDetails();
						}
					});
				}
			}else{
				var result;
				if(this.joValCard.col_1.var4 == "LOG") {
					result = confirm("You will lose agent records permanently!\nAre you sure you want to delete?");
				}else {
					result = confirm("Are you sure you want to delete?\nYou will lose agent records permanently!\nThe mapped reference(s) from Service Map will be removed.\nThe mapped Alert(s) will be removed.");
				}
				if(result == true) {	
					$scope.moduleName = this.joValCard.col_2.var1;
					$scope.currentModule = this.joValCard.col_1.var4;
					cardDetailsServices.deleteModuleRow($scope, this.joValCard, function (response) {
						if( ! response.success ){
							// err
							messageService.showErrorMessage(response.errorMessage.replace("#MODULE_NAME#", $scope.moduleName));
						} else {
							if($scope.currentModule == "LOG") {
								var msg = $scope.currentModule+' `'+$scope.moduleName +'` has been deleted.';
								messageService.showSuccessMessage(msg);
							}else {
								
							//}
							var joRespDeleteSLA = response.deleted_SLAs, joDisableSLA = {};
							var aryDisabledSLAs = joRespDeleteSLA.disabled_sla;
							
							var msg = $scope.currentModule+' `'+$scope.moduleName +'` has been deleted.';
							if ( aryDisabledSLAs.length > 0 ) {
								msg += '<BR />Due to mapping of another GUID, Disabled below SLA(s):<BR />';
								for(var i = 0; i < aryDisabledSLAs.length; i = i + 1) {
									joDisableSLA = aryDisabledSLAs[i];
									
									if ( i != 0 ) {
										msg += '<BR />';
									}
									msg += '`'+joDisableSLA.sla_name+'`';
								}
								
								messageService.showSuccessMessage(msg, {dismissOnTimeout: false, dismissOnClick: false, additionalClasses: 'apd-alert-msg'});
							} else {
								messageService.showSuccessMessage(msg);
							}				
							//$scope.appcardscontent.splice(index, 1);
							//$scope.getModules();
							$scope.getCardDetails();
							}
						}
						
					});
				}
			}
		}
	};

	$scope.showContent = function(){
		var variable = this.joValCard.content;
//		variable = variable.replace(/\\n/g, "<br />");
//		replace(/\\r\\n/g, "<br />");
//		str.replace(/i/g, "ramaaa")
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/load_test/show_variable_content.html',
			controller: 'showVariableContentController',
			size: 'lg',
			resolve: {
				item: function () {
					return variable;
				}							
			}
		});
	};
	
	$scope.uploadcsvfiles = function(elem){
		cardDetailsServices.uploadCSVFile($scope, elem, './lt/uploadcsvdata', this.joValCard.col_2.var1, function(data){
			if(data.success){
				//$scope.loadSelectedMode();
				messageService.showSuccessMessage(data.message);
				
			}else{
				messageService.showErrorMessage(data.errorMessage);
			}
		});
	};
	
	$scope.getUrlDownStatus = function(){
		cardDetailsServices.getUrlDownStatus($scope, function(Response){
			if(Response.success) {
				var urlDownStatus = Response.message;
				for(var i = 0 ; i < $scope.testCardData.length; i++) {
					if($scope.testCardData[i].col_6.var2 == "Active") {
						$scope.testCardData[i].col_7.var3 = "0";
					}
					for(var j = 0 ; j < urlDownStatus.length; j++ ) {
						if($scope.testCardData[i].agentId == urlDownStatus[j].agent_id) {
							$scope.testCardData[i].col_7.var3 = urlDownStatus[j].url_Down;
						}
					}
				}
			}else{
				messageService.showErrorMessage(Response.errorMessage);
			}
		});
	};
	
	$scope.LTScript_Status = function(Script_id) {
		$scope.ltScriptData = this.joValCard;
		if(this.joValCard.col_1.var4 == "LT Scripts") {
			cardDetailsServices.getLTScriptStatus($scope, Script_id, function(Response){
				if(Response.success) {
					console.log(Response.message);
					for(var i = 0 ; i < $scope.testCardData.length; i++  ) {
						if($scope.testCardData[i].script_id == Response.message.script_id) {
							$scope.testCardData[i].col_6.var2 = Response.message.status;
							//$scope.testCardData[i].col_5.var2 = cardAvailableData.configured;
						}
					}
				}else {
					console.info("failure LT_Script ajex!");
					messageService.showErrorMessage(Response.errorMessage);
				}
			});
		}
	};
	
	$scope.appedo = {};
	$scope.openMonitorPage = function() {
		$scope.selectedScenario = this.joValCard;
		console.info("scenario Value in New UI :");
		console.log($scope.selectedScenario);
		
		// Running Status/Result
		if( $scope.selectedScenario.run_status == true && $scope.selectedScenario.mappedo_scripts > 0 ) {
			
			// go to, the scenario running status
			ltFactory.viewScenarioRunningStatus($scope.selectedScenario.loadTestType, $scope.selectedScenario.col_2.var1, $scope.selectedScenario.run_id, $scope.selectedScenario.scenario_id);
		}
		// Start a new Test; only if scripts are mapped
		else if ( $scope.selectedScenario.mappedo_scripts > 0  ) {
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/load_test/lt_select_monitors.html',
				controller: 'loadTestMonitorController',
				size: 'lg',
				resolve: {
					selectedScenario: function() {
						return $scope.selectedScenario;
					},
					testTypeScript: function() {
						//return $scope.appedo.loadTestType;
						return $scope.selectedScenario.loadTestType;
					}
				}
			});
		} else {
			//toastErrNoMapscipts();
		}
	};
	
	$scope.goReports = function() {
		var joSelectedScenario = this.joValCard;
		if(joSelectedScenario.type == "Alert"){
			//$scope.openAlertLog(joSelectedScenario);
			sessionServices.set("selectedAlertcard", JSON.stringify(joSelectedScenario));
			$state.transitionTo('/sla_alert_details');
		}else{
			if ( joSelectedScenario.total_runs == 0 ) {
				// avoid goes to report page
				messageService.showWarningMessage('No runs were executed.');
			} else {
				// go to, the scenario's all reports page
				//ltFactory.viewScenarioAllReports($scope.appedo.loadtestValue, joSelectedScenario.scenarioName, joSelectedScenario.run_id, joSelectedScenario.scenario_id);
				ltFactory.viewScenarioAllReports(joSelectedScenario.loadTestType, joSelectedScenario.col_2.var1, joSelectedScenario.run_id, joSelectedScenario.scenario_id, joSelectedScenario.col_1.var4);		
			 }
		}
	};

	$scope.$on('$destroy', function() {
		$interval.cancel($scope.refreshTimerSet);
    });
}]);

appedoApp.controller('sla_alert_details_controller', ['$scope', 'cardDetailsServices', 'messageService', 'sessionServices', '$state', 
                                                       function ($scope, cardDetailsServices, messageService, sessionServices, $state){
	var sla = JSON.parse(sessionServices.get("selectedAlertcard"));
	console.log(sla);
	$scope.slaMsg ='Alert Log - '+sla.sla_name;
	$scope.showSLAGrid = false;
	$scope.showAlertLog = true;
	$scope.showHealLog = false;
	
	$scope.pagination = {};
	$scope.pagination.currentPage = 1;
	var numPerPage = 10;
	$scope.maxSize = 5;
	$scope.slaId = sla.sla_id;
	$scope.selectedPage = function(page) {
		$scope.slaAlerts = [];
		var offSet = ((page - 1) * numPerPage);
		//showLoading();
		
		cardDetailsServices.getSLAAlerLog($scope, $scope.slaId, offSet, numPerPage, function(slaALerLogCardData) {
			//hideLoading();
			
			$scope.slaAlerts = {};
			$scope.totalLength = slaALerLogCardData.total_count;
			$scope.slaAlerts = slaALerLogCardData.log_records;
			//$state.transitionTo('/sla_alert_details');
		});
	};
	$scope.selectedPage(1);
	
	$scope.goBack = function(){
		$state.transitionTo('/moduleDetails');
		sessionServices.set("currentModule", "Alert-User");
	};
}]);

appedoApp.controller('configure_counters_controller', ['$scope', 'cardDetailsServices', '$uibModalInstance', '$uibModal', 'appcardcontent', 'messageService', 
function ($scope, cardDetailsServices, $uibModalInstance, $uibModal, appcardcontent, messageService) {
	   	$scope.configCounter = {};
	   	$scope.close = function () {
	   		$uibModalInstance.dismiss('cancel');
	};

	//appcardcontent.col_4.var3 --> uid
	$scope.getAgentAllCategoryCounters = function() {
		
		cardDetailsServices.getConfiguredCategories($scope, appcardcontent.col_4.var3, appcardcontent.type+' '+appcardcontent.version, function(responseData) {
			$scope.configuredCategories = responseData;
			
			$scope.$watch('configCounter.Categories', function() {
				$scope.counters = {};
				if ($scope.configCounter.Categories != undefined) {
					if ($scope.configCounter.Categories.category != undefined) {
						$scope.counters = $scope.configCounter.Categories.counters;
					}
				}
			});
		});
	};
	$scope.getAgentAllCategoryCounters();
	
	cardDetailsServices.getMaxCounters(function(data){
		if(data.success){
			$scope.maxCounters = data.max_counters;
		}
	});
	
	$scope.validateCounters = function() {
		$scope.showSave = true;
		var nSelectedCounters = 0;
		
		for(var i = 0; i < $scope.configuredCategories.length; i = i + 1) {
			var joCategoryData = $scope.configuredCategories[i];
			for(var j = 0; j < joCategoryData.counters.length; j = j + 1){
				if( joCategoryData.counters[j].isSelected ) {
					nSelectedCounters = nSelectedCounters + 1;
				}
			}
		}
		
		if( nSelectedCounters > $scope.maxCounters ) {
			$scope.showSave = true;
			messageService.showWarningMessage("Number of Metrics should not exceed "+$scope.maxCounters);
		} else {
			$scope.showSave = false;
		}
	};
	
	$scope.saveConfigureCounters = function() {
		// if($scope.configureCounters.$valid) {
			var arySelectedCounterIds = [];
			
			for(var i = 0; i < $scope.configuredCategories.length; i = i + 1) {
				var joCategoryData = $scope.configuredCategories[i];
				for(var j = 0; j < joCategoryData.counters.length; j = j + 1){
					if(joCategoryData.counters[j].isSelected) {
						arySelectedCounterIds.push(joCategoryData.counters[j].counter_id);
					}
				}
			}
			cardDetailsServices.saveConfiguredCategories($scope, appcardcontent, arySelectedCounterIds, function(updatedData) {
				$scope.configCountersErrorMsg = false;
				if(updatedData.success == true) {
					messageService.showSuccessMessage(updatedData.message);
					$uibModalInstance.dismiss('cancel');
				} else {
					$scope.showConfigCountersErrorMsg = true;
					$scope.ConfigCountersErrorMsg = updatedData.errorMessage;
				}
			});
		// }
  	};
}]);

//=======
/* not in use
>>>>>>> Stashed changes
appedoApp.controller('appedoGraphsHeaderController', ['$scope', '$rootScope', 'appedoChartsServices', function ($scope, $rootScope, appedoChartsServices) {
	$scope.aryHealths = [ { name: 'All Critical', value: 'CRITICAL' }, 
						{ name: 'All Warning', value: 'WARNING' }, 
						{ name: 'Critical & Warning', value: 'CRITICAL & WARNING' }, 
						{ name: 'Counters with values', value: 'Counters without values' } ];
	
	$scope.graphHeaderFields = {};
	$scope.graphHeaderFields.health = $scope.aryHealths[0];
	
	
	$scope.slider = {
		value: 5,
		options: {
			showTicksValues: true,
			showTicks: true,
			hidePointerLabels: true,
			hideLimitLabels: true,
	        showSelectionBar: true,
			stepsArray: [
				{ value: 1, legend: 'Last 1 hr' },
				{ value: 2, legend: 'Last 6 hrs' },
				{ value: 3, legend: 'Last 12 hrs' },
				{ value: 4, legend: 'Last 1 days' },
				{ value: 5, legend: 'Last 7 days' },
				{ value: 6, legend: 'Last 15 days' }
			]
		}
	};
	
	//$scope.ngSliderValue = "2:4";
	$scope.ngSliderValue = 1;
	$scope.ngSliderOptions = {
		from: 1,
		to: 6,
		step: 1,
		scale: ["1 hr", "6 hrs", "12 hrs", "1 day", "7 days", "15 days"],
		//heterogeneity: ['1', '6'],
		qry_intervals: ["1 hour", "6 hours", "12 hours", "1 day", "7 days", "15 days"],
		css: {
			after: {"background-color": "#42A6DB"},
			pointer: {"background-color": "#42A6DB"}
		}
	};
}]);
*/ 
//for charts.html controller added 

appedoApp.controller('appedoChartsController', ['$scope', '$rootScope','$location','$filter', '$q', 'sessionServices', '$interval', 'ajaxCallService', '$appedoUtils', 'avmModuleFactory', 'appedoChartsServices', '$uibModal', 'serviceMapService','apmModulesService','chartViewService','forDateTimeModuleMethod','rumService', 'sumModuleServices', 'logService', 'messageService', '$state' ,'avmModuleServices' ,
                                                function ($scope, $rootScope, $location, $filter, $q, sessionServices, $interval, ajaxCallService, $appedoUtils, avmModuleFactory, appedoChartsServices, $uibModal, serviceMapService, apmModulesService, chartViewService, forDateTimeModuleMethod, rumService, sumModuleServices, logService, messageService, $state, avmModuleServices) {


	$scope.charts = {};
	$scope.asdChartsData = [];
	$scope.sumTests = [];
	$scope.rumModules = [];
	$scope.logModules = [];
	$scope.joSUMData = {};
	$scope.myChartLists = [];
	$scope.myChartName = {};
	$scope.myChartName.name = '';
	$scope.selectedMyChart = {};
	$scope.updatedMyChart = {};
	$scope.OADChartLoaded = true;
	$scope.RUMChartLoaded = true;
	$scope.SUMChartLoaded = true;
	$scope.LOGChartLoaded = true;
	$scope.isChartAvailable = true;
	$scope.myChart=[];
	$scope.isDefaultMyChartModified = false;
	$scope.searchText = {};
	$scope.searchText.logSearchText = '';
	$scope.searchText.rumSearchText = '';
	
	$scope.layout = 'col-lg-6 col-md-6 col-sm-12 col-xs-12 ';
	var joCounterSummary = {};
//	var isChartDataAvailable = true;
	$scope.loginUserData = JSON.parse(sessionServices.get('loginUser'));
	$scope.enterpriseData = JSON.parse(sessionServices.get('selectedEnterprise'));
	
//	console.log("location path :"+$location.path());
	
	$scope.joGraphData = {};
	$scope.selgrval = function(val){
			$scope.selGraphValue=val;
	};
	$scope.datePicker = {};
	$scope.ngSliderValue = 1;
	$scope.ngSliderOptions = {
		from: 1,
		to: 6,
		step: 1,
		scale: ["1 hr", "6 hrs", "12 hrs", "1 day", "7 days", "15 days"],
		//heterogeneity: ['1', '6'],
		qry_intervals: ["1 hour", "6 hours", "12 hours", "1 day", "7 days", "15 days"],
		css: {
			after: {"background-color": "#42A6DB"},
			pointer: {"background-color": "#42A6DB"}
		}
	};
	
	$scope.setDefaultcardmodule = function(){
		sessionServices.set("currentModule", $scope.loginUserData.defaultCardLayout);
		console.log("DefaultModule "+$scope.loginUserData.defaultCardLayout);
		console.log("Current Module "+sessionServices.get("currentModule"));
	};
	
	$scope.onUpdateMyChart = function() {
		console.log("inside onChange");
		$scope.myChartName.name = '';
	};
	
	//set default enterprise if session is null
	if(sessionServices.get("selectedEnterprise") == null){
		sessionServices.set("selectedEnterprise", JSON.stringify({"e_id":0,"e_name":"Select Enterprise","e_user_id":"None","is_owner":true}));
		console.log(sessionServices.get("selectedEnterprise"));
	}
	
	// qry filter interval 
	$scope.sliderSelectedValue = null;
	$scope.sliderSelectedValue = $scope.ngSliderOptions.qry_intervals[$scope.ngSliderValue - 1];
	
	$scope.loadSliderSelection = function() {
		$scope.sliderSelectedValue = $scope.ngSliderOptions.qry_intervals[$scope.ngSliderValue - 1];
		$scope.selectedStartDateTime = null;
		$scope.selectedEndDateTime =  null;
		$rootScope.healthBoardFilters = { interval: $scope.sliderSelectedValue, startDateTime: $scope.selectedStartDateTime, endDateTime: $scope.selectedEndDateTime};
		reloadChartData();
	};
	
	//clear chart data & reload.
	function reloadChartData() {
		$scope.charts = {};
		$scope.joGraphData = {};
		
		if ($location.path() == "/dashboard" ) {
			if ($scope.selectedMyChart != undefined && $scope.isDefaultMyChartModified){
				$scope.loadOnMyChartChange();
			} else {
				messageService.loading();
				$scope.isDefaultMyChartModified = false;
				$scope.selectedMyChart = undefined;
				getServiceMapBreaches();
			}
		}  else if($location.path() == "/log_details"){
			$scope.loadSelectedLOGTypeData();
		}else if($location.path() == "/rum_details"){
			$scope.loadSelectedRUMTypeData();
		}  else {
			loadSelectedDetails();
		}

	}
	//to call dashboard with selected enterprise
	$rootScope.$on("call_ent_Details_dashboard", function(event, enterpriseData){
		 //console.info("call_ent_Details_dashboard");
		 //console.log(enterpriseData);
		 //$scope.enterpriseData = enterpriseData;
		 $scope.enterpriseData = enterpriseData;
		 //console.log($scope.enterpriseData);
		 $scope.charts = {};
		 $scope.joGraphData = {};
		 $scope.getServiceMapsHealth();
		 $scope.getAllMyCharts();
	});

	//will go to module details page
	$scope.backToCardPage = function() {
		//$state.transitionTo(joModuleDetails[$scope.selectedDetailsModule].back_button_URL);
		$state.transitionTo('/moduleDetails');
		sessionServices.set("currentModule", $scope.selectedDetailsModule);
	};
	
	$scope.openDateTimeFilter = function(size) {
		//the below statement is used to set the min and max value of the datefilter
		forDateTimeModuleMethod.setMethod("filter");
		$uibModal.open({
			animation: true,
			ariaLabelledBy: 'modal-title',
			ariaDescribedBy: 'modal-body',
			templateUrl: './view/html/dateTimeFilter.html',
			controller: 'datePickerCtrls',
			controllerAs: 'ctrl',
			windowClass: 'app-modal-filter',
			size: size,
			resolve: {
/*				isFrom: function() {
					console.info("setting isFrom Value");
					return "fromSlider";
				}*/
			}
		}).result.then(function (customDate) {
	        if (customDate.startDate != null && customDate.endDate != null) {
	        	$scope.sliderSelectedValue = null;
	        	$scope.selectedStartDateTime = customDate.startDate.getTime();
	        	$scope.selectedEndDateTime = customDate.endDate.getTime();
	        	$rootScope.healthBoardFilters = { interval: $scope.sliderSelectedValue, startDateTime: $scope.selectedStartDateTime, endDateTime: $scope.selectedEndDateTime};
	        	reloadChartData();
	        }
	      });
	};

	$scope.removeCounter = function() {
		var result = confirm("You are trying to remove a metric from monitoring!\nAre you sure want to continue?");
		if(result == true) {
			apmModulesService.removeCounterFromMonitor( this.joValChart.uid, this.joValChart.counterId, function(updatedData) {
				if(updatedData.success == true) {
					messageService.showSuccessMessage(updatedData.message);
					this.joValChart.isActive = false;
					//delete $scope.charts[this.keyChart];
				} else {
					messageService.showErrorMessage(updatedData.errorMessage);
				}
			});
		}
	};
	
	$scope.addEditMyChart = function(idx) {
		console.log("in my chart "+idx);
		$scope.myChart[idx]=true;
		console.log("$scope.myChart[]"+$scope.myChart[idx]);
	};
	
	$scope.cancelEditMyChart = function(idx){
		$scope.myChart[idx]=false;
		$scope.myChartName.name == '';
		this.updatedMyChart = undefined;
	};

	$scope.onEditMyChartName = function(){
		//console.log("editing");
		this.updatedMyChart = undefined;
	};
	
	$scope.viewAlterAlert = function() {
		//var joSelectedSLAPolicy = this.joValCard;
		
  		// open SLA's mapped counters
		appedoChartsServices.openSLAMappedCounters(this.joValChart);
	}
	
	$scope.getAllMyCharts = function() {
		$scope.myChartLists = [];
		appedoChartsServices.getAllMyCharts(function(jaMyChartResp){
			if (!jaMyChartResp.success) {
				messageService.showErrorMessage(jaMyChartResp.errorMessage);
			} else {
				$scope.myChartLists = jaMyChartResp.message;
			}
		});	
	};
	//$scope.getAllMyCharts();
	
	$scope.removeChart = function(idx) {
		//console.log("removing");
		var result = confirm("Are you sure to remove this chart from my chart?");
		if (result) {
			appedoChartsServices.removeFromMyChart(this.joValChart.chartId, $scope.selectedMyChart.name, function(jaMyChartResp){
				if (!jaMyChartResp.success) {
					messageService.showErrorMessage(jaMyChartResp.errorMessage);
				} else {
					messageService.showSuccessMessage(jaMyChartResp.message);
					$scope.getAllMyCharts();
					delete $scope.charts[this.keyChart];
					delete $scope.joGraphData[this.keyChart];
					if (!Object.keys($scope.charts).length > 0) {
						$scope.loadOnServiceMapHealthChange();
					}
				}
			});
		}
	};
	
	
	$scope.addToMyChart = function(idx) {
		
		if ((this.updatedMyChart != undefined && this.updatedMyChart.name != undefined) || $scope.myChartName.name.trim() != ''){
			appedoChartsServices.addToMyChart(this.joValChart, $scope.myChartName.name.trim() == '' ? this.updatedMyChart.name : $scope.myChartName.name, $scope.myChartName.name.trim() == '' ? false : true, $scope.myChartLists.length > 0 ? true : false, function(jaMyChartResp){
				if (!jaMyChartResp.success) {
					messageService.showErrorMessage(jaMyChartResp.errorMessage);
				} else {
					//if (this.myChartName.name.trim() != '') {
					$scope.getAllMyCharts();
					//}
					$scope.myChartName.name == '';
					$scope.myChart[idx]=false;
					this.updatedMyChart = undefined;
					messageService.showSuccessMessage(jaMyChartResp.message);
					
				}
			}); 
			//console.log("updated Chart :"+JSON.stringify(this.updatedMyChart)+" chartId :"+this.joValChart.chartId);
			
		} else {
			messageService.showInfoMessage("Please enter/select chart name.");
		}	
	};
	
	$scope.loadOnMyChartChange = function(){
		$interval.cancel($scope.refreshTimerSet);
		var myChartIds = [];
		messageService.loading();
		$scope.joGraphData = {};
		$scope.charts = {};
		if ($scope.selectedMyChart != null) {
			$scope.isDefaultMyChartModified = true;
			appedoChartsServices.getChartIds($scope.selectedMyChart.name, function(jaMyChartResp){
				if (!jaMyChartResp.success) {
					$rootScope.$emit('disable_Loader');
					messageService.showErrorMessage(jaMyChartResp.errorMessage);
				} else {
					myChartIds = jaMyChartResp.message;
					if (myChartIds.length > 0) {
						loadChartDataWithChartId(myChartIds);
					} else {
						$rootScope.$emit('disable_Loader');
					}
					
					if($scope.sliderSelectedValue == '1 hour'){
						$scope.autoRefreshEnabled = true;
						refreshTimer();
					}else{
						$interval.cancel($scope.refreshTimerSet);
						$scope.autoRefreshEnabled = false;
					}
				}
			});	
		} else {
			$scope.isDefaultMyChartModified = false;
			reloadChartData();
		}
		
	};
	
	function loadChartDataWithChartId(myChartIds) {
		// get counters chart data
		var totalCharts = 0;
		totalCharts = myChartIds.length;
		$scope.OADCalledService = 0;
		
		for(var i = 0; i < totalCharts; i = i + 1) {
			getChartDataWithChartId(myChartIds[i].chartId).then(function(jaCharts){
				$scope.OADCalledService++;
				if (totalCharts <= $scope.OADCalledService ) {
					$scope.OADChartLoaded = true;
					$scope.RUMChartLoaded = true;
					$scope.SUMChartLoaded = true;
					$scope.LOGChartLoaded = true;
					$scope.isChartAvailable = true;
					chartLoader();
				}
			});
		}
	}
	//getLogSearchResults
	
	$scope.getLogSearchResults = function() {
		
		if ($scope.searchText.logSearchText.trim() != ''){
			messageService.loading();
			var resultLOGsData = logService.getSearchLOGSData($scope.logDetails.uid, $scope.searchText.logSearchText, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedLogType.value, $scope.selectedLogType.tableName, $scope.selectedLogLevel.value, $scope.selectedEnterprise );
			resultLOGsData.then(function(resp){
				if( ! resp.success ){
					// error message to be displayed 
					messageService.showErrorMessage(resp.errorMessage);
					$rootScope.$emit('disable_Loader');
				} else {
					var jaLogsData = [];
					var source;
					jaLogsData = resp.message;
					for (i=0; i<jaLogsData.length; i++) {
						source = jaLogsData[i].source;
						source = source.split("/");
						jaLogsData[i].source = source[source.length - 2]+"/"+source[source.length - 1];
					}
					$scope.logDatas = jaLogsData;
					if ($scope.logDatas.length > 0) {
						$scope.isLOGDataAvailable = true;
					} else {
						$scope.isLOGDataAvailable = false;
						messageService.showInfoMessage("No Data Found")
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				}
			});
		} else {
			messageService.showInfoMessage("Please enter keyword to search.");
		}	
	};
	//getRUMSearchResults
	$scope.getRUMSearchResults = function() {
		
		if ($scope.searchText.rumSearchText.trim() != ''){
			messageService.loading();
			var resultRUMData = rumService.getRUMSearchDatas($scope.selectedRUM.value, $scope.searchText.rumSearchText, $scope.selectedRUMFilterType.value, $scope.selectedRUMFilterValue.value, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime);
			resultRUMData.then(function(resp){
				if( ! resp.success ){
					// error message to be displayed 
					messageService.showErrorMessage(resp.errorMessage);
					$rootScope.$emit('disable_Loader');
				} else {
					//var jaRUMDatas = [];
					var jaRUMDatas = resp.message;
					$scope.rumDatas = jaRUMDatas;
					if ($scope.rumDatas.length == 0){
						messageService.showInfoMessage("No Data found.");
						$scope.isRUMDataAvailable = false;
					} else {
						$scope.isRUMDataAvailable = true;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				}
			});
		} else {
			messageService.showInfoMessage("Please enter keyword to search.");
		}	
	};
	
	var getChartDataWithChartId = function(chartId) {
		var deferred = $q.defer();
		var refId = -1;
		var location = null;
		var rumType = null;
		appedoChartsServices.getChartVisualDataWithChartId(chartId, function(jaMyChartResp) {
			if (!jaMyChartResp.success) {
				messageService.showErrorMessage(jaMyChartResp.errorMessage);
			} else {
				var joRespData = jaMyChartResp.message;
				if (joRespData.hasOwnProperty("isQueryExist") && joRespData.isQueryExist){
					
					if (isNaN(joRespData.chart.refId) && !angular.isNumber(joRespData.chart.refId)) {
						var refIdSplit = joRespData.chart.refId.split("_");
						if (refIdSplit.length > 0) {
							refId = refIdSplit[refIdSplit.length - 1];
						}
						joCounterSummary.unit = '-';
					} else {
						refId = joRespData.chart.refId;
					} 
					
					if (joRespData.chart.type == 'SUM') {
						location = joChartRawData.chartRawData.location+':'+joChartRawData.chartRawData.browser+'.'+joChartRawData.chartRawData.connectionName;
					}
					if (joRespData.chart.hasOwnProperty("rumType")) {
						rumType = joRespData.chart.rumType;
					}
					
					//(refId, counterId, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, metricId, xyAxisLabel, location ,rumType)
					var resultModuleCountersChartdata = appedoChartsServices.getChartDataPoints(refId, joRespData.chart.hasOwnProperty("counterId") ? joRespData.chart.counterId : null, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, joRespData.chart.type, joRespData.chartRawData.metricId, joRespData.chart.xyAxisLabel, location, rumType);
					resultModuleCountersChartdata.then(function(respGraph) {
						if( ! respGraph.success ) {
							deferred.resolve();
						} else {
							var joCounterResp = respGraph.message;
							var joRespCountersData = joCounterResp;
							var resultData = appedoChartsServices.formatChartDataJSON_v1(joCounterSummary, joRespCountersData, joRespData, $scope.joGraphData);
							$scope.joGraphData = resultData;
							deferred.resolve();
						}
					});
				}
			}
		});
		return deferred.promise;
	};
	
	//function getOADChartData() {
	var getOADChartData = function() {
		var deferred = $q.defer();
		$scope.chartDatas = [];
		var totalCharts = 0;
		var calledCharts = 0;
		
		var resultChartVisualizer = chartViewService.getChartVisualizerData_v1(joCounterSummary.uid, joCounterSummary.counterId, joCounterSummary.moduleCode, joCounterSummary.counterTemplateId, null, null, null, null, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedEnterprise );
		resultChartVisualizer.then(function (joChartVisResp) {
			var jaChartRawData = joChartVisResp.message;
			var resultModuleCountersChartdata;
			if ( !joChartVisResp.success ) {
				$scope.isOADChartAvailable = false;
				deferred.resolve($scope.chartDatas);
			} else {
				//console.log("totalObject :"+ Object.keys(jaChartRawData).length);
				totalCharts = Object.keys(jaChartRawData).length;
				angular.forEach(jaChartRawData, function(joChartRawData){
					if (joChartRawData.hasOwnProperty("isQueryExist") && joChartRawData.isQueryExist){
						$scope.isOADChartAvailable = true;
						resultModuleCountersChartdata = apmModulesService.getModuleCountersChartdata_v2(joCounterSummary.uid, joChartRawData.chart.counterId, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, joChartRawData.chartRawData.metricId, joChartRawData.chart.xyAxisLabel);
						resultModuleCountersChartdata.then(function(respGraph) {
							calledCharts++;
							if( ! respGraph.success ) {
								if (calledCharts >= totalCharts){
									//console.log("inside ifs");
									deferred.resolve();
								}
							} else {
								var joCounterResp = respGraph.message;
								var joRespCountersData = joCounterResp;
								var resultData = appedoChartsServices.formatChartDataJSON_v1(joCounterSummary, joRespCountersData, joChartRawData, $scope.joGraphData);
								$scope.joGraphData = resultData;
								/*var graphCount = Object.keys($scope.joGraphData).length;
								var topObject = 'graph'+(graphCount+1);
								//console.log("topObject :"+ topObject);
								//$scope.joGraphData.put(topObject, eachGraphSet);
								$scope.joGraphData[topObject] = eachGraphSet;*/
								//eachGraphSet.index = index;
								//console.log("joGraphData"+ JSON.stringify($scope.joGraphData));
								//$scope.charts = $scope.joGraphData;
							//	$scope.chartDatas.push(eachGraphSet);
//								console.log("total chart:"+totalCharts+" called charts:"+calledCharts);
								if (calledCharts >= totalCharts){
//									console.log("inside ifs");
									deferred.resolve();
								}
							}
						});
					}
				});
				//deferred.resolve();
			}
		});
		return deferred.promise;
	};
	
	// gets LOG's count chartdata
	//function getLOGCountChartData(joParamModule) {
	var getLOGCountChartData = function(joParamModule){
		// To get the chart visual data
		var deferred = $q.defer();
		var totalCharts = 0;
		var calledCharts = 0;
		var resultChartVisualizer = chartViewService.getChartVisualizerData_v1(joParamModule.uid, null, joParamModule.moduleName, null, joParamModule.logType, joParamModule.logTableId, joParamModule.logTableName, null, null, null, null, $scope.selectedEnterprise);
		resultChartVisualizer.then(function (joChartVisResp) {
			if ( !joChartVisResp.success ) {
				deferred.resolve();
			} else {
				var jaChartRawData = joChartVisResp.message;
				if (jaChartRawData.length == 0) {
					$scope.isLOGChartAvailable = false;
				}
				var resultLOGChart;
				//for (var nCount = 0; nCount < jaChartRawData.length; nCount++) {
				totalCharts = Object.keys(jaChartRawData).length;
				angular.forEach(jaChartRawData, function(joChartRawData){
					if (joChartRawData.hasOwnProperty("isQueryExist") && joChartRawData.isQueryExist) {
						resultLOGChart = logService.getLOGData_v2(joParamModule.uid, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, joChartRawData.chartRawData.metricId, joChartRawData.chart.xyAxisLabel, $scope.selectedEnterprise);
						calledCharts++;
						resultLOGChart.then(function(resp) {
							if( ! resp.success ){
								if (calledCharts >= totalCharts){
									//console.log("inside ifs");
									deferred.resolve();
								}
							} else {
								var joLOGChartData = resp.message;
								var resultData = appedoChartsServices.formatChartDataJSON_v1(joParamModule, joLOGChartData, joChartRawData, $scope.joGraphData);
								$scope.joGraphData = resultData;
							//	$scope.charts = $scope.joGraphData;
							}
							if (calledCharts >= totalCharts){
								//console.log("inside ifs");
								deferred.resolve();
							}
						});
					}
				});
			}
		});
		return deferred.promise;
	};
	
	//get SUM chart data
	//function getSumChartsData(joTest) {
	var getSumChartsData = function() {
		var deferred = $q.defer();
		if (joTest.testtype == 'URL') {											
			var resultChartVisualizer = chartViewService.getChartVisualizerData_v1(joTest.test_id, null, "SUM", null, null, null, joTest.testurl, joTest.testtype);
			resultChartVisualizer.then(function (joChartVisResp) {
				if ( !joChartVisResp.success ) {
					//TODO error message
				} else {
					var jaChartRawData = joChartVisResp.message;
					//var joSUMChartData = {};
					angular.forEach(jaChartRawData, function(joChartRawData){
						if (joChartRawData.hasOwnProperty("isQueryExist") && joChartRawData.isQueryExist) {
							var location = joChartRawData.chartRawData.location+':'+joChartRawData.chartRawData.browser+'.'+joChartRawData.chartRawData.connectionName;
							var resultSUMMultiLine;
							//console.log("Location ->> "+ location);
							if ( joTest.testtype === 'URL' ) {
								//joSUMChartData = $scope.getSUMMultiLineChartData(joTest, joChartRawData.query, location);
								resultSUMMultiLine = sumModuleServices.getSUMMultiLine(joTest.test_id, null, null, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, joChartRawData.chartRawData.metricId, location);
								resultSUMMultiLine.then(function(resp) {
									if(!resp.success){
										//error message
									} else {
										var joSUMChartData = resp.message;
										//To form json object
										var resultData = appedoChartsServices.formatChartDataJSON_v1(joTest, joSUMChartData, joChartRawData, $scope.joGraphData);
										$scope.joGraphData = resultData;
										//$scope.charts = $scope.joGraphData;
									}
										
								});
							} /* TODO to add for transaction
							else {
								joCounterResp = getSUMTestPages(joTest);
							}*/
						}
					});
				}
				deferred.resolve();
			}); 
		}
		return deferred.promise;
	};
	
	// gets RUM's page view(s) chartdata
	//function getRUMPageViewsChartData(joParamModule) {
	var getRUMPageViewsChartData = function(joParamModule) {
		var deferred = $q.defer();
		var totalCharts = 0;
		var calledCharts = 0;
		// To get the chart visual data											
		var resultChartVisualizer = chartViewService.getChartVisualizerData_v1(joParamModule.uid, null, 'RUM', null, joParamModule.moduleName, null, null, null, null, null, null, $scope.selectedEnterprise);
		resultChartVisualizer.then(function (joChartVisResp) {
			if ( !joChartVisResp.success ) {
				//$rootScope.$emit('disable_Loader');
				deferred.resolve();
			} else {
				
				var jaChartRawData = joChartVisResp.message;
				var resultRUMAreaChart;
				totalCharts = Object.keys(jaChartRawData).length;
				//for (var nCount = 0; nCount < jaChartRawData.length; nCount++) {
				angular.forEach(jaChartRawData, function(joChartRawData){
					if (joChartRawData.hasOwnProperty("isQueryExist") && joChartRawData.isQueryExist) {
						if (!joChartRawData.chart.hasOwnProperty("rumType")) {
							joChartRawData.chart.rumType = null;
						}
						resultRUMAreaChart = rumService.getRUMDashArea_v2(joParamModule.uid, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, joChartRawData.chartRawData.metricId, joChartRawData.chart.xyAxisLabel, joChartRawData.chart.rumType);
						calledCharts++;
						resultRUMAreaChart.then(function(resp) {
							if( ! resp.success ){
								/*if (calledCharts >= totalCharts){
								//	console.log("inside ifs");
									deferred.resolve();
								}*/
							} else {
								var joRUMChartData = resp.message;
								var resultData = appedoChartsServices.formatChartDataJSON_v1(joParamModule, joRUMChartData, joChartRawData, $scope.joGraphData);
								$scope.joGraphData = resultData;
								/*if (calledCharts >= totalCharts){
									//console.log("inside ifs");
									deferred.resolve();
								}*/
							}
						});
						if (calledCharts >= totalCharts){
							//console.log("inside ifs");
							deferred.resolve();
						}
					}
				});
			}
		});
		return deferred.promise;
	};
	
	//apm_details
	if($location.path() == "/apm_details") {
		//console.info("inside cardlayout code");
		$scope.selectedDetailsModule = sessionServices.get("selectedModule");
		$scope.selectedAppCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
		//console.info("selectedAppCardContent");
		//console.log($scope.selectedAppCardContent);
		//$scope.apmMonitorRadio = 'MONITOR';
		if(sessionServices.get("RadioOption") == "MONITOR"){
			$scope.apmMonitorRadio = 'MONITOR';
			
		}else if(sessionServices.get("RadioOption") == "PROFILER"){
			$scope.apmMonitorRadio = 'TRANSACTION';
		}else if(sessionServices.get("RadioOption") == "AVM"){
			$scope.apmMonitorRadio = 'AVM_Details';
		}else if(sessionServices.get("RadioOption") == "SUM"){
			$scope.apmMonitorRadio = 'SUM_Details';
			$scope.ngSliderValue = 4;
		}
		$scope.getAllMyCharts();
		joCounterSummary.uid = $scope.selectedAppCardContent.col_4.var3;
		joCounterSummary.moduleCode = $scope.selectedAppCardContent.col_1.var4;
		
		var joModuleDetails = {
				"APPLICATION": {
					radio_buttons_URL: "common/data/apm_app_monitor_radio_value.json",
					back_button_URL: "/apm_home/application"
				},
				"SERVER": {
					radio_buttons_URL: "common/data/apm_svr_monitor_radio_value.json",
					back_button_URL: "/apm_home/servers"
				},
				"DATABASE": {
					radio_buttons_URL: "common/data/apm_db_monitor_radio_value.json",
					back_button_URL: "/apm_home/db"
				}
			};
		
		// gets module radio btns
		$scope.getCounterTypeRadioButtons = function() {
			ajaxCallService.getJsonData(joModuleDetails[$scope.selectedDetailsModule].radio_buttons_URL, function(responseData){
				if ( $scope.selectedDetailsModule !== "Servers" ) {
					/*
					 * for APPLICATION & DATABASE, respective counter_type's radio buttons retrieved, 
					 *  since say Tomcat has Profiler `All Transactions` & `Key Transactions` but Apache doesn't have profiler And
					 *  		  Tomcat has Profiler MYSQL's slow_queries but MSIIS doesn't have Profiler slow_queries 
					 */
					console.log("")
					$scope.apmRadioButtonValues = responseData[$scope.selectedAppCardContent.type];
				} else {
					// since for all SERVERs has only Monitors, doesn't differentitate with sepecific radio btns
					$scope.apmRadioButtonValues = responseData;
				}
			});
		};
		
		if($scope.selectedDetailsModule == "APPLICATION" || $scope.selectedDetailsModule == "SERVER" || $scope.selectedDetailsModule == "DATABASE") {
			$scope.getCounterTypeRadioButtons();
		}
		
		
		
		
		//getOADChartData();
		
/*---------------------------------------------------------------------------------*/		
		// get Transation Data
		$scope.profilerData = {};
		$scope.profilerPanel = {};
		//$scope.sliderSelectedValue = "1 hour";
// Profiler page -- Transaction and Key Transaction
		$scope.loadProfilerDetails = function() {
			$scope.clearProfilerValue();
			$scope.getProfilerTransactions();
		};
		
		$scope.loadKeyProfilerDetails = function() {
			//$scope.clearKeyProfilerValue();
			$scope.clearProfilerValue();
			$scope.getKeyProfilerTransactions();
		};

		$scope.clearProfilerValue = function() {
			$scope.profilerData.transactionsData = [];
			
			$scope.profilerPanel.showTransactionTimeTaken = false;
			$scope.profilerData.transactionTimeTakenData = [];
			
			// clear methodes trace
			$scope.clearMethodsTrace();
		};
		
		// get Transaction Data's
		$scope.getProfilerTransactions = function() {
			//showProfilerTransactionLoading();
			
			if( $scope.selectedStartDateTime != null && $scope.selectedEndDateTime != null ){
				apmModulesService.getProfilerTransactionsWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedAppCardContent.type, $scope.selectedStartDateTime, $scope.selectedEndDateTime, function(data){
					//hideProfilerTransactionLoading();
					console.log("Date Time Ajex");
					if ( ! data.success ) {
						// err 
						messageService.showErrorMessage(data.errorMessage);
					} else {
						$scope.profilerData.transactionsData = data.message;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				});
			} else {
				apmModulesService.getProfilerTransactions($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.sliderSelectedValue, function(data){
					//hideProfilerTransactionLoading();
					console.log("Normal Ajex");
					if ( ! data.success ) {
						// err 
						messageService.showErrorMessage(data.errorMessage);
					} else {
						$scope.profilerData.transactionsData = data.message;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				});
			}
		};
		//$scope.getProfilerTransactions();

		// get Key Tranaction Data's
		$scope.getKeyProfilerTransactions = function() {
			//showProfilerTransactionLoading();
			
			if( $scope.selectedStartDateTime != null && $scope.selectedEndDateTime != null ){
				apmModulesService.getKeyProfilerTransactionsWithDateRange($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.selectedStartDateTime, $scope.selectedEndDateTime, function(data){
					//hideProfilerTransactionLoading();
					
					if ( ! data.success ) {
						// err 
						messageService.showErrorMessage(data.errorMessage);
					} else {
						$scope.profilerData.transactionsData = data.message;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				});
			}else{
				apmModulesService.getKeyProfilerTransactions($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.sliderSelectedValue, function(data){
					//hideProfilerTransactionLoading();
					
					if ( ! data.success ) {
						// err 
						messageService.showErrorMessage(data.errorMessage);
					} else {
						$scope.profilerData.transactionsData = data.message;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				});
			}
		};
		
		// on click transation charts
		$scope.getProfilerTransactionTimeTaken = function() {
			$scope.selectedTransaction = this.transaction;

			// clear methodes trace
			$scope.profilerPanel.showMethodTrace = false;
			$scope.profilerData.methodsTrace = [];
			
			$scope.profilerPanel.showTransactionTimeTaken = true;
			$scope.profilerData.transactionTimeTakenData = [];
			
			//showProfilerTransTimeTakenGraphLoading();
			
			if( $scope.selectedStartDateTime != null && $scope.selectedEndDateTime != null ){
				apmModulesService.getProfilerTransactionTimeTakenWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, $scope.selectedStartDateTime, $scope.selectedEndDateTime, function(data){
					//hideProfilerTransTimeTakenGraphLoading();
					
					if ( ! data.success ) {
						// err 
						messageService.showErrorMessage(data.errorMessage);
					} else {
						var chartData = data.message;
						$scope.profilerData.transactionTimeTakenData = $appedoUtils.changeFormatToArrayInJSON(chartData);
					}
				});
			}else{
				apmModulesService.getProfilerTransactionTimeTaken($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, $scope.sliderSelectedValue, function(data){
					//hideProfilerTransTimeTakenGraphLoading();
					
					if ( ! data.success ) {
						// err 
						messageService.showErrorMessage(data.errorMessage);
					} else {
						var chartData = data.message;
						$scope.profilerData.transactionTimeTakenData = $appedoUtils.changeFormatToArrayInJSON(chartData);
					}
				});
			}
		};

		//after seleted graph point
		$scope.getProfilerMethodTrace = function(time, duration) {
			// clear methodes trace
			//$scope.clearMethodsTrace();
			$scope.selectedTransactionTime = {time: time, duration: duration};
			
			$scope.profilerPanel.showMethodTrace = true;
			
			// gets time taken methods
			$scope.getProfilerTimeTakenMethods(time, duration);
			
			// gets profiler methods stack trace
			$scope.getProfilerMethodStackTrace(time, duration);
		};
		
		$scope.clearMethodsTrace = function() {
			// clear methodes trace
			$scope.profilerPanel.showMethodTrace = false;
			$scope.profilerPanel.showMethodTraceLoading = false;
			$scope.profilerData.isLimitedMethods = false;
			$scope.profilerData.methodsTrace = [];
			$scope.profilerData.allMethodsTrace = [];
			$scope.profilerData.timeTakenMethods = [];
		};

		
		
		// gets profiler stack trace
		$scope.getProfilerMethodStackTrace = function(time, duration) {
			// since time taken methods shown, commented loading for stackTrace
			//$scope.profilerPanel.showMethodTraceLoading = true;
			//showProfilerMethodTraceLoading();
			
			apmModulesService.getProfilerMethodTrace($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, time, duration, function(data){
				//hideProfilerMethodTraceLoading();
				
				if ( ! data.success ) {
					// err 
					messageService.showErrorMessage(data.errorMessage);
				} else {
					var aryMethodsTrace = data.message, aryRtnLimitedMethodsTrace = [];
					// since time taken methods shown, commented loading for stackTrace
					//$scope.profilerPanel.showMethodTraceLoading = false;
					
					// tried, angular.copy used to disconnect obj. by ref
					$scope.profilerData.allMethodsTrace = angular.copy(aryMethodsTrace);
					
					/* limited methods stack trace is not shown
					// to show limited method stacktrace 
	    			aryRtnLimitedMethodsTrace = apmModulesFactory.limitMethodsTrace(aryMethodsTrace, sessionServices.get('methodsTraceLimit'));
					$scope.profilerData.isLimitedMethods = aryRtnLimitedMethodsTrace[0];
					$scope.profilerData.methodsTrace = aryRtnLimitedMethodsTrace[1];
					*/
				}
			});
		};
		
		// gets time taken methods
		$scope.getProfilerTimeTakenMethods = function(time, duration) {
			//showProfilerTransMostTimeTakenMethodsLoading();
			
			apmModulesService.getProfilerTimeTakenMethods($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, time, duration, function(data){
				//hideProfilerTransMostTimeTakenMethodsLoading();
				
				if ( ! data.success ) {
					// err 
					messageService.showErrorMessage(data.errorMessage);
				} else {
					var aryTimetakenMethods = data.message;
					$scope.profilerPanel.showMethodTraceLoading = false;
					
					// 
					$scope.profilerData.timeTakenMethods = aryTimetakenMethods;
				}
			});
		};
		
/*-----------------------------------------------------------------------------------------*/
// SQL , SLOW QUERY , Function's
		
		// gets expensive queries
		// gets Profiler's MYSQL slow query data
		function getProfilerSlowQueryData(){
			if( ($scope.selectedStartDateTime != null) && ($scope.selectedEndDateTime != null) ){
		    	var resultSlowQuerydata = apmModulesService.getProfilerSlowQueryDataWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedAppCardContent.type);
		    	resultSlowQuerydata.then(function(resp) {
		        	$scope.slowSQLQueryData = resp.message;
		        	$rootScope.$emit('disable_Loader');
		        });
			} else {
		    	var resultSlowQuerydata = apmModulesService.getProfilerSlowQueryData($scope.selectedAppCardContent.guid, $scope.sliderSelectedValue, $scope.selectedAppCardContent.type);
		    	resultSlowQuerydata.then(function(resp) {
		        	$scope.slowSQLQueryData = resp.message;
		        	$rootScope.$emit('disable_Loader');
		        });
			}
		}
		
		// gets Database slow query data; (Note: Profiler & Database slow query is different)
		function getDatabaseSlowQueryData(){
			if( ($scope.selectedStartDateTime != null) && ($scope.selectedEndDateTime != null) ){
		    	var resultSlowQuerydata = apmModulesService.getDatabaseSlowQueryDataWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedAppCardContent.type);
		    	resultSlowQuerydata.then(function(resp) {
		        	$scope.slowSQLQueryData = resp.message;
		        	$rootScope.$emit('disable_Loader');
		        });
			} else {
		    	var resultSlowQuerydata = apmModulesService.getDatabaseSlowQueryData($scope.selectedAppCardContent.guid, $scope.sliderSelectedValue, $scope.selectedAppCardContent.type);
		    	resultSlowQuerydata.then(function(resp) {
					$scope.slowSQLQueryData = resp.message;
					$rootScope.$emit('disable_Loader');
		        });
			}
	    }

		function getSlowProcedureData(){
			var checkKey = ["MSSQL"]; 
			if(checkKey.indexOf($scope.selectedAppCardContent.type) >= 0) {
				if(($scope.selectedStartDateTime !=null ) && ($scope.selectedEndDateTime !=null)){
					var resultSlowProceduredata = apmModulesService.getSlowProcedureDataWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedAppCardContent.type);
			    	resultSlowProceduredata.then(function(resp) {
			    		if(resp.success){
				        	$scope.slowSQLProcedureData = resp.message;
			    		}else{
			    			$scope.slowSQLProcedureData = [];
			    		}
			    		angular.element(document).ready(function () {
							$rootScope.$emit('disable_Loader');
						});
			        });
				}else{
			    	var resultSlowProceduredata = apmModulesService.getSlowProcedureData($scope.selectedAppCardContent.guid, $scope.sliderSelectedValue, $scope.selectedAppCardContent.type);
			    	resultSlowProceduredata.then(function(resp) {
			    		if(resp.success){
				        	$scope.slowSQLProcedureData = resp.message;
			    		}else{
			    			$scope.slowSQLProcedureData = [];
			    		}
			    		angular.element(document).ready(function () {
							$rootScope.$emit('disable_Loader');
						});
			        });
				}
			}
	    }
/*----------------------------------------------------------------------------------*/	
		// AVM Page Loading Process
		$scope.selectedAvmCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
		
		$scope.userSummary = {};
		$scope.locationsStatus = [];
		
		$scope.loadingSummary = false;
		$scope.loadingDownLocations = false;
		
		$scope.currentPage = 0;
		$scope.offsetValueForResfresh = 0;  // Offset Value for Refresh
		$scope.numPerPage = 10;  // Limit per page value
		
		$scope.AVM_STATUSES = avmModuleFactory.AVM_STATUSES;
		
		$scope.loadAVMData = function() {
			messageService.loading();
			getUserTestSummary();
			getTestLocationsStatus($scope.offsetValueForResfresh, (($scope.currentPage + 1)*$scope.numPerPage), true);
			
		};
		
		// Get user's availability monitor summary 
		function getUserTestSummary() {
			showLoadingSummary();
			
			avmModuleServices.getUserTestSummary($scope.selectedAvmCardContent.testid, function(data) {
				hideLoadingSummary();
				
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.userSummary = data.message;
				}
				angular.element(document).ready(function () {
					$rootScope.$emit('disable_Loader');
				});
			});
		}
		
		// Gets down locations status 
		function getTestLocationsStatus(offSet, numPerPage, isRefresh) {
			if ( $scope.selectedAvmCardContent.status === 'Completed' ) {
				// for AVM `Completed` test's, not called location status 
			} else {
				showLoadingDownLocations();
				
				avmModuleServices.getTestLocationsStatus($scope.selectedAvmCardContent.testid, offSet, numPerPage, function(data) {
					hideLoadingDownLocations();
					var aryLocationsStatusData = [];
					if (!data.success) {
						// err
						messageService.showErrorMessage(data.errorMessage);
					} else {
						// If the function is invoked on refresh clear the array.
						if(isRefresh){
							$scope.locationsStatus = [];
						}
		
						aryLocationsStatusData = data.message;
		
						if(aryLocationsStatusData.length > 0) {
							$scope.disableLoadMore = false;
							for (var i = 0; i < aryLocationsStatusData.length; i++) {
								$scope.locationsStatus.push(aryLocationsStatusData[i]);
							}
						} else {
							$scope.disableLoadMore = true;
						}
					}
				});
			}
		}

		// Load more 
		$scope.loadMore = function() {
			$scope.currentPage++;
		    $scope.offSet = ($scope.currentPage * $scope.numPerPage);
		    getTestLocationsStatus($scope.offSet, $scope.numPerPage, false);
		};
		
		
		function showLoadingSummary() { $scope.loadingSummary = true; }
		function hideLoadingSummary() { $scope.loadingSummary = false; }
		function showLoadingDownLocations() { $scope.loadingDownLocations = true; }
		function hideLoadingDownLocations() { $scope.loadingDownLocations = false; }
		
/*----------------------------------------------------------------------*/
		var responseData = {};
		//call the all OAD and AVM function
		function loadSelectedDetails() {
			if( $scope.apmMonitorRadio === "MONITOR" ) {
				// get application data
				$scope.isOADChartAvailable = true;
				messageService.loading();
				
				$scope.selectedEnterprise = JSON.parse(sessionServices.get("selectedEnterprise")); 
				getOADChartData().then(function(jaCharts){
					console.log("inside getOAD Response - cardLayout");
					$scope.OADChartLoaded = true;
					$scope.LOGChartLoaded = true;
					$scope.RUMChartLoaded = true;
					$scope.SUMChartLoaded = true;
					chartLoader();
				});
				
			} else if( $scope.apmMonitorRadio === "TRANSACTION" ) {
				// get profiler data
				$scope.loadProfilerDetails();
				messageService.loading();
			} else if( $scope.apmMonitorRadio === "KEY_TRANSACTION" ) {
				// get profiler KEY TRANSACTIONS data
				$scope.loadKeyProfilerDetails();
				messageService.loading();
			} else if( $scope.apmMonitorRadio === "PROFILER_SLOW_QUERY" ) {
				// get profiler Slow query data
				getProfilerSlowQueryData();
				messageService.loading();
			} else if( $scope.apmMonitorRadio === "SLOW_QUERY" ) {
				// gets db SLOW query data
				getDatabaseSlowQueryData();
				messageService.loading();
			} else if( $scope.apmMonitorRadio === "SLOW_PROCEDURE" ) {
				// gets SLOW procedure data
				getSlowProcedureData();
				messageService.loading();
			} else if( $scope.apmMonitorRadio === "AVM_Details" ) {
				// gets AVM Details page data
				$scope.loadAVMData();
			}else if( $scope.apmMonitorRadio === "SUM_Details" ) {
				// gets SUM Details page data
				//$scope.ngSliderValue = 4;
				responseData.startDateTime = $scope.selectedStartDateTime;
				responseData.endDateTime = $scope.selectedEndDateTime;
				responseData.strInterval = $scope.sliderSelectedValue;
				if(responseData.endDateTime == null){
					var stD;
					var enD = new Date();
					var intr = parseInt(responseData.strInterval.substring(0,responseData.strInterval.indexOf(" ")));
					var intr_unit = responseData.strInterval.substring(responseData.strInterval.indexOf(" ")+1);
					if(intr_unit == "days" || intr_unit == "day") {
						stD = new Date(enD.getFullYear() , enD.getMonth(), enD.getDate()-intr,0,0,0);
					}else {
						stD = new Date(enD.getFullYear() , enD.getMonth(), enD.getDate(),enD.getHours()-intr,enD.getMinutes(),0);
					}
					responseData.startDateTime = stD.getTime();
					responseData.endDateTime = enD.getTime();
				}
				
				$rootScope.$emit('call_SUM_Details', responseData);	
			}
		}
		
		 
		// load data, based on slider interval 
		$scope.loadSelectedTypeData = function() {
			// loads selected panel type's, say MONITOR or TRANSACTION or ...
			loadSelectedDetails();
		};
		loadSelectedDetails();
		
		$scope.openMoreMethodsTrace = function() {
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/oad/more_methods_trace.html',
				controller: 'methodsTraceDetailsController',
				size: 'lg',
				resolve: {
					methodsTrace: function() {
						return $scope.profilerData.allMethodsTrace;
						//return $scope.profilerData.methodsTrace;
					},
					transaction: function() {
						return $scope.selectedTransaction;
					},
					transactionTime : function() {
						return $scope.selectedTransactionTime;
					}
				}
			});
			
		};
		
		$scope.updateAPMProfilerKey = function(){
			var selectedTransaction = this.transaction;
			selectedTransaction.keyTransactionName = "";
			selectedTransaction.keyTransactionDescription = "";
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/oad/add_profiler_key.html',
				controller: 'apmProfilerKeyController',
				size: 'lg',
				resolve: {
					transaction: function() {
						return selectedTransaction;
					}
				}
			});
		};
	} else if($location.path() == "/log_details") {
		$scope.selectedDetailsModule = sessionServices.get("selectedModule");
		$scope.selectedAppCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
		$scope.logDetails = {};
		$scope.logTypes = [];
		$scope.logDetails.uid = $scope.selectedAppCardContent.col_4.var3;
		$scope.logDatas = [];
		$scope.isLOGDataAvailable = true;
		if(sessionServices.get("RadioOption") == "MONITOR"){
			$scope.logMonitorRadio = 'MONITOR';
		}else {
			$scope.logMonitorRadio = 'DETAILS';
		}
		$scope.logLevelList = [{ name: 'All', value: 'ALL' }, 
								{ name: 'Info', value: 'INFO' }, 
								{ name: 'Warning', value: 'WARNING' },
								{ name: 'Critical', value: 'CRITICAL' }];
		
		$scope.selectedLogLevel = {};
		$scope.selectedLogLevel = $scope.logLevelList[0];
		$scope.getAllMyCharts();
		var radio_buttons_URL="common/data/log_details_radio_button_value.json";
		// gets module radio btns
		$scope.getLOGTypeRadioButtons = function() {
			ajaxCallService.getJsonData(radio_buttons_URL, function(responseData){
				$scope.logRadioButtonValues = responseData;
			});
		};
		$scope.getLOGTypeRadioButtons();
		$scope.loadOnLogLevelChange = function() {
			messageService.loading();
			$scope.logDatas = [];
			getLOGsData();
		};
		$scope.loadOnLogTypeChange = function() {
			$scope.logDatas = [];
			messageService.loading();
			if ($scope.selectedLogType.name != 'TOMCAT_ACCESS' && $scope.selectedLogType.name != 'TOMCAT_CATALINA') {
				$scope.selectedLogLevel = $scope.logLevelList[0];
			}
			getLOGsData();
		};
		
		function loadLogChartData() {
			joCounterSummary.uid = $scope.selectedAppCardContent.col_4.var3;
			joCounterSummary.moduleName = $scope.selectedAppCardContent.col_1.var4;
			getLOGCountChartData(joCounterSummary).then(function(){
					$scope.LOGChartLoaded = true;
					$scope.RUMChartLoaded = true;
					$scope.OADChartLoaded = true;
					$scope.SUMChartLoaded = true;
					chartLoader();
			});
		}
		
		$scope.loadSelectedLOGTypeData = function() {
			$scope.selectedEnterprise = JSON.parse(sessionServices.get("selectedEnterprise"));
			if( $scope.logMonitorRadio === "MONITOR" ) {
				// get application data
				$scope.charts = {};
				$scope.joGraphData = {};
				messageService.loading();
				loadLogChartData();
			} else if ($scope.logMonitorRadio === "DETAILS"){
				$scope.isLOGDataAvailable = true;
				$scope.logDatas = [];
				$scope.searchText = {};
				messageService.loading();
				if ($scope.logTypes != undefined && $scope.logTypes.length > 0) {
					getLOGsData();
				} else {
					$scope.getLOGTypes();
				}
			}
		};
		$scope.loadSelectedLOGTypeData();
		
		$scope.getLOGTypes = function() {
			//$scope.showLoadingServiceMaps = true;
			var resultLOGTypes = logService.getLOGTypes($scope.logDetails.uid, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime);
			resultLOGTypes.then(function(resp) {
				if( ! resp.success ){
					// error message to be displayed 
					messageService.showErrorMessage(resp.errorMessage);
				} else {

					var joLogTypesData = resp.message;
					if (joLogTypesData.logType.length > 0) {
						$scope.logDetails.osName = joLogTypesData.logType[0].osName;
						$scope.logTypes = joLogTypesData.logType;
						$scope.selectedLogType=$scope.logTypes[0];
						
						getLOGsData();
					} else {
						$scope.isLOGDataAvailable = false;
						messageService.showInfoMessage("No Logs found.");
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				}
			});
		};
		
		function getLOGsData() {
			var resultLOGsData = logService.getLOGSData($scope.logDetails.uid, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedLogType.value, $scope.selectedLogType.tableName, $scope.selectedLogLevel.value, $scope.selectedEnterprise );
			resultLOGsData.then(function(resp){
				if( ! resp.success ){
					// error message to be displayed 
					messageService.showErrorMessage(resp.errorMessage);
					$rootScope.$emit('disable_Loader');
				} else {
					var jaLogsData = [];
					var source;
					jaLogsData = resp.message;
					for (i=0; i<jaLogsData.length; i++) {
						source = jaLogsData[i].source;
						source = source.split("/");
						jaLogsData[i].source = source[source.length - 2]+"/"+source[source.length - 1];
					}
					$scope.logDatas = jaLogsData;
					if ($scope.logDatas.length > 0) {
						$scope.isLOGDataAvailable = true;
					} else {
						$scope.isLOGDataAvailable = false;
						messageService.showInfoMessage("No Data Found")
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				}
			});
		}
		
	} else if($location.path() == "/rum_details") {
		$scope.selectedDetailsModule = sessionServices.get("selectedModule");
		$scope.selectedAppCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
		$scope.rumCards = [];
		$scope.rumDatas  = [];
		$scope.rumFilterValueList = [];
		$scope.selectedRUM = {};
		$scope.selectedRUMFilterValue = {};
		$rootScope.rumDetails = {};
		$rootScope.rumDetails.uid = $scope.selectedAppCardContent.col_4.var3;
		$rootScope.rumDetails.moduleName = $scope.selectedAppCardContent.col_2.var1;
		$scope.isRUMDataAvailable = true;
		var rumTransformData = {};	
		
		if(sessionServices.get("RadioOption") == "MONITOR"){
			$scope.rumMonitorRadio = 'MONITOR';
		}else {
			$scope.rumMonitorRadio = 'DETAILS';
		}
		$scope.rumFilterTypeList = [{ name: 'Browser', value: 'browser_name' }, 
								{ name: 'Device Type', value: 'device_type' }, 
								{ name: 'Location', value: 'city_name' },
								{ name: 'OS', value: 'os' }];
		
		$scope.selectedRUMFilterType = $scope.rumFilterTypeList[0];
		$scope.getAllMyCharts();
		var radio_buttons_URL="common/data/rum_details_radio_button_value.json";
		// gets module radio btns
		$scope.getRUMTypeRadioButtons = function() {
			ajaxCallService.getJsonData(radio_buttons_URL, function(responseData){
				$scope.rumRadioButtonValues = responseData;
			});
		};
		$scope.getRUMTypeRadioButtons();
		
		$scope.loadSelectedRUMTypeData = function() {
			$scope.selectedEnterprise = JSON.parse(sessionServices.get("selectedEnterprise"));
			if( $scope.rumMonitorRadio === "MONITOR" ) { 
				// get application data
				$scope.charts = {};
				$scope.joGraphData = {};
				messageService.loading();
				loadRUMChartsData(); 
			} else if ($scope.rumMonitorRadio === "DETAILS"){
				$scope.rumDatas = [];
				$scope.searchText = {};
				messageService.loading();
				if ($scope.rumCards != undefined && $scope.rumCards.length > 0) {
					getRUMFilterValues();
				} else {
					getRUMCards();
				}
			} else if ($scope.rumMonitorRadio === "EVENTS") {
				getRUMCards();
				rumTransformData.uid = $rootScope.rumDetails.uid;
				rumTransformData.startDateTime = $scope.selectedStartDateTime;
				rumTransformData.endDateTime = $scope.selectedEndDateTime;
				rumTransformData.strInterval = $scope.sliderSelectedValue;
				rumTransformData.moduleName = $rootScope.rumDetails.moduleName;
				rumTransformData.isSliderDateChange = true;
				$rootScope.$emit('call_RUM_Events', rumTransformData);	
			}
		};
		$scope.loadSelectedRUMTypeData();
		
		$scope.loadOnRUMFilterTypeChange = function() {
			
			$rootScope.rumDetails.uid = $scope.selectedRUM.value;
			$rootScope.rumDetails.moduleName = $scope.selectedRUM.name;
			if ($scope.rumMonitorRadio === "DETAILS"){
				messageService.loading();
				$scope.rumDatas = [];
				getRUMFilterValues();
			} else {
				rumTransformData.uid = $rootScope.rumDetails.uid;
				rumTransformData.startDateTime = $scope.selectedStartDateTime;
				rumTransformData.endDateTime = $scope.selectedEndDateTime;
				rumTransformData.strInterval = $scope.sliderSelectedValue;
				rumTransformData.moduleName = $rootScope.rumDetails.moduleName;
				rumTransformData.isSliderDateChange = false;
				$rootScope.$emit('call_RUM_Events', rumTransformData);
			}
			
		}
		
		$scope.loadOnRUMFilterValueChange = function() {
			messageService.loading();
			$scope.rumDatas = [];
			getRUMData();
		}
		
		function loadRUMChartsData() {
			if($scope.rumDetails.moduleName != undefined) {
				joCounterSummary.uid = $scope.rumDetails.uid;
			} else {
				joCounterSummary.uid = $scope.selectedAppCardContent.col_4.var3;
				$rootScope.rumDetails.moduleName = $scope.selectedAppCardContent.col_2.var1;
				$rootScope.rumDetails.uid = $scope.selectedAppCardContent.col_4.var3;
			}
			getRUMPageViewsChartData(joCounterSummary).then(function(jaCharts){
					$scope.OADChartLoaded = true;
					$scope.RUMChartLoaded = true;
					$scope.SUMChartLoaded = true;
					$scope.LOGChartLoaded = true;
					chartLoader();
			});
		}
		
		 function getRUMCards(){   
			var resultRUMCards = rumService.getRUMCards($scope.selectedEnterprise);
			resultRUMCards.then(function(resp) {
				if( ! resp.success ){
					// error message to be displayed 
					messageService.showErrorMessage(resp.errorMessage);
					$rootScope.$emit('disable_Loader');
				} else {
					var jaRUMCardsData = resp.message;
					if (jaRUMCardsData.length > 0) {
						$scope.isRUMDataAvailable = true;
						$scope.rumCards = jaRUMCardsData;
						if ($scope.rumDetails != undefined ){
							var tempRUM = {};
							tempRUM.name = $scope.rumDetails.moduleName;
							tempRUM.value = $scope.rumDetails.uid;
							//$scope.selectedAppCardContent.col_4.var3 = null;
								for (var i = 0; i < $scope.rumCards.length; i++)
								{
									if (tempRUM.value == $scope.rumCards[i].value) {
										$scope.selectedRUM = $scope.rumCards[i]; 
										break;
										}
								}
						} else {
							$scope.selectedRUM=$scope.rumCards[0];
						}
						if ($scope.rumMonitorRadio === "DETAILS") {
							getRUMFilterValues();
						}
						
					} else {
						messageService.showErrorMessage("No RUM found.");
						$scope.isRUMDataAvailable = false;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				}
			});
		}
		
		function getRUMFilterValues() {
			var resultRUMFilterValuesData = rumService.getRUMFilterValues($scope.selectedRUM.value, $scope.selectedRUMFilterType.value, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime);
			resultRUMFilterValuesData.then(function(resp){
				if( ! resp.success ){
					// error message to be displayed 
					messageService.showErrorMessage(resp.errorMessage);
					$rootScope.$emit('disable_Loader');
				} else {
					var jaRUMFilterValues = [];
					jaRUMFilterValues = resp.message;
					if (jaRUMFilterValues.length > 0){
						$scope.rumFilterValueList = jaRUMFilterValues;
						$scope.selectedRUMFilterValue = $scope.rumFilterValueList[0];
						$scope.isRUMDataAvailable = true;
						getRUMData();
					} else {
						$scope.rumFilterValueList = [{name:'No Data', value:' '}];
						$scope.selectedRUMFilterValue = $scope.rumFilterValueList[0];
						messageService.showInfoMessage("No Data found.");
						$scope.isRUMDataAvailable = false;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				}
			});
		}
		
		function getRUMData() {
			var resultRUMData = rumService.getRUMDatas($scope.selectedRUM.value, $scope.selectedRUMFilterType.value, $scope.selectedRUMFilterValue.value, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime);
			resultRUMData.then(function(resp){
				if( ! resp.success ){
					// error message to be displayed 
					messageService.showErrorMessage(resp.errorMessage);
					$rootScope.$emit('disable_Loader');
				} else {
					//var jaRUMDatas = [];
					var jaRUMDatas = resp.message;
					$scope.rumDatas = jaRUMDatas;
					if ($scope.rumDatas.length == 0){
						messageService.showInfoMessage("No Data found.");
						$scope.isRUMDataAvailable = false;
					} else {
						$scope.isRUMDataAvailable = true;
					}
					angular.element(document).ready(function () {
						$rootScope.$emit('disable_Loader');
					});
				}
			});
		}
	}
	else {
	$scope.aryHealths = [ { name: 'All Critical', value: 'CRITICAL' }, 
						{ name: 'Critical & Warning', value: 'CRITWARN' }/*, 
						{ name: 'Healthy,Critical & Warning', value: 'CWV' },
						{ name: 'Metric without values', value: 'CWOV' }*/];
	
	$scope.graphHeaderFields = {};


//	$scope.loginUserData.defaultCritWarn;
	$scope.OADCalledService = 0;
	$scope.RUMCalledService = 0;
	$scope.SUMCalledService = 0;
	$scope.LOGCalledService = 0;
	/*$scope.OADChartLoaded = true;
	$scope.RUMChartLoaded = true;
	$scope.SUMChartLoaded = true;
	$scope.LOGChartLoaded = true;*/

	$scope.loginUserData = JSON.parse(sessionServices.get('loginUser'));
	if($scope.loginUserData != null && $scope.loginUserData.hasOwnProperty("defaultCritWarn")){
		var arr_pos = $filter('filter')($scope.aryHealths, {value: $scope.loginUserData.defaultCritWarn}, true)[0];
		$scope.graphHeaderFields.health = $scope.aryHealths[$scope.aryHealths.indexOf(arr_pos)];
	} else {
		$scope.graphHeaderFields.health = $scope.aryHealths[0];
	}
	
	$scope.selectedServiceMap = {};
	//TODO : needed to pagination concept
	var chartPerPage = 10;
	$scope.pagination = {};
	$scope.pagination.maxSize = 5;
	$scope.pagination.currentPage = 1;
	$scope.pagination.totalItems = Object.keys($scope.charts).length;
	
	$scope.selectedPage = function(page) {
		$scope.slaAlerts = [];
		var offSet = ((page - 1) * chartPerPage);
		showLoading();
		
		slacardService.getSLAAlerLog($scope, $scope.slaId, offSet, chartPerPage, function(slaALerLogCardData) {
			hideLoading();
			
			$scope.slaAlerts = {};
			$scope.totalLength = slaALerLogCardData.total_count;
			$scope.slaAlerts = slaALerLogCardData.log_records;
		});
	};
	
	//$scope.getAllMyCharts();
	
	//set as Default
	$scope.setAsDefault = function(defaultValueOn) {
		
		apmModulesService.setAsDefaultDashboard($scope, defaultValueOn == 'healthCode' ? $scope.graphHeaderFields.health.value : null, defaultValueOn == 'serviceMap' ? $scope.selectedServiceMap.serviceMapId : null, function(response) {
			if(!response.success) {
				messageService.showErrorMessage(response.errorMessage);
			}else {
				messageService.showSuccessMessage(response.message);
			}
		});
		console.log("setAsDefault");
	};

	//set as Default
	$scope.setAsDefault = function(defaultValueOn) {
		
		apmModulesService.setAsDefaultDashboard($scope, defaultValueOn == 'healthCode' ? $scope.graphHeaderFields.health.value : null, defaultValueOn == 'serviceMap' ? $scope.selectedServiceMap.serviceMapId : null, function(response) {
			if(!response.success) {
				messageService.showErrorMessage(response.errorMessage);
			}else {
				messageService.showSuccessMessage(response.message);
			}
		});
		//console.log("setAsDefault");
	};


	$scope.openAddModuleType = function () {
//		console.info("inside openaddmodule");
		var moduleType = "Service Map";
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
//			backdrop : 'static'
			resolve: {
				moduleType: function() {
					return moduleType;
				}
			}
		});
	};
	
	$scope.loadOnServiceMapHealthChange = function (){
		if ($scope.selectedServiceMap != null && $scope.graphHeaderFields.health != null){
			$scope.selectedMyChart = undefined;
			$scope.isDefaultMyChartModified = false;
			if ($scope.selectedStartDateTime != null && $scope.selectedEndDateTime != null) {
	        	$scope.sliderSelectedValue = null;
				}
			reloadChartData();
		}
	};
	
	// gets static chart data 
	$scope.getChartData = function() {
		appedoChartsServices.getChartData(function(resp) {
			console.info('Chart data resp');
			
			$scope.charts = resp;
			
			//console.info('$scope.charts: '+JSON.stringify($scope.charts));
		});
	};
	//$scope.getChartData();
	//console.log("in Appedo chart controller : "+$scope.startDateTime +"--"+$scope.endDateTime);
	//console.log("after getChartData()");
	$scope.loadSelectedChartPoinDetails = function(joDatum) {
		console.info('<<<<<<<<<<< appedoChartsController >>>>>>>>>>>>>>');
		console.info('joDatum: '+JSON.stringify(joDatum));
	};
	
	// grids data
	$scope.serviceMapsHealth = [];
	

	var nCustomStartDateTime = null, nCustomEndDateTime = null;
	nCustomStartDateTime = $scope.startDateTime;
	nCustomEndDateTime =$scope.endDateTime;
	
	
	// gets Service Maps overall health
	$scope.getServiceMapsHealth = function() {
		messageService.loading();
		$scope.showLoadingServiceMaps = true;
		serviceMapService.getServiceMaps(function(resp){
			$scope.showLoadingServiceMaps = false;
			if ( ! resp.success ) {
				$scope.isChartAvailable
				$rootScope.$emit('disable_Loader');
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.serviceMapsHealth = resp.message;
				var selectedAppCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
				var entDetails = JSON.parse(sessionServices.get("selectedEnterprise"));
				/*if (!$rootScope.isEnterpriseSelected) {
					
				} */
				//console.log("in service map :" +entDetails);
				//console.log("in service map :" +entDetails.e_id);
				if (selectedAppCardContent != undefined && selectedAppCardContent.col_1.var4 == 'Service Map' && selectedAppCardContent.serviceMapId != undefined && selectedAppCardContent.col_2.var1 != undefined) {
					var tempServiceMap = {};
					tempServiceMap.serviceMapId = selectedAppCardContent.serviceMapId;
					tempServiceMap.serviceMapName = selectedAppCardContent.col_2.var1;
					
					for (var i = 0; i < $scope.serviceMapsHealth.length; i++)
					{
						if (tempServiceMap.serviceMapId == $scope.serviceMapsHealth[i].serviceMapId) {
							$scope.selectedServiceMap = $scope.serviceMapsHealth[i]; 
							break;
							}
					}
					//$scope.selectedServiceMap = tempServiceMap;
					selectedAppCardContent = {};
					//sessionServices.set("selectedAppCardContent", null);
				} else if(entDetails != undefined && entDetails.e_id > 0) {
					$scope.selectedServiceMap = $scope.serviceMapsHealth[0];
				} else if($scope.loginUserData != null && $scope.loginUserData.hasOwnProperty("defaultServiceMapId")){
					var serviceMap_pos = $filter('filter')($scope.serviceMapsHealth, {serviceMapId: $scope.loginUserData.defaultServiceMapId}, true)[0];
					$scope.selectedServiceMap = $scope.serviceMapsHealth[$scope.serviceMapsHealth.indexOf(serviceMap_pos)];
				} else {
					$scope.selectedServiceMap = $scope.serviceMapsHealth[0];
				}
					//if($scope.loginUserData.hasOwnProperty("defaultServiceMapId") && ($scope.loginUserData.defaultServiceMapId != null || $scope.loginUserData.defaultServiceMapId.trim != '')){
					
				
				if( $scope.serviceMapsHealth.length === 0 || $scope.selectedServiceMap == undefined ){
					// show blank page instructions
					$scope.isChartAvailable= false;
					$rootScope.$emit('disable_Loader');
				} else {
					getServiceMapBreaches();
				}
			}
		});
	};
		
	//$scope.getServiceMapsHealth();
	}
	function getServiceMapBreaches() {
		if (document.querySelector('.apd-chart-tooltip') != null) {
			console.info("chart tooltip clear");
        	//d3.select("#tooltip"+attrs.idx).remove();
			$('.apd-chart-tooltip').remove();
        }
		messageService.loading();
		if ($scope.selectedServiceMap == undefined){
			$scope.isChartAvailable= false;
			$rootScope.$emit('disable_Loader');
		} else {
			serviceMapService.getModuleCountersData_v1($scope.selectedServiceMap.serviceMapId, null, null, $scope.graphHeaderFields.health.value, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, loadBreachedCountersData);
		}
	}	

	//auto Refresh set Variable
	$scope.autoRefreshEnabled = true;
	// loads chart data for breached ASD counters, SUM tests & RUM modules
	function loadBreachedCountersData(resp) {
		//hideLoadingBreaches();
		$scope.lastRefreshedOn = new Date().getTime();
		
		if ( ! resp.success ) {
			$rootScope.$emit('disable_Loader');
			// err
			//messageService.showErrorMessage(resp.errorMessage);
		} else {
			//dashboard Auto refresh
			$interval.cancel($scope.refreshTimerSet);
			if($scope.sliderSelectedValue == '1 hour'){
				$scope.autoRefreshEnabled = true;
				$scope.charts = {};
				$scope.joGraphData = {};
				refreshTimer();
			}else{
				$interval.cancel($scope.refreshTimerSet);
				$scope.autoRefreshEnabled = false;
			}

			var joRespMappedModulesDetails = resp.message;
			$scope.asdChartsData = joRespMappedModulesDetails.ASD;
			$scope.sumTests = joRespMappedModulesDetails.SUM;
			$scope.rumModules = joRespMappedModulesDetails.RUM;
			$scope.logModules = joRespMappedModulesDetails.LOG;
			isChartDataAvailable = false;
			// loads ASD chart data	
			if ( $scope.asdChartsData !== undefined && $scope.asdChartsData.length > 0) {
				isChartDataAvailable = true;
				$scope.OADChartLoaded = false;
				loadCountersChartdata();
			}
			
			// loads SUM test's chart data
			if ( $scope.sumTests !== undefined && $scope.sumTests.length > 0) {
				isChartDataAvailable = true;
				$scope.SUMChartLoaded = false;
				loadSUMTestsChartData();
			}
			
			// loads RUM module's chart data
			if ( $scope.rumModules !== undefined && $scope.rumModules.length > 0) {
				isChartDataAvailable = true;
				$scope.RUMChartLoaded = false;
				loadRUMModuleChartData();
			}
			
			// loads LOG module's chart data
			if ( $scope.logModules !== undefined && $scope.logModules.length > 0) {
				isChartDataAvailable = true;
				$scope.LOGChartLoaded = false;
				loadLOGModuleChartData();
			}
			
			$scope.isChartAvailable = isChartDataAvailable;
			if (!$scope.isChartAvailable){
				$rootScope.$emit('disable_Loader');
			}
			
		}

	}
	
	//Auto refresh timer Edit function 
	$scope.isEditRefreshTime = false;
	
	$scope.editRefTime = function(){
		console.log("iseditrefresh");
		$scope.isEditRefreshTime = true;
	};
	
	$scope.doNotUpdateRefTime = function(){
		console.log("iseditrefresh");
		$scope.isEditRefreshTime = false;
	};
	
	$scope.UpdateRefTime = function(){
		console.log($scope.setRefreshTime);
		
		if($scope.setRefreshTime <= 0){
			$interval.cancel($scope.refreshTimerSet);
			messageService.showWarningMessage("Refresh Timer is stopped, Timer starts on refresh");
			$scope.isEditRefreshTime = false;
			$scope.refreshTime = 0;
		}else if($scope.setRefreshTime > 0 && $scope.setRefreshTime < 30){
			messageService.showSuccessMessage("Refresh Time Minimum 30 Sec");
		}else{
			if($scope.setRefreshTime > 900 || $scope.setRefreshTime == undefined){
				$scope.setRefreshTime = 900;
				messageService.showSuccessMessage("Max time 900 Sec, hence reset to 900 sec");
			}else{
				messageService.showSuccessMessage("Settings reset on page refresh.");
			}
			sessionServices.set("cardRefreshTime", $scope.setRefreshTime);
			$scope.isEditRefreshTime = false;
			$interval.cancel($scope.refreshTimerSet);
			refreshTimer();
		}
	};
	$scope.setRefreshTime = Number(sessionServices.get("cardRefreshTime"));
	//auto refresh
	var refreshTimer = function() {
		var i = sessionServices.get("cardRefreshTime");
		$scope.refreshTimerSet = $interval(function(){
			 if(i===0){
				 
				 if ($scope.selectedMyChart != undefined && $scope.isDefaultMyChartModified) {
					 $scope.loadOnMyChartChange();
				 } else {
					 getServiceMapBreaches();
				 }
				 //i=0;
				 $scope.refreshTime = i;
				 $interval.cancel($scope.refreshTimerSet);
			 }else{
				 $scope.refreshTime = i; 
			 }
			i--;
		},1000);
	};
	
	// loads ASD's counter's chart data
	function loadCountersChartdata() {
		// get counters chart data
		var OADTotal = 0;
		OADTotal = $scope.asdChartsData.length;
		//$scope.OADCalledService = 0;
		
		for(var i = 0; i < $scope.asdChartsData.length; i = i + 1) {
			joCounterSummary = $scope.asdChartsData[i];
			joCounterSummary.loadingChartData = true;
			// for hotspots
			joCounterSummary.label = joCounterSummary.displayName;
			joCounterSummary.breaches = [];
			
			// get counter chart data
			//getModuleCountersChartdata_v1(joCounterSummary.guid, joCounterSummary.counterId, joCounterSummary.maxTimeStamp != undefined ? joCounterSummary.maxTimeStamp : null, joCounterSummary.isAboveThreshold, joCounterSummary);
			//respArray.add(true);
			//respArray[i] = false;
			getOADChartData().then(function(jaCharts){
				//console.log(" OAD Chart Loaded");
				//console.log("total Charts :"+Object.keys($scope.charts).length);
				//console.log("total JoGraphData :"+Object.keys($scope.joGraphData).length);
				//$scope.charts = joCharts;
				
				//chartDatas = jaCharts;
				//respArray.add(true);
				$scope.OADCalledService++;
//				console.log($scope.OADCalledService);
				if (OADTotal <= $scope.OADCalledService ) {
					//console.log("chart Loaded ");
					$scope.OADChartLoaded = true;
					chartLoader();
				}
				//console.log("chartDatas :"+JSON.stringify(chartDatas));
				//$rootScope.$emit('disable_Loader');
			});/*.finally(function(){
				//console.log(" in finally------------------------------");
				console.log("chartDatas :"+JSON.stringify(chartDatas));
			});*/
			//console.log(" inside looping");
		}
		//console.log("after loop : "+$scope.OADCalledService);
		/*do	 {
			setTimeout( function(){}, 1000);
			console.log("waiting -> OADTotal :"+OADTotal+" ::::: OATCalledService : "+$scope.OATCalledService);
		}
		while (OADTotal > $scope.OATCalledService );
		*/
	//	console.log(" after looping");
		//OADResponse = true;
		
		
		//$scope.charts =chartData;
	//	$rootScope.$emit('disable_Loader');
	}
	

	function chartLoader () {

		if ($scope.OADChartLoaded && $scope.RUMChartLoaded && $scope.SUMChartLoaded && $scope.LOGChartLoaded) {
			//console.log("chart Loaded");
			$scope.OADCalledService = 0;
			$scope.RUMCalledService = 0;
			$scope.SUMCalledService = 0;
			$scope.LOGCalledService = 0;
//			console.log("totalObjec :"+Object.keys($scope.joGraphData).length);
			//console.log(JSON.stringify($scope.joGraphData));
			if (Object.keys($scope.joGraphData).length <= 0){
				$scope.isOADChartAvailable = false;
				$scope.isLOGChartAvailable = false;
				$scope.isChartAvailable = false;
			}
			$scope.charts = $scope.joGraphData;
//			console.log("disabling loader");
			$rootScope.$emit('disable_Loader');
		}
	}
	
	
	
	// loads SUM tests chart data
	function loadSUMTestsChartData() {
		var joTest = {};
		var SUMTotal = 0;
		for (var i = 0; i < $scope.sumTests.length; i = i + 1) {
			joTest = $scope.sumTests[i];
			joTest.loadingChartData = true;
			
			//validateTestType(joTest);
			if (joTest.testtype == 'URL'){
				SUMTotal++;
				//getSumChartsData(joTest);
				getSumChartsData(joTest).then(function(jaCharts){
					$scope.SUMCalledService++;
					console.log($scope.SUMCalledService);
					if (SUMTotal <= $scope.SUMCalledService ) {
						//console.log("SUM chart Loaded ");
						$scope.SUMChartLoaded = true;
						chartLoader();
					}
				});
			}
			
		}
	}
	

	// 
	function validateTestType(joTest) {
		
		if ( joTest.testtype === 'URL' ) {
			// gets SUM test chart data
			$scope.getSUMMultiLineChartData(joTest);
		} else {
			// gets test'stransaction pages
			getSUMTestPages(joTest);
		}
	};
	
	 
	
	// gets test's transaction pages
	function getSUMTestPages(joParamTest) {
		sumModuleServices.getSUMTestPages(joParamTest.test_id, function(data) {
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var aryRespTestTransactionPages = data.message;
				//var nRespTestId = parseInt(data.testId);
				var joTest = {};
				joTest = joParamTest;
				joTest.selectedTransactionPage = {};
				if (aryRespTestTransactionPages.length > 0) {
					joTest.selectedTransactionPage = aryRespTestTransactionPages[0];
				}
					return $scope.getSUMMultiLineChartData(joTest);
			}
		});
	};
	
	// gets test's chart data
	$scope.getSUMMultiLineChartData = function(joTest, query, location){
			// selected Transaction page sets
			var pageId = '', pageName = '';
			if( joTest.selectedTransactionPage != undefined ) {
				pageId = joTest.pageId;
				pageName = joTest.pageName;
			}
			if ( joTest.testtype === 'TRANSACTION' && pageId === '' ) {
				// For SUM Transactions, Avoid to get chartdata when nullabel value of `Scanned Pages` selected
				var joNone = {};
				return joNone;
			} else {
				var resultSUMMultiLine = sumModuleServices.getSUMMultiLine(joTest.test_id, pageId, pageName, $scope.sliderSelectedValue, $scope.selectedStartDateTime, $scope.selectedEndDateTime, query, location);
				resultSUMMultiLine.then(function(resp) {
					var aryRespChartData;
					if(resp.success){
						aryRespChartData = resp.message;
					} else {
						aryRespChartData = {};
					}
					return aryRespChartData;
				});
			}
		//}
	};	
	
	// loads RUM module's chart data
	function loadRUMModuleChartData() {
		var joModule = {};
		var RUMTotal = 0;
		RUMTotal = $scope.rumModules.length;
		for (var i = 0; i < $scope.rumModules.length; i = i + 1) {
			joModule = $scope.rumModules[i];
			joModule.loadingChartData = true;

			// gets RUM's page view(s) chartdata
			//getRUMPageViewsChartData(joModule);
			getRUMPageViewsChartData(joModule).then(function(jaCharts){
				$scope.RUMCalledService++;
				console.log($scope.RUMCalledService);
				if (RUMTotal <= $scope.RUMCalledService ) {
					//console.log("SUM chart Loaded ");
					$scope.RUMChartLoaded = true;
					chartLoader();
				}
			});
		}
	}
	// $scope.selectedStartDateTime, $scope.selectedEndDateTime,  $scope.graphHeaderFields.health.value

	
	// loads LOG module's chart data
	function loadLOGModuleChartData() {
		var joModule = {};
		var LOGTotal = 0;
		LOGTotal = $scope.logModules.length;
		for (var i = 0; i < $scope.logModules.length; i = i + 1) {
			joModule = $scope.logModules[i];
			joModule.loadingChartData = true;

			// gets LOG's count chartdata
			//getLOGCountChartData(joModule);
			getLOGCountChartData(joModule).then(function(jaCharts){
				$scope.LOGCalledService++;
				console.log($scope.LOGCalledService);
				if (LOGTotal <= $scope.LOGCalledService ) {
					console.log("chart Loaded ");
					$scope.LOGChartLoaded = true;
					chartLoader();
				}
			});
		}
	}
	

	$scope.$on('$destroy', function() {
		$interval.cancel($scope.refreshTimerSet);
    });
}]);

appedoApp.controller('enterprise_Controller', ['$scope', '$uibModal', '$uibModalInstance', 'enterpriseService', 'sessionServices', 'messageService', 
                                               function ($scope, $uibModal, $uibModalInstance, enterpriseService, sessionServices, messageService){
	
	//close Modal
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	
	$scope.enterpriseData = {};
	//set name of header
	$scope.formName = "Add";
	$scope.saveBtn = "Save";
	$scope.showProceed = true;
	
	//Validate Enterprise name
	$scope.validateEnterpriseName = function() {
		if($scope.enterpriseData.enterpriseName != '' && $scope.enterpriseData.enterpriseName != undefined) {
			enterpriseService.validateEnterpriseName($scope, $scope.enterpriseData.enterpriseName, function(data) {
	    		if(data.success){
	    			$scope.showProceed = data.message=="true"?true:false;
	    			if(data.message=='true'){
	            		messageService.showErrorMessage($scope.enterpriseData.enterpriseName+" is already exists.");
	    			}
	    		}else{
	    			$scope.showProceed = true;
	    		}
	    	});
		}
	};
	//end of validate Enterprise Name
	
	//adding Enterprise Data
	$scope.addEnterprise = function() {
		enterpriseService.addEnterpriseData($scope, $scope.enterpriseData.enterpriseName, $scope.enterpriseData.enterpriseDescription, function(data) {
    		if(data.success){
            		messageService.showSuccessMessage(data.message);
            		$uibModalInstance.dismiss('cancel');
            		var modalInstance = $uibModal.open({
            			templateUrl: 'common/views/enterprise/user_mapping.html',
            			controller: 'userEnterpriseMappingController',
            			size: 'lg',
            			resolve: {
            				enterpriseId: function() {
            					return data.e_id;
            				},
            				enterpriseUserDetails: function() {
            					return $scope.enterpriseData;
            				},
            			}
            		});
    		}else{
    			//messageService.showErrorMessage("Unable to add Enterprise");
    			messageService.showErrorMessage(data.errorMessage);
    		}
    	});
		
	};

}]);

appedoApp.controller('userEnterpriseMappingController', ['$scope', '$uibModal', '$uibModalInstance', 'enterpriseService', 'enterpriseUserDetails', 'sessionServices', 'messageService', 'enterpriseId', 'cardDetailsServices',
                                               function ($scope, $uibModal, $uibModalInstance, enterpriseService, enterpriseUserDetails, sessionServices, messageService, enterpriseId, cardDetailsServices){
	
	//close Modal
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
		cardDetailsServices.openEnterpriseViewMappedUser('fromEdit', enterpriseUserDetails, enterpriseId);
	};
	
	$scope.userProfile = {};
	
	$scope.enterpriseId = enterpriseId;
	$scope.enterpriseUserDetails = enterpriseUserDetails;
	$scope.enterpriseName = enterpriseUserDetails.enterpriseName || enterpriseUserDetails.col_2.var1;
	$scope.saveAndAddUserEnterpriseMapping = function(){
		console.log($scope.enterpriseId);
		enterpriseService.addUserEnterpriseMapping($scope, $scope.userProfile, $scope.enterpriseId, $scope.enterpriseName, function(data) {
    		if(data.success){
    			$scope.userProfile = {};
        		messageService.showSuccessMessage(data.message);
			}else{
				messageService.showErrorMessage(data.errorMessage);
			}
		});
	};
	
	$scope.saveAndFinishUserEnterpriseMapping = function(){
		console.log($scope.enterpriseId);
		enterpriseService.addUserEnterpriseMapping($scope, $scope.userProfile, $scope.enterpriseId,  $scope.enterpriseName, function(data) {
    		if(data.success){
        		messageService.showSuccessMessage(data.message);
        		$uibModalInstance.dismiss('cancel');
        		cardDetailsServices.openEnterpriseViewMappedUser('fromEdit', enterpriseUserDetails, enterpriseId);
			}else{
				messageService.showErrorMessage(data.errorMessage);
			}
		});
	};
	
}]);

appedoApp.controller('enterpriseViewMapUser', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'enterpriseUserDetails', 'e_Id', 'enterpriseService', '$rootScope', 'messageService',
  	function($scope, $uibModal, $uibModalInstance, isFrom, enterpriseUserDetails, e_Id, enterpriseService, $rootScope, messageService) {
 	$scope.close = function () {
 		$uibModalInstance.dismiss('cancel');
 	};
 	$scope.mappedcounters = [];
 	$scope.enterpriseUserDetails = enterpriseUserDetails;
 	
 	
 	$scope.getMapUsers = function() {
 		var counters;
 		counters = enterpriseService.getMapUser(e_Id);
 		counters.then(function(data) {
 			if( ! data.success ){
 				// err
 				messageService.showErrorMessage(data.errorMessage);
 			} else {
 				$scope.mappedUsers = data.message;
 			}
 		});
 	};
 	$scope.getMapUsers();
 	
 	$scope.deleteMapUser = function() {
 		var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
 		if(result == true) {
 			var mapuser;
 			mapuser = enterpriseService.deleteMapUser(this.users.e_id, this.users.userName);
 			mapuser.then(function(data) {
 				if( ! data.success ){
 					// err
 					messageService.showErrorMessage(data.errorMessage);
 				} else {
 					
 					$scope.getMapUsers();
 					//$rootScope.$emit('reloadSLACardLayout');
 				}
 			});
 		}
 	};
 	
 	$scope.addMapUser = function() {
 		$uibModalInstance.close();
 		enterpriseService.openUserEnterpriseMapping(e_Id, $scope.enterpriseUserDetails);		
 	};
 	
}]);


//for more details of methods trace
appedoApp.controller('methodsTraceDetailsController', ['$scope', '$uibModal', '$uibModalInstance', 'methodsTrace', 'transaction', 'transactionTime', 'apmModulesFactory', 
                                                       function ($scope, $uibModal, $uibModalInstance, methodsTrace, transaction, transactionTime, apmModulesFactory) {
	$scope.profilerData = {};
	$scope.profilerData.methodsTrace = methodsTrace;
	//$scope.profilerData.methodsTrace = apmModulesFactory.limitMethodsTrace(methodsTrace, 50)[1];
	//console.info('aryLimitedMethodsTrace methodsTraceDetailsController: '+JSON.stringify($scope.profilerData.methodsTrace));
	
	$scope.transaction = transaction;
	$scope.transactionTime = transactionTime;
	
    $scope.close = function () {
    	$uibModalInstance.dismiss('cancel');
    };
}]);

appedoApp.controller('apmProfilerKeyController', ['$scope', '$uibModal', '$uibModalInstance', 'transaction', 'apmModulesService', 'messageService','$rootScope', function ($scope, $uibModal, $uibModalInstance, transaction, apmModulesService, messageService, $rootScope) {
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
    };
    
    $scope.transaction = transaction;
    
    $scope.removeKey = function () {
    	apmModulesService.updateApmKeyTransaction($scope, $scope.transaction, 'delete', function(data){
			if ( data.success ) {
				$uibModalInstance.dismiss('cancel');
				var updatedTransaction = data.message;
				$scope.transaction.keyTransactionDescription = updatedTransaction.keyTransactionDescription;
				$scope.transaction.keyTransactionId = updatedTransaction.keyTransactionId;
				$scope.transaction.keyTransactionName = updatedTransaction.keyTransactionName;
				/*ngToast.create({
					className: 'success',
					content: updatedTransaction.successMessage,
					timeout: 3000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
				});*/
				messageService.showSuccessMessage(updatedTransaction.successMessage);
			} else {
				/*ngToast.create({
					className: 'warning',
					content: response.errorMessage,
					timeout: 3000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
				});*/
				messageService.showSuccessMessage(data.errorMessage);
			}
		});
    };
    
    $scope.addKey = function () {
    	apmModulesService.updateApmKeyTransaction($scope, $scope.transaction, 'insert', function(data){
    		if ( data.success ) {
    			$uibModalInstance.dismiss('cancel');
				var updatedTransaction = data.message;
				$scope.transaction.keyTransactionDescription = updatedTransaction.keyTransactionDescription;
				$scope.transaction.keyTransactionId = updatedTransaction.keyTransactionId;
				$scope.transaction.keyTransactionName = updatedTransaction.keyTransactionName;
				/*ngToast.create({
					className: 'success',
					content: updatedTransaction.successMessage,
					timeout: 3000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
				});*/
				messageService.showSuccessMessage(updatedTransaction.successMessage);
			} else {
				/*ngToast.create({
					className: 'warning',
					content: data.errorMessage,
					timeout: 3000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
				});*/
				messageService.showSuccessMessage(data.errorMessage);
			}
		});
    };
    
}]);

appedoApp.controller('myChartAddEditController', function($scope,$rootScope,sessionServices) {
	
	console.log("check");
	
});


appedoApp.controller('datePickerCtrls', function($scope,$rootScope,forDateTimeModuleMethod,sessionServices) {
	//console.info("isFrom:"+isFrom );
	$scope.customDate={};
	$scope.startOpen = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.startOpened = true;
	};
	$scope.endOpen = function($event) {
		$event.preventDefault();
		$event.stopPropagation();
		$scope.endOpened = true;
	};

	$scope.toDateDire=forDateTimeModuleMethod.getMethod();
//	console.info("Scope toDate: "+$scope.toDateDire);

		 
	var d = new Date();
	var minDate = {};
	var maxDate = {};
	this.startDateTime=function(mod){
//		console.info("inside init call module name:"+mod);
		if (mod=="fromAddSum"||mod=="fromAddAVM"){
			minDate=d;
			var stdttm=d; 
//			console.info("mindate:"+minDate);
			$scope.dateOptions = {
					formatYear: 'yy',
					showWeeks: 0,
					minDate: minDate
				};
			sessionServices.set("start_date",stdttm);
			return stdttm;
		}else if(mod=="fromEditSum" || mod=="fromEditAVM" || mod=="fromLicUpgrade") {
			minDate = forDateTimeModuleMethod.getStDate();
			var stdttm= minDate; 
			$scope.dateOptions = {
					formatYear: 'yy',
					showWeeks: 0,
					minDate: minDate
				};
			sessionServices.set("start_date",stdttm);
			return stdttm;
		}else if (mod=="filter"){
			minDate=d.getDate()-120; //120 must come from license or while login need to get this value from report retention period column
			maxDate=d;
			var stdttm=new Date(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours()-1,d.getMinutes(),d.getSeconds());
			$scope.dateOptions = {
					formatYear: 'yy',
					showWeeks: 0,
					minDate: minDate,
					maxDate: maxDate
				};
			return stdttm;
		}
	};
	$scope.hstep = 1;
	$scope.mstep = 15;

	$scope.ismeridian = false;
	$scope.spinShow=false;
  
	$scope.formats = ['dd-MMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
	$scope.format = $scope.formats[0];
	
	this.endDateTime=function(mod){
		var eddttm;
		if(mod=="fromEditSum" || mod == "fromEditAVM" || mod=="fromLicUpgrade") {
			eddttm = forDateTimeModuleMethod.getEndDate(); //$scope.endDateTime variable changed to make it as return
		}else{
			eddttm = d;
		}
		sessionServices.set("end_date",eddttm);
		return eddttm;
	};
	
	//$scope.endDateTime = d;
	
	$scope.changed = function (mod) {
		if ($scope.endDateTime==null){
			if (mod=='filter'||mod=="fromAddSum"||mod=="fromAddAVM"){d=$scope.endDateTime = new Date();}
			else {d=$scope.endDateTime=forDateTimeModuleMethod.getEndDate();}
		}
		else {
			d= $scope.endDateTime;
		}
		sessionServices.set("end_date",d);
		var d3 = $scope.startDateTime;
		var d1 = (new Date(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours(),d.getMinutes())).getTime();
		var d2 =(new Date(d3.getFullYear(),d3.getMonth(),d3.getDate(),d3.getHours(),d3.getMinutes())).getTime();
		if (d1<=d2)
		{
			$scope.startDateTime=new Date(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours()-1,d.getMinutes(),d.getSeconds());
		}
		sessionServices.set("start_date",$scope.startDateTime);
	};
	
	$scope.changeStartDate = function (mod) {
		if ($scope.startDateTime==null){ 
			if (mod=='filter'|| mod=="fromAddSum"||mod=="fromAddAVM"){d=$scope.startDateTime = new Date();}
			else {d=$scope.startDateTime=forDateTimeModuleMethod.getStDate();}
		}
		else {
			d= $scope.startDateTime;
		}
		sessionServices.set("start_date",$scope.startDateTime);
		var d3 = $scope.endDateTime;
		var d1 = (new Date(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours(),d.getMinutes())).getTime();
		var d2 =(new Date(d3.getFullYear(),d3.getMonth(),d3.getDate(),d3.getHours(),d3.getMinutes())).getTime();
//		console.info('startdate '+d1+' enddate :'+d2);
		if (d1>=d2)
		{
			$scope.endDateTime=new Date(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours()+1,d.getMinutes(),d.getSeconds());
		}
		sessionServices.set("end_date",$scope.startDateTime);
	};
	$scope.ok = function () {
//		console.info("inside ok");
		$scope.customDate.startDate =  $scope.startDateTime;
		$scope.customDate.endDate = $scope.endDateTime;
//		console.info($scope.customDate);
		$scope.$close( $scope.customDate);
	};
	
	$scope.cancel = function () {
		$scope.$dismiss('cancel');
	};
	
	$scope.licDateChange = function(){
		if(sessionServices.get("Lic_category") ==  "Top-Up" || sessionServices.get("Lic_category") ==  "Update"){
			$scope.startDateTime = new Date(sessionServices.get("Lic_startDate"));
			sessionServices.set("start_date",$scope.startDateTime);
		}
		$scope.endDateTime = new Date(sessionServices.get("Lic_endDate"));
		sessionServices.set("end_date",$scope.endDateTime);
	};
	var licenseDateChange = $rootScope.$on("loadLicenseDateChange", $scope.licDateChange);
	$rootScope.$on('$destroy', licenseDateChange);
	
});
/* not used commented by sriram 25-12-2016
appedoApp.controller( 'add-modal-controller', ['$scope', '$uibModal', '$location', 'ajaxCallService', 'sessionServices', 'moduleSelectorService', function( $scope, $uibModal, $location, ajaxCallService, sessionServices, moduleSelectorService) {
	$scope.loginUserData = JSON.parse(sessionServices.get('loginUser'));
	
	var currentURLLocation = $location.path().split("/")[1];
	// appedo modules to have based on user license
	var aryModuleOptions = moduleSelectorService.getModulesOptions($scope.loginUserData);
	// selects particular module option details, based on user is in current module from URL location path
	$scope.userCurrentModuleOption = moduleSelectorService.getModuleOptionBasedOnLocation(aryModuleOptions, currentURLLocation);
	
	$scope.openAddModuleType = function () {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
}]);
*/

appedoApp.controller( 'add-model-instance-controller', ['$scope', '$rootScope', '$location', '$uibModalInstance','$uibModal', 'moduleType', 'ajaxCallService','sessionServices', 'moduleSelectorService', 'slacardService', 'ltService', 'rumService', 'avmModuleServices', 'successMsgService', 'messageService',  
   function( $scope, $rootScope, $location, $uibModalInstance,$uibModal,moduleType,ajaxCallService, sessionServices, moduleSelectorService, slacardService, ltService, rumService, avmModuleServices, successMsgService, messageService, $uibModalInstance) {
	$scope.close = function () {
		$scope.$dismiss('cancel');
	};
	var emailIds = ["sales_test@appedo.com", "sales_test@softsmith.com"];
	
	var locPath = $location.path().split("/")[1];
	var navData = $rootScope.navData;

	$scope.selectType = {};
	
	var bDashboardPage = false;
	if ( locPath === 'dashboard' ) {
		bDashboardPage = true;
	}
	$scope.loginUserData = JSON.parse(sessionServices.get('loginUser'));
	
	// appedo modules to have based on user license
	$scope.options = moduleSelectorService.getModulesOptions($scope.loginUserData);
	console.log($scope.options);
	// to selects the respective module based on user is in current module
/*	for(var i = 0; i < $scope.options.length; i++){
		var joOption = $scope.options[i];
		
		if( bDashboardPage && navData === joOption.name ){
			// if user is dashboard page, respective module to select based on `navData` (i.e. dashboard's current selection tab)
			$scope.selectType.module = joOption;
			break;
		} else if ( ! bDashboardPage && (joOption.path.indexOf(locPath) != -1) ) {
			// split of `path.split('/')[0]` added, since for ASD, say apm_home/application /application is ignored, 
			
			// if user is in respective module page, module to select based on from URL 
			$scope.selectType.module = joOption;
			break;
		}
	}*/
	
	//to select the respective module
	
	for(var i = 0; i < $scope.options.length; i++){
		var joOption = $scope.options[i];
		
		if(moduleType == joOption.name) {
			$scope.selectType.module = joOption;
			break;
		}
	}
	
	// selects the default option
	if ( $scope.selectType.module === undefined ) {
		$scope.selectType.module = $scope.options[0];
	}
	
	// loads selected module content
	$scope.loadSelectedModuleContent = function () {
		// gets module content
		ajaxCallService.getJsonData($scope.selectType.module.moduleContent, function(responseData){
			$scope.moduleCardsContent = responseData;
		});
	};
	// loads the module content, for the selection's
	$scope.loadSelectedModuleContent();
    
	$scope.notifications = [
		{id:1, message: 'Server 4 is down', time: '2015-03-28T17:57:28.556094Z'},
		{id:2, message: 'App 4 is not responding', time: '2015-03-31T09:23:28.556094Z'},
		{id:3, message: 'The response time is bad for demo app', time: '2015-04-01T09:34:28.556094Z'}
	];
	
	$scope.openAddModule = function (moduleCardContent) {
		$scope.moduleCardData = moduleCardContent;
		$scope.moduleCardContent = moduleCardContent;
		var templateUrl = "";
		var controllerName = "";
		if(moduleCardContent.selection == "APM") {
			console.info("inside apm");
			moduleSelectorService.checkModuleLimit($scope, function(data) {
				if( ! data.success ){
					// error
					console.info("inside data failure");
					//successMsgService.showSuccessOrErrorMsg(data);
					messageService.showErrorMessage(data.errorMessage)
				}else{
					$scope.ModuleLimit = data;
					$scope.isLimitExceeded = data.isLimitExceeded;

					if($scope.isLimitExceeded){
						console.info("inside limit exceeded");
						messageService.showWarningMessage('Unable to proceed. Max ASD exceeds the limit.');
					}else{
						console.info("inside apm modal open");
						var modalInstance = $uibModal.open({
							templateUrl: 'common/views/oad/add_module.html',
							controller: 'add_module_controller',
							size: 'lg',
							backdrop : 'static',
							resolve: {
								moduleCardContent: function() {
									return $scope.moduleCardContent;
								}
							}
						});
			    	}
				}
			});
		} else if (moduleCardContent.selection == "RUM") {
			// add/edit RUM module
			rumService.openAddorEditRUMModule('fromAdd', $scope.moduleCardContent, null);
		} else if (moduleCardContent.selection == "SUM") {
			console.info("inside sum modal")
			var modalInstance = $uibModal.open({
				//templateUrl: 'modules/sum/view/add_sum_test.html',
				//controller: 'addSumController',
				templateUrl: 'common/views/sum/add_sum.html',
				controller: 'sumAddController',
				size: 'lg',
				backdrop : 'static',
				resolve: {
					isFrom: function() {
						return 'fromAdd';
					},
					sumTestData: function() {
						return null;
					},							
					 moduleCardContent: function() {
						return $scope.moduleCardContent;
					}
				}
			});
		} else if (moduleCardContent.module_name === "Availability Monitor" ) {
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/avm/add_avm.html',
				controller: 'avmAddController',
				size: 'lg',
				backdrop : 'static',
				resolve: {
					isFrom: function() {
						return 'fromAdd';
					},
					avmTestData: function() {
						return null;
					},
					 moduleCardContent: function() {
						return $scope.moduleCardContent;
					}
				}
			});
		} else if (moduleCardContent.module_name === "Agent Locations" ) {
			// AVM add locations 
			avmModuleServices.openAddorEditMyLocations('fromAdd', null, $scope.moduleCardContent);
		} else if (moduleCardContent.selection == "Alerts") {
			if(moduleCardContent.module_name=="Settings"){
				var modalInstance = $uibModal.open({
					templateUrl: 'common/views/sla/sla_setting.html',
					controller: 'slaSettingController',
					size: 'lg',
					resolve: {
						isFrom: function() {
							return 'fromAdd';
						},
						slaActionFormData: function() {
							return null;
						},					
						moduleCardContent: function() {
							return $scope.moduleCardContent;
						}
					}
				});
			}
			if(moduleCardContent.module_name=="Manage Actions"){
				var modalInstance = $uibModal.open({
					templateUrl: 'common/views/sla/add_sla_action.html',
					controller: 'addSlaActionController',
					size: 'lg',
					resolve: {
						isFrom: function() {
							return 'fromAdd';
						},
						slaActionFormData: function() {
							return null;
						},					
						moduleCardContent: function() {
							return $scope.moduleCardContent;
						}
					}
				});
			}
			if(moduleCardContent.module_name=="Manage Rule"){
				var modalInstance = $uibModal.open({
					templateUrl: 'common/views/sla/add_sla_rule.html',
					controller: 'addSlaRuleController',
					size: 'lg',
					resolve: {
						isFrom: function() {
							return 'fromAdd';
						},
						slaRuleFormData: function() {
							return null;
						},
						moduleCardContent: function() {
							return $scope.moduleCardContent;
						}
					}
				});
			}
			if( moduleCardContent.module_name === "Policy"){
				// add/edit SLA policy, after add to reload 
				slacardService.openAddorEditSLAPolicy('fromAdd', null, $scope.moduleCardContent);
			}
			if(moduleCardContent.module_name=="Manage Setting"){
				var modalInstance = $uibModal.open({
					templateUrl: 'common/views/sla/sla_setting.html',
					controller: 'SlaSettingController',
					size: 'lg',
					resolve: {
						isFrom: function() {
							return 'fromAdd';
						},
						slaSettingFormData: function() {
							return null;
						},
						moduleCardContent: function() {
							return $scope.moduleCardContent;
						}
					}
				});
			}
		} else if (moduleCardContent.selection == "Load Testing") {
			// add/edit scenario/map scripts
			ltService.openAddorEditScenario('fromAdd', $scope.moduleCardContent, null, true);
		} else if (moduleCardContent.module_name === "Enterprise" ) {
			// Create Enterprise  
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/enterprise/add_enterprise.html',
				controller: 'enterprise_Controller',
				size: 'lg',
				/*resolve: {
					isFrom: function() {
						return 'fromAdd';
					},
					slaActionFormData: function() {
						return null;
					},					
					moduleCardContent: function() {
						return $scope.moduleCardContent;
					}
				}*/
			});
		}else if (moduleCardContent.selection == "ServiceMap") {
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/dashboard/add_servicemap.html',
				controller: 'addServiceMapController',
				size: 'lg',
				resolve: {
					isFrom: function() {
						return 'fromAdd';
					},
					serviceMapEditData: function() {
						return null;
					},
					 moduleCardContent: function() {
						return $scope.moduleCardContent;
					}
				}
			});
		} else if (moduleCardContent.selection == "CHARTS") {
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/charts/add_chart_details.html',
				controller: 'addChartController',
				size: 'lg',
				backdrop : 'static',
				resolve: {
					isFrom: function() {
						return 'fromAdd';
					},
					chartViewEditData: function() {
						return null;
					},
					 moduleCardContent: function() {
						return $scope.moduleCardContent;
					}
				}
		});
		}else if(moduleCardContent.selection == "Logs"){

		    if($scope.loginUserData.License=="level0"){
	    		messageService.showWarningMessage('You do not have sufficient license to add log view.<BR/>Please contact <STRONG>'+$scope.appedoWhiteLabels.support_emailid+'</STRONG>', {dismissOnTimeout: false, dismissOnClick: false, additionalClasses: 'apd-alert-msg'});
		    }else{

				moduleSelectorService.getLogViewLicenseDetails($scope, function(data){
					if( ! data.success ){
						//error response
						successMsgService.showSuccessOrErrorMsg(data);
					}else{
						$scope.islicenseValid = data.islicenseValid;

						if($scope.islicenseValid){
							var modalInstance = $uibModal.open({
								templateUrl: 'common/views/log/add_log_details.html',
								controller: 'addLogController',
								size: 'lg',
								backdrop : 'static',
								resolve: {
									isFrom: function() {
										return 'fromAdd';
									},
									chartViewEditData: function() {
										return null;
									}, moduleCardContent: function() {
										return $scope.moduleCardContent;
									}
								}
							});
						}else{
							messageService.showWarningMessage('Please contact <STRONG>'+$scope.appedoWhiteLabels.support_emailid+'</STRONG> to add Logs monitoring', {dismissOnTimeout: false, dismissOnClick: false, additionalClasses: 'apd-alert-msg'});
						}
					}
				});
		    }
		}
			$scope.$dismiss('cancel');
	};
}]) ;

appedoApp.controller('add_module_controller', function($scope, moduleCardContent, $uibModalInstance, moduleSelectorService, $uibModal, $rootScope, successMsgService, messageService, apmModulesService) {	
	console.info("inside add module controller");
	$scope.moduleCardContent = moduleCardContent;
	$scope.versions = [];
	
	// form data, ngModel
	$scope.moduledata = {};
	
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	
	// gets counter types
	$scope.getCounterTypes = function() {
		moduleSelectorService.getCounterTypes($scope, $scope.moduleCardContent, function(data) {
			$scope.moduleTypes = data;
		});	
	};
	$scope.getCounterTypes();
	
	// loads counter type versions
	$scope.getCounterTypeVersions = function() {
        $scope.versions = $scope.moduledata.selectModuleType.versions;
		
		// to set the Counter type version value default if counter type version has only one, else clears the existing selection
		$scope.moduledata.versionType = $scope.versions.length === 1?$scope.versions[0]:undefined;
	};
	
	// loads MSIIS clr versions
	$scope.getCLRVersions = function() {
		moduleSelectorService.getCLRVersions($scope, function(data) {
	    	$scope.clrVersions = data;
	    	
	    	// for default selection
	    	$scope.moduledata.clrVersion = $scope.clrVersions[0];
		});
	};
	// loads CLR versions, as one time to load since `clrVersions` not changable 
	$scope.getCLRVersions();
	
	$scope.disableASDSaveButton = false;
	$scope.saveModule = function () {
		console.log("inside save function");
    	if($scope.moduleAddForm.$valid) {
    		$scope.disableASDSaveButton = true;
    		moduleSelectorService.saveModule($scope, $scope.moduleCardContent, function (data) {
    			if( ! data.success ){
    				console.log("inside save not data success if function");
    				// error
    				//successMsgService.showSuccessOrErrorMsg(data);
    				messageService.showErrorMessage(data.errorMessage);
    				$scope.disableASDSaveButton = false;
    			} else {
    				console.log("inside save else function");
    				var joResp = data;
    				messageService.showSuccessMessage(joResp.message);
    				
    				$rootScope.$emit('load_apm_card_layout');
    				$uibModalInstance.dismiss('cancel');
    				//sessionServices.set("currentModule", $scope.moduleCardContent.module_name)
    				// opens download window, adds the respective content for downloadData
    				joResp.moduleName = $scope.moduledata.moduleName;
    				joResp.clrVersion = (joResp.type == "MSIIS" ? $scope.moduledata.clrVersion.clrVersionType : '');
    				apmModulesService.openDownloadWindow(joResp, $scope.moduleCardContent);
    			}
    		});
    	}
    	//$uibModalInstance.dismiss('cancel');
    };
});

appedoApp.controller('download_form_controller', function($scope, moduleDownloadData, $uibModalInstance, moduleSelectorService, $state, $location, moduleCardContent, apmModulesService, $appedoUtils, messageService) {	
	$scope.currentModule = moduleCardContent.module_name;
	//console.log($scope.currentModule);
	$scope.moduleCardContent = moduleCardContent;
	$scope.moduleDownloadData = moduleDownloadData;
	$scope.moduleDownloadData.agreeProfilerDownload = false;
	$scope.moduleDownloadData.isProfilerClicked = false;
	
	$scope.appedoURL = $appedoUtils.getLocationTillPathName();
	
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	
	//var currentUrl = $location.url();
	$scope.redirectCardLayout = function (data) {
		if($scope.currentModule=="Application") {
			$state.transitionTo('/apm_home/application');
			$scope.currentModuleName = 'application';
		} else if($scope.currentModule=="Server") {
			$scope.currentModuleName = 'server';
			$state.transitionTo('/apm_home/servers');
		} else if($scope.currentModule=="Database") {
			$scope.currentModuleName = 'database';
			$state.transitionTo('/apm_home/db');
		}
	};
	
	// to download profiler, Jboss to show msg
	$scope.downloadProfiler = function(joModule) {
		$scope.moduleDownloadData.isProfilerClicked = true;
		
		if ( ! $scope.moduleDownloadData.agreeProfilerDownload ) {
			messageService.showWarningMessage('Please agree for the above condition(s).');
			return false;
		} else {
			apmModulesService.downloadProfiler(joModule);
		}
	};
});


appedoApp.controller('addRumController', function($rootScope, $scope, $uibModalInstance, $uibModal, isFrom, rumService, moduleDescriptionContent, rumModuleData, successMsgService, messageService) {	
	$scope.moduleDescriptionContent = moduleDescriptionContent;
	
	$scope.moduledata = {};
	$scope.moduleTypes = [];
	$scope.disableRUMSaveButton = false;
	
	$scope.hasFromAdd = (isFrom === 'fromAdd'); 
	
	var DEFAULT_THRESHOLD = {warning: 5, critical: 10, breachCount: 1, responseAlert: false};
	
	
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	
	if ( $scope.hasFromAdd ) {
		// add
		$scope.moduledata.responseAlert = DEFAULT_THRESHOLD.responseAlert;
		$scope.moduledata.warning = DEFAULT_THRESHOLD.warning;
		$scope.moduledata.critical = DEFAULT_THRESHOLD.critical;
		$scope.moduledata.breachCount = DEFAULT_THRESHOLD.breachCount;
		
		// gets counter type version
		getCounterTypeVersion();
	} else {
		// edit 
		
		// gets RUM module details
		getRUMModuleDetails();
	}
	
	// gets counter type version
	function getCounterTypeVersion() {
		rumService.getModuleTypes(function(data) {
			$scope.moduleTypes = data;
			
			// sets counter type version
			$scope.moduledata.counterTypeVersionId = $scope.moduleTypes[0].versions[0].ctv_id;
		});
	}
	
	// get RUM uid's details & sets module details for the form
	function getRUMModuleDetails() {
		var joModule = {};
		
		rumService.getRUMModuleDetails(rumModuleData, function( data ) {
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				joModule = data.message;
				
				// sets module details 
				$scope.moduledata.uid = joModule.uid;
				$scope.moduledata.guid = joModule.guid;
				$scope.moduledata.moduleName = joModule.moduleName;
				$scope.moduledata.moduleDescription = joModule.description;
				$scope.moduledata.responseAlert = joModule.isActive || DEFAULT_THRESHOLD.responseAlert;
				//if ( $scope.moduledata.responseAlert ) {
					$scope.moduledata.warning = joModule.warningThresholdValue || DEFAULT_THRESHOLD.warning;;
					$scope.moduledata.critical = joModule.criticalThresholdValue || DEFAULT_THRESHOLD.critical;
					$scope.moduledata.breachCount = joModule.minBreachCount || DEFAULT_THRESHOLD.breachCount;
				//}
			}
		});
	}
	
	
	$scope.saveRUM = function () {
		if($scope.rumAddForm.$valid) {
			$scope.disableRUMSaveButton = true;
			rumService.saveRUM($scope.hasFromAdd, $scope.moduledata, function (data) {
				if( data.success ){
					messageService.showSuccessMessage(data.message);
					
					$rootScope.$emit('load_rum_card_layout');
					var modalInstance = $uibModal.open({
						//templateUrl: 'modules/rum/view/download_rum_module.html',
						templateUrl: 'common/views/rum/download_rum_module.html',
						controller: 'downloadRumController',
						size: 'lg',
						resolve: {
							moduleAddData: function() {
								return $scope.moduledata;
							},
							moduleDownloadData: function() {
								return data;
							},
							moduleDescriptionContent: function() {
								return $scope.moduleDescriptionContent;
							}
						}
					});
					$uibModalInstance.dismiss('cancel');
				} else {
					successMsgService.showSuccessOrErrorMsg(data);
					$scope.disableRUMSaveButton = false;
				}
			}); 
		}
	};
});
appedoApp.controller('downloadRumController', function($scope, moduleAddData, moduleDownloadData, $uibModalInstance,  moduleDescriptionContent) {	
	$scope.moduleAddData = moduleAddData;
	
	$scope.currentModule = moduleDescriptionContent.module_name;
	$scope.moduleDownloadData = moduleDownloadData;
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
});

appedoApp.controller('rumDashPanel', ['$scope', '$attrs', 'apmCardService', 'rumModuleFactory', 'rumService', 'sessionServices', '$appedoUtils', '$timeout', 'messageService', function($scope, $attrs, apmCardService, rumModuleFactory, rumService, sessionServices, $appedoUtils, $timeout, messageService) {
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('RUM Dashboard Page', 'pageOpen', 
		{
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	var d3ChartTimeFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"));
	
	$scope.rumDurations = JSON.parse(sessionServices.get("sliderServerSideScale"));
	//$scope.selectedRUMDuration = $scope.rumDurations[0];
	//by default 24hrs showing
	$scope.selectedRUMDuration = $scope.rumDurations[1];
	$scope.d3XaixsFormat = d3ChartTimeFormat[$scope.rumDurations.indexOf($scope.selectedRUMDuration)];
	$scope.durationForDonut = $scope.rumDurations[0];
	
	$scope.userRUMWebsiteModules = [];
	
	$scope.rumChartData = {};
	$scope.browserLoading = false;
	$scope.locationLoading = false;
	$scope.deviceTypeLoading = false;
	$scope.osLoading = false;
	
	$scope.siteAnalysisTypes = rumModuleFactory.siteAnalysisTypes;
	
	// gets user's RUM websites
	$scope.getRUMModules = function() {
		apmCardService.populateApmCardData($scope,'RUM',function(resp){
			$scope.browserDonutData=[];
			$scope.deviceTypeDonutData=[];
			$scope.osDonutData=[];
			$scope.totalVisitor = 0;
			
			$scope.userRUMWebsiteModules = resp.moduleData;
			
			loadRUMChartData();
		});
	};
	// defaults to load user's SUM Tests 
	if ( $scope.navData !== undefined && $scope.navData === 'Service Map' ) {
		// to load user's SUM Tests is avoided for ServiceMap, since same controller and template used for dashboard's SUM & ServiceMap's SUM, (Note: $scope.navData is available from root/parent controller)
	} else {
		$scope.getRUMModules();
	}

	// Used for serviceMap's SUM panel, user mapped sumTests are set and loadsChartData
	$scope.$on("loadSelectedServiceMap", function(event, joMappedService) {
		$scope.userRUMWebsiteModules = joMappedService.RUM || [];
		
		loadRUMChartData();
	});
	
	function loadRUMChartData() {
		$scope.selectedRUMWebSite = $scope.userRUMWebsiteModules[0];
		$scope.uidForDonut = $scope.selectedRUMWebSite.uid;
		
		//$scope.totalVisitor = 0;
		
		$scope.getRUMChartData();
	}
	
	$scope.getRUMChartData = function(){
		 $scope.getRUMAreaChart();
		 
		// RUM site analysis used bar chart, donut is commented 
		//$scope.getRUMSummary();
		$scope.getVisitorsCount();
		$scope.loadRUMSiteAnalysis();
		//$scope.brodcastRUMSiteAnalysis();
	};
	
	// visitors count
	$scope.getRUMAreaChart= function(){
		$scope.d3XaixsFormat = d3ChartTimeFormat[$scope.rumDurations.indexOf($scope.selectedRUMDuration)];
		var resultRUMAreaChart = rumService.getRUMDashArea($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration);
		resultRUMAreaChart.then(function(resp) {
			var respMsg = resp.message;
			$scope.rumChartData.visitorsCountChartData = respMsg.dailyVisitorsCount;
			
//			var nTotalVis = 0;
//			$scope.rumChartData.visitorsCountChartData.forEach(function(d) {
//				nTotalVis = nTotalVis + d.V;
//			});
//			$scope.totalVisitor = nTotalVis;
		});
	};
	
	$scope.getVisitorsCount = function() {
		var resultVisitorsCount = rumService.getVisitorsCount($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration);
		resultVisitorsCount.then(function(resp) {
			nTotalVis = 0;
			if(resp.success){
				$scope.totalVisitor = resp.message.visitorsCount;
			}
		});
	};
	
	// gets RUM site analysis donut chart data
	$scope.getRUMSummary = function(){
		var resultDonutChartData;
		resultDonutChartData = rumService.getDonutChartdata('Browser', $scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration);
		resultDonutChartData.then(function(resp) {
			$scope.browserDonutData=resp;
		});
		
		resultDonutChartData="";
		resultDonutChartData = rumService.getDonutChartdata('DeviceType', $scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration);
		resultDonutChartData.then(function(resp) {
			$scope.deviceTypeDonutData=resp;
		});
		
		resultDonutChartData="";
		resultDonutChartData = rumService.getDonutChartdata('OS', $scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration);
		resultDonutChartData.then(function(resp) {
			$scope.osDonutData=resp;
		});
	};
	

	// loads RUM site analysis
	$scope.loadRUMSiteAnalysis = function() {
		$scope.getRUMBrowserWiseData();
		$scope.getRUMDeviceTypeWiseData();
		$scope.getRUMOSWiseData();
//		$scope.getRUMDeviceNameWiseData();
		$scope.getRUMLocationWiseData();
	};

	$scope.brodcastRUMSiteAnalysis = function(){
		$timeout(function() {
			$scope.$broadcast('loadRUMSiteAnalysis', $scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration);
		}, 100);
	};
	
	// gets browser wise data
	$scope.getRUMBrowserWiseData = function() {
		$scope.browserLoading = true;
		$scope.rumChartData = {};
		rumService.getRUMBrowserWiseData($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.browserLoading = false;
				$scope.rumChartData.browserWiseVisitorsCount = data.message;
				var barVal = 0;
				for(var i = 0; i<$scope.rumChartData.browserWiseVisitorsCount.length; i= i+1){
					barVal = barVal + $scope.rumChartData.browserWiseVisitorsCount[i].visitCount;
				}
				for(var i = 0; i<$scope.rumChartData.browserWiseVisitorsCount.length; i= i+1) {
					$scope.rumChartData.browserWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.browserWiseVisitorsCount[i].visitCount*100)/barVal;
				}
			}
		});
	};
	
	// gets device type wise data
	$scope.getRUMDeviceTypeWiseData = function() {
		$scope.deviceTypeLoading = true;
		$scope.rumChartData = {};
		rumService.getRUMDeviceTypeWiseData($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.deviceTypeLoading = false;
				$scope.rumChartData.deviceTypeWiseVisitorsCount = data.message;
				var barVal = 0;
				for(var i = 0; i<$scope.rumChartData.deviceTypeWiseVisitorsCount.length; i= i+1){
					barVal = barVal + $scope.rumChartData.deviceTypeWiseVisitorsCount[i].visitCount;
				}
				for(var i = 0; i<$scope.rumChartData.deviceTypeWiseVisitorsCount.length; i= i+1) {
					$scope.rumChartData.deviceTypeWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.deviceTypeWiseVisitorsCount[i].visitCount*100)/barVal;
				}

			}
		});
	};
	
	// gets os wise data
	$scope.getRUMOSWiseData = function() {
		$scope.osLoading = true;
		$scope.rumChartData = {};
		rumService.getRUMOSWiseData($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.osLoading = false;
				$scope.rumChartData.osWiseVisitorsCount = data.message;
				var barVal = 0;
				for(var i = 0; i<$scope.rumChartData.osWiseVisitorsCount.length; i= i+1){
					barVal = barVal + $scope.rumChartData.osWiseVisitorsCount[i].visitCount;
				}
				for(var i = 0; i<$scope.rumChartData.osWiseVisitorsCount.length; i= i+1) {
					$scope.rumChartData.osWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.osWiseVisitorsCount[i].visitCount*100)/barVal;
				}

			}
		});
	};
	
	// gets device name wise data
	/*$scope.getRUMDeviceNameWiseData = function() {
		rumService.getRUMDeviceNameWiseData($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumChartData.deviceNameWiseVisitorsCount = data.message;
			}
		});
	};*/
	
	$scope.getRUMLocationWiseData = function() {
		$scope.locationLoading = true;
		$scope.rumChartData = {};
		rumService.getRUMLocationWiseData($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.locationLoading = false;
				$scope.rumChartData.locationWiseVisitorsCount = data.message;
				if($scope.rumChartData.locationWiseVisitorsCount.length>0){
					var avgVal = 0;
					for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1){
						avgVal = avgVal + $scope.rumChartData.locationWiseVisitorsCount[i].count;
					}
					for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1) {
						$scope.rumChartData.locationWiseVisitorsCount[i].barsize = ($scope.rumChartData.locationWiseVisitorsCount[i].count*100)/avgVal;
					}
				}
			}
		});
	};
	
	
	// open RUM's top/most time taken responses, based on Browser or City or DeviceType or OS
	$scope.openTopRUMResponses = function(joSiteAnalysisType, joTypeDatum) {
		rumService.openTopRUMResponses($scope.selectedRUMWebSite, joSiteAnalysisType, joTypeDatum, $scope.selectedRUMDuration, null, null);
	};
	
	// onclick of bar chart, to open top responses
	$scope.showPageViewsTopResponses = function(joDatum) {
		$scope.openTopRUMResponses($scope.siteAnalysisTypes[4], joDatum);
	};
}]);


appedoApp.controller('rumCardController', ['$scope', 'rumCardService', '$location', '$state', 'moduleSelectorService', 'ajaxCallService', 'rumModuleFactory', 'rumService', 'sessionServices', '$uibModal', '$rootScope', 'successMsgService', 'messageService', function ($scope, rumCardService, $location, $state, moduleSelectorService, ajaxCallService, rumModuleFactory, rumService, sessionServices, $uibModal, $rootScope, successMsgService, messageService) {
	var moduleType = 'RUM';
	var url = $location.url();
	
	$scope.moduleDescription = {};
	$scope.showLoading = false;
	
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('RUM Card Layout', 'pageOpen', 
		{
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	// default value
	if($rootScope.backPageFrom == "RUMDetails") {
		if(sessionServices.get('selectedRUMRadioValue') == null){
			$scope.selectedRUMRadioValue = 'RUM';
		}else{
			$scope.selectedRUMRadioValue = sessionServices.get('selectedRUMRadioValue');
		}
		sessionServices.destroy('selectedRUMRadioValue');
	} else {
		$scope.selectedRUMRadioValue = 'DASHBOARD';
	}
	
	
	// loads the RUM module description  content, 
	function loadModuleDescriptionContent() {
		// gets module content
		ajaxCallService.getJsonData('common/data/module_content_rum.json', function(responseData){
			$scope.moduleDescription = responseData[0];
		});
	};
	loadModuleDescriptionContent();
	
	
	$scope.openAddModuleType = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
	
	$scope.loadSelectedTypeDetails = function() {
		var checkKey = ["DASHBOARD", "WORLDMAP"]; 
		if(checkKey.indexOf($scope.selectedRUMRadioValue)<0){
			$scope.getTransactionDataAndAgentStatus();
		}
	};
	$scope.getRumCardData = function() {
		$scope.appcardscontent = [];
		showLoading();
		
		rumCardService.populateRumCardData($scope, moduleType, function(rumCardData) {
			$scope.appcardscontent = rumCardData;
			hideLoading();
			$scope.showCard = false;
			$scope.showCardEmptyMsg = false;
			if($scope.appcardscontent.length >0){
				$scope.showCard = true;
			}else {
				$scope.showCardEmptyMsg = true;
			}
			$scope.getTransactionDataAndAgentStatus();
		});
	};
	$scope.getRumCardData();
	//for refresh the card layout after Add
	var rumCard = $rootScope.$on("load_rum_card_layout", $scope.getRumCardData);
	$scope.$on('$destroy', rumCard);
	
	/*var reloadRumCardLayout = $rootScope.$on("load_rum_card_layout", function(event){
		rumCardService.populateRumCardData($scope, moduleType, function(rumCardData) {
			$scope.appcardscontent = rumCardData;
			$scope.getTransactionDataAndAgentStatus();
		});
	});*/
	
	var timerAgentStatus;
	$scope.getTransactionDataAndAgentStatus = function() {
		clearTimeout(timerAgentStatus);
		
		if($scope.appcardscontent.length>0){
			var resultTransactionData = rumCardService.getTransactionDataService();
			resultTransactionData.then(function(rumTransactionData) {
				$scope.rumTransactions = rumTransactionData;
				for(var i=0; i<$scope.appcardscontent.length; i++){
					for(var j=0; j<$scope.rumTransactions.length; j++){
						if($scope.appcardscontent[i].uid == $scope.rumTransactions[j].uid){
							$scope.appcardscontent[i].visitor_count = $scope.rumTransactions[j].visitor_count;
							$scope.appcardscontent[i].max_page_load = $scope.rumTransactions[j].max_page_load;
						}
					}
				}
				var resultAgentStatus = rumCardService.getAgentStatus();
				resultAgentStatus.then(function(rumAgentStatus) {
					$scope.agentStatus = rumAgentStatus;
					for(var i=0; i<$scope.appcardscontent.length; i++){
						for(var j=0; j<$scope.agentStatus.length; j++){
							if($scope.appcardscontent[i].uid == $scope.agentStatus[j].uid){
//								$scope.appcardscontent[i].csharp_status = $scope.agentStatus[j].csharp_status;
//								$scope.appcardscontent[i].java_status = $scope.agentStatus[j].java_status;
//								$scope.appcardscontent[i].js_status = $scope.agentStatus[j].js_status;
//								$scope.appcardscontent[i].php_status = $scope.agentStatus[j].php_status;
//								$scope.appcardscontent[i].python_status = $scope.agentStatus[j].python_status;
								$scope.appcardscontent[i].rum_status = $scope.agentStatus[j].rum_status;
							};
						}
					};
				});
			});
		}
		
		timerAgentStatus = setTimeout($scope.getTransactionDataAndAgentStatus, sessionServices.get("textRefresh"));
	};
	
	$scope.apmCardEdit = false;
	$scope.moduleOriginalData = {};
	$scope.moduleCardEdit = function (index) {
		$scope.moduleOriginalData = JSON.parse(JSON.stringify(this.appcardcontent));
		$scope.module = this.appcardcontent;
		
		for(var i=0; i<$scope.appcardscontent.length; i++) {
			var moduleContent = $scope.appcardscontent[i];
			moduleContent.isEditEnabled = false;
		}
		$scope.module.isEditEnabled = true;
	};
	
	$scope.openRUMModuleEditWindow = function() {
		var joModuleCardData = this.appcardcontent;
		
		// add/edit RUM module
		rumService.openAddorEditRUMModule('fromEdit', $scope.moduleDescription, joModuleCardData);
	};
	
	
	$scope.doNotUpdate = function() {
		$scope.module.isEditEnabled = false;
		this.appcardcontent = $scope.moduleOriginalData;
	};
	
	$scope.updateApmModule = function() {
		//$scope.module.isEditEnabled = false;
		var isValid = true;
		var msg = '';
		if(this.appcardcontent.moduleName == '' || this.appcardcontent.moduleName == undefined) {
			var isValid = false;
			msg = "Please enter name";
		} else if(this.appcardcontent.description == '' || this.appcardcontent.description == undefined) {
			var isValid = false;
			msg = "Please enter description";
		}
		if(isValid) {
			rumCardService.updateApmModule($scope, this.appcardcontent, moduleType, function (data) {
				if( data.success ) {
					$scope.module.isEditEnabled = false;
					$scope.getRumCardData();
				} else {
					$scope.module.isEditEnabled = true;
				}
				successMsgService.showSuccessOrErrorMsg(data);
			});
		} else {
			messageService.showWarningMessage(msg);
		}
	};
	
	$scope.deleteSelectedRow = function(index) {
		var result = confirm("You will lose agent records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			var moduleName = this.appcardcontent.moduleName;
			rumCardService.deleteModuleRow($scope, this.appcardcontent, moduleType, function (response) {
				if ( ! response.success ) {
					messageService.showWarningMessage(response.errorMessage);
				} else {
					messageService.showSuccessMessage('RUM `'+moduleName+'` has been deleted.');
					
					// $scope.appcardscontent.splice(index,1);
					$scope.getRumCardData();
				}
			});
		}
	};
	
	// gets CI default agent types
	$scope.getDefaultAgentTypes = function() {
		
		rumCardService.getDefaultAgentTypes(function(data) {
			$scope.defaultAgentTypes = data;
		});
	};
	$scope.getDefaultAgentTypes();
	
	
	
	$scope.getUserEventsVisitorsCount = function() {
		rumCardService.getUserEventsVisitorsCount($scope.selectedAgentType != undefined ? $scope.selectedAgentType.value : null, $scope.selectedEnvironment != undefined ? $scope.selectedEnvironment.env : null, function(data) {

			if( data.success ){
				$scope.eventsVisitorsCount = data.message;
				
				for (var keyUid in $scope.eventsVisitorsCount) {
					for(var i = 0; i < $scope.appcardscontent.length; i = i + 1) {
						var joCardContent = $scope.appcardscontent[i];
						
						if( joCardContent.uid == keyUid ) {
							joCardContent.eventsVisitorsCount = $scope.eventsVisitorsCount[keyUid];
							break;
						}
					}
				}
			} else {
				// err
			}
		});
	};
	
	$scope.getUserEventsDistinctEnvironments = function() {
		rumCardService.getUserEventsDistinctEnvironments(function(data) {
			//
			if( data.success ){
				$scope.eventsDistinctEnvironments = data.message;
			} else {
				// err
			}
		});
	};
	$scope.getUserEventsDistinctEnvironments();
	
	// to go RUM/CI details page
	$scope.goModuleDetailGrpahs = function() {
		$scope.selectedRumCardContent = this.appcardcontent;
		
		// go to `rum_details` page 
		rumModuleFactory.viewRUMDetailsPage($scope.selectedRumCardContent, $scope.selectedRUMRadioValue);
	};
	
	function showLoading() {
		$scope.showLoading = true;
	}
	function hideLoading() {
		$scope.showLoading = false;
	}
	
	$scope.$on('$destroy', function() {
		clearTimeout(timerAgentStatus);
	});
}]);

appedoApp.controller('rumDetailsController', ['$scope', '$rootScope', '$stateParams', 'rumModuleFactory', 'rumService', '$appedoUtils', 'sessionServices', '$state', '$timeout', 'appedoDirectiveChartUtils', 'messageService', function($scope, $rootScope, $stateParams, rumModuleFactory, rumService, $appedoUtils, sessionServices, $state, $timeout, appedoDirectiveChartUtils, messageService) {
	
	//$scope.selectedRumCardContent = JSON.parse(sessionServices.get("selectedRumCardContent"));
	
	$scope.backToRumCardPage = function() {
		$rootScope.backPageFrom = "RUMDetails";
		$state.transitionTo('/rum_details');
		sessionServices.destroy('selectedRUMRadioValue');
		sessionServices.set('selectedRUMRadioValue', $stateParams.type);
	};
	
	sessionServices.destroy('selectedRUMRadioValue');
	// params when transistion from `rum_home` page
	$scope.moduleNameParam = $rootScope.rumDetails.moduleName;
	
	$scope.uidParam = $rootScope.rumDetails.uid;
	
	//$scope.selectedRUMRadioValue = "RUM";
	$scope.selectedRUMRadioValue = "EVENTS";
	//$scope.sliderValue = "1";
	//$scope.sliderOptions = sliderFactory.sliderOptions;
	
	// for details page
	/*$scope.rumDetails = {};
	$scope.rumDetails.startDate = '';
	$scope.rumDetails.endDate = '';
	$scope.rumDetails.startDateTime = '';
	$scope.rumDetails.endDateTime = '';
	$scope.rumDetails.startHour = 0;
	$scope.rumDetails.endHour = 23;
	$scope.rumDetails.startMins = 0;
	$scope.rumDetails.endMins = 59;
	$scope.rumDetails.customDateStatus = false;
	$scope.rumDetails.enDateLimit = new Date();
	$scope.rumDetails.stDateLimit = new Date("January 01, 2000 00:00:00");*/
	
	var aryD3ChartTimeFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"));
	var arySliderServerSideScale = JSON.parse(sessionServices.get("sliderServerSideScale"));
	//$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[0];
	$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[0];
	$scope.rumDetails.sliderSelectedValue = arySliderServerSideScale[0];
	
	var sliderSelectedValue = null, nStartDateTimeInMills = null, nEndDateTimeInMills = null;
	var healthCode = null;
	sliderSelectedValue = $scope.rumDetails.sliderSelectedValue;
	
	$scope.RUM_HEALTH_DETAILS = rumModuleFactory.RUM_HEALTH_DETAILS;
	
	
	// to filter health board selection's in `rum_details` page
	if ( $rootScope.transitionFromHealthBoard ) {
		// transition from health dashboard, to apply respective filters 
		
		healthCode = $rootScope.healthBoardFilters.healthCode.length > 0 ? $rootScope.healthBoardFilters.healthCode : null;
		
		if ( $rootScope.healthBoardFilters.interval !== null ) {
			/* set of `$scope.sliderValue = <>` to reflect UI in slider selection,
			 *   is ignored since healthboard slider is different from `rum_details` page slider 
			 */
			
			$scope.rumDetails.sliderSelectedValue = $rootScope.healthBoardFilters.interval;
			sliderSelectedValue = $scope.rumDetails.sliderSelectedValue;	
			console.log("selected Slider Value :"+sliderSelectedValue);
		} else {
			sliderSelectedValue = null;
			nStartDateTimeInMills = parseInt($rootScope.healthBoardFilters.startDateTime);
			nEndDateTimeInMills = parseInt($rootScope.healthBoardFilters.endDateTime);
			
			$scope.rumDetails.customDateStatus = true;
			
			// sets datetime filter in fields, to reflect in ui 
			setDateTimeFilter();
		}
	}
	
	
	// for RUM
	$scope.rumChartData = {};
	
	$scope.rumModules = [];
	//$scope.pagesLoadTime = [];
	//$scope.pageLoadTimeChartData = [];
	
	
	// for CI, Events 
	$scope.ciChartData = {};
	$scope.moduleAgentTypes = [];
	$scope.moduleEnvironments = [];
	$scope.isSliderDateChange;
	
	$scope.siteAnalysisTypes = rumModuleFactory.siteAnalysisTypes;
	
/*	
	$scope.handleRadioClick = function(selectedValue){
		if(selectedValue!=$scope.selectedRUMRadioValue){
			$scope.selectedRUMRadioValue = selectedValue;
			if(selectedValue=="EVENTS"){
				getCIData();
			}else if(selectedValue=="RUM"){
				$scope.getModules();
			}
		}
	};*/
	
	// sets datetime filters in fields, from startDateTimeInMills & endDateTimeInMills 
	/*function setDateTimeFilter() {
		var dtStartDateTime = new Date(nStartDateTimeInMills), dtEndDateTime = new Date(nEndDateTimeInMills);
		
		//this.startDate = new Date(dtStartDateTime.getFullYear(), dtStartDateTime.getMonth(), dtStartDateTime.getDate());
		$scope.rumDetails.startDate = $appedoUtils.format_Date_To_ddMMMyyyy(dtStartDateTime);//dtStartDateTime.getFullYear()+'-'+(dtStartDateTime.getMonth() + 1)+'-'+dtStartDateTime.getDate();
		$scope.rumDetails.startHour = dtStartDateTime.getHours();
		$scope.rumDetails.startMins = dtStartDateTime.getMinutes();
		
		//this.endDate = new Date(dtEndDateTime.getFullYear(), dtEndDateTime.getMonth(), dtEndDateTime.getDate());
		$scope.rumDetails.endDate = $appedoUtils.format_Date_To_ddMMMyyyy(dtEndDateTime);
		$scope.rumDetails.endHour = dtEndDateTime.getHours();
		$scope.rumDetails.endMins = dtEndDateTime.getMinutes();
	}*/
	
	/*
	// slider change
	$scope.$watch('sliderValue',function(newVal){
		if(newVal){
			if(newVal=="1"){
				$scope.rumDetails.sliderSelectedValue = arySliderServerSideScale[0];
				$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[0];
			}else{
				$scope.rumDetails.sliderSelectedValue = arySliderServerSideScale[(newVal/$scope.sliderOptions.step)];
				$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[(newVal/$scope.sliderOptions.step)];
			}
			
			$scope.loadSelectedTypeDetails();
		}
	});*/
	
	$scope.loadSliderSelectionData = function() {
		$scope.rumDetails.startDate = '';
		$scope.rumDetails.endDate = '';
		$scope.rumDetails.startDateTime = '';
		$scope.rumDetails.endDateTime = '';
		$scope.rumDetails.startHour = 0;
		$scope.rumDetails.endHour = 23;
		$scope.rumDetails.startMins = 0;
		$scope.rumDetails.endMins = 59;
		$scope.rumDetails.customDateStatus = false;
		if( $scope.sliderValue == 1 ){
			$scope.rumDetails.sliderSelectedValue = arySliderServerSideScale[0];
			//$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[0];
			$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[0];
		}else{
			$scope.rumDetails.sliderSelectedValue = arySliderServerSideScale[($scope.sliderValue/$scope.sliderOptions.step)];
			//$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[($scope.sliderValue/$scope.sliderOptions.step)];
			$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[($scope.sliderValue/$scope.sliderOptions.step)];
		}
		sliderSelectedValue = $scope.rumDetails.sliderSelectedValue;
		nStartDateTimeInMills = null;
		nEndDateTimeInMills = null;
		
		// clears, healthboard slider filter
		if ( $rootScope.transitionFromHealthBoard ) {
			$rootScope.healthBoardFilters.interval = null;
		}
		
		loadSelectionDetails();
	};
	
	//TODO: add method for emit function
	
	$rootScope.$on("call_RUM_Events", function(event, responseData){
		$scope.rumDetails.startDate = responseData.startDateTime;
		 $scope.rumDetails.endDate = responseData.endDateTime;
		 $scope.rumDetails.sliderSelectedValue = responseData.strInterval;
		 console.log("str_Date:"+$scope.rumDetails.startDate);
		 console.log("end_Date:"+$scope.rumDetails.endDate);
		 console.log("Interval:"+$scope.rumDetails.sliderSelectedValue );
		 
		 sliderSelectedValue = $scope.rumDetails.sliderSelectedValue;
		 nStartDateTimeInMills = $scope.rumDetails.startDate;
		 nEndDateTimeInMills = $scope.rumDetails.endDate;
		 $scope.isSliderDateChange = responseData.isSliderDateChange;
		 $scope.selectedModule = {};
		 $scope.selectedModule.uid = responseData.uid;
		 if ($scope.isSliderDateChange) {
			 $scope.getSelectedAgentTypeEvents();
		 } else {
			 $scope.loadSelectedTypeDetails(); 
		 }
		 
		});
	
	
	
	// for RUM Modules dropdown
	/*$scope.getModules = function(){
		rumCardService.populateRumCardData($scope, 'RUM', function(data) {
			$scope.rumModules = data;
			
			selectModuleFromUID();
			//$scope.loadRUMDetails();
		});
	};
	$scope.getModules();*/
	
	
	// to selecte comobo
	function selectModuleFromUID() {
		for(var i = 0; i < $scope.rumModules.length; i = i + 1) {
			var joModule = $scope.rumModules[i];
			
			if ( joModule.uid == $scope.uidParam ) {
				$scope.selectedModule = $scope.rumModules[i];
			}
		}
	}
	
	// tried, handle to load initially when page refresh, sessionUId param is passed for other `uidParam` is not given
	$scope.loadSelectedTypeDetails = function(uidParam) {
		$scope.selectedModuleUId = uidParam || $scope.selectedModule.uid ;
		
		$scope.clearRUMChartValues();
		$scope.clearCIValues();
		
	//	if($scope.selectedRUMRadioValue == 'EVENTS') {
			//getCIData();
			$scope.loadCIDetails();
		/*}else if($scope.selectedRUMRadioValue == 'RUM'){
			//getRUMData();
			//$scope.loadRUMDetails();
			
			loadRUMSelectionDetails();
		}*/
	};
	// load initially when page refresh uidParam passed 
	//$scope.loadSelectedTypeDetails($scope.uidParam);
	
	function loadSelectionDetails() {
		clearRUMDetailsOtherThanSelections();
		clearCIDetailsOtherThanSelections();
		
		if( $scope.selectedRUMRadioValue == 'EVENTS' ) {
			loadCISelectionDetails();
		} else if($scope.selectedRUMRadioValue == 'RUM'){
			loadRUMSelectionDetails();
		}
	}
	
	
	// for RUM details to load
	$scope.loadRUMDetails = function() {
		if( sliderSelectedValue === null ){
			$scope.getrumDetailsChartWithDateRange();
		}else{
			$scope.getPagesLoadTime();
			$scope.getRUMBarChart();
			$scope.getRUMLastReceivedOn();
			// RUM site analysis used bar chart, donut is commented 
			//$scope.getRUMSummary();
			$scope.loadRUMSiteAnalysis();
			//$scope.brodcastRUMSiteAnalysis();
		}
	};
	
	function loadRUMSelectionDetails() {
		// page analysis
		
		/*if( sliderSelectedValue === null ){
			$scope.getPagesLoadTimeWithDateRange();
		} else {
			$scope.getPagesLoadTime();
		}*/
		$scope.getPagesLoadTime();
		
		$scope.getRUMBarChart();
		
		
		$scope.getRUMLastReceivedOn();
		
		// site analysis 
		$scope.loadRUMSiteAnalysis();
		
		// load selected URL's, page load time chart data
		if ( $scope.selectedPage !== undefined ) {
			$scope.loadSelectedPageLoadTime($scope.selectedPage);
		}
	}
	
	// tried separate controller 
	$scope.brodcastRUMSiteAnalysis = function(){
		//$rootScope.$broadcast('loadRUMSiteAnalysis');
		$timeout(function() {
			$scope.$broadcast('loadRUMSiteAnalysis', $scope.selectedModuleUId, $scope.rumDetails.sliderSelectedValue);
		}, 100);
	};
	
	// loads RUM site analysis
	$scope.loadRUMSiteAnalysis = function() {
		$scope.getRUMBrowserWiseData();
		$scope.getRUMDeviceTypeWiseData();
		$scope.getRUMOSWiseData();
//		$scope.getRUMDeviceNameWiseData();
		$scope.getRUMLocationWiseData();
	};
	
	
	// RUM, to get pagesLoadtime, page analysis
	$scope.getPagesLoadTime = function() {
		$scope.rumChartData.pagesLoadTime = [];
		
		rumService.getPagesLoadTime($scope.selectedModuleUId, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode, function(data) {
			//$scope.pagesLoadTime = data;
			
			if ( ! data.success ) {
				// err msg
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumChartData.pagesLoadTime = data.message;  
			}
		});
	};
	
	$scope.getPagesLoadTimeWithDateRange = function() {
		$scope.rumChartData.pagesLoadTime = [];
		
		rumService.getPagesLoadTimeWithDateRange($scope.selectedModuleUId, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {
			//$scope.pagesLoadTime = data;
			
			if ( ! data.success ) {
				// err msg
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumChartData.pagesLoadTime = data.message;  
			}
		});
	};

	// calls  from directive, page load time area graph 
	$scope.loadSelectedPageLoadTime = function(joPage) {
		//$scope.selectedPage = url;
		$scope.selectedPage = joPage;
		//$scope.selectedPageURL = $scope.selectedPage.page;
		
		
		// clears selection details of `PageBreakDownDetails`
		$scope.selectedRUMIdTimeForPageBreakDownDetails = undefined;
		$scope.selectedRUMPageLoadTime = undefined;
		
		// getschart data
		$scope.getPageLoadTimeChartData();
	};
	
	// get Page load time chart data for 
	$scope.getPageLoadTimeChartData = function() {
		$scope.rumChartData.pageLoadTimeChartData = [];
/*
		if( sliderSelectedValue === null ){
			rumService.getSelectedPageLoadTimeWithDateRange($scope.selectedModuleUId, $scope.selectedPage.page, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {//uid, url, startDate,endDate 
				var chartdata = data.message || [];
				$scope.rumChartData.pageLoadTimeChartData = chartdata;
			});
		}else{
*/
			rumService.getSelectedPageLoadTime($scope.selectedModuleUId, $scope.selectedPage.page, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode, function(data) {//uid, url, fromstartinterval,
				
				if ( ! data.success ) {
					// err msg
					messageService.showErrorMessage(data.errorMessage);
				} else {
					var chartdata = data.message || [];
					$scope.rumChartData.pageLoadTimeChartData = chartdata;
				}
			});
//		}
	};
	
	// 
	$scope.getPageBreakDownDetails = function(time, value, rumId) {
		//$scope.selectedRUMIdTimeForPageBreakDownDetails = $scope.rumChartData.rumIdMapping[time+'_'+value];
		$scope.selectedRUMIdTimeForPageBreakDownDetails = rumId;
		
		$scope.selectedRUMPageLoadTime = time;
		
		$scope.rumChartData.pageBreakDownData = [];
		$scope.rumChartData.pageBreakDownFullURL = '';
		
/*
		if( sliderSelectedValue === null ){
			rumService.getPageBreakDownDetailsWithDateRange($scope.selectedModuleUId, $scope.selectedRUMIdTimeForPageBreakDownDetails, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {//uid, url, fromstartinterval, 
				$scope.rumChartData.pageBreakDownData = data.message;
			});
		}else{
*/
			rumService.getPageBreakDownDetails($scope.selectedModuleUId, $scope.selectedRUMIdTimeForPageBreakDownDetails, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {//uid, url, fromstartinterval,

				if ( ! data.success ) {
					// err msg
					messageService.showErrorMessage(data.errorMessage);
				} else { 
					var joResp = data.message;
					$scope.rumChartData.pageBreakDownFullURL = joResp.fullURL;
					$scope.rumChartData.pageBreakDownData = joResp.pageBreakDownDetails;
				}
			});
//		}
	};
	
	
	
	// RUM, donut chart details, for site analysis, 
	$scope.getRUMSummary = function(){
		clearDonutChartsData();
		
		var resultDonutChartData;
		resultDonutChartData = rumService.getDonutChartdata('Browser', $scope.selectedModuleUId, $scope.rumDetails.sliderSelectedValue);
		resultDonutChartData.then(function(resp) {
			$scope.rumChartData.browserDonutData=resp;
		});
		
		
		resultDonutChartData="";
		resultDonutChartData = rumService.getDonutChartdata('DeviceType', $scope.selectedModuleUId, $scope.rumDetails.sliderSelectedValue);
		resultDonutChartData.then(function(resp) {
			$scope.rumChartData.deviceTypeDonutData=resp;
		});
		
		
		resultDonutChartData="";
		resultDonutChartData = rumService.getDonutChartdata('OS', $scope.selectedModuleUId, $scope.rumDetails.sliderSelectedValue);
		resultDonutChartData.then(function(resp) {
			$scope.rumChartData.osDonutData=resp;
		});

		
		resultDonutChartData="";
		resultDonutChartData = rumService.getDonutChartdata('DEVICE_NAME', $scope.selectedModuleUId, $scope.rumDetails.sliderSelectedValue);
		resultDonutChartData.then(function(resp) {
			$scope.rumChartData.deviceNameDonutData=resp;
		});
	};
	
	function clearDonutChartsData() {
		$scope.rumChartData.browserDonutData = [];
		$scope.rumChartData.deviceTypeDonutData = [];
		$scope.rumChartData.osDonutData = [];
		$scope.rumChartData.deviceNameDonutData = [];
	}
	
	
	// TODO: thinks, Visitors count graph is new logic
	// RUM, Visitors count
	$scope.getRUMBarChart = function() {
		$scope.rumChartData.visitorsCountChartData = [];
		//$scope.d3XaixsFormat = aryD3ChartTimeFormat[3];
		var totalVis = 0;
		
		var resultRUMAreaChart = rumService.getRUMDashArea($scope.selectedModuleUId, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode);
		resultRUMAreaChart.then(function(resp) {
			totalVis = 0;
			if( ! resp.success ){
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				var data = resp.message;
				if(data.dailyVisitorsCount.length>0){
					$scope.rumChartData.visitorsCountChartData = data.dailyVisitorsCount;
						
					$scope.rumChartData.visitorsCountChartData.forEach(function(d) {
						totalVis =  totalVis + d.V;
					});
				}else{
					$scope.rumChartData.visitorsCountChartData = [];
				}
			}
			$scope.rumChartData.totalVisitor = totalVis;
		});
	};
	
	// onclick of bar chart, to open top responses
	$scope.showPageViewsTopResponses = function(joDatum) {
		$scope.openTopRUMResponses($scope.siteAnalysisTypes[4], joDatum);
	};
	
	/*
	$scope.getRUMBarChartWithDateRange = function() {
		$scope.rumChartData.visitorsCountChartData = [];
		$scope.rumDetails.d3XaixsFormat = "%d %b";
		var totalVis = 0;
		var resultRUMAreaChart = rumService.getRUMBarChartWithDateRange($scope.selectedModuleUId, $scope.rumDetails.startDateTime.getTime(), $scope.rumDetails.endDateTime.getTime());
		resultRUMAreaChart.then(function(resp) {
			totalVis = 0;
			if(resp.success){
				var data = resp.message;
				if(data.dailyVisitorsCount.length>0){
					$scope.rumChartData.visitorsCountChartData = data.dailyVisitorsCount;
						
					$scope.rumChartData.visitorsCountChartData.forEach(function(d) {
						totalVis =  totalVis + d.V;
					});
				}else{
					$scope.rumChartData.visitorsCountChartData = [];
				}
			}
			$scope.rumChartData.totalVisitor = totalVis;
		});
	};*/
	
	//
	$scope.getRUMLastReceivedOn = function() {
		$scope.rumChartData.lastReceivedOn = '';
		
		rumService.getRUMLastReceivedOn($scope.selectedModuleUId, function(data){
			 
			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumChartData.lastReceivedOn = data.message; 
			}
		});
	};
	
	
	// gets browser wise data
	$scope.getRUMBrowserWiseData = function() {
		$scope.browserLoading = true;
		$scope.rumChartData = {};
		
/*
		if(($scope.rumDetails.startDateTime !='' ) && ($scope.rumDetails.endDateTime !='')){
			rumService.getRUMBrowserWiseDataWithDateRange($scope.selectedModuleUId, $scope.rumDetails.startDateTime.getTime(), $scope.rumDetails.endDateTime.getTime(), function(data) {
				if ( ! data.success ) {
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.browserLoading = false;
					$scope.rumChartData.browserWiseVisitorsCount = data.message;
					var barVal = 0;
					for(var i = 0; i<$scope.rumChartData.browserWiseVisitorsCount.length; i= i+1){
						barVal = barVal + $scope.rumChartData.browserWiseVisitorsCount[i].visitCount;
					}
					for(var i = 0; i<$scope.rumChartData.browserWiseVisitorsCount.length; i= i+1) {
						$scope.rumChartData.browserWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.browserWiseVisitorsCount[i].visitCount*100)/barVal;
					}
				}
			});
		}else{
*/
			rumService.getRUMBrowserWiseData($scope.selectedModuleUId, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode, function(data) {
				$scope.browserLoading = false;
				
				if ( ! data.success ) {
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.rumChartData.browserWiseVisitorsCount = data.message;
					var barVal = 0;
					for(var i = 0; i<$scope.rumChartData.browserWiseVisitorsCount.length; i= i+1){
						barVal = barVal + $scope.rumChartData.browserWiseVisitorsCount[i].visitCount;
					}
					for(var i = 0; i<$scope.rumChartData.browserWiseVisitorsCount.length; i= i+1) {
						$scope.rumChartData.browserWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.browserWiseVisitorsCount[i].visitCount*100)/barVal;
					}
				}
			});
//		}
	};
	
	// gets device type wise data
	$scope.getRUMDeviceTypeWiseData = function() {
		$scope.deviceTypeLoading = true;
		$scope.rumChartData = {};
/*
		if(($scope.rumDetails.startDateTime !='' ) && ($scope.rumDetails.endDateTime !='')){
			rumService.getRUMDeviceTypeWiseDataWithDateRange($scope.selectedModuleUId, $scope.rumDetails.startDateTime.getTime(), $scope.rumDetails.endDateTime.getTime(), function(data) {
				if ( ! data.success ) {
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.deviceTypeLoading = false;
					$scope.rumChartData.deviceTypeWiseVisitorsCount = data.message;
					var barVal = 0;
					for(var i = 0; i<$scope.rumChartData.deviceTypeWiseVisitorsCount.length; i= i+1){
						barVal = barVal + $scope.rumChartData.deviceTypeWiseVisitorsCount[i].visitCount;
					}
					for(var i = 0; i<$scope.rumChartData.deviceTypeWiseVisitorsCount.length; i= i+1) {
						$scope.rumChartData.deviceTypeWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.deviceTypeWiseVisitorsCount[i].visitCount*100)/barVal;
					}
				}
			});
		}else{
*/
			rumService.getRUMDeviceTypeWiseData($scope.selectedModuleUId, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode, function(data) {
				$scope.deviceTypeLoading = false;
				
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.rumChartData.deviceTypeWiseVisitorsCount = data.message;
					var barVal = 0;
					for(var i = 0; i<$scope.rumChartData.deviceTypeWiseVisitorsCount.length; i= i+1){
						barVal = barVal + $scope.rumChartData.deviceTypeWiseVisitorsCount[i].visitCount;
					}
					for(var i = 0; i<$scope.rumChartData.deviceTypeWiseVisitorsCount.length; i= i+1) {
						$scope.rumChartData.deviceTypeWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.deviceTypeWiseVisitorsCount[i].visitCount*100)/barVal;
					}
				}
			});
//		}
	};
	
	// gets os wise data
	$scope.getRUMOSWiseData = function() {
		$scope.osLoading = true;
		$scope.rumChartData = {};
/*
		if(($scope.rumDetails.startDateTime !='' ) && ($scope.rumDetails.endDateTime !='')){
			rumService.getRUMOSWiseDataWithDateRange($scope.selectedModuleUId, $scope.rumDetails.startDateTime.getTime(), $scope.rumDetails.endDateTime.getTime(), function(data) {
				if ( ! data.success ) {
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.osLoading = false;
					$scope.rumChartData.osWiseVisitorsCount = data.message;
					var barVal = 0;
					for(var i = 0; i<$scope.rumChartData.osWiseVisitorsCount.length; i= i+1){
						barVal = barVal + $scope.rumChartData.osWiseVisitorsCount[i].visitCount;
					}
					for(var i = 0; i<$scope.rumChartData.osWiseVisitorsCount.length; i= i+1) {
						$scope.rumChartData.osWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.osWiseVisitorsCount[i].visitCount*100)/barVal;
					}
				}
			});
		}else{
*/
			rumService.getRUMOSWiseData($scope.selectedModuleUId, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode, function(data) {
				$scope.osLoading = false;
				
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.rumChartData.osWiseVisitorsCount = data.message;
					var barVal = 0;
					for(var i = 0; i<$scope.rumChartData.osWiseVisitorsCount.length; i= i+1){
						barVal = barVal + $scope.rumChartData.osWiseVisitorsCount[i].visitCount;
					}
					for(var i = 0; i<$scope.rumChartData.osWiseVisitorsCount.length; i= i+1) {
						$scope.rumChartData.osWiseVisitorsCount[i].avgLoadTime = ($scope.rumChartData.osWiseVisitorsCount[i].visitCount*100)/barVal;
					}
				}
			});
//		}
	};
	
	// gets device name wise data
//	$scope.getRUMDeviceNameWiseData = function() {
//		rumService.getRUMDeviceNameWiseData($scope.selectedModuleUId, $scope.rumDetails.sliderSelectedValue, function(data) {
//			if ( ! data.success ) {
//				messageService.showErrorMessage(data.errorMessage);
//			} else {
//				$scope.rumChartData.deviceNameWiseVisitorsCount = data.message;
//			}
//		});
//	};
	
	$scope.getRUMLocationWiseData = function() {
		$scope.locationLoading = true;
		$scope.rumChartData = {};
/*
		if(($scope.rumDetails.startDateTime !='' ) && ($scope.rumDetails.endDateTime !='')){
			rumService.getRUMLocationWiseDataWithDateRange($scope.selectedModuleUId, $scope.rumDetails.startDateTime.getTime(), $scope.rumDetails.endDateTime.getTime(), function(data) {
				if ( ! data.success ) {
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.locationLoading = false;
					$scope.rumChartData.locationWiseVisitorsCount = data.message;
					if($scope.rumChartData.locationWiseVisitorsCount.length>0){
						var avgVal = 0;
		   			   for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1){
		   			   		avgVal = avgVal + $scope.rumChartData.locationWiseVisitorsCount[i].count;
		   			   }
		   			   for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1) {
		   			   		$scope.rumChartData.locationWiseVisitorsCount[i].barsize = ($scope.rumChartData.locationWiseVisitorsCount[i].count*100)/avgVal;
		   			   }
					}
				}
			});
		}else{
*/
			rumService.getRUMLocationWiseData($scope.selectedModuleUId, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode, function(data) {
				$scope.locationLoading = false;
				
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.rumChartData.locationWiseVisitorsCount = data.message;
					if($scope.rumChartData.locationWiseVisitorsCount.length>0){
						var avgVal = 0;
		   			   for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1){
		   			   		avgVal = avgVal + $scope.rumChartData.locationWiseVisitorsCount[i].count;
		   			   }
		   			   for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1) {
		   			   		$scope.rumChartData.locationWiseVisitorsCount[i].barsize = ($scope.rumChartData.locationWiseVisitorsCount[i].count*100)/avgVal;
		   			   }
					}
				}
			});
//		}
	};
	
	
	$scope.clearRUMChartValues = function() {
		clearRUMDetailsOtherThanSelections();
		
		// clears selection details
		clearRUMSelectionDetails();
	};
	function clearRUMDetailsOtherThanSelections() {
		// clear page analysis details
		clearRUMPageAnalysis();
		// clears RUM site analysis data
		clearRUMSiteAnalysis();
		// clears RUM's, last received on & total visitor
		clearRUMBriefDetails();
		clearDonutChartsData();
	}
	
	// clears RUM page analysis details 
	function clearRUMPageAnalysis() {
		$scope.rumChartData.pagesLoadTime = [];
		$scope.rumChartData.visitorsCountChartData = [];
		$scope.rumChartData.pageLoadTimeChartData = [];
		$scope.rumChartData.pageBreakDownData = [];
		$scope.rumChartData.pageBreakDownFullURL = '';
	}
	// clears RUM site analysis details 
	function clearRUMSiteAnalysis() {
		$scope.rumChartData.browserWiseVisitorsCount = [];
		$scope.rumChartData.deviceTypeWiseVisitorsCount = [];
		$scope.rumChartData.osWiseVisitorsCount = [];
		$scope.rumChartData.deviceTypeWiseVisitorsCount = [];
	}
	// clears RUM's, last received on & total visitor
	function clearRUMBriefDetails() {
		$scope.rumChartData.lastReceivedOn = '';
		$scope.rumChartData.totalVisitor = 0;
	}
	// clears RUM selection details 
	function clearRUMSelectionDetails() {
		$scope.selectedPage = undefined;
		$scope.selectedRUMIdTimeForPageBreakDownDetails = undefined;
		$scope.selectedRUMPageLoadTime = undefined;
	}
	
	
	
	$scope.loadCIDetails = function() {
		//console.log("Module Agent Type :: "+$scope.moduleAgentTypes);
		//console.log("Module Environment Type :: "+$scope.moduleEnvironments);
		
		$scope.getModuleAgentTypes();
		$scope.getModuleEnvironments();
		// commented due to load Events after selected agent_type
		//$scope.getEventsSummary();
	};
	
	function loadCISelectionDetails() {
		$scope.getEventsSummary();
		
		if ( $scope.selectedEvent !== undefined ) {
			$scope.loadSelectedEventDetails($scope.selectedEvent);
		}
	}
	
	
	// 
	$scope.getModuleAgentTypes = function() {
		//console.log("Module Agent Type :: "+$scope.moduleAgentTypes);
		$scope.moduleAgentTypes = [];
		
		rumService.getModuleAgentTypes($scope.selectedModuleUId, function(data) {
			
			if(data.success) {
				$scope.moduleAgentTypes = data.message;
//				$scope.selectedModuleAgentType = data.message[0];
				if ($scope.moduleAgentTypes.length > 0) {
					$scope.selectedModuleAgentType = $scope.moduleAgentTypes[0];
					$scope.getSelectedAgentTypeEvents();
				}
				 
			} else {
				// TODO: err
			}
		});
	};
	
	$scope.getModuleEnvironments = function() {
		//console.log("Module Environment Type :: "+$scope.moduleEnvironments);
		$scope.moduleEnvironments = [];
		
		rumService.getModuleEnvironments($scope.selectedModuleUId, function(data) {
			
			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.moduleEnvironments = data.message;
//				$scope.selectedModuleEnvironment = data.message[0];
			}
		});
	};
	
	
	$scope.getSelectedAgentTypeEvents = function() {
		$scope.selectedEvent = undefined;
		clearCIDetailsOtherThanSelections();
		
		//$rootScope.healthBoardFilters = { interval: $scope.sliderSelectedValue, startDateTime: $scope.selectedStartDateTime, endDateTime: $scope.selectedEndDateTime};
		//sliderSelectedValue = $rootScope.healthBoardFilters.interval;
		//nStartDateTimeInMills = $rootScope.healthBoardFilters.startDateTime;
		//nEndDateTimeInMills = $rootScope.healthBoardFilters.endDateTime;
		if ($scope.selectedModuleAgentType != undefined){
			$scope.getEventsSummary();
		} else {
			$scope.ciChartData.eventsSummary = [];
		}
	};
	
	// gets Events Summary, bar chart
	$scope.getEventsSummary = function() {
		var environmentValue = $scope.selectedModuleEnvironment == undefined ? null : $scope.selectedModuleEnvironment.envValue;
		if( sliderSelectedValue === null ){
			rumService.getEventsSummaryWithDateRange($scope.selectedModuleUId, nStartDateTimeInMills, nEndDateTimeInMills, $scope.selectedModuleAgentType.agentTypeValue, environmentValue, function(data) {
				if( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.ciChartData.eventsSummary = data.message;
				}
			});
		}else{
			rumService.getEventsSummary($scope.selectedModuleUId, sliderSelectedValue, $scope.selectedModuleAgentType.agentTypeValue, environmentValue, function(data) {
				if( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.ciChartData.eventsSummary = data.message;
				}
			});
		}
	};
	
	
	
	$scope.loadSelectedEventDetails = function(joEvent) {

		//$scope.selectedPage = url;
		$scope.selectedEvent = joEvent;
		//$scope.selectedEventId = $scope.selectedPage.page;
		//$scope.selectedPageURL = url;
		if( sliderSelectedValue === null ){
			// 
			$scope.getEventLoadTimeWithDateRange();
			$scope.getCIDailyVisitorsCountWithDateRange();
			
			// load CI event site analysis donut chart data
			//$scope.loadCIEventSiteAnalysisDonutData();
			
			// load CI event site analysis bar chart data
			$scope.loadCIEventSiteAnalysisBarDataWithDateRange();
			
		}else{
			// 
			$scope.getEventLoadTime();
			$scope.getCIDailyVisitorsCount();
			
			// load CI event site analysis donut chart data
			//$scope.loadCIEventSiteAnalysisDonutData();
			
			// load CI event site analysis bar chart data
			$scope.loadCIEventSiteAnalysisBarData();
		}
		$scope.getEventLastReceivedOn();
	};
	
	// load CI event site analysis donut chart data
	$scope.loadCIEventSiteAnalysisDonutData = function() {
		$scope.getBrowserWiseDonutData();
		$scope.getDeviceTypeWiseDonutData();
		$scope.getOSWiseDonutData();
		$scope.getDeviceNameWiseDonutData();
	};
	
	$scope.loadCIEventSiteAnalysisBarData = function() {
		$scope.getCIBrowserWiseData();
		$scope.getCIDeviceTypeWiseData();
		$scope.getCIOSWiseData();
		$scope.getCIDeviceNameWiseData();
	};

	$scope.loadCIEventSiteAnalysisBarDataWithDateRange = function() {
		$scope.getCIBrowserWiseDataWithDateRange();
		$scope.getCIDeviceTypeWiseDataWithDateRange();
		$scope.getCIOSWiseDataWithDateRange();
		$scope.getCIDeviceNameWiseDataWithDateRange();
	};

	$scope.getEventLoadTime = function() {
		$scope.ciChartData.eventLoadTimeChartData = [];
		
		rumService.getsEventLoadTime($scope.selectedModuleUId, $scope.selectedEvent.eventId, $scope.rumDetails.sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var dataMsg = data.message;
				$scope.ciChartData.eventLoadTimeChartData = dataMsg.eventLoadTimeData;
			}
		});
	};

	$scope.getEventLoadTimeWithDateRange = function() {
		$scope.ciChartData.eventLoadTimeChartData = [];
		
		rumService.getsEventLoadTimeWithDateRange($scope.selectedModuleUId, $scope.selectedEvent.eventId, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var dataMsg = data.message;
				$scope.ciChartData.eventLoadTimeChartData = dataMsg.eventLoadTimeData;
			}
		});
	};
	

	$scope.getCIDailyVisitorsCount = function() {
		$scope.ciChartData.dailyVisitorsCount = [];
		
		rumService.getCIDailyVisitorsCount($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var dataMsg = data.message;
				$scope.ciChartData.dailyVisitorsCount = dataMsg.dailyVisitorsCount;
				
				var nTotalEventVisitors = 0;
				$scope.ciChartData.dailyVisitorsCount.forEach(function(d) {
					nTotalEventVisitors = nTotalEventVisitors + d.V;
				});
				$scope.ciChartData.totalEventVisitors = nTotalEventVisitors;
			}
		});
	};

	$scope.getCIDailyVisitorsCountWithDateRange = function() {
		$scope.ciChartData.dailyVisitorsCount = [];
		
		rumService.getCIDailyVisitorsCountWithDateRange($scope.selectedModuleUId, $scope.selectedEvent.eventId, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var dataMsg = data.message;
				$scope.ciChartData.dailyVisitorsCount = dataMsg.dailyVisitorsCount;
				
				var nTotalEventVisitors = 0;
				$scope.ciChartData.dailyVisitorsCount.forEach(function(d) {
					nTotalEventVisitors = nTotalEventVisitors + d.V;
				});
				$scope.ciChartData.totalEventVisitors = nTotalEventVisitors;
			}
		});
	};

	$scope.getBrowserWiseDonutData = function() {
		$scope.ciChartData.browserWiseDonutData = [];
		
		rumService.getBrowserWiseDonutData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.browserWiseDonutData = data.message;
			}
		});
	};

	$scope.getDeviceTypeWiseDonutData = function() {
		$scope.ciChartData.deviceTypeWiseDonutData = [];
		
		rumService.getDeviceTypeWiseDonutData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.deviceTypeWiseDonutData = data.message;
			}
		});
	};

	$scope.getOSWiseDonutData = function() {
		$scope.ciChartData.osWiseDonutData = [];
		
		rumService.getOSWiseDonutData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.osWiseDonutData = data.message;
			}
		});
	};

	$scope.getDeviceNameWiseDonutData = function() {
		$scope.ciChartData.deviceNameWiseDonutData = [];
		
		rumService.getDeviceNameWiseDonutData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {
			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.deviceNameWiseDonutData = data.message;
			}
		});
	};

	$scope.getEventLastReceivedOn = function() {
		$scope.ciChartData.eventLastReceivedOn = '';
		
		rumService.getEventLastReceivedOn($scope.selectedModuleUId, $scope.selectedEvent.eventId, function(data) {
			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.eventLastReceivedOn = data.message;
			}
		});
	};
	
	// get CI browser Wise visitors count bar data
	$scope.getCIBrowserWiseData = function() {
		$scope.ciChartData.browserWiseData = [];
		
		rumService.getCIBrowserWiseData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.browserWiseData = data.message;
			}
		});
	};
	$scope.getCIBrowserWiseDataWithDateRange = function() {
		$scope.ciChartData.browserWiseData = [];
		
		rumService.getCIBrowserWiseDataWithDateRange($scope.selectedModuleUId, $scope.selectedEvent.eventId, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.browserWiseData = data.message;
			}
		});
	};

	// get CI device Type Wise visitors count bar data
	$scope.getCIDeviceTypeWiseData = function() {
		$scope.ciChartData.deviceTypeWiseData = [];
		
		rumService.getCIDeviceTypeWiseData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success)  {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.deviceTypeWiseData = data.message;
			}
		});
	};

	$scope.getCIDeviceTypeWiseDataWithDateRange = function() {
		$scope.ciChartData.deviceTypeWiseData = [];
		
		rumService.getCIDeviceTypeWiseDataWithDateRange($scope.selectedModuleUId, $scope.selectedEvent.eventId, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.deviceTypeWiseData = data.message;
			}
		});
	};

	// get CI device Type Wise visitors count bar data
	$scope.getCIOSWiseData = function() {
		$scope.ciChartData.osWiseData = [];
		
		rumService.getCIOSWiseData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.osWiseData = data.message;
			}
		});
	};
	$scope.getCIOSWiseDataWithDateRange = function() {
		$scope.ciChartData.osWiseData = [];
		
		rumService.getCIOSWiseDataWithDateRange($scope.selectedModuleUId, $scope.selectedEvent.eventId, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.osWiseData = data.message;
			}
		});
	};

	// get CI device Type Wise visitors count bar data
	$scope.getCIDeviceNameWiseData = function() {
		$scope.ciChartData.deviceNameWiseData = [];
		
		rumService.getCIDeviceNameWiseData($scope.selectedModuleUId, $scope.selectedEvent.eventId, sliderSelectedValue, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.deviceNameWiseData = data.message;
			}
		});
	};
	
	$scope.getCIDeviceNameWiseDataWithDateRange = function() {
		$scope.ciChartData.deviceNameWiseData = [];
		
		rumService.getCIDeviceNameWiseDataWithDateRange($scope.selectedModuleUId, $scope.selectedEvent.eventId, nStartDateTimeInMills, nEndDateTimeInMills, function(data) {

			if( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.ciChartData.deviceNameWiseData = data.message;
			}
		});
	};
	
	// clear values when moved to RUM
	$scope.clearCIValues = function() {
		$scope.moduleAgentTypes = [];
		$scope.moduleEnvironments = [];
		
		clearCIDetailsOtherThanSelections();
		
		// clears selection details
		clearCISelectionDetails();
	};
	// clears CI event analysis
	function clearCIEventAnalysis() {
		$scope.ciChartData.eventsSummary = [];
		$scope.ciChartData.eventLoadTimeChartData = [];
		$scope.ciChartData.dailyVisitorsCount = [];
	}
	// clears CI site analysis
	function clearCISiteAnalysis() {
		$scope.ciChartData.browserWiseData = [];
		$scope.ciChartData.deviceTypeWiseData = [];
		$scope.ciChartData.osWiseData = [];
		$scope.ciChartData.deviceNameWiseData = [];
	}
	// clears CI event's, last receivedon & totalvisitor 
	function clearCIBriefDetails() {
		$scope.ciChartData.eventLastReceivedOn = '';
		$scope.ciChartData.totalEventVisitors = 0;
	}
	// clear CI selection details, 
	function clearCISelectionDetails() {
		// clears CI, dropdown selection
		$scope.selectedModuleEnvironment = undefined;
		$scope.selectedModuleAgentType = undefined;
		
		$scope.selectedEvent = undefined;
	}
	function clearCIDetailsOtherThanSelections() {
		// clear CI event details 
		clearCIEventAnalysis();
		
		/* for CI donut data
		$scope.ciChartData.browserWiseDonutData = [];
		$scope.ciChartData.deviceTypeWiseDonutData = [];
		$scope.ciChartData.osWiseDonutData = [];
		$scope.ciChartData.deviceNameWiseDonutData = [];
		*/
		clearCISiteAnalysis();
		
		// clears CI event's, last received on & total visitor
		clearCIBriefDetails();
	}
	
	
	$scope.getrumDetailsChartWithDateRange= function(){
		$scope.rumDetails.sliderSelectedValue = arySliderServerSideScale[0];
		var selectedDateCheck=false;
		var startHourCheck=false;
		var startMinsCheck=false;
		var endHourCheck=false;
		var endMinsCheck=false;
		
		
		if(($scope.rumDetails.startDate == '' ) || ($scope.rumDetails.endDate =='')){
			$scope.rumDetails.startDateTime = '';
			$scope.rumDetails.endDateTime = '';
			
			messageService.showWarningMessage('Please select start date & end date');
		}else{
			selectedDateCheck = true;
		}

		if(($scope.rumDetails.startHour == null) ||($scope.rumDetails.startHour.length == 0) || (parseInt($scope.rumDetails.startHour)>23)){
			$scope.rumDetails.startDateTime = '';
			$scope.rumDetails.endDateTime = '';
			
			messageService.showWarningMessage('Start Hour should not be either empty or greater than 23');
		}else{
			startHourCheck = true;
		}

		if(($scope.rumDetails.startMins == null) || ($scope.rumDetails.startMins.length ==0) || (parseInt($scope.rumDetails.startMins)>59)){
			$scope.rumDetails.startDateTime = '';
			$scope.rumDetails.endDateTime = '';
			
			messageService.showWarningMessage('Start Mins should not be either empty or greater than 59');
		}else{
			startMinsCheck = true;
		}

		if(($scope.rumDetails.endHour == null) || ($scope.rumDetails.endHour.length == 0) || (parseInt($scope.rumDetails.endHour)>23)){
			$scope.rumDetails.startDateTime = '';
			$scope.rumDetails.endDateTime = '';
			
			messageService.showWarningMessage('End Hour should not be either empty or greater than 23');
		}else{
			endHourCheck = true;
		}

		if(($scope.rumDetails.endMins == null ) || ($scope.rumDetails.endMins.length == 0) || (parseInt($scope.rumDetails.endMins) > 59)){
			$scope.rumDetails.startDateTime = '';
			$scope.rumDetails.endDateTime = '';
			
			messageService.showWarningMessage('End Mins should not be either empty or greater than 59');
		}else{
			endMinsCheck = true;
		}
		
		if((selectedDateCheck == true ) && (startHourCheck == true ) && (startMinsCheck == true ) && (endHourCheck == true ) && (endMinsCheck == true ) ){
			$scope.rumDetails.startDateTime = $appedoUtils.isDate($scope.rumDetails.startDate) ? $scope.rumDetails.startDate : $appedoUtils.parse_ddMMMyyyy_To_Date($scope.rumDetails.startDate);
			$scope.rumDetails.startDateTime.setHours($scope.rumDetails.startHour);
			$scope.rumDetails.startDateTime.setMinutes($scope.rumDetails.startMins);
			
			$scope.rumDetails.endDateTime = $appedoUtils.isDate($scope.rumDetails.endDate) ? $scope.rumDetails.endDate : $appedoUtils.parse_ddMMMyyyy_To_Date($scope.rumDetails.endDate);
			$scope.rumDetails.endDateTime.setHours($scope.rumDetails.endHour);
			$scope.rumDetails.endDateTime.setMinutes($scope.rumDetails.endMins);
			
			if($scope.rumDetails.startDateTime <= $scope.rumDetails.endDateTime){
				$scope.rumDetails.customDateStatus = true;
				
				sliderSelectedValue = null;
				nStartDateTimeInMills = $scope.rumDetails.startDateTime.getTime();
				nEndDateTimeInMills = $scope.rumDetails.endDateTime.getTime();
				
				
				/*if(checkSelectedDurationLessThanGivenHour(1,(endDateinMs - startDateinMs))){ //1 hour
					$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[0];
					$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[0];
				}else if(checkSelectedDurationLessThanGivenHour(24,(endDateinMs - startDateinMs))){ //24 hour
					$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[1];
					$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[1];
				}else if(checkSelectedDurationLessThanGivenHour(168,(endDateinMs - startDateinMs))){ //7 days
					$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[2];
					$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[2];
				}else if(checkSelectedDurationLessThanGivenHour(360,(endDateinMs - startDateinMs))){ //15 days
					$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[3];
					$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[3];
				}else if(checkSelectedDurationLessThanGivenHour(720,(endDateinMs - startDateinMs))){ //30 days
					$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[4];
					$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[4];
				}else if(checkSelectedDurationLessThanGivenHour(1440,(endDateinMs - startDateinMs))){ //60 days
					$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[5];
					$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[5];
				}else{ // 120 days
					$scope.rumDetails.d3XaixsTick = arySliderServerSideScale[6];
					$scope.rumDetails.d3XaixsFormat = aryD3ChartTimeFormat[6];
				}*/
				
				
				// PDF x-axis format, (Note: In aryPDFFormats `aryD3ChartTimeFormatForASDPdf` has more same formats used needed)
				if ( appedoDirectiveChartUtils.isDateTimeWithInOneDay(nStartDateTimeInMills, nEndDateTimeInMills) ) {
					// PDF x-axis format, interval with in one day
					$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormat[0];
				} else {
					// PDF x-axis format, interval > one day
					$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormat[2];
				}
				
				loadSelectionDetails();
			} else {
				messageService.showWarningMessage('End datetime should be greater than or equal to start datetime');
			}
		}
	};
	
	// load initially when page refresh uidParam passed, since other scope functions not loaded, added 
	$scope.loadSelectedTypeDetails($scope.uidParam);
	
	// open RUM's top/most time taken responses, based on Browser or City or DeviceType or OS
	$scope.openTopRUMResponses = function(joSiteAnalysisType, joTypeDatum) {
		rumService.openTopRUMResponses($scope.selectedModule, joSiteAnalysisType, joTypeDatum, sliderSelectedValue, nStartDateTimeInMills, nEndDateTimeInMills, healthCode);
	};
	
	
	function checkSelectedDurationLessThanGivenHour(hour,runTime){
		return (1000 * 60 * 60 * Number(hour)) > Number(runTime) ? true : false;
	}

	// to destroy stored hidden params when transistion from `/#/rum_home` page
	$scope.$on('$destroy', function() {
		sessionServices.destroy("uid");
		
		// reset transition from healthboard selection 
		if ( $rootScope.transitionFromHealthBoard ) {
			$rootScope.transitionFromHealthBoard = false;	
		}
	});
}]);

appedoApp.controller('rumSiteAnalysisController', ['$scope', '$state', '$stateParams', 'apmCardService', 'rumCardService', 'rumService', 'sliderFactory', '$appedoUtils', 'sessionServices', 'messageService', function($scope, $state, $stateParams, apmCardService, rumCardService, rumService, sliderFactory, $appedoUtils, sessionServices, messageService) {
	
	//console.info('rumSiteAnalysisController : uid: '+$scope.selectedModuleUId+' <> rumDetails.sliderSelectedValue: '+$scope.rumDetails.sliderSelectedValue);
	
	// tried, $scope.selectedModuleUId & $scope.rumDetails.sliderSelectedValue are from parent controller
	$scope.selectedUId = -1;
	$scope.sliderSelectedDuration = '';
	//$scope.selectedUId = $scope.selectedModuleUId;
	//$scope.sliderSelectedDuration = $scope.rumDetails.sliderSelectedValue;
	
	
	$scope.rumSiteAnalysisChartData = {};
	
	// gets browser wise data
	$scope.getRUMBrowserWiseData = function() {
		rumService.getRUMBrowserWiseData($scope.selectedUId, $scope.sliderSelectedDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumSiteAnalysisChartData.browserWiseVisitorsCount = data.message;
			}
		});
	};
	
	// gets device type wise data
	$scope.getRUMDeviceTypeWiseData = function() {
		rumService.getRUMDeviceTypeWiseData($scope.selectedUId, $scope.sliderSelectedDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumSiteAnalysisChartData.deviceTypeWiseVisitorsCount = data.message;
			}
		});
	};
	
	// gets os wise data
	$scope.getRUMOSWiseData = function() {
		rumService.getRUMOSWiseData($scope.selectedUId, $scope.sliderSelectedDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumSiteAnalysisChartData.osWiseVisitorsCount = data.message;
			}
		});
	};
	
	// gets device name wise data
//	$scope.getRUMDeviceNameWiseData = function() {
//		rumService.getRUMDeviceNameWiseData($scope.selectedUId, $scope.sliderSelectedDuration, function(data) {
//			if ( ! data.success ) {
//				messageService.showErrorMessage(data.errorMessage);
//			} else {
//				$scope.rumSiteAnalysisChartData.deviceNameWiseVisitorsCount = data.message;
//			}
//		});
//	};
	
	$scope.getRUMLocationWiseData = function() {
		rumService.getRUMLocationWiseData($scope.selectedUId, $scope.sliderSelectedDuration, null, null, null, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.rumChartData.locationWiseVisitorsCount = data.message;
				if($scope.rumChartData.locationWiseVisitorsCount.length>0){
					var avgVal = 0;
	   			   for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1){
	   			   		avgVal = avgVal + $scope.rumChartData.locationWiseVisitorsCount[i].count;
	   			   }
	   			   for(var i = 0; i<$scope.rumChartData.locationWiseVisitorsCount.length; i= i+1) {
	   			   		$scope.rumChartData.locationWiseVisitorsCount[i].barsize = ($scope.rumChartData.locationWiseVisitorsCount[i].count*100)/avgVal;
	   			   }
				}
			}
		});
	};
	$scope.loadRUMSiteAnalysis = function() {
		$scope.getRUMBrowserWiseData();
		$scope.getRUMDeviceTypeWiseData();
		$scope.getRUMOSWiseData();
//		$scope.getRUMDeviceNameWiseData();
		$scope.getRUMLocationWiseData();
	};
	//$scope.loadRUMSiteAnalysis();
	

	$scope.$on("loadRUMSiteAnalysis", function(event, uid, sliderSelectedDuration) {
		$scope.selectedUId = uid;
		$scope.sliderSelectedDuration = sliderSelectedDuration;
		
		$scope.loadRUMSiteAnalysis();
	});
}]);


appedoApp.controller('rumWorldMapController', ['$scope', '$attrs', 'apmCardService', 'rumService', 'sessionServices', '$appedoUtils', '$timeout', 'messageService', function($scope, $attrs, apmCardService, rumService, sessionServices, $appedoUtils, $timeout, messageService) {
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('RUM WorldMap Page', 'pageOpen', 
		{
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	$scope.rumDurations = JSON.parse(sessionServices.get("sliderServerSideScale"));
	$scope.selectedRUMDuration = $scope.rumDurations[1];
	$scope.durationForDonut = $scope.rumDurations[0];
	
	$scope.userRUMWebsiteModules = [];
	
	$scope.rumChartData = {};

	// gets user's RUM websites
	$scope.getRUMModules = function() {
		apmCardService.populateApmCardData($scope,'RUM',function(resp){
			$scope.totalVisitor = 0;
			$scope.userRUMWebsiteModules = resp.moduleData;
			loadRUMChartData();
		});
	};
	$scope.getRUMModules();
	
	function loadRUMChartData() {
		$scope.selectedRUMWebSite = $scope.userRUMWebsiteModules[0];
		$scope.getRUMWorldMapData();
	}
	
	$scope.getRUMWorldMapData = function(){
		 $scope.loadRUMSiteAnalysis();
	};
	
	// loads RUM site analysis
	$scope.loadRUMSiteAnalysis = function() {
		$scope.getRUMLocationWiseDataForWorldMap();
	};

	$scope.brodcastRUMSiteAnalysis = function(){
		$timeout(function() {
			$scope.$broadcast('loadRUMSiteAnalysis', $scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration);
		}, 100);
	};
	
	$scope.getRUMLocationWiseDataForWorldMap = function() {
		rumService.getRUMLocationWiseDataForWorldMap($scope.selectedRUMWebSite.uid, $scope.selectedRUMDuration, function(data) {
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var responseData = data.message.mapData;
				$scope.mapData = responseData;
				var pageViewCount = 0, locationCount = 0;
				if(responseData.length>0){
					for (var key in responseData) {
						pageViewCount += responseData[key].completed;
						if(responseData[key].id) {
							locationCount = responseData[key].id++;
						}
					}
				}
				$scope.othersCount = data.message.othersCount;
				$scope.pageViewCount = pageViewCount;
				$scope.locationCount = locationCount;
			}
		});
	};
}]);

appedoApp.controller('rumTopResponsesController', ['$scope', '$uibModalInstance', 'rumModuleFactory', 'rumService', 'selectedModule', 'siteAnalysisType', 'typeDatum', 'interval', 'healthCode', '$appedoUtils', 'sessionServices', 'messageService', 
													function($scope, $uibModalInstance, rumModuleFactory, rumService, selectedModule, siteAnalysisType, typeDatum, interval, healthCode, $appedoUtils, sessionServices, messageService) {
	
	$scope.selectedModule = selectedModule;
	$scope.siteAnalysisType = siteAnalysisType;
	$scope.typeDatum = typeDatum;
	$scope.interval = interval;
	var sliderInterval = $scope.interval.sliderInterval, nStartDateTimeInMills = $scope.interval.startDateTimeInMills, nEndDateTimeInMills = $scope.interval.endDateTimeInMills;
	
	if ( healthCode !== null && healthCode !== undefined ) {//&& (healthCode === 'WARNING' || healthCode === 'CRITICAL') 
		$scope.healthCode = healthCode;
		$scope.RUM_HEALTH_DETAILS = rumModuleFactory.RUM_HEALTH_DETAILS;
	}
	
	$scope.rumTopResponses = [];
	
	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};
	
	
	function loadTopRUMResponses() {
		// top responses form `Page views graph's` time selection, alter interval 
		if ( $scope.siteAnalysisType.isTimeSelection ) {
			alterIntervalForTimeSelection();
		}
		
		rumService.getTopRUMResponses(selectedModule.uid, $scope.siteAnalysisType.type, $scope.typeDatum[$scope.siteAnalysisType.respDatumKey], sliderInterval, nStartDateTimeInMills, nEndDateTimeInMills, $scope.healthCode, function(resp) {
			
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.rumTopResponses = resp.message;
			}
		});
	}
	loadTopRUMResponses();
	
	// top responses form `Page views graph's` time selection, alter interval 
	function alterIntervalForTimeSelection() {
		nStartDateTimeInMills = $scope.typeDatum[$scope.siteAnalysisType.respDatumKey];
		
		if ( $scope.interval.sliderInterval !== null && $scope.interval.sliderInterval !== undefined ) {
			// slider 
			if ( rumModuleFactory.GROUP_BY_MINUTE_INTERVALS.indexOf($scope.interval.sliderInterval) !== -1 ) {
				// + 1 minute
				nEndDateTimeInMills = nStartDateTimeInMills + rumModuleFactory.ONE_MINUTE;
			} else if ( rumModuleFactory.GROUP_BY_HOUR_INTERVALS.indexOf($scope.interval.sliderInterval) !== -1 ) {
				// + 1 hour
				nEndDateTimeInMills = nStartDateTimeInMills + rumModuleFactory.ONE_HOUR;
			} else {
				// + 1 day
				nEndDateTimeInMills = nStartDateTimeInMills + rumModuleFactory.ONE_DAY;
			}
		} else {
			// datetime 
			
			if ( $scope.interval.endDateTimeInMills - $scope.interval.startDateTimeInMills <= rumModuleFactory.ONE_HOUR ) {
				// + 1 minute
				nEndDateTimeInMills = nStartDateTimeInMills + rumModuleFactory.ONE_MINUTE;
			} else if ( $scope.interval.endDateTimeInMills - $scope.interval.startDateTimeInMills <= rumModuleFactory.ONE_DAY ) {
				// + 1 hour
				nEndDateTimeInMills = nStartDateTimeInMills + rumModuleFactory.ONE_HOUR;
			} else {
				// + 1 day
				nEndDateTimeInMills = nStartDateTimeInMills + rumModuleFactory.ONE_DAY;
			}
		}
		
		sliderInterval = undefined;
	}
}]);

appedoApp.controller('apmDetailsController', ['$scope', 'sessionServices', 'apmModulesService', 'ajaxCallService', '$appedoUtils', 'successMsgService', '$state', 'apmModulesFactory','$uibModal','$rootScope', 'messageService', 'asdSliderFactory', 'appedoDirectiveChartUtils', 
                                              function ($scope, sessionServices, apmModulesService, ajaxCallService, $appedoUtils, successMsgService, $state, apmModulesFactory, $uibModal, $rootScope, messageService, asdSliderFactory, appedoDirectiveChartUtils) {
var timerChartsLoading;

// for details page
$scope.asdDetails = {};
$scope.asdDetails.startDate = '';
$scope.asdDetails.endDate = '';
$scope.asdDetails.startDateTime = '';
$scope.asdDetails.endDateTime = '';
$scope.asdDetails.startHour = 0;
$scope.asdDetails.endHour = 23;
$scope.asdDetails.startMins = 0;
$scope.asdDetails.endMins = 59;
$scope.asdDetails.enDateLimit = new Date();
$scope.asdDetails.stDateLimit = new Date("January 01, 2000 00:00:00");

$scope.selectedDetailsModule = sessionServices.get("selectedModule");
$scope.selectedAppCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
console.log($scope.selectedAppCardContent);
$scope.yaxis_category = 'Avg';

var joOldSliderValue = { default_old_value: 1, profiler_old_value: 1 };
// default slider
$scope.sliderValue = joOldSliderValue.default_old_value;
$scope.sliderOptions = asdSliderFactory.defaultSliderOptions;
$scope.sliderSelectedValue = $scope.sliderOptions.qry_intervals[0];

var apmPrevRadioValue = 'MONITOR';
$scope.apmMonitorRadio = 'MONITOR';

var aryAllCounters = [];
$scope.apmChartdata = [];
$scope.asdStaticCountersData = [];

var staticCounterIds = '';

// default and profiler radio btns values
var aryDefaultSliderRadios = ['MONITOR', 'SLOW_QUERY', 'SLOW_PROCEDURE'];
var aryProfilerSliderRadios = ['TRANSACTION', 'KEY_TRANSACTION', 'PROFILER_SLOW_QUERY'];

// chart tick format based on slider interval varies
var aryD3ChartTimeFormatForASDPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForASDPdf"));
$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[0];

$scope.profilerPanel = {};
$scope.profilerPanel.showTransactionLoading = false;
$scope.profilerPanel.showTransTimeTakenGraphLoading = false;
$scope.profilerPanel.showTransMostTimeTakenMethodsLoading = false;
$scope.profilerPanel.showMethodTraceLoading = false;
$scope.profilerData = {};

$scope.showMonitorChartLoading = false;

var joModuleDetails = {
	"Applications": {
		radio_buttons_URL: "common/data/apm_app_monitor_radio_value.json",
		back_button_URL: "/apm_home/application"
	},
	"Servers": {
		radio_buttons_URL: "common/data/apm_svr_monitor_radio_value.json",
		back_button_URL: "/apm_home/servers"
	},
	"Databases": {
		radio_buttons_URL: "common/data/apm_db_monitor_radio_value.json",
		back_button_URL: "/apm_home/db"
	}
};

// gets module radio btns
$scope.getCounterTypeRadioButtons = function() {
	ajaxCallService.getJsonData(joModuleDetails[$scope.selectedDetailsModule].radio_buttons_URL, function(responseData){
		if ( $scope.selectedDetailsModule !== "Servers" ) {
			/*
			 * for APPLICATION & DATABASE, respective counter_type's radio buttons retrieved, 
			 *  since say Tomcat has Profiler `All Transactions` & `Key Transactions` but Apache doesn't have profiler And
			 *  		  Tomcat has Profiler MYSQL's slow_queries but MSIIS doesn't have Profiler slow_queries 
			 */
			$scope.apmRadioButtonValues = responseData[$scope.selectedAppCardContent.type];
			console.log("json Response:"+$scope.apmRadioButtonValues);
		} else {
			// since for all SERVERs has only Monitors, doesn't differentitate with sepecific radio btns
			$scope.apmRadioButtonValues = responseData;
		}
	});
};
$scope.getCounterTypeRadioButtons();

$scope.backToApmCardPage = function() {
	//$state.transitionTo(joModuleDetails[$scope.selectedDetailsModule].back_button_URL);
	$state.transitionTo('/moduleDetails');
};


// load data, based on slider interval 
$scope.loadSelectedTypeData = function() {
	$scope.asdDetails.startDate = '';
	$scope.asdDetails.endDate = '';
	$scope.asdDetails.startHour = 0;
	$scope.asdDetails.endHour = 23;
	$scope.asdDetails.startMins = 0;
	$scope.asdDetails.endMins = 59;
	$scope.asdDetails.startDateTime = '';
	$scope.asdDetails.endDateTime = '';
	
	// loads selected panel type's, say MONITOR or TRANSACTION or ...
	loadSelectedDetails();
};
$scope.loadSelectedTypeData();

// loads selected panel type's, 
function loadSelectedDetails() {
	// clear timers added when change from on tab (ie.. Monitor to Transaction) clears the timer for charts
	clearTimer();
	
	// slider 
	if ( aryDefaultSliderRadios.indexOf( apmPrevRadioValue ) >= 0 && aryProfilerSliderRadios.indexOf( $scope.apmMonitorRadio ) >= 0 ) {
		// previous MONITOR/SLOW_QUERY current TRANSACTION/KEY_TRANSACTION
		$scope.sliderValue = joOldSliderValue.profiler_old_value;
		$scope.sliderOptions = asdSliderFactory.profilerSliderOptions;
	} else if ( aryProfilerSliderRadios.indexOf( apmPrevRadioValue ) >= 0 && aryDefaultSliderRadios.indexOf( $scope.apmMonitorRadio ) >= 0) {
		// previous PROFILER current MONITOR/SLOW_QUERY 
		$scope.sliderValue = joOldSliderValue.default_old_value ;
		$scope.sliderOptions = asdSliderFactory.defaultSliderOptions;
	}
	$scope.sliderSelectedValue = $scope.sliderOptions.qry_intervals[$scope.sliderValue - 1];
	
	if( $scope.apmMonitorRadio === "MONITOR" ) {
		// get graph data
		getGraphData();
		joOldSliderValue.default_old_value = $scope.sliderValue;
	} else if( $scope.apmMonitorRadio === "TRANSACTION" ) {
		// loads profiler data
		$scope.loadProfilerDetails();
		joOldSliderValue.profiler_old_value = $scope.sliderValue;
	} else if( $scope.apmMonitorRadio === "KEY_TRANSACTION" ) {
		// loads profiler KEY TRANSACTIONS data
		$scope.loadKeyProfilerDetails();
		joOldSliderValue.profiler_old_value = $scope.sliderValue;
	} else if( $scope.apmMonitorRadio === "PROFILER_SLOW_QUERY" ) {
		// gets profiler Slow query data
		getProfilerSlowQueryData();
		joOldSliderValue.profiler_old_value = $scope.sliderValue;
	} else if( $scope.apmMonitorRadio === "SLOW_QUERY" ) {
		// gets SLOW query data
		getDatabaseSlowQueryData();
		joOldSliderValue.default_old_value = $scope.sliderValue;
	} else if( $scope.apmMonitorRadio === "SLOW_PROCEDURE" ) {
		// gets SLOW procedure data
		getSlowProcedureData();
		joOldSliderValue.default_old_value = $scope.sliderValue;
	}
	// chart axis
	$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[$scope.sliderValue - 1];
	
	apmPrevRadioValue = $scope.apmMonitorRadio;
};

// loads module's chart data
function getGraphData(){
	$scope.inDashBoardStatus = false;
    $scope.dotsize = 1.5;
    $scope.linewidth = 2;
    $scope.linkstatus = "false";
	
	// gets module's counters and load counters charts data
	getModuleCountersAndLoadCharts();
}

// gets module's selected counters and load counters charts data
function getModuleCountersAndLoadCharts() {
	// gets selected counters, after resp gets respective counter's chart data
	var resultSelectedCounterSummary = apmModulesService.getSelectedCounterSummary(/*$scope.selectedAppCardContent.guid*/$scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type+' '+$scope.selectedAppCardContent.version);
	resultSelectedCounterSummary.then(function(resp) {
		if ( ! resp.success ) {
			// err
			messageService.showErrorMessage(resp.errorMessage);	
		} else {
			aryAllCounters = resp.message;
			// disconnect array from obj by ref.
			$scope.apmChartdata = aryAllCounters.slice();
			$scope.asdStaticCountersData = [];
			staticCounterIds = '';
			
			// get counters chart data
			$scope.loadCountersChartdata();	
		}
	});
};

// get counters chart data
$scope.loadCountersChartdata = function() {
	clearTimeout(timerChartsLoading);
	
	var startDateTime = null, endDateTime = null;
	
	if( $scope.asdDetails.startDateTime != '' && $scope.asdDetails.endDateTime != '' ){
		startDateTime = $scope.asdDetails.startDateTime.getTime();
		endDateTime = $scope.asdDetails.endDateTime.getTime();
	} else {
		startDateTime = null;
		endDateTime = null;
	}
	
	// get counters chart data
	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
		//$scope.apmChartdata[i].yaxis_category = 'Avg';
		var joCounterSummary = $scope.apmChartdata[i];
		joCounterSummary.counterId = joCounterSummary.counter_id;
		//joCounterSummary.yaxis_category = 'Max';
		
		// get counter chart data
		if ( ! joCounterSummary.is_static_counter ) {
			$scope.getModuleCountersChartdata(/*$scope.selectedAppCardContent.guid*/$scope.selectedAppCardContent.col_3.var2, joCounterSummary.counter_id, joCounterSummary.maxTimeStamp != undefined ? joCounterSummary.maxTimeStamp : null, joCounterSummary.is_above_threshold, startDateTime, endDateTime, joCounterSummary.max_value_counter_id);
		} else {
			// filters static counters, at 1st time loads; second time timer refresh for every 1 min., thinks `else` not comes
			
			// removes & decrements, since array `$scope.apmChartdata` is reduced 
			var joRemoved = $scope.apmChartdata.splice(i, 1);
			i = i - 1;
			
			// static counters
			$scope.asdStaticCountersData.push(joCounterSummary);
			if ( staticCounterIds.length > 0 ) {
				staticCounterIds += ',';
			}
			staticCounterIds += joCounterSummary.counter_id;
		}
	}
	
	// get static counters data 
	if ( staticCounterIds.length > 0 ) {
		getModuleStaticCountersData($scope.selectedAppCardContent.guid, staticCounterIds);	
	}
	
	
	// timer chart refresh for last `1 hour`
	if ( $scope.sliderSelectedValue == '1 hour') {
		timerChartsLoading = setTimeout($scope.loadCountersChartdata, sessionServices.get("graphRefresh"));
	}
};

// gets counter chartdata
$scope.getModuleCountersChartdata = function(guid, counter_id, maxTimeStamp, is_above_threshold, startDateTime, endDateTime, nMaxValueCounterId) {
	// TODO: thinks, to check for respective `joCounterSummary`'s chart response data is updated in respective jo

	var resultModuleCountersChartdata = apmModulesService.getModuleCountersChartdata(guid, counter_id, maxTimeStamp, is_above_threshold, $scope.sliderSelectedValue, startDateTime, endDateTime, false, nMaxValueCounterId);
	resultModuleCountersChartdata.then(function(respGraph) {
		if( ! respGraph.success ) {
			// error msg
			messageService.showErrorMessage(respGraph.errorMessage);
		} else {
			
			//console.info('respGraph.message :'+JSON.stringify(respGraph.message));
			var joResp = respGraph.message;
			var joRespCountersChartData = joResp.chartdata;
			var joRespCountersException = joResp.countersException;
			var strRespAgentException = joResp.agentException || '';

			// To gets length of the JSON object
			var aryRespCounterIds = Object.keys(joRespCountersChartData);
			var nRespCounters = aryRespCounterIds.length;
			
    		// TODO: push

			for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
	    		var joCounterData = $scope.apmChartdata[i];
				
				joCounterData.maxTimeStamp = joResp['max_recieved_on'];
				joCounterData.serverCurrentTime = joResp['serverCurrentTime'];

				if($scope.selectedDetailsModule=="Applications") {
					joCounterData.moduleType = "APPLICATION";
				} else if ($scope.selectedDetailsModule=="Servers") {
					joCounterData.moduleType = "SERVER";
				} else if ($scope.selectedDetailsModule=="Databases") {
					joCounterData.moduleType = "DATABASE";
				}
				
				if( nRespCounters == 1 ) {
					var respCounterId = aryRespCounterIds[0];
					
					var nRespCounterSetsLength = 0;
					if ( joCounterData['counter_id'] == respCounterId) {
						var aryRespCounterChartData = joRespCountersChartData[respCounterId];
						
						var aryChartData = joCounterData['graphData'] || [];
						
						if ( aryChartData.length > 0 ) {
							
							if ( aryRespCounterChartData.length > 0 ) {
				        		/* DON'T delete, break counter sets, commented 
								// slice
								nRespCounterSetsLength = apmModulesFactory.getCounterSetsLength(aryRespCounterChartData);
								aryChartData = apmModulesFactory.sliceCounterSets(aryChartData, nRespCounterSetsLength);
								
								// push
								aryChartData = apmModulesFactory.pushCounterSets(aryChartData, aryRespCounterChartData);

				        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
								// commented, since tried in directive show hour interval in x-axis, instead of min/max
								//aryChartData = apmModulesFactory.appendZeroAtFirst(aryChartData);
								*/
								
								// based on new correction, Note: maxTS is not used, all response data is sets
								// 
								aryChartData = aryRespCounterChartData;
							}
						} else {
							aryChartData = aryRespCounterChartData;
						}

						joCounterData['graphData'] = aryChartData;
						
						// counter's reference `max_value_counter_id` of static counter data 
						if ( joResp.static_counter_data !== undefined ) {
							joCounterData['static_counter_data'] = joResp.static_counter_data;
						}
						
						break;
					}
				} else {
					// TODO: for multi counters response
					break;
				}
			}
    		
    		//console.info('joCounterSummary.graphData: '+JSON.stringify(joCounterSummary.graphData));
    		
			/*
			var jsonGraphObj = [];
			var data = respGraph.message.chartdata[joCounterSummary.counter_id];
    		data.forEach(function(d1) {
    			graphItem = {};
    			graphItem ["time"] = d1[0];
    			graphItem ["value"] = d1[1];
    	        jsonGraphObj.push(graphItem);
            });*/
		}
    });
};

// gets static counters data 
function getModuleStaticCountersData(guid, counterIds) {
	apmModulesService.getModuleStaticCountersData(guid, counterIds, function(resp) {
		if ( ! resp.success ) {
			// err
			messageService.showErrorMessage(resp.errorMessage);
		} else {
			var joResp = resp.message;
			var joRespStaticCountersData = joResp.chartdata;
			var joRespCountersException = joResp.countersException;
			
			// sets static counters resp data 
			for (var i = 0; i < $scope.asdStaticCountersData.length; i = i + 1) {
				var joStaticCounter = $scope.asdStaticCountersData[i];
				
				var aryStaticCounterData = joRespStaticCountersData[joStaticCounter['counter_id']] || [];
				joStaticCounter['graphData'] = aryStaticCounterData;
			}
		}
	});
}

// adds chart to dashboard
$scope.addChartToDashboard = function(){
	var counterDatas = this.counterData;
	var resultAddChartToDashboard;
	resultAddChartToDashboard = apmModulesService.addChartToDashboard($scope.selectedAppCardContent.guid,counterDatas.counter_id);
	resultAddChartToDashboard.then(function(resp) {
    	if(resp.success){
    		counterDatas.show_in_dashboard = true;
    	}
    	successMsgService.showSuccessOrErrorMsg(resp);
    });
};

// remove chart from dashboard
$scope.removeChartToDashboard = function(){
	var counterDatas = this.counterData;
	var resultRemoveChartToDashboard;
	resultRemoveChartToDashboard = apmModulesService.removeChartToDashboard($scope.selectedAppCardContent.guid,counterDatas.counter_id);
	resultRemoveChartToDashboard.then(function(resp) {
    	if(resp.success){
    		counterDatas.show_in_dashboard = false;
    	}
    	successMsgService.showSuccessOrErrorMsg(resp);
    });
};

// remove counter/chart from monitoring
$scope.removeCounterFromMonitor = function() {
	var counterData = this.counterData;
	
	var result = confirm("Are you sure to remove this metric from monitoring?");
	if(result == true) {
		var resultRemoveCounterFromMonitor = apmModulesService.removeCounterFromMonitor($scope.selectedAppCardContent.guid, counterData.counter_id);
		resultRemoveCounterFromMonitor.then(function(resp) {
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				// success
				messageService.showSuccessMessage(resp.message);
				
				// remove the repective counter from array of module's counters
				removeCounterFromMonitorCharts(counterData.counter_id);
			}
		});
	};
};



// remove the repective counter from array of module's counters
function removeCounterFromMonitorCharts(nCounterid) {
	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
		var joCounterData = $scope.apmChartdata[i];
		if ( joCounterData.counter_id === nCounterid ) {
			$scope.apmChartdata.splice(i, 1);
		}
	}
}




// gets expensive queries
// gets Profiler's MYSQL slow query data
function getProfilerSlowQueryData(){
	if( ($scope.asdDetails.startDateTime != '') && ($scope.asdDetails.endDateTime != '') ){
    	var resultSlowQuerydata = apmModulesService.getProfilerSlowQueryDataWithDateRange($scope.selectedAppCardContent.guid, $scope.asdDetails.startDateTime.getTime(), $scope.asdDetails.endDateTime.getTime(), $scope.selectedAppCardContent.type);
    	resultSlowQuerydata.then(function(resp) {
        	$scope.slowSQLQueryData = resp.message;
        });
	} else {
    	var resultSlowQuerydata = apmModulesService.getProfilerSlowQueryData($scope.selectedAppCardContent.guid, $scope.sliderSelectedValue, $scope.selectedAppCardContent.type);
    	resultSlowQuerydata.then(function(resp) {
        	$scope.slowSQLQueryData = resp.message;
        });
	}
}

// gets Database slow query data; (Note: Profiler & Database slow query is different)
function getDatabaseSlowQueryData(){
	if( ($scope.asdDetails.startDateTime != '') && ($scope.asdDetails.endDateTime != '') ){
    	var resultSlowQuerydata = apmModulesService.getDatabaseSlowQueryDataWithDateRange($scope.selectedAppCardContent.guid, $scope.asdDetails.startDateTime.getTime(), $scope.asdDetails.endDateTime.getTime(), $scope.selectedAppCardContent.type);
    	resultSlowQuerydata.then(function(resp) {
        	$scope.slowSQLQueryData = resp.message;
        });
	} else {
    	var resultSlowQuerydata = apmModulesService.getDatabaseSlowQueryData($scope.selectedAppCardContent.guid, $scope.sliderSelectedValue, $scope.selectedAppCardContent.type);
    	resultSlowQuerydata.then(function(resp) {
			$scope.slowSQLQueryData = resp.message;
        });
	}
}

function getSlowProcedureData(){
	var checkKey = ["MSSQL"]; 
	if(checkKey.indexOf($scope.selectedAppCardContent.type) >= 0) {
		if(($scope.asdDetails.startDateTime !='' ) && ($scope.asdDetails.endDateTime !='')){
			var resultSlowProceduredata = apmModulesService.getSlowProcedureDataWithDateRange($scope.selectedAppCardContent.guid, $scope.asdDetails.startDateTime.getTime(), $scope.asdDetails.endDateTime.getTime(), $scope.selectedAppCardContent.type);
	    	resultSlowProceduredata.then(function(resp) {
	    		if(resp.success){
		        	$scope.slowSQLProcedureData = resp.message;
	    		}else{
	    			$scope.slowSQLProcedureData = [];
	    		}
	        });
		}else{
	    	var resultSlowProceduredata = apmModulesService.getSlowProcedureData($scope.selectedAppCardContent.guid, $scope.sliderSelectedValue, $scope.selectedAppCardContent.type);
	    	resultSlowProceduredata.then(function(resp) {
	    		if(resp.success){
		        	$scope.slowSQLProcedureData = resp.message;
	    		}else{
	    			$scope.slowSQLProcedureData = [];
	    		}
	        });
		}
	}
}

// Profiler
$scope.loadProfilerDetails = function() {
	$scope.clearProfilerValue();
	$scope.getProfilerTransactions();
};

$scope.loadKeyProfilerDetails = function() {
	//$scope.clearKeyProfilerValue();
	$scope.clearProfilerValue();
	$scope.getKeyProfilerTransactions();
};

// 
$scope.getProfilerTransactions = function() {
	showProfilerTransactionLoading();
	
	if( $scope.asdDetails.startDateTime != '' && $scope.asdDetails.endDateTime != '' ){
		apmModulesService.getProfilerTransactionsWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedAppCardContent.type, $scope.asdDetails.startDateTime.getTime(), $scope.asdDetails.endDateTime.getTime(), function(data){
			hideProfilerTransactionLoading();
			
			if ( ! data.success ) {
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.profilerData.transactionsData = data.message;
			}
		});
	} else {
//		console.log("guid :"+ $scope.selectedAppCardContent.col_3.var2);
		apmModulesService.getProfilerTransactions($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.sliderSelectedValue, function(data){
			hideProfilerTransactionLoading();
			
			if ( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.profilerData.transactionsData = data.message;
			}
		});
	}
};

$scope.getKeyProfilerTransactions = function() {
	showProfilerTransactionLoading();
	
	if( $scope.asdDetails.startDateTime != '' && $scope.asdDetails.endDateTime != '' ){
		apmModulesService.getKeyProfilerTransactionsWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedAppCardContent.type, $scope.asdDetails.startDateTime.getTime(), $scope.asdDetails.endDateTime.getTime(), function(data){
			hideProfilerTransactionLoading();
			
			if ( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.profilerData.transactionsData = data.message;
			}
		});
	}else{
		apmModulesService.getKeyProfilerTransactions($scope.selectedAppCardContent.guid, $scope.selectedAppCardContent.type, $scope.sliderSelectedValue, function(data){
			hideProfilerTransactionLoading();
			
			if ( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.profilerData.transactionsData = data.message;
			}
		});
	}
};

$scope.getProfilerTransactionTimeTaken = function() {
	$scope.selectedTransaction = this.transaction;

	// clear methodes trace
	$scope.profilerPanel.showMethodTrace = false;
	$scope.profilerData.methodsTrace = [];
	
	$scope.profilerPanel.showTransactionTimeTaken = true;
	$scope.profilerData.transactionTimeTakenData = [];
	
	showProfilerTransTimeTakenGraphLoading();
	
	if( $scope.asdDetails.startDateTime != '' && $scope.asdDetails.endDateTime != '' ){
		apmModulesService.getProfilerTransactionTimeTakenWithDateRange($scope.selectedAppCardContent.guid, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, $scope.asdDetails.startDateTime.getTime(), $scope.asdDetails.endDateTime.getTime(), function(data){
			hideProfilerTransTimeTakenGraphLoading();
			
			if ( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var chartData = data.message;
				$scope.profilerData.transactionTimeTakenData = $appedoUtils.changeFormatToArrayInJSON(chartData);
			}
		});
	}else{
		apmModulesService.getProfilerTransactionTimeTaken(/*$scope.selectedAppCardContent.guid*/$scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, $scope.sliderSelectedValue, function(data){
			hideProfilerTransTimeTakenGraphLoading();
			
			if ( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var chartData = data.message;
				$scope.profilerData.transactionTimeTakenData = $appedoUtils.changeFormatToArrayInJSON(chartData);
			}
		});
	}
};

$scope.updateAPMProfilerKey = function(){
		var selectedTransaction = this.transaction;
		selectedTransaction.keyTransactionName = "";
		selectedTransaction.keyTransactionDescription = "";
		var modalInstance = $modal.open({
			templateUrl: 'modules/apm/add_profiler_key.html',
			controller: 'apmProfilerKeyController',
			size: 'lg',
			resolve: {
				transaction: function() {
					return selectedTransaction;
				}
			}
		});
};

$scope.getProfilerMethodTrace = function(time, duration) {
	// clear methodes trace
	$scope.clearMethodsTrace();
	$scope.selectedTransactionTime = {time: time, duration: duration};
	
	$scope.profilerPanel.showMethodTrace = true;
	
	// gets time taken methods
	$scope.getProfilerTimeTakenMethods(time, duration);
	
	// gets profiler methods stack trace
	$scope.getProfilerMethodStackTrace(time, duration);
};

// gets profiler stack trace
$scope.getProfilerMethodStackTrace = function(time, duration) {
	// since time taken methods shown, commented loading for stackTrace
	//$scope.profilerPanel.showMethodTraceLoading = true;
	showProfilerMethodTraceLoading();
	
	apmModulesService.getProfilerMethodTrace($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, time, duration, function(data){
		hideProfilerMethodTraceLoading();
		
		if ( ! data.success ) {
			// err 
			messageService.showErrorMessage(data.errorMessage);
		} else {
			var aryMethodsTrace = data.message, aryRtnLimitedMethodsTrace = [];
			// since time taken methods shown, commented loading for stackTrace
			//$scope.profilerPanel.showMethodTraceLoading = false;
			
			// tried, angular.copy used to disconnect obj. by ref
			$scope.profilerData.allMethodsTrace = angular.copy(aryMethodsTrace);
			
			/* limited methods stack trace is not shown
			// to show limited method stacktrace 
			aryRtnLimitedMethodsTrace = apmModulesFactory.limitMethodsTrace(aryMethodsTrace, sessionServices.get('methodsTraceLimit'));
			$scope.profilerData.isLimitedMethods = aryRtnLimitedMethodsTrace[0];
			$scope.profilerData.methodsTrace = aryRtnLimitedMethodsTrace[1];
			*/
		}
	});
};

// gets time taken methods
$scope.getProfilerTimeTakenMethods = function(time, duration) {
	showProfilerTransMostTimeTakenMethodsLoading();
	
	apmModulesService.getProfilerTimeTakenMethods($scope.selectedAppCardContent.col_3.var2, $scope.selectedAppCardContent.type, $scope.selectedTransaction.localhost_name_ip, $scope.selectedTransaction.transactionType, $scope.selectedTransaction.transactionName, time, duration, function(data){
		hideProfilerTransMostTimeTakenMethodsLoading();
		
		if ( ! data.success ) {
			// err 
			messageService.showErrorMessage(data.errorMessage);
		} else {
			var aryTimetakenMethods = data.message;
			$scope.profilerPanel.showMethodTraceLoading = false;
			
			// 
			$scope.profilerData.timeTakenMethods = aryTimetakenMethods;
		}
	});
};

$scope.openMoreMethodsTrace = function() {
	var modalInstance = $modal.open({
		templateUrl: 'modules/apm/more_methods_trace.html',
		controller: 'methodsTraceDetailsController',
		size: 'lg',
		resolve: {
			methodsTrace: function() {
				return $scope.profilerData.allMethodsTrace;
				//return $scope.profilerData.methodsTrace;
			},
			transaction: function() {
				return $scope.selectedTransaction;
			},
			transactionTime : function() {
				return $scope.selectedTransactionTime;
			}
		}
	});
	
};

$scope.clearProfilerValue = function() {
	$scope.profilerData.transactionsData = [];
	
	$scope.profilerPanel.showTransactionTimeTaken = false;
	$scope.profilerData.transactionTimeTakenData = [];
	
	// clear methodes trace
	$scope.clearMethodsTrace();
};

$scope.clearMethodsTrace = function() {
	// clear methodes trace
	$scope.profilerPanel.showMethodTrace = false;
	$scope.profilerPanel.showMethodTraceLoading = false;
	$scope.profilerData.isLimitedMethods = false;
	$scope.profilerData.methodsTrace = [];
	$scope.profilerData.allMethodsTrace = [];
	$scope.profilerData.timeTakenMethods = [];
};

function showProfilerTransactionLoading() {
	$scope.profilerPanel.showTransactionLoading = true;
}
function hideProfilerTransactionLoading() {
	$scope.profilerPanel.showTransactionLoading = false;
}
function showProfilerTransTimeTakenGraphLoading() {
	$scope.profilerPanel.showTransTimeTakenGraphLoading = true;
}
function hideProfilerTransTimeTakenGraphLoading() {
	$scope.profilerPanel.showTransTimeTakenGraphLoading = false;
}
function showProfilerTransMostTimeTakenMethodsLoading() {
	$scope.profilerPanel.showTransMostTimeTakenMethodsLoading = true;
}
function hideProfilerTransMostTimeTakenMethodsLoading() {
	$scope.profilerPanel.showTransMostTimeTakenMethodsLoading = false;
}
function showProfilerMethodTraceLoading() {
	$scope.profilerPanel.showMethodTraceLoading = true;
}
function hideProfilerMethodTraceLoading() {
	$scope.profilerPanel.showMethodTraceLoading = false;
}


/*
$scope.clearKeyProfilerValue = function() {
	$scope.profilerData.transactionsData = [];
	
	$scope.profilerPanel.showTransactionTimeTaken = false;
	$scope.profilerData.transactionTimeTakenData = [];
	
	// clear methodes trace
	$scope.profilerPanel.showMethodTrace = false;
	$scope.profilerData.isLimitedMethods = false;
	$scope.profilerData.methodsTrace = [];
	$scope.profilerData.allMethodsTrace = [];
};*/

// clears timer
function clearTimer() {
	clearTimeout(timerChartsLoading);
}

$scope.openTopProcess = function(selectedTime, counter_id, category) {
	var resultTopProcess = apmModulesService.getTopProcess($scope.selectedAppCardContent.uid, counter_id, category, $scope.sliderSelectedValue, selectedTime);
	resultTopProcess.then(function(resp) {
		if(resp.success){
			if(resp.message.topProcessDetails.length>0){
				var modalInstance = $modal.open({
					templateUrl: 'modules/apm/top_process.html',
					controller: 'top_process_controller',
					size: 'lg',
					backdrop : 'static',
					resolve: {
						selectedAppCardContent: function() {
							return $scope.selectedAppCardContent;
						},
						selectedTime:function() {
							return selectedTime;
						},
						topProcessContent :  function() {
							return resp.message;
						},
						category :  function() {
							return category;
						}
					}
				});
			}
		}
	});
};

$scope.getASDDetailsChartWithDateRange = function() {
	var selectedDateCheck=false;
	var startHourCheck=false;
	var startMinsCheck=false;
	var endHourCheck=false;
	var endMinsCheck=false;
	
	if( $scope.asdDetails.startHour == null || $scope.asdDetails.startHour.length == 0 || parseInt($scope.asdDetails.startHour) > 23 ){
		$scope.asdDetails.startDateTime = '';
		$scope.asdDetails.endDateTime = '';
		
		messageService.showWarningMessage('Start Hour should not be either empty or greater than 23');
	} else {
		startHourCheck = true;
	}

	if( $scope.asdDetails.startMins == null || $scope.asdDetails.startMins.length == 0 || parseInt($scope.asdDetails.startMins) > 59 ){
		$scope.asdDetails.startDateTime = '';
		$scope.asdDetails.endDateTime = '';
		
		messageService.showWarningMessage('Start Mins should not be either empty or greater than 59');
	} else {
		startMinsCheck = true;
	}

	if( $scope.asdDetails.endHour == null || $scope.asdDetails.endHour.length == 0 || parseInt($scope.asdDetails.endHour) > 23 ){
		$scope.asdDetails.startDateTime = '';
		$scope.asdDetails.endDateTime = '';
		
		messageService.showWarningMessage('End Hour should not be either empty or greater than 23');
	} else {
		endHourCheck = true;
	}

	if( $scope.asdDetails.endMins == null || $scope.asdDetails.endMins.length == 0 || parseInt($scope.asdDetails.endMins) > 59 ){
		$scope.asdDetails.startDateTime = '';
		$scope.asdDetails.endDateTime = '';
		
		messageService.showWarningMessage('End Mins should not be either empty or greater than 59');
	} else {
		endMinsCheck = true;
	}
	
	if( $scope.asdDetails.startDate == '' || $scope.asdDetails.endDate == '' ){
		$scope.asdDetails.startDateTime = '';
		$scope.asdDetails.endDateTime = '';
		
		messageService.showWarningMessage('Please select start date & end date');
	} else {
		selectedDateCheck = true;
	}

	if((selectedDateCheck == true ) && (startHourCheck == true ) && (startMinsCheck == true ) && (endHourCheck == true ) && (endMinsCheck == true ) ){
		$scope.asdDetails.startDateTime = $scope.asdDetails.startDate;
		$scope.asdDetails.startDateTime.setHours($scope.asdDetails.startHour);
		$scope.asdDetails.startDateTime.setMinutes($scope.asdDetails.startMins);
		
		$scope.asdDetails.endDateTime = $scope.asdDetails.endDate;
		$scope.asdDetails.endDateTime.setHours($scope.asdDetails.endHour);
		$scope.asdDetails.endDateTime.setMinutes($scope.asdDetails.endMins);
		
		if( $scope.asdDetails.startDateTime <= $scope.asdDetails.endDateTime ){
			//$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[0];
			
			var nStartDateTimeInMs = $scope.asdDetails.startDateTime.getTime();
		    var nEndDateTimeInMs = $scope.asdDetails.endDateTime.getTime();
		    
		    /*
			if(checkSelectedDurationLessThanGivenHour(1, (endDateinMs - startDateinMs))){ //1 hour
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[0];
			}else if(checkSelectedDurationLessThanGivenHour(24,(endDateinMs - startDateinMs))){ //24 hour
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[1];
			}else if(checkSelectedDurationLessThanGivenHour(168,(endDateinMs - startDateinMs))){ //7 days
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[2];
			}else if(checkSelectedDurationLessThanGivenHour(360,(endDateinMs - startDateinMs))){ //15 days
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[3];
			}else if(checkSelectedDurationLessThanGivenHour(720,(endDateinMs - startDateinMs))){ //30 days
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[4];
			}else if(checkSelectedDurationLessThanGivenHour(1440,(endDateinMs - startDateinMs))){ //60 days
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[5];
			}else{ //  >= 120 days
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[6];
			}*/
			
		    // PDF x-axis format, (Note: In aryPDFFormats `aryD3ChartTimeFormatForASDPdf` has more same formats used needed)
			if ( appedoDirectiveChartUtils.isDateTimeWithInOneDay(nStartDateTimeInMs, nEndDateTimeInMs) ) {
				// PDF x-axis format, interval with in one day
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[0];
			} else {
				// PDF x-axis format, interval > one day
				$scope.d3ChartTimeFormatForASDPdf = aryD3ChartTimeFormatForASDPdf[2];
			}
			
			loadSelectedDetails();
		} else {
			messageService.showWarningMessage('End datetime should be greater than or equal to start datetime');
		}
	}
};

function checkSelectedDurationLessThanGivenHour(hour,runTime){
	return (1000 * 60 * 60 * Number(hour)) > Number(runTime) ? true : false;
}


$scope.onlyDigits = function() {
	if( $scope.asdDetails.startHour != undefined){
		$scope.asdDetails.startHour = $scope.asdDetails.startHour.replace(/[^0-9]/g, '');
		console.info('$scope.asdDetails.startHour: '+$scope.asdDetails.startHour);
	}
};

$scope.$on('$destroy', function() {
	clearTimer();
});
}]);

appedoApp.controller('adminController', ['$scope', 'sessionServices', 'messageService', 'userMetrics', 'licenseServices', 'successMsgService', '$uibModal', '$rootScope', function($scope, sessionServices, messageService, userMetrics, licenseServices, successMsgService, $uibModal, $rootScope) {
	
	$scope.userAccessPrivilege = {};
    $scope.admin = {};
    $scope.manage = {};
    $scope.manage.months = {};
    $scope.userAccessPrivilege.selectedAdmintask = "license";
    $scope.admin.selectedLicenseType = "manage";
    $scope.manage.licenseCategory = "newLicense";
    $scope.showLicensedetails = true;
    $scope.manage.selectedPlanType = "level0";
    $scope.showAccRightsdetails = false;
    $scope.showReportsdetails = false;
    $scope.showSettingsdetails = false;
    $scope.manage.selectedPeriod = "Monthly";
    $scope.noLicense = true;
    $scope.disableDaily = false;
	$scope.disableMonthly = false;
	$scope.disableAnnual = false;
	$scope.disablelevel0 = false;
	$scope.disablelevel1 = false;
	$scope.disablelevel2 = false;
	$scope.disablelevel3 = false;
	
    $scope.loginUser = JSON.parse(sessionServices.get('loginUser'));
	
    $scope.licensingEmail = [];

    //clear chart tooltip
	if (document.querySelector('.apd-chart-tooltip') != null) {
		console.info("chart tooltip clear");
    	//d3.select("#tooltip"+attrs.idx).remove();
		$('.apd-chart-tooltip').remove();
    }

    $scope.moduleType = "SUM";
    $scope.openAddModuleType = function () {
		console.info("inside openaddmodule");
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			//backdrop : 'static'
			resolve: {
				moduleType: function() {
					return $scope.moduleType;
				}
			}
		});
	};
    
    var emails;
    emails = licenseServices.getLicesingEmails();
    emails.then(function(data) {
        $scope.licensingEmail = data.message;
        if(!$scope.loginUser.viewAllUsers){
        	$scope.manage.email = $scope.licensingEmail[0];
        	//$scope.selectedUserDetails();
        	$scope.selectedUserLicenseHistory();
        }
    });

    var timer;
    $scope.getUserMetrics = function() {
        clearTimeout(timer);

        $scope.signup = {};
        var signUps;
        signUps = userMetrics.getUsageMetrics('signup');
        signUps.then(function(resp) {
            if (resp.success) {
            	$scope.signup.lable1 = resp.message.label_name1;
                $scope.signup.value1 = resp.message.label_value1;
            	$scope.signup.lable2 = resp.message.label_name2;
                $scope.signup.value2 = resp.message.label_value2;
                $scope.signup.lable3 = resp.message.label_name3;
                $scope.signup.value3 = resp.message.label_value3;
                $scope.signup.lable4 = resp.message.label_name4;
                $scope.signup.value4 = resp.message.label_value4;
            }
        });
        
        $scope.loggedin = {};
        var lid;
        lid = userMetrics.getUsageMetrics('loggedin');
        lid.then(function(resp) {
            if (resp.success) {
            	$scope.loggedin.lable1 = resp.message.label_name1;
                $scope.loggedin.value1 = resp.message.label_value1;
            	$scope.loggedin.lable2 = resp.message.label_name2;
                $scope.loggedin.value2 = resp.message.label_value2;
                $scope.loggedin.lable3 = resp.message.label_name3;
                $scope.loggedin.value3 = resp.message.label_value3;
                $scope.loggedin.lable4 = resp.message.label_name4;
                $scope.loggedin.value4 = resp.message.label_value4;
            }
        });
        
        $scope.lt = {};
        var lid;
        lid = userMetrics.getUsageMetrics('lt');
        lid.then(function(resp) {
            if (resp.success) {
            	$scope.lt.lable1 = resp.message.label_name1;
                $scope.lt.value1 = resp.message.label_value1;
            	$scope.lt.lable2 = resp.message.label_name2;
                $scope.lt.value2 = resp.message.label_value2;
                $scope.lt.lable3 = resp.message.label_name3;
                $scope.lt.value3 = resp.message.label_value3;
                $scope.lt.lable4 = resp.message.label_name4;
                $scope.lt.value4 = resp.message.label_value4;
            }
        });
        
        $scope.sla = {};
        var slaBreaches;
        slaBreaches = userMetrics.getUsageMetrics('sla');
        slaBreaches.then(function(resp) {
            if (resp.success) {
            	$scope.sla.lable1 = resp.message.label_name1;
                $scope.sla.value1 = resp.message.label_value1;
            	$scope.sla.lable2 = resp.message.label_name2;
                $scope.sla.value2 = resp.message.label_value2;
                $scope.sla.lable3 = resp.message.label_name3;
                $scope.sla.value3 = resp.message.label_value3;
                $scope.sla.lable4 = resp.message.label_name4;
                $scope.sla.value4 = resp.message.label_value4;
            }
        });
        
        $scope.agents = {};
        var maa;
        maa = userMetrics.getUsageMetrics('agents');
        maa.then(function(resp) {
            if (resp.success) {
            	$scope.agents.lable1 = resp.message.label_name1;
                $scope.agents.value1 = resp.message.label_value1;
            	$scope.agents.lable2 = resp.message.label_name2;
                $scope.agents.value2 = resp.message.label_value2;
                $scope.agents.lable3 = resp.message.label_name3;
                $scope.agents.value3 = resp.message.label_value3;
                $scope.agents.lable4 = resp.message.label_name4;
                $scope.agents.value4 = resp.message.label_value4;
            }
        });
        
        $scope.application = {};
        var app;
        app = userMetrics.getUsageMetrics('app');
        app.then(function(resp) {
            if (resp.success) {
            	$scope.application.lable1 = resp.message.label_name1;
                $scope.application.value1 = resp.message.label_value1;
            	$scope.application.lable2 = resp.message.label_name2;
                $scope.application.value2 = resp.message.label_value2;
                $scope.application.lable3 = resp.message.label_name3;
                $scope.application.value3 = resp.message.label_value3;
                $scope.application.lable4 = resp.message.label_name4;
                $scope.application.value4 = resp.message.label_value4;
            }
        });
        
        $scope.server = {};
        var svr;
        svr = userMetrics.getUsageMetrics('svr');
        svr.then(function(resp) {
            if (resp.success) {
            	$scope.server.lable1 = resp.message.label_name1;
                $scope.server.value1 = resp.message.label_value1;
            	$scope.server.lable2 = resp.message.label_name2;
                $scope.server.value2 = resp.message.label_value2;
                $scope.server.lable3 = resp.message.label_name3;
                $scope.server.value3 = resp.message.label_value3;
                $scope.server.lable4 = resp.message.label_name4;
                $scope.server.value4 = resp.message.label_value4;
            }
        });
        
        $scope.database = {};
        var db;
        db = userMetrics.getUsageMetrics('db');
        db.then(function(resp) {
            if (resp.success) {
            	$scope.database.lable1 = resp.message.label_name1;
                $scope.database.value1 = resp.message.label_value1;
            	$scope.database.lable2 = resp.message.label_name2;
                $scope.database.value2 = resp.message.label_value2;
                $scope.database.lable3 = resp.message.label_name3;
                $scope.database.value3 = resp.message.label_value3;
                $scope.database.lable4 = resp.message.label_name4;
                $scope.database.value4 = resp.message.label_value4;
            }
        });
        
        $scope.sum = {};
        var sumTest;
        sumTest = userMetrics.getUsageMetrics('sumtest');
        sumTest.then(function(resp) {
            if (resp.success) {
            	$scope.sum.lable2 = resp.message.label_name2;
                $scope.sum.value2 = resp.message.label_value2;
                $scope.sum.lable3 = resp.message.label_name3;
                $scope.sum.value3 = resp.message.label_value3;
                $scope.sum.lable4 = resp.message.label_name4;
                $scope.sum.value4 = resp.message.label_value4;
            }
        });
        
        $scope.sumnode = {};
        var sumNode;
        sumNode = userMetrics.getUsageMetrics('sumnode');
        sumNode.then(function(resp) {
            if (resp.success) {
            	$scope.sumnode.lable1 = resp.message.label_name1;
                $scope.sumnode.value1 = resp.message.label_value1;
            	$scope.sumnode.lable2 = resp.message.label_name2;
                $scope.sumnode.value2 = resp.message.label_value2;
                $scope.sumnode.lable3 = resp.message.label_name3;
                $scope.sumnode.value3 = resp.message.label_value3;
                $scope.sumnode.lable4 = resp.message.label_name4;
                $scope.sumnode.value4 = resp.message.label_value4;
            }
        });
        
        $scope.summst = {};
        var sumMeasurement;
        sumMeasurement = userMetrics.getUsageMetrics('summst');
        sumMeasurement.then(function(resp) {
            if (resp.success) {
            	$scope.summst.lable1 = resp.message.label_name1;
                $scope.summst.value1 = resp.message.label_value1;
            	$scope.summst.lable2 = resp.message.label_name2;
                $scope.summst.value2 = resp.message.label_value2;
                $scope.summst.lable3 = resp.message.label_name3;
                $scope.summst.value3 = resp.message.label_value3;
                $scope.summst.lable4 = resp.message.label_name4;
                $scope.summst.value4 = resp.message.label_value4;
            }
        });
        
		$scope.rummst = {};
		var rumMeasurement;
		rumMeasurement = userMetrics.getUsageMetrics('rummst');
		rumMeasurement.then(function(resp) {
		    if (resp.success) {
		    	$scope.rummst.lable1 = resp.message.label_name1;
		        $scope.rummst.value1 = resp.message.label_value1;
		    	$scope.rummst.lable2 = resp.message.label_name2;
		        $scope.rummst.value2 = resp.message.label_value2;
		        $scope.rummst.lable3 = resp.message.label_name3;
		        $scope.rummst.value3 = resp.message.label_value3;
		        $scope.rummst.lable4 = resp.message.label_name4;
		        $scope.rummst.value4 = resp.message.label_value4;
		    }
		});
        timer = setTimeout($scope.getUserMetrics, sessionServices.get("textRefresh"));
    };

    $scope.loadAdminDetails = function() {
        if ($scope.userAccessPrivilege.selectedAdmintask == "license") {
            $scope.showLicensedetails = true;
            $scope.showUsagemetricsDetails = false;
            $scope.admin.selectedLicenseType = "manage";
        } else {
            $scope.showUsagemetricsDetails = true;
            $scope.showLicensedetails = false;
            $scope.showAccRightsdetails = false;
            $scope.showReportsdetails = false;
            $scope.showSettingsdetails = false;
            $scope.getUserMetrics();
        }
    };
    
    $scope.showNewLicense = true;
    $scope.height = 0;
    $scope.selectedUserLicenseHistory = function() {
    	$scope.showTopUpButton = false;
    	$scope.pricingData = [];
    	$scope.currentLicense = '';
    	$scope.expiresOn = '';
    	$scope.showLoading = true;
    	licenseServices.getLicesenseDetails($scope, $scope.manage.email.email_id, function(data){
    		$scope.selectedRow = null; 
    		$scope.licenseHistory = data.message.license_history;
    		$scope.showLoading = false;
    		if($scope.licenseHistory.length > 0){
    			$scope.showNewLicense = false;
    			$scope.height = 200;
    			for( var i = 0; i < $scope.licenseHistory.length; i++){
    				if($scope.licenseHistory[i].active_lic == true){
    					$scope.currentLicense = $scope.licenseHistory[i].lic_type;
    				}
    			}
    			var lastLicense = $scope.licenseHistory[0];
    			if( new Date(lastLicense.end_date) >= new Date() ) {
	        		$scope.expiresOn = new Date(lastLicense.end_date);
    			} else {
	        		$scope.currentLicense = 'level0';
	        		$scope.expiresOn = 'Unlimited';
    			}
    		}else {
    			$scope.showNewLicense = true;
    			$scope.height = 0;
				
        		$scope.currentLicense = 'level0';
        		$scope.expiresOn = 'Unlimited';
    		}
    	});
    };
	
    $scope.selectedUserDetails = function() {
    	$scope.clearPaymentDetails();
    	$scope.selectedUserLicenseHistory();
    };
	
    var licenseHistoryLoad = $rootScope.$on("loadLicenseHistory", $scope.selectedUserLicenseHistory);
	$rootScope.$on('$destroy', licenseHistoryLoad);
    
    $scope.topupAlertMsg = "Top-Up is applicable for the below parameters only: \n  Load Test Runs per Day, SUM PageViews";
    //New UI changes - Grid row selection
    // initialize our variable to null
    $scope.setClickedRow = function(index){  //function that sets the value of selectedRow to current index
       $scope.selectedRow = index;
       $scope.populateLicenseValues(this.license);
    };
    
    $scope.populateLicenseValues = function(licenseData) {
        $scope.pricingData = [];
        $scope.licData = licenseData;
        $scope.showTopUpButton = true;
        $scope.disableEdit = false;
        $scope.disableTopUp = false;
        if(licenseData.lic_category == 'Top-Up') {
        	$scope.disableEdit = true;
        }
        
        if(licenseData.is_expired == true) {
        	$scope.disableTopUp = true;
        	$scope.disableEdit = true;
        }

        $scope.manage.selectedPlanType = licenseData.lic_type;
        //populating data to grid

        $scope.pricingDetails = function() {
            var commonData = {};
            $scope.pricings = licenseData.pricings;
            //var licensePrice = $scope.pricings[$scope.pricings.length - 1];
            if ($scope.pricings) {
                for (var i = 0; i < $scope.pricings.length; i++) {
                    $scope.pricingData.push($scope.pricings[i]);
                };
            }
            commonData = licenseServices.getPricingCommonDetails($scope);
            commonData.then(function(data) {
                angular.forEach(data.data, function(commonData) {
                	commonData.value = commonData[licenseData.lic_type];
                	$scope.pricingData.push(commonData);
                });
                //$scope.pricingData.push(licensePrice);
            });
        };
        $scope.pricingDetails();
    };
    
    //New UI changes - License pop up
    $scope.openLicensePage = function(licenseCategory) {
    	$scope.clearPaymentDetails();
    	var is_valid = true;
    	var msg = '';
    	if(licenseCategory == 'New License' && ($scope.manage.email == '' || $scope.manage.email==undefined)) {
    		is_valid = false;
    		msg = "Please select emailId.";
    	} else if($scope.selectedRow == null && licenseCategory == 'Top-Up') {
    		is_valid = false;
    		msg = "Please select one row from grid.";
    	} else if($scope.selectedRow == null && licenseCategory == 'Renewal') {
    		is_valid = true;
    	} 
    	if(is_valid) {
			var licenseData = $scope.licData; 
	    	var modalInstance = $uibModal.open({
					templateUrl: 'common/views/accounts/admin_license_update_details.html',
					controller: 'licenseUpdateController',
					size: 'lg',
					backdrop : 'static',
					resolve: {
						licenseCategory: function() {
							return licenseCategory;
						},
						licenseData: function() {
							return licenseData;
						},
						emailId: function() {
							return $scope.manage.email.email_id;
						},
						pricingData: function() {
							return $scope.pricingData;
						},
						licenseHistory: function() {
							return $scope.licenseHistory;
						}, 
						selectedRow: function() {
							return $scope.selectedRow;
						}
					}
			});
    	} else {
    		messageService.showWarningMessage(msg);
    		/*ngToast.create({
					className: 'warning',
					content: msg,
					timeout: 3000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
			});*/
    	}
    };
    
    $scope.loadLiceseDetails = function() {
        if ($scope.admin.selectedLicenseType == 'manage') {
            $scope.showLicensedetails = true;
            $scope.showAccRightsdetails = false;
            $scope.showReportsdetails = false;
            $scope.showSettingsdetails = false;
        } else if ($scope.admin.selectedLicenseType == 'accRights') {
            $scope.showAccRightsdetails = true;
            $scope.showLicensedetails = false;
            $scope.showReportsdetails = false;
            $scope.showSettingsdetails = false;
        } else if ($scope.admin.selectedLicenseType == 'reports') {
            $scope.showReportsdetails = true;
            $scope.showLicensedetails = false;
            $scope.showAccRightsdetails = false;
            $scope.showSettingsdetails = false;
        } else if ($scope.admin.selectedLicenseType == 'settings') {
            $scope.showSettingsdetails = true;
            $scope.showLicensedetails = false;
            $scope.showAccRightsdetails = false;
            $scope.showReportsdetails = false;
        }
    };
    $scope.clearPaymentDetails = function(){
    	$rootScope.payment_mode = '';
    	$rootScope.payment_status = '';
    	$rootScope.payment_errorMeassage = '';
	};

    $scope.$on('$destroy', function() {
        clearTimeout(timer);
        $scope.clearPaymentDetails();
    });
}]);

appedoApp.controller('licenseUpdateController', ['$scope', '$uibModal', 'sessionServices', 'licenseServices', 'forDateTimeModuleMethod',  'successMsgService', 'messageService', 'licenseCategory', '$uibModalInstance', 'licenseData', 'emailId', 'pricingData', 'licenseHistory', 'selectedRow', '$rootScope', 'ngToast',
     function($scope, $uibModal, sessionServices, licenseServices, forDateTimeModuleMethod, successMsgService, messageService, licenseCategory, $uibModalInstance, licenseData, emailId, pricingData, licenseHistory, selectedRow, $rootScope, ngToast) {
 	    $scope.loginUser = JSON.parse(sessionServices.get('loginUser'));
         $scope.licenseCategory = licenseCategory;
         $scope.disableAnnualSelect = true;
         //$scope.pricingData = pricingData;
         $scope.manage = {};
         $scope.paypal_Gateway_url= "";
         $scope.paypal_Business_Id = "";
         $scope.paypal_Return_URL = "";
         $scope.paypal_Cancel_Return_URL = "";
         $scope.licMessage = "";
         $scope.showlicMessage = true;
         $scope.manage.selectedPlanType;
         $scope.manage.selectedPeriod;
         $scope.manage.licensePaymentAmount;
         if(licenseData && $scope.licenseCategory == 'Update') {
         	$scope.manage.selectedPlanType = licenseData.lic_type;
             $scope.manage.selectedPeriod = licenseData.lic_period;
         }
         $scope.testCITrigger = function(module, action) {
     		Appedo_CI.triggerEvent(module, action, 
     		{
     			page_open_date_time : new Date()
     		});
     	};
     	
     	licenseServices.getGatewayDetails($scope, function(data) {
         if (data.success == true) {
         	$scope.paypal_Gateway_url = data.message.Paypal_URL;
         	$scope.paypal_Business_Id = data.message.Paypal_Business_Email_id;
         	$scope.paypal_Return_URL = data.message.Paypal_Return_URL+"/paymentGatewayResult/paypal";
         	$scope.paypal_Cancel_Return_URL = data.message.Paypal_Return_URL+"/paymentGatewayResult/paypalCancel";
         }
         //successMsgService.showSuccessOrErrorMsg(data);
     	}, 
     	function(data){
     		if( data.status == 499 ) {
     			successMsgService.showSuccessOrErrorMsg("Unable to get Payment-Gateway details,<br/>as your AntiVirus is blocking our request.");
     		}else{
     			successMsgService.showSuccessOrErrorMsg("Unable to get Payment-Gateway details.");
     		}	
     	});

         $scope.close = function() {
        	 $uibModalInstance.dismiss('cancel');
         };
         
         //$scope.licenseCategoryName = $scope.licenseCategory;
         $scope.licenseCategoryName = "License/subscription";

         if ($scope.licenseCategory == 'Top-Up' || $scope.licenseCategory == 'Update') {
             $scope.disableAnnualSelect = false;
         }

         $scope.curdate;
         $scope.today = function() {
             months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
             currentDate = new Date();
             $scope.curdate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
         };
         $scope.today();
 		$scope.hideDatePicker = false;
 		$scope.showLicDay = true;
 		$scope.showLicMonth = true;
 		forDateTimeModuleMethod.setMethod("fromLicUpgrade");
         if ($scope.licenseCategory == 'New License' || ($scope.licenseCategory == 'Renewal' && selectedRow != null)) {
             //$scope.manage.selectedPlanType = 'level1';
             //$scope.manage.selectedPeriod = 'Monthly';
             //$scope.manage.startdate = $scope.curdate;

         	if(licenseHistory.length > 0){
         		var expiredDate = licenseHistory[0].end_date;
         		var finalvalue = getNowIfExpired(expiredDate);
              	$scope.manage.startdate = finalvalue; 
              	forDateTimeModuleMethod.setStDate(new Date($scope.manage.startdate));
         	} else {
             	$scope.manage.startdate = $scope.curdate;
             	forDateTimeModuleMethod.setStDate(new Date($scope.manage.startdate));
             	//Licensemessage
             	$scope.licMessage = "";
             	$scope.showlicMessage = false;
         	}
         	
             $scope.licenseHeading = "Upgrade";

             var stDate = $scope.manage.startdate;
             if (isdate(stDate) == 1) {
                 stDate = convertDate(stDate);
             } else {
                 stDate = new Date(stDate.toString());
             }
             var enDate = stDate;
             enDate.setMonth(stDate.getMonth() + 1);
             enDate.setDate(stDate.getDate() - 1);
             $scope.manage.enddate = formateDate(enDate);
             forDateTimeModuleMethod.setEndDate(new Date($scope.manage.enddate));
             $scope.stDateLimit = convertDate($scope.manage.startdate);
           	$scope.enDateLimit = '';
           	$scope.manage.lic_schedule_id = null;
         } else if ($scope.licenseCategory == 'Renewal' && selectedRow == null) {
             var endDate = licenseHistory[0].end_date;
             var startDate = getNowIfExpired(endDate);
             $scope.manage.startdate = startDate;
             forDateTimeModuleMethod.setStDate(new Date($scope.manage.startdate));

             //$scope.manage.selectedPlanType = 'level1';
             //$scope.manage.selectedPeriod = 'Monthly';
             $scope.licenseHeading = "Upgrade";
             var stDate = $scope.manage.startdate;
             if (isdate(stDate) == 1) {
                 stDate = convertDate(stDate);
             } else {
                 stDate = new Date(stDate.toString());
             }
             var enDate = stDate;
             enDate.setMonth(stDate.getMonth() + 1);
             enDate.setDate(stDate.getDate() - 1);
             $scope.manage.enddate = formateDate(enDate);
             forDateTimeModuleMethod.setEndDate(new Date($scope.manage.enddate));
             $scope.stDateLimit = convertDate($scope.manage.startdate);
           	$scope.enDateLimit = '';
         } else {
             //$scope.manage.selectedPlanType = licenseData.lic_type;
         	$scope.licenseType =  licenseData.lic_type;
             $scope.manage.selectedPeriod = licenseData.lic_period == undefined ? "Monthly" : licenseData.lic_period;
             var endDate = licenseData.end_date.split('T');
             endDate = endDate[0];
             $scope.manage.startdate = (formateDate(new Date(licenseData.start_date)));
             $scope.manage.enddate = (formateDate(new Date(endDate)));
             
             forDateTimeModuleMethod.setStDate(new Date($scope.manage.startdate));
             forDateTimeModuleMethod.setEndDate(new Date($scope.manage.enddate));
             /*if(licenseData.lic_category != 'Top-Up' && $scope.licenseCategory == 'Top-Up'){
             	$scope.manage.lic_schedule_id = null;
             } else {
             	$scope.manage.lic_schedule_id = licenseData.lic_schedule_id;
             }*/
             if(licenseData.lic_category == 'Top-Up' && $scope.licenseCategory == 'Top-Up'){
             	$scope.hideDatePicker = true;
             	if(licenseData.lic_period == 'Monthly') {
             		$scope.showLicDay = false;
             		$scope.showLicMonth = true;
             	} else if(licenseData.lic_period == 'Daily') {
             		$scope.showLicDay = true;
             		$scope.showLicMonth = false;
             	}
             	$scope.licenseCategory = 'Top-Up';
             } else if(licenseData.lic_category != 'Top-Up' && $scope.licenseCategory == 'Top-Up' && $scope.manage.selectedPeriod == 'Monthly'){
             	$scope.hideDatePicker = true;
             } else if(licenseData.lic_category != 'Top-Up' && $scope.licenseCategory == 'Top-Up'){
             	$scope.manage.lic_schedule_id = null;
             } else {
             	$scope.hideDatePicker = false;
             	$scope.manage.lic_schedule_id = licenseData.lic_schedule_id;
             }
             $scope.stDateLimit = convertDate($scope.manage.startdate);
             if ($scope.licenseCategory == 'Update') {
             	$scope.stDateLimit = convertDate($scope.curdate);
             	$scope.licenseCategoryName = "License/subscription";
             }
             
           	$scope.enDateLimit = '';
           	$scope.licenseHeading = "Update";
         }
         $scope.setLiceseEndDate = function() {
             validateEndDate();
         };

         $scope.pricingData = [];
         $scope.pricingFeature = [];
         $scope.licenseAmounts = [];
         $scope.commonDatas = [];
         
         $scope.selectPricingDetails = function(){
         	if($scope.licenseCategory == 'Top-Up') {
         		$scope.licenseAmounts.splice(1, 1);
         	}
         	for(var i = 0; i < $scope.pricingFeature.length; i++) {
         		$scope.pricingData.push($scope.pricingFeature[i]);
         	}
         	for(var j =0; j < $scope.commonDatas.length; j++) {
         		$scope.pricingData.push($scope.commonDatas[j]);
         	}
         	for(var k = 0; k < $scope.licenseAmounts.length; k++) {
     			$scope.pricingData.push($scope.licenseAmounts[k]);
     		}
         };
         
         $scope.pricingDetails = function() {
             $scope.showEnterprseEdit = false;
             var commonData = {};
             $scope.licenseAmount = [];
             licenseServices.getPricingDetails($scope, function(data) {
                 for (var i = 0; i < data.message.length - 3; i++) {
                 	$scope.pricingFeature.push(data.message[i]);
                 }
                 for (var i = data.message.length - 3; i < data.message.length; i++) {
                     $scope.licenseAmounts.push(data.message[i]);
                 }
                 commonData = licenseServices.getPricingCommonDetails($scope);
                 commonData.then(function(data) {
                     angular.forEach(data.data, function(commonData) {
                     	$scope.commonDatas.push(commonData);
                     });
                     // show LicensePricingFeature and Details
                     $scope.selectPricingDetails();
                 });
             });
         };
         
         $scope.pricingDetails();
         
         var indexedTeams = [];
         
         $scope.pricingDataToFilter = function() {
             indexedTeams = [];
             return $scope.pricingData;
         };        
         $scope.filterPricingFeature = function(pricing) {
             var teamIsNew = indexedTeams.indexOf(pricing.module_name) == -1;
             if (teamIsNew) {
                 indexedTeams.push(pricing.module_name);
             }
             return teamIsNew;
         };

         /*if (selectedRow == null) {
             $scope.pricingDetails($scope.manage.selectedPeriod);
             
         }*/
         $scope.showEnterprseEdit = false;
         $scope.editEnterpriseData = function() {
             $scope.showEnterprseEdit = true;
             $scope.originalPricingData = JSON.parse(JSON.stringify($scope.pricingData));
         };

         $scope.doNotUpdateEnterprise = function() {
             $scope.showEnterprseEdit = false;
             $scope.pricingData = $scope.originalPricingData;
         };

         $scope.loadPeriodTypeDetails = function() {
        	sessionServices.set("Lic_startDate", null);
     		sessionServices.set("Lic_endDate", null);
     		sessionServices.set("Lic_category", null);
             /*if ($scope.manage.licenseCategory == 'newLicense' && $scope.manage.startdate) {
                 validateEndDate('', 'newLicense');
             } else {
                 validateEndDate($scope.manage.startdate, "renewal");
             }*/

        	 sessionServices.set("Lic_category", $scope.licenseCategory);
         	if(licenseData && licenseData.lic_category != 'Top-Up' && $scope.licenseCategory == 'Top-Up') {
         		if($scope.manage.selectedPeriod == 'Daily') {
         			$scope.hideDatePicker = false;
         			$scope.stDateLimit = convertDate($scope.manage.startdate);
           			$scope.enDateLimit = convertDate($scope.manage.enddate);
         		} else {
         			$scope.hideDatePicker = true;
         			$scope.manage.startdate = (formateDate(new Date(licenseData.start_date)));
           			$scope.manage.enddate = (formateDate(new Date(licenseData.end_date)));
           			sessionServices.set("Lic_startDate", new Date($scope.manage.startdate));
           			sessionServices.set("Lic_endDate", new Date(licenseData.end_date));
	           	}
         	}
         	
         	if(($scope.licenseCategory == 'Top-Up' || $scope.licenseCategory == 'Update') && $scope.manage.selectedPeriod == 'Daily') {
         		var startDt = new Date(licenseData.start_date);
         		var currentDt = new Date();
         		if(startDt > currentDt) {
         			$scope.manage.startdate = (formateDate(new Date(licenseData.start_date)));
         			sessionServices.set("Lic_startDate", new Date(licenseData.start_date));
         			$scope.stDateLimit = convertDate($scope.manage.startdate);
         			if($scope.licenseCategory == 'Top-Up') {
         				$scope.enDateLimit = convertDate($scope.manage.enddate);
         			} else {
         				$scope.enDateLimit = "";
         			}
         		} else {
             		$scope.manage.startdate = $scope.curdate;
             		sessionServices.set("Lic_startDate", new Date($scope.manage.startdate));
             		$scope.stDateLimit = convertDate($scope.curdate);
         		}
         		
             } else if (($scope.licenseCategory == 'Top-Up' || $scope.licenseCategory == 'Update') && $scope.manage.selectedPeriod == 'Monthly') {
             	$scope.manage.startdate = (formateDate(new Date(licenseData.start_date)));
             	sessionServices.set("Lic_startDate", new Date(licenseData.start_date));
             } else if (($scope.licenseCategory == 'Top-Up' || $scope.licenseCategory == 'Update') && $scope.manage.selectedPeriod == 'Annual') {
             	$scope.manage.startdate = (formateDate(new Date(licenseData.start_date)));
             	sessionServices.set("Lic_startDate", new Date(licenseData.start_date));
             }
             validateEndDate();
         };

         function validateEndDate() {
             var stDate = '';
             /*if (isFrom == 'newLicense') {
                 stDate = $scope.manage.startdate;
             } else {
                 stDate = strtDate;
             }*/
             stDate = $scope.manage.startdate;
             var enDate = $scope.manage.enddate;
             if (isdate(stDate) == 1) {
                 stDate = convertDate(stDate);
             } else {
                 stDate = new Date(stDate.toString());
             }
             if (isdate(enDate) == 1) {
                 enDate = convertDate(enDate);
             } else {
                 enDate = new Date(enDate.toString());
             }
             if (enDate < stDate) {
                 enDate = stDate;
                 $scope.manage.enddate = stDate;
                 sessionServices.set("Lic_endDate", new Date($scope.manage.enddate));
             }
             var endDate = new Date();
             endDate = stDate;
             if ($scope.manage.selectedPeriod == 'Daily') {
                 endDate = endDate.setDate(endDate.getDate());
                 var date = new Date(endDate)
                 $scope.manage.enddate = formateDate(date);
                 sessionServices.set("Lic_endDate", new Date($scope.manage.enddate));
             } else if ($scope.manage.selectedPeriod == 'Monthly') {
                 endDate = endDate.setMonth(endDate.getMonth() + 1);
                 endDate = new Date(endDate);
                 endDate = endDate.setDate(endDate.getDate() - 1);
                 var date = new Date(endDate)
                 $scope.manage.enddate = formateDate(date);
                 sessionServices.set("Lic_endDate", new Date($scope.manage.enddate));
             } else if ($scope.manage.selectedPeriod == 'Annual') {
                 endDate = endDate.setYear(endDate.getFullYear() + 1);
                 endDate = new Date(endDate);
                 endDate = endDate.setDate(endDate.getDate() - 1);
                 var date = new Date(endDate)
                 $scope.manage.enddate = formateDate(date);
                 sessionServices.set("Lic_endDate", new Date($scope.manage.enddate));
             }
             $rootScope.$emit('loadLicenseDateChange');
             var todayDateTime = new Date();
             var todayDate = todayDateTime.getDate() + "-" + (months[todayDateTime.getMonth()]) + "-" + todayDateTime.getFullYear();
             if (stDate < todayDate) {
                 $scope.manage.startdate = todayDate;
             }
         };

         function getNowIfExpired(val)
         {
         	var enDate = val;
             if (isdate(enDate) == 1) {
                 enDate = convertDate(enDate);
             }
             var endDate = enDate.split('T');
             endDate = endDate[0];
             var strtDate = new Date(endDate);
             strtDate = strtDate.setDate(strtDate.getDate() + 1);
             var date = new Date(strtDate);

         	var lic_date = formateDate(date);
         	var now_date = new Date();
             var now_date1 = formateDate(now_date);
         	if(now_date > date){
 	        	//Licensemessage
 	        	$scope.licMessage = " License is already expired. Your renewal starts from today.";
 	        	return now_date1;
         	}else{
             	//Licensemessage
             	$scope.licMessage = " Current license is active. Auto-Renewal will take place.";
             	return lic_date;
             }
         }
         
         function isdate(val) {
             var date = Date.parse(val);
             if (isNaN(date)) {
                 return 1;
             } else {
                 return 0;
             }
         }

 		function convertDate(date)
 		{
 			var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
 			var splitDate = date.split("-");
 			var convertedDate = new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
 			return convertedDate;
 		}

         function formateDate(date) {
             months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
             currentDate = date;
             var formatedDate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
             return formatedDate;
         };
        
         $scope.updateLicensePaymentDetails = function(PricingObject,pricingAmt,licLevel) {
         	$scope.manage.selectedPlanType = licLevel;
             $scope.manage.selectedPeriod = PricingObject.payment_code;
             $scope.manage.licensePaymentAmount = pricingAmt;
             $scope.loadPeriodTypeDetails();
         };

         $scope.updateLicense = function() {
         	//var dt1 = new Date($scope.manage.startdate);
        	 console.log("lic st_date: "+ sessionServices.get("start_date"));
        	 console.log("lic en_date: "+ sessionServices.get("end_date"));
        	 $scope.manage.startdate = sessionServices.get("start_date");
        	 $scope.manage.enddate = sessionServices.get("end_date"); 
         	var stDate = $scope.manage.startdate;
         	if (isdate(stDate) == 1) {
                 stDate = convertDate(stDate);
             } else {
                 stDate = new Date(stDate.toString());
             }
         	
         	var enDate = $scope.manage.enddate;
         	if (isdate(enDate) == 1) {
         		enDate = convertDate(enDate);
             } else {
             	enDate = new Date(enDate.toString());
             }
         	//var dt2 = new Date();
         	var strtDate = formateDateBeforeUpdate(stDate);
         	var endDate = formateDateBeforeUpdate(enDate);
         	
         	function formateDateBeforeUpdate(date) {
                 months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                 currentDate = date;
                 var formatedDate = currentDate.getFullYear() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getDate() ;
                 return formatedDate;
             };
             licenseServices.getformatedDate(strtDate, endDate, function() {});
             
             if ($scope.licenseCategory == 'Update') {
             	$scope.licenseCategory = 'Renewal';
             } 
             if ($scope.manage.selectedPlanType == 'level3') {
                 var pricing_data = [];
                 angular.forEach($scope.pricingData, function(data) {
                     if (data.lic_id) {
                         pricingValues = {};
                         pricingValues.enterprise = data.enterprise || data.level3;
                         pricingValues.feature = data.feature;
                         pricingValues.module_name = data.module_name;
                         pricingValues.lic_id = data.lic_id;
                         pricingValues.payment_code = data.payment_code || "";
                         pricing_data.push(pricingValues);
                     }
                 });

                 params = {
                     email_id: emailId,
                     lic_category: $scope.licenseCategory,
                     lic_type: $scope.manage.selectedPlanType,
                     lic_period: $scope.manage.selectedPeriod,
                     lic_start_date: licenseServices.getFormattedStartDate(),
                     lic_end_date: licenseServices.getFormattedEndDate(),
                     pricing_data: JSON.stringify(pricing_data),
                     lic_schedule_id: $scope.manage.lic_schedule_id,
                     reference: $scope.manage.reference
                 };
             } else {
                 params = {
                     email_id: emailId,
                     lic_category: $scope.licenseCategory,
                     lic_type: $scope.manage.selectedPlanType,
                     lic_period: $scope.manage.selectedPeriod,
                     lic_start_date: licenseServices.getFormattedStartDate(),
                     lic_end_date: licenseServices.getFormattedEndDate(),
                     lic_schedule_id: $scope.manage.lic_schedule_id,
                     reference: $scope.manage.reference
                 };
             }
 			//if($scope.manage.reference) {
             if($scope.manage.selectedPlanType) {
             	licenseServices.updateUserLicese($scope, params, function(data) {
                 	if (data.success == true) {
                     	$scope.showEnterprseEdit = false;
                     	$uibModalInstance.dismiss('cancel');
                     	$rootScope.$emit('loadLicenseHistory');
                     	//successMsgService.showSuccessOrErrorMsg(data);
                     	messageService.showSuccessMessage(data.message);
                 	}
                 	else{
                 		//messageService.showWarningMessage(data.errorMessage,{dismissOnTimeout: false, dismissOnClick: false, additionalClasses: 'apd-alert-msg'});
                 		messageService.showWarningMessage(data.errorMessage);
                 	}
             });
 			} else {
 				messageService.showWarningMessage("Select a License Category.");
 			   /*ngToast.create({
 					className: 'warning',
 					//content: "Please enter reference.",
 					content: "Select a License Category.",
 					timeout: 3000,
 					dismissOnTimeout: true,
 					dismissButton: true,
 					animation: 'fade'
 				});
*/ 			}
         };

         $scope.paypalPayment = function() {
         	// check for license Price in click on License radio Button
 	        if($scope.manage.licensePaymentAmount){
 	        	$scope.manage.startdate = sessionServices.get("start_date");
 	        	$scope.manage.enddate = sessionServices.get("end_date"); 
 	        	var stDate = $scope.manage.startdate;
 	        	if (isdate(stDate) == 1) {
 	                stDate = convertDate(stDate);
 	            } else {
 	                stDate = new Date(stDate.toString());
 	            }
 	        	
 	        	var enDate = $scope.manage.enddate;
 	        	if (isdate(enDate) == 1) {
 	        		enDate = convertDate(enDate);
 	            } else {
 	            	enDate = new Date(enDate.toString());
 	            }
 	        	//var dt2 = new Date();
 	        	var strtDate = formateDateBeforeUpdate(stDate);
 	        	var endDate = formateDateBeforeUpdate(enDate);
         	
 	        	function formateDateBeforeUpdate(date) {
 	                months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
 	                currentDate = date;
 	                var formatedDate = currentDate.getFullYear() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getDate() ;
 	                return formatedDate;
 	            };
 	            licenseServices.getformatedDate(strtDate, endDate, function() {});
 	            
 	            if ($scope.licenseCategory == 'Update') {
 	            	$scope.licenseCategory = 'Renewal';
 	            }
 	            custom_params = {
 	                email_id: emailId,
 	                lic_category: $scope.licenseCategory,
 	                lic_type: $scope.manage.selectedPlanType,
 	                lic_period: $scope.manage.selectedPeriod,
 	                lic_start_date: licenseServices.getFormattedStartDate(),
 	                lic_end_date: licenseServices.getFormattedEndDate(),
 	                lic_schedule_id: $scope.manage.lic_schedule_id,
 	                reference: $scope.manage.reference
 	            };
 	            if ($scope.manage.selectedPlanType == 'level3') {
 	                var pricing_data = [];
 	                angular.forEach($scope.pricingData, function(data) {
 	                    if (data.lic_id) {
 	                        pricingValues = {};
 	                        pricingValues.enterprise = data.enterprise;
 	                        pricingValues.feature = data.feature;
 	                        pricingValues.module_name = data.module_name;
 	                        pricingValues.lic_id = data.lic_id;
 	                        pricing_data.push(pricingValues);
 	                    }
 	                });
 		            
                 cutom_params.pricing_data = JSON.stringify(pricing_data);
             }
             $("#paypalForm").attr("action",$scope.paypal_Gateway_url);
             document.getElementById("Business_Id").value = $scope.paypal_Business_Id;
             document.getElementById("return").value = $scope.paypal_Return_URL;
             //document.getElementById("cancel_return").value = $scope.paypal_Cancel_Return_URL;
             // Paypal Params:
             document.getElementById("custom").value = JSON.stringify( custom_params);
 	        document.getElementById("amount").value = $scope.manage.licensePaymentAmount;
             if($scope.manage.selectedPlanType == 'level1')
             {
             	//document.getElementById("amount").value = 30.00;
             	document.getElementById("itemName").value = "Essential License";
             }
             else if($scope.manage.selectedPlanType == 'level2')
             {
             	//document.getElementById("amount").value = 150.00;
             	document.getElementById("itemName").value = "Pro License";
             }
             else
         	{
             	document.getElementById("amount").value = 0.00;
         	}
 	       	// CI entry for cross verification
 				$scope.testCITrigger('Admin License Window', 'Paypal Pay-Now onClick');
 	        document.getElementById("paypalForm").submit();
 	       }else{
         		/*ngToast.create({
 					className: 'warning',
 					content: "Select a License Category.",
 					timeout: 3000,
 					dismissOnTimeout: true,
 					dismissButton: true,
 					animation: 'fade'
 				});*/
 	    	  messageService.showWarningMessage("Select a License Category.");
         	}
 	    }
     }
]);

appedoApp.controller('licenseReportsController', ['$scope', 'licenseServices', 'messageService', function($scope, licenseServices, messageService) {

	$scope.reports = {};
	$scope.reports.expire = 'EXPIRED';
	
	$scope.reports.expireInNextDays = 10;
	
	//$scope.licenseExpiredUsers = [];
	//$scope.LicenseWillExipreUsers = [];
	
	$scope.LicenseExipreUsers = [];
	
	// gets users whose license gets expired
	$scope.getLicenseExpiredUsers = function() {
		clearLicenseExipreUsers();
		licenseServices.getLicenseExpiredUsers(function(data) {
			if (!data.success) {
				// error
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.LicenseExipreUsers = data.message;
			}
		});
	};
	
	
	// gets users whose license will expire in next days
	$scope.getLicenseWillExipreUsers = function() {
		clearLicenseExipreUsers();
		licenseServices.getLicenseWillExipreUsers($scope.reports.expireInNextDays, function(data) {
			if (!data.success) {
				// error
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.LicenseExipreUsers = data.message;
			}
		});
	};
	

	// 
	$scope.loadLicenseExpireUsers = function() {
		if ($scope.reports.expire === 'EXPIRED') {
			$scope.getLicenseExpiredUsers();
		} else {
			$scope.getLicenseWillExipreUsers();
		}
	};
	$scope.loadLicenseExpireUsers();
	
	function clearLicenseExipreUsers() {
		$scope.LicenseExipreUsers = [];
	}
	
}]);

appedoApp.controller('adminAccessRightsController', ['$scope', '$rootScope', '$uibModal', 'sessionServices', 'userMetrics', 'licenseServices', 'successMsgService', function($scope, $rootScope, $uibModal, sessionServices, userMetrics, licenseServices, successMsgService) {

	//$scope.formAccessRights = {};
	
	

	// get User all email ids, based on logged in user's privilage 
	$scope.getUserEmailds = function() {
		var resultEmails = licenseServices.getLicesingEmails();
		resultEmails.then(function(data) {
			$scope.licensingEmailIds = data.message;
		});
	};
	$scope.getUserEmailds();
	/*
	// update access rights for a user
	$scope.updateUserAccessRights = function() {

		var resultAccessLicensePrevilage = licenseServices.updateUserAccessRights($scope.formAccessRights.email.email_id, ($scope.formAccessRights.useLiceseManagement != undefined ? $scope.formAccessRights.useLiceseManagement : false), ( $scope.formAccessRights.useUsageMetric != undefined ? $scope.formAccessRights.useUsageMetric : false));
		resultAccessLicensePrevilage.then(function(data) {
			successMsgService.showSuccessOrErrorMsg(data);
			if ( data.success ) {
				$scope.getUsersAdminPrivilege();
			}
		});
	};
	*/
	
	// gets user has either can manage license or view usage reports
	$scope.getUsersAdminPrivilege = function() {

		var resultUsersAdminPrivilages = licenseServices.getUsersAdminPrivilege();
		resultUsersAdminPrivilages.then(function(data) {
			if ( ! data.success ) {
				// err
				successMsgService.showSuccessOrErrorMsg(data);
			} else {
				$scope.usersAdminPrivilege = data.message;
			}
			//successMsgService.showSuccessOrErrorMsg(data);
		});
	};
	$scope.getUsersAdminPrivilege();
	//for refresh the card layout after updated
	var loadUsersAdminPrivilege = $rootScope.$on("loadUsersAdminPrivilege", $scope.getUsersAdminPrivilege);
	$rootScope.$on('$destroy', loadUsersAdminPrivilege);
	
	
	// 
	$scope.openUpdateUserAccessRights = function(joUserPrivilage) {

		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/accounts/updateUserAccessRights.html',
			controller: 'updateUserAccessRightsController',
			size: 'lg',
			resolve: {
				licensingEmailIds: function() {
					return $scope.licensingEmailIds;
				},
				userPrivilage: function() {
					return joUserPrivilage;
				}
			}
		});
	};
}]);

appedoApp.controller('updateUserAccessRightsController', function($scope, $rootScope, $uibModalInstance, licenseServices, licensingEmailIds, userPrivilage, successMsgService) {	
	$scope.licensingEmailIds = licensingEmailIds;

	$scope.formAccessRights = {};
	
	// since to make readonly of emailId dropdown while edit clicked
	$scope.isEdit = false;
	
	// sets grid value in form while edit from grid
	if ( userPrivilage != undefined ) {
		$scope.isEdit = true;
		
		// sets email id
		for(var i = 0; i < $scope.licensingEmailIds.length; i = i +1) {
			var joEmail = $scope.licensingEmailIds[i];
			
			if( joEmail.email_id === userPrivilage.emailId ) {
				$scope.formAccessRights.email = $scope.licensingEmailIds[i];
			}
		}
		
		$scope.formAccessRights.useLiceseManagement = userPrivilage.canManageLicense;
		$scope.formAccessRights.useUsageMetric = userPrivilage.canViewUsageReports;
	}
	
	
	// update access rights for a user
	$scope.updateUserAccessRights = function() {

		var resultAccessLicensePrevilage = licenseServices.updateUserAccessRights($scope.formAccessRights.email.email_id, ($scope.formAccessRights.useLiceseManagement != undefined ? $scope.formAccessRights.useLiceseManagement : false), ( $scope.formAccessRights.useUsageMetric != undefined ? $scope.formAccessRights.useUsageMetric : false));
		resultAccessLicensePrevilage.then(function(data) {
			successMsgService.showSuccessOrErrorMsg(data);
			if ( data.success ) {
				$rootScope.$emit('loadUsersAdminPrivilege');
				$scope.close();
			}
		});
	};
	

	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};	
});

appedoApp.controller('avmHomeController', ['$scope', '$rootScope', '$uibModal', '$state', 'avmModuleFactory', 'avmModuleServices', 'ajaxCallService', 'sessionServices', 'messageService', '$appedoUtils', 
                                       	function($scope, $rootScope, $uibModal, $state, avmModuleFactory, avmModuleServices, ajaxCallService, sessionServices, messageService, $appedoUtils) {
                                       	
                                       	$scope.avmTests = [];
                                       	var aryUserAVMTests = [];
                                       	$scope.showCardEmptyMsg = false;
                                       	
                                       	$scope.avmUserLocations = [];
                                       	$scope.avmLoadingLocations = false;
                                       	
                                       	// AVM status
                                       	$scope.aryAVMStatus = [{label: "Running", selected: true, count: 0}, {label: "Scheduled", selected: true, count: 0}, {label: "Completed", selected: true, count: 0}, {label: "Disabled", selected: true, count: 0}];
                                       	
                                       	$scope.AVM_STATUSES = avmModuleFactory.AVM_STATUSES;
                                       	
                                       	var aryModuleDescriptionContents = [];

                                       	// loads module description content
                                       	function getModuleDescriptionContent() {
                                       		ajaxCallService.getJsonData('common/data/module_content_avm.json', function(responseData){
                                       			aryModuleDescriptionContents = responseData;
                                       			
                                       			// idxModuleDescriptionContent no. given, since is had in respective orders
                                       			//$scope.moduleDescription = $scope.moduleASDCardsDescriptionContent[idxModuleDescriptionContent];
                                       		});
                                       	};
                                       	getModuleDescriptionContent();
                                       	
                                       	
                                       	// Default dashboard
                                       	if ( $rootScope.backPageFrom == 'AVMDetails' || $rootScope.backPageFrom == '360View' ) {
                                       		$scope.selectedAVMRadioValue = "AVMPanel";
                                       		//$rootScope.backPageFrom = '';
                                       	} else {
                                       		$scope.selectedAVMRadioValue = "DASHBOARD";
                                       	}
                                       	
                                       	// Reset, since on refresh, to be in `Dashboard` Panel
                                       	$rootScope.backPageFrom = '';
                                       	
                                       	
                                       	$scope.openAddModuleType = function() {
                                       		var modalInstance = $uibModal.open({
                                       			templateUrl: 'common/views/select_module.html',
                                       			controller: 'add-model-instance-controller',
                                       			size: 'lg',
                                       			backdrop : 'static'
                                       		});
                                       	};
                                       	
                                       	$scope.loadSelectedTypePanel = function() {
                                       		
                                       		if ( $scope.selectedAVMRadioValue === 'AVMPanel' ) {
                                       			// loads user's availability tests 
                                       			$scope.getAVMTests();
                                       		} else if ( $scope.selectedAVMRadioValue === 'AVM_USER_LOCATIONS' ) {
                                       			// loads user's monitoring locations 
                                       			$scope.getUserLocations();
                                       		}
                                       	};
                                       	
                                       	$scope.getAVMTests = function() {
                                       		avmModuleServices.getAVMUserTests(function(data) {
                                       			if ( ! data.success ) {
                                       				// err
                                       				messageService.showErrorMessage(data.errorMessage);
                                       			} else {				
                                       				aryUserAVMTests = data.message;
                                       				$scope.avmTests = aryUserAVMTests;
                                       				// AVM status has been selected, on click the status from from `360 View` in `Synthetic User Summary`->`Test Status`
                                       				var selectedAVMStatus = $rootScope.selectedAVMStatus || '';
                                       				// Reset, since on refresh, to load default all tests
                                       				$rootScope.selectedAVMStatus = '';
                                       				
                                       				// If array length is 0 show blank page description content else show cardlayout. 
                                       				if( $scope.avmTests.length === 0 ) {
                                       					$scope.showCardEmptyMsg = true;
                                       				} else {
                                       					$scope.showCardEmptyMsg = false;
                                       				}
                                       				
                                       				// Reset all status as selected & calc status's count, added since on SUMTest add, after added to show all status's data
                                       				resetStatusAllSelection(selectedAVMStatus);
                                       				// To show respective status's Test(s); Note: the selected status is made as `selected:true` in `resetStatusAllSelection`
                                       				if ( selectedAVMStatus.length > 0 ) {
                                       					$scope.getSelectedAVMStatuses();
                                       				}
                                       			}
                                       		});
                                       	};
                                       	$scope.getAVMTests();
                                       	
                                       	// Filter's selected status's AVM tests
                                       	$scope.getSelectedAVMStatuses = function() {
                                       		var arySelectedStatus = [], arySelectedStatusAVMTests = [];
                                       		
                                       		// Has selected status in ary, say ["Running, "Scheduled"], Note: "Running, "Scheduled" are selected from dropdown
                                       		arySelectedStatus = $appedoUtils.filteredOptions($scope.aryAVMStatus);
                                       		
                                       		// Filter's selected status's AVM tests
                                       		for (var i = 0; i < aryUserAVMTests.length; i = i + 1) {
                                       			var joTest = aryUserAVMTests[i];
                                       			if ( arySelectedStatus.indexOf( joTest.status ) >= 0 ) {
                                       				arySelectedStatusAVMTests.push( joTest );
                                       			}
                                       		}
                                       		
                                       		// Sets filtered AVM Tests
                                       		$scope.avmTests = arySelectedStatusAVMTests;
                                       	};
                                       	
                                       	// Reset all status as selected true
                                       	function resetStatusAllSelection(selectedAVMStatus) {
                                       		// Calc user's AVM Tests status wise count; Note: key in `joStatusWiseCount` has to match with `label` property in `$scope.aryAVMStatus`
                                       		var joStatusWiseCount = {"Running": 0, "Scheduled": 0, "Completed": 0, "Disabled": 0};
                                       		for (var i = 0; i < aryUserAVMTests.length; i = i + 1) {
                                       			var joTest = aryUserAVMTests[i];
                                       			joStatusWiseCount[joTest.status] = joStatusWiseCount[joTest.status] + 1;
                                       		};
                                       		
                                       		// Sets selected true and respective status's count
                                       		for (var i = 0; i < $scope.aryAVMStatus.length; i = i + 1) {
                                       			var joStatus = $scope.aryAVMStatus[i];
                                       			// Since, to show selected status condition added; Note: the status has been selected from `360 View` in `Synthetic User Summary`->`Test Status`
                                       			joStatus.selected = selectedAVMStatus.length > 0 ? (joStatus.label === selectedAVMStatus) : true;
                                       			joStatus.count = joStatusWiseCount[joStatus.label];
                                       		};
                                       	}
                                       	
                                       	// For refresh the card layout after Add/Update
                                       	var avmCard = $rootScope.$on("reloadAVMCardLayout", $scope.getAVMTests);
                                       	$scope.$on('$destroy', avmCard);

                                       	// To delete a AVM from the card layout
                                       	$scope.deleteSelectedAvm = function(index) {
                                       		var result = confirm("You will lose AVM records permanently!\nAre you sure you want to delete?");
                                       		if(result == true) {
                                       			avmModuleServices.deleteAVMRecord($scope, this.test.testid, function (response) {
                                       				if( response.success ){
                                       					messageService.showSuccessMessage(response.message);

                                       					$scope.getAVMTests();
                                       				} else {
                                       					messageService.showWarningMessage(response.errorMessage);
                                       				}
                                       			});
                                       		}
                                       	};
                                       	
                                       	$scope.editSum = function() {
                                       		var testData = this.test;
                                       		var modalInstance = $uibModal.open({
                                       			templateUrl: 'modules/avm/view/add_avm.html',
                                       			controller: 'avmAddController',
                                       			size: 'lg',
                                       			resolve: {
                                       				isFrom: function() {
                                       					return 'fromEdit';
                                       				},
                                       				avmTestData: function() {
                                       					return testData;
                                       				}, moduleCardContent: function() {
                                       					return null;
                                       				}
                                       			}
                                       		});
                                       	};
                                       	
                                       	$scope.openModuleDetailGrpahs = function(index) {
                                       		sessionServices.set("selectedAvmCardContent", JSON.stringify(this.test));
                                       		$state.transitionTo('/avm_details');
                                       	};
                                       	
                                       	// 
                                       	$scope.getUserLocations = function() {
                                       		showLoadingLocations();
                                       		$scope.avmUserLocations = [];
                                       			
                                       		avmModuleServices.getUserLocations(function(data) {
                                       			if ( ! data.success ) {
                                       				// err
                                       				messageService.showErrorMessage(data.errorMessage);
                                       			} else {
                                       				hideLoadingLocations();
                                       				
                                       				$scope.avmUserLocations = data.message;
                                       			}
                                       		});
                                       	};
                                       	$scope.getUserLocations();
                                       	
                                       	//for refresh the card layout after Add
                                       	var avmUserLocationsCard = $rootScope.$on("loadAVMUserLocations", $scope.getUserLocations);
                                           $scope.$on('$destroy', avmUserLocationsCard);
                                       	
                                           // edit's agent location for status `Just Added`
                                       	$scope.openEditLocation = function(joLocation) {
                                       		// AVM location's description details; Note: `1` hardcoded since respective order known in `common/data/module_content_avm.json`
                                       		var joLocationDescContent = aryModuleDescriptionContents[1];
                                       		
                                       		avmModuleServices.openAddorEditMyLocations('fromEdit', joLocation, joLocationDescContent);
                                       	};
                                           
                                       	// 
                                       	$scope.openLocationToAlertAddresses = function(joLocation) {
                                       		// AVM location's description details; Note: `1` hardcoded since respective order known in `common/data/module_content_avm.json` 
                                       		var joLocationDescContent = aryModuleDescriptionContents[1];
                                       		
                                       		// opens window, of location's view added alert addresses, when site is down or location_agent is down 
                                       		avmModuleServices.openLocationToAlertAddresses(joLocation.agentId, joLocationDescContent);
                                       	};
                                           
                                           
                                       	function showLoadingLocations() { $scope.avmLoadingLocations = true; }
                                       	function hideLoadingLocations() { $scope.avmLoadingLocations = false; }
                                       }]);

appedoApp.controller('avmAddController', ['$scope', '$uibModal', 'avmModuleServices', '$uibModalInstance', 'isFrom', 'moduleCardContent', 'ngToast', 'sessionServices', '$rootScope', 'avmTestData', 'successMsgService', 'messageService','forDateTimeModuleMethod', 
	function($scope, $uibModal, avmModuleServices, $uibModalInstance, isFrom, moduleCardContent, ngToast, sessionServices, $rootScope, avmTestData, successMsgService, messageService,forDateTimeModuleMethod) {
	
	$scope.avmTestData = {};
	$scope.dupCheck = true;
	
	$scope.DAYS = [{"SUNDAY": false}, {"MONDAY": true}, {"TUESDAY": true}, {"WEDNESDAY": true}, 
	                {"THURSDAY": true}, {"FRIDAY": true}, {"SATURDAY": false}];
	
	// To check whether AVM test_name exists already.
	$scope.validateAVMTestName = function () {
		if($scope.avmTestData.testName != undefined && $scope.avmTestData.testName != ""){
			$scope.dupCheck = false;
			avmModuleServices.validateAVMTestName($scope, $scope.avmTestData.testName, $scope.avmTestData.testid, function(data) {
				if(data.success){
					$scope.showProceed = data.isExist;
					if(data.isExist){
						$scope.response ={};
						$scope.response.success = false;
						$scope.response.errorMessage = $scope.avmTestData.testName+" already exists.";
						//successMsgService.showSuccessOrErrorMsg($scope.response);
						messageService.showErrorMessage($scope.response.errorMessage);
					}
				}else{
					$scope.showProceed = true;
				}
			});
		}
	};
	
	var currentDate = '';
	$scope.today = function() {
		months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		currentDate = new Date();
		$scope.curdate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
		};
	$scope.today();
	
	
	if(isFrom == 'fromAdd') {
		forDateTimeModuleMethod.setMethod("fromAddAVM");
		$scope.formName = "Add";
		$scope.saveBtn = "Save";
		$scope.show_deactivate = false;
		$scope.avmTestData.testName = "";
		$scope.avmTestData.status = true;
		$scope.avmTestData.url = 'http://';
		$scope.avmTestData.requestMethod = 'GET';
		$scope.avmTestData.testHeadMethodFirst = true;
		$scope.avmTestData.requestHeaders = [{"name": "Accept", "value": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}, {"name": "Accept-Encoding", "value": "gzip, deflate, br"}, {"name": "Accept-Language", "value": "en-US,en;q=0.5"}, {"name": "Connection", "value": "close"}, {"name": "User-Agent", "value": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0"}];
		$scope.avmTestData.requestParameters = [{"name":"","value":""}];
		$scope.avmTestData.frequency = "3";
		$scope.avmTestData.startdate = $scope.curdate;
		$scope.avmTestData.enddate = $scope.curdate;
		$scope.avmTestData.avmBreachCount = "1";
		$scope.avmTestData.days = $scope.DAYS;
		
		$scope.avmTestData.startHour = undefined;
		$scope.avmTestData.endHour = undefined;
		$scope.avmTestData.startMins = undefined;
		$scope.avmTestData.endMins = undefined;
		$scope.avmTestData.timezoneOffset = new Date().getTimezoneOffset();
		
		// Bandwidth alert parameters
		$scope.avmTestData.bandwidthAlert = false;
		$scope.avmTestData.warning = 100;
		$scope.avmTestData.error = 50;
		$scope.avmTestData.bmBreachCount = 1;
	
	} else {
		forDateTimeModuleMethod.setMethod("fromEditAVM");
		$scope.formName = "Edit";
		$scope.saveBtn = "Update";
		$scope.show_deactivate = true;
		
		// sets the formatted json
		avmTestData.formatted_startdate = formateDate(new Date(avmTestData.startdate));
		avmTestData.formatted_enddate = formateDate(new Date(avmTestData.enddate));
		
		if(avmTestData.startTimeInMinutes == -1 || avmTestData.endTimeInMinutes == -1) {
			$scope.avmTestData.startHour = undefined;
			$scope.avmTestData.endHour = undefined;
			$scope.avmTestData.startMins = undefined;
			$scope.avmTestData.endMins = undefined;
		} else {
			// (start_time + Browser_timezoneOffset )
			
			var startTimeInMinutes = new Date(avmTestData.startTimeInMinutes);
			var endTimeInMinutes = new Date(avmTestData.endTimeInMinutes);
	
			$scope.avmTestData.startHour = startTimeInMinutes.getHours();
			$scope.avmTestData.startMins = startTimeInMinutes.getMinutes();
	
			$scope.avmTestData.endHour = endTimeInMinutes.getHours();
			$scope.avmTestData.endMins = endTimeInMinutes.getMinutes();
			
		}
		$scope.avmTestData.timezoneOffset = new Date().getTimezoneOffset();
	
		$scope.userSelectedCities = {};
		$scope.avmTestData.testid = avmTestData.testid;
		$scope.avmTestData.testName = avmTestData.testname;
		$scope.avmTestData.url = avmTestData.testurl;
		$scope.avmTestData.requestMethod = avmTestData.requestMethod;
		$scope.avmTestData.testHeadMethodFirst = avmTestData.testHeadMethodFirst;
		console.info("requedtHeader.length:");
		console.log(avmTestData);
		if( avmTestData.requestHeaders.length > 0 ) {
			$scope.avmTestData.requestHeaders = avmTestData.requestHeaders;
		} else {
			$scope.avmTestData.requestHeaders = [{"name":"","value":""}];
		}
		if( avmTestData.requestParameters.length > 0 ) {
			$scope.avmTestData.requestParameters = avmTestData.requestParameters;
		} else {
			$scope.avmTestData.requestParameters = [{"name":"","value":""}];
		}
		$scope.avmTestData.frequency = avmTestData.frequency;
		$scope.avmTestData.testType = avmTestData.testtype;
		$scope.avmTestData.status = avmTestData.originalstatus;
		$scope.avmTestData.startdate = avmTestData.formatted_startdate;
		$scope.avmTestData.enddate = avmTestData.formatted_enddate;
		forDateTimeModuleMethod.setStDate(new Date(avmTestData.startdate));
		forDateTimeModuleMethod.setEndDate(new Date(avmTestData.enddate));
		$scope.avmTestData.mapped_locations = avmTestData.mapped_locations;
		
		var editDta = $scope.sumTestAddData;
		var citiesData = avmTestData.cities;
		$scope.validateAVMTestName();
		$scope.defaultMinBreachCount = avmTestData.minbreachcount;
		$scope.avmTestData.avmBreachCount = avmTestData.am_minbreachcount;
	}
	
	function formateDate(date){
		months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		currentDate = date;
		var formatedDate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
		return formatedDate;
	};
	
	$scope.appendHttpPrefix = function() {
		var urlregex = new RegExp(sessionServices.get("webURLValidation"),"i");
		$scope.showInfoHttpAppended = false;
		$scope.showHttpMsg = false;
		$scope.showInValidUrlMsg = false;
		if( !/^(http):\/\//i.test($scope.avmTestData.url) && !/^(https):\/\//i.test($scope.avmTestData.url) ) {
			$scope.avmTestData.url = 'http://';
			$scope.showInfoHttpAppended = true;
			$scope.showHttpMsg = true;
			$scope.showInValidUrlMsg = false;
		} else {
			$scope.showHttpMsg = false;
			$scope.showInValidUrlMsg = false;
			if( !urlregex.test($scope.avmTestData.url)) {
				$scope.showInfoHttpAppended = true;
				$scope.showHttpMsg = false;
				$scope.showInValidUrlMsg = true;
			} else {
				$scope.showInfoHttpAppended = false;
				$scope.showHttpMsg = false;
				$scope.showInValidUrlMsg = false;
			}
		}
	};
	
	$scope.setEndDateAsStartDate = function() {
		stDate = $scope.avmTestData.startdate;
		enDate = $scope.avmTestData.enddate;
		
		console.info('$scope.avmTestData.startdate');console.log($scope.avmTestData.startdate);
		console.info('$scope.avmTestData.enddate');console.log($scope.avmTestData.enddate);
		
		if (isdate(stDate)==1){stDate=convertDate(stDate);}
		else {
			stDate = new Date(stDate.toString());
		}
		if (isdate(enDate)==1){enDate=convertDate(enDate);} 
		else {
			enDate = new Date(enDate.toString());
		}
		if (enDate < stDate){enDate=stDate; $scope.avmTestData.enddate=stDate;}
		$scope.avmTestData.enddate = enDate.getDate() + "-" + (months[enDate.getMonth()]) + "-" + enDate.getFullYear();
		
		if ( $scope.formName == "Add" ) {
			var todayDateTime=new Date();
			var todayDate =todayDateTime.getDate()+ "-" +(months[todayDateTime.getMonth()]) + "-" + todayDateTime.getFullYear();
			if (stDate<todayDate){$scope.sumTestAddData.startdate=todayDate;}
		} else if ( $scope.formName == "Edit" ) {
			// While edit for the test, start date changed to have `true`/`false` to send, 
			var startDateSelectedFormatted = formateDate(stDate);
			if ( avmTestData.formatted_startdate != startDateSelectedFormatted ) {
				// Start date changed date for scheduled test
				$scope.avmTestData.isStartDateChanged = true;
			} else {
				// Start date not changed
				$scope.avmTestData.isStartDateChanged = false;
			}
		}
	};
	
	$scope.setStartOrEndMinsAsZero = function(val) {
		if(val == 'STARTMINS'){
			$scope.avmTestData.startMins = 0;
		}else if(val == 'ENDMINS'){
			$scope.avmTestData.endMins = 0;
		}
	};
	
	function isdate(val)
	{
		var date = Date.parse(val);
		if(isNaN(date))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	function convertDate(date)
	{
		var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
		var splitDate = date.split("-");
		var convertedDate=new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
		return convertedDate;
	}
	
	
	$scope.onlyDigits = function( value ){
		if(value == 'AVM_MINBREACHCOUNT'){
			$scope.avmTestData.avmBreachCount = $scope.avmTestData.avmBreachCount.replace(/[^0-9]/g, '');
		}
	};
	
	$scope.addCities = function() {
		$scope.sumFormSubmitted = true;
		// TODO: thinks, below URL validation to occur manually when user submitted the form, instead of `$scope.$broadcast`
		// calls the function in directive
		$scope.$broadcast('triggerURLValidation');
		
		$scope.avmTestData.startdate = sessionServices.get("start_date");
		$scope.avmTestData.enddate = sessionServices.get("end_date");
		sdateToCompare = $scope.avmTestData.startdate;
		edateToCompare = $scope.avmTestData.enddate;
		var sDate = Date.parse($scope.avmTestData.startdate);
		var eDate = Date.parse($scope.avmTestData.enddate);
		if (isdate(sdateToCompare)==1){sdateToCompare=convertDate(sdateToCompare);}
		if (isdate(edateToCompare)==1){edateToCompare=convertDate(edateToCompare);}
	
		var msgContent = "";
		if (sDate > eDate)
		{
			msgContent ='End Date must be greater than Start Date';
		}
		var isEdit = $scope.formName == 'Edit';
		if ($scope.avmTestData.testName.length==0)
		{
			msgContent = 'Test Name is mandatory.';
		} else if (!$scope.sumAddForm.$valid) {
				msgContent = 'Invalid URL';
		} else if($scope.avmTestData.enableAvailabilityMonitor && ($scope.avmTestData.avmBreachCount == undefined || $scope.avmTestData.avmBreachCount <= 0)){
			msgContent='Please enter Breach Count for Availability Monitor.';
		} else if($scope.avmTestData.responseAlert == undefined || $scope.avmTestData.responseAlert == false ){
			$scope.avmTestData.responseAlert = false;
		}
		
		if ( msgContent.length > 0 ) {
			messageService.showWarningMessage(msgContent);
		} else {
			$rootScope.$on("close_avm_parent_popup", function(event){
				$uibModalInstance.dismiss('cancel');
			});
			
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/avm/add_avm_cities.html',
				controller: 'addAvmCitiesController',
				size: 'lg',
				resolve: {
					avmTestAddData: function() {
						return $scope.avmTestData;
					},
					citiesData: function() {
						return "";
					},
					saveBtn: function() {
						return $scope.saveBtn;
					}
				}
			});
			
			modalInstance.close();
		}
	};
	$scope.addNewRequestHeaderRow = function() {
		$scope.avmTestData.requestHeaders.push({"name":"","value":""});
	};
	
	$scope.removeRequestHeaderRow = function(index) {
		$scope.avmTestData.requestHeaders.splice( index-1, 1 );
	};
	
	$scope.addNewRequestParameterRow = function() {
		if( $scope.avmTestData.requestMethod === 'POST' || $scope.avmTestData.requestMethod === 'PUT' ) {
			$scope.avmTestData.requestParameters.push({"name":"","value":""});
		}
	};
	
	$scope.removeRequestParameterRow = function(index) {
		$scope.avmTestData.requestParameters.splice( index-1, 1 );
	};
		
	$scope.close = function() {
		$uibModalInstance.dismiss('cancel');
   	};

}]);


appedoApp.controller('addAvmCitiesController', ['$scope', '$uibModal', 'avmModuleServices', '$uibModalInstance', 'avmTestAddData', 'citiesData', 'saveBtn', '$rootScope', 'messageService', 
function($scope, $uibModal, avmModuleServices, $uibModalInstance, avmTestAddData, citiesData, saveBtn, $rootScope, messageService) {
	// Controller to add cities for the Availability monitor.
	
	$scope.showSave = false;
	$scope.avmTestAddData = avmTestAddData;
	$scope.saveButton = saveBtn;
	$scope.avmLocation = {};
	
	// If Availability Monitor is disabled then, 
	// No need to fetch existing AVM-Agent-Locations
	if( avmTestAddData.status ) {
		
		avmModuleServices.getUserAgents($scope, (avmTestAddData != null ? avmTestAddData.testid : undefined) , function(data) {
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.userAgents = data.message;
	
				$scope.$watch('avmLocation.userAgent', function() {
	   					$scope.userCities = {};
	   					$scope.counters = {};
	   					if ($scope.avmLocation.userAgent != undefined) {
	   						if ($scope.avmLocation.userAgent.country != undefined) {
	   							$scope.citiesData = $scope.avmLocation.userAgent.cities;
	   						}
	   					}
	   				});
	   			}
	   		});
	
	   	}
	   	
	   /*	$scope.validateCities = function() {
		$scope.showSave = true;
		var cities = 0;
		
		for(var i = 0; i < $scope.userAgents.length; i = i + 1) {
			var userAgentsData = $scope.userAgents[i];
			for(var j=0; j < userAgentsData.cities.length; j=j+1){
				if(userAgentsData.cities[j].isSelected) {
					cities = cities + 1;
				}
			}
		}
		
		if(cities>$scope.maxLocationPerTest){
			$scope.showSave = true;
			messageService.showWarningMessage("Max location per test should not exceed "+$scope.maxLocationPerTest);
		}else{
			$scope.showSave = false;
		}
	};*/
	
	$scope.close = function() {
		$uibModalInstance.dismiss('cancel');
		//$rootScope.$emit('close_sum_cities_popup');
		$uibModalInstance.dismiss();
	};
	
	$scope.saveAVMData = function() {
		var selectedCities = [];
	
		//  Save data..
		console.info('avmTestAddData ...');console.log(avmTestAddData);
		
		// If Availability Monitor is disabled then, 
		// No need to fetch existing AVM-Agent-Locations.
		if( ! avmTestAddData.status ) {	// Availability Monitor is disabled
			$scope.showSave = false;
		} else {						// Availability Monitor is enabled
			$scope.showSave = true;
			
			for(var i = 0; i < $scope.userAgents.length; i = i + 1) {
				var userAgentsData = $scope.userAgents[i];
				for(var j=0; j < userAgentsData.cities.length; j=j+1){
					if(userAgentsData.cities[j].isSelected) {
						selectedCitiesData = {};
						selectedCitiesData.country = $scope.userAgents[i].country;
						selectedCitiesData.state = userAgentsData.cities[j].state;
						selectedCitiesData.city = userAgentsData.cities[j].city;
						selectedCitiesData.region = userAgentsData.cities[j].region;
						selectedCitiesData.zone = userAgentsData.cities[j].zone;
						selectedCitiesData.location = $scope.userAgents[i].country + "--" + userAgentsData.cities[j].city;
						selectedCities.push(selectedCitiesData);
					}
				}
			}
		}
		// Service which saves the avm test
		avmModuleServices.saveAVMData($scope, avmTestAddData, selectedCities, function(responseData) {
			if(responseData.success == true){
				$rootScope.$emit('close_avm_parent_popup');
				$rootScope.$emit('reloadAVMCardLayout');
				$uibModalInstance.dismiss();
				messageService.showSuccessMessage(responseData.message);
			} else {
				messageService.showWarningMessage(responseData.errorMessage);
				$uibModalInstance.dismiss();
				$scope.showSave = false;
			}
		});
	};
	
	// If Availability Monitor is disabled then, 
	// Call the submit without fetching SUM-Locations
	   	function initCitiesLoad() {
	   		if( ! avmTestAddData.status ) {
	   			$scope.showSave = false;
	   			$uibModalInstance.dismiss();
	   			
	   			$scope.saveAVMData();
	   		}
	   	}
	   	initCitiesLoad();
   	
}]);

appedoApp.controller('avmDetailsController', ['$scope', '$rootScope', '$state', 'avmModuleFactory', 'avmModuleServices', /*'appedoDirSliderFactory',*/ '$appedoUtils', 'sessionServices', 'messageService', 
                                              function($scope, $rootScope, $state, avmModuleFactory, avmModuleServices, /*appedoDirSliderFactory,*/ $appedoUtils, sessionServices, messageService) {
   	// Controller for availability monitor details page
   	
   	//$scope.selectedAvmCardContent = JSON.parse(sessionServices.get("selectedAvmCardContent"));
   	$scope.selectedAvmCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
   	
   	//console.info('$scope.selectedAvmCardContent');
   	//console.info($scope.selectedAvmCardContent);
   	//console.log(JSON.stringify($scope.selectedAvmCardContent));
   	
   	//$scope.sliderValue = 2;
   	//$scope.sliderOptions = sumModuleFactory.sliderOptions;
   	
   	$scope.userSummary = {};
   	$scope.locationsStatus = [];
   	
   	$scope.loadingSummary = false;
   	$scope.loadingDownLocations = false;
   	
   	$scope.currentPage = 0;
   	$scope.offsetValueForResfresh = 0;  // Offset Value for Refresh
   	$scope.numPerPage = 10;  // Limit per page value
   	
   	
   	var joSliderOptions = avmModuleFactory.defaultSliderOptions, nSliderValue = 3;
   	// for directive `appedoSlider`, for slider & custom filter
   	//$scope.sliderSettings = appedoDirSliderFactory.getSliderSettings(joSliderOptions, nSliderValue);
   	
   	$scope.AVM_STATUSES = avmModuleFactory.AVM_STATUSES;
   	
   	
   	$scope.backToSUMCardPage = function() {
   		$rootScope.backPageFrom = "AVMDetails";
   		$state.transitionTo('/avm_metrics');
   	};
   	
   	// 
   	$scope.loadAVMData = function() {
   		
   		getUserTestSummary();
   		getTestLocationsStatus($scope.offsetValueForResfresh, (($scope.currentPage + 1)*$scope.numPerPage), true);
   		
   	};
   	$scope.loadAVMData();
   	
   	
   	// Get user's availability monitor summary 
   	function getUserTestSummary() {
   		showLoadingSummary();
   		
   		avmModuleServices.getUserTestSummary($scope.selectedAvmCardContent.testid, function(data) {
   			hideLoadingSummary();
   			
   			if ( ! data.success ) {
   				// err
   				messageService.showErrorMessage(data.errorMessage);
   			} else {
   				$scope.userSummary = data.message;
   			}
   		});
   	}
   	
   	
   	// Gets down locations status 
   	function getTestLocationsStatus(offSet, numPerPage, isRefresh) {
   		if ( $scope.selectedAvmCardContent.status === 'Completed' ) {
   			// for AVM `Completed` test's, not called location status 
   		} else {
   			showLoadingDownLocations();
   			
   			avmModuleServices.getTestLocationsStatus($scope.selectedAvmCardContent.testid, offSet, numPerPage, function(data) {
   				hideLoadingDownLocations();
   				var aryLocationsStatusData = [];
   				if (!data.success) {
   					// err
   					messageService.showErrorMessage(data.errorMessage);
   				} else {
   					// If the function is invoked on refresh clear the array.
   					if(isRefresh){
   						$scope.locationsStatus = [];
   					}
   	
   					aryLocationsStatusData = data.message;
   	
   					if(aryLocationsStatusData.length > 0) {
   						$scope.disableLoadMore = false;
   						for (var i = 0; i < aryLocationsStatusData.length; i++) {
   							$scope.locationsStatus.push(aryLocationsStatusData[i]);
   						}
   					} else {
   						$scope.disableLoadMore = true;
   					}
   				}
   			});
   		}
   	}

   	// Load more 
   	$scope.loadMore = function() {
   		$scope.currentPage++;
   	    $scope.offSet = ($scope.currentPage * $scope.numPerPage);
   	    getTestLocationsStatus($scope.offSet, $scope.numPerPage, false);
   	};
   	
   	
   	function showLoadingSummary() { $scope.loadingSummary = true; }
   	function hideLoadingSummary() { $scope.loadingSummary = false; }
   	function showLoadingDownLocations() { $scope.loadingDownLocations = true; }
   	function hideLoadingDownLocations() { $scope.loadingDownLocations = false; }
}]);


                                       appedoApp.controller('avmDashboardController', ['$scope', 'avmModuleFactory', 'avmModuleServices', 'sessionServices', '$rootScope', 'messageService', '$appedoUtils', 
                                       											function($scope, avmModuleFactory, avmModuleServices, sessionServices, $rootScope, messageService, $appedoUtils) {
                                       	$scope.userSummary = {};
                                       	$scope.downLocationsStatus = [];
                                       	$scope.applicationsStatus = [];
                                       	var timerRefreshDashboard;
                                       	
                                       	$scope.loadingSummary = false;
                                       	$scope.loadingDownLocations = false;
                                       	$scope.loadingApplicationsStatus = false;
                                       	
                                       	$scope.currentPage = 0;
                                       	$scope.offsetValueForResfresh = 0;  // Offset Value for Refresh
                                       	$scope.numPerPage = 10;  // Limit per page value
                                       	
                                       	$scope.disableLoadMore = false;
                                       	
                                       	$scope.AVM_STATUSES = avmModuleFactory.AVM_STATUSES;
                                       	
                                       	/*// onchange of selection radio buton
                                       	$scope.loadSelectedTypePanel = function() {
                                       		// clears timer
                                       		clearTimeout(timerRefreshDashboard);
                                       	};*/
                                       	
                                       	// Get user's availability monitor summary 
                                       	function getAVMUserDashboardSummary() {
                                       		showLoadingSummary();
                                       		
                                       		avmModuleServices.getAVMUserDashboardSummary(function(data) {
                                       			hideLoadingSummary();
                                       			
                                       			if ( ! data.success ) {
                                       				// err
                                       				messageService.showErrorMessage(data.errorMessage);
                                       			} else {
                                       				$scope.userSummary = data.message;
                                       			}
                                       		});
                                       	}
                                       	// getAVMUserDashboardSummary();
                                       	
                                       	// Gets down locations status 
                                       	function getUserDownLocationsStatus(offSet, numPerPage, isRefresh) {
                                       		showLoadingDownLocations();

                                       		avmModuleServices.getUserDownLocationsStatus($scope, offSet, numPerPage, function(data) {
                                       			hideLoadingDownLocations();
                                       			var downLocationsStatusData = [];
                                       			if (!data.success) {
                                       				// err
                                       				messageService.showErrorMessage(data.errorMessage);
                                       			} else {
                                       				// If the function is invoked on refresh clear the array.
                                       				if(isRefresh){
                                       					$scope.downLocationsStatus = [];
                                       				}

                                       				downLocationsStatusData = data.message;

                                       				if(downLocationsStatusData.length > 0) {
                                       					$scope.disableLoadMore = false;
                                       					for (var i = 0; i < downLocationsStatusData.length; i++) {
                                       						$scope.downLocationsStatus.push(downLocationsStatusData[i]);
                                       					}
                                       				}else{
                                       					$scope.disableLoadMore = true;
                                       				}
                                       			}
                                       		});
                                       	}
                                       	// getDownLocationsStatus();
                                       	
                                       	// Load more 
                                       	$scope.loadMore = function() {
                                       		$scope.currentPage++;
                                       	    $scope.offSet = ($scope.currentPage * $scope.numPerPage);
                                       	    getUserDownLocationsStatus($scope.offSet , $scope.numPerPage, false);
                                       	};
                                       	
                                       	// gets user's applications status 
                                       	function getUserApplicationsStatus() {
                                       		showApplicationsStatus();
                                       		
                                       		avmModuleServices.getUserApplicationsStatus(function(data) {
                                       			hideApplicationsStatus();
                                       			
                                       			if ( ! data.success ) {
                                       				// err
                                       				messageService.showErrorMessage(data.errorMessage);
                                       			} else {
                                       				$scope.applicationsStatus = data.message;
                                       			}
                                       		});
                                       	}
                                       	
                                       	
                                       	$scope.refreshDashbaordData = function() {
                                       		clearTimeout(timerRefreshDashboard);
                                       		
                                       		getAVMUserDashboardSummary();
                                       		getUserDownLocationsStatus($scope.offsetValueForResfresh, (($scope.currentPage + 1)*$scope.numPerPage), true);
                                       		getUserApplicationsStatus();
                                       		
                                       		timerRefreshDashboard = setTimeout($scope.refreshDashbaordData, sessionServices.get("graphRefresh"));
                                       	};
                                       	$scope.refreshDashbaordData();
                                       	
                                       	
                                       	function showLoadingSummary() { $scope.loadingSummary = true; }
                                       	function hideLoadingSummary() { $scope.loadingSummary = false; }
                                       	function showLoadingDownLocations() { $scope.loadingDownLocations = true; }
                                       	function hideLoadingDownLocations() { $scope.loadingDownLocations = false; }
                                       	function showApplicationsStatus() { $scope.loadingApplicationsStatus = true; }
                                       	function hideApplicationsStatus() { $scope.loadingApplicationsStatus = false; }
                                       	
                                       	$scope.$on('$destroy', function() {
                                       		clearTimeout(timerRefreshDashboard);
                                       	});
                                       }]);


appedoApp.controller('addAVMMyLocationsController', ['$scope', '$rootScope', '$uibModalInstance', 'avmModuleServices', 'isFrom', 'locationDetails', 'moduleCardContent',  'sessionServices', 'messageService', 
  function($scope, $rootScope, $uibModalInstance, avmModuleServices, isFrom, locationDetails, moduleCardContent, sessionServices, messageService) {
   	
   	$scope.avmLocationFormData = {};
   	$scope.disableLocationSaveButton = false;
   	
   	$scope.hasFromAdd = (isFrom === 'fromAdd');
   	
   	$scope.close = function () {
   		$uibModalInstance.dismiss('cancel');
   	};
   	
   	if ( ! $scope.hasFromAdd ) {
   		// edit, sets
   		$scope.avmLocationFormData.country = locationDetails.country;
   		$scope.avmLocationFormData.state = locationDetails.state;
   		$scope.avmLocationFormData.city = locationDetails.city;
   		$scope.avmLocationFormData.region = locationDetails.region;
   		$scope.avmLocationFormData.zone = locationDetails.zone;
   		$scope.avmLocationFormData.agentId = locationDetails.agentId;
   		$scope.avmLocationFormData.private = locationDetails.isPrivate;
   	} else {
   		// add 
   		
   		// default
   		$scope.avmLocationFormData.private = true;
   	}
   	
   	
   	$scope.saveAgentLocation = function() {
   		
   		if( $scope.avmAddMyLocationsForm.$valid ) {
   			$scope.disableLocationSaveButton = true;
   			
   			avmModuleServices.saveAgentLocation($scope.hasFromAdd, $scope.avmLocationFormData, function (data) {
   				$scope.disableLocationSaveButton = false;
   				
   				if( ! data.success ){
   					// err
   					messageService.showErrorMessage(data.errorMessage);
   				} else {
   					messageService.showSuccessMessage(data.message);
   					
   					// loads AVM user's locations 
   					$rootScope.$emit('loadAVMUserLocations');
   					
   					// close
   					$scope.close();
   					
   					// opens window, of location's view added alert addresses, when site is down or location_agent is down
   					avmModuleServices.openLocationToAlertAddresses(data.agentId, moduleCardContent);
   				}
   			});
   		}
   	};
   	/*
   	$scope.changeAgentType = function() {
   		console.info('changeAgentType() return false');
   		return false;
   	};*/
   	
}]);


appedoApp.controller('avmLocationViewToAlertAddressesController', ['$scope', '$rootScope', '$uibModalInstance', 'avmModuleServices', 'agentId', 'moduleCardContent', 'sessionServices', 'messageService', 
   											function($scope, $rootScope, $uibModalInstance, avmModuleServices, agentId, moduleCardContent, sessionServices, messageService) {
   	
   	/*
   	 * Note: view alert addresses used same grid template for SLA & AVM location's alert addresses;
   	 *   used same variable & fn. name of `$scope.alertAddresses`, `$scope.addAlertAddress`, `$scope.deleteAlertAddress` & `$scope.closeAlertTypeListPage`
   	 */
   	
   	$scope.moduleCardContent = moduleCardContent;
   	
   	//$scope.locationDetails = locationDetails;
   	$scope.locationDetails = {};
   	
   	// to alert addresses; Note: `$scope.alertAddresses` same name used for SLA alert addresses & Location alert addresses, since same grid template used 
   	$scope.alertAddresses = [];
   	
   	$scope.loadingAlertAddresses = false;
   	
   	$scope.close = function () {
   		$uibModalInstance.dismiss('cancel');
   	};
   	
   	$scope.closeAlertTypeListPage = function() {
   		$uibModalInstance.dismiss('cancel');
   	};
   	
   	// gets agent's/location's details 
   	function getLocationDetails() {
   		avmModuleServices.getLocationDetails(agentId, function(data) {
   			
   			if( ! data.success ) {
   				// err 
   				messageService.showErrorMessage(data.errorMessage);
   			} else {
   				$scope.locationDetails = data.message;
   			}
   		});
   	}
   	getLocationDetails();
   	
   	
   	// gets to alert addresses 
   	function getLocationAlertAddresses() {
   		showLoadingAlertAddresses();
   		
   		var alertGrid;
   		alertGrid = avmModuleServices.getLocationAlertAddresses(agentId);	
   		alertGrid.then(function(data) {
   			hideLoadingAlertAddresses();

   			if( ! data.success ) {
   				// err 
   				messageService.showErrorMessage(data.errorMessage);
       		} else {
       			$scope.alertAddresses = data.message;
       		}
   		});
   	}
   	getLocationAlertAddresses();
   	
   	// adds alert address, open window alert address form 
   	$scope.addAlertAddress = function() {
   		// closes current 
   		$scope.close();
   		
   		avmModuleServices.openLocationAddAlertAddress($scope.locationDetails, moduleCardContent);
   	};
   	
   	// deletes alert address 
   	$scope.deleteAlertAddress = function(joAlertAddress){
   		var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
   		if(result == true) {
   			var deleteAlert;
   			deleteAlert = avmModuleServices.deleteLocationAlertAddress(joAlertAddress.alertId, agentId);
   			deleteAlert.then(function(data) {
   				
   				if ( ! data.success ) {
   					// err
   					messageService.showErrorMessage(data.errorMessage);
   				} else {
   					messageService.showSuccessMessage(data.message);
   					
   					// gets to alert addresses
   					getLocationAlertAddresses();
   				}
   			}); 
   		}
   	};
   	
   	function showLoadingAlertAddresses() { $scope.loadingAlertAddresses = true; }
   	function hideLoadingAlertAddresses() { $scope.loadingAlertAddresses = false; }
}]);

appedoApp.controller('avmLocationAddAlertAddressController', ['$scope', '$rootScope', '$uibModalInstance', 'avmModuleServices', 'locationDetails', 'moduleCardContent', 'successMsgService', 'messageService',
	function($scope, $rootScope, $uibModalInstance, avmModuleServices, locationDetails, moduleCardContent, successMsgService, messageService) {
       	/*
       	 * Note: add alert address form used same template for SLA and AVM location add alert address;
       	 *  used same varaiable & fn. name of `$scope.addAlertAddressForm`, `$scope.disableAddButton`, `$scope.saveAlertAddress`, `$scope.openSettingsToAlertAddresses`,
       	 *    in controllers `slaSettingAlert`, `avmLocationAddAlertAddressController`
       	 */
       	
       	$scope.moduleCardContent = moduleCardContent;
       	$scope.locationDetails = locationDetails;
       	
       	/* Note: dont change display names as common for SLA & AVM alert type, */
       	$scope.alertTypes = [{ displayName: 'Email', value: 'EMAIL' }, { displayName: 'SMS', value: 'SMS' }];
       	
       	$scope.addAlertAddressForm = {};
       	// default `Email` type 
       	$scope.addAlertAddressForm.alertType = $scope.alertTypes[0];
       	//$scope.addAlertAddressForm.alertType = "Email";
       	
       	$scope.disableAddButton = false;
       	
       	
       	$scope.close = function () {
       		$uibModalInstance.dismiss('cancel');
       	};
       	
       	// opens window, of location's view added alert addresses 
       	$scope.openSettingsToAlertAddresses = function() {
       		$scope.close();
       		
       		// opens window, of location's view added alert addresses, when site is down or location_agent is down
       		avmModuleServices.openLocationToAlertAddresses($scope.locationDetails.agentId, moduleCardContent);
       	};
       	
       	// save alert address 
       	$scope.saveAlertAddress = function(bOpenAlertAddresses) {
       		disableAddAlertButton();
       		
       		// must save the record
       		var alerts;
       		alerts = avmModuleServices.addLocationAlertAddress($scope.locationDetails.agentId, $scope.locationDetails.guid, $scope.addAlertAddressForm);
       		alerts.then(function(data) {
       			enableAddAlertButton();
       			
       			if( ! data.success ) {
       				// err 
       				messageService.showErrorMessage(data.errorMessage);
           		} else {
           			if ( ! data.emailSent ) {
           				// address might already verfied or for SMS default verified 
           				messageService.showSuccessMessage(data.message);	
           			} else {
           				// for added email, verification email is sent for verification 
           				messageService.showWarningMessage(data.message+'<BR>Check the inbox/spam/junk for the verification mail.<BR>Click on the link given in the email.', {dismissOnTimeout: false, dismissOnClick: false, additionalClasses: 'apd-alert-msg'});	
           			}
       				
       				
       				if ( bOpenAlertAddresses ) {	// opens added alert addresses window
       					
       					/*$rootScope.$on("close_sla_setting_parent_popup", function(event){
       		    			$uibModalInstance.dismiss('cancel');
       		    		});*/
       					
       					
       					// closes & open SLA settings to alert email/SMS addresses
       					$scope.openSettingsToAlertAddresses();
       				} else {	// remains same screen, add alert addresses
       					
       					$scope.addAlertAddressForm.emailOrMobileAddress = '';
       					//$scope.validtaeForm();
       				}
           		}
           	});
       	};
       	
    function enableAddAlertButton() { $scope.disableAddButton = false; }
    function disableAddAlertButton() { $scope.disableAddButton = true; }
}]);
                                   
   appedoApp.controller( 'sumSummaryController', ['$scope', 'sumModuleServices', 'sessionServices', function( $scope, sumModuleServices, sessionServices) {
	
	var resultSUMLicense = sumModuleServices.getSUMLicense();
	resultSUMLicense.then(function(resp) {
		$scope.summarydata = resp;
	});

	var resultDonutChartData;
	resultDonutChartData = sumModuleServices.getDonutChartdata("TestStatus");
	resultDonutChartData.then(function(resp) {
		if(resp!=undefined){
			if(resp.success){
				$scope.cTextCompletedDonutData = findAndRemove(resp.message,'label','Total');
				$scope.completedDonutData=resp.message;
			}else{
				$scope.completedDonutData=JSON.parse(sessionServices.get("noRecordForDonut"));
			}
		}
	});
	
	resultDonutChartData="";
	resultDonutChartData = sumModuleServices.getDonutChartdata("Mst");
	resultDonutChartData.then(function(resp) {
		if(resp!=undefined){
				if(resp.success){
				$scope.cTextAvailableDonutData = findAndRemove(resp.message,'label','Total');
					$scope.availableDonutData=resp.message;
			}else{
				$scope.availableDonutData=JSON.parse(sessionServices.get("noRecordForDonut"));
			}
		}
	});
	
	resultDonutChartData="";
	resultDonutChartData = sumModuleServices.getDonutChartdata("TestType");
	resultDonutChartData.then(function(resp) {
		if(resp!=undefined){
			if(resp.success){
				$scope.cTextUrlDonutData = findAndRemove(resp.message,'label','Total');
				$scope.urlDonutData=resp.message;
			}else{
				$scope.urlDonutData=JSON.parse(sessionServices.get("noRecordForDonut"));
			}
		}
	});
}]) ;

function findAndRemove(array, property, value) {
	var cTextInfiStatus=0;
	$.each(array, function(index, result) {
		if(result[property] == value) {
			//Remove from array
			array.splice(index, 1);
			cTextInfiStatus=-1;
		}
	});
	return cTextInfiStatus;
}

function findAndCreate(array, property, value) {
	var newArray = [];
	$.each(array, function(index, result) {
		if(result[property] == value) {
			newArray.push(result);
		}
	});
	return newArray;
}

appedoApp.controller('sumHomeController', ['$scope', '$uibModal', 'sumModuleServices', 'ngToast', 'sessionServices', '$state', '$rootScope', 'messageService', '$appedoUtils', function($scope, $uibModal, sumModuleServices, ngToast, sessionServices, $state, $rootScope, messageService, $appedoUtils) {
	$scope.sumTests = [];
	var aryUserSUMTests = [];
	
	// SUM status
	$scope.arySUMStatus = [{label: "Running", selected: true, count: 0}, {label: "Scheduled", selected: true, count: 0}, {label: "Completed", selected: true, count: 0}, {label: "Disabled", selected: true, count: 0}];
	
	$scope.showCardEmptyMsg = false;
	
	//default dashboard
	if ( $rootScope.backPageFrom == 'SUMDetails' || $rootScope.backPageFrom == '360View' ) {
		$scope.selectedSUMRadioValue = "SUMPanel";
		//$rootScope.backPageFrom = '';
	} else {
		$scope.selectedSUMRadioValue = "DASHBOARD";
	}
	// reset, since on refresh, to be in `Dashboard` Panel
	$rootScope.backPageFrom = '';
	
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('SUM Card Layout', 'pageOpen', 
		{
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	$scope.openAddModuleType = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
	
	$scope.getSUMTests = function() {
		sumModuleServices.getSUMUserTests(function(data) {
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				aryUserSUMTests = data.message;
				$scope.sumTests = aryUserSUMTests;
				// the SUM status has been selected, on click the status from from `360 View` in `Synthetic User Summary`->`Test Status`
				var selectedSUMStatus = $rootScope.selectedSUMStatus || '';
				// reset, since on refresh, to load default all tests
				$rootScope.selectedSUMStatus = '';
				
				// to show cardlayout OR blank page description content
				if( $scope.sumTests.length === 0 ) {
					// blank page content
					$scope.showCardEmptyMsg = true;
				} else {
					// to show cardlayout 
					$scope.showCardEmptyMsg = false;
				}
				
				// reset all status as selected & calc status's count, added since on SUMTest add, after added to show all status's data
				resetStatusAllSelection(selectedSUMStatus);
				// to show respective status's Test(s); Note: the selected status is made as `selected:true` in `resetStatusAllSelection`
				if ( selectedSUMStatus.length > 0 ) {
					$scope.getSelectedSUMStatuses();
				}
			}
		});
	};
	$scope.getSUMTests();
	
	// filter's selected status's SUM tests
	$scope.getSelectedSUMStatuses = function() {
		var arySelectedStatus = [], arySelectedStatusSUMTests = [];
		
		// has selected status in ary, say ["Running, "Scheduled"], Note: "Running, "Scheduled" are selected from dropdown
		arySelectedStatus = $appedoUtils.filteredOptions($scope.arySUMStatus);
		
		// filter's selected status's SUM tests
		for (var i = 0; i < aryUserSUMTests.length; i = i + 1) {
			var joTest = aryUserSUMTests[i];
			if ( arySelectedStatus.indexOf( joTest.status ) >= 0 ) {
				arySelectedStatusSUMTests.push( joTest );
			}
		}
		
		// sets filtered SUM Tests
		$scope.sumTests = arySelectedStatusSUMTests;
	};
	
	// reset all status as selected true
	function resetStatusAllSelection(selectedSUMStatus) {
		// calc user's SUM Tests status wise count; Note: key in `joStatusWiseCount` has to match with `label` property in `$scope.arySUMStatus`
		var joStatusWiseCount = {"Running": 0, "Scheduled": 0, "Completed": 0, "Disabled": 0};
		for (var i = 0; i < aryUserSUMTests.length; i = i + 1) {
			var joTest = aryUserSUMTests[i];
			joStatusWiseCount[joTest.status] = joStatusWiseCount[joTest.status] + 1;
		};
		
		// sets selected true and respective status's count
		for (var i = 0; i < $scope.arySUMStatus.length; i = i + 1) {
			var joStatus = $scope.arySUMStatus[i];
			// since, to show selected status condition added; Note: the status has been selected from `360 View` in `Synthetic User Summary`->`Test Status`
			joStatus.selected = selectedSUMStatus.length > 0 ? (joStatus.label === selectedSUMStatus) : true;
			joStatus.count = joStatusWiseCount[joStatus.label];
		};
	}
	
	// tried, cardlayout SUM Test's hover title, for browser multiple selection to have respective selected browsers title 
	$scope.hoverSUMTestBrowserTitle = function() {
		var sumTest = this.test, titleBrowsers = '';
		
		for(var i = 0; i < sumTest.browserDetails.length; i = i + 1) {
			var joBrowserDetails = sumTest.browserDetails[i];
			
			if ( i !== 0) {
				titleBrowsers += ', ';
			}
			
			titleBrowsers += joBrowserDetails.browserName;
		}
		
		return titleBrowsers;
	};
	
	
	//for refresh the card layout after Add/Update
	var sumCard = $rootScope.$on("reloadSUMCardLayout", $scope.getSUMTests);
	$scope.$on('$destroy', sumCard);
	/*var reload = $rootScope.$on("close_sum_parent_popup", function(event){
		sumModuleServices.getSUMUserTests(function(data) {
			$scope.sumTests = data.message;
		});
		event.preventDefault();
		reload();
	});*/
	
	$scope.deleteSelectedSum = function(index) {
		var result = confirm("You will lose sum records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			sumModuleServices.deleteSumRecord($scope, this.test.testid, this.test.testtype, true, function (response) {
				if( response.success ){
					messageService.showSuccessMessage(response.message);
					//$scope.sumTests.splice(index,1);
					
					$scope.getSUMTests();
				} else {
					messageService.showWarningMessage(response.errorMessage);
				}
			});
		}
	};
	
//                                    		$scope.editSum = function() {
//                                    			var testData = this.test;
//                                    			var modalInstance = $uibModal.open({
//                                    				templateUrl: 'modules/sum/view/add_sum_test.html',
//                                    				controller: 'addSumController',
//                                    				size: 'lg',
//                                    				resolve: {
//                                    					isFrom: function() {
//                                    						return 'fromEdit';
//                                    					},
//                                    					sumTestData: function() {
//                                    						return testData;
//                                    					}, moduleCardContent: function() {
//                                    						return null;
//                                    					}
//                                    				}
//                                    			});
//                                    		};
	
	$scope.editSum = function() {
		var testData = this.test;
		
		var modalInstance = $uibModal.open({
			templateUrl: 'modules/sum/view/add_sum.html',
			controller: 'sumAddController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return 'fromEdit';
				},
				sumTestData: function() {
					return testData;
				}, moduleCardContent: function() {
					return null;
				}
			}
		});
	};
	$scope.openModuleDetailGrpahs = function(index) {
		sessionServices.set("selectedSumCardContent", JSON.stringify(this.test));
		$state.transitionTo('/sum_details');
	};
}]);

appedoApp.controller('addSumController', ['$scope', '$uibModal', 'sumModuleServices', '$uibModalInstance', 'isFrom', 'sumTestData', 'moduleCardContent', 'ngToast', '$rootScope', 'successMsgService', 'sessionServices',
function($scope, $uibModal, sumModuleServices, $uibModalInstance, isFrom, sumTestData, moduleCardContent, ngToast, $rootScope, successMsgService,sessionServices) {
	$scope.close = function() {
		$uibModalInstance.dismiss('cancel');
	};
	
	$scope.moduleCardContent = moduleCardContent;
	$scope.curdate;
	$scope.today = function() {
		months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		currentDate = new Date();
		$scope.curdate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
		};
	$scope.today();

	function formateDate(date){
			months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			currentDate = date;
			var formatedDate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
			return formatedDate;
	};
	$scope.sumTestAddData = {};
	//$scope.showProceed = true;
	$scope.dupCheck = true;
	$scope.sumNameIconCheck = function(event) {
		if($scope.sumTestAddData.testName != undefined || $scope.sumTestAddData.testName != ""){
			$scope.dupCheck = true;
		} 
	};
	$scope.showAddModuleErrorMsg = false;
	$rootScope.$on("close_sum_current_popup", function(event, responseData){
		$scope.showAddModuleErrorMsg = true;
		$scope.AddModuleErrorMsg = responseData.errorMessage.errorMessage;
	});
	$scope.validateSUMTestName = function () {
		if($scope.sumTestAddData.testName != undefined && $scope.sumTestAddData.testName != ""){
			$scope.dupCheck = false;
			sumModuleServices.validateSUMTestName($scope, $scope.sumTestAddData.testName, $scope.sumTestAddData.testid, function(data) {
				if(data.success){
					$scope.showProceed = data.isvalid;
					if(data.isvalid){
						$scope.response ={};
						$scope.response.success = false;
						$scope.response.errorMessage = $scope.sumTestAddData.testName+" already exists.";
						successMsgService.showSuccessOrErrorMsg($scope.response);
					}
				}else{
					$scope.showProceed = true;
				}
			});
		}
	};
	
	//$scope.sumTestAddData = {};
	if(isFrom == 'fromEdit') {
		$scope.userSelectedCities = {};
		$scope.sumTestAddData.testid = sumTestData.testid;
		$scope.sumTestAddData.testName = sumTestData.testname;
		$scope.sumTestAddData.tranasctionImports = sumTestData.trasnactionImports;
		$scope.sumTestAddData.transaction = sumTestData.testtransaction;
		$scope.sumTestAddData.url = sumTestData.testurl;
		$scope.sumTestAddData.runEveryMinutes = sumTestData.runevery;
		$scope.sumTestAddData.testType = sumTestData.testtype;
		$scope.sumTestAddData.status = sumTestData.originalstatus;
		$scope.sumTestAddData.startdate = formateDate(new Date(sumTestData.startdate));
		$scope.sumTestAddData.enddate = formateDate(new Date(sumTestData.enddate));
		$scope.sumTestAddData.slaId = sumTestData.slaId;
		var editDta = $scope.sumTestAddData;
		var citiesData = sumTestData.cities;
		$scope.formName = "Edit";
		$scope.saveBtn = "Update";
		$scope.validateSUMTestName();
		$scope.disableUrlRadio = true;
	} else {
		$scope.formName = "Add";
		$scope.sumTestAddData.testName= "";
		$scope.sumTestAddData.testType = "URL";
		$scope.sumTestAddData.startdate = $scope.curdate;//new Date();
		$scope.sumTestAddData.enddate = $scope.curdate;	//new Date();
		$scope.sumTestAddData.runEveryMinutes = "60";
		$scope.sumTestAddData.url = 'http://';
		$scope.sumTestAddData.status = true;
		$scope.saveBtn = "Save";
		
		// gets default transaction imports, TODO: thinks load Constants as 1 time process either while refreshing or after login
		sumModuleServices.getPackages($scope);
	}
	$scope.sumFormSubmitted = false;
	$scope.appendHttpPrefix = function() {
		var urlregex = new RegExp(sessionServices.get("webURLValidation"),"i");
		$scope.showInfoHttpAppended = false;
		$scope.showHttpMsg = false;
		$scope.showInValidUrlMsg = false;
		if( !/^(http):\/\//i.test($scope.sumTestAddData.url) && !/^(https):\/\//i.test($scope.sumTestAddData.url) ) {
			$scope.sumTestAddData.url = 'http://';
			$scope.showInfoHttpAppended = true;
			$scope.showHttpMsg = true;
			$scope.showInValidUrlMsg = false;
		} else {
			$scope.showHttpMsg = false;
			$scope.showInValidUrlMsg = false;
			if( !urlregex.test($scope.sumTestAddData.url)) {
				$scope.showInfoHttpAppended = true;
				$scope.showHttpMsg = false;
				$scope.showInValidUrlMsg = true;
			} else {
				$scope.showInfoHttpAppended = false;
				$scope.showHttpMsg = false;
				$scope.showInValidUrlMsg = false;
			}
		}
	};
	
	
	$scope.setEndDateAsStartDate = function() {
		stDate=$scope.sumTestAddData.startdate;
		enDate=$scope.sumTestAddData.enddate;
		if (isdate(stDate)==1){stDate=convertDate(stDate);}
		else {
			stDate = new Date(stDate.toString());
		}
		if (isdate(enDate)==1){enDate=convertDate(enDate);} 
		else {
			enDate = new Date(enDate.toString());
		}
		if (enDate < stDate){enDate=stDate; $scope.sumTestAddData.enddate=stDate;}
		$scope.sumTestAddData.enddate = enDate.getDate() + "-" + (months[enDate.getMonth()]) + "-" + enDate.getFullYear();
		
		if ($scope.formName=="Add")
		{
			var todayDateTime=new Date();
			var todayDate = todayDateTime.getDate()+ "-" +(months[todayDateTime.getMonth()]) + "-" + todayDateTime.getFullYear();
			if (stDate<todayDate){$scope.sumTestAddData.startdate=todayDate;}
		}
	};
	
	function isdate(val)
	{
		var date = Date.parse(val);
		if(isNaN(date))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function convertDate(date)
	{
		var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
		var splitDate = date.split("-");
		var convertedDate=new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
		return convertedDate;
	}

	$rootScope.$on("close_sum_cities_popup", function(event){
		sumModuleServices.getPackages($scope);
	});
	
	$scope.addCities = function() {
		$scope.sumFormSubmitted = true;
		// TODO: thinks, below URL validation to occur manually when user submitted the form, instead of `$scope.$broadcast`
		// calls function in directive
		if ( $scope.sumTestAddData.testType === 'URL') {
			$scope.$broadcast('triggerURLValidation');
			
		}
		$scope.sumTestAddData.startdate = sessionServices.get("start_date");
		$scope.sumTestAddData.enddate = sessionServices.get("end_date");
		sdateToCompare = $scope.sumTestAddData.startdate;
		edateToCompare = $scope.sumTestAddData.enddate;
		var sDate = Date.parse($scope.sumTestAddData.startdate);
		var eDate = Date.parse($scope.sumTestAddData.enddate);
		if (isdate(sdateToCompare)==1){sdateToCompare=convertDate(sdateToCompare);}
		if (isdate(edateToCompare)==1){edateToCompare=convertDate(edateToCompare);}

		var msgContent = "";
		if (sDate > eDate)
		{
			msgContent ='End Date must be greater than Start Date';
		}
		if (!$scope.sumAddForm.$valid) {
			if($scope.sumTestAddData.testType == 'URL') {
				msgContent=msgContent+'Invalid URL';
			} else if($scope.sumTestAddData.testType == 'TRANSACTION'){
				if($scope.sumTestAddData.tranasctionImports == undefined || $scope.sumTestAddData.tranasctionImports == '') {
					msgContent=msgContent+'Must enter packages.';
				}
				if($scope.sumTestAddData.transaction == undefined || $scope.sumTestAddData.transaction == '') {
					msgContent=msgContent+'Must enter transaction.';
//                                    						msgContent = 'Please enter Test Name & URL to proceed.';
				}
			}
		}
		if ($scope.sumTestAddData.testName.length==0) {
			msgContent='Test Name is mandatory.';
//                                    				msgContent = 'Please enter Test Name & URL to proceed.';
		}
		if (sDate > eDate || ($scope.sumAddForm.$valid==false && $scope.sumTestAddData.testType == 'URL')
			|| ($scope.sumAddForm.$valid==false && ($scope.sumTestAddData.tranasctionImports == undefined || $scope.sumTestAddData.tranasctionImports == ''))
			|| ($scope.sumAddForm.$valid==false && ($scope.sumTestAddData.transaction == undefined || $scope.sumTestAddData.transaction == ''))
			|| $scope.sumTestAddData.testName.length==0)
		{
			ngToast.create({
				className: 'warning',
				content: msgContent,
				timeout: 5000,
				dismissOnTimeout: true,
				dismissButton: true,
				animation: 'fade'
			});
		} 
		else 
		{
			$rootScope.$on("close_sum_parent_popup", function(event){
				$uibModalInstance.dismiss('cancel');
			});
			
			/*if($scope.sumTestAddData.testType == "URL"){
				$scope.sumTestAddData.transaction = '';
			} else {
				$scope.sumTestAddData.url = '';
			}*/
			var modalInstance = $uibModal.open({
				templateUrl: 'modules/sum/view/add_sum_cities.html',
				controller: 'addSumCitiesController',
				size: 'lg',
				resolve: {
					sumTestAddData: function() {
						return $scope.sumTestAddData;
					},
					citiesData: function() {
						return citiesData;
					},
					saveBtn: function() {
						return $scope.saveBtn;
					}
				}
			});
		}
	};
}]);

appedoApp.controller('addSumCitiesController', ['$scope', '$uibModal', 'sumModuleServices', '$uibModalInstance', 'sumTestAddData', 'citiesData', 'saveBtn', '$rootScope', 'messageService',
	function($scope, $uibModal, sumModuleServices, $uibModalInstance, sumTestAddData, citiesData, saveBtn, $rootScope, messageService) {
		$scope.showSave = false;
		var dobId = sumTestAddData.browser;
		
		$scope.sumTestAddData = sumTestAddData;
		
		// if Response Monitor is disabled then, 
		// No need to fetch existing SUM-Locations
		if( sumTestAddData.status ) {
			sumModuleServices.getUserNodes($scope, (sumTestAddData != null ? sumTestAddData.testid : undefined), dobId, function(data) {
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.userNodes = data.message;
					$scope.$watch('sumLocation.userNode', function() {
						$scope.userCities = {};
						$scope.counters = {};
						if ($scope.sumLocation.userNode != undefined) {
							if ($scope.sumLocation.userNode.country != undefined) {
								$scope.citiesData = $scope.sumLocation.userNode.cities;
							}
						}
					});
				}
			});
			
			sumModuleServices.getMaxLocation(function(data){
				if(data.success){
					$scope.maxLocationPerTest = data.max_location;
				}
			});
			
			$scope.userNodes = sumModuleServices.getUserNodesData();
		}
		
		$scope.validateCities = function() {
			$scope.showSave = true;
			var cities = 0;
			
			for(var i = 0; i < $scope.userNodes.length; i = i + 1) {
				var userNodesData = $scope.userNodes[i];
				for(var j=0; j < userNodesData.cities.length; j=j+1){
					if(userNodesData.cities[j].isSelected) {
						cities = cities + 1;
					}
				}
			}
			
			if(cities>$scope.maxLocationPerTest){
				$scope.showSave = true;
				messageService.showWarningMessage("Max location per test should not exceed "+$scope.maxLocationPerTest);
			}else{
				$scope.showSave = false;
			}
		};
		
		$scope.close = function() {
			$uibModalInstance.dismiss('cancel');
			//$rootScope.$emit('close_sum_cities_popup');
			$uibModalInstance.dismiss();
		};
		
		$scope.saveButton = saveBtn;
		$scope.sumLocation = {};
		$scope.saveSumData = function() {
			var selectedCities = [];
			
			// if Response Monitor is disabled then, 
			// No need to fetch existing SUM-Locations
			if( ! sumTestAddData.status ) {	// Response Monitor is disabled
				$scope.showSave = false;
			} else {						// Response Monitor is enabled
				$scope.showSave = true;
				if(sumTestAddData.testType == "URL"){
					sumTestAddData.transaction = '';
					sumTestAddData.tranasctionImports = '';
				} else {
					sumTestAddData.url = '';
				}
				
				for(var i = 0; i < $scope.userNodes.length; i = i + 1) {
					var userNodesData = $scope.userNodes[i];
					for(var j=0; j < userNodesData.cities.length; j=j+1){
						if(userNodesData.cities[j].isSelected) {
							selectedCitiesData = {};
							selectedCitiesData.city = $scope.userNodes[i].country + " - " + userNodesData.cities[j].city;
							selectedCitiesData.location = $scope.userNodes[i].country + "--" + userNodesData.cities[j].city;
							selectedCities.push(selectedCitiesData);
						}
					}
				}
			}
			
			sumModuleServices.saveNewSumData($scope, sumTestAddData, selectedCities, function(responseData) {
				if(responseData.success == true){
					$rootScope.$emit('close_sum_parent_popup');
					$rootScope.$emit('reloadSUMCardLayout');
					$uibModalInstance.dismiss();
				} else if(responseData.errorMessage != null && responseData.errorMessage.errorType == 'Compilation error(s). Unable to proceed.'){
					$rootScope.$emit('close_sum_current_popup', responseData);
					$scope.showSave = false;
					$uibModalInstance.dismiss();
				}
				
				if( responseData.success ){
					messageService.showSuccessMessage(responseData.message);
				}else if(responseData.errorMessage != null && responseData.errorMessage.errorType == 'Compilation error(s). Unable to proceed.'){
					messageService.showWarningMessage(responseData.errorMessage.errorType);
					$scope.showSave = false;
				} else {
					messageService.showWarningMessage(responseData.errorMessage);
					$uibModalInstance.dismiss();
					$scope.showSave = false;
				}
			});
		};
		
		// if Response Monitor is disabled then, 
		// call the submit without fetching SUM-Locations
		function initCitiesLoad() {
			if( ! sumTestAddData.status ) {
				$scope.showSave = false;
				$uibModalInstance.dismiss();
				
				$scope.saveSumData();
			}
		}
		initCitiesLoad();
	}
]);


appedoApp.controller('sumDashPanel', ['$scope', '$location', '$rootScope', '$state', 'sumModuleServices', 'sessionServices', '$appedoUtils', 'sumModuleFactory', 'messageService', function($scope, $location, $rootScope, $state, sumModuleServices, sessionServices, $appedoUtils, sumModuleFactory, messageService) {
	var d3ChartTimeFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"));
	
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('SUM Dashboard Page', 'pageOpen', 
		{
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	$scope.noRunningTests = false;
	$scope.sumMultiChartLoadingSvrMap = true;
	$scope.userWebsiteCounterModules;
	$scope.selectedRUMDuration;
	$scope.selectedLocation;
	$scope.responseTimeChartData = [];
	
	$scope.userWebsiteCounterModules = [];

	$scope.userSUMLicense = {};
	$scope.loginUser = JSON.parse(sessionServices.get('loginUser'));
	
	//$scope.sumDurations = JSON.parse(sessionServices.get("sliderServerSideScale"));
	
	$scope.sumDurations = sumModuleFactory.sliderOptions.qry_intervals;
	var aryIntervalInHours = sumModuleFactory.sliderOptions.interval_in_hours;
	
	// for SUM default selection is made as `24 hours`
	$scope.selectedSUMDuration = $scope.sumDurations[1];
	
//                                    		$scope.d3XaixsFormat = d3ChartTimeFormat[$scope.sumDurations.indexOf($scope.selectedSUMDuration)];
	$scope.d3XaixsFormat = "%d %b %H:%M";
	$scope.stLimit =0;
	/*
	 * thinks, below fn. retrives URL sum test,
	 * since to have transactions in ServiceMap and SUM dashboard, to have common template html used older UI service `./getSUMTestsResults`,
	 * Note: since in Service map SUM's test's page_id, page_name is not retrived, not used the service used in SUM details page testResults dropdown 
	 * 
	var resultSUMDropdown = sumModuleServices.getSUMDropdown();
	resultSUMDropdown.then(function(resp) {
		$scope.userWebsiteCounterModules = resp;
		$scope.selectedWebSite = $scope.userWebsiteCounterModules[0];
		$scope.getSUMChartData();
	});
	*/
	
	// thinks, gets SUM tests and 
	$scope.getSUMTestsResults = function() {
		sumModuleServices.getSUMTestsResults(function(data) {
			//$scope.userWebsiteCounterModules = data.message;
			if($scope.dbtype == 'apm') {
				angular.forEach(data.message, function(d){
					if(d.status == 'Running') {
						$scope.userWebsiteCounterModules.push(d);
					}
				});
			} else {
				$scope.userWebsiteCounterModules = data.message;
			}
			
			loadSUMChartData();
		});
	};
	
	var currentURLLocation = $location.path().split("/")[1];
	if(currentURLLocation == 'sum_metrics'){
		$rootScope.navData = undefined;
	}

	// defaults to load user's SUM Tests 
	if ( $scope.navData !== undefined && $scope.navData === 'Service Map' ) {
		// to load user's SUM Tests is avoided for ServiceMap, since same controller and template used for dashboard's SUM & ServiceMap's SUM, (Note: $scope.navData is available from root/parent controller)
	} else {
		$scope.getSUMTestsResults();
	}
	

	// gets SUM particular test pages
	$scope.getSUMTestPages = function() {
		sumModuleServices.getSUMTestPages($scope.selectedWebSite.test_id, function(data) {
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.sumMultiChartLoadingSvrMap = false;
				$scope.storeSUMTestPages = data.message;

				// selects & gets SUM test chart data
				if($scope.storeSUMTestPages.length>0){
					$scope.selectedTransactionPage = $scope.storeSUMTestPages[0];
				}else{
					$scope.selectedTransactionPage = {}; // assigned empty object since currently we were not showing scanned pagewise har result
				}
				$scope.getSUMChartData();
			}
		});
	};

	
	// Used for serviceMap's SUM panel, user mapped sumTests are set and loadsChartData
	$scope.$on("loadSelectedServiceMap", function(event, joMappedService) {
		$scope.userWebsiteCounterModules = joMappedService.SUM || [];
		$scope.storeSUMTestPages = [];
		
		loadSUMChartData();
	});

	
	function loadSUMChartData() {
		if($scope.userWebsiteCounterModules.length>0){
			$scope.noRunningTests = false;
			$scope.selectedWebSite = $scope.userWebsiteCounterModules[0];
			$scope.validateTestType();	
		}else{
			$scope.noRunningTests = true;
			$scope.sumMultiChartLoadingSvrMap = false;
		}
		
	}

	/* based selected data from 'SUM Tests', 
	 * if a test is of its type 'URL' harResults were called, if its 'Transaction' to gets its result pages were called
	 */
	$scope.validateTestType = function() {
		$scope.sumMultiChartLoadingSvrMap = true;
		clearSUMTransactionPages();
		
		if ($scope.selectedWebSite.testtype === 'URL') {
			// gets SUM test chart data
			$scope.getSUMChartData();
		} else {
			clearChartData();
			
			// gets test'stransaction pages
			$scope.getSUMTestPages();
		}
	};
	
	$scope.getLicenseSUMDetails = function(){
		var resultLicenseSUMDetails = sumModuleServices.getLicenseSUMDetails();
		resultLicenseSUMDetails.then(function(resp) {
			if ( ! resp.success ) {
				// err
			} else {
				// success
				$scope.userSUMLicense = resp.message;	
			}
			
			/*
			var stLimit=0;
			if( $scope.loginUser.License === 'level3' ){
				stLimit = "1825";// 365*5=1825 :: 5 years
			}else{
				stLimit = resp.message.max_retention_in_days;
			}
			$scope.stLimit = stLimit;*/
		});
	};
	$scope.getLicenseSUMDetails();

	
	$scope.getSUMChartData = function(){
		$scope.sumMultiChartLoadingSvrMap = true;
		$scope.selectedLocation = "All Locations";
		
		clearChartData();
/*
		var limit = $scope.stLimit*24;
		var selected = JSON.parse(sessionServices.get("sliderServerSideScaleInHour"))[$scope.sumDurations.indexOf($scope.selectedSUMDuration)];
		if(Number(limit)>0){
			if(Number(selected)>Number(limit)){
				$scope.selectedSUMDuration = $scope.sumDurations[1];			
				ngToast.create({
					className: 'warning',
					content: "Contact support@appedo.com to see data older than "+$scope.stLimit+" day(s).",
					timeout: 5000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
				});
			}
		}
*/
		
		var nUserLicenseMaxRetentionInHour = $scope.userSUMLicense.max_retention_in_days * 24;
		if ( aryIntervalInHours[$scope.sumDurations.indexOf($scope.selectedSUMDuration)] > nUserLicenseMaxRetentionInHour && $scope.loginUser.License !== 'level3' ) {
			// selection made as `24 hours`, when user selected interval > user's license interval,
			$scope.selectedSUMDuration = $scope.sumDurations[1];
			messageService.showWarningMessage('You can see maximum of last '+$scope.userSUMLicense.max_retention_in_days+' day(s). For further details please contact <STRONG>support@appedo.com</STRONG>');
		}
		$scope.getSUMMultiLineChart();
	};
	
	$scope.getSUMMultiLineChart= function(){
		if($scope.selectedWebSite!=undefined){
			// selected Transaction page sets
			var pageId = '', pageName = '';
			if( $scope.selectedTransactionPage != undefined ) {
				pageId = $scope.selectedTransactionPage.pageId;
				pageName = $scope.selectedTransactionPage.pageName;
			}
			
			if ( $scope.selectedWebSite.testtype === 'TRANSACTION' && pageId === '') {
				// For SUM Transactions, Avoid to get chartdata when nullabel value of `Scanned Pages` selected 
			} else {
				var resultSUMMultiLine = sumModuleServices.getSUMMultiLine($scope.selectedWebSite.test_id, pageId, pageName, $scope.selectedSUMDuration, null, null);
				resultSUMMultiLine.then(function(resp) {
					if(resp.success){
						$scope.sumLocations = resp.message;
						$scope.responseTimeChartData = resp.message;
						$scope.responseTimeOriChartData = resp.message;
						$scope.sumMultiChartLoadingSvrMap = false;
					}
				});
			}
		}
	};

	$scope.getSelectedLocation = function(selectedLoc)
	{
		if(selectedLoc=="All Locations"){
			$scope.responseTimeChartData = $scope.responseTimeOriChartData;
		}else{
			var selectedResponseTimeCount = [];
			for(var i=0; i< $scope.responseTimeOriChartData.length; i++) {
				var moduleContent = $scope.responseTimeOriChartData[i];
				if(moduleContent.City==selectedLoc){
					selectedResponseTimeCount.push(moduleContent);
					break;
				}
			}
			$scope.responseTimeChartData = selectedResponseTimeCount;
		}
	};
	
	// to go SUM test's details page 
	$scope.viewSUMTestDetailsPage = function() {
		sessionServices.set("selectedSumCardContent", JSON.stringify($scope.selectedWebSite));
		$rootScope.selectedSUMInterval = $scope.selectedSUMDuration;
		//sessionServices.set("selectedSUMInterval", $scope.selectedSUMDuration);
		$state.transitionTo('/sum_details');
	};
	
	function clearChartData() {
		$scope.sumLocations = [];
		$scope.responseTimeChartData = [];
		$scope.responseTimeOriChartData = [];
	}

	// clears SUM tranasction pages & selected scanned page pageId	
	function clearSUMTransactionPages() {
		$scope.storeSUMTestPages = [];
		$scope.selectedTransactionPage = undefined;
	}
}]);

appedoApp.controller('sumDetailsController', ['$scope', 'sumModuleServices', '$appedoUtils', 'sessionServices', '$state', 'ngToast', '$rootScope', 'sumModuleFactory', 'messageService', function($scope, sumModuleServices, $appedoUtils, sessionServices, $state, ngToast, $rootScope, sumModuleFactory, messageService) {
	$scope.backToSUMCardPage = function() {
		$rootScope.backPageFrom = "SUMDetails";
		$state.transitionTo('/sum_metrics');
	};
	//$scope.selectedSumCardContent = JSON.parse(sessionServices.get("selectedSumCardContent"));
	$scope.selectedSumCardContent = JSON.parse(sessionServices.get("selectedAppCardContent"));
	//$scope.runEvery = $scope.selectedSumCardContent.runevery;
	$scope.sumMultiChartLoading = true;
	
	$scope.loginUser = JSON.parse(sessionServices.get('loginUser'));
	
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('SUM Details Page', 'pageOpen', 
		{
			page_open_date_time : new Date()
		});
	};
	//$scope.testCITrigger();
	
	// for slider
	$scope.sliderOptions = sumModuleFactory.sliderOptions;
	// default slider interval `24 hours`
	var DEFAULT_SLIDER_INTERVAL = 2;
	if ( $rootScope.selectedSUMInterval !== undefined ) {
		// transition from dashboard, to load selected interval; since healthboard, hotspot intervals different from SUM details slider, to load default interval 
		var idx = $scope.sliderOptions.qry_intervals.indexOf($rootScope.selectedSUMInterval);
		$scope.sliderValue = (idx === -1 ? DEFAULT_SLIDER_INTERVAL : idx + 1);
	} else {
		// default, in SUM default selection of `24 hours`
		$scope.sliderValue = DEFAULT_SLIDER_INTERVAL;
	}

	$scope.selectedTimeInterval = $scope.sliderOptions.interval_in_hours[$scope.sliderValue - 1];
	//$scope.selectedTimeInterval = $scope.sliderOptions.interval_in_hours[0];
	
	$scope.sumMultiLine = {};
	$scope.sumMultiLine.startDate = '';
	$scope.sumMultiLine.endDate = '';
	$scope.sumMultiLine.startDateTime = null;
	$scope.sumMultiLine.endDateTime = null;
	$scope.sumMultiLine.startHour = 0;
	$scope.sumMultiLine.endHour = 23;
	$scope.sumMultiLine.startMins = 0;
	$scope.sumMultiLine.endMins = 59;
	$scope.sumMultiLine.enDateLimit = new Date();
	$scope.stLimit = 0;
//                                    		$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[0];
	$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormatForLT"))[0];
	
	$scope.userWebsiteCounterModules;
//                                    		$scope.selectedLocation;
	$scope.responseTimeChartData;
	$scope.isTestInitialRun = false;
	
	$scope.showScannedPageDropdown=false;
	$scope.userWebsiteCounterModules = [];
	
	$scope.tab = {};
	
	$scope.userSUMLicense = {};
	
	$scope.getModules = function(){
		var resultSUMDropdown = sumModuleServices.getSUMDetailsDropDown();
		resultSUMDropdown.then(function(resp) {
			$scope.userWebsiteCounterModules = resp.message;
			selectModuleByTestId();
		});
	};
	$scope.getModules();

	$scope.getLicenseSUMDetails = function(){
		var resultLicenseSUMDetails = sumModuleServices.getLicenseSUMDetails();
		resultLicenseSUMDetails.then(function(resp) {
			
			if ( ! resp.success ) {
				// err
			} else {
				// success
				var nUserLicenseMaxRetentionInDay = 0;
				$scope.userSUMLicense = resp.message;
				
				if ( $scope.loginUser.License === "level3" ) {
					nUserLicenseMaxRetentionInDay = 1825;// 365*5=1825 :: 5 years
				} else {
					nUserLicenseMaxRetentionInDay = $scope.userSUMLicense.max_retention_in_days;
				}
				
				var startDateLimit = new Date();
				startDateLimit = startDateLimit.setMilliseconds(startDateLimit.getMilliseconds() - ((nUserLicenseMaxRetentionInDay - 1)*24*60*60*1000));
				$scope.sumMultiLine.stDateLimit = new Date(startDateLimit);
			}
		});
	};
	$scope.getLicenseSUMDetails();
	
	function selectModuleByTestId() {
		for(var i = 0; i < $scope.userWebsiteCounterModules.length; i = i + 1) {
			var joModule = $scope.userWebsiteCounterModules[i];
			
			if ( joModule.testid == ($scope.selectedSumCardContent.testid || $scope.selectedSumCardContent.test_id) ) {
				$scope.selectedWebSite = joModule;
				showScannedPagesDropdown();
				break;
			}
		}
	}
	
	function showScannedPagesDropdown() {
		clearHarData();
		$scope.sumMultiChartLoading = true;
		if($scope.selectedWebSite.testtype=="TRANSACTION"){
			$scope.showScannedPageDropdown=true;
			$scope.scannedPages = $scope.selectedWebSite.pageDetails;
			if($scope.scannedPages.length > 0){
				$scope.scannedPage = $scope.scannedPages[0];
			}else{
				$scope.scannedPage = {}; // assigned empty object since currently we were not showing scanned pagewise har result
			}
			if($scope.scannedPage!=undefined){
				$scope.getSUMChartData();
			}
		}else if($scope.selectedWebSite.testtype=="URL"){
			$scope.scannedPages = [];
			$scope.scannedPage = "";
			$scope.showScannedPageDropdown=false;
			$scope.getSUMChartData();
		}
	}

	$scope.loadSliderSelectionData = function() {
/*
		var limit = $scope.stLimit*24;
		var selected = JSON.parse(sessionServices.get("sliderServerSideScaleInHour"))[($scope.sliderValue/$scope.sliderOptions.step)];
		if(Number(limit)>0){
			if(Number(selected)>Number(limit)){
				$scope.sliderValue = "20";			
				ngToast.create({
					className: 'warning',
					content: "Contact support@appedo.com to see data older than "+$scope.stLimit+" day(s).",
					timeout: 5000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
				});
			}
		}
*/
		clearHarData();

		$scope.sumMultiChartLoading = true;
		$scope.sumMultiLine.startDate = '';
		$scope.sumMultiLine.endDate = '';
		$scope.sumMultiLine.startDateTime = null;
		$scope.sumMultiLine.endDateTime = null;
		$scope.sumMultiLine.startHour = 0;
		$scope.sumMultiLine.endHour = 23;
		$scope.sumMultiLine.startMins = 0;
		$scope.sumMultiLine.endMins = 59;
		var nUserLicenseMaxRetentionInHour = $scope.userSUMLicense.max_retention_in_days * 24;
		if ( $scope.sliderOptions.interval_in_hours[$scope.sliderValue - 1] > nUserLicenseMaxRetentionInHour && $scope.loginUser.License !== 'level3' ) {
			// selection made as `24 hours`, when user selected interval > user's license interval,
			$scope.sliderValue = 2;
			messageService.showWarningMessage('You can see maximum of last '+$scope.userSUMLicense.max_retention_in_days+' day(s). For further details please contact <STRONG>support@appedo.com</STRONG>');
		}
		$scope.selectedTimeInterval = $scope.sliderOptions.interval_in_hours[$scope.sliderValue - 1];
		//$scope.getSUMChartData();
	};
	
	$scope.strInterval = '1 day';

	$scope.getSUMChartData = function(){
		clearHarData();
		$scope.sumMultiChartLoading = true;
		$scope.showMultiSelectDropdown = false;
		
		clearChartData();
		
		$scope.scannedPages = [];
		$scope.scannedPage = "";
		if( $scope.selectedWebSite != undefined ){
			if($scope.selectedWebSite.testtype!="TRANSACTION"){
				$scope.scannedPages = [];
				$scope.scannedPage;
				$scope.showScannedPageDropdown=false;
				if(($scope.sumMultiLine.startDateTime != null ) && ($scope.sumMultiLine.endDateTime != null)){
					$scope.getSUMMultiLineChartWithDateRange();
				} else{
					$scope.getSUMMultiLineChart();
				}
			}else{
				$scope.showScannedPageDropdown=true;
				$scope.scannedPages = $scope.selectedWebSite.pageDetails;
				if($scope.scannedPages.length > 0){
					$scope.scannedPage = $scope.scannedPages[0];
				}else{
					$scope.scannedPage = {}; // assigned empty object since currently we were not showing scanned pagewise har result
				}
				if($scope.scannedPage!=undefined){
					if(($scope.sumMultiLine.startDateTime != null ) && ($scope.sumMultiLine.endDateTime != null)){
						$scope.getSUMMultiLineChartWithDateRange();
					} else{
						$scope.getSUMMultiLineChart();
					}
				}
			}
		}
	};
	 $rootScope.$on("call_SUM_Details", function(event, responseData){
		 $scope.sumMultiLine.startDateTime = responseData.startDateTime;
		 $scope.sumMultiLine.endDateTime = responseData.endDateTime;
		 $scope.strInterval = responseData.strInterval;
		 console.log("str_Date:"+$scope.sumMultiLine.startDateTime);
		 console.log("end_Date:"+$scope.sumMultiLine.endDateTime);
		 console.log("Interval:"+$scope.strInterval );
		 $scope.getSUMChartData();
		});
	 
	
	$scope.getSUMSearchPageChangeChartData = function(){
		clearHarData();
		$scope.scannedPage =this.scannedPage;
/*
		$scope.selectedLocations = [];
		$scope.selectedBrowsers = [];
		$scope.selectedConnections = [];
		$scope.responseTimeChartData=[];
		$scope.responseTimeOriChartData=[];
*/		
		
		if( ($scope.scannedPage != "") && ($scope.scannedPage != undefined) ){
			$scope.sumMultiChartLoading = true;
//                                    				$scope.selectedLocation = "All Locations";
			if( ($scope.sumMultiLine.startDateTime != '') && ($scope.sumMultiLine.endDateTime != '') ){
				$scope.getSUMMultiLineChartWithDateRange();
			} else{
				$scope.getSUMMultiLineChart();
			}
		}
	};

	var timerChartsLoading;
	$scope.getSUMMultiLineChart = function(){
		//clearHarData();
		clearInterval(timerChartsLoading);
		
		$scope.sumMultiChartLoading = true;
		$scope.showMultiSelectDropdown = false;
		
		clearChartData();
		
		$scope.sumMultiLine.startDate = '';
		$scope.sumMultiLine.endDate = '';
		
		if( $scope.selectedWebSite != undefined ){
			//var resultSUMMultiLine, strInterval = $scope.sliderOptions.qry_intervals[$scope.sliderValue - 1];
			//var resultSUMMultiLine, strInterval = '1 hour';
			var resultSUMMultiLine, strInterval = $scope.strInterval;
			
			if( $scope.selectedWebSite.testtype === "TRANSACTION" ) {
				resultSUMMultiLine = sumModuleServices.getSUMMultiLineWithLocationBrowserConnection($scope.selectedWebSite.testid, $scope.scannedPage.page_id, $scope.scannedPage.page_name, strInterval);
			} else if ( $scope.selectedWebSite.testtype === "URL" ) {
				resultSUMMultiLine = sumModuleServices.getSUMMultiLineWithLocationBrowserConnection($scope.selectedWebSite.testid, '', '', strInterval);
			}
			resultSUMMultiLine.then(chartDataResponse);
		}
		
		timerChartsLoading = setInterval($scope.getSUMMultiLineChart, 1000 * 120);
	};
	
	$scope.getSUMMultiLineChartWithDateRange= function(){
		clearHarData();
		$scope.selectedTimeInterval = undefined;
		var selectedDateCheck=false;
		var startHourCheck=false;
		var startMinsCheck=false;
		var endHourCheck=false;
		var endMinsCheck=false;
		
		if(($scope.sumMultiLine.startHour == null) ||($scope.sumMultiLine.startHour.length == 0) || (parseInt($scope.sumMultiLine.startHour)>23)){
			$scope.sumMultiLine.startDateTime = '';
			$scope.sumMultiLine.endDateTime = '';
			messageService.showWarningMessage('Start Hour should not be either empty or greater than 23');
		}else{
			startHourCheck = true;
		}

		if(($scope.sumMultiLine.startMins == null) || ($scope.sumMultiLine.startMins.length ==0) || (parseInt($scope.sumMultiLine.startMins)>59)){
			$scope.sumMultiLine.startDateTime = '';
			$scope.sumMultiLine.endDateTime = '';
			messageService.showWarningMessage('Start Mins should not be either empty or greater than 59');
		}else{
			startMinsCheck = true;
		}

		if(($scope.sumMultiLine.endHour == null) || ($scope.sumMultiLine.endHour.length == 0) || (parseInt($scope.sumMultiLine.endHour)>23)){
			$scope.sumMultiLine.startDateTime = '';
			$scope.sumMultiLine.endDateTime = '';
			messageService.showWarningMessage('End Hour should not be either empty or greater than 23');
		}else{
			endHourCheck = true;
		}

		if(($scope.sumMultiLine.endMins == null ) || ($scope.sumMultiLine.endMins.length == 0) || (parseInt($scope.sumMultiLine.endMins) > 59)){
			$scope.sumMultiLine.startDateTime = '';
			$scope.sumMultiLine.endDateTime = '';
			messageService.showWarningMessage('End Mins should not be either empty or greater than 59');
		}else{
			endMinsCheck = true;
		}
		
		if(($scope.sumMultiLine.startDate == null ) || ($scope.sumMultiLine.endDate == null)){
			$scope.sumMultiLine.startDateTime = '';
			$scope.sumMultiLine.endDateTime = '';
			messageService.showWarningMessage('Please select start date & end date');
		}else{
			selectedDateCheck = true;
		}
		
		if((selectedDateCheck == true ) && (startHourCheck == true ) && (startMinsCheck == true ) && (endHourCheck == true ) && (endMinsCheck == true ) ){
			//$scope.sumMultiLine.startDateTime = $scope.sumMultiLine.startDate;
			//$scope.sumMultiLine.startDateTime.setHours($scope.sumMultiLine.startHour);
			//$scope.sumMultiLine.startDateTime.setMinutes($scope.sumMultiLine.startMins);
			
			//$scope.sumMultiLine.endDateTime = $scope.sumMultiLine.endDate;
			//$scope.sumMultiLine.endDateTime.setHours($scope.sumMultiLine.endHour);
			//$scope.sumMultiLine.endDateTime.setMinutes($scope.sumMultiLine.endMins);
			
			if( $scope.sumMultiLine.startDateTime <= $scope.sumMultiLine.endDateTime ){
				$scope.d3XaixsFormat = "%d %b %H:%M";
				$scope.sumMultiChartLoading = true;
				$scope.showMultiSelectDropdown = false;
				
				clearChartData();
				
				if( $scope.selectedWebSite != undefined ){
					var resultSUMMultiLine;
					if( $scope.selectedWebSite.testtype === "TRANSACTION" ){
						resultSUMMultiLine = sumModuleServices.getSUMMultiLineWithDateRange($scope.selectedWebSite.testid, $scope.scannedPage.page_id, $scope.scannedPage.page_name, $scope.sumMultiLine.startDateTime, $scope.sumMultiLine.endDateTime);
					} else if( $scope.selectedWebSite.testtype === "URL" ){
						resultSUMMultiLine = sumModuleServices.getSUMMultiLineWithDateRange($scope.selectedWebSite.testid, '', '', $scope.sumMultiLine.startDateTime, $scope.sumMultiLine.endDateTime);
					}
					resultSUMMultiLine.then(chartDataResponse);
				}
			} else {
				messageService.showWarningMessage('End datetime should be greater than or equal to start datetime');
			}
		}
	};
	
	// sum details graph data response
	function chartDataResponse(resp) {
		if( ! resp.success ){
			messageService.showErrorMessage('Unable to get chart data.');
		} else {
			$scope.sumTestlocations = resp.message.LocationDetail;
			for(var l=0; l < $scope.sumTestlocations.length; l++){
				$scope.selectedLocations.push($scope.sumTestlocations[l].label);
			}
			$scope.sumbrowsers = resp.message.BrowserDetail;
			for(var l=0; l < $scope.sumbrowsers.length; l++){
				$scope.selectedBrowsers.push($scope.sumbrowsers[l].label);
			}
			$scope.sumconnections = resp.message.ConnectionDetail;
			for(var l=0; l < $scope.sumconnections.length; l++){
				$scope.selectedConnections.push($scope.sumconnections[l].label);
			}
//                                    				$scope.sumLocations = resp.message.MainDetail;
			
			// Merge the SUM-Response result & Unavailablity Result
			$scope.responseTimeChartData = [{chartData: resp.message.MainDetail, failureResults: sumFailureResults, failureXAxisDataIndex: 'appedo_received_on'}];
			$scope.responseTimeOriChartData = resp.message.MainDetail;
			
			$scope.sumMultiChartLoading = false;
			if( resp.message.MainDetail.length > 0 ){
				$scope.showMultiSelectDropdown = true; 
			}else{
				if(resp.message.isTestRunning != undefined){
					$scope.isTestInitialRun = resp.message.isTestRunning;	
				}
			}
		}
	}
	
	$scope.getSelectedSUMTestData = function() {
		var selectedResponseTimeCount = [];
		for(var i=0; i < $scope.selectedLocations.length; i++) {
			var locationContent = $scope.selectedLocations[i];
			
			for(var j=0; j < $scope.selectedBrowsers.length; j++ ) {
				var browserContent = $scope.selectedBrowsers[j];
				
				for(var k=0; k < $scope.selectedConnections.length; k++) {
					var connectionContent = $scope.selectedConnections[k];
					
					for(var m=0; m < $scope.responseTimeOriChartData.length; m++) {
						var moduleContent = $scope.responseTimeOriChartData[m];
						if((moduleContent.locationName==locationContent)&&(moduleContent.browserName==browserContent)&&(moduleContent.connectionName==connectionContent)){
							selectedResponseTimeCount.push(moduleContent);
							break;
						}
					}
				}
			}
		}
		clearHarData();
		
		// Merge the SUM-Response result & Unavailablity Result
		$scope.responseTimeChartData = [{chartData: selectedResponseTimeCount, failureResults: sumFailureResults, failureXAxisDataIndex: 'appedo_received_on' }];
	};
	
	clearHarData();
	
	$scope.harFileLoading = true;
	$scope.populateHarFile = function(filePath,time,respTime,location,id){
		clearHarData();
		$scope.tab.showSummaryTab = true;
		$scope.harTimeHeading="";
		$scope.harRespTimeHeading="";
		$scope.harLocationHeading="";
		$scope.showErrorByte = false;
		$scope.storeScreenUrls={};
		$scope.storeContentUrl="";
		$scope.storeDomainUrl="";
		
		$scope.harFilePath="";
		$scope.harFileLoading = true;
		

		$scope.showHAR = true;
		$scope.showError = false;
		$scope.showFirstByte = false;
		$scope.hideDocForTrans = false;
		$scope.showScreen = true;
		$scope.harTimeHeading=time;
		$scope.harRespTimeHeading=respTime;
		$scope.harLocationHeading=location;
		$scope.$apply();
	
		var checkVaildHarURL = sumModuleServices.checkVaildHarURL(filePath);
		checkVaildHarURL.then(function(resp) {
			if(resp.success){
				$scope.harFilePath=filePath;
			}else{
				$scope.harFilePath="";
				messageService.showWarningMessage('No Har File Found');
			}
		});
		
		$scope.storeFirstByte=[];
		var getFirstByte=sumModuleServices.getFirstByte(id, function(data) {
			if(data.success){
				if(((data.message[0].docTime==0)&&(data.message[0].requestsDoc==0)&&(data.message[0].requests==0)) || ((data.message[0].docTime==undefined)&&(data.message[0].requestsDoc==undefined)&&(data.message[0].requests==undefined))){
					$scope.showError = true;
					
				}else{
					$scope.storeFirstByte = data.message;
					if(data.message[0].domElements==undefined){
						$scope.hideDocForTrans = true;
					}
					$scope.showFirstByte = true;		
				}
			}else{
				$scope.showFirstByte = false;
				$scope.showErrorByte = true;
			}
		});
		
		$scope.fetchScreen = function() {
			sumModuleServices.fetchScreen(id,function(data) {
				if( data.success ){
					$scope.storeScreenUrls = data.message;
					$scope.storeContentUrl = data.message.breakdown;
					$scope.storeDomainUrl = data.message.domains;
				} else {
					messageService.showErrorMessage('No details Found');
				}
			});
		};
		$scope.fetchScreen();
	};
		
	function clearHarData() {
		// clears the har URL data
		$scope.harFilePath = '';
		$scope.showHAR = false;
		$scope.storeContentUrl="";
		$scope.storeDomainUrl="";
	}
	
	function clearChartData() {
		$scope.selectedLocations = [];
		$scope.selectedBrowsers = [];
		$scope.selectedConnections = [];
		$scope.responseTimeChartData = [];
		$scope.responseTimeOriChartData = [];
		sumFailureResults = [];
		$scope.isTestInitialRun = false;
	}

	$scope.harFileLoadingFinish= function(){
		$scope.harFileLoading = false;
		$scope.$apply();
	};

	$scope.$on('$destroy', function() {
		clearInterval(timerChartsLoading);
	});
}]);

appedoApp.controller('sumMapController', ['$scope', 'sumModuleServices', function($scope , sumModuleServices){
	
	var resultSUMWorldMap = sumModuleServices.getSUMWorldMap();
	
	resultSUMWorldMap.then(function(resp) {
		if(resp.success){
			var responseData = resp.message;
			$scope.mapData = responseData;
			var runningCount = 0, completedCount = 0, locationCount = 0;
			for (var key in responseData) {
				runningCount += responseData[key].running;
				completedCount += responseData[key].completed;
				if(responseData[key].id) {
					locationCount = responseData[key].id++;
				}
			}
			$scope.runningCount = runningCount;
			$scope.completedCount = completedCount;
			$scope.locationCount = locationCount;
		}
	});
}]);

appedoApp.controller('sumAddController', ['$scope', '$uibModal', 'sumModuleServices', '$uibModalInstance', 'isFrom', 'moduleCardContent', 'ngToast', 'sessionServices', '$rootScope', 'sumTestData', 'successMsgService', 'messageService','forDateTimeModuleMethod', 
	function($scope, $uibModal, sumModuleServices, $uibModalInstance, isFrom, moduleCardContent, ngToast, sessionServices, $rootScope, sumTestData, successMsgService, messageService,forDateTimeModuleMethod) {
	
	$scope.sumTestData = {};
	$scope.dupCheck = true;
	// Advanced Settings is removed; instead, "Enable Response Monitor" is added.
	// $scope.advanceSettingsStatus = false;
	
	$scope.validateSUMTestName = function () {
		if($scope.sumTestData.testName != undefined && $scope.sumTestData.testName != ""){
			$scope.dupCheck = false;
			sumModuleServices.validateSUMTestName($scope, $scope.sumTestData.testName, $scope.sumTestData.testid, function(data) {
				if(data.success){
					$scope.showProceed = data.isvalid;
					if(data.isvalid){
						$scope.response ={};
						$scope.response.success = false;
						$scope.response.errorMessage = $scope.sumTestData.testName+" already exists.";
						//successMsgService.showSuccessOrErrorMsg($scope.response);
						messageService.showErrorMessage($scope.response.errorMessage);
					}
				}else{
					$scope.showProceed = true;
				}
			});
		}
	};
	
	var currentDate = '';
	$scope.today = function() {
		months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		currentDate = new Date();
		$scope.curdate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
		};
	$scope.today();
	
	$scope.responseAlerts = false;
	$scope.checkResponseAlert = function () {
		if($scope.sumTestData.responseAlert){
			$scope.responseAlerts = true;
			$scope.sumTestData.warning = $scope.defaultWarningLimit;
			$scope.sumTestData.error = $scope.defaultErrorLimit ;
			$scope.sumTestData.rmBreachCount = $scope.defaultMinBreachCount;
		}else{
			$scope.responseAlerts = false;
			$scope.sumTestData.warning = 0;
			$scope.sumTestData.error = 0 ;
			$scope.sumTestData.rmBreachCount = 0;
		}
	};
	
	$scope.sumTestData.downTimeAlert = true;
	$scope.checkDownTimeAlert = function () {
		if($scope.sumTestData.downTimeAlert){
			$scope.downTimeAlert = true;
		}else{
			$scope.downTimeAlert = false;
		}
	};

	// Advanced Settings is removed; instead, "Enable Response Monitor" is added.
	/*$scope.showAdvanceSettings = function () {
		if($scope.advanceSettingsStatus){
			$scope.advanceSettingsStatus = false;
		}else{
			$scope.advanceSettingsStatus = true;
		}
	};*/
	if(isFrom == 'fromAdd') {
		forDateTimeModuleMethod.setMethod("fromAddSum");
		console.info("AfterSetabcd: "+forDateTimeModuleMethod.getMethod());
		$scope.formName = "Add";
		$scope.show_deactivate = false;
		$scope.sumTestData.testType = "URL";
		$scope.sumTestData.testName = "";
		$scope.sumTestData.status = true;
		$scope.sumTestData.url = 'http://';
		$scope.sumTestData.runEveryMinutes = "60";
		sumModuleServices.getPackages($scope);
		$scope.saveBtn = "Save";
		$scope.sumTestData.startdate = $scope.curdate;
		$scope.sumTestData.enddate = $scope.curdate;
		$scope.sumTestData.repeatView = false;
		
		var devices = sumModuleServices.getSUMDeviceTypes();
		devices.then(function(resp) {
			if(resp.success){
				$scope.devicetypes = resp.message.deviceTypes;
				$scope.sumTestData.deviceType = $scope.devicetypes[0];
				$scope.getSUMConnectionDetails();
			}
		});
		$scope.getSUMConnectionDetails = function() {
			var sumconnections = sumModuleServices.getSUMConnections();
			sumconnections.then(function(resp) {
				if(resp.success){
					$scope.desktopconnections = resp.message.connectivity;
					$scope.mobileconnections = findAndCreate(resp.message.connectivity,'connectionName','Native');

					if($scope.sumTestData.deviceType.deviceType == 'DESKTOP'){
						$scope.connections = $scope.desktopconnections;
					}else if($scope.sumTestData.deviceType.deviceType == 'MOBILE'){
						$scope.connections = $scope.mobileconnections ;
					}
					
					$scope.sumTestData.connection = $scope.connections[0];
					
					$scope.sumTestData.download = $scope.sumTestData.connection.downloadLimit;
					$scope.sumTestData.upload = $scope.sumTestData.connection.uploadLimit;
					$scope.sumTestData.latency = $scope.sumTestData.connection.latencyLimit;
					$scope.sumTestData.packetloss = $scope.sumTestData.connection.packetLoss;
					
					$scope.downloadLimt = resp.sumDownloadLimit;
					$scope.uploadLimit = resp.sumUploadLimit;
					$scope.latencyLimit = resp.sumLatencyLimit;
					$scope.packetDataLimit = resp.sumPacketLossLimit;
					$scope.warningLimit = resp.sumWarningLimit;
					$scope.errorLimit = resp.sumErrorLimit;

					$scope.defaultWarningLimit = resp.sumDefaultWarningLimit;
					$scope.defaultErrorLimit = resp.sumDefaultErrorLimit;
					$scope.defaultMinBreachCount = resp.sumDefaultMinBreachCount;
					$scope.getOSTypes();
				}
			});
			
		};
		
		$scope.getOSTypes = function() {
			
			if($scope.sumTestData.deviceType.deviceType == 'DESKTOP'){
				$scope.connections = $scope.desktopconnections;
				$scope.sumTestData.connection = $scope.connections[0];
				$scope.sumTestData.download = $scope.sumTestData.connection.downloadLimit;
				$scope.sumTestData.upload = $scope.sumTestData.connection.uploadLimit;
				$scope.sumTestData.latency = $scope.sumTestData.connection.latencyLimit;
				$scope.sumTestData.packetloss = $scope.sumTestData.connection.packetLoss;
			}else if($scope.sumTestData.deviceType.deviceType == 'MOBILE'){
				$scope.connections = $scope.mobileconnections;
				$scope.sumTestData.connection = $scope.connections[0];
				$scope.sumTestData.download = $scope.sumTestData.connection.downloadLimit;
				$scope.sumTestData.upload = $scope.sumTestData.connection.uploadLimit;
				$scope.sumTestData.latency = $scope.sumTestData.connection.latencyLimit;
				$scope.sumTestData.packetloss = $scope.sumTestData.connection.packetLoss;
			}
			var os = sumModuleServices.getSUMOSTypes($scope.sumTestData.deviceType.deviceType);
			os.then(function(resp) {
				if(resp.success){
					$scope.sumTestData.OSType = undefined;
					$scope.ostypesoriginal = resp.message.osNames;
					$scope.ostypes = [];
					for(var i=0; i<$scope.ostypesoriginal.length; i++){
						if($scope.sumTestData.deviceType.deviceType == 'DESKTOP' && $scope.ostypesoriginal[i].osName == 'WINDOWS'){
							$scope.ostypes.push($scope.ostypesoriginal[i]);
							$scope.sumTestData.OSType = $scope.ostypes[0];
							$scope.getBrowserTypes();
						}//else if($scope.sumTestData.deviceType.deviceType == 'DESKTOP'){
						//	$scope.ostypes.splice(i, 1);
						//}
					}
					if($scope.sumTestData.OSType == undefined){
							$scope.ostypes = $scope.ostypesoriginal;
						$scope.sumTestData.OSType = $scope.ostypes[0];
							$scope.getBrowserTypes();
					}
				}
			});
		};
		
		
		$scope.sumBrowser = {};
		$scope.getBrowserTypes = function() {
			$scope.sumTestData.browser = [];
			var browsers = sumModuleServices.getSUMBrowserTypes($scope.sumTestData.deviceType.deviceType, $scope.sumTestData.OSType.osName);
			browsers.then(function(resp) {
				if(resp.success){
					$scope.sumbrowsers = resp.message.browserNames;
					//$scope.sumTestData.browser = $scope.sumbrowsers[0];
					$scope.sumTestData.browser.push($scope.sumbrowsers[0].dobId);
				}
			});
		};
		
	} else {
		forDateTimeModuleMethod.setMethod("fromEditSum");
		console.info("AfterSetabcd: "+forDateTimeModuleMethod.getMethod());
		//forDateTimeModuleMethod.setStDate()
		$scope.show_deactivate = true;
		
		// sets the formatted jo
		sumTestData.formatted_startdate = formateDate(new Date(sumTestData.startdate));
		sumTestData.formatted_enddate = formateDate(new Date(sumTestData.enddate));
		
		$scope.userSelectedCities = {};
		$scope.sumTestData.testid = sumTestData.testid;
		$scope.sumTestData.testName = sumTestData.testname;
		$scope.sumTestData.tranasctionImports = sumTestData.trasnactionImports;
		$scope.sumTestData.transaction = sumTestData.testtransaction;
		$scope.sumTestData.url = sumTestData.testurl;
		$scope.sumTestData.runEveryMinutes = sumTestData.runevery;
		$scope.sumTestData.testType = sumTestData.testtype;
		$scope.sumTestData.status = sumTestData.originalstatus;
		$scope.sumTestData.startdate = sumTestData.formatted_startdate;
		$scope.sumTestData.enddate = sumTestData.formatted_enddate;
		// set StartDate And EndDate of SUM Modules.
		//forDateTimeModuleMethod.setStDate(sumTestData.formatted_startdate);
		forDateTimeModuleMethod.setStDate(new Date(sumTestData.startdate));
		console.info("AfterSetSTDATE : "+forDateTimeModuleMethod.getStDate());
		forDateTimeModuleMethod.setEndDate(new Date(sumTestData.enddate));
		console.info("AfterSetEndDate : "+forDateTimeModuleMethod.getEndDate());
		// sets limit
		$scope.sumTestData.download = sumTestData.downloadlimit;
		$scope.sumTestData.upload = sumTestData.uploadlimit;
		$scope.sumTestData.latency = sumTestData.latencylimit;
		$scope.sumTestData.packetloss = sumTestData.packetloss;
		$scope.sumTestData.repeatView = sumTestData.repeatView;
		
		var editDta = $scope.sumTestAddData;
		var citiesData = sumTestData.cities;
		$scope.formName = "Edit";
		$scope.saveBtn = "Update";
		$scope.validateSUMTestName();
		$scope.disableUrlRadio = true;
		if ( $scope.sumTestData.testType === 'URL') {
			$scope.disableTransaction = true;
		} else {
			$scope.disableUrl= true;
		}
		
		$scope.getSUMConnectionDetails = function() {
			var sumconnections = sumModuleServices.getSUMConnections();
			sumconnections.then(function(resp) {
				if(resp.success){
					$scope.desktopconnections = resp.message.connectivity;
					$scope.mobileconnections = findAndCreate(resp.message.connectivity,'connectionName','Native');
						if($scope.sumTestData.deviceType.deviceType == 'DESKTOP'){
						$scope.connections = $scope.desktopconnections;
					}else if($scope.sumTestData.deviceType.deviceType == 'MOBILE'){
						$scope.connections = $scope.mobileconnections ;
					}
					
					for(var i=0; i<$scope.connections.length; i++){
						if($scope.connections[i].connectionId == sumTestData.connectionid){
							$scope.sumTestData.connection = $scope.connections[i];
						}
					}
					// to show config. data for `Custom` connection type
					if($scope.sumTestData.connection.connectionName == 'Custom'){
						$scope.showConnectivityParameters = true;
					}
					
					$scope.downloadLimt = resp.sumDownloadLimit;
					$scope.uploadLimit = resp.sumUploadLimit;
					$scope.latencyLimit = resp.sumLatencyLimit;
					$scope.packetDataLimit = resp.sumPacketLossLimit;
					$scope.warningLimit = resp.sumWarningLimit;
					$scope.errorLimit = resp.sumErrorLimit;
					$scope.getOSTypes();
				}
			});
		};
		
		var device = sumModuleServices.getSUMDeviceTypes();
		device.then(function(resp) {
			if(resp.success){
				$scope.devicetypes = resp.message.deviceTypes;
				for(var j=0; j<$scope.devicetypes.length; j++){
					if($scope.devicetypes[j].deviceType == sumTestData.browserDetails[0].deviceType){
						$scope.sumTestData.deviceType = $scope.devicetypes[j];
						$scope.getSUMConnectionDetails();
					}
				}
			}
		});
		
		$scope.getOSTypes = function() {
			var os = sumModuleServices.getSUMOSTypes($scope.sumTestData.deviceType.deviceType);
			os.then(function(resp) {
				if(resp.success){
					$scope.sumTestData.OSType="";
					$scope.ostypes = resp.message.osNames;
					for(var k=0; k<$scope.ostypes.length; k++){
						if($scope.ostypes[k].osName == sumTestData.browserDetails[0].osName){
							$scope.sumTestData.OSType = $scope.ostypes[k];
							//$scope.getBrowserTypes();
							break;
						}
					}
					if($scope.sumTestData.OSType!=""){
						$scope.getBrowserTypes();
					}else{
						$scope.sumTestData.OSType = $scope.ostypes[0];
						$scope.getBrowserTypes();
					}
				}
			});
		};
		
		$scope.getBrowserTypes = function() {
			$scope.sumTestData.browser = [];
			var browsers = sumModuleServices.getSUMBrowserTypes($scope.sumTestData.deviceType.deviceType, $scope.sumTestData.OSType.osName);
			browsers.then(function(resp) {
				if(resp.success){
					//$scope.sumTestData.browser = "";
					$scope.sumbrowsers = resp.message.browserNames;
					/*for(var l=0; l<$scope.sumbrowsers.length; l++){
						if($scope.sumbrowsers[l].dobId == sumTestData.browserDetails[0].dobId){
							$scope.sumTestData.browser = $scope.sumbrowsers[l];
							break;
						}
					}
					if($scope.sumTestData.browser==""){
						$scope.sumTestData.browser = $scope.sumbrowsers[0];
					}*/
					for(var l=0; l<$scope.sumbrowsers.length; l++){
						 for(var k=0; k<sumTestData.browserDetails.length; k++){
							if($scope.sumbrowsers[l].dobId == sumTestData.browserDetails[k].dobId){
								$scope.sumTestData.browser.push($scope.sumbrowsers[l].dobId);
							}
						 }
					}
					if($scope.sumTestData.browser.length==0){
						$scope.sumTestData.browser.push($scope.sumbrowsers[0].dobId);
					}
				}
			});
		};
		
		if(sumTestData.smsalert || sumTestData.emailalert){
			$scope.sumTestData.responseAlert = true;
			$scope.sumTestData.sms = sumTestData.smsalert;
			$scope.sumTestData.email = sumTestData.emailalert;
			$scope.defaultWarningLimit = sumTestData.warning;
			$scope.defaultErrorLimit = sumTestData.error;
			$scope.defaultMinBreachCount = sumTestData.minbreachcount;
			$scope.checkResponseAlert();
		}else{
			$scope.sumTestData.responseAlert = false;
			$scope.defaultWarningLimit = 0;
			$scope.defaultErrorLimit = 0;
			$scope.defaultMinBreachCount = 0;
		}
		
		$scope.sumTestData.warning = sumTestData.warning/1000;
		$scope.sumTestData.error = sumTestData.error/1000;
		$scope.sumTestData.rmBreachCount = sumTestData.rm_minbreachcount;
		$scope.sumTestData.amBreachCount = sumTestData.am_minbreachcount;
	}
	
	function formateDate(date){
		months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		currentDate = date;
		var formatedDate = currentDate.getDate() + "-" + (months[currentDate.getMonth()]) + "-" + currentDate.getFullYear();
		return formatedDate;
	};
	
	$scope.appendHttpPrefix = function() {
		var urlregex = new RegExp(sessionServices.get("webURLValidation"),"i");
		$scope.showInfoHttpAppended = false;
		$scope.showHttpMsg = false;
		$scope.showInValidUrlMsg = false;
		if( !/^(http):\/\//i.test($scope.sumTestData.url) && !/^(https):\/\//i.test($scope.sumTestData.url) ) {
			$scope.sumTestData.url = 'http://';
			$scope.showInfoHttpAppended = true;
			$scope.showHttpMsg = true;
			$scope.showInValidUrlMsg = false;
		} else {
			$scope.showHttpMsg = false;
			$scope.showInValidUrlMsg = false;
			if( !urlregex.test($scope.sumTestData.url)) {
				$scope.showInfoHttpAppended = true;
				$scope.showHttpMsg = false;
				$scope.showInValidUrlMsg = true;
			} else {
				$scope.showInfoHttpAppended = false;
				$scope.showHttpMsg = false;
				$scope.showInValidUrlMsg = false;
			}
		}
	};
	
	$scope.setEndDateAsStartDate = function() {
		stDate = $scope.sumTestData.startdate;
		enDate = $scope.sumTestData.enddate;
		if (isdate(stDate)==1){stDate=convertDate(stDate);}
		else {
			stDate = new Date(stDate.toString());
		}
		if (isdate(enDate)==1){enDate=convertDate(enDate);} 
		else {
			enDate = new Date(enDate.toString());
		}
		if (enDate < stDate){enDate=stDate; $scope.sumTestData.enddate=stDate;}
		$scope.sumTestData.enddate = enDate.getDate() + "-" + (months[enDate.getMonth()]) + "-" + enDate.getFullYear();
		
		if ( $scope.formName == "Add" ) {
			var todayDateTime=new Date();
			var todayDate =todayDateTime.getDate()+ "-" +(months[todayDateTime.getMonth()]) + "-" + todayDateTime.getFullYear();
			if (stDate<todayDate){$scope.sumTestAddData.startdate=todayDate;}
		} else if ( $scope.formName == "Edit" ) {
			// while edit for the test, start date changed to have `true`/`false` to send, 
			var startDateSelectedFormatted = formateDate(stDate);
			if ( sumTestData.formatted_startdate != startDateSelectedFormatted ) {
				// start date changed date for scheduled test
				$scope.sumTestData.isStartDateChanged = true;
			} else {
				// start date not changed
				$scope.sumTestData.isStartDateChanged = false;
			}
		}
	};
	
	function isdate(val)
	{
		var date = Date.parse(val);
		if(isNaN(date))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function convertDate(date)
	{
		var monthInNumber={'Jan':'1','Feb':'2','Mar':'3','Apr':'4','May':'5','Jun':'6','Jul':'7','Aug':'8','Sep':'9','Oct':'10','Nov':'11','Dec':'12'};
		var splitDate = date.split("-");
		var convertedDate=new Date(monthInNumber[splitDate[1]]+"/"+splitDate[0]+"/"+splitDate[2]);
		return convertedDate;
	}
	
	$scope.showConnectivityParameters = false;
	$scope.checkConnection = function() {
		if($scope.sumTestData.connection.connectionName == 'Custom'){
			$scope.showConnectivityParameters = true;
			
			/* tried, since to avoid undefined error 
			$scope.sumTestData.download = undefined;
			$scope.sumTestData.upload = undefined;
			$scope.sumTestData.latency = undefined;
			$scope.sumTestData.packetloss = undefined;
			*/ 
			$scope.sumTestData.download = '';
			$scope.sumTestData.upload = '';
			$scope.sumTestData.latency = '';
			$scope.sumTestData.packetloss = '';
		}else{
			$scope.showConnectivityParameters = false;
			$scope.sumTestData.download = $scope.sumTestData.connection.downloadLimit;
			$scope.sumTestData.upload = $scope.sumTestData.connection.uploadLimit;
			$scope.sumTestData.latency = $scope.sumTestData.connection.latencyLimit;
			$scope.sumTestData.packetloss = $scope.sumTestData.connection.packetLoss;
		}
	};
	
	$scope.onlyDigits = function( value ){
		if(value == 'download'){
			$scope.sumTestData.download = $scope.sumTestData.download.replace(/[^0-9]/g, '');
		}else if(value == 'upload'){
			$scope.sumTestData.upload = $scope.sumTestData.upload.replace(/[^0-9]/g, '');
		}else if(value == 'latency'){
			$scope.sumTestData.latency = $scope.sumTestData.latency.replace(/[^0-9]/g, '');
		}else if(value == 'packetloss'){
			$scope.sumTestData.packetloss = $scope.sumTestData.packetloss.replace(/[^0-9]/g, '');
		}else if(value == 'warning'){
			$scope.sumTestData.warning = $scope.sumTestData.warning.replace(/[^0-9]/g, '');
		}else if(value == 'error'){
			$scope.sumTestData.error = $scope.sumTestData.error.replace(/[^0-9]/g, '');
		}else if(value == 'rm_minbreachcount'){
			$scope.sumTestData.rmBreachCount = $scope.sumTestData.rmBreachCount.replace(/[^0-9]/g, '');
		}else if(value == 'am_minbreachcount'){
			$scope.sumTestData.amBreachCount = $scope.sumTestData.amBreachCount.replace(/[^0-9]/g, '');
		}
	};
	
	$rootScope.$on("close_sum_cities_popup", function(event){
		sumModuleServices.getPackages($scope);
	});
	
	$scope.addCities = function() {
		$scope.sumFormSubmitted = true;
		// TODO: thinks, below URL validation to occur manually when user submitted the form, instead of `$scope.$broadcast`
		// calls function in directive
		if ( $scope.sumTestData.testType === 'URL') {
			$scope.$broadcast('triggerURLValidation');
			
		}
		
		$scope.sumTestData.startdate = sessionServices.get("start_date");
		$scope.sumTestData.enddate = sessionServices.get("end_date");

		sdateToCompare = $scope.sumTestData.startdate;
		edateToCompare = $scope.sumTestData.enddate;
		var sDate = Date.parse($scope.sumTestData.startdate);
		var eDate = Date.parse($scope.sumTestData.enddate);
		if (isdate(sdateToCompare)==1){sdateToCompare=convertDate(sdateToCompare);}
		if (isdate(edateToCompare)==1){edateToCompare=convertDate(edateToCompare);}

		var msgContent = "";
		/*if (sDate > eDate)
		{
			msgContent ='End Date must be greater than Start Date';
		}*/
		var isEdit = $scope.formName == 'Edit';
		var isUrl = $scope.sumTestData.testType === 'URL';
		if ($scope.sumTestData.testName.length==0)
		{
			msgContent = 'Test Name is mandatory.';
		} else if (!$scope.sumAddForm.$valid) {
			if($scope.sumTestData.testType == 'URL') {
				if($scope.showInfoHttpAppended) {
					msgContent = 'Invalid URL';
				}
			} else if($scope.sumTestData.testType == 'TRANSACTION'){
				//$scope.sumTestData.status = "true";
				// while adding setting status true
				if(!isEdit){
					$scope.sumTestData.status = "true";
				}
				if($scope.sumTestData.tranasctionImports == undefined || $scope.sumTestData.tranasctionImports == '') {
					msgContent = 'Must enter packages.';
				}
				if($scope.sumTestData.transaction == undefined || $scope.sumTestData.transaction == '') {
					msgContent = 'Must enter transaction.';
				}
			}
		} else if($scope.sumTestData.browser.length==0) {
			msgContent='Please select atleast one browser.';
		} else if($scope.sumTestData.connection == undefined){
			msgContent='Connection is mandatory.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.download == undefined || $scope.sumTestData.download.length <= 0)){
			msgContent='Download Limit is mandatory.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.download > $scope.downloadLimt )){
			msgContent='Download Limit should not exceed '+$scope.downloadLimt+'.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.upload == undefined || $scope.sumTestData.upload.length <= 0)){
			msgContent='Upload Limit is mandatory.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.upload >$scope.uploadLimit )){
			msgContent='Upload Limit should not exceed '+$scope.uploadLimit+'.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.latency == undefined || $scope.sumTestData.latency.length <= 0)){
			msgContent='Latency Limit is mandatory.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.latency > $scope.latencyLimit )){
			msgContent='Latency Limit should not exceed '+$scope.latencyLimit+'.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.packetloss == undefined || $scope.sumTestData.packetloss.length <= 0)){
			msgContent='Packet Data Limit is mandatory.';
		}else if(($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.packetloss > $scope.packetDataLimit )){
			msgContent='Packet Data Limit should not exceed '+$scope.packetDataLimit+'.';
		}else if($scope.sumTestData.responseAlert == undefined || $scope.sumTestData.responseAlert == false ){
			$scope.sumTestData.responseAlert = false;
		}else if($scope.sumTestData.status && $scope.sumTestData.responseAlert){
			/*if($scope.sumTestData.sms == undefined && $scope.sumTestData.email == undefined){
				msgContent='Please select atleast one alert type.';
			}else*/ if($scope.sumTestData.warning == undefined || $scope.sumTestData.warning <= 0){
				msgContent='Please enter Warning Limit.';
			}/*else if( $scope.sumTestData.warning > $scope.warningLimit){
				msgContent='Warning Limit should not exceed '+$scope.warningLimit+'.';
			}*/else if($scope.sumTestData.error == undefined || $scope.sumTestData.error <= 0){
				msgContent='Please enter Error Limit.';
			}/*else if($scope.sumTestData.error > $scope.errorLimit){
				msgContent='Error Limit should not exceed '+$scope.errorLimit+'.';
			}*/else if(parseInt($scope.sumTestData.error) < parseInt($scope.sumTestData.warning)){
				msgContent='Error Threshold should be greater than Warning.';
			}
			else if($scope.sumTestData.rmBreachCount == undefined || $scope.sumTestData.rmBreachCount <= 0){
				msgContent='Please enter Breach Count for Response Monitor.';
			}
		}else if($scope.sumTestData.downTimeAlert == undefined ){
			$scope.sumTestData.downTimeAlert = true;
		}
		
		/*
		if (sDate > eDate || ($scope.sumAddForm.$valid==false && $scope.sumTestData.testType == 'URL')
			|| ($scope.sumAddForm.$valid==false && ($scope.sumTestData.tranasctionImports == undefined || $scope.sumTestData.tranasctionImports == ''))
			|| ($scope.sumAddForm.$valid==false && ($scope.sumTestData.transaction == undefined || $scope.sumTestData.transaction == ''))
			|| $scope.sumTestData.testName.length==0 
			|| $scope.sumTestData.connection == undefined
			|| (($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.download == undefined || $scope.sumTestData.upload == undefined || $scope.sumTestData.latency == undefined || $scope.sumTestData.packetloss == undefined))
			|| (($scope.sumTestData.connection.connectionName == 'Custom') && ( $scope.sumTestData.download > $scope.downloadLimt || $scope.sumTestData.latency > $scope.latencyLimit || $scope.sumTestData.upload >$scope.uploadLimit || $scope.sumTestData.packetloss > $scope.packetDataLimit ))
			|| (($scope.sumTestData.responseAlert != undefined && $scope.sumTestData.responseAlert ) &&($scope.sumTestData.sms == undefined && $scope.sumTestData.email == undefined)) 
			|| (($scope.sumTestData.responseAlert != undefined && $scope.sumTestData.responseAlert ) &&($scope.sumTestData.warning == undefined || $scope.sumTestData.error == undefined || $scope.sumTestData.breachCount == undefined || $scope.sumTestData.warning == "" || $scope.sumTestData.error == "" || $scope.sumTestData.breachCount == ""))
			|| ($scope.sumTestData.warning > $scope.warningLimit ||$scope.sumTestData.error > $scope.errorLimit )
			)*/
		
		if (sDate > eDate || msgContent.length > 0 ) {
			messageService.showWarningMessage(msgContent);
		} else {
			$rootScope.$on("close_sum_parent_popup", function(event){
				$uibModalInstance.dismiss('cancel');
			});
			
			if($scope.sumTestData.testType == "URL"){
				$scope.sumTestData.transaction = '';
			} else {
				$scope.sumTestData.url = '';
			}
			var modalInstance = $uibModal.open({
				//templateUrl: 'modules/sum/view/add_sum_cities.html',
				templateUrl: 'common/views/sum/add_sum_cities.html',
				controller: 'addSumCitiesController',
				size: 'lg',
				resolve: {
					sumTestAddData: function() {
						return $scope.sumTestData;
					},
					citiesData: function() {
						return "";
					},
					saveBtn: function() {
						return $scope.saveBtn;
					}
				}
			});
			
			modalInstance.close();
		}
	};
	
	$scope.close = function() {
		$uibModalInstance.dismiss('cancel');
	};
}]);

appedoApp.controller( 'sumRum360SummaryController', ['$scope', 'sumModuleServices', 'sessionServices', 'rumService', '$state', '$rootScope', function( $scope, sumModuleServices, sessionServices, rumService, $state, $rootScope) {
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('360 View', 'pageOpen', {
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	var resultDonutChartData;
	resultDonutChartData = sumModuleServices.getDonutChartdata("TestStatus");
	resultDonutChartData.then(function(resp) {
		if(resp!=undefined){
			if(resp.success){
					$scope.cTextCompletedDonutData = findAndRemove(resp.message,'label','Total');
					$scope.completedDonutData=[];
					$scope.completedDonutData=resp.message;
					var totalBarVal = 0;
 				for(var i = 0; i<$scope.completedDonutData.length; i= i+1){
 					totalBarVal = totalBarVal + $scope.completedDonutData[i].value;
 				}
 				for(var i = 0; i<$scope.completedDonutData.length; i= i+1) {
 						$scope.completedDonutData[i].barVal = ($scope.completedDonutData[i].value*100)/totalBarVal;
 				}
 			}else{
					$scope.completedDonutData=[];
 			}
			}
	});
	
	var sumAvgPageLoadTimeDonutCount;
	sumAvgPageLoadTimeDonutCount = sumModuleServices.getSumAvgPageLoadTimeDonutCount('1 day');
	sumAvgPageLoadTimeDonutCount.then(function(resp) {
		if(resp!=undefined){
			if(resp.success){
					$scope.cTextSumAvgPageLoadTime = findAndRemove(resp.message,'label','Total');
					$scope.sumAvgPageLoadTime=[];
					$scope.sumAvgPageLoadTime=resp.message;
					var totalBarVal = 0;
 				for(var i = 0; i<$scope.sumAvgPageLoadTime.length; i= i+1){
 					totalBarVal = totalBarVal + $scope.sumAvgPageLoadTime[i].value;
 				}
 				for(var i = 0; i<$scope.sumAvgPageLoadTime.length; i= i+1) {
 						$scope.sumAvgPageLoadTime[i].barVal = ($scope.sumAvgPageLoadTime[i].value*100)/totalBarVal;
 				}
 			}else{
					$scope.sumAvgPageLoadTime=[];
 			}
			}
	});

	var rumAvgPageLoadTimeDonutCount;
	rumAvgPageLoadTimeDonutCount = rumService.getRumAvgPageLoadTimeDonutCount('1 day');
	rumAvgPageLoadTimeDonutCount.then(function(resp) {
		if(resp!=undefined){
			if(resp.success){
				$scope.cTextRumAvgPageLoadTime = findAndRemove(resp.message,'label','Total');
				$scope.rumAvgPageLoadTime=[];
				$scope.rumAvgPageLoadTime=resp.message;
				var totalBarVal = 0;
				for(var i = 0; i<$scope.rumAvgPageLoadTime.length; i= i+1){
					totalBarVal = totalBarVal + $scope.rumAvgPageLoadTime[i].value;
				}
				for(var i = 0; i<$scope.rumAvgPageLoadTime.length; i= i+1) {
						$scope.rumAvgPageLoadTime[i].barVal = ($scope.rumAvgPageLoadTime[i].value*100)/totalBarVal;
				}
			}else{
				$scope.rumAvgPageLoadTime=[];
			}
			}
	});

	var rumUrlWisePageView;
	$scope.noDataMsg = true;
	rumUrlWisePageView = rumService.getRumUrlWisePageView('1 day');
	rumUrlWisePageView.then(function(resp) {
		if(resp!=undefined){
			if(resp.success){
				$scope.noDataMsg = false;
				$scope.rumUrlWisePageView=[];
				$scope.rumUrlWisePageView=resp.message;
				var avgVal = 0;
				for(var i = 0; i<$scope.rumUrlWisePageView.length; i= i+1){
						avgVal = avgVal + $scope.rumUrlWisePageView[i].pageView;
				}
				for(var i = 0; i<$scope.rumUrlWisePageView.length; i= i+1) {
						$scope.rumUrlWisePageView[i].avgLoad = ($scope.rumUrlWisePageView[i].pageView*100)/avgVal;
				}
			}else{
				//$scope.noDataMsg=true;
					$scope.rumUrlWisePageView=[];
			}
		}
	});
	
	$scope.loadSUMManageByStatus = function() {
		$rootScope.backPageFrom = '360View';
		$rootScope.selectedSUMStatus = this.testStatus.label; 
		$state.transitionTo('/sum_metrics');
	};
}]);

appedoApp.controller('slaActionCardController', ['$scope', 'slaActionsService', '$location', '$state', 'sessionServices', '$uibModal', 'ngToast', 'successMsgService', '$rootScope', function ($scope, slaActionsService, $location, $state, sessionServices, $uibModal, ngToast, successMsgService, $rootScope) {
	//card layout
	$scope.slaactions = [];
	$scope.openAddModuleType = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
	$scope.getSlaActionCardData = function() {
		slaActionsService.getSLAActions($scope, function(slaActionCardData) {
			$scope.slaactions = slaActionCardData;
			$scope.showCard = false;
			$scope.showCardEmptyMsg = false;
			if($scope.slaactions.length >0){
				$scope.showCard = true;
			}else {
				$scope.showCardEmptyMsg = true;
			}
		});
	};
	
	$scope.getSlaActionCardData();
	/*var slaActionCard = $rootScope.$on('close_sla_action_parent_popup', function(event) {
		slaActionsService.getSLAActions($scope, function(slaActionCardData) {
			$scope.slaactions = slaActionCardData;
		});
	});*/
	var slaActionCard = $rootScope.$on("close_sla_action_parent_popup", $scope.getSlaActionCardData);
	$scope.$on('$destroy', slaActionCard);
	//edit action
	$scope.editAction = function(){
		$scope.action = this.slaaction;
		var modalInstance = $uibModal.open({
			templateUrl: 'modules/sla/view/add_sla_action.html',
			controller: 'addSlaActionController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return 'fromEdit';
				},
				slaActionFormData: function() {
					return $scope.action;
				},					
				moduleCardContent: function() {
					return $scope.moduleCardContent;
				}							
			}
		});
	};
	$scope.displayMessage = function() {
		$scope.response ={};
		$scope.response.success = false;
		$scope.response.errorMessage = "Action is mapped to rule. Edit and Delete are disabled";
		successMsgService.showSuccessOrErrorMsg($scope.response);
	};
	
	//delete action
	$scope.deleteAction = function() {
		var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			$scope.action = this.slaaction;
			slaActionsService.deleteAction($scope, this.slaaction.action_id, function(data) {
				if(data.success){
					for(var i=0; i<$scope.slaactions.length; i++){
						if($scope.slaactions[i].action_id==$scope.action.action_id){
							$scope.slaactions.splice(i, 1);
						}
					}
				}else{
					successMsgService.showSuccessOrErrorMsg(data);
				}
			});
		}
	};
	
}]);


appedoApp.controller('slaRuleCardController', ['$scope', 'slaRuleService', '$location', '$state', 'sessionServices', '$uibModal', 'ngToast', '$rootScope', 'successMsgService', function ($scope, slaRuleService, $location, $state, sessionServices, $uibModal, ngToast, $rootScope, successMsgService) {

	//card layout
	$scope.slarules = [];
	$scope.openAddModuleType = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
	$scope.getSlaRuleCardData = function() {
		slaRuleService.getSLARules($scope, function(slaRuleCardData) {
			$scope.slarules = slaRuleCardData;
			$scope.showCard = false;
			$scope.showCardEmptyMsg = false;
			if($scope.slarules.length >0){
				$scope.showCard = true;
			}else {
				$scope.showCardEmptyMsg = true;
			}
		});
	};
	/*var slaRuleCard = $rootScope.$on('close_sla_rule_parent_popup', function(event) {
		slaRuleService.getSLARules($scope, function(slaRuleCardData) {
			$scope.slarules = slaRuleCardData;
		});
	});*/
	$scope.getSlaRuleCardData();
	var slaRuleCard = $rootScope.$on("close_sla_rule_parent_popup", $scope.getSlaRuleCardData);
	$scope.$on('$destroy', slaRuleCard);
	//edit rule
	$scope.editRule = function() {
		$scope.rule = this.slarule;
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/add_sla_rule.html',
			controller: 'addSlaRuleController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return 'fromEdit';
				},
				slaRuleFormData: function() {
					return $scope.rule;
				},						
				moduleCardContent: function() {
					return $scope.moduleCardContent;
				}							
			}
		});
	};
	
	$scope.displayMessage = function() {
		$scope.response ={};
		$scope.response.success = false;
		$scope.response.errorMessage = "Rule is mapped to Policy. Edit and Delete are disabled";
		successMsgService.showSuccessOrErrorMsg($scope.response);
	};
	
	//delete Rule
	$scope.deleteRule = function() {
		var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			$scope.rule = this.slarule;
			slaRuleService.deleteRule($scope, this.slarule.rule_id, function(data) {
				if(data.success){
					for(var i=0; i<$scope.slarules.length; i++){
						if($scope.slarules[i].rule_id==$scope.rule.rule_id){
							$scope.slarules.splice(i, 1);
						}
					}
				}
			});
		}
	};
}]);

appedoApp.controller('slaCardController', ['$scope', 'slacardService', '$location', '$state', 'sessionServices', '$uibModal', 'ngToast', '$rootScope', 'messageService', function ($scope, slacardService, $location, $state, sessionServices, $uibModal, ngToast, $rootScope, messageService) {
	$scope.slaMsg ='Policy';
	$scope.showCardEmptyMsg = false;
	$scope.showSLAGrid = true;
	$scope.showAlertLog = false;
	$scope.showHealLog = false;
    $scope.showLoading = false;
	//$scope.showDownloadOption = false;
    
	var loginUser = JSON.parse(sessionServices.get('loginUser'));
	var emailIds = ["sales_test@appedo.com","sales_test@softsmith.com"];
	
	$scope.showDownloadOption = (emailIds.indexOf(loginUser.emailId) >= 0);
	
    $scope.slas = [];
    
	$scope.slaPolicyRadio = {};
	// default to have, user added SLAs
	$scope.slaPolicyRadio.mode = 'USER';
	
	// added CI trigger for SLA policy page
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('SLA policy cardlayout', 'pageOpen', 
		{
				page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	$scope.openAddModuleType = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
	
	$scope.getSlaPolicyCardData = function() {
		$scope.slas = [];
		$scope.showCardEmptyMsg = false;
		showLoading();
		
		var moduleCode = ($scope.slaPolicyRadio.mode === 'SUM' || $scope.slaPolicyRadio.mode === 'RUM' ? $scope.slaPolicyRadio.mode : 'ASD');
		
		slacardService.getSLAGrid($scope, ($scope.slaPolicyRadio.mode==='USER'?false:true), moduleCode, function(data) {
			hideLoading();
			
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.slas = data.message;
				$scope.showCard = false;
				
				if( $scope.slas.length > 0 ){
					$scope.showCardEmptyMsg = false;
					$scope.showCard = true;
					
				} else {
					$scope.showCardEmptyMsg = true;
				}
			}
			
		});
	};
	/*var slaPolicyCard = $rootScope.$on('close_sla_policy_parent_popup', function(event) {
		slacardService.getSLAGrid($scope, function(slaCardData) {
			$scope.slas = slaCardData;
		});
	});*/
	$scope.getSlaPolicyCardData();
	var slaPolicyCard = $rootScope.$on("reloadSLACardLayout", $scope.getSlaPolicyCardData);
	$scope.$on('$destroy', slaPolicyCard);
	
	$scope.openAlertLog = function() {
		$scope.slaMsg ='Alert Log - '+this.sla.sla_name;
		$scope.showSLAGrid = false;
		$scope.showAlertLog = true;
		$scope.showHealLog = false;
		
		$scope.pagination = {};
		$scope.pagination.currentPage = 1;
		var numPerPage = 10;
		$scope.maxSize = 5;
		$scope.slaId = this.sla.sla_id;
		$scope.selectedPage = function(page) {
			$scope.slaAlerts = [];
			var offSet = ((page - 1) * numPerPage);
			showLoading();
			
			slacardService.getSLAAlerLog($scope, $scope.slaId, offSet, numPerPage, function(slaALerLogCardData) {
				hideLoading();
				
				$scope.slaAlerts = {};
				$scope.totalLength = slaALerLogCardData.total_count;
				$scope.slaAlerts = slaALerLogCardData.log_records;
			});
		};
		$scope.selectedPage(1);
		
		/*slacardService.getSLAAlerLog($scope, this.sla.sla_id, function(slaALerLogCardData) {
			$scope.slaAlerts = slaALerLogCardData;
		});*/
	};
	
	$scope.openHealLog = function() {
		$scope.slaMsg ='Heal Log - '+this.sla.sla_name;
		$scope.showSLAGrid = false;
		$scope.showAlertLog = false;
		$scope.showHealLog = true;
		showLoading();
		
		$scope.slaHeals = [];
		
		slacardService.getSLAHealLog($scope, this.sla.sla_id, function(slaHealLogCardData) {
			hideLoading();
			
			$scope.slaHeals = slaHealLogCardData;
		});
	};
	
	$scope.showLogFile = function() {
		var logFileName = this.heal.Exec_log;
		var modalInstance = $uibModal.open({
			templateUrl: 'modules/sla/view/show_exec_log.html',
			controller: 'showExecLogController',
			size: 'lg',
			resolve: {
				item: function () {
					return logFileName;
				}							
			}
		});
	};
	
	$scope.goBack = function() {
		$scope.slaMsg ='Policy';
		$scope.showSLAGrid = true;
		$scope.showAlertLog = false;
		$scope.showHealLog = false;
	};
	
	$scope.editSLAPolicy = function() {
		//$scope.sla = this.sla;
		var joSelectedSLAPolicy = this.sla;
		slacardService.openAddorEditSLAPolicy('fromEdit', joSelectedSLAPolicy, $scope.moduleCardContent);
	};
	
	$scope.deleteSLAPolicy = function() {
		if( $scope.slaPolicyRadio.mode === 'SUM' ){
			messageService.showWarningMessage('Policy cannot be deleted as it is mapped to a SUM Test.');
		} else {
			var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
		}
		if(result == true) {
			$scope.sla = this.sla;
			
			slacardService.deleteSLAPolicy($scope, $scope.sla.sla_id, function(data) {
				if( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					messageService.showSuccessMessage(data.message);
					// reload SLA card data
					$scope.getSlaPolicyCardData();
					/* ignored slice 
					for(var i=0; i<$scope.slas.length; i++){
						if($scope.slas[i].sla_id==$scope.sla.sla_id){
							$scope.slas.splice(i, 1);
						}
					}
					*/
				}
			});
		}
	};
	
	// activate or deactivate SLA policy
	$scope.enableOrDisableSLAPolicy = function() {
		var joSLA = this.sla;
		var result = confirm("Are you sure you want to "+(joSLA.isActive ? 'disable' : 'enable' )+" the alert?");
		if(result == true) {
			slacardService.enableOrDisableSLAPolicy($scope, joSLA.sla_id, ! joSLA.isActive, function(data) {
				if( ! data.success ) {
					// error
					messageService.showErrorMessage(data.errorMessage);
				} else {
					messageService.showSuccessMessage(data.message);
					
					// reload SLA card data
					$scope.getSlaPolicyCardData();
				}
			});
		}
	};
	
	function showLoading() {
		$scope.showLoading = true;
	}
	function hideLoading() {
		$scope.showLoading = false;
	}
	
	// map counter(s) to the selected SLA
	$scope.mapCountersToSLA = function() {
		var joSelectedSLAPolicy = this.sla;
		
  		// open SLA's mapped counters
  		slacardService.openSLAViewMappedCounters('fromEdit', joSelectedSLAPolicy, joSelectedSLAPolicy.sla_id);
	};
	
	// opens SLA setting page
	$scope.openSettingsPage = function() {
		slacardService.openSettingsPage('fromAdd', $scope.moduleCardContent);
	};
}]);

appedoApp.controller('showExecLogController', ['$scope', '$uibModal',  '$uibModalInstance', 'item', 'slacardService',
  	function($scope, $uibModal, $uibModalInstance, execFileName, slacardService) {
		
		
		$scope.cardLayout = function() {
	  	      $uibModalInstance.dismiss('cancel');
	  	};
	  	
	  	var log;
		log = slacardService.getExecLogFile(execFileName);
		log.then(function(data) {
			$scope.logdata = data.message;
		});
}]);

appedoApp.controller('slaSlaveCardController', ['$scope', 'slaSlaveService', '$location', '$state', 'sessionServices', '$uibModal', 'ngToast', function ($scope, slaSlaveService, $location, $state, sessionServices, $uibModal, ngToast) {

	var timerSlaveStatus;
	$scope.getAgentStatus = function() {
		clearTimeout(timerSlaveStatus);
		
		slaSlaveService.getSlaveStatus($scope, function(slaSlaveCardData) {
			$scope.slaves = slaSlaveCardData;
		});
		
		timerSlaveStatus = setTimeout($scope.getAgentStatus, sessionServices.get("textRefresh"));
	};
	
	$scope.getAgentStatus();
	
	$scope.$on('$destroy', function() {
		clearTimeout(timerSlaveStatus);
    });
	
}]);

appedoApp.controller('addSlaActionController', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'slaActionFormData', 'moduleCardContent', 'successMsgService', 'slaActionsService', '$rootScope',
  function($scope, $uibModal, $uibModalInstance, isFrom, slaActionFormData, moduleCardContent, successMsgService, slaActionsService, $rootScope) {
    $scope.close = function() {
        $uibModalInstance.dismiss('cancel');
    };

    $scope.moduleCardContent=moduleCardContent;
    
    $scope.slaActionForm = {};
    $scope.submitted = false;
    $scope.showProceed = true;
    
    $scope.validateActionName = function () {
    	if($scope.slaActionForm.actionName != undefined && $scope.slaActionForm.actionName != ''){
	    	slaActionsService.isValidActionName($scope, $scope.slaActionForm.actionName, $scope.slaActionForm.actionId, function(data) {
	    		if(data.success){
	    			$scope.showProceed = data.isAvailable;
	    			if(data.isAvailable){
	    				$scope.response ={};
	            		$scope.response.success = false;
	            		$scope.response.errorMessage = "This Action name already exists.";
	            		successMsgService.showSuccessOrErrorMsg($scope.response);
	    			}
	    		}else{
	    			$scope.showProceed = true;
	    		}
	    	});
    	}
    };
    
    if(isFrom == 'fromEdit') {
    	$scope.slaActionForm.actionId = slaActionFormData.action_id;
    	$scope.slaActionForm.actionName = slaActionFormData.action_name;
    	$scope.slaActionForm.radioPublicORPrivate = slaActionFormData.is_public == true?'public':'pvt';
    	$scope.slaActionForm.actionDescription = slaActionFormData.action_description;
    	$scope.slaActionForm.parameterType = slaActionFormData.parameter_format;
    	$scope.slaActionForm.scriptParameter = slaActionFormData.parameter_values;
    	if(slaActionFormData.is_public){
    		$scope.slaActionForm.radioPublicORPrivate = 'public';
    	}else{
    		$scope.slaActionForm.radioPublicORPrivate = 'pvt';
    	}
    	$scope.slaActionForm.type = slaActionFormData.type;
    	$scope.slaActionForm.actionScript = slaActionFormData.script;
    	$scope.validateActionName();
    } else {
	    $scope.slaActionForm.getPublicAction = false;
	    $scope.slaActionForm.radioPublicORPrivate="pvt";
	    $scope.slaActionForm.parameterType="json";
    }
    
    $scope.addActionScript = function() {
    	$rootScope.$on("close_sla_action_parent_popup", function(event){
    		$uibModalInstance.close();
    	});
    	var modalInstance = $uibModal.open({
			 templateUrl: 'common/views/sla/add_sla_action_script.html',
			 controller: 'addSlaActionScriptController',
			 size: 'lg',
			 resolve: {
				 isFrom: function() {
					 return isFrom;
				 },
				 slaActionForm: function() {
					 return $scope.slaActionForm;
				 },
				 moduleCardContent: function() {
					 return $scope.moduleCardContent;
				 }
			 }
		 });
    };
}]);

appedoApp.controller('addSlaActionScriptController', ['$scope', 'slaActionsService', '$uibModal', '$uibModalInstance',  'slaActionForm', 'ngToast', 'isFrom','moduleCardContent', 'successMsgService', '$rootScope',
    function($scope, slaActionsService, $uibModal, $uibModalInstance,  slaActionForm,  ngToast, isFrom, moduleCardContent, successMsgService, $rootScope) {

        $scope.close = function() {
            $uibModalInstance.dismiss('cancel');
        };
        
        $scope.slaActionForm = slaActionForm;
        $scope.moduleCardContent=moduleCardContent;
        $scope.submitted = false;
        
        if(isFrom == 'fromEdit') {
        	$scope.slaActionForm.scriptType = slaActionForm.type;
        	$scope.slaActionForm.actionScript = slaActionForm.actionScript;
        } else {
    	    $scope.slaActionForm.scriptType="shell";
        }
        
        $scope.addActionSave = function() {
//        	$scope.submitted = true;
        	var isvalidated = true;
        	var msgContent = "";
        	if($scope.slaActionForm.actionScript==undefined || $scope.slaActionForm.actionScript == '' || $scope.slaActionForm.actionScript.length<0){
        		isvalidated = false;
        		msgContent = "Script Content ";
        	}
        	
        	if( isvalidated ) {
        		//service for add action
            	if(isFrom == 'fromEdit') {
            		slaActionsService.updateSLAAction($scope, $scope.slaActionForm, $scope.moduleCardContent, function(data) {
            			if(data.success){
            				$rootScope.$emit('close_sla_action_parent_popup');
            				$uibModalInstance.dismiss('cancel');
            				var modalInstance = $uibModal.open({
                                templateUrl: 'modules/sla/view/sla_action_success.html',
                                controller: 'addSlaActionSaveController',
                                size: 'lg',
                                resolve: {
                    				isFrom: function() {
                    					return isFrom;
                    				},
                                    slaActionForm: function() {
                                        return $scope.slaActionForm;
                                    },
                					moduleCardContent: function() {
                						return $scope.moduleCardContent;
                					}
                                }
                            });
            			}else{
            				successMsgService.showSuccessOrErrorMsg(data);
            			}
            		});
                }else{
                	slaActionsService.addSLAAction($scope, $scope.slaActionForm, $scope.moduleCardContent, function(data) {
                		if(data.success){
                			$rootScope.$emit('close_sla_action_parent_popup');
                			$uibModalInstance.dismiss('cancel');
                			var modalInstance = $uibModal.open({
                                templateUrl: 'modules/sla/view/sla_action_success.html',
                                controller: 'addSlaActionSaveController',
                                size: 'lg',
                                resolve: {
                    				isFrom: function() {
                    					return isFrom;
                    				},
                                    slaActionForm: function() {
                                        return $scope.slaActionForm;
                                    },
                					moduleCardContent: function() {
                						return $scope.moduleCardContent;
                					}
                                }
                            });
                		}else{
            				successMsgService.showSuccessOrErrorMsg(data);
            			}
                	});
                }
        	}else{
        		$scope.response ={};
        		$scope.response.success = false;
        		$scope.response.errorMessage = msgContent+" is mandatory.";
        		successMsgService.showSuccessOrErrorMsg($scope.response);
        	}
        };
    }
]);

appedoApp.controller('addSlaActionSaveController', ['$scope', '$uibModal', '$uibModalInstance',  'slaActionForm', 'ngToast', 'isFrom','moduleCardContent',
  function($scope, $uibModal, $uibModalInstance,  slaActionForm,  ngToast, isFrom, moduleCardContent) {

      $scope.cardLayout = function() {
    	  	$uibModalInstance.dismiss('cancel');
      };
      if(isFrom == 'fromEdit') {
    	  $scope.isEditEnabled = true;
      }
      $scope.slaActionForm = slaActionForm;
      $scope.moduleCardContent=moduleCardContent;
}]);

appedoApp.controller('addSlaRuleController', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'slaRuleFormData', 'moduleCardContent', 'slaRuleService', '$rootScope', 'successMsgService',
      function($scope, $uibModal, $uibModalInstance, isFrom, slaRuleFormData, moduleCardContent, slaRuleService, $rootScope, successMsgService) {
		$scope.close = function() {
			$uibModalInstance.dismiss('cancel');
		};
		
		$scope.moduleCardContent=moduleCardContent;
//		$scope.submitted = false;
		$scope.showProceed = true;
		$scope.slaRuleForm = {};
		
		var getactions;
		getactions = slaRuleService.getActionsForMapping();
		getactions.then(function(data) {
			$scope.slaRuleForm.actions = data.message;
		});
		
		var getactions;
		getactions = slaRuleService.getActionsForMapping();
		getactions.then(function(data) {
			$scope.slaRuleForm.actions = data.message;
		});
		
		$scope.validateRuleName = function () {
			if($scope.slaRuleForm.ruleName != undefined && $scope.slaRuleForm.ruleName != ''){
				slaRuleService.isValidRuleName($scope, $scope.slaRuleForm.ruleName, $scope.slaRuleForm.ruleId,function(data) {
					if(data.success){
						$scope.showProceed = data.isAvailable;
		    			if(data.isAvailable){
		    				$scope.response ={};
		            		$scope.response.success = false;
		            		$scope.response.errorMessage = "This Rule name already exists.";
		            		successMsgService.showSuccessOrErrorMsg($scope.response);
		    			}
		    		}else{
		    			$scope.showProceed = true;
		    		}
		    	});
			}
	    };
	    
		if(isFrom == 'fromEdit') {
		  	$scope.slaRuleForm.ruleId = slaRuleFormData.rule_id;
		  	$scope.slaRuleForm.ruleName = slaRuleFormData.rule_name;
		  	$scope.slaRuleForm.ruleDescription = slaRuleFormData.ruleDescription;
		  	$scope.validateRuleName();
		  	
		  	var rules;
			rules = slaRuleService.getMappedRules($scope.slaRuleForm.ruleId);
			rules.then(function(data) {
				$scope.slaRuleForm.ruleactions = data;
			});
		} else {
			slaRuleService.getActionsForMapping($scope, function(data) {
				$scope.slaRuleForm.actions = data.message;
			});
		}
		
		$scope.saveRuleAndMapAction = function() {
			$rootScope.$on("close_sla_rule_parent_popup", function(event){
				$uibModalInstance.close();
			});
		  $scope.submitted = true;
		  if( this.ruleForm.$valid ) {
			  var modalInstance = $uibModal.open({
				  templateUrl: 'modules/sla/view/sla_map_rule_action.html',
				  controller: 'mapSlaRuleAction',
				  size: 'lg',
				  resolve: {
					  isFrom: function() {
						  return isFrom;
					  },
					  slaRuleForm: function() {
						  return $scope.slaRuleForm;
					  },
					  moduleCardContent: function() {
						  return $scope.moduleCardContent;
					  }
				  }
			  });
		  }
	  };
}]);

appedoApp.controller('mapSlaRuleAction', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'slaRuleForm', 'moduleCardContent', 'slaRuleService', 'ngToast', '$rootScope',
	function($scope, $uibModal, $uibModalInstance, isFrom, slaRuleForm, moduleCardContent, slaRuleService, ngToast, $rootScope) {
		$scope.close = function() {
			$uibModalInstance.dismiss('cancel');
		};
		$scope.actions = [];
		$scope.selectedActions = [];
		$scope.moduleCardContent = moduleCardContent;
		$scope.slaRuleForm = slaRuleForm;
		$scope.submitted = false;
		
		$scope.tempactions = [];
//		var getactions;
//		getactions = slaRuleService.getActionsForMapping();
//		getactions.then(function(data) {
//			$scope.actions = data.message;
//			$scope.selectedActions = $scope.actions;
//		});
		
		$scope.actions = $scope.slaRuleForm.actions;
		$scope.selectedActions = $scope.slaRuleForm.actions;
		
		$scope.validateActions = function(){
			$scope.tempactions = [];
			for(var j=0; j<$scope.selectedActions.length; j++){
				if($scope.selectedActions[j].isSelected){
					$scope.submitted = true;
					$scope.tempactions.push($scope.selectedActions[j]);
				}
			}
			if($scope.tempactions.length>0){
				$scope.submitted = true;
			}else{
				$scope.submitted = false;
			}
		};
		
		
		if(isFrom == 'fromEdit') {
//			var rules;
//			rules = slaRuleService.getMappedRules($scope.slaRuleForm.ruleId);
//			rules.then(function(data) {
//				$scope.ruleactions = data;
//				for(var j=0; j<$scope.selectedActions.length; j++){
//					for(var i=0; i<$scope.ruleactions.length; i++){
//						if($scope.ruleactions[i].actionId==$scope.selectedActions[j].actionId){
//							$scope.selectedActions[j].isSelected = true;
//						}
//					}
//				}
//				$scope.validateActions();
//			});
			
			$scope.ruleactions = slaRuleForm.ruleactions;
			for(var i=0; i<$scope.ruleactions.length; i++){
				for(var j=0; j<$scope.selectedActions.length; j++){
					if($scope.ruleactions[i].actionId==$scope.selectedActions[j].actionId){
						$scope.selectedActions[j].isSelected = true;
					}
				}
			}
			$scope.validateActions();
		} else {
		}
		
		$scope.saveMappedActions = function() {
			
		  // save rule service
			$scope.slaRuleForm.actions = $scope.selectedActions;
//			for(var j=0; j<$scope.selectedActions.length; j++){
//				if($scope.selectedActions[j].isSelected){
//					$scope.submitted = true;
//				}
//			}
			if($scope.submitted){
				if(isFrom == 'fromEdit'){
					slaRuleService.updateSLARule($scope, $scope.slaRuleForm, $scope.moduleCardContent, function(data) {
			      		if(data.success){
			      			$rootScope.$emit('close_sla_rule_parent_popup');
			      			$uibModalInstance.close();
			      			var modalInstance = $uibModal.open({
			      	          templateUrl: 'modules/sla/view/sla_rule_success.html',
			      	          controller: 'slaRuleSuccess',
			      	          size: 'lg',
			      	          resolve: {
			      				isFrom: function() {
			      					return 'fromEdit';
			      	  	  			},
			      	  	            slaRuleForm: function() {
			      	  	            	return $scope.slaRuleForm;
			      	  	            },
			      	  	  			moduleCardContent: function() {
			      	  	  				return $scope.moduleCardContent;
			      	  	  			}
			      	  	     	}
			      	  	   });
			      		}
			      	});
				}else{
					slaRuleService.addSLARule($scope, $scope.slaRuleForm, $scope.moduleCardContent, function(data) {
			      		if(data.success){
			      			$rootScope.$emit('close_sla_rule_parent_popup');
			      			$uibModalInstance.close();
			      			var modalInstance = $uibModal.open({
			      	          templateUrl: 'modules/sla/view/sla_rule_success.html',
			      	          controller: 'slaRuleSuccess',
			      	          size: 'lg',
			      	          resolve: {
			      				isFrom: function() {
			      					return 'fromAdd';
			      	  	  			},
			      	  	            slaRuleForm: function() {
			      	  	            	return $scope.slaRuleForm;
			      	  	            },
			      	  	  			moduleCardContent: function() {
			      	  	  				return $scope.moduleCardContent;
			      	  	  			}
			      	  	     	}
			      	  	   });
			      		}
			      	});
				};
			}else{
				ngToast.create({
					className: 'warning',
					content: 'Select atleast one action',
					timeout: 5000,
					dismissOnTimeout: true,
					dismissButton: true,
					animation: 'fade'
					});
			}
	   };
}]);

appedoApp.controller('slaRuleSuccess', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'moduleCardContent', 'slaRuleForm',
  	function($scope, $uibModal, $uibModalInstance, isFrom, moduleCardContent, slaRuleForm) {

		$scope.cardLayout = function() {
	  	      $uibModalInstance.dismiss('cancel');
	  	};
	  	
	  	if(isFrom == 'fromEdit') {
	  		$scope.isEditEnabled = true;
	  	}
	  	$scope.moduleCardContent=moduleCardContent;
	  	$scope.slaRuleForm = slaRuleForm;
}]);

appedoApp.controller('addSlaPolicyController', ['$scope', '$uibModal', '$uibModalInstance', 'ngToast', 'isFrom', 'moduleCardContent', 'slaPolicyFormData', 'slacardService', '$rootScope', 'successMsgService', 'sessionServices', 'messageService', 
	function($scope, $uibModal, $uibModalInstance, ngToast, isFrom, moduleCardContent, slaPolicyFormData, slacardService, $rootScope, successMsgService, sessionServices, messageService) {
		var loginUser = JSON.parse(sessionServices.get('loginUser'));
		var emailIds = ["sales_test@appedo.com","sales_test@softsmith.com"];
		$scope.showAlertOption = false;
		if(emailIds.indexOf(loginUser.emailId)>=0){
			$scope.showAlertOption = true;
		}else{
			$scope.showAlertOption = false;
		}

		// $scope.submitted = false;
		$scope.showProceed = true;
		$scope.slaPolicyForm = {};
		$scope.rules = [];
		$scope.slas = [];
		$scope.slaPolicyForm.type = 'Alert';
		$scope.moduleCardContent = moduleCardContent;
		
		$scope.close = function() {
			//$uibModalInstance.dismiss('cancel');
			$uibModalInstance.close();
		};
		
		$scope.validatePolicyName = function () {
			var isvalid = true;
			if($scope.slaPolicyForm.policyName != undefined && $scope.slaPolicyForm.policyName != ''){
				slacardService.isValidPolicyName($scope, $scope.slaPolicyForm.policyName, $scope.slaPolicyForm.slaId, function(data) {
					if(data.success){
						$scope.showProceed = data.isAvailable;
						if( data.isAvailable ){
							// err, Policy already exists
							messageService.showErrorMessage('This Policy name already exists.');
						}
					} else {
						$scope.showProceed = true;
					}
				});
			}
		};
		
		if(isFrom == 'fromEdit') {
			var rules;
			rules = slacardService.getRulesForMapping();
			rules.then(function(data) {
				$scope.rules = data.message;
				$scope.slaPolicyForm.slaId = slaPolicyFormData.sla_id;
				$scope.slaPolicyForm.policyName = slaPolicyFormData.sla_name;
				$scope.slaPolicyForm.policyDescription = slaPolicyFormData.description;
				$scope.slaPolicyForm.type = slaPolicyFormData.type;
				$scope.slaPolicyForm.policySvr = slaPolicyFormData.policySvr;
				$scope.slaPolicyForm.policySvrType = slaPolicyFormData.policySvrType;
				$scope.slaPolicyForm.activePolicy = slaPolicyFormData.isActive;
				
				for(var i=0; i<$scope.rules.length; i++){
					if($scope.rules[i].ruleId==slaPolicyFormData.ruleId){
						$scope.slaPolicyForm.mappedRule = $scope.rules[i];
					}
				}
				$scope.validatePolicyName();
			});
			$scope.validatePolicyName();
		} else {
			$scope.slaPolicyForm.activePolicy = true;
    	  
			var rules;
			rules = slacardService.getRulesForMapping();
			rules.then(function(data) {
				$scope.rules = data.message;
			});
		}
		$scope.addPolicySaveAndMapSvr = function() {
			$rootScope.$on("close_sla_policy_parent_popup", function(event){
				$uibModalInstance.close();
			});
			$scope.submitted = true;
			
			//	if( this.policyForm.$valid ){
			if( $scope.slaPolicyForm.type === 'Alert&Heal' ){
				// add/edit server details for the SLA, to perform heal action
				slacardService.openSLAHealMapToServer(isFrom, $scope.slaPolicyForm, $scope.moduleCardContent);
			} else if( isFrom === 'fromEdit' ) {
				// update SLA policy 
				slacardService.updateSLAPolicy($scope, $scope.slaPolicyForm, function(data) {
					if( ! data.success ) {
						// err
						messageService.showErrorMessage(data.errorMessage);
					} else {
						$rootScope.$emit('close_sla_policy_parent_popup');
						$rootScope.$emit('reloadSLACardLayout');
						$uibModalInstance.close();
						
						// open SLA policy success fully added or updated
						slacardService.openSLAPolicySuccess(isFrom, $scope.slaPolicyForm, $scope.slaPolicyForm.slaId);
					}
				});
			} else {
				// add SLA policy, save redirect to grid
				slacardService.addSLAPolicy($scope, $scope.slaPolicyForm, function(data) {
					if( ! data.success ) {
						// err
						messageService.showErrorMessage(data.errorMessage);
					} else {
						$rootScope.$emit('close_sla_policy_parent_popup');
						$rootScope.$emit('reloadSLACardLayout');
						
						// open SLA policy success fully added or updated
						slacardService.openSLAPolicySuccess(isFrom, $scope.slaPolicyForm, data.slaId);
					}
				});
			}
		};
	}
]);

appedoApp.controller('slaPolicyMapSvrController', ['$scope', '$uibModal', '$uibModalInstance',  'slaPolicyForm', 'ngToast', 'isFrom','moduleCardContent', 'slacardService', '$rootScope',
   function($scope, $uibModal, $uibModalInstance,  slaPolicyForm,  ngToast, isFrom, moduleCardContent, slacardService, $rootScope) {

		$scope.submitted = false;
		$scope.moduleCardContent=moduleCardContent;
		$scope.slaPolicyForm = slaPolicyForm;
		if(isFrom == 'fromEdit') {
			$scope.slaPolicyForm.policySvrType = slaPolicyForm.policySvrType;
			$scope.slaPolicyForm.policySvr = JSON.stringify(slaPolicyForm.policySvr);
		} else {
			$scope.slaPolicyForm.policySvrType="json";
		}
		
		$scope.close = function() {
			//$uibModalInstance.dismiss('cancel');
			$uibModalInstance.close();
		};

		$scope.addPolicySave = function() {
			$scope.submitted = true;
			if( this.slaPolicyMapSvrForm.$valid ){
				if(isFrom == 'fromEdit'){
					slacardService.updateSLAPolicy($scope, $scope.slaPolicyForm, function(data) {
						if(data.success){
							$rootScope.$emit('close_sla_policy_parent_popup');
							$rootScope.$emit('reloadSLACardLayout');
							$uibModalInstance.close();
        				  
							// open SLA policy success fully added or updated
							slacardService.openSLAPolicySuccess(isFrom, $scope.slaPolicyForm, $scope.slaPolicyForm.slaId);
						}
					});
				} else {
					slacardService.addSLAPolicy($scope, $scope.slaPolicyForm, function(data) {
						
						if(data.success){
							$rootScope.$emit('close_sla_policy_parent_popup');
							$rootScope.$emit('reloadSLACardLayout');
							$uibModalInstance.close();
        				  
							// open SLA policy success fully added or updated
							slacardService.openSLAPolicySuccess(isFrom, $scope.slaPolicyForm, data.slaId);
						}
					});
				}
			}
		};
	}
]);

appedoApp.controller('slaPolicySuccess', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'slaPolicyForm', 'slaId', '$rootScope', 'slacardService',
  	function($scope, $uibModal, $uibModalInstance, isFrom, slaPolicyForm, slaId, $rootScope, slacardService) {
		if(isFrom=='fromEdit'){
			$scope.isEditEnabled = true;
		}
		$scope.slaPolicyForm = slaPolicyForm;
		
		$scope.cardLayout = function() {
	  	      $uibModalInstance.dismiss('cancel');
	  	};
	  	
//	  	$scope.moduleCardContent=moduleCardContent;
	  	$scope.mapCounter = function() {
	  		$rootScope.$on("close_sla_counter_parent_popup", function(event){
	  			$uibModalInstance.close();
	  		});
		  
	  		// open SLA's mapped counters
	  		slacardService.openSLAViewMappedCounters(isFrom, $scope.slaPolicyForm, slaId);
	  	};
}]);


appedoApp.controller('slaPolicyViewMapCounter', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'slaPolicyDetails', 'slaId', 'slacardService', '$rootScope', 'messageService',
 	function($scope, $uibModal, $uibModalInstance, isFrom, slaPolicyDetails, slaId, slacardService, $rootScope, messageService) {
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	$scope.mappedcounters = [];
	$scope.slaPolicyDetails = slaPolicyDetails;
	
	
	$scope.getMapCounters = function() {
		var counters;
		counters = slacardService.getMapCounters(slaId);
		counters.then(function(data) {
			if( ! data.success ){
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.mappedcounters = data.message;
			}
		});
	};
	$scope.getMapCounters();
	
	$scope.deleteMapCounter = function() {
		var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			var mapcounter;
			mapcounter = slacardService.deleteMapCounter(slaId, this.counter.mapCounterId, this.counter.guid);
			mapcounter.then(function(data) {
				if( ! data.success ){
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.getMapCounters();
					$rootScope.$emit('reloadSLACardLayout');
				}
			});
		}
	};
	
	$scope.editMapCounter = function() {
		$scope.counter = this.counter;
		$rootScope.$emit('close_sla_policy_parent_popup');
		$uibModalInstance.close();
		
		// edit the already added counter for the SLA 
		slacardService.openSLAMapToCounter("fromEdit", $scope.slaPolicyDetails, $scope.counter, slaId);
	};
	
 	$scope.cardLayout = function() {
 		$scope.counter = this.counter;
		$rootScope.$emit('close_sla_policy_parent_popup');
		$uibModalInstance.close();
		
		// add counter for particular SLA
		slacardService.openSLAMapToCounter("addForm", $scope.slaPolicyDetails, $scope.slaActionForm, slaId);
   	};
   	
   	$scope.closemodal = function() {
   		$rootScope.$emit('close_sla_counter_parent_popup');
		$uibModalInstance.close();
   	};
}]);

appedoApp.controller('slaViewMappedCountersChart', ['$scope', '$uibModal',  '$uibModalInstance', 'uid', 'counterId', 'chartName', 'unit', 'slacardService', '$rootScope', 'messageService',
  	function($scope, $uibModal, $uibModalInstance, uid, counterId, chartName, unit, slacardService, $rootScope, messageService) {
 	$scope.close = function () {
 		$uibModalInstance.dismiss('cancel');
 	};
 	$scope.counter = {};
 	$scope.mappedcounters = [];
 	$scope.chartName = chartName;
 	$scope.counter.uid = uid;
 	$scope.counter.refId = uid;
 	$scope.counter.unit = unit;
	$scope.counter.counterId = counterId;
 	
 	$scope.getMapCounters = function() {
 		var counters;
 		counters = slacardService.getCounterMappedAlerts($scope.counter.uid, $scope.counter.counterId);
 		counters.then(function(data) {
 			if( ! data.success ){
 				// err
 				messageService.showErrorMessage(data.errorMessage);
 			} else {
 				$scope.mappedcounters = data.message;
 			}
 		});
 	};
 	$scope.getMapCounters();
 	
 	$scope.deleteMapCounter = function() {
 		var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
 		if(result == true) {
 			var mapcounter;
 			mapcounter = slacardService.deleteMapCounter(this.counter.slaId, this.counter.slaCounterId, this.counter.guid);
 			mapcounter.then(function(data) {
 				if( ! data.success ){
 					// err
 					messageService.showErrorMessage(data.errorMessage);
 				} else {
 					$scope.getMapCounters();
 					//$rootScope.$emit('reloadSLACardLayout');
 				}
 			});
 		}
 	};
 	
 	$scope.editMapCounter = function() {
 		$scope.counter = this.counter;
 		$uibModalInstance.close();
 		
 		// edit the already added counter for the SLA 
 		slacardService.openSLAAddAlterCounterChart("editAlert", $scope.counter, $scope.chartName);
 	};
 	
  	$scope.mapToExisting = function() {
  		//$scope.counter = this.counter;
 		$uibModalInstance.close();
 		
 		// add counter for particular SLA
 		slacardService.openSLAAddAlterCounterChart("mapToExisting", $scope.counter, $scope.chartName);
    	};
    	
	$scope.createNewAlert = function() {
  		//$scope.counter = this.counter;
 		$uibModalInstance.close();
 		
 		// add counter for particular SLA
 		slacardService.openSLAAddAlterCounterChart("createNew", $scope.counter, $scope.chartName);
    	};
    	
    $scope.closemodal = function() {
    		//$rootScope.$emit('close_sla_counter_parent_popup');
    		$uibModalInstance.close();
    	};
 }]);

appedoApp.controller('slaAddAlterCounterChart', ['$scope', '$uibModal',  '$uibModalInstance', 'operation', 'slaPolicyDetails', 'chartName', 'slacardService', 'appedoChartsServices', 'ajaxCallService', '$rootScope', 'messageService',
    	function($scope, $uibModal, $uibModalInstance, operation, slaPolicyDetails, chartName, slacardService, appedoChartsServices, ajaxCallService, $rootScope, messageService) {
   	$scope.close = function () {
   		$uibModalInstance.dismiss('cancel');
   		
   	// open SLA's mapped counters
		appedoChartsServices.openSLAMappedCounters($scope.counter);
   	};
   	$scope.counter = slaPolicyDetails;
   	$scope.operation = operation;
   	$scope.ASDmoduleCountents = [];
   	$scope.slaPolicyMapCounterForm = {};
   	$scope.alertDetails = [];
   	$scope.counter.origChartTitle = chartName;
   	$scope.counter.refId = $scope.counter.uid;
   	
   	if ($scope.operation !== 'createNew') {
   		$scope.slaPolicyMapCounterForm.uid = $scope.counter.uid;
   		$scope.slaPolicyMapCounterForm.counterId = $scope.counter.counterId;
   	   	$scope.slaPolicyMapCounterForm.thresholdabv = $scope.counter.isAboveThreshold==true?'gt':'lt';
   	 	$scope.slaPolicyMapCounterForm.minBreachCount = $scope.counter.minBreachCount;
   	 	$scope.slaPolicyMapCounterForm.warning_threshold_value = $scope.counter.warningValue;
   	 	$scope.slaPolicyMapCounterForm.critical_threshold_value = $scope.counter.criticalValue;
   	 	$scope.slaPolicyMapCounterForm.mapCounterId = $scope.counter.slaCounterId;
   	 	$scope.slaPolicyMapCounterForm.slaId = $scope.counter.slaId;
   	 	$scope.slaPolicyMapCounterForm.slaName = $scope.counter.slaName;
   	 	$scope.slaPolicyMapCounterForm.guid = $scope.counter.guid;
   	 	$scope.slaPolicyMapCounterForm.unit = $scope.counter.unit;
   	 	
   	 	
   	}
   	$scope.slaPolicyMapCounterForm.unit = $scope.counter.unit;
   	if ($scope.operation === 'mapToExisting') {
 		getASDModuleContent();
 	}
   	if ($scope.operation !== 'editAlert') {
   		getBreachType();
   		
   		var rules;
		rules = slacardService.getRulesForMapping();
		rules.then(function(data) {
			$scope.rules = data.message;
			for(var i=0; i<$scope.rules.length; i++){
				if($scope.rules[i].ruleId==slaPolicyMapCounterForm.ruleId){
					$scope.slaPolicyMapCounterForm.mappedRule = $scope.rules[i];
				}
			}
			if ($scope.slaPolicyMapCounterForm.mappedRule == undefined) {
				$scope.slaPolicyMapCounterForm.mappedRule = {};
			}
		});
   	}
   	
   	$scope.onlyDigitsWarning = function() {
 		var warningThresholdValue = $scope.slaPolicyMapCounterForm.warning_threshold_value;
 		
 		if(warningThresholdValue != undefined && !(angular.isNumber(warningThresholdValue))){
 			$scope.slaPolicyMapCounterForm.warning_threshold_value = warningThresholdValue.replace(/[^0-9]/g, '');	
 		}
	};
	
	$scope.onlyDigitsCritical = function() {
		var criticalThresholdValue = $scope.slaPolicyMapCounterForm.critical_threshold_value;
		
			if(criticalThresholdValue != undefined && !(angular.isNumber(criticalThresholdValue))){
				$scope.slaPolicyMapCounterForm.critical_threshold_value = criticalThresholdValue.replace(/[^0-9]/g, '');	
			}
		};
	
	$scope.onlyDigitsBreach = function() {
		var minBreachCount = $scope.slaPolicyMapCounterForm.minBreachCount;
		
		if(minBreachCount != undefined && !(angular.isNumber(minBreachCount))){
			$scope.slaPolicyMapCounterForm.minBreachCount = minBreachCount.replace(/[^0-9]/g, '');	
		}
	};
	
	$scope.updateCounter = function() {
 		$scope.submitted = true;
 		if( this.policyMapCounterForm.$valid ){
 			var updateCounter;
 			updateCounter = slacardService.updateMapCounter($scope, $scope.slaPolicyMapCounterForm);
 			updateCounter.then(function(data) {
 				if(data.success){
 					messageService.showSuccessMessage(data.message);
 					$uibModalInstance.close();
 					
 			  		// open SLA's mapped counters
 					appedoChartsServices.openSLAMappedCounters($scope.counter);
 				}else{
 					messageService.showErrorMessage(data.errorMessage);
 				}
 			});
 		}
 	};
 	//saveAndAddAlert
 	$scope.saveAndAddAlert = function() {
 		$scope.submitted = true;
 		if( this.policyMapCounterForm.$valid ){
 			var resultData;
 			resultData = slacardService.addAlertAndCounter($scope.slaPolicyMapCounterForm, $scope.counter);
 			resultData.then(function(data) {
 				if(data.success){
 					messageService.showSuccessMessage(data.message);
 					$uibModalInstance.close();
 			  		// open SLA's mapped counters
 					appedoChartsServices.openSLAMappedCounters($scope.counter);
 				}else{
 					messageService.showErrorMessage(data.errorMessage);
 				}
 			});
 		}
 	};
 	//checkAlertNameExist
 	$scope.checkAlertNameExist = function() {
		var isvalid = true;
		if($scope.slaPolicyMapCounterForm.policyName != undefined && $scope.slaPolicyMapCounterForm.policyName != ''){
			slacardService.isValidPolicyName($scope, $scope.slaPolicyMapCounterForm.policyName, $scope.slaPolicyMapCounterForm.slaId, function(data) {
				if(data.success){
					$scope.showProceed = data.isAvailable;
					if( data.isAvailable ){
						// err, Policy already exists
						$scope.slaPolicyMapCounterForm.policyName = '';
						messageService.showErrorMessage('This Alert name already exists.');
					}
				} else {
					$scope.showProceed = true;
				}
			});
		}
	};
 	//mapToAlert
 	
	$scope.mapToAlert = function() {
 		$scope.submitted = true;
 		if( this.policyMapCounterForm.$valid ){
 			var resultData;
 			resultData = slacardService.mapToAlert($scope.slaPolicyMapCounterForm, $scope.counter);
 			resultData.then(function(data) {
 				if(data.success){
 					messageService.showSuccessMessage(data.message);
 					$uibModalInstance.close();
 					
 			  		// open SLA's mapped counters
 					appedoChartsServices.openSLAMappedCounters($scope.counter);
 				}else{
 					messageService.showErrorMessage(data.errorMessage);
 				}
 			});
 		}
 	};
 	
 	$scope.getAllSLAAlert = function() {
		var resultAllAlerts;
		resultAllAlerts = slacardService.getAllSLAAlert($scope.slaPolicyMapCounterForm.moduleType.module_code, $scope.counter.uid, $scope.counter.counterId);
		resultAllAlerts.then(function(data) {
			if(data.success){
				$scope.alertDetails = [];
				$scope.alertDetails = data.message;
			} else {
				messageService.showErrorMessage(data.errorMessage);
			}
		});
 	};
 	
 	function getBreachType(callbackFn) {
		var breachTypes;
	 	breachTypes = slacardService.getBreachTypes();
	 	breachTypes.then(function(data) {
	 		$scope.breachTypes = data;
	 		if ( callbackFn instanceof Function ) {
	 			// while edit to set the respective breachType
	 			callbackFn();
	 		} else {
	 			// while add
		 		// for auto select of breachType, if has only one `breachTypes`
		 		if ( $scope.breachTypes.length === 1 ) {
		 			$scope.slaPolicyMapCounterForm.breachType = $scope.breachTypes[0];
		 		}	
	 		}
	 	});
	}
 	
 // gets ASD module content/description
	function getASDModuleContent(callbackFn) {
		ajaxCallService.getJsonData('common/data/module_content_apm.json', function(responseData){
			$scope.ASDmoduleCountents = responseData;
			// 
			if ( callbackFn instanceof Function) {
				callbackFn();
			}
		});
	}
 	
	
   
   }]);

appedoApp.controller('slaPolicyMapCounter', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'slaPolicyDetails', 'slaActionForm', 'slaId', 'slacardService', '$rootScope', 'successMsgService', 'ajaxCallService', 'messageService',
 	function($scope, $uibModal, $uibModalInstance, isFrom, slaPolicyDetails, slaActionForm, slaId, slacardService, $rootScope, successMsgService, ajaxCallService, messageService) {
		/*
	 	$scope.cardLayout = function() {
	   	      $uibModalInstance.dismiss('cancel');
	 	};*/
		$scope.slaPolicyMapCounterForm = {};
		$scope.slaPolicyMapCounterForm.slaId = slaId;
		$scope.slaPolicyDetails = slaPolicyDetails;
		$scope.ASDmoduleCountents = [];
		$scope.submitted = false;
		$scope.showmodules = false;
		$scope.showcounters = false;
		$scope.isEditEnabled = false;
		$scope.counterLoading = false;
		$scope.modulesLoading = false;
		$scope.maxCounterIdInfo = false;
		$scope.disableSave = true;

		$scope.close = function () {
			$uibModalInstance.dismiss('cancel');
	  		// open SLA's mapped counters
	  		slacardService.openSLAViewMappedCounters(isFrom, $scope.slaPolicyDetails, slaId);
		};
		
		if(isFrom == 'fromEdit'){
	 		$scope.showmodules = true;
		 	$scope.showcounters = true;
		 	$scope.isEditEnabled = true;
	 		$scope.counter = slaActionForm;
	 		//$scope.slaPolicyMapCounterForm.moduleType = {module_code: $scope.counter.moduleName };
	 		getASDModuleContent(function() {
	 			// select
	 			for (var i = 0; i < $scope.ASDmoduleCountents.length; i = i + 1) {
	 				var joModule = $scope.ASDmoduleCountents[i];
	 				if ( joModule.module_code === $scope.counter.moduleName ) {
	 					$scope.slaPolicyMapCounterForm.moduleType = joModule;
	 				}
	 			}
	 		});
	 		$scope.slaPolicyMapCounterForm.agentName = $scope.counter.moduleValue;
	 		$scope.slaPolicyMapCounterForm.counterName = {counterName: $scope.counter.category +' - '+$scope.counter.countername, unit: $scope.counter.unit};
	 		
	 		// gets & sets breach type
	 		$scope.slaPolicyMapCounterForm.breachType = $scope.counter.breachType;
	 		/*getBreachType(function() {
	 			// select
	 			for (var i = 0; i < $scope.breachTypes.length; i = i + 1) {
	 				var joBreach = $scope.breachTypes[i];
	 				console.info('joBreach : '+JSON.stringify(joBreach));
	 				if ( joBreach.breachType === $scope.counter.breachType ) {
	 					$scope.slaPolicyMapCounterForm.breachType = joBreach;
	 					console.info('SElection edit: '+JSON.stringify($scope.slaPolicyMapCounterForm.breachType));
	 				}
	 			}
	 		});*/
	 		
	 		$scope.slaPolicyMapCounterForm.thresholdabv = $scope.counter.isThresholdAbove==true?'gt':'lt';
		 	$scope.slaPolicyMapCounterForm.minBreachCount = $scope.counter.minBreachCount;
		 	$scope.slaPolicyMapCounterForm.warning_threshold_value = $scope.counter.warning_threshold_value;
		 	$scope.slaPolicyMapCounterForm.critical_threshold_value = $scope.counter.critical_threshold_value;
		 	$scope.slaPolicyMapCounterForm.mapCounterId = $scope.counter.mapCounterId;
		 	$scope.slaPolicyMapCounterForm.guid = $scope.counter.guid;
	 	}else{
	 		// gets ASD module countents, say APPLICATION, SERVER, DATABASE
	 		getASDModuleContent();
	 		
	 		// gets default breach types
	 		getBreachType();
	 		
	 		$scope.slaPolicyMapCounterForm.percentageVsTotal = 'VALUES';
	 		$scope.slaPolicyMapCounterForm.thresholdabv = 'gt';
		 	$scope.slaPolicyMapCounterForm.minBreachCount = 1;
	 	}
	 	
	 	$scope.onlyDigitsWarning = function() {
	 		var warningThresholdValue = $scope.slaPolicyMapCounterForm.warning_threshold_value;
	 		
	 		if(warningThresholdValue != undefined && !(angular.isNumber(warningThresholdValue))){
	 			$scope.slaPolicyMapCounterForm.warning_threshold_value = warningThresholdValue.replace(/[^0-9]/g, '');	
	 		}
		};
		
		$scope.onlyDigitsCritical = function() {
			var criticalThresholdValue = $scope.slaPolicyMapCounterForm.critical_threshold_value;
			
				if(criticalThresholdValue != undefined && !(angular.isNumber(criticalThresholdValue))){
					$scope.slaPolicyMapCounterForm.critical_threshold_value = criticalThresholdValue.replace(/[^0-9]/g, '');	
				}
			};
		
		$scope.onlyDigitsBreach = function() {
			var minBreachCount = $scope.slaPolicyMapCounterForm.minBreachCount;
			
			if(minBreachCount != undefined && !(angular.isNumber(minBreachCount))){
				$scope.slaPolicyMapCounterForm.minBreachCount = minBreachCount.replace(/[^0-9]/g, '');	
			}
		};
			
		// gets ASD module content/description
		function getASDModuleContent(callbackFn) {
			ajaxCallService.getJsonData('common/data/module_content_apm.json', function(responseData){
				$scope.ASDmoduleCountents = responseData;
				
				// 
				if ( callbackFn instanceof Function) {
					callbackFn();
				}
			});
		}

		// gets default breach types
		function getBreachType(callbackFn) {
			var breachTypes;
		 	breachTypes = slacardService.getBreachTypes();
		 	breachTypes.then(function(data) {
		 		$scope.breachTypes = data;
		 		
		 		if ( callbackFn instanceof Function ) {
		 			// while edit to set the respective breachType
		 			callbackFn();
		 		} else {
		 			// while add
			 		// for auto select of breachType, if has only one `breachTypes`
			 		if ( $scope.breachTypes.length === 1 ) {
			 			$scope.slaPolicyMapCounterForm.breachType = $scope.breachTypes[0];
			 		}	
		 		}
		 	});
		}
		
	 	$scope.getModules = function(){
	 		var moduleTypes;

	 		// clears, previous selections
	 		$scope.slaPolicyMapCounterForm.agentName = undefined;
	 		$scope.slaPolicyMapCounterForm.counterName = undefined;
	 		$scope.slaPolicyMapCounterForm.warning_threshold_value = '';
	 		$scope.slaPolicyMapCounterForm.critical_threshold_value = '';
	 		$scope.slaPolicyMapCounterForm.percentageVsTotal = '';
	 		$scope.modulesLoading = true;

	 		moduleTypes = slacardService.getModuleTypeValues($scope.slaPolicyMapCounterForm.moduleType.module_code);
	 		moduleTypes.then(function(data) {
	 			$scope.modulesLoading = false;
	 			$scope.showmodules = true;
	 			$scope.showcounters = false;
	 			$scope.modules = data;

	 			if($scope.modules.length <= 0){
	 				$scope.response ={};
	 	    		$scope.response.success = false;
	 	    		$scope.response.errorMessage = "Add an agent in &lt Application or Database or Server &gt; - OPS VIEW and Map the metrics.";
	 	    		successMsgService.showSuccessOrErrorMsg($scope.response);
	 			}else{
	 				$scope.nocounters = false;
	 			}
	 		});
	 	};
 	
	 	$scope.getCounters = function() {
	 		var counterValue;
	 	// clears, previous selections
	 		$scope.slaPolicyMapCounterForm.counterName = undefined;
	 		$scope.slaPolicyMapCounterForm.warning_threshold_value = '';
	 		$scope.slaPolicyMapCounterForm.critical_threshold_value = '';
	 		$scope.slaPolicyMapCounterForm.percentageVsTotal = '';
	 		$scope.counterLoading = true;
	 		
	 		counterValue = slacardService.getCounters($scope.slaPolicyMapCounterForm.agentName.uid);
	 		counterValue.then(function(data) {
	 			if ( ! data.success ) {
	 				// err
	 				messageService.showErrorMessage(data.errorMessage);
	 			} else {
	 				// success
	 				$scope.counterLoading = false;
		 			$scope.showcounters = true;
		 			$scope.counters = data.message;
	 			}
	 		});
	 	};
	
	 	$scope.getCounterValues = function() {
	 		$scope.maxCounterIdInfo = false;
	 		$scope.slaPolicyMapCounterForm.thresholdabv = $scope.slaPolicyMapCounterForm.counterName.isThreshold ? 'gt' : 'lt';
	 		$scope.disableSave = false;
	 		$scope.counterUnit = $scope.slaPolicyMapCounterForm.counterName.unit;

	 		// Selecting check-box to values 
	 		if ($scope.slaPolicyMapCounterForm.counterName.max_value_counter_id > 0) {
				$scope.slaPolicyMapCounterForm.percentageVsTotal = 'PERCENTAGE';

				// To check whether the max_value_counter_id is selected/configured
				slacardService.getMaxValueCounterIdDetail($scope, $scope.slaPolicyMapCounterForm.counterName.max_value_counter_id, $scope.slaPolicyMapCounterForm.agentName.uid, function(data) {
					if(data.success){
						$scope.isMaxCounterConfigured = data.message.isSelected;
						$scope.displayName = data.message.displayName;

						if( !$scope.isMaxCounterConfigured ){
							$scope.maxCounterIdInfo = true;
							$scope.disableSave = true;
							messageService.showWarningMessage('You Need to configure the <STRONG>'+$scope.displayName+'</STRONG> Metric for the option Percentage against Total');
						}else{
							$scope.disableSave = false;
						}
					} else {
						messageService.showErrorMessage(data.errorMessage);
					}
				});

				$scope.loadSelectedMode();

	 		}else{
	 			$scope.slaPolicyMapCounterForm.percentageVsTotal = 'VALUES';
	 			$scope.slaPolicyMapCounterForm.warning_threshold_value = $scope.slaPolicyMapCounterForm.counterName.warning_threshold_value;
		 		$scope.slaPolicyMapCounterForm.critical_threshold_value = $scope.slaPolicyMapCounterForm.counterName.critical_threshold_value;
	 		}
	 	};

		$scope.loadSelectedMode = function() {

	 		// Toggle the values of  warning and critical threshold_value on change of radio button
	 		if ($scope.slaPolicyMapCounterForm.percentageVsTotal == 'PERCENTAGE') {
	 			// Assign unit value as '%' when percentage radio button is selected
	 			$scope.slaPolicyMapCounterForm.counterName.unit = '%';

	 			// For percentage by default set values
	 			if ($scope.slaPolicyMapCounterForm.thresholdabv == 'gt') {
					$scope.slaPolicyMapCounterForm.warning_threshold_value = '60';
					$scope.slaPolicyMapCounterForm.critical_threshold_value = '80';
				} else if ($scope.slaPolicyMapCounterForm.thresholdabv == 'lt') {
					$scope.slaPolicyMapCounterForm.warning_threshold_value = '40';
					$scope.slaPolicyMapCounterForm.critical_threshold_value = '20';
				}
				if( !$scope.isMaxCounterConfigured ){
					$scope.disableSave = true;
				}
	 		}else if($scope.slaPolicyMapCounterForm.percentageVsTotal == 'VALUES'){
	 			$scope.slaPolicyMapCounterForm.counterName.unit = $scope.counterUnit;
	 			$scope.disableSave = false;
	 			$scope.slaPolicyMapCounterForm.warning_threshold_value = $scope.slaPolicyMapCounterForm.breachTypecounterName.warning_threshold_value;
	 			$scope.slaPolicyMapCounterForm.critical_threshold_value = $scope.slaPolicyMapCounterForm.counterName.critical_threshold_value;
	 		}
		};
 	
		$scope.saveAndFinish = function() {
	 		$scope.submitted = true;
	 		if( this.policyMapCounterForm.$valid ){
	 			var saveRule;
	 			saveRule = slacardService.addMapCounter($scope, $scope.slaPolicyMapCounterForm);
	 			saveRule.then(function(data) {
	 				if(data.success){
	 					$rootScope.$emit('close_sla_counter_parent_popup');
						$rootScope.$emit('reloadSLACardLayout');
	 					$uibModalInstance.close();
	 					successMsgService.showSuccessOrErrorMsg(data);
	 			  		// open SLA's mapped counters
	 			  		slacardService.openSLAViewMappedCounters('fromAdd', $scope.slaPolicyDetails, slaId);
	 				}else{
	 					successMsgService.showSuccessOrErrorMsg(data);
	 				}
	 			});
	 		}else{
	 			messageService.showWarningMessage(msgContent);
	 		}
	 	};

 	$scope.saveAndAddCounter = function() {
 		$scope.submitted = true;
 		if( this.policyMapCounterForm.$valid ){
 			var saveRule;
 			saveRule = slacardService.addMapCounter($scope, $scope.slaPolicyMapCounterForm);
 			saveRule.then(function(data) {
 				if(data.success){
 					$scope.counters = [];
 					$scope.modules = [];
 					$scope.slaPolicyMapCounterForm.counterName = '';
 					$scope.slaPolicyMapCounterForm.agentName = '';
 					$scope.slaPolicyMapCounterForm.warning_threshold_value = '';
 					$scope.slaPolicyMapCounterForm.critical_threshold_value = '';
 					//$scope.slaPolicyMapCounterForm.moduleType = '';
 					$scope.slaPolicyMapCounterForm.moduleType = {};
 					$scope.slaPolicyMapCounterForm.breachType = '';
 					$scope.slaPolicyMapCounterForm.minBreachCount = 1;
 					$scope.submitted = false;
 					$scope.showmodules = false;
 					$scope.showcounters = false;
 					$scope.disableSave = true;
 					successMsgService.showSuccessOrErrorMsg(data);
 				}else{
 					successMsgService.showSuccessOrErrorMsg(data);
 				}
 			});
 		}else{
 			messageService.showWarningMessage(msgContent);
 		}
 	};
 	
 	$scope.updateCounter = function() {
 		$scope.submitted = true;
 		if( this.policyMapCounterForm.$valid ){
 			var updateCounter;
 			updateCounter = slacardService.updateMapCounter($scope, $scope.slaPolicyMapCounterForm);
 			updateCounter.then(function(data) {
 				if(data.success){
 					successMsgService.showSuccessOrErrorMsg(data);
 					$rootScope.$emit('close_sla_counter_parent_popup');
					$rootScope.$emit('reloadSLACardLayout');
 					$uibModalInstance.close();
 					
 			  		// open SLA's mapped counters
 			  		slacardService.openSLAViewMappedCounters('fromAdd', $scope.slaPolicyDetails, slaId);
 				}
 			});
 		}
 	};
 	  
}]);

appedoApp.controller('slaSettingController', ['$scope', '$uibModal',  '$uibModalInstance', 'isFrom', 'moduleCardContent', 'slacardService', 'ngToast', 'successMsgService', '$rootScope', 'sessionServices', 'messageService',
	function($scope, $uibModal, $uibModalInstance, isFrom, moduleCardContent, slacardService, ngToast, successMsgService, $rootScope, sessionServices, messageService) {

	$scope.cardLayout = function() {
		$uibModalInstance.dismiss('cancel');
	};
	$scope.close = function() {
		$uibModalInstance.dismiss('cancel');
	};
	
	$scope.moduleCardContent=moduleCardContent;
	$scope.slaSettingForm = {};
	var loginUser = JSON.parse(sessionServices.get('loginUser'));
	var emailIds = ["sales_test@appedo.com","sales_test@softsmith.com"];
	$scope.showHealOption = false;
	var settings;
	settings = slacardService.getSLASettings();
	settings.then(function(data) {
		if(data){
			$scope.slaSettingForm.maxTryDuration = data.trycountduration;
			$scope.slaSettingForm.maxTry = data.maxtrycount;
			$scope.slaSettingForm.alertTriggerFrequency = data.triggeralert; 
			if(emailIds.indexOf(loginUser.emailId)>=0){
				$scope.showHealOption = true;
			}else{
				$scope.showHealOption = false;
			}
		} else {
			$scope.showHealOption = false;
		}
	});
	$scope.setSlaSetting = function() {
		var isvalidated = true;
		var msgContent = "";
		if($scope.slaSettingForm.maxTryDuration==undefined || $scope.slaSettingForm.maxTryDuration == '' || $scope.slaSettingForm.maxTryDuration.length<0){
			isvalidated = false;
			msgContent = "Max Try Duration";
		}
		
		if($scope.slaSettingForm.maxTry==undefined || $scope.slaSettingForm.maxTry == '' || $scope.slaSettingForm.maxTry.length<0){
			isvalidated = false;
			msgContent = msgContent+"<br>Max Try";
		}
		
		if($scope.slaSettingForm.alertTriggerFrequency==undefined || $scope.slaSettingForm.alertTriggerFrequency == '' || $scope.slaSettingForm.alertTriggerFrequency.length<0){
			isvalidated = false;
			msgContent = msgContent+"<br>Alert Trigger Frequency ";
		}
		
		if(isvalidated){
			$rootScope.$on("close_sla_setting_parent_popup", function(event){
				$uibModalInstance.dismiss('cancel');
			});
			
			var settings;
			settings = slacardService.setSlaSetting($scope, $scope.slaSettingForm);
			settings.then(function(data) {
				if( ! data.success ){
					messageService.showErrorMessage(data.errorMessage);
				} else {
					$scope.close();
					
					// open SLA settings to alert email/SMS addresses
					slacardService.openSettingsToAlertAddresses();
					//slacardService.openSettingsToAlertAddresses('SLA', undefined, undefined);
				}
			});
		} else {
			$scope.response ={};
			$scope.response.success = false;
			$scope.response.errorMessage = msgContent+"is mandatory.";
			successMsgService.showSuccessOrErrorMsg($scope.response);
		}
	};
}]);

appedoApp.controller('slaSettingViewAlert', ['$scope', '$rootScope', '$uibModal',  '$uibModalInstance', 'slacardService', 'messageService',//'moduleCode', 'moduleCardContent', 'moduleParams', 
	function($scope, $rootScope, $uibModal, $uibModalInstance, slacardService, messageService) {//moduleCode, moduleCardContent, moduleParams, 
	
	/*
	 * Note: view alert addresses used same grid template for SLA & AVM location's alert addresses;
	 *   used same variable & fn. name of `$scope.alertAddresses`, `$scope.addAlertAddress`
	 */
	
	//$scope.moduleCardContent = moduleCardContent;
	$scope.alertAddresses = [];

	$scope.loadingAlertAddresses = false;
	
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	
	//console.log(status);
	$scope.addAlertAddress = function() {
		$rootScope.$on("close_sla_setting_parent_popup", function(event){
			$uibModalInstance.dismiss('cancel');
		});
		
		// closes current 
		$scope.close();
		
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/sla/sla_setting_alert.html',
			controller: 'slaSettingAlert',
			size: 'lg'
		});
	};
	
	$scope.closeAlertTypeListPage = function() {
		$rootScope.$emit('close_sla_setting_parent_popup');
		$uibModalInstance.dismiss('cancel');
	};
	
	// gets to alert addresses 
	function getAlertAddresses() {
		showLoadingAlertAddresses();
		
		var alertGrid;
		alertGrid = slacardService.getAlerts();
		alertGrid.then(function(data) {
			hideLoadingAlertAddresses();

			if( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
    		} else {
    			$scope.alertAddresses = data.message;
    		}
		});
	}
	getAlertAddresses();
	
	$scope.deleteAlertAddress = function(joAlertAddress){
		var result = confirm("You will lose records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			var deleteAlert;
			deleteAlert = slacardService.deleteAlert(joAlertAddress.alertId);
			deleteAlert.then(function(data) {

				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					messageService.showSuccessMessage(data.message);
					
					// gets to alert addresses
					getAlertAddresses();
				}
			}); 
		}
	};
	
	function showLoadingAlertAddresses() { $scope.loadingAlertAddresses = true; }
	function hideLoadingAlertAddresses() { $scope.loadingAlertAddresses = false; }
}]);

appedoApp.controller('slaSettingAlert', ['$scope', '$uibModal',  '$uibModalInstance', 'slacardService', '$rootScope', 'successMsgService', 'messageService', 'userServices', 
	function($scope, $uibModal, $uibModalInstance, slacardService, $rootScope, successMsgService, messageService, userServices) {
	/*
	 * Note: add alert address form used same template for SLA and AVM location add alert address;
	 *  used same varaiable & fn. name of `$scope.addAlertAddressForm`, `$scope.disableAddButton`, `$scope.saveAlertAddress`, `$scope.openSettingsToAlertAddresses`, `$scope.alertTypes`
	 *    in controllers `slaSettingAlert`, `avmLocationAddAlertAddressController`
	 */
	
	$scope.alertTypes = [{ displayName: 'Email', value: 'Email' }, { displayName: 'SMS', value: 'SMS' }];
	
	$scope.addAlertAddressForm = {};
	// default `Email` type
	$scope.addAlertAddressForm.alertType = $scope.alertTypes[0];
	//$scope.addAlertAddressForm.alertType = "Email";
	
	
	$scope.showButton = true;
	$scope.disableAddButton = false;
	$scope.countriesCode = [];
	
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	
	// To get phone numbers.
	userServices.getCountryCodeDetails(function(data) {
		if ( ! data.success ) {
			// Error
		} else {
			$scope.countriesCode = data.message;
			$scope.addAlertAddressForm.countryCode = $scope.countriesCode[1];
		}
	});
	
	$scope.validtaeForm = function() {
		if($scope.addAlertAddressForm.alertType === "Email" && $scope.addAlertAddressForm.emailOrMobileAddress != undefined && $scope.addAlertAddressForm.emailOrMobileAddress.length>=0){
			var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
			if( re.test($scope.addAlertAddressForm.emailOrMobileAddress)){
				$scope.showButton = false;
			} else {
				$scope.showButton = true;
			}
		} else if($scope.addAlertAddressForm.alertType === "SMS" && $scope.addAlertAddressForm.emailOrMobileAddress != undefined && $scope.addAlertAddressForm.emailOrMobileAddress.length>=0){
			$scope.addAlertAddressForm.emailOrMobileAddress = $scope.addAlertAddressForm.emailOrMobileAddress.replace(/[^0-9]/g, '');
			if($scope.addAlertAddressForm.alertType=="SMS" && $scope.addAlertAddressForm.emailOrMobileAddress != undefined && $scope.addAlertAddressForm.emailOrMobileAddress != "" && $scope.addAlertAddressForm.emailOrMobileAddress.length>=0){
				$scope.showButton = false;
			} else {
				$scope.showButton = true;
			}
		} else {
			$scope.showButton = true;
		}
	};
	
	// opens SLA added alert address email & mobile numbers 
	$scope.openSettingsToAlertAddresses = function() {
		$scope.close();
		
		// open SLA settings to alert email/SMS addresses
		slacardService.openSettingsToAlertAddresses();
	};
	
	// save SLA alert address
	$scope.saveAlertAddress = function(bOpenAlertAddresses) {
		disableAddAlertButton();
		
		// must save the record
		var alerts;
		alerts = slacardService.saveAlerts($scope.addAlertAddressForm);
		alerts.then(function(data) {
			enableAddAlertButton();
			
			if( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
    		} else {
    			if ( ! data.emailSent ) {
    				// address might already verfied or for SMS default verified 
    				messageService.showSuccessMessage(data.message);	
    			} else {
    				// for added email, verification email is sent for verification 
    				messageService.showWarningMessage(data.message+'<BR>Check the inbox/spam/junk for the verification mail.<BR>Click on the link given in the email.', {dismissOnTimeout: false, dismissOnClick: false, additionalClasses: 'apd-alert-msg'});	
    			}
				
				if ( bOpenAlertAddresses ) {	// opens added alert addresses window
					$rootScope.$on("close_sla_setting_parent_popup", function(event){
		    			$uibModalInstance.dismiss('cancel');
		    		});
					// closes 
					$scope.close();
					
					// open SLA settings to alert email/SMS addresses
					slacardService.openSettingsToAlertAddresses();
				} else {	// remains same screen, add alert addresses
					
					$scope.addAlertAddressForm.emailOrMobileAddress = '';
					$scope.validtaeForm();
				}
    		}
    	});
	};/*
	$scope.SaveAndAdd = function() {
		disableAddAlertButton();
		
		// must save the record and be on the same screen
		var alerts;
		alerts = slacardService.saveAlerts($scope.addAlertAddressForm);
		alerts.then(function(data) {
			enableAddAlertButton();
			
			if( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
			} else {
				/*var altype=$scope.addAlertAddressForm.alertType;
				$scope.addAlertAddressForm = {};
				$scope.addAlertAddressForm.alertType = altype;
				$scope.showButton = true;* /
				
				messageService.showSuccessMessage(data.message);
				
				$scope.addAlertAddressForm.emailOrMobileAddress = '';
				$scope.validtaeForm();
			}
		});
	};*/
	
	function enableAddAlertButton() { $scope.disableAddButton = false; }
	function disableAddAlertButton() { $scope.disableAddButton = true; }
}]);
appedoApp.controller('ltDashPanel', ['$scope', '$rootScope', '$location', 'ltFactory', 'ltService', 'sessionServices', '$appedoUtils', 'messageService', function($scope, $rootScope, $location, ltFactory, ltService, sessionServices, $appedoUtils, messageService) {
	var d3ChartTimeFormat = JSON.parse(sessionServices.get("d3ChartTimeFormatForLT"));
	$scope.lastRunReports = [];
	
	var locPath = $location.path().split("/")[1];
	var bDashboardPage = false;
	if ( locPath === 'dashboard' ) {
		bDashboardPage = true;
	}
	
	//$scope.showLoading = false;
	
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('LT Dashboard Page', 'pageOpen', {
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	
	function getLTLicense() {
		var resultLTLicense = ltService.getLTLicense();
		resultLTLicense.then(function(resp) {
			$scope.summarydata = resp;
		});	
	}
	getLTLicense();
	
	function getLicDonutData() {
		resultDonutChartData=null;
		resultDonutChartData = ltService.getDonutChartdata('Run',null);
		resultDonutChartData.then(function(resp) {
			if(resp.success){
				$scope.licDonutData=resp.message;
			}else{
				$scope.licDonutData=[];
			}
		});

	}
	getLicDonutData();
	
	// gets user's all Loadtest type reports
	$scope.getScenarioReports = function(loadTestType, callbackFn) {
		$scope.showLoading = true;
		$scope.lastRunReports = [];
		$scope.selectedLastRunreport = {};
		
		// gets user's all Loadtest type reports
		ltService.getScenarioReports(null, loadTestType, function(resp) {
			$scope.showLoading = false;
			//$scope.$parent.showLoading = false;
			
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.errorDonutData=[];
				$scope.svfDonutData=[];
				//$scope.licDonutData=[];
				
				$scope.lastRunReports = resp.message;
				
				if( $scope.lastRunReports.length > 0 ) {
					$scope.selectedLastRunreport = $scope.lastRunReports[0];
					$scope.uidForDonut = $scope.selectedLastRunreport.uid;
					
					$scope.getLTChartData();
				}
			}
			
			// callback fn called in parent
			if ( callbackFn instanceof Function ) {
				// since `showLoading = FALSE` not updated in its parent; added callbackFn, called $scope.$emit('loadedDashboardReports') to update `showLoading` 
				callbackFn();
			}
		});
	};
	
	/*
	 * In url `/dashboard`, default gets `APPEDO_LT` reports
	 * Note: since in `/dashboard` not used the controller, added to gets only `APPEDO_LT`, 
	 *   TODO: when using the controller in url `/dashboard` page, handle for both `APPEDO_LT` and `JMETER` reports to get
	 */
	if ( bDashboardPage ) {
		$scope.getScenarioReports('APPEDO_LT');
	}
	
	// added for in `/load_test` -> `Dashboard` page to load selected type reports
	$scope.$on("loadSelectedTypeReports", function(event, loadTestType, callbackFn) {
		$scope.getScenarioReports(loadTestType, callbackFn);
	});
	
	$scope.getLTChartData = function(){
		$scope.getLTAreaChart();
		$scope.getLTSummary();
	};
	
	$scope.getLTAreaChart= function(){
		$scope.pageResponseLoading = true;
		$scope.userCountLoading = true;
		$scope.errorCountLoading = true;
		
		if($scope.selectedLastRunreport.testType=="JMETER"){
			$scope.loadTestType = "JMETER";
			$scope.d3XaixsFormat = d3ChartTimeFormat[2];
			var resultDashResponseArea = ltService.getDashResponseArea($scope.selectedLastRunreport.reportId);
			resultDashResponseArea.then(function(resp) {
				$scope.pageResponseTimeChartData = $appedoUtils.changeFormatToArrayInJSON(resp);
				$scope.pageResponseLoading = false;
			});
			var resultDashVUsersArea = ltService.getDashVUsersArea($scope.selectedLastRunreport.reportId,$scope.selectedLastRunreport.scenarioName);
			resultDashVUsersArea.then(function(resp) {
				$scope.vUsersChartData = $appedoUtils.changeFormatToArrayInJSON(resp);
				$scope.userCountLoading = false;
			});
		}else if($scope.selectedLastRunreport.testType=="APPEDO_LT"){
			$scope.loadTestType = "APPEDO_LT";
			$scope.d3XaixsFormat = d3ChartTimeFormat[0];
			ltService.getNewChartReport($scope.selectedLastRunreport.reportId, $scope.selectedLastRunreport.testType,$scope.selectedLastRunreport.runStartTime,'Hours',0,$scope.selectedLastRunreport.status,$scope.selectedLastRunreport.runTime,'userCountChartData', function(data) {
				if ( data.success ) {
					$scope.vUsersChartData = data.message.userCountChartData;
					$scope.userCountLoading = false;
				} else {
					$scope.vUsersChartData = [];
					$scope.userCountLoading = false;
				}
			});
			ltService.getNewChartReport($scope.selectedLastRunreport.reportId, $scope.selectedLastRunreport.testType,$scope.selectedLastRunreport.runStartTime,'Hours',0,$scope.selectedLastRunreport.status,$scope.selectedLastRunreport.runTime,'pageResponseChartData', function(data) {
				if ( data.success ) {
					$scope.pageResponseTimeChartData = data.message.pageResponseChartData;
					$scope.pageResponseLoading = false;
				} else {
					$scope.pageResponseTimeChartData = [];
					$scope.pageResponseLoading = false;
				}
			});
			ltService.getNewChartReport($scope.selectedLastRunreport.reportId, $scope.selectedLastRunreport.testType,$scope.selectedLastRunreport.runStartTime,'Hours',0,$scope.selectedLastRunreport.status,$scope.selectedLastRunreport.runTime,'errorCountChartData', function(data) {
				if ( data.success ) {
					$scope.errorCountChartData = data.message.errorCountChartData;
					$scope.errorCountLoading = false;
				} else {
					$scope.errorCountChartData = [];
					$scope.errorCountLoading = false;
				}
			});
		}
	};
	
	$scope.getLTSummary = function(){
		var resultDonutChartData;
//			resultDonutChartData = ltService.getDonutChartdata('Error',$scope.selectedLastRunreport.reportId);
//			resultDonutChartData.then(function(resp) {
//				if(resp.success){
//					$scope.errorDonutData=resp.message;
//				}else{
//					$scope.errorDonutData=[];
//				}
//			});
		
		resultDonutChartData="";
		resultDonutChartData = ltService.getDonutChartdata('Status',$scope.selectedLastRunreport.reportId);
		resultDonutChartData.then(function(resp) {
			if(resp!=undefined){
				if(resp.success){
					$scope.cTextCompletedDonutData = findAndRemove(resp.message,'label','Total');
					$scope.svfDonutData=[];
					$scope.svfDonutData=resp.message;
					var totalBarVal = 0;
					for(var i = 0; i<$scope.svfDonutData.length; i= i+1){
						totalBarVal = totalBarVal + $scope.svfDonutData[i].value;
					}
					for(var i = 0; i<$scope.svfDonutData.length; i= i+1) {
						$scope.svfDonutData[i].barVal = ($scope.svfDonutData[i].value*100)/totalBarVal;
					}
				}else{
					$scope.svfDonutData=[];
				}
			}
		});
		
/*		resultDonutChartData="";
		resultDonutChartData = ltService.getDonutChartdata('Run',$scope.selectedLastRunreport.reportId);
		resultDonutChartData.then(function(resp) {
			if(resp.success){
				$scope.licDonutData=resp.message;
			}else{
				$scope.licDonutData=[];
			}
		});*/
	};
	
	$scope.saveTransitionHiddenParams = function() {
		sessionServices.set("runId", $scope.selectedLastRunreport.reportId);
		sessionServices.set("scenarioId", $scope.selectedLastRunreport.scenarioId);
	};
	
	$scope.viewScenarioAllReports = function() {
		// go to, the scenario's all reports page
		ltFactory.viewScenarioAllReports($scope.selectedLastRunreport.testType, $scope.selectedLastRunreport.scenarioName, $scope.selectedLastRunreport.reportId, $scope.selectedLastRunreport.scenarioId);
	};
}]);



appedoApp.controller('load_test_controller', ['$scope', 'ltCardService', '$location', '$state', 'sessionServices', '$uibModal', '$timeout', 'ltFactory', 'ltService', 'successMsgService', '$rootScope', 'messageService', function ($scope, ltCardService, $location, $state, sessionServices, $uibModal, $timeout, ltFactory, ltService, successMsgService, $rootScope, messageService) {
	$scope.appedo = {};
	$scope.appedo.loadtestValue = 'APPEDO_LT';
	
	$scope.ltScenarioEmptyMsgContent = false;
	
	$scope.ltscriptscontent = [];
	$scope.ltvariablescontent = [];
	$scope.ltscenarioscontent = [];
	
	$scope.showLoading = false;
	
	$scope.loginUser = JSON.parse(sessionServices.get('loginUser'));
	
	var timer;
	
	//$scope.appedo.scripts_scenarios = 'Scenarios';
	
	// default landing page is dashboard,
	if( $rootScope.backPageFrom == "LTDetails" ) {
		// to load selected loadTest type's `Scenarios`, when back from report page
		$scope.appedo.scripts_scenarios = 'Scenarios';
		$scope.appedo.loadtestValue = $rootScope.selectedLoadTestType;
	} else {
		$scope.appedo.scripts_scenarios = 'LTDashboard';
	}
	
	$scope.testCITrigger = function() {
		Appedo_CI.triggerEvent('RUM Card Layout', 'pageOpen', 
		{
			page_open_date_time : new Date()
		});
	};
	$scope.testCITrigger();
	
	/*
	$scope.loadtestType = function() {
		if( $scope.appedo.loadtestValue=='JMETER' ){
			$scope.appedo.jmeter = true;
			$scope.appedo.appedo_lt = false;
		} else {
			$scope.appedo.jmeter = false;
			$scope.appedo.appedo_lt = true;
		}
		$scope.loadSelectedMode();
	};*/
	
	$scope.scenariosCardLayout = function(){
		clearTimeout(timer);
		$scope.showLoading = true;
		$scope.ltscenarioscontent = [];
		
		ltCardService.populateLTScenarioData($scope, $scope.appedo.loadtestValue, function(rumCardData) {
			$scope.showLoading = false;
			$scope.ltscenarioscontent = rumCardData;
			
			if ( $scope.ltscenarioscontent.length === 0 ) {
				$scope.ltScenarioEmptyMsgContent = true;
			} else {
				$scope.ltScenarioEmptyMsgContent = false;
			}
			
			for(var i=0; i<rumCardData.length; i++){
				if(!rumCardData[i].run_status  && (rumCardData[i].status=='COMPLETED' || rumCardData[i].status=='FAILED' || rumCardData[i].status=='MANUAL REPORT GENERATION COMPLETED' ||  
					rumCardData[i].status=='ANUAL REPORT GENERATION FAILED' || rumCardData[i].status=='AUTO REPORT GENERATION COMPLETED' || rumCardData[i].status=='AUTO REPORT GENERATION FAILED')){
					rumCardData[i].redclass = true;
					rumCardData[i].blueclass = false;
					rumCardData[i].greenclass = false;
					rumCardData[i].yellowclass = false;
				}else if(!rumCardData[i].run_status && (rumCardData[i].status=='AUTO REPORT PREPARATION STARTED' || rumCardData[i].status=='AUTO REPORT GENERATION STARTED' || rumCardData[i].status=='MANUAL REPORT PREPARATION STARTED' ||  
					rumCardData[i].status=='MANUAL REPORT GENERATION STARTED' || rumCardData[i].status=='REPORT GENERATION STARTED' || rumCardData[i].status=='AUTO REPORT PROCESS IN QUEUE')){
					rumCardData[i].redclass = false;
					rumCardData[i].blueclass = true;
					rumCardData[i].greenclass = false;
					rumCardData[i].yellowclass = false;
				}else if(rumCardData[i].run_status && rumCardData[i].status=='RUNNING'){
					rumCardData[i].redclass = false;
					rumCardData[i].blueclass = false;
					rumCardData[i].greenclass = true;
					rumCardData[i].yellowclass = false;
				}else if(rumCardData[i].run_status && rumCardData[i].status=='QUEUED'){
					rumCardData[i].redclass = false;
					rumCardData[i].blueclass = false;
					rumCardData[i].greenclass = false;
					rumCardData[i].yellowclass = true;
				}
			}
		});
		timer = setTimeout($scope.scenariosCardLayout, sessionServices.get("textRefresh"));
	};
	
	$scope.loadSelectedMode = function() {
		
		if( $scope.appedo.scripts_scenarios === 'Scripts' ){
			// loads scripts
			loadScripts();
		} else if ( $scope.appedo.scripts_scenarios === 'Scenarios' ) {
			// loads scenarios
			$scope.scenariosCardLayout();
			var ltCard = $rootScope.$on("lt_card_layout", $scope.scenariosCardLayout);
			$scope.$on('$destroy', ltCard);
		} else if ( $scope.appedo.scripts_scenarios === 'Variables' ) {
			// load variables
			loadVariables();
		} else if ( $scope.appedo.scripts_scenarios === 'LTDashboard' ) {
			// dashboard, load selected load test type reports data
			loadDashboardReportsData();
		}
	};
	$scope.loadSelectedMode();
	
	// load scripts
	function loadScripts() {
		$scope.showLoading = true;
		
		ltCardService.populateLTScriptData($scope, $scope.appedo.loadtestValue, function(data) {
			$scope.showLoading = false;
			$scope.ltscriptscontent = data;
		});
	}
	
	// load variables
	function loadVariables() {
		$scope.showLoading = true;
		
		ltCardService.populateDataFiles($scope, $scope.appedo.loadtestValue, function(data) {
			$scope.showLoading = false;
			$scope.ltvariablescontent = data;
		});
	}
	
	// dashboard, loads selected load test type's reports data
	function loadDashboardReportsData() {
		$scope.showLoading = true;
		
		$timeout(function() {
			$scope.$broadcast('loadSelectedTypeReports', $scope.appedo.loadtestValue, function() {
				//$scope.showLoading = false;
				//$scope.$apply();
				
				// since `showLoading` not updated in its parent added, 
				$scope.$emit('loadedDashboardReports');
			});
		}, 1000);
	}
	// after dashboard reports dropdown loaded, `showLoading` is made as false; since based `showLoading` handled radio button selection
	$scope.$on("loadedDashboardReports", function() {
		$scope.showLoading = false;
	});
	
	
	
	$scope.uploadJmeterScript = function(elem) {
		ltCardService.uploadJmeterScript($scope, elem, './lt/uploadJmeterScript', function(data){

			if(data.success){
				$scope.scenariosCardLayout();
				successMsgService.showSuccessOrErrorMsg(data);
			}else{
				successMsgService.showSuccessOrErrorMsg(data);
			}
		});
	};
	
	$scope.openUploadCSVFiles = function(index){
		$('importScript_'+index).trigger('click');
	};
	
	$scope.uploadcsvfiles = function(elem){
		
		ltCardService.uploadCSVFile($scope, elem, './lt/uploadcsvdata', this.ltvariable.variable_name, function(data){

			if(data.success){
				$scope.loadSelectedMode();
				successMsgService.showSuccessOrErrorMsg(data);
			}else{
				successMsgService.showSuccessOrErrorMsg(data);
			}
		});
	};
	
	$scope.deleteSelectedVariable = function() {
		var result = confirm("You will lose some records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			ltService.deleteVariable($scope, this.ltvariable.variable_name, function(data){

				if(data.success){
					$scope.loadSelectedMode();
					successMsgService.showSuccessOrErrorMsg(data);
				}else{
					successMsgService.showSuccessOrErrorMsg(data);
				}
			});
		}
	};
	$scope.isEditEnabled = false;
	$scope.editVariable = function(index) {
		
		$scope.variableOriginalData = JSON.parse(JSON.stringify(this.ltvariable));
		$scope.variable = this.ltvariable;
		
		for(var i=0; i<$scope.ltvariablescontent.length; i++) {
			var variable = $scope.ltvariablescontent[i];
			variable.isEditEnabled = false;
		}
		$scope.variable.isEditEnabled = true;
		
	};
	$scope.doNotUpdate = function() {
		$scope.variable.isEditEnabled = false;
		this.ltvariable = $scope.variableOriginalData;
	};
	
	$scope.updateVariable = function() {
		ltService.updateVariable($scope, this.ltvariable.variable_name, this.ltvariable.policy, this.ltvariable.starts_from,function(data){

			if(data.success){
				$scope.loadSelectedMode();
				successMsgService.showSuccessOrErrorMsg(data);
			}else{
				successMsgService.showSuccessOrErrorMsg(data);
			}
		});
	};
	
	$scope.openMonitorPage = function() {
		$scope.selectedScenario = this.ltscenario;
		
		// Running Status/Result
		if( $scope.selectedScenario.run_status == true && $scope.selectedScenario.mappedo_scripts > 0 ) {
			
			// go to, the scenario running status
			ltFactory.viewScenarioRunningStatus($scope.appedo.loadtestValue, $scope.selectedScenario.scenarioName, $scope.selectedScenario.run_id, $scope.selectedScenario.scenario_id);
		}
		// Start a new Test; only if scripts are mapped
		else if ( $scope.selectedScenario.mappedo_scripts > 0  ) {
			var modalInstance = $uibModal.open({
				templateUrl: 'modules/load_test/view/lt_select_monitors.html',
				controller: 'loadTestMonitorController',
				size: 'lg',
				resolve: {
					selectedScenario: function() {
						return $scope.selectedScenario;
					},
					testTypeScript: function() {
						return $scope.appedo.loadtestValue;
					}
				}
			});
		} else {
			toastErrNoMapscipts();
		}
	};
	
	$scope.goReports = function() {
		var joSelectedScenario = this.ltscenario;
		
		if ( joSelectedScenario.total_runs === 0 ) {
			// avoid goes to report page
			messageService.showWarningMessage('No runs were executed.');
		} else {
			// go to, the scenario's all reports page
			ltFactory.viewScenarioAllReports($scope.appedo.loadtestValue, joSelectedScenario.scenarioName, joSelectedScenario.run_id, joSelectedScenario.scenario_id);
		}
	};
	
	
	$scope.saveTransitionHiddenParams = function(scenario) {
		sessionServices.set("runId", scenario.run_id);
		sessionServices.set("scenarioId", scenario.scenario_id);
	};

	// edit scenario/map scripts
	$scope.editMapScript = function() {
		$scope.mapScript = this.ltscenario;
		
		// opens edit scenario/map scripts
		ltService.openAddorEditScenario('fromEdit', $scope.moduleCardContent, $scope.mapScript, false);
	};
	
	$scope.openLtRunSetting = function() {
		$scope.mapScript = this.ltscenario;
		
		if( $scope.mapScript.mappedo_scripts === 0 ) {
			// err msg
			toastErrNoMapscipts();
		} else {
			// opens configure scenario/mapped scripts for load test run 
			ltService.openConfigureScenario('fromEdit', $scope.moduleCardContent, $scope.mapScript, $scope.appedo.loadtestValue);
		}
	};
	
	// for no mapped scripts (0 - Mapped script)
	function toastErrNoMapscipts() {
		messageService.showErrorMessage('Map atleast one script.');
	}
	
	$scope.deleteSelectedScenario = function(index) {
		var joSelectedScenario = this.ltscenario;
		var result = confirm("You will lose some records permanently!\nAre you sure you want to delete?");
		if(result == true) {
			if($scope.appedo.loadtestValue == 'APPEDO_LT'){
				ltService.deleteScenarioRecord($scope, joSelectedScenario.scenario_id, joSelectedScenario.scenarioName, function (response) {
					successMsgService.showSuccessOrErrorMsg(response);
				  	if(response.success == true){
				  		$scope.ltscenarioscontent.splice(index,1);
				  	}
				});
			}else{
				ltService.deleteJmeterScenarioRecord($scope, joSelectedScenario.scenario_id, joSelectedScenario.scenarioName, joSelectedScenario.type, function (response) {
					successMsgService.showSuccessOrErrorMsg(response);
				  	if(response.success == true){
				  		$scope.ltscenarioscontent.splice(index,1);
				  	}
				});
			}
		}
	};
	
	$scope.deleteSelectedScript = function(index) {
		$scope.ltScriptData = this.ltscript;
		var result = confirm("You will lose some records permanently!\nAre you sure you want to delete?");
			if(result == true) {
				ltService.deleteScriptRecord($scope, $scope.ltScriptData, $scope.appedo.loadtestValue, function (response) {
					successMsgService.showSuccessOrErrorMsg(response);
				  	if(response.success == true){
				  		$scope.ltscriptscontent.splice(index,1);
				  	}
				});
			}
	};
	
	
	$scope.showContent = function(){
		var variable = this.ltvariable.content;
//		variable = variable.replace(/\\n/g, "<br />");
//		replace(/\\r\\n/g, "<br />");
//		str.replace(/i/g, "ramaaa")
		var modalInstance = $uibModal.open({
			templateUrl: 'modules/load_test/view/show_variable_content.html',
			controller: 'showVariableContentController',
			size: 'lg',
			resolve: {
				item: function () {
					return variable;
				}							
			}
		});
	};
	$scope.$on('$destroy', function() {
		clearTimeout(timer);
	});
}]);

appedoApp.controller('showVariableContentController', ['$scope', '$uibModal',  '$uibModalInstance', 'item', function($scope, $uibModal, $uibModalInstance, item) {
	
	
	$scope.cardLayout = function() {
  		  $uibModalInstance.dismiss('cancel');
   	  	};
   	  	
   			$scope.content = item;
   	$scope.close = function() {
		  $uibModalInstance.dismiss('cancel');
	  };
}]);

appedoApp.controller('loadTestRunningScenarioController', ['$scope', '$state', '$stateParams', 'sessionServices', 'ltService', '$appedoUtils', 'ngToast', '$rootScope', function($scope, $state, $stateParams, sessionServices, ltService, $appedoUtils, ngToast, $rootScope) {
	$scope.backToLTCardPage = function() {
		$state.transitionTo('/moduleDetails');
		sessionServices.set("currentModule", "AppedoLT Scenario");
		//$rootScope.backPageFrom = "LTDetails";
		//$rootScope.selectedLoadTestType = $scope.loadTestType;
	};
	$scope.scenarioName = $stateParams.scenarioName;
	$scope.loadTestType = $stateParams.loadTestType;
	
	$scope.runId = sessionServices.get("runId");
	$scope.scenarioId = sessionServices.get("scenarioId");
	
	$scope.ltRunningScenario = {};
	$scope.scenarioReports = [];
	$scope.ltScenarioReport = [];
	// shown for all scripts completed status
	$scope.showReportsBtn = false;

	var bClearSessionValues = true;
	$scope.runChartLoading = true;
	$scope.d3XaixsFormatForRunCharts = "%H : %M";
	var timerRunningScenario, timerCountdown, timerRunningScenarioForChart;
	
	$scope.getRunningScenario = function() {
		clearTimeout(timerRunningScenario);
		
		ltService.getRunningScenario($scope.runId, $scope.loadTestType, function(data) {
			if ( data.success ) {
				$scope.ltRunningScenario = data.message;
				$scope.ltRunningScenario.total_oth = 0;
				var statusCount = 0;
				$scope.disableStopButton = true;
				for(var i = 0; i < $scope.ltRunningScenario.scripts.length; i = i + 1) {
					var joScript = $scope.ltRunningScenario.scripts[i];
					if(joScript.status=="COMPLETED") {
						statusCount = statusCount + 1;
					}
					$scope.ltRunningScenario.total_oth += joScript.httpOthStatus; 
				}
				if( $scope.ltRunningScenario.scripts.length !== 0 && $scope.ltRunningScenario.scripts.length == statusCount){
					$scope.disableStopButton = false;
					$scope.showReportsBtn = true;
				}
				
				if ( $scope.ltRunningScenario.runendtime == 0 ) {
					timerRunningScenario = setTimeout($scope.getRunningScenario, 1000 * 2);
				} else {
					clearTimeout(timerRunningScenario);
				}
			} else {
				// TODO: for err msg
			}
		});
	};
	$scope.getRunningScenario();
	
	$scope.getRunningScenarioForChart = function() {
		clearTimeout(timerRunningScenarioForChart);
		
		ltService.getRunningScenarioForChart($scope.runId, function(data) {
			if ( data.success ) {
				$scope.throughputRunChartData = [];
				$scope.hitCountRunChartData = [];
				$scope.userRumpupRunChartData = [];
				$scope.throughputRunChartData = getThroughputData(data.message.tPutAndHitsCounts);
				$scope.hitCountRunChartData = getHitCountData(data.message.tPutAndHitsCounts);
				$scope.userRumpupRunChartData = data.message.userRampUp;
				$scope.runChartLoading = false;
				if ( $scope.showReportsBtn ) {
					clearTimeout(timerRunningScenarioForChart);
				} else {
					timerRunningScenarioForChart = setTimeout($scope.getRunningScenarioForChart, 1000 * 10);
				}
			} else {
				// TODO: for err msg
			}
		});
	};
	$scope.getRunningScenarioForChart();
	
	$scope.stopRunningScenario = function(){
		
		var result = confirm("Are you sure on stopping the Load Test?");
		if(result == true) {
			ltService.stopRunningScenario($scope.runId, function(data) {
		 		if(data.success){
					ngToast.create({
						className: 'warning',
						content: data.message,
						timeout: 3000,
						dismissOnTimeout: true,
						dismissButton: true,
						animation: 'fade'
					});
		 		}else{
		 			//showMessage.setMessage({level:'bg-error-message', text: data.message});
		 		}
			});
			
		}
	};
	
	
	$scope.saveHiddenParams = function() {
		// for redirect to report page, avoided to clear session storage
		bClearSessionValues = false;
	}
	
	$scope.openOrFocusWindow = function(oLink) {
		var oWindow = null, sTarget = "_appedo_report_"+oLink.ltRunningScenario.reportName;
		if ( !window.popups )
			window.popups = {};
			
		if ( window.popups[sTarget] ) {
			oWindow = window.popups[sTarget];
			oWindow.close();
		}
		
		if ( !oWindow || oWindow.closed ) {
			oWindow = window.open(oLink.ltRunningScenario.grafanaReportURL, sTarget);
			window.popups[sTarget] = oWindow;
		}
		
		oWindow.focus();
	};

	$scope.$on('$destroy', function() {
		clearTimeout(timerRunningScenario);
		clearTimeout(timerRunningScenarioForChart);
		
		if ( bClearSessionValues ) {
			sessionServices.destroy("runId");
			sessionServices.destroy("scenarioId");	
		}
	});
}]);

appedoApp.controller('loadTestScenarioReportsController', ['$scope', '$stateParams', 'sessionServices', 'ltFactory', 'ltService', 'apmModulesService', '$state', '$appedoUtils','successMsgService', '$rootScope','$location', 'messageService', function($scope, $stateParams, sessionServices, ltFactory, ltService, apmModulesService, $state, $appedoUtils, successMsgService, $rootScope, $location, messageService) {

	$scope.scenarioName = $stateParams.scenarioName;
	$scope.loadTestType = $stateParams.loadTestType;
	$scope.moduleType = $stateParams.moduleType;
	
	var d3ChartTimeFormatForLT = JSON.parse(sessionServices.get("d3ChartTimeFormatForLT"));
	var d3ChartTimeFormatForLTPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForLTPdf"));
	var d3ChartTypeForLT = JSON.parse(sessionServices.get("d3ChartTypeForLT"));
	
	$scope.runId = sessionServices.get("runId");
	$scope.scenarioId = sessionServices.get("scenarioId");
	
	$scope.scenarios = [];
	
	$scope.ltReportType = 'SUMMARY';
	
	$scope.summaryReports = [];
	$scope.logReports = [];
	$scope.errorReports = [];
	$scope.masterSummaryReport = [];
	$scope.scriptSummaryReport = [];
	$scope.requestResponseData = [];
	$scope.containerResponseData = [];
	$scope.transactionResponseData = [];
	$scope.errorCountData = [];
	$scope.errorDescriptionData = [];
	$scope.showSummaryGrid = false;
	$scope.showManualReportButton = false;
	$scope.reportGenerationMsg = false;
	// shown for all scripts completed status
	$scope.showReportsBtn = false;
	$scope.removeAggregation = true;
	var bClearSessionValues = true;
	
	var timerRunningScenario;
	$scope.scenarioReports = [];
	
	$scope.selectedSummaryScript = {};
	var joCategoryWiseNotes = {};
	// the categories; notes also sets into the category, in resp., since to reflect in UI 
	$scope.summaryReportNotesCategories = ltFactory.summaryReportNotesCategories;

	$scope.backToLTCardPage = function() {
		$state.transitionTo('/moduleDetails');
		sessionServices.set("currentModule", "AppedoLT Scenario");
		//$rootScope.backPageFrom = "LTDetails";
		//$rootScope.selectedLoadTestType = $scope.loadTestType;
	};
	
	$scope.getScenarioReports = function() {
		ltService.getScenarioReports($scope.scenarioId, $scope.loadTestType, function(data) {
			if ( ! data.success ) {
				// err 
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.scenarioReports = data.message;
				
				/*
				 * select the report,
				 * since from LT dashboard, the selected report details to show; 
				 *   from Scenario, the last runId is stored, the last run's report is shown 
				 */
				for (var i = 0; i < $scope.scenarioReports.length; i = i + 1) {
					var joReport = $scope.scenarioReports[i];
					if ( joReport.reportId ==  $scope.runId ) {
						$scope.selectedReport = joReport;
					}
				}
				/* ignored, the select of first report, 
				$scope.selectedReport = $scope.scenarioReports[0];
				*/
				
				$scope.summary_message = $scope.selectedReport.status == 'REPORT GENERATION STARTED'?$scope.selectedReport.status:'';
				
				
				$scope.getSelectedReportDetails();
			}
		});
	};
	$scope.getScenarioReports();

	$scope.loadSelectedTypeReport = function() {
		if ( $scope.loadTestType === 'APPEDO_LT' ) {
			// APPEDO_LT report
			getAppedoLTReport();
		} else {
			// JMETER report
			getJmeterLTReport();
		}
	};
	
	// gets APPEDO_LT run report
	function getAppedoLTReport() {
		if ( $scope.ltReportType == 'STATUS' ) {
			$scope.getRunningScenario();
		} else if ( $scope.ltReportType == 'SUMMARY' ) {
			$scope.chartDurationForPdf = undefined;
			$scope.selectedTime = undefined;
			if($scope.selectedReport.status == 'REPORT GENERATION STARTED'){
				$scope.summary_message = 'Report Generation Started';
			}else{
				$scope.summary_message = '';
				if(checkRunTimeLessThanGivenHour(3,$scope.selectedReport.runTime)){
					if(checkRunTimeLessThanGivenMinute(1,$scope.selectedReport.runTime)){
						$scope.getLTChartForPdf(1,0);
					}else{
						$scope.getLTChartForPdf(0,0);
					}
				}else{
					$scope.getSummaryReport();
				}
			}
		} else if ( $scope.ltReportType == 'CHART' ) {
			$scope.chartDurationType = undefined;
			$scope.selectedTime = undefined;
			if($scope.selectedReport.status=="RUNNING"){
				$scope.getChartReport();
			}else{
				if(checkRunTimeLessThanGivenHour(3,$scope.selectedReport.runTime)){
					if(checkRunTimeLessThanGivenMinute(1,$scope.selectedReport.runTime)){
						$scope.getDrillDownLTChart(1,0);
					}else{
						$scope.getDrillDownLTChart(0,0);
					}
				}else{
					$scope.getChartReport();
				}
			}
		} else if ( $scope.ltReportType == 'LOG' ) {
			$scope.getLogReport();
		} else if ( $scope.ltReportType == 'ERROR' ) {
			$scope.getErrorReport();
		}
	}
	
	// gets JMETER run report
	function getJmeterLTReport() {
		// TODO
	};
	
	function checkRunTimeLessThanGivenHour(hour,runTime){
		return (1000 * 60 * 60 * Number(hour)) > Number(runTime) ? true : false;
	}

	function checkRunTimeLessThanGivenMinute(minute,runTime){
		return (1000 * 60 * Number(minute)) > Number(runTime) ? true : false;
	}

	$scope.getDrillDownLTChart = function(chartDurationType,selectedTime) {
		$scope.chartDurationType = chartDurationType;
		$scope.selectedTime = selectedTime;
		$scope.getChartReport();
	};
	
	$scope.getLTChartForPdf = function(chartDurationForPdf,selectedTime) {
		$scope.chartDurationForPdf = chartDurationForPdf;
		$scope.selectedTime = selectedTime;
		$scope.getSummaryReport();
	};

	$scope.getChartReport = function() {
		$scope.ltAreaChartData = [];
		$scope.loadgensAvgReqResps = [];
		$scope.loadgensAvgPageResps = [];
		$scope.loadgensAvgReqRespsOri = [];
		$scope.loadgensAvgPageRespsOri = [];
		$scope.reqResponseLocations = [];
		$scope.pageResponseLocations = [];
		$scope.selectedReqResponseLocation="All Locations";
		$scope.selectedPageResponseLocation="All Locations";
		$scope.showReqLocationDropdown = false;
		$scope.showPageLocationDropdown = false;
		if($scope.loadTestType == "APPEDO_LT"){
			if($scope.selectedReport.status=="RUNNING"){
				if($scope.chartDurationType==undefined){
					$scope.d3XaixsFormat = d3ChartTimeFormatForLT[1];
					$scope.queryDurationType = d3ChartTypeForLT[1];
					$scope.chartDurationType = 1;
				}else{
					$scope.d3XaixsFormat = d3ChartTimeFormatForLT[Number($scope.chartDurationType)+1];
					$scope.queryDurationType = d3ChartTypeForLT[Number($scope.chartDurationType)+1];
					$scope.chartDurationType = Number($scope.chartDurationType)+1;
				}
			}else{
				if($scope.chartDurationType==undefined){
					$scope.d3XaixsFormat = d3ChartTimeFormatForLT[0];
					$scope.queryDurationType = d3ChartTypeForLT[0];
					$scope.chartDurationType = 0;
				}else{
					$scope.d3XaixsFormat = d3ChartTimeFormatForLT[Number($scope.chartDurationType)+1];
					$scope.queryDurationType = d3ChartTypeForLT[Number($scope.chartDurationType)+1];
					$scope.chartDurationType = Number($scope.chartDurationType)+1;
				}
			}
			
			getAPMChartDataAppedoLT();
			
			$scope.userCountLoading = true;
			$scope.requestResponseHitCountChartAndThroughputLoading = true;
			$scope.errorCountLoading = true;
			$scope.pageResponseLoading = true;
			$scope.loadgensAvgReqRespsLoading = true;
			$scope.loadgensAvgPageRespsLoading = true;
			ltService.checkEndTimeFormatForExistingTest($scope.selectedReport.reportId, function(data) {
				if ( data.success ) {
					if(data.message){
						allLTChart();
					}else{
						ltService.runEndTimeFormatForExistingTest($scope.selectedReport.reportId, function(data) {
							if ( data.success ) {
								allLTChart();
							} else {

							}
						});
					}
				} else {
					ltService.runEndTimeFormatForExistingTest($scope.selectedReport.reportId, function(data) {
						if ( data.success ) {
							allLTChart();
						} else {

						}
					});
				}
			});
			
			function allLTChart(){
				ltService.getNewChartReport($scope.selectedReport.reportId, $scope.loadTestType,$scope.selectedReport.runStartTime,$scope.queryDurationType,$scope.selectedTime,$scope.selectedReport.status,$scope.selectedReport.runTime,'userCountChartData', function(data) {
					if ( data.success ) {
						$scope.userCountChartData = data.message.userCountChartData;
						$scope.userCountLoading = false;
					} else {
						$scope.userCountChartData = [];
						$scope.userCountLoading = false;
					}
				});
	
				ltService.getNewChartReport($scope.selectedReport.reportId, $scope.loadTestType,$scope.selectedReport.runStartTime,$scope.queryDurationType,$scope.selectedTime,$scope.selectedReport.status,$scope.selectedReport.runTime,'combinedDataForRequestResponseHitCountChartAndThroughput', function(data) {
					if ( data.success ) {
						$scope.throughputChartData = getThroughputData(data.message.combinedDataForRequestResponseHitCountChartAndThroughput);
						$scope.hitCountChartData = getHitCountData(data.message.combinedDataForRequestResponseHitCountChartAndThroughput);
						$scope.requestResponseChartData = getRequestResponseData(data.message.combinedDataForRequestResponseHitCountChartAndThroughput);
						$scope.requestResponseHitCountChartAndThroughputLoading = false;
					} else {
						$scope.throughputChartData = [];
						$scope.hitCountChartData = [];
						$scope.requestResponseChartData = [];
						$scope.requestResponseHitCountChartAndThroughputLoading = false;
					}
				});
				
				ltService.getNewChartReport($scope.selectedReport.reportId, $scope.loadTestType,$scope.selectedReport.runStartTime,$scope.queryDurationType,$scope.selectedTime,$scope.selectedReport.status,$scope.selectedReport.runTime,'errorCountChartData', function(data) {
					if ( data.success ) {
						$scope.errorCountChartData = data.message.errorCountChartData;
						$scope.errorCountLoading = false;
					} else {
						$scope.errorCountChartData = [];
						$scope.errorCountLoading = false;
					}
				});
				
				ltService.getNewChartReport($scope.selectedReport.reportId, $scope.loadTestType,$scope.selectedReport.runStartTime,$scope.queryDurationType,$scope.selectedTime,$scope.selectedReport.status,$scope.selectedReport.runTime,'pageResponseChartData', function(data) {
					if ( data.success ) {
						$scope.pageResponseChartData = data.message.pageResponseChartData;
						$scope.pageResponseLoading = false;
					} else {
						$scope.pageResponseChartData = [];
						$scope.pageResponseLoading = false;
					}
				});
	
				ltService.getNewChartReport($scope.selectedReport.reportId, $scope.loadTestType,$scope.selectedReport.runStartTime,$scope.queryDurationType,$scope.selectedTime,$scope.selectedReport.status,$scope.selectedReport.runTime,'loadgensAvgReqResps', function(data) {
					if ( data.success ) {
						$scope.loadgensAvgReqResps = data.message.loadgensAvgReqResps;
						$scope.loadgensAvgReqRespsOri = data.message.loadgensAvgReqResps;
						$scope.reqResponseLocations = data.message.loadgensAvgReqResps;
						$scope.showReqLocationDropdown = true;
						$scope.loadgensAvgReqRespsLoading = false;
					} else {
						$scope.loadgensAvgReqResps = [];
						$scope.loadgensAvgReqRespsOri = [];
						$scope.reqResponseLocations = [];
						$scope.showReqLocationDropdown = false;
						$scope.loadgensAvgReqRespsLoading = false;
					}
				});
	
				ltService.getNewChartReport($scope.selectedReport.reportId, $scope.loadTestType,$scope.selectedReport.runStartTime,$scope.queryDurationType,$scope.selectedTime,$scope.selectedReport.status,$scope.selectedReport.runTime,'loadgensAvgPageResps', function(data) {
					if ( data.success ) {
						$scope.loadgensAvgPageResps = data.message.loadgensAvgPageResps;
						$scope.loadgensAvgPageRespsOri = data.message.loadgensAvgPageResps;
						$scope.pageResponseLocations = data.message.loadgensAvgPageResps;
						$scope.showPageLocationDropdown = true;
						$scope.loadgensAvgPageRespsLoading = false;
					} else {
						$scope.loadgensAvgPageResps = [];
						$scope.loadgensAvgPageRespsOri = [];
						$scope.pageResponseLocations = [];
						$scope.showPageLocationDropdown = false;
						$scope.loadgensAvgPageRespsLoading = false;
					}
				});
			}
		}else if($scope.loadTestType == "JMETER"){
//			$scope.d3XaixsFormat = "%d %b %H:%M %S";
			$scope.d3XaixsFormat = "%H:%M:%S";
//			$scope.d3XaixsFormat = "%d %b";
			$scope.pageResponseLoading = true;
			$scope.errorCountLoading = true;
			$scope.requestResponseHitCountChartAndThroughputLoading = true;
			$scope.userCountLoading = true;
			getAPMChartDataAppedoLT();
			ltService.getChartReport($scope.selectedReport.reportId, $scope.loadTestType,$scope.selectedReport.runStartTime, function(data) {
				if ( data.success ) {
					for(var i = 0; i < data.message.emptyLoadgenValue.length; i = i + 1) {
						var graphContent = data.message.emptyLoadgenValue[i];
						if(graphContent.chartName == "User Counts"){
							$scope.userCountChartData = graphContent.chartData;
						}else if(graphContent.chartName == "Hit Counts"){
							$scope.hitCountChartData = graphContent.chartData;
						}else if(graphContent.chartName == "Avg. Request Response"){
							$scope.requestResponseChartData = graphContent.chartData;
						}else if(graphContent.chartName == "Avg. ThroughPut"){
							$scope.throughputChartData = graphContent.chartData;
						}else if(graphContent.chartName == "Error Counts"){
							$scope.errorCountChartData = graphContent.chartData;
						}else if(graphContent.chartName == "Avg. Page Response"){
							$scope.pageResponseChartData = graphContent.chartData;
						}
					}
					$scope.pageResponseLoading = false;
					$scope.errorCountLoading = false;
					$scope.requestResponseHitCountChartAndThroughputLoading = false;
					$scope.userCountLoading = false;
				} else {
					$scope.pageResponseLoading = false;
					$scope.errorCountLoading = false;
					$scope.requestResponseHitCountChartAndThroughputLoading = false;
					$scope.userCountLoading = false;
				}
			});	
		}
		
		$scope.getReqResponseSelectedLocation = function(selectedLoc)
		{
			if(selectedLoc=="All Locations"){
				$scope.loadgensAvgReqResps = $scope.loadgensAvgReqRespsOri;
			}else{
				var selectedChartData = [];
				for(var i=0; i< $scope.loadgensAvgReqRespsOri.length; i++) {
					var moduleContent = $scope.loadgensAvgReqRespsOri[i];
					if((moduleContent.loadgen_name+"-"+moduleContent.City)==selectedLoc){
						selectedChartData.push(moduleContent);
						break;
					}
				}
				$scope.loadgensAvgReqResps = selectedChartData;
			}
		};
		
		$scope.getPageResponseSelectedLocation = function(selectedLoc)
		{
			if(selectedLoc=="All Locations"){
				$scope.loadgensAvgPageResps = $scope.loadgensAvgPageRespsOri;
			}else{
				var selectedChartData = [];
				for(var i=0; i< $scope.loadgensAvgPageRespsOri.length; i++) {
					var moduleContent = $scope.loadgensAvgPageRespsOri[i];
					if((moduleContent.loadgen_name+"-"+moduleContent.City)==selectedLoc){
						selectedChartData.push(moduleContent);
						break;
					}
				}
				$scope.loadgensAvgPageResps = selectedChartData;
			}
		};

		function searchCounterIdInArray(nameKey, myArray){
			for (var i=0; i < myArray.length; i++) {
				if (myArray[i].counterId == nameKey) {
					return myArray[i];
				}
			}
		}
		
		function getAPMChartDataAppedoLT(){
			$scope.apmChartdata = [];
			if($scope.selectedReport.guid!=undefined){
				if($scope.selectedReport.guid!="0")
				{
					$scope.state = "/"+$location.path().split("/")[1];
					$scope.apmChartdata=[];
					$scope.inDashBoardStatus = false;
					$scope.isLTReports = true;
					var primaryCountersChartdataJSONObj={};
					var primaryCountersChartdataJSONArray=[];

					var allGuid = $scope.selectedReport.guid.split(",");
					for(var i = 0; i < allGuid.length; i = i + 1) {
						var guid = allGuid[i];
						var resultPrimaryCountersdata = apmModulesService.getPrimaryCountersForAllDetailsPage(guid, true);
						resultPrimaryCountersdata.then(function(resp) {
							if(resp.success){
								var primaryRespGUID = resp.message[0].counterData.guid;
								if(resp.message.length>0){
									resp.message.forEach(function(counter) {
										resultPrimaryCountersChartdata = ltService.getNewModuleCountersChartdataForLoadTest(primaryRespGUID, counter.counter_id,$scope.selectedReport.runStartTime,$scope.selectedReport.runEndTime,$scope.selectedReport.runTime,$scope.queryDurationType,$scope.selectedTime,$scope.selectedReport.status, $scope.selectedReport.startMonitor, $scope.selectedReport.endMonitor);
										resultPrimaryCountersChartdata.then(function(respGraph) {
											if(respGraph.success) {
												var data = searchCounterIdInArray(counter.counter_id, respGraph.message);
												if(data.graphData != null){
													primaryCountersChartdataJSONObj={};
													primaryCountersChartdataJSONObj["guid"]=primaryRespGUID;
													primaryCountersChartdataJSONObj["category"]=counter.category;
													primaryCountersChartdataJSONObj["title"]=counter.title;
													primaryCountersChartdataJSONObj["display_name"]=counter.display_name;
													primaryCountersChartdataJSONObj["counter"]=counter.counter;
													//primaryCountersChartdataJSONObj["unit"]=counter.unit
													primaryCountersChartdataJSONObj["show_in_dashboard"]=counter.show_in_dashboard;
													primaryCountersChartdataJSONObj["show_in_primary"]=counter.show_in_primary;
													primaryCountersChartdataJSONObj["is_mandatory"]=counter.is_mandatory;
													primaryCountersChartdataJSONObj["counterId"]=counter.counter_id;
													primaryCountersChartdataJSONObj["graphData"]=data.graphData;
													
													primaryCountersChartdataJSONArray.push(primaryCountersChartdataJSONObj);
													$scope.apmChartdata = primaryCountersChartdataJSONArray;
												}
											}
										});
									});
								}
							}
						});
					}
				}
			}
		}
	};

	$scope.addChartToDashboard = function(){
		var counterDatas = this.counterData;
		var resultAddChartToDashboard;
		resultAddChartToDashboard = apmModulesService.addChartToDashboard(counterDatas.guid,counterDatas.counterId);
		resultAddChartToDashboard.then(function(resp) {
			if(resp.success){
				counterDatas.show_in_dashboard = true;
			}
			successMsgService.showSuccessOrErrorMsg(resp);
		});
	};

	$scope.removeChartToDashboard = function(){
		var counterDatas = this.counterData;
		var resultRemoveChartToDashboard;
		resultRemoveChartToDashboard = apmModulesService.removeChartToDashboard(counterDatas.guid,counterDatas.counterId);
		resultRemoveChartToDashboard.then(function(resp) {
			if(resp.success){
				for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
					var primaryContent = $scope.apmChartdata[i];
					if(primaryContent.counter_id==counterDatas.counterId){
						$scope.apmChartdata.splice(i,1);
					}
				}
				counterDatas.show_in_dashboard = false;
			}
			successMsgService.showSuccessOrErrorMsg(resp);
		});
	};

	// TODO: pass params might be scenarioId, Running scenario screen
	$scope.getRunningScenario = function() {
		clearTimeout(timerRunningScenario);
		var nTotalCompletedScript = 0;
		
		ltService.getRunningScenario($scope.selectedReport.reportId, $scope.loadTestType, function(data) {
			if ( data.success ) {
				$scope.ltRunningScenario = data.message;
				$scope.ltRunningScenario.elapsedTime = (new Date()).getTime() - $scope.ltRunningScenario.runStartTime;
				$scope.ltRunningScenario.total_oth = 0;
				for(var i = 0; i < $scope.ltRunningScenario.scripts.length; i = i + 1) {
					var joScript = $scope.ltRunningScenario.scripts[i];
					$scope.ltRunningScenario.total_oth += joScript.httpOthStatus;
					
					if ( joScript.status === "COMPLETED" ) {
						nTotalCompletedScript = nTotalCompletedScript + 1;
					}
				}
				if ( $scope.ltRunningScenario.runendtime == 0 ) {
					timerRunningScenario = setTimeout($scope.getRunningScenario, 1000 * 2);
				} else {
					clearTimeout(timerRunningScenario);
				}
				
				/*
				if ( $scope.ltRunningScenario.scripts.length !== 0 && $scope.ltRunningScenario.scripts.length === nTotalCompletedScript ){
					$scope.showReportsBtn = true;
				}*/
				
			} else {
				// TODO: for err msg
			}
		});
		
		$scope.showErrorPage = function() {
			$scope.ltReportType = 'ERROR';
			$scope.getErrorReport();
		};
	};
	
	// go to running scenario status screen, for the selected scenario status is `RUNNING`
	$scope.viewScenarioRunningStatus = function() {
		ltFactory.viewScenarioRunningStatus($scope.loadTestType, $scope.scenarioName, $scope.selectedReport.reportId, $scope.selectedReport.scenarioId);
	};
	
	
	//  
	$scope.goToSummaryReport = function() {
		$scope.ltReportType = 'SUMMARY';
		$scope.loadSelectedTypeReport();
	};
	
	$scope.getSummaryReport = function() {
		$scope.summaryReports = [];
		ltService.getSummaryReport($scope.selectedReport.reportId, $scope.loadTestType, function(data) {
			if(data.success){
				$scope.summaryReports = data;
				$scope.runId = $scope.selectedReport.reportId;
				if($scope.selectedReport.status=="RUNNING"){
					if($scope.chartDurationForPdf==undefined){
						$scope.d3XaixsFormatForPdf = d3ChartTimeFormatForLTPdf[1];
						$scope.queryDurationForPdf = d3ChartTypeForLT[1];
						$scope.chartDurationForPdf = 1;
					}else{
						$scope.d3XaixsFormatForPdf = d3ChartTimeFormatForLTPdf[Number($scope.chartDurationForPdf)+1];
						$scope.queryDurationForPdf = d3ChartTypeForLT[Number($scope.chartDurationForPdf)+1];
						$scope.chartDurationForPdf = Number($scope.chartDurationForPdf)+1;
					}
				}else{
					if($scope.queryDurationForPdf==undefined){
						$scope.d3XaixsFormatForPdf = d3ChartTimeFormatForLTPdf[0];
						$scope.queryDurationForPdf = d3ChartTypeForLT[0];
						$scope.chartDurationForPdf = 0;
					}else{
						$scope.d3XaixsFormatForPdf = d3ChartTimeFormatForLTPdf[Number($scope.chartDurationForPdf)+1];
						$scope.queryDurationForPdf = d3ChartTypeForLT[Number($scope.chartDurationForPdf)+1];
						$scope.chartDurationForPdf = Number($scope.chartDurationForPdf)+1;
					}
				}
				
				if($scope.selectedReport.status == 'FAILED'){
					$scope.showSummaryGrid = false;
					$scope.showManualReportButton = true;
					$scope.showManualReportButtonMessage = "Load Test run is failed. Please click Manual Report button to generate a report.";
					$scope.reportGenerationMsg = false;
				} else if($scope.selectedReport.status == 'RUNNING'){
					$scope.showSummaryGrid = false;
					$scope.showManualReportButton = false;
					$scope.reportGenerationMsg = true;
					$scope.reportGenerationMsgMessage = "Test is under process.";
				} else if($scope.selectedReport.status == 'QUEUED'){
					$scope.showSummaryGrid = false;
					$scope.showManualReportButton = false;
					$scope.reportGenerationMsg = true;
					$scope.reportGenerationMsgMessage = "Please wait Load Test is queued.";
				} else {
					var scriptIds = getScriptsId(data.message.scripts);
					if(scriptIds !=""){
						getNewSummaryReportDetails(scriptIds);
					}
				}
			}
		});
		
		// run's summary report categories notes
		getLoadTestRunSummaryReportNotes();
	};

	
	function getScriptsId(scripts){
		var scriptIds="";
		for(var i = 0; i < scripts.length; i = i + 1) {
			var jsonObj = scripts[i];
			if(scriptIds==""){
				scriptIds =  jsonObj.scriptId;
			}else{
				scriptIds = scriptIds+","+ jsonObj.scriptId;
			}
		}
		return scriptIds;
	}

	function getNewSummaryReportDetails(scriptIds){
		$scope.showSummaryGrid = true;
		$scope.showManualReportButton = false;
		$scope.reportGenerationMsg = false;
		$scope.masterSummaryReport = [];
		$scope.disableManualReportButton = false;
		if($scope.selectedReport.status == 'MANUAL REPORT GENERATION COMPLETED' || $scope.selectedReport.status == 'AUTO REPORT GENERATION COMPLETED') {
			$scope.showSummaryGrid = true;
			$scope.showManualReportButton = false;
			$scope.reportGenerationMsg = false;
			$scope.getSummaryReportData(scriptIds);
		} else if($scope.selectedReport.status == 'MANUAL REPORT GENERATION FAILED' || $scope.selectedReport.status == 'AUTO REPORT GENERATION FAILED') {
			$scope.showSummaryGrid = false;
			$scope.showManualReportButton = true;
			$scope.showManualReportButtonMessage = "Summary report is not generated. Please click Manual Report button to generate a report.";
			$scope.reportGenerationMsg = false;
		} else if($scope.selectedReport.status == 'MANUAL REPORT PREPARATION STARTED' || $scope.selectedReport.status == 'MANUAL REPORT GENERATION STARTED') {
			$scope.showSummaryGrid = false;
			$scope.showManualReportButton = false;
			$scope.reportGenerationMsg = true;
			$scope.reportGenerationMsgMessage = "Please wait manual report generation is in progress.";
		} else if($scope.selectedReport.status == 'AUTO REPORT PREPARATION STARTED' || $scope.selectedReport.status == 'AUTO REPORT GENERATION STARTED') {
			$scope.showSummaryGrid = false;
			$scope.showManualReportButton = false;
			$scope.reportGenerationMsg = true;
			$scope.reportGenerationMsgMessage = "Please wait report generation is in progress.";
		} else if($scope.selectedReport.status == 'COMPLETED' || $scope.selectedReport.status == 'REPORT GENERATION STARTED' ) {
			$scope.showSummaryGrid = false;
			$scope.showManualReportButton = true;
			$scope.showManualReportButtonMessage = "Design is changed. Please click Manual Report button to generate a report.";
			$scope.reportGenerationMsg = false;
		} else if($scope.selectedReport.status == 'AUTO REPORT PROCESS IN QUEUE') {
			$scope.showSummaryGrid = false;
			$scope.showManualReportButton = false;
			$scope.reportGenerationMsg = true;
			$scope.reportGenerationMsgMessage = "Run is completed. Auto report process in queue.";
		}
	}
	
	$scope.getSummaryReportData = function (scriptIds) {
		ltService.getMasterSummaryReport($scope.selectedReport.reportId, $scope.loadTestType, function(data) {
			if(data.success){
				$scope.masterSummaryReport = data.message[0];
			}else{
				
			}
		});
		$scope.scriptSummaryReport = [];
		$scope.showSelectedScriptAccordion = false;
		$scope.selectedSummaryScript = {};
		$scope.selectedScriptName = '';
		ltService.getScriptSummaryReport($scope.selectedReport.reportId, $scope.loadTestType, scriptIds, function(data) {
			if( ! data.success ){
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				$scope.scriptSummaryReport = data.message;
				
				// default, loads 1'st script's script wise report
				if($scope.scriptSummaryReport.length > 0) {
					$scope.getScriptWiseReport($scope.scriptSummaryReport[0]);
				}
			}
		});
		
		$scope.status = {
			isFirstOpen: true,
			isSecondOpen: true,
			isRrOpen: true,
			isCrOpen: true,
			isTrOpen: true,
			isEcOpen: true,
			isEdOpen: true,
			isSettingOpen: true
		};
		$scope.showCollapse = true;
	};
	//$scope.expandAll = false;
	
	$scope.expandAll = function() {
		$scope.showCollapse = true;
		$scope.status = {
			isFirstOpen: true,
		   	isSecondOpen: true,
			isRrOpen: true,
			isCrOpen: true,
			isTrOpen: true,
			isEcOpen: true,
			isEdOpen: true,
			isSettingOpen: true
		};
	};
	$scope.isAllOpened = function() {
			if($scope.status.isFirstOpen && $scope.status.isSecondOpen && $scope.status.isRrOpen && $scope.status.isCrOpen && $scope.status.isTrOpen && $scope.status.isEcOpen && $scope.status.isEdOpen && $scope.status.isSettingOpen){
				$scope.showCollapse = true;
			} else if(!$scope.status.isFirstOpen && !$scope.status.isSecondOpen && !$scope.status.isRrOpen && !$scope.status.isCrOpen && !$scope.status.isTrOpen && !$scope.status.isEcOpen && !$scope.status.isEdOpen && !$scope.status.isSettingOpen) {
				$scope.showCollapse = false;
			}
	}
	$scope.closeAll = function() {
		$scope.showCollapse = false;
		$scope.status = {
			isFirstOpen: false,
			isSecondOpen: false,
			isRrOpen: false,
			isCrOpen: false,
			isTrOpen: false,
			isEcOpen: false,
			isEdOpen: false,
			isSettingOpen: false
		};
	};
	
	//$scope.showSelectedScriptAccordion = false;
	$scope.getScriptWiseReport = function(joSummaryScript) {
		$scope.selectedSummaryScript = joSummaryScript;
		
		$scope.selectedScriptName = joSummaryScript.scriptName;
		$scope.showSelectedScriptAccordion = true;
		
		// gets script wise reports
		$scope.getChildSummaryReport(joSummaryScript.scriptId);
		
		// sets catgories script wise notes; thinks, need to handle if notes are not loaded till script wise report loads
		setCategoriesScriptWiseNotes(joSummaryScript);
	};
		
	$scope.getChildSummaryReport = function(scriptId) {
		$scope.requestResponseData = [];
		ltService.getChildSummaryReportScriptWise($scope.selectedReport.reportId, $scope.loadTestType,scriptId,"requestResponse", function(data) {
			if(data.success) {
				$scope.requestResponseData = data.message.summaryData;
				$scope.scriptId = scriptId;
			}
		});
		
		$scope.containerResponseData = [];
		ltService.getChildSummaryReportScriptWise($scope.selectedReport.reportId, $scope.loadTestType,scriptId,"containerResponse", function(data) {
			if(data.success) {
				$scope.containerResponseData = data.message.summaryData;
				$scope.scriptId = scriptId;
			}
		});

		$scope.transactionResponseData = [];
		ltService.getChildSummaryReportScriptWise($scope.selectedReport.reportId, $scope.loadTestType,scriptId,"transactionResponse", function(data) {
			if(data.success) {
				$scope.transactionResponseData = data.message.summaryData;
				$scope.scriptId = scriptId;
			}
		});

		$scope.errorCountData = [];
		ltService.getChildSummaryReportScriptWise($scope.selectedReport.reportId, $scope.loadTestType,scriptId,"errorCount", function(data) {
			if(data.success) {
				$scope.errorCountData = data.message.summaryData;
				$scope.scriptId = scriptId;
			} else {
				//$scope.errorCountData = "No data available";
			}
		});

		$scope.errorDescriptionData = [];
		ltService.getChildSummaryReportScriptWise($scope.selectedReport.reportId, $scope.loadTestType,scriptId,"errorDescription", function(data) {
			if(data.success) {
				$scope.errorDescriptionData = data.message.summaryData;
				$scope.scriptId = scriptId;
			}else {
				//$scope.errorDescriptionData = "No data available";
			}
		});
	};
	
	
	// add or edit Summary, report notes
	$scope.addSummaryNotes = function(joSelectedSummaryCategory) {
		
		// Note: in `$scope.selectedReport`, `runId` is saved in the key name of `reportId`
		ltService.openAddOrEditSummaryNotes('ADD/EDIT', joSelectedSummaryCategory, $scope.selectedReport, $scope.selectedSummaryScript, $scope.loadTestType, function() {
			// reload notes on notes save & sets the notes for the category
			getLoadTestRunSummaryReportNotes(function() {
				setCategoriesScriptWiseNotes($scope.selectedSummaryScript);
			});
		});
	};
	
	// gets summary report notes for the categories for the LT run
	function getLoadTestRunSummaryReportNotes( callback ) {
		ltService.getLoadTestRunSummaryReportNotes($scope.selectedReport.reportId, function(data) {
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				joCategoryWiseNotes = data.message;
				
				// set notes for the categories, which doesn't have script wise; say `Summary`, `Settings`, `Script Wise`
				$scope.summaryReportNotesCategories[0].notes = joCategoryWiseNotes[$scope.summaryReportNotesCategories[0].value];
				$scope.summaryReportNotesCategories[1].notes = joCategoryWiseNotes[$scope.summaryReportNotesCategories[1].value];
				$scope.summaryReportNotesCategories[2].notes = joCategoryWiseNotes[$scope.summaryReportNotesCategories[2].value];
				
				// callback fn
				if ( callback instanceof Function ) {
					callback();
				}
			}
		});
	}
	
	// sets notes for the categories which has script wise
	function setCategoriesScriptWiseNotes( joScript ) {
		
		// sets notes into the respective categories, which are script wise; say `Container`, `Request`, ...
		for (var i = 0; i < $scope.summaryReportNotesCategories.length; i = i + 1) {
			var joSummaryCategory = $scope.summaryReportNotesCategories[i];
			
			if ( joSummaryCategory.hasScriptWiseNote ) {
				var aryCategoryScriptWiseNotes = joCategoryWiseNotes[joSummaryCategory.value] || [];
				
				// sets selected script's notes into the respective category
				for (var j = 0; j < aryCategoryScriptWiseNotes.length; j = j + 1) {
					var joScriptNote = aryCategoryScriptWiseNotes[j];
					
					if ( joScript.scriptId === joScriptNote.scriptId ) {
						joSummaryCategory.notes = joScriptNote.notes;
						break;
					}
				}
			}
		}
	}
	
	
	$scope.manualReport = function() {
		$scope.disableManualReportButton = true;
		$scope.showManualReportButtonMessage = "Please wait manual report generation is in progress.";
		ltService.checkEndTimeFormatForExistingTest($scope.selectedReport.reportId, function(data) {
			if ( data.success ) {
				if(data.message){
					runManualReport();
				}else{
					ltService.runEndTimeFormatForExistingTest($scope.selectedReport.reportId, function(data) {
						if ( data.success ) {
							runManualReport();
						} else {
//							console.log(data);
						}
					});
				}
			} else {
				ltService.runEndTimeFormatForExistingTest($scope.selectedReport.reportId, function(data) {
					if ( data.success ) {
						runManualReport();
					} else {
//						console.log(data);
					}
				});
			}
		});
	};
	
	function runManualReport(){
		
		ltService.runManualSummaryReport($scope.selectedReport.reportId, function(data) {
			$scope.showSummaryGrid = false;
			$scope.showManualReportButton = false;
			$scope.reportGenerationMsg = true;
			//$scope.reportGenerationMsgMessage = "Please wait manual report generation is in progress.";
			if ( data.success ) {
				$scope.selectedReport.status = data.message;
				if(checkRunTimeLessThanGivenHour(3,$scope.selectedReport.runTime)){
					if(checkRunTimeLessThanGivenMinute(1,$scope.selectedReport.runTime)){
						$scope.getLTChartForPdf(1,0);
					}else{
						$scope.getLTChartForPdf(0,0);
					}
				}else{
					$scope.getSummaryReport();
				}
				$scope.showSummaryGrid = true;
				$scope.showManualReportButton = false;
				$scope.reportGenerationMsg = false;
				$scope.disableManualReportButton = true;
			} else {
				$scope.showSummaryGrid = false;
				$scope.showManualReportButton = true;
				$scope.showManualReportButtonMessage = "Manual Summary report generation failed";
				$scope.reportGenerationMsg = false;
				$scope.disableManualReportButton = false;
				// TODO: for err msg
			}
		});
	}

	$scope.getLogReport = function() {
		$scope.logReports = [];
		ltService.getLogReport($scope.selectedReport.reportId, $scope.loadTestType, function(data) {
			if ( data.success ) {
				$scope.logReports = data.message;
			} else {
				// TODO: for err msg
			}
		});
	};

	$scope.getErrorReport = function() {
		$scope.errorReports = [];
		ltService.getErrorReport($scope.selectedReport.reportId, $scope.loadTestType, function(data) {
			if ( data.success ) {
				$scope.errorReports = data.message;
			} else {
				// TODO: for err msg
			}
		});
	};
	$scope.getSelectedReportDetails = function() {
//		$scope.loadSelectedTypeReport();
		$scope.masterSummaryReport = [];
		$scope.scriptSummaryReport = [];
		$scope.requestResponseData = [];
		$scope.containerResponseData = [];
		$scope.transactionResponseData = [];
		$scope.errorCountData = [];
		$scope.errorDescriptionData = [];
		$scope.showSummaryGrid = false;
		$scope.showManualReportButton = false;
		$scope.reportGenerationMsg = false;
		
		if($scope.loadTestType == 'APPEDO_LT'){
			var checkStatus = ['RUNNING','QUEUED'];
			
			ltService.getselectedReportGuid($scope.selectedReport.reportId, $scope.loadTestType, function(data) {
				if ( data.success ) {
					var resultData = data.message;
					if( resultData.guid != '' ) {
						$scope.selectedReport.guid=resultData.guid;
					} else {
						$scope.selectedReport.guid='0';
					}
				} else {
					$scope.selectedReport.guid='0';
				}
			});
			
			ltService.getRunSettings($scope, $scope.selectedReport.reportId, function(scriptData) {
			   	$scope.scriptData = scriptData.message;
			});
			
			// load default tab's data, (i.e.) "Summary" tab.
			$scope.loadSelectedTypeReport();
		}
	};

	$scope.saveHiddenParams = function() {
		// for redirect to report page, avoided to clear session storage
		bClearSessionValues = false;
	};
	
	$scope.openOrFocusWindow = function(oLink) {
		var oWindow = null, sTarget = "_appedo_report_"+oLink.selectedReport.reportName;
		if ( !window.popups )
			window.popups = {};
			
		if ( window.popups[sTarget] ) {
			oWindow = window.popups[sTarget];
			oWindow.close();
		}
		
		if ( !oWindow || oWindow.closed ) {
			oWindow = window.open(oLink.selectedReport.grafanaReportURL, sTarget);
			window.popups[sTarget] = oWindow;
		}
		
		oWindow.focus();
	};
	
	
	$scope.$on('$destroy', function() {
		clearTimeout(timerRunningScenario);
		
		if ( bClearSessionValues) {
			// destroy's session saved values, when page gets refreshed also sessionStorage doesn't destroy & controller destroy also not 
			sessionServices.destroy("runId");
			sessionServices.destroy("scenarioId");	
		}
	});
}]);

appedoApp.controller('addLTController', ['$scope', '$rootScope', '$uibModal', '$uibModalInstance', 'ltService', 'successMsgService', 'isFrom', 'moduleCardContent', 'ltScenarioData', 'openConfigureScenario', 'messageService',
	function($scope, $rootScope, $uibModal, $uibModalInstance,  ltService, successMsgService, isFrom, moduleCardContent, ltScenarioData, openConfigureScenario, messageService) {
		// form submitted false
		$scope.submitted = false;
			
		$scope.showProceed = true;
		$scope.moduleCardContent = moduleCardContent;
		
		$scope.mapScript = {};
		
		// true for Add
		var bFromAdd = (isFrom !== "fromEdit");
		
		if( bFromAdd ) {
			// add
			$scope.saveButton = "Save";
		} else {
			// edit
			$scope.saveButton = "Update";
		}
		function getLtScripts() {
			ltService.getLtScripts($scope, isFrom, isFrom === "fromEdit" ? ltScenarioData.scenario_id : '', function(data) {
				if ( bFromAdd ) {
					// from Add 
					$scope.availableScripts = data;
					$scope.selectedScripts = $scope.availableScripts;
				} else {
					// edit from
					
					$scope.availableScripts = data.message.script;
					//$scope.selectedScripts = $scope.availableScripts;
					$scope.mapScript.scenarioName = data.message.scenario_name;
					$scope.mapScript.scenarioId = data.message.scenario_id
					
					//$scope.scenarioDetails = data.message;
				}
			});	
		}
		getLtScripts();
		
		$scope.close = function() {
			$uibModalInstance.dismiss('cancel');
		};
		
		$scope.checkSelectedScripts = function() {
			for(var i = 0; i<$scope.availableScripts.length; i++) {
				if($scope.availableScripts[i].isSelected) {
					$scope.showProceed = false;
					break;
				}else{
					$scope.showProceed = true;
				}
			}
		};
		
		$scope.disableLTSaveButton = false;
		$scope.saveLtMapScripts = function () {
			$scope.submitted = true;
			var arySelectedScriptDetails = [], joSelectedScript = {};
			for(var i = 0; i < $scope.availableScripts.length; i++) {
				var joScript = $scope.availableScripts[i];
				if( joScript.isSelected ) {
					joSelectedScript = {
						script_id: joScript.script_id,
						scriptName: joScript.scriptName,
						settings: joScript.settings
					};
					arySelectedScriptDetails.push(joSelectedScript);
				}
			}
			
			/* Avoided, validation of must select a script
			if( arySelectedScriptDetails.length === 0) {
	 			messageService.showErrorMessage('Must select atleast a script.');
			} else*/
			if ( $scope.addLtScenario.$valid ) {
				$scope.disableLTSaveButton = true;
				// valid form
				ltService.saveLtScripts($scope, isFrom, arySelectedScriptDetails, function(data) {
					if( ! data.success ){
						// err
						$scope.disableLTSaveButton = false;
						messageService.showErrorMessage(data.errorMessage);
					} else {
						$rootScope.$emit('lt_card_layout');
						$scope.close();
						
						// opens configure scenario/lt run settings for the script window
						if ( openConfigureScenario ) {
							// add, opens configure scenario/mapped scripts for load test run 
							ltService.openConfigureScenario(isFrom, $scope.moduleCardContent, {scenario_id: data.scenario_id, scenarioName: data.scenarioName}, 'APPEDO_LT');
						}
						
					}
				});
			}
		};
	}
]);

appedoApp.controller('loadTestMonitorController', ['$scope', '$uibModal', '$uibModalInstance', 'ltService', 'successMsgService', 'selectedScenario', 'ngToast', '$rootScope', 'testTypeScript',
	  function($scope, $uibModal, $uibModalInstance,  ltService, successMsgService, selectedScenario, ngToast, $rootScope, testTypeScript) {
	  $scope.close = function() {
		  $uibModalInstance.dismiss('cancel');
	  };
// how testTypeScript comes from appedoApp.controller
//	  ltService.getRunAgentMapping($scope, selectedScenario, testTypeScript);
	  ltService.getRunAgentMapping($scope, selectedScenario);
	  
	  $scope.ltMonitors = {};
	  $scope.monitorSelect = {};
	  $scope.monitorSelect.startMonitor = 0;
	  $scope.monitorSelect.endMonitor = 0;
	  
	  $scope.agentLoadGenerator = function() {
		  var selectedMonitorIds = [];
		  for(var i = 0; i < $scope.ltMonitors.length; i = i + 1) {
				var monitorData = $scope.ltMonitors[i];
				for(var j=0; j < monitorData.agents.length; j=j+1){
					if(monitorData.agents[j].isSelected) {
						selectedMonitorIds.push(monitorData.agents[j].guid);
					}
				}
		  }
			  ltService.agentLoadGenerator($scope, selectedScenario, function(data) {
					$scope.agentLoadData = data.message;
					$scope.selectedMonitorIds = selectedMonitorIds;
					if(data.success==true){
						$rootScope.$on("close_lt_parent_popup", function(event){
						  	$uibModalInstance.dismiss('cancel');
						});
						var userAgentDetails = ltService.getUserAgentDetails();
						userAgentDetails.then(function(resp) {
							if(resp.success){
								$scope.userAgentDetails = resp.message;
								var modalInstance = $uibModal.open({
									templateUrl: 'common/views/load_test/lt_assign_load_generator.html',
									controller: 'assignLoadGeneratorController',
									size: 'lg',
									resolve: {
										selectedMonitorIds: function() {
											return $scope.selectedMonitorIds;
										}, 
										agentLoadData: function() {
											return $scope.agentLoadData;
										}, 
										selectedScenario: function() {
											return selectedScenario;
										},
										userAgent: function() {
											return $scope.userAgentDetails;
										},
										testType: function() {
											return testTypeScript;
										},
										startMonitor: function(){
											return $scope.monitorSelect.startMonitor;
										},
										endMonitor: function(){
											return $scope.monitorSelect.endMonitor;
										}
									}
								});
							}
						});
					} else {
						messageService.showErrorMessage(data.errorMessage);
					}
			  });
	  };
}]);

appedoApp.controller('assignLoadGeneratorController', ['$scope', '$uibModal', '$uibModalInstance', '$state', 'ltService', 'sessionServices', 'selectedMonitorIds', 'agentLoadData', 'selectedScenario', 'ngToast', '$rootScope', 'testType', 'userAgent','startMonitor','endMonitor', 'messageService', 
	function($scope, $uibModal, $uibModalInstance, $state,  ltService, sessionServices, selectedMonitorIds, agentLoadData, selectedScenario, ngToast, $rootScope, testType, userAgent, startMonitor, endMonitor, messageService) {
		$scope.close = function() {
			$uibModalInstance.dismiss('cancel');
		};
		$scope.regionData = agentLoadData;
		$scope.userAgents = userAgent;
		$scope.startMonitor = startMonitor;
		$scope.endMonitor = endMonitor;
		$scope.testType = testType;
		
		$scope.moduledata = {};
		
		$scope.disableRunBtn = false;
		
		$scope.runAgentLoadGenerator = function() {
			var distributions = [];
			var regions = [];
			var distribution = 0;

			$scope.disableRunBtn = true;
			
			angular.forEach($scope.regionData, function(region){
				if(region.showRegion == true) {
					var preIndex = region.region.indexOf("(")+1; 
					var postIndex = region.region.indexOf(")");
					var regionName = region.region.substring(preIndex, postIndex);
					if(parseInt(region.distribution)>0){
						distributions.push(parseInt(region.distribution));
						distribution = distribution + parseInt(region.distribution);
						if(regionName != ""){
							regions.push(regionName);
						}
					} else {
						$scope.regionsForm.$invalid;
						messageService.showWarningMessage('Distribution value shoule be greater than 0 for '+regionName);
						return 1; // break from forEach loop
					}
				}
			});
			var params = {
				maxUserCount: selectedScenario.virtual_users,
				//maxUserCount:5,
				guids: selectedMonitorIds.join(),
				testType: selectedScenario.loadTestType,
				scenarioId: selectedScenario.scenario_id,
				//scenarioId: 24,
				scenarioName: selectedScenario.scenarioName,
				//scenarioName: 'QAMDemo',
				reportName: $scope.moduledata.moduleName,
				userAgent: $scope.moduledata.userAgent != undefined ? $scope.moduledata.userAgent.user_agent_value : 'Recorded Agent',
				runType: selectedScenario.runType,
				//runType: 'DURATION',
				regions: regions.join(),
				distributions: distributions.join(),
				startMonitor: startMonitor,
				endMonitor: endMonitor
			};
			
			if($scope.regionsForm.$valid) {
				if( regions.length == 0 ){
					messageService.showWarningMessage('Select atleast one Region.');
				} else if(distribution < 100 || distribution > 100){
					messageService.showWarningMessage('Sum of distribution is 100% only.');
				} else if(selectedScenario.maxusers < regions.length){
					messageService.showWarningMessage('Selected region should not be greater than max user count.');
				} else {
					if( testType === 'APPEDO_LT' ) {
						// Appedo LT
						ltService.runScenario($scope, params, function(data) { 
							$scope.disableRunBtn = false;
							//successMsgService.showSuccessOrErrorMsg(data);
							if ( data.success == true ) {
								messageService.showSuccessMessage(data.message);
								$rootScope.$emit('close_lt_parent_popup');
								$uibModalInstance.dismiss('cancel');								
							} else {
								messageService.showErrorMessage(data.errorMessage)
							}
						});
					} else {
						// Jmeter
						ltService.runJmeterScenario($scope, params, function(data) {
							$scope.disableRunBtn = false;
							//successMsgService.showSuccessOrErrorMsg(data);
							if(data.success == true){
								$rootScope.$emit('close_lt_parent_popup');
								$uibModalInstance.dismiss('cancel');
								messageService.showSuccessMessage(data.message);
							} else {
								messageService.showSuccessMessage(data.errorMessage);
							}
						});
					}
				}
			}
		};
}]);

appedoApp.controller('ltRunConfigureScript', ['$scope', '$uibModal', '$uibModalInstance', 'ltService', 'successMsgService', 'isFrom', 'moduleCardContent', 'ltScenarioData', 'ngToast', 'testTypeScript', '$rootScope',
	function($scope, $uibModal, $uibModalInstance,  ltService, successMsgService, isFrom, moduleCardContent, ltScenarioData, ngToast, testTypeScript, $rootScope) {
		$scope.moduleCardContent = moduleCardContent;
		$scope.ltRunSettingForm = {};
		// default parallel connection `6`
		var nDefaultParallelConnections = 6;
		
		$scope.scenario = ltScenarioData.col_2.var1;
		
		$scope.showBackButton = false;
		
		$scope.loadtestValue = testTypeScript;
		
		// true for Add
		var bFromAdd = (isFrom !== "fromEdit");
		
		// form Add, to show back button 
		if ( bFromAdd ) {
			$scope.showBackButton = true;
		}
		
		if(testTypeScript == 'JMETER'){
			$scope.maxUserCount = 1000;
			$scope.maxiteration = 1000;
			$scope.maxdurationHrs = 5 ;
			$scope.maxdurationMns = 59;
		} else {
			$scope.maxUserCount = '';
			$scope.maxiteration = '';
			$scope.maxdurationHrs = '' ;
			$scope.maxdurationMns = '';
		}
		
		$scope.close = function() {
			$uibModalInstance.dismiss('cancel');
		};
		
		$scope.goBack = function() {
			$scope.close();
			
			// opens edit scenario/map scripts
			ltService.openAddorEditScenario('fromEdit', $scope.moduleCardContent, ltScenarioData, bFromAdd);
		};
		
		
		function getScenarioSettings() {
			ltService.getScenarioSettings($scope, ltScenarioData.scenario_id, testTypeScript, function(scriptData) {
				$scope.scriptData = scriptData.message;
				
				// TODO: ASK, correction for below sets & then cleared
				$scope.ltRunSettingForm.script = $scope.scriptData[0];
				//$scope.ltRunSettingForms = {};
				
				
				$scope.$watch('ltRunSettingForm.script', function() {
					if ($scope.ltRunSettingForm.script != undefined) {
						//if ($scope.ltRunSettingForm.script.script_name != undefined) {
							$scope.scriptConfigData = $scope.ltRunSettingForm.script.scenario_settings;
							var aryScriptDurationTime = $scope.scriptConfigData.durationtime.split(";");
							var aryScriptIncrementTime = $scope.scriptConfigData.incrementtime.split(";");
							
							$scope.ltRunSettingForm.clearBrowserCache = $scope.scriptConfigData.browsercache;
							$scope.ltRunSettingForm.startUserCount = parseInt($scope.scriptConfigData.startuser);
							$scope.ltRunSettingForm.maxUserCount = parseInt($scope.scriptConfigData.maxuser);
							$scope.ltRunSettingForm.durationHrs = parseInt(aryScriptDurationTime[0]);
							$scope.ltRunSettingForm.durationMins = parseInt(aryScriptDurationTime[1]);
							$scope.ltRunSettingForm.durationSecs = parseInt(aryScriptDurationTime[2]);
							$scope.ltRunSettingForm.iterationCount = parseInt($scope.scriptConfigData.iterations);
							$scope.ltRunSettingForm.increamnetUser = parseInt($scope.scriptConfigData.incrementuser);
							$scope.ltRunSettingForm.forEveryHrs = parseInt(aryScriptIncrementTime[0]);
							$scope.ltRunSettingForm.forEveryMins = parseInt(aryScriptIncrementTime[1]);
							$scope.ltRunSettingForm.forEverySecs = parseInt(aryScriptIncrementTime[2]);
							$scope.ltRunSettingForm.iterationDuration = parseInt($scope.scriptConfigData.type);
							$scope.ltRunSettingForm.parallelconnections = parseInt($scope.scriptConfigData.parallelconnections) || nDefaultParallelConnections;
							if($scope.ltRunSettingForm.iterationDuration == '1') {
								$scope.ltRunSettingForm.iterationDuration="iteration";
							} else {
								$scope.ltRunSettingForm.iterationDuration="duration";
							}
						//}
					}
				});
			});
		}
		getScenarioSettings();
		
		
		$scope.applyToAll = function() {
			if($scope.ltRunSettingConfigForm.$valid) {
				var scriptIds = [];
				var scriptNames = [];
				script_id = $scope.scriptData.script_id;
				script_name = $scope.scriptData.script_name;
				angular.forEach($scope.scriptData, function(script){
					scriptIds.push(script.script_id);
					scriptNames.push(script.script_name);
				});
				
				ltService.updateScenarioSettings($scope, scriptIds, ltScenarioData, scriptNames, $scope.scriptConfigData, testTypeScript, function(data){
					successMsgService.showSuccessOrErrorMsg(data);
					if(data.success == true){
						$rootScope.$emit('lt_card_layout');
						$scope.close();
					}
				});
			}
		};
		
		$scope.apply = function() {
			if($scope.ltRunSettingConfigForm.$valid) {
				var scriptIds = [];
				var scriptNames = [];
				scriptIds.push($scope.ltRunSettingForm.script.script_id);
				scriptNames.push($scope.ltRunSettingForm.script.script_name);
				ltService.updateScenarioSettings($scope, scriptIds, ltScenarioData, scriptNames, $scope.scriptConfigData, testTypeScript, function(data){
					successMsgService.showSuccessOrErrorMsg(data);
					if(data.success == true){
						$rootScope.$emit('lt_card_layout');
						$scope.close();
					}
				});
			}
		};
	}
]);

// Add/Edit summary report notes controller
appedoApp.controller('addEditSummaryReportNotesController', ['$scope', '$uibModalInstance', 'ltFactory', 'ltService', 'isFrom', 'selectedSummaryCategory', 'selectedReport', 'selectedScript', 'testTypeScript', 'messageService',
	function($scope, $uibModalInstance, ltFactory, ltService, isFrom, selectedSummaryCategory, selectedReport, selectedScript, testTypeScript, messageService) {
		$scope.selectedSummaryCategory = selectedSummaryCategory;

		var joRespCategoryNote = {}, nScriptId = null;
		
		// Note: in `$scope.selectedReport`, `runId` is saved in the key name of `reportId`
		$scope.selectedReport = selectedReport;
		$scope.selectedScript = selectedScript;
		if ( $scope.selectedSummaryCategory.hasScriptWiseNote ) {
			nScriptId = $scope.selectedScript.scriptId;
		}
		
		$scope.formCategoryNote = {};
		$scope.formCategoryNote.disableSaveBtn = false;
		
		$scope.close = function(bParam) {
			$uibModalInstance.close(bParam);
		};
		
		$scope.cancel = function() {
			$uibModalInstance.dismiss('cancel');
		};
		
		// gets runid's particular category's notes
		function getSummaryReportCategoryNote() {
			ltService.getSummaryReportCategoryNote($scope.selectedReport.reportId, $scope.selectedSummaryCategory.value, nScriptId, function(data) {
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else if ( data.message !== undefined ) {
					joRespCategoryNote = data.message;
					$scope.formCategoryNote.notes = joRespCategoryNote.notes;
				}
			});
		}
		getSummaryReportCategoryNote();
		
		// inserts/update notes for the run's category OR run's category script's
		$scope.saveNotes = function() {
			var nNoteId = joRespCategoryNote.id !== undefined  ? joRespCategoryNote.id : null;
			$scope.formCategoryNote.disableSaveBtn = true;
			
			ltService.saveSummaryReportCategoryNote($scope.selectedSummaryCategory, $scope.selectedReport, nScriptId, nNoteId, $scope.formCategoryNote.notes, function(data) {
				if ( ! data.success ) {
					// err
					messageService.showErrorMessage(data.errorMessage);
				} else {
					messageService.showSuccessMessage(data.message);
					
					// `true` returned on close, snice to reload notes 
					$scope.close(true);
					$scope.formCategoryNote.disableSaveBtn = false;
				}
			});
		};
	}
]);


function getThroughputData(data){
	var throughputJSONArray = [];
	var throughputJSONObj={};
	var checkKey = ["T", "V", "Hour counts","Minute counts","Second counts","Bps","Bytes"]; 
	if(data.length>0){
		for(var i = 0; i < data.length; i = i + 1) {
			var chartData = data[i];
			chartData["V"] =  chartData["Bps"];
			throughputJSONObj={};
			for (var key in chartData) {
				if(checkKey.indexOf(key)>=0){
					throughputJSONObj[key]=chartData[key];
				}
			}
			throughputJSONArray.push(throughputJSONObj);
		}
	}
	return throughputJSONArray;
}
function getHitCountData(data){
	var hitCountJSONArray = [];
	var hitCountJSONObj={};
	var checkKey = ["T", "V", "Total Hits", "Hits/Sec"]; 
	if(data.length>0){
		for(var i = 0; i < data.length; i = i + 1) {
			var chartData = data[i];
			chartData["V"] = chartData["Total Hits"];
			hitCountJSONObj={};
			for (var key in chartData) {
				if(checkKey.indexOf(key)>=0){
					hitCountJSONObj[key]=chartData[key];
				}
			}
			hitCountJSONArray.push(hitCountJSONObj);
		}
	}
	return hitCountJSONArray;
}
function getRequestResponseData(data){
	var requestResponseJSONArray = [];
	var requestResponseJSONObj={};
	var checkKey = ["T", "V", "Hour counts","Minute counts","Second counts","Min","Avg","Max"]; 
	if(data.length>0){
		for(var i = 0; i < data.length; i = i + 1) {
			var chartData = data[i];
			chartData["V"] = chartData["Avg"];
			requestResponseJSONObj={};
			for (var key in chartData) {
				if(checkKey.indexOf(key)>=0){
					requestResponseJSONObj[key]=chartData[key];
				}
			}
			requestResponseJSONArray.push(requestResponseJSONObj);
		}
	}
	return requestResponseJSONArray;
}
appedoApp.controller('serviceMapController', ['$scope', '$rootScope', 'serviceMapService','sessionServices', '$uibModal', '$timeout', 'messageService','apmModulesService', function( $scope, $rootScope, serviceMapService, sessionServices, $uibModal, $timeout, messageService,apmModulesService) {
	$scope.showServiceMapSum = false;
	$scope.showServiceMapRum = false;
	$scope.showServiceMapApp = false;
	$scope.showServiceMapSvr = false;
	$scope.showServiceMapDb = false;

    $scope.showDashboard =true;
    $scope.showPanel = false;
    // if no service mapped to show message
    $scope.showEmptyServiceMapMsg = false;
    
	$scope.serviceMap = {};
	$scope.serviceMapRadio = {};
	$scope.serviceMapRadio.type = "DASHBOARD";
	
	// selected service Map's mapped_service/mapped_modules
	$scope.serviceMapMappedService = {};
	   
	//var application, server, database, sum, rum;
	
	$scope.serviceMaps = [];
	
	var resultDonutChartData;
	resultDonutChartData = apmModulesService.getDonutChartdata("APPLICATION");
    resultDonutChartData.then(function(resp) {
    	if(resp!=undefined){
 		   if(resp.success){
 		    	$scope.appDonutData=resp.message;
 		   }else{
 			    $scope.appDonutData=JSON.parse(sessionServices.get("noRecordForDonut"));
 		   }
 	   	}
    });
	/*
	 * Avoided ServiceMap(s) with each mapped_services in response
	$scope.getServiceMapData = function() {
		var resultSserviceMap;
	    resultSserviceMap = serviceMapService.getServiceMapData();
	    resultSserviceMap.then(function(resp) {
	    	//console.log(resp.message);
	    	if(resp.success){
	    	    $scope.showEmptyServiceMapMsg = true;
	    	    
	        	$scope.serviceMaps = resp.message;
	        	$scope.serviceMap.selectedService = $scope.serviceMaps[0];

	        	// 
	        	if ( $scope.serviceMap.selectedService != undefined) {
	            	$scope.loadModules();
	        	}
	    	}
	    });
	};
	//$scope.getServiceMapData();
	//for refresh the configure serviceMap
	var serviceMapData = $rootScope.$on("loadServiceMapData", $scope.getServiceMapData);
    $scope.$on('$destroy', serviceMapData);
    */
    
	$scope.getUserServiceMaps = function() {
		serviceMapService.getUserServiceMaps($scope, function(resp) {
			if( ! resp.success ){
    			// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.showEmptyServiceMapMsg = true;
				
				$scope.serviceMaps = resp.message;
/*				
				if($scope.serviceMaps.length == 1) {
					$scope.serviceMap.selectedService = $scope.serviceMaps[0];
					$scope.getServiceMapMappedModules();
				}*/
				// before they avoided the default selection of first service map
				if(serviceMapService.myRootVar.serviceMapId == undefined){
						$scope.serviceMap.selectedService = $scope.serviceMaps[0];
				}else{
						for(var i = 0; i<$scope.serviceMaps.length; i++){
							if($scope.serviceMaps[i].serviceMapId == serviceMapService.myRootVar.serviceMapId){
								$scope.serviceMap.selectedService = $scope.serviceMaps[i];
								break;
							}
						}	
				}
				
	        	if ( $scope.serviceMap.selectedService != undefined) {
	        		$scope.getServiceMapMappedModules();
	        	}
	        	
    		}
    	});
	};
	
    // gets user ServiceMaps with mapped modules count
    $scope.getserviceMapCard = function() {
		serviceMapService.getServiceMapCardData($scope, function(resp){
			$scope.serviceMapCardData = resp.message;
			$scope.showCardEmptyMsg = false;
			if( $scope.serviceMapCardData.length > 0 ){
				$scope.showCardEmptyMsg = false;
			}else{
				$scope.showCardEmptyMsg = true;
			}
		});
	};
	//$scope.getserviceMapCard();
    
    
	// loads selected panel 
	$scope.loadSelectedTypePanel = function() {
    	
    	if( $scope.serviceMapRadio.type === 'DASHBOARD' ) {
    		// loads ServiceMap's dashboard dropdown
    		
    		// added CI trigger for ServiceMap Dashboard Panel
    		$scope.testCITrigger = function() {
    			Appedo_CI.triggerEvent('ServiceMap Dashboard Page', 'pageOpen', 
    			{
    					page_open_date_time : new Date()
    			});
    		};
    		$scope.testCITrigger();
    		
    		//$scope.getServiceMapData();
    		$scope.getUserServiceMaps();
    	} else if ( $scope.serviceMapRadio.type === 'PANEL' ) {
        	// clears Dashboard's dropdown selection & selected modules
        	clearsSelectionDashboardMap();
        	
        	// added CI trigger for ServiceMap CardLayout Panel
    		$scope.testCITrigger = function() {
    			Appedo_CI.triggerEvent('ServiceMap Card Layout', 'pageOpen', 
    			{
    					page_open_date_time : new Date()
    			});
    		};
    		$scope.testCITrigger();
        	
    		// loads UserServiceMaps with mapped modules count card data
    		$scope.getserviceMapCard();
    	}
    };
    $scope.loadSelectedTypePanel();

	var serviceMapcard = $rootScope.$on("loadServiceMapSelectedTypePanel", $scope.loadSelectedTypePanel);
    $scope.$on('$destroy', serviceMapcard);
    
	$scope.openAddModuleType = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
	
	// gets particular ServiceMap's mapped service
	$scope.getServiceMapMappedModules = function() {
		serviceMapService.getServiceMapMappedModules($scope, $scope.serviceMap.selectedService.serviceMapId, function(data) {

    		if( ! data.success ){
    			// err
    			messageService.showErrorMessage(data.errorMessage);
    		} else {
    			var joRespMsg = data.message;
    			
    			$scope.serviceMapMappedService = joRespMsg.mapped_service;
    			
    			// 
    			$scope.loadModules($scope.serviceMapMappedService);
    		}
		});
	};
	
	$scope.loadModules = function(moduleMappedService) {
		$timeout(function() {
			$scope.$broadcast('loadSelectedServiceMap', moduleMappedService);
		}, 1000);
	};
	
	// clears dropdown selection & selected modules
	function clearsSelectionDashboardMap() {
		// clear dropdown selection
		$scope.serviceMap = {};
		
		// clears the SELECTION's service map's modules
		$scope.serviceMapMappedService = {};
	}
	
	/* Avoided ServiceMap(s) with each mapped_services in response
	$scope.loadModules = function() {
		$timeout(function() {
			$scope.$broadcast('loadSelectedServiceMap', $scope.serviceMap.selectedService.mapped_service);
		}, 1000);
	};*/
}]);


appedoApp.controller('serviceMapAPMAppController', ['$scope', '$attrs', '$state', 'apmModulesService', 'apmModulesFactory', 'd3Service', 'sessionServices', function($scope, $attrs, $state, apmModulesService, apmModulesFactory, d3Service, sessionServices) {
	$scope.apmChartdata = [];
    var timerChartsLoading;
    $scope.inDashBoardStatus = true;
    $scope.dotsize = 1.5;
    $scope.linewidth = 2;
    $scope.linkstatus = "false";
    $scope.userApplicationCounterModules = [];
    $scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[0];
    $scope.yaxis_category = 'Avg';
	
	/*var resultUserApplicationCounterModules = JSON.parse(sessionServices.get("service_map_apm_app"));
    if(resultUserApplicationCounterModules.length>0){
    	$scope.userApplicationCounterModules = resultUserApplicationCounterModules;
    	$scope.sectionSelectApp = $scope.userApplicationCounterModules[0];
    	getModuleCountersDataCall();
    };*/
    //setMapAndLoad(resultUserApplicationCounterModules);
    /*
    //
    $scope.$watch('userApplicationCounterModules', function(newVal) {
    	console.info('CHILD $scope.serviceMap.selectedService');
    	console.info(newVal);
    	setMapAndLoad(newVal);
    });*/
    $scope.setMapAndLoad = function(aryModules) {
    	$scope.userApplicationCounterModules = aryModules;
    	if(aryModules.length>0){
        	$scope.sectionSelectApp = $scope.userApplicationCounterModules[0];
        	getModuleCountersDataCall();
        };
    };
    $scope.$on("loadSelectedServiceMap", function(event, joMappedService) {
    	$scope.setMapAndLoad(joMappedService.APPLICATION || []);
    });
    
   
    $scope.getModuleCountersData = function() {
    	getModuleCountersDataCall();
    };
    
    function getModuleCountersDataCall(){
    	var resultPrimaryCountersChartdata = apmModulesService.getPrimaryCountersChartdata($scope.sectionSelectApp.guid);
    	resultPrimaryCountersChartdata.then(function(resp) {
//        	$scope.applicationPrimaryCountersChartdata = resp.message;
    		var joRespMsg = resp.message;
        	$scope.apmChartdata = joRespMsg.chartdata;
        	
//        	for(var i = 0; i < $scope.applicationPrimaryCountersChartdata.length; i = i + 1) {
//        		var joCounter = $scope.applicationPrimaryCountersChartdata[i];
        	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
        		var joCounter = $scope.apmChartdata[i];
        		joCounter.guid = joRespMsg.guid;
        		// joCounter.moduleCode = moduleCode;
        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
				// commented, since tried in directive show hour interval in x-axis, instead of min/max
        		//joCounter.counterData = apmModulesFactory.appendZeroAtFirst(joCounter.counterData);

        		/* DON'T delete, break counter sets, commented 
        		// to set counter lastvalue as primary counter to display in UI
        		var aryCounterSet = joCounter.counterData[joCounter.counterData.length - 1];
        		*/
        		
        		// based on new correction, break counter sets is not there 
        		var aryCounterSet = joCounter.counterData;
        		
        		joCounter.counterLastValue = aryCounterSet[aryCounterSet.length - 1].V;

        	}
        });
    	
    	var resultSecondaryCounters = apmModulesService.getSecondaryCountersData('APPLICATION', $scope.sectionSelectApp.guid);
    	resultSecondaryCounters.then(function(resp) {
    		$scope.apmAppSecSumData = resp;
    		$scope.getAppSecondaryData();
    	});
    	
		clearInterval(timerChartsLoading);
		timerChartsLoading = setInterval(getCountersNewData, sessionServices.get("graphRefresh"));
    }
    
    var timerAppSecondaryData;
	$scope.getAppSecondaryData = function() {
    	clearTimeout(timerAppSecondaryData);
    	var strCounterIds='';
    	for (var i = 0; i < $scope.apmAppSecSumData.length; i = i + 1 ) {
			if ( i != 0 ) strCounterIds = strCounterIds + ',';
			var apmAppSecSumDataObj = $scope.apmAppSecSumData[i];
			strCounterIds = strCounterIds + apmAppSecSumDataObj.counter_id;
    	}
    	if(strCounterIds!=""){
        	var resultSecondaryCounters = apmModulesService.getSecondaryCountersValues('APPLICATION', $scope.sectionSelectApp.guid, strCounterIds);
        	resultSecondaryCounters.then(function(resp) {
        		if(resp!=undefined){
            		for (var i = 0; i < $scope.apmAppSecSumData.length; i = i + 1 ) {
    					var data = resp[i];
    					var apmAppSecSumDataObj = $scope.apmAppSecSumData[i];
    					if(data!=undefined){
    						apmAppSecSumDataObj.value = data.value;
    					}else{
    						apmAppSecSumDataObj.value = "NA";
    					}
    		 		}        			
        		}
        	});
    	}
    	timerAppSecondaryData = setTimeout($scope.getAppSecondaryData, sessionServices.get("textRefresh"));
    };
    
    // getsCountersNewData ToPush
    function getCountersNewData() {
//    	for(var i = 0; i < $scope.applicationPrimaryCountersChartdata.length; i = i + 1) {
//    		var joCounterData = $scope.applicationPrimaryCountersChartdata[i];
    	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
    		var joCounterData = $scope.apmChartdata[i];
    		
    		getPushData($scope.sectionSelectApp.guid, joCounterData.counterId, joCounterData.maxTimeStamp);
    	}
    }
    
    // gets counterdata
    function getPushData(guid, counter_id, maxTimeStamp) {

		var resultCountersData =  apmModulesService.getModuleCountersChartdata(guid, counter_id, maxTimeStamp, null);
		resultCountersData.then(function(resp) {
        	var joResp = resp.message;

			var joRespCountersData = resp.message;//.flotChartData;
			var joRespCountersChartData = joRespCountersData.chartdata;
			var joRespCountersException = joRespCountersData.countersException;
			var strRespAgentException = joRespCountersData.agentException || '';

			// To gets length of the JSON object
			var aryRespCounterIds = Object.keys(joRespCountersChartData);
			var nRespCounters = aryRespCounterIds.length;


//			for(var i = 0; i < $scope.applicationPrimaryCountersChartdata.length; i = i + 1) {
//				var joCounterData = $scope.applicationPrimaryCountersChartdata[i];
			for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
				var joCounterData = $scope.apmChartdata[i];

				// To set chart's maxTimeStamp and chartData for the response countername
				if( nRespCounters == 1 ) {
					// for single line chart 
					var respCounterId = aryRespCounterIds[0];
					if(joCounterData.counterId === respCounterId) {
						joCounterData.maxTimeStamp = joRespCountersData['max_recieved_on'];
						var aryChartData = joCounterData.counterData || [];
						var aryRespChartDataArrayInArray = joRespCountersChartData[respCounterId];
						var aryRespCounterChartData = joRespCountersChartData[respCounterId];

						var nRespCounterSetsLength = 0;

						if ( aryRespCounterChartData.length > 0 ) {


			        		/* DON'T delete, break counter sets, commented 
							// slice
							nRespCounterSetsLength = apmModulesFactory.getCounterSetsLength(aryRespCounterChartData);
							//console.info('nRespCounterSetsLength: '+nRespCounterSetsLength);
							aryChartData = apmModulesFactory.sliceCounterSets(aryChartData, nRespCounterSetsLength);

							// push
							aryChartData = apmModulesFactory.pushCounterSets(aryChartData, aryRespCounterChartData);

			        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
							//aryChartData = apmModulesFactory.appendZeroAtFirst(aryChartData);
							*/

							// based on new correction, Note: maxTS is not used, all response data is sets, 
							aryChartData = aryRespCounterChartData;
							
							
							joCounterData.counterData = aryChartData;

			        		/* DON'T delete, break counter sets, commented 
			        		// to set counter lastvalue as primary counter to display in UI
			        		var aryCounterSet = joCounter.counterData[joCounter.counterData.length - 1];
			        		*/
			        		// based on new correction, break counter sets is not there 
			        		var aryLastCounterSet = aryChartData;
			        		
							joCounterData.counterLastValue = aryLastCounterSet[aryLastCounterSet.length - 1].V;

						}

						break;
					}
				}
			}

        });
    }
    
	$scope.$on('$destroy', function() {
		clearInterval(timerChartsLoading);
		clearTimeout(timerAppSecondaryData);
    });
}]);

appedoApp.controller('serviceMapAPMSvrController', ['$scope', '$attrs', '$state', 'apmModulesService', 'apmModulesFactory', 'd3Service', 'sessionServices', function($scope, $attrs, $state, apmModulesService, apmModulesFactory, d3Service, sessionServices) {
	$scope.apmChartdata = [];
    var timerChartsLoading;
    $scope.inDashBoardStatus = true;
    $scope.dotsize = 1.5;
    $scope.linewidth = 2;
    $scope.linkstatus = "false";
	$scope.userServerCounterModules = [];
    $scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[0];
    $scope.yaxis_category = 'Avg';
    
    /*var resultUserServerCounterModules = JSON.parse(sessionServices.get("service_map_apm_svr"));
    if(resultUserServerCounterModules.length>0){
    	$scope.userServerCounterModules = resultUserServerCounterModules;
    	$scope.sectionSelectSvr = $scope.userServerCounterModules[0];
    	getModuleCountersDataCall();
    };*/
    

    $scope.setMapAndLoad = function(aryModules) {
    	$scope.userServerCounterModules = aryModules;
    	if(aryModules.length>0){
        	$scope.sectionSelectSvr = $scope.userServerCounterModules[0];
        	getModuleCountersDataCall();
        };
    };
    $scope.$on("loadSelectedServiceMap", function(event, joMappedService) {
    	$scope.setMapAndLoad(joMappedService.SERVER || []);
    });
    
   
    $scope.getModuleCountersData = function() {
    	getModuleCountersDataCall();
    };
    
    function getModuleCountersDataCall(){
    	
    	var resultPrimaryCountersChartdata = apmModulesService.getPrimaryCountersChartdata($scope.sectionSelectSvr.guid);
    	resultPrimaryCountersChartdata.then(function(resp) {
//        	$scope.serverPrimaryCountersChartdata = resp.message;
    		var joRespMsg = resp.message;
        	$scope.apmChartdata = joRespMsg.chartdata;
        	
        	// last value for PrimaryCounter
//        	for(var i = 0; i < $scope.serverPrimaryCountersChartdata.length; i = i + 1) {
//        		var joCounter = $scope.serverPrimaryCountersChartdata[i];
        	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
        		var joCounter = $scope.apmChartdata[i];
        		joCounter.guid = joRespMsg.guid;
        		// joCounter.moduleCode = moduleCode;
        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
				// commented, since tried in directive show hour interval in x-axis, instead of min/max
        		//joCounter.counterData = apmModulesFactory.appendZeroAtFirst(joCounter.counterData);


        		/* DON'T delete, break counter sets, commented 
        		// to set counter lastvalue as primary counter to display in UI
        		var aryCounterSet = joCounter.counterData[joCounter.counterData.length - 1];
        		*/
        		
        		// based on new correction, break counter sets is not there 
        		var aryCounterSet = joCounter.counterData;
        		
        		joCounter.counterLastValue = aryCounterSet[aryCounterSet.length - 1].V;
        	}
        });
        
//    	 get secondary data
    	var resultSecondaryCounters = apmModulesService.getSecondaryCountersData('SERVER', $scope.sectionSelectSvr.guid);
    	resultSecondaryCounters.then(function(resp) {
    		$scope.apmSvrSecSumData = resp;
        	$scope.getSvrSecondaryData();
    	});
    	
    	
    	// counter's new data are added into jo as `pushdata` per minute
		// loads for pushdata
		clearInterval(timerChartsLoading);
		timerChartsLoading = setInterval(getCountersNewData, sessionServices.get("graphRefresh"));
    };
    
    var timerSvrSecondaryData;
	$scope.getSvrSecondaryData = function() {
    	clearTimeout(timerSvrSecondaryData);
    	var strCounterIds='';
    	for (var i = 0; i < $scope.apmSvrSecSumData.length; i = i + 1 ) {
			if ( i != 0 ) strCounterIds = strCounterIds + ',';
			var apmSvrSecSumDataObj = $scope.apmSvrSecSumData[i];
			strCounterIds = strCounterIds + apmSvrSecSumDataObj.counter_id;
    	}
    	if(strCounterIds!=""){
        	var resultSecondaryCounters = apmModulesService.getSecondaryCountersValues('SERVER', $scope.sectionSelectSvr.guid,strCounterIds);
        	resultSecondaryCounters.then(function(resp) {
        		if(resp!=undefined){
            		for (var i = 0; i < $scope.apmSvrSecSumData.length; i = i + 1 ) {
    					var data = resp[i];
    					var apmSvrSecSumDataObj = $scope.apmSvrSecSumData[i];
    					if(data!=undefined){
    						apmSvrSecSumDataObj.value = data.value;
    					}else{
    						apmSvrSecSumDataObj.value = "NA";
    					}
    		 		}        			
        		}
        	});
    	}
    	timerSvrSecondaryData = setTimeout($scope.getSvrSecondaryData, sessionServices.get("textRefresh"));
    };


    // getsCountersNewData ToPush
    function getCountersNewData() {
//    	for(var i = 0; i < $scope.serverPrimaryCountersChartdata.length; i = i + 1) {
//    		var joCounterData = $scope.serverPrimaryCountersChartdata[i];
    	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
    		var joCounterData = $scope.apmChartdata[i];
    		
    		//console.info(joCounterData);
    		getPushData($scope.sectionSelectSvr.guid, joCounterData.counterId, joCounterData.maxTimeStamp);
    	}
    }
    

    // gets counterdata
    function getPushData(guid, counter_id, maxTimeStamp) {

		var resultCountersData =  apmModulesService.getModuleCountersChartdata(guid, counter_id, maxTimeStamp, null);
		resultCountersData.then(function(resp) {
        	var joResp = resp.message;

			var joRespCountersData = resp.message;//.flotChartData;
			var joRespCountersChartData = joRespCountersData.chartdata;
			var joRespCountersException = joRespCountersData.countersException;
			var strRespAgentException = joRespCountersData.agentException || '';

			// To gets length of the JSON object
			var aryRespCounterIds = Object.keys(joRespCountersChartData);
			var nRespCounters = aryRespCounterIds.length;
			

			
//			for(var i = 0; i < $scope.serverPrimaryCountersChartdata.length; i = i + 1) {
//				var joCounterData = $scope.serverPrimaryCountersChartdata[i];
			for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
				var joCounterData = $scope.apmChartdata[i];
				

				// To set chart's maxTimeStamp and chartData for the response countername
				if( nRespCounters == 1 ) {
					// for single line chart 
					var respCounterId = aryRespCounterIds[0];
					if(joCounterData.counterId === respCounterId) {
						joCounterData.maxTimeStamp = joRespCountersData['max_recieved_on'];
						var aryChartData = joCounterData.counterData || [];
						var aryRespCounterChartData = joRespCountersChartData[respCounterId];

						var nRespCounterSetsLength = 0;

						if ( aryRespCounterChartData.length > 0 ) {


			        		/* DON'T delete, break counter sets, commented 
							// slice
							nRespCounterSetsLength = apmModulesFactory.getCounterSetsLength(aryRespCounterChartData);
							//console.info('nRespCounterSetsLength: '+nRespCounterSetsLength);
							aryChartData = apmModulesFactory.sliceCounterSets(aryChartData, nRespCounterSetsLength);

							// push
							aryChartData = apmModulesFactory.pushCounterSets(aryChartData, aryRespCounterChartData);

			        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
							//aryChartData = apmModulesFactory.appendZeroAtFirst(aryChartData);
							*/

							// based on new correction, Note: maxTS is not used, all response data is sets, 
							aryChartData = aryRespCounterChartData;
							
							
							joCounterData.counterData = aryChartData;

			        		/* DON'T delete, break counter sets, commented 
			        		// to set counter lastvalue as primary counter to display in UI
			        		var aryCounterSet = joCounter.counterData[joCounter.counterData.length - 1];
			        		*/
			        		// based on new correction, break counter sets is not there 
			        		var aryLastCounterSet = aryChartData;
			        		
							joCounterData.counterLastValue = aryLastCounterSet[aryLastCounterSet.length - 1].V;

						}
						
						break;
					}
				}
			}

        });
    }
    
	$scope.$on('$destroy', function() {
		clearInterval(timerChartsLoading);
		clearTimeout(timerSvrSecondaryData);
    });
	

}]);

appedoApp.controller('serviceMapAPMDbController', ['$scope', '$attrs','$state', 'apmModulesService', 'apmModulesFactory', 'd3Service', 'sessionServices', '$timeout', function($scope, $attrs, $state, apmModulesService, apmModulesFactory, d3Service, sessionServices, $timeout) {
	$scope.apmChartdata = [];
    var timerChartsLoading;
    $scope.inDashBoardStatus = true;
    $scope.dotsize = 1.5;
    $scope.linewidth = 2;
    $scope.linkstatus = "false";
    $scope.userDatabaseCounterModules = [];
    $scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[0];
    $scope.yaxis_category = 'Avg';
    /*var resultUserDatabaseCounterModules = JSON.parse(sessionServices.get("service_map_apm_db"));
    if(resultUserDatabaseCounterModules.length>0){
    	$scope.userDatabaseCounterModules = resultUserDatabaseCounterModules;
    	$scope.sectionSelectDb = $scope.userDatabaseCounterModules[0];
    	getModuleCountersDataCall();
    };*/

    $scope.setMapAndLoad = function(aryModules) {
    	$scope.userDatabaseCounterModules = aryModules;
    	if(aryModules.length>0){
        	$scope.sectionSelectDb = $scope.userDatabaseCounterModules[0];
        	getModuleCountersDataCall();
        };
    };
    $scope.$on("loadSelectedServiceMap", function(event, joMappedService) {
    	$scope.setMapAndLoad(joMappedService.DATABASE || []);
    });
    
    $scope.getModuleCountersData = function() {
    	getModuleCountersDataCall();
    };
    
    function getModuleCountersDataCall(){
    	var resultPrimaryCountersChartdata = apmModulesService.getPrimaryCountersChartdata($scope.sectionSelectDb.guid);
    	resultPrimaryCountersChartdata.then(function(resp) {
//        	$scope.databasePrimaryCountersChartdata = resp.message;
    		var joRespMsg = resp.message;
        	$scope.apmChartdata = joRespMsg.chartdata;
        	

        	// last value for PrimaryCounter
//        	for(var i = 0; i < $scope.databasePrimaryCountersChartdata.length; i = i + 1) {
//        		var joCounter = $scope.databasePrimaryCountersChartdata[i];
        	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
        		var joCounter = $scope.apmChartdata[i];
        		joCounter.guid = joRespMsg.guid;
        		// joCounter.moduleCode = moduleCode;
        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
				// commented, since tried in directive show hour interval in x-axis, instead of min/max
        		//joCounter.counterData = apmModulesFactory.appendZeroAtFirst(joCounter.counterData);


        		/* DON'T delete, break counter sets, commented 
        		// to set counter lastvalue as primary counter to display in UI
        		var aryCounterSet = joCounter.counterData[joCounter.counterData.length - 1];
        		*/
        		
        		// based on new correction, break counter sets is not there 
        		var aryCounterSet = joCounter.counterData;
        		
        		joCounter.counterLastValue = aryCounterSet[aryCounterSet.length - 1].V;
        	}
        });

    	// get secondary data
    	var resultSecondaryCounters = apmModulesService.getSecondaryCountersData('DATABASE', $scope.sectionSelectDb.guid);
    	resultSecondaryCounters.then(function(resp) {
    		$scope.apmDbSecSumData = resp;
        	$scope.getDbSecondaryData();
    	});
    	

    	// counter's new data are added into jo as `pushdata` per minute
		// loads for pushdata
		clearInterval(timerChartsLoading);
		timerChartsLoading = setInterval(getCountersNewData, sessionServices.get("graphRefresh"));
		//console.info('getCountersNewData:  graphRefresh: '+sessionServices.get("graphRefresh"));
    };

    var timerDbSecondaryData;
	$scope.getDbSecondaryData = function() {
    	clearTimeout(timerDbSecondaryData);
    	var strCounterIds='';
    	for (var i = 0; i < $scope.apmDbSecSumData.length; i = i + 1 ) {
			if ( i != 0 ) strCounterIds = strCounterIds + ',';
			var apmDbSecSumDataObj = $scope.apmDbSecSumData[i];
			strCounterIds = strCounterIds + apmDbSecSumDataObj.counter_id;
    	}
    	if(strCounterIds!=""){
        	var resultSecondaryCounters = apmModulesService.getSecondaryCountersValues('DATABASE', $scope.sectionSelectDb.guid,strCounterIds);
        	resultSecondaryCounters.then(function(resp) {
        		if(resp!=undefined){
            		for (var i = 0; i < $scope.apmDbSecSumData.length; i = i + 1 ) {
    					var data = resp[i];
    					var apmDbSecSumDataObj = $scope.apmDbSecSumData[i];
    					if(data!=undefined){
    						apmDbSecSumDataObj.value = data.value;
    					}else{
    						apmDbSecSumDataObj.value = "NA";
    					}
    		 		}        			
        		}
        	});
    	}
    	timerDbSecondaryData = setTimeout($scope.getDbSecondaryData, sessionServices.get("textRefresh"));
    };

    // getsCountersNewData ToPush
    function getCountersNewData() {
//    	for(var i = 0; i < $scope.databasePrimaryCountersChartdata.length; i = i + 1) {
//    		var joCounterData = $scope.databasePrimaryCountersChartdata[i];
    	for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
    		var joCounterData = $scope.apmChartdata[i];
    		
    		getPushData($scope.sectionSelectDb.guid, joCounterData.counterId, joCounterData.maxTimeStamp);
    	}
    }
    

    // gets counterdata
    function getPushData(guid, counter_id, maxTimeStamp) {

		var resultCountersData =  apmModulesService.getModuleCountersChartdata(guid, counter_id, maxTimeStamp, null);
		resultCountersData.then(function(resp) {
			if( ! resp.success ) {
				// err
			} else {
	        	var joResp = resp.message;
	
				var joRespCountersData = resp.message;//.flotChartData;
				var joRespCountersChartData = joRespCountersData.chartdata;
				var joRespCountersException = joRespCountersData.countersException;
				var strRespAgentException = joRespCountersData.agentException || '';
	
				// To gets length of the JSON object
				var aryRespCounterIds = Object.keys(joRespCountersChartData);
				var nRespCounters = aryRespCounterIds.length;
				
				
//				for(var i = 0; i < $scope.databasePrimaryCountersChartdata.length; i = i + 1) {
//					var joCounterData = $scope.databasePrimaryCountersChartdata[i];
				for(var i = 0; i < $scope.apmChartdata.length; i = i + 1) {
					var joCounterData = $scope.apmChartdata[i];
					
	
					// To set chart's maxTimeStamp and chartData for the response countername
					if( nRespCounters == 1 ) {
						// for single line chart 
						var respCounterId = aryRespCounterIds[0];
						if(joCounterData.counterId === respCounterId) {
							joCounterData.maxTimeStamp = joRespCountersData['max_recieved_on'];
							
							
							//$timeout(function() {
	
								var aryChartData = joCounterData.counterData || [];
								var aryRespCounterChartData = joRespCountersChartData[respCounterId];
								//
								var nRespCounterSetsLength = 0;
	
								if ( aryRespCounterChartData.length > 0 ) {
									


					        		/* DON'T delete, break counter sets, commented 
									// slice
									nRespCounterSetsLength = apmModulesFactory.getCounterSetsLength(aryRespCounterChartData);
									//console.info('nRespCounterSetsLength: '+nRespCounterSetsLength);
									aryChartData = apmModulesFactory.sliceCounterSets(aryChartData, nRespCounterSetsLength);

									// push
									aryChartData = apmModulesFactory.pushCounterSets(aryChartData, aryRespCounterChartData);

					        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
									//joCounterData.counterData = apmModulesFactory.appendZeroAtFirst(joCounterData.counterData);
									//aryChartData = apmModulesFactory.appendZeroAtFirst(aryChartData);
									*/

									// based on new correction, Note: maxTS is not used, all response data is sets, 
									aryChartData = aryRespCounterChartData;
									
									joCounterData.counterData = aryChartData;

					        		/* DON'T delete, break counter sets, commented 
					        		// to set counter lastvalue as primary counter to display in UI
					        		var aryCounterSet = joCounter.counterData[joCounter.counterData.length - 1];
					        		*/
					        		// based on new correction, break counter sets is not there 
					        		var aryLastCounterSet = aryChartData;
					        		
									joCounterData.counterLastValue = aryLastCounterSet[aryLastCounterSet.length - 1].V;

								}
								
							//}, 0, false);
							
							break;
						}
					}
				}
			}
        });
    }
    
	$scope.openApmAllDetailGrpahs = function() {
		$state.transitionTo('/apm_all_details');
	};

	$scope.$on('$destroy', function() {
		clearInterval(timerChartsLoading);
		clearTimeout(timerDbSecondaryData);
    });
}]);

appedoApp.controller("addServiceMapController", function($scope, moduleCardContent, $uibModalInstance, $uibModal, serviceMapService, 
serviceMapEditData, isFrom, successMsgService, $rootScope){
	$scope.moduleCardContent = moduleCardContent;
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	$scope.serviceMapData = {};
	if(isFrom == 'fromEdit') {
		$scope.serviceMapData.serviceMapName = serviceMapEditData.name;
		$scope.serviceMapData.serviceMapDescription = serviceMapEditData.description;
		$scope.serviceMapData.service_map_id = serviceMapEditData.serviceMapId;
		
		$scope.formName = "Edit";
        $scope.saveBtn = "Update";
        $scope.showProceed = false;
	} else {
		$scope.formName = "Add";
		$scope.saveBtn = "Save";
		$scope.showProceed = true;
	}
	
	$scope.validateServiceMapName = function() {
		if($scope.serviceMapData.serviceMapName != '' && $scope.serviceMapData.serviceMapName != undefined) {
			serviceMapService.validateServiceMapName($scope, $scope.serviceMapData.serviceMapName, $scope.serviceMapData.service_map_id, function(data) {
	    		if(data.success){
	    			$scope.showProceed = data.message=="true"?true:false;
	    			if(data.message=='true'){
	    				$scope.response ={};
	            		$scope.response.success = false;
	            		$scope.response.errorMessage = $scope.serviceMapData.serviceMapName+" is already exists.";
	            		successMsgService.showSuccessOrErrorMsg($scope.response);
	    			}
	    		}else{
	    			$scope.showProceed = true;
	    		}
	    	});
		}
	};
	
	$scope.openServiceMapForm = function(){
		$rootScope.$on("close_servicemap_parent_popup", function(event){
			$uibModalInstance.dismiss('cancel');
		});
		var modalInstance = $uibModal.open({
	        templateUrl: 'common/views/dashboard/service_mapping.html',
	        controller: 'serviceMapSelectionController',
	        size: 'lg',
	        resolve: {
	        	serviceAddData: function() {
	        		return $scope.serviceMapData
	        	}, 
	        	saveBtn: function() {
	            	return $scope.saveBtn;
	            }
	        }
		});
	};
});

appedoApp.controller("serviceMapSelectionController", function($scope, $uibModalInstance, $uibModal, serviceAddData, serviceMapService, ngToast, saveBtn, messageService, sessionServices, $rootScope){
	$scope.serviceMapData = {};
	$scope.close = function () {
		$uibModalInstance.dismiss('cancel');
	};
	$scope.saveBtn = saveBtn;
	serviceMapService.getServicesData($scope, serviceAddData, function(){
	});
	
	
	$scope.saveServiceMap = function() {
		/*
		var joSelectedServiceMaps = {};
		var selectedmaps = [];
		for(var i = 0; i < $scope.servicesMap.length; i = i + 1) {
			var joMap = $scope.servicesMap[i];
			var arySelectedModules = []; 
			for(var j=0; j < joMap.modules.length; j = j + 1) {
				var joModule = joMap.modules[j];
				var joModules = {};
				if(joModule.isSelected) {
					//delete joModule.isSelected;
					joModules.module_code = joModule.module_code;
					if(joModule.uid){
						joModules.uid = joModule.uid;
					} else {
						joModules.test_id = joModule.test_id;
					}
					/*for(var key in joModule) {
						if ( key != 'isSelected' && key != '$$hashKey' ) {
							joModules[key] = joModule[key];
						}
					}* /
					selectedmaps.push(joModules);
					arySelectedModules.push(joModules);
				}
			}
			joSelectedServiceMaps[joMap.serviceType] = arySelectedModules;
		}
		*/
		
		var arySelectedMaps = [], joSelectedServiceMaps = {}, joSelectedModule = {};
		var moduleCode = '';
		for (var i = 0; i < $scope.servicesMap.length; i = i + 1) {
			var joMap = $scope.servicesMap[i];
			moduleCode = joMap.serviceType;
			
			//joSelectedMap = {};
			for(var j=0; j < joMap.modules.length; j = j + 1) {
				var joModule = joMap.modules[j];
				joSelectedModule = {}, joSelectedMap = {};
				
				if(joModule.isSelected) {
					joSelectedModule.module_code = moduleCode;
					if(joModule.uid){
						joSelectedModule.uid = joModule.uid;
					} else {
						joSelectedModule.test_id = joModule.test_id;
					}					
					
					joSelectedMap['module_master'] = joSelectedModule;
					
					// 
					arySelectedMaps.push(joSelectedMap);
				}
			}
		}
		
		var url = '', params = {};
		if(serviceAddData && serviceAddData.service_map_id){
			params = {
				serviceMapId: serviceAddData.service_map_id,
				serviceName: serviceAddData.serviceMapName,
				serviceDescription: serviceAddData.serviceMapDescription,
				//selectedServiceMaps: JSON.stringify(joSelectedServiceMaps),
				selectedServiceMaps: JSON.stringify( arySelectedMaps ),
				updateServiceMapDetails: true,
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			};
			url = './service/updateServiceMap_v1';
		} else {
			params = {
				serviceName: serviceAddData.serviceMapName,
				serviceDescription: serviceAddData.serviceMapDescription,
				//selectedServiceMaps: JSON.stringify(joSelectedServiceMaps)
				selectedServiceMaps: JSON.stringify( arySelectedMaps ),
				e_data: JSON.parse(sessionServices.get("selectedEnterprise"))
			};
			url = './service/addServiceMap';
		}
		$scope.disableSMSaveButton = false;
		if( arySelectedMaps && arySelectedMaps.length>0 ){
			$scope.disableSMSaveButton = true;
			serviceMapService.saveOrUpdateServiceMap($scope, params, url, function(data){
				/*successMsgService.showSuccessOrErrorMsg(data);*/
				if(data.success == true){
            		$rootScope.$emit('close_servicemap_parent_popup');
            		$rootScope.$emit('loadServiceMapSelectedTypePanel');
            		//$rootScope.$emit('loadServiceMapData');
            		
            		$uibModalInstance.dismiss();
            		messageService.showSuccessMessage(data.message);
            	} else {
            		$scope.disableSMSaveButton = false;
            		messageService.showErrorMessage(data.errorMessage)
            	}
			});
		} else {
			/*ngToast.create({
				className: 'warning',
				content:'Please select service(s)',
				timeout: 3000,
				dismissOnTimeout: true,
				dismissButton: true,
				animation: 'fade'
			});*/
			messageService.showWarningMessage("Please select service(s)");
		}
	};
});

appedoApp.controller("ServiceMapCardController", function($scope, serviceMapService, $uibModal, successMsgService, $rootScope){
	/*
	 * commented, since ServiceMap's panel cardlayout is loaded on selection of radio button
	$scope.getserviceMapCard = function() {
		serviceMapService.getServiceMapCardData($scope, function(resp){
			$scope.serviceMapCardData = resp;
			$scope.showCardEmptyMsg = false;
			if(resp && resp.length>0){
				$scope.showCardEmptyMsg = false;
			}else{
				$scope.showCardEmptyMsg = true;
			}
		});
	};
	$scope.getserviceMapCard();
	var serviceMapcard = $rootScope.$on("close_servicemap_parent_popup", $scope.getserviceMapCard);
    $scope.$on('$destroy', serviceMapcard);
    */
	
	$scope.getSelectedDashboard = function(serviceMap) {
		$scope.serviceMapRadio.type = "DASHBOARD";
		// myRootVar is the shared variable in serviceMapService
		serviceMapService.myRootVar=serviceMap;
		
		// to load DASHBOARD
		$rootScope.$emit('loadServiceMapSelectedTypePanel');
		
	};
	
	$scope.openAddModuleType = function() {
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/select_module.html',
			controller: 'add-model-instance-controller',
			size: 'lg',
			backdrop : 'static'
		});
	};
	
	$scope.serviceMapCardEdit = function() {
		var serviceMapEditData = this.serviceMap;
		var modalInstance = $uibModal.open({
			templateUrl: 'common/views/dashboard/add_servicemap.html',
			controller: 'addServiceMapController',
			size: 'lg',
			resolve: {
				isFrom: function() {
					return 'fromEdit';
				},
				serviceMapEditData: function() {
					return serviceMapEditData;
				}, moduleCardContent: function() {
					return null;
				}
			}
		});
	};
	
	$scope.deleteSelecteServiceMap = function(index) {
		var result = confirm("Are you sure you want to delete?");
		if(result == true) {
			serviceMapService.deleteServiceMapRecord($scope, this.serviceMap.serviceMapId, function (response) {
				successMsgService.showSuccessOrErrorMsg(response);
				if(response.success == true){
					$scope.serviceMapCardData.splice(index, 1);
					
					// to reload 
            		$rootScope.$emit('loadServiceMapSelectedTypePanel');
            		
					/* commented, since ServiceMap's dropdown is loaded on selection of radio button
					// to reload dropdown service
    				$rootScope.$emit('loadServiceMapData');
    				*/
				}
			});
		}
	};
});


appedoApp.controller('serviceMapHealthDashboardController', ['$rootScope', '$scope', '$state', 'serviceMapService', 'serviceMapFactory', 'appedoDirSliderFactory', 'sessionServices', 'messageService', function($rootScope, $scope, $state, serviceMapService, serviceMapFactory, appedoDirSliderFactory, sessionServices, messageService) {
	// module codes default; DON'T CHANGE array order
	$scope.modules = ['APPLICATION', 'SERVER', 'DATABASE', 'SUM', 'RUM'];
	$scope.MODULES_DEFAULT_STATUS = {};
	$scope.MODULES_DEFAULT_STATUS[$scope.modules[0]] = { moduleCode: 'APPLICATION', displayName: 'Application(s)', moduleCodeDisplayName: 'App', totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0 };
	$scope.MODULES_DEFAULT_STATUS[$scope.modules[1]] = { moduleCode: 'SERVER', displayName: 'Server(s)', moduleCodeDisplayName: 'Svr', totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0 };
	$scope.MODULES_DEFAULT_STATUS[$scope.modules[2]] = { moduleCode: 'DATABASE', displayName: 'Database(s)', moduleCodeDisplayName: 'Db', totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0 };
	$scope.MODULES_DEFAULT_STATUS[$scope.modules[3]] = { moduleCode: 'SUM', displayName: 'SUM(s)',  totalGood: 0, moduleCodeDisplayName: 'SUM', totalWarning: 0, totalCritical: 0, total: 0 };
	$scope.MODULES_DEFAULT_STATUS[$scope.modules[4]] = { moduleCode: 'RUM', displayName: 'RUM/CI(s)',  totalGood: 0, moduleCodeDisplayName: 'RUM', totalWarning: 0, totalCritical: 0, total: 0 };
	
	// health codes default; DON'T CHANGE array order
	$scope.healths = ['OK', 'WARNING', 'CRITICAL', 'INACTIVE'];
	$scope.HEALTH_STATUSES = {};
	$scope.HEALTH_STATUSES[$scope.healths[0]] = { image: 'webflow/images/checkmark_whitebg_greenfg.svg', imageCSSClass: 'imgrndgrnbdr', cssClass: 'bggrn43a047', text: 'Ok' };
	$scope.HEALTH_STATUSES[$scope.healths[1]] = { image: 'webflow/images/notification_whitebg_amberfg.svg', imageCSSClass: 'imgrndamber', cssClass: 'bgyellow', text: 'Warning' };
	$scope.HEALTH_STATUSES[$scope.healths[2]] = { image: 'webflow/images/cross_whitebg_redfg.svg', imageCSSClass: 'imgrndredbdr', cssClass: 'bgred', text: 'Critical' };
	$scope.HEALTH_STATUSES[$scope.healths[3]] = { image: 'webflow/images/arrow_down.svg', imageCSSClass: 'imgrndgreybdr', cssClass: 'bggrey', text: 'Inactive' };
	$scope.HEALTH_STATUSES[$scope.healths[4]] = { image: 'webflow/images/minus.svg', imageCSSClass: 'imgrndgreybdr', cssClass: 'bggrey', text: 'Unconfigured / Inactive' };
	
	// for ASD agent status, agent is Running or not; for SUM test status, test is Running or not; DON'T CHANGE array order
	$scope.STATUSES = ['ACTIVE', 'INACTIVE'];
	
	// blank page page content 
	$scope.showCardEmptyMsg = false;
	
	// for show 2nd & 3rd grids 
	$scope.showModulesStatus = false;
	$scope.showModuleSummaries = false;
	
	// for show loading of 1st, 2nd & 3rd grids
	$scope.showLoadingServiceMaps = false;
	$scope.showLoadingModuleCodesHealth = false;
	$scope.showLoadingModuleSummaries = false;
	
	// grids data
	$scope.serviceMapsHealth = [];
	$scope.moduleCodesStatuses = [];
	$scope.modulesCountersStatuses = [];
	
	// auto refresh
	var timerRefreshGrids;
	
	// back from health dashboard charts page, to restore previous selection
	var bBackFromHealthChartsPage = ($rootScope.backPageFrom === 'SM_HEALTH_DASHBOARD_CHARTS');
	
	
	// qry filter interval 
	var sliderSelectedValue = null, nCustomStartDateTime = null, nCustomEndDateTime = null;
	
	var joSliderOptions = serviceMapFactory.defaultSliderOptions, nSliderValue = 3;
	// restore previous selections, when back from new dashboard charts page  
	if ( bBackFromHealthChartsPage ) {
		if ( $rootScope.serviceMapHealthSelection.interval !== null && $rootScope.serviceMapHealthSelection.interval !== 'null' ) {
			// previous slider selection, 
			nSliderValue = joSliderOptions.qry_intervals.indexOf($rootScope.serviceMapHealthSelection.interval) + 1;
		} else {
			// previous custom time filter selection, 
			nCustomStartDateTime = parseInt($rootScope.serviceMapHealthSelection.startDateTime);
			nCustomEndDateTime = parseInt($rootScope.serviceMapHealthSelection.endDateTime);
		}
	}
	// for directive `appedoSlider`, for slider & custom filter
	$scope.sliderSettings = appedoDirSliderFactory.getSliderSettings(joSliderOptions, nSliderValue);
	
	if (nCustomStartDateTime === null || nCustomEndDateTime === null) {
		// slider qry interval; ignore to set interval, for custom time filter selection, back from new dashboard charts page 
		sliderSelectedValue = $scope.sliderSettings.getQryInterval();
	} else {
		sliderSelectedValue = null;
		// set previous custom time filter, to reflect in UI, sets in fields
		$scope.sliderSettings.setDateTimeFilter(nCustomStartDateTime, nCustomEndDateTime);
	}
	
	
	// gets Service Maps overall health
	$scope.getServiceMapsHealth = function(callback) {
		$scope.showLoadingServiceMaps = true;
		// clear, ignored since masking
		//$scope.serviceMapsHealth = [];
		
		// clears module codes health & modules counters health
		clearModuleCodesHealth();
		clearModulesCountersHealth();
		
		serviceMapService.getServiceMapsHealth(sliderSelectedValue, nCustomStartDateTime, nCustomEndDateTime, function(resp){
			$scope.showLoadingServiceMaps = false;
			// ASK 
			$scope.serviceMapsHealth = [];
			
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.serviceMapsHealth = resp.message;
				
				if( $scope.serviceMapsHealth.length === 0 ){
					// show blank page instructions
					$scope.showCardEmptyMsg = true;
				} else {
					$scope.showCardEmptyMsg = false;
					
					if ( callback instanceof Function ) {
						callback();
					}
				}
			}
		});
	};
	$scope.getServiceMapsHealth(function() {
		/* callbacks,
		 * after 1st grid loaded, called callbackFn. to load module code wise health (2nd grid),
		 * after 2nd grid loaded, called callbackFn. to load modules counters health (3rd grid)
		 */
		
		// sets default selection
		if ( ! bBackFromHealthChartsPage ) {
			// loads module code wise health (2nd grid), selects default 1st Service Map's; after 2nd grid loaded, callaback fn. called to load 3rd grid,
			$scope.load2ndAnd3rdGridSequentially($scope.serviceMapsHealth[0], '', '');
		} else {
			// load previous selection, back from chart page
			var joServiceMap = {};
			for(var i = 0; i < $scope.serviceMapsHealth.length; i = i + 1) {
				joServiceMap = $scope.serviceMapsHealth[i];
				
				if ( joServiceMap.serviceMapId == $rootScope.serviceMapHealthSelection.serviceMapId ) {
					// loads 2nd & 3rd grid, based on previous selection
					$scope.load2ndAnd3rdGridSequentially(joServiceMap, $rootScope.serviceMapHealthSelection.filtered_moduleCode || '', $rootScope.serviceMapHealthSelection.module_healthCode || '');
					break;
				}
			}
		}
	});
	
	
	/**
	 * gets Service Map's mapped modules, module code wise health,
	 * 
	 * @params joServiceMap (selected Service Map)
	 * @params moduleCode & healthCode (to gets mapped modules counters health)
	 */
	$scope.getModuleCodeWiseHealth = function(joServiceMap, callback) {
		//$scope.selectedServiceMap = this.serviceMap;
		$scope.selectedServiceMap = joServiceMap;
		$scope.showModulesStatus = true;
		$scope.showLoadingModuleCodesHealth = true;
		
		// clears module counters health
		clearModulesCountersHealth();
		
		/*
		 * since modules counters wise health are loaded of default select first,
		 * added to show `Performance Counter Status` grid 
		 */
		//$scope.showModuleSummaries = true;
		//$scope.showLoadingModuleSummaries = true;
		
		serviceMapService.getModuleCodeWiseHealth($scope.selectedServiceMap.serviceMapId, sliderSelectedValue, nCustomStartDateTime, nCustomEndDateTime, function(resp){
			$scope.showLoadingModuleCodesHealth = false;
			// ASK, clear add in err (i.e. ! resp.success)
			$scope.moduleCodesStatuses = [];
			
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				var joRespModuleCodeStatuses = resp.message;
				
				var aryModuleCodesStatuses = [], joModuleCodeStatus = {}, joModuleDefaultStatus = {};
				
				
				// arranges/order module codes health, 
				for (var keyModuleCode in $scope.MODULES_DEFAULT_STATUS) {
					// default
					joModuleDefaultStatus = $scope.MODULES_DEFAULT_STATUS[keyModuleCode];
					
					// resp. module code's status
					joModuleCodeStatus = joRespModuleCodeStatuses[keyModuleCode];
					
					if ( joModuleCodeStatus !== undefined ) {
						joModuleCodeStatus.displayName = joModuleDefaultStatus.displayName;
						aryModuleCodesStatuses.push(joModuleCodeStatus);
					}
				}
				
				$scope.moduleCodesStatuses = aryModuleCodesStatuses;
				
				/*
				// loads defaults, 1st module code's counters health, TODO all
				if ( $scope.moduleCodesStatuses.length > 0 ) {
					$scope.getModulesCountersWiseHealth(moduleCode, healthCode);
				}*/
				
				if ( callback instanceof Function ) {
					callback();
				}
			}
		});
	};
	
	// TODO: filter for OK and INACTIVE 
	
	/**
	 * gets Service Map's mapped modules, each modules counters health,
	 * with filter, 
	 *   either moduleCode's `APPLICATION/SERVER/DATABASE/SUM/RUM` OR healthCode `CRITICAL/WARNING/` OR both moduleCode's healthCode
	 *   moduleCode given as `''` to get all mapped `uid/test_id`s health
	 *   healthCode given as `''` to get all `CRITICAL/WARNIING/OK` status 
	 */
	$scope.getModulesCountersWiseHealth = function(moduleCode, healthCode) {
		//$scope.selectedModuleCodeStatus = joModuleCodeStatus;
		$scope.selectedModuleCodeStatus = {
			moduleCode: moduleCode,
			healthCode: healthCode,
			moduleCodeDisplayName: moduleCode === '' ? '' : ' <i class="fa fa-long-arrow-right clr626161"></i> '+$scope.MODULES_DEFAULT_STATUS[moduleCode].displayName,
			healthCodeDisplayName: healthCode === '' ? '' : ' <i class="fa fa-long-arrow-right clr626161"></i> '+$scope.HEALTH_STATUSES[healthCode].text,
		};
		
		$scope.showModuleSummaries = true;
		$scope.showLoadingModuleSummaries = true;
		
		// clear avoided, since masking
		//$scope.modulesCountersStatuses = [];
		
		serviceMapService.getModulesCountersWiseHealth($scope.selectedServiceMap.serviceMapId, moduleCode, healthCode, sliderSelectedValue, nCustomStartDateTime, nCustomEndDateTime, function(resp) {
			$scope.showLoadingModuleSummaries = false;
			// ASK, clear add in err (i.e. ! resp.success)
			$scope.modulesCountersStatuses = [];
			
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.modulesCountersStatuses = resp.message;
				
				// since default select of 1st Service Map, after all grids loaded, added refresh grids automatically
				refreshAutoServiceMapData();
			}
		});
	};
	
	// clears module codes health
	function clearModuleCodesHealth() {
		$scope.showModulesStatus = false;
		/* clear avoided, since masking 
		$scope.moduleCodesStatuses = [];
		*/
	}
	// clears modules counters health
	function clearModulesCountersHealth() {
		$scope.showModuleSummaries = false;
		/* clear avoided, since masking 
		$scope.modulesCountersStatuses = [];
		*/
	}
	
	// loads 2nd & 3rd grid sequentially 
	$scope.load2ndAnd3rdGridSequentially = function(joServiceMap, moduleCode, healthCode) {
		// loads module code wise health (2nd grid); after 2nd grid loaded, callback fn. called to load 3rd grid,
		$scope.getModuleCodeWiseHealth(joServiceMap, function() {
			// loads, module(s) counters health(3rd grid)
			$scope.getModulesCountersWiseHealth(moduleCode, healthCode);
		});
	};
	
	
	// refresh, all grids with selected Service Map's 
	$scope.reloadServiceMapData = function() {
		//sliderSelectedValue = $scope.sliderOptions.qry_intervals[$scope.sliderValue - 1];
		
		// uses slider interval OR custom date time filter 
		if ( $scope.sliderSettings.isSliderSelected() ) {
			// slider filter
			sliderSelectedValue = $scope.sliderSettings.getQryInterval();
			nCustomStartDateTime = null;
			nCustomEndDateTime = null;
		} else {
			// custom date time filter
			sliderSelectedValue = null;
			nCustomStartDateTime = $scope.sliderSettings.startDateTimeInMills;
			nCustomEndDateTime = $scope.sliderSettings.endDateTimeInMillis;
		}
		
		if($scope.selectedServiceMap != undefined){
			
			// loads Service Maps health 
			$scope.getServiceMapsHealth();
			
			// loads module code wise health & default loads given counters health for the given moduleCode, healthCode  
			$scope.getModuleCodeWiseHealth($scope.selectedServiceMap);
			
			// loads module(s) counters health, SUM tests health
			$scope.getModulesCountersWiseHealth($scope.selectedModuleCodeStatus.moduleCode, $scope.selectedModuleCodeStatus.healthCode);	
		}
	};
	
	// auto refresh Service Map grids
	function refreshAutoServiceMapData() {
		clearInterval(timerRefreshGrids);
		
		// reload grid 
		timerRefreshGrids = setInterval( function() {
				// avoid reload if any grid is loading, tried 
				if ( ! $scope.showLoadingServiceMaps && ! $scope.showLoadingModuleCodesHealth && ! $scope.showLoadingModuleSummaries ) {
					$scope.reloadServiceMapData();	
				} 
			}, sessionServices.get('textRefresh'));
	}
	
	// TODO: transistion for chart to show in next page
	
	$scope.viewCharts = function(healthCode) {
		var joSelectedModule = this.moduleCountersStatus;
		if ( joSelectedModule !== undefined ) {
			// particular uid's click's, charts to show
			$state.transitionTo('/serviceMapHealthDashboardCharts');	
		} else {
			// 3rd grid header click's, charts to show
			$state.transitionTo('/serviceMapHealthDashboardCharts');
		}
		
		saveHiddenParams(joSelectedModule, healthCode);
	};
	
	function saveHiddenParams(joSelectedModule, healthCode) {
		// 1st grid selection
		sessionServices.set("smh_serviceMapId", $scope.selectedServiceMap.serviceMapId);
		sessionServices.set("smh_serviceMapName", $scope.selectedServiceMap.serviceMapName);
		
		/*
		 * 2nd grid selection, 
		 * 
		 * 3rd grid for header click of (`WARNING/CRITICAL`), for particular moduleCode's selection from 2nd grid, say only `APPLICATION`'s, mapped modules are filtered in 3rd grid, 
		 * to get filtered moduleCode's, all charts either `WARNING` OR `CRITICAL`,
		 */
		sessionServices.set("smh_filtered_moduleCode", $scope.selectedModuleCodeStatus.moduleCode);
		sessionServices.set("smh_module_healthCode", $scope.selectedModuleCodeStatus.healthCode);
		
		// 3rd grid selection, of particular module OR module's healthCode OR at header healthCode (WARNING/CRITICAL)
		if ( joSelectedModule !== undefined ) {
			// for particular uid's click 
			sessionServices.set("smh_referenceId", joSelectedModule.referenceId);
			sessionServices.set("smh_moduleCode", joSelectedModule.moduleCode);
			sessionServices.set("smh_guid", joSelectedModule.guid);
			sessionServices.set("smh_moduleName", joSelectedModule.moduleName);
		}
		sessionServices.set("smh_metric_healthCode", healthCode);
		
		// slider interval
		if ( sliderSelectedValue !== null ) {
			sessionServices.set("smh_interval", sliderSelectedValue);
		} else {
			sessionServices.set("smh_startDateTime", nCustomStartDateTime);
			sessionServices.set("smh_endDateTime", nCustomEndDateTime);	
		}
	}
	
	$scope.$on('$destroy', function() {
		clearInterval(timerRefreshGrids);
	});
}]);

// Servcie Map's charts controller for 3rd grid 
appedoApp.controller('serviceMapHealthDashboardChartsController', ['$rootScope', '$scope', '$state', '$location', 'serviceMapService', 'serviceMapFactory', 'apmModulesFactory', 'apmModulesService', 'sumModuleServices', 'rumModuleFactory', 'rumService', 'appedoDirSliderFactory', 'sessionServices', 'messageService', function($rootScope, $scope, $state, $location, serviceMapService, serviceMapFactory, apmModulesFactory, apmModulesService, sumModuleServices, rumModuleFactory, rumService, appedoDirSliderFactory, sessionServices, messageService) {
	var URL = $location.url();
	
	$scope.asdChartsData = [];
	$scope.sumTests = [];
	$scope.rumModules = [];
	
	// SUM chart time format
	$scope.d3SUMXaixsFormat = "%d %b %H:%M";
	
	$scope.yaxis_category = 'Avg';
	
	// to use common for `/serviceMapDashboardCharts` & Hot Spots
	$scope.selectedInterval = null, $scope.selectedStartDateTime = null, $scope.selectedEndDateTime = null;
	
	$scope.loadingBreachesCounters = false;
	
	$scope.haveHealthboardCharts = (URL === '/serviceMapHealthDashboardCharts');
	$scope.haveHotspotsCharts = ($scope.navData !== undefined && $scope.navData === 'Hot Spot' && URL === '/dashboard');
	
	if ( $scope.haveHealthboardCharts ) {
		// for service map health dashbaord charts,
		
		// 1st grid selection
		$scope.selectedServiceMapId = sessionServices.get('smh_serviceMapId');
		$scope.selectedServiceMapName = sessionServices.get('smh_serviceMapName');
		
		// 2nd grid selection,  
		$scope.selectedFilteredModuleCode = sessionServices.get('smh_filtered_moduleCode');
		$scope.selectedModuleHealthCode = sessionServices.get('smh_module_healthCode');
		
		// 3rd grid selection, particular module OR module's healthCode OR at header healthCode (WARNING/CRITICAL)
		$scope.selectedModuleDetails = {
			referenceId: sessionServices.get('smh_referenceId'),
			moduleCode: sessionServices.get('smh_moduleCode'),
			guid: sessionServices.get('smh_guid'),
			moduleName: sessionServices.get('smh_moduleName')
		};
		$scope.selectedMetricHealthCode = sessionServices.get('smh_metric_healthCode');
		
		// slider selection
		$scope.selectedInterval = sessionServices.get('smh_interval');
		$scope.selectedStartDateTime = sessionServices.get("smh_startDateTime");
		$scope.selectedEndDateTime = sessionServices.get("smh_endDateTime");
		
		// gets service map healthboard selection charts 
		getServiceMapBreaches();
	} else if ( $scope.haveHotspotsCharts ) {
		// for hot spot, all breaches charts 
		
		var joSliderOptions = apmModulesFactory.hotSpotSliderOptions, nSliderValue = 1;
		
		// for directive `appedoSlider`, for slider & custom filter
		$scope.sliderSettings = appedoDirSliderFactory.getSliderSettings(joSliderOptions, nSliderValue);
		
		// loads breaches counters & chart data
		loadHotSpotData();
	}
	
	
	// gets healthboard selection's breaches, of ASD counters, SUM tests & RUM modules 
	function getServiceMapBreaches() {
		showLoadingBreaches();
		
		serviceMapService.getModuleCounters($scope.selectedServiceMapId, $scope.selectedModuleDetails.referenceId, $scope.selectedModuleDetails.moduleCode || $scope.selectedFilteredModuleCode, $scope.selectedMetricHealthCode, $scope.selectedInterval, $scope.selectedStartDateTime, $scope.selectedEndDateTime, loadBreachedCountersData);
	}
	//getServiceMapBreaches();
	
	// gets hotspots all breaches of ASD counters, SUM tests & RUM modules 
	function getAllBreachesForHotSpot() {
		showLoadingBreaches();
		
		apmModulesService.getBreachedCountersForHotspot($scope.selectedInterval, $scope.selectedStartDateTime, $scope.selectedEndDateTime, loadBreachedCountersData);
	}
	
	// load hotspots all breaches of ASD counters, SUM tests & RUM modules & breached chart data
	function loadHotSpotData() {
		// uses slider interval OR custom date time filter 
		if ( $scope.sliderSettings.isSliderSelected() ) {
			// slider filter
			$scope.selectedInterval = $scope.sliderSettings.getQryInterval();
			$scope.selectedStartDateTime = null;
			$scope.selectedEndDateTime = null;
		} else {
			// custom date time filter
			$scope.selectedInterval = null;
			$scope.selectedStartDateTime = $scope.sliderSettings.startDateTimeInMills;
			$scope.selectedEndDateTime = $scope.sliderSettings.endDateTimeInMillis;
		}
		// ASK, to clear 
		//clearChartData();
		
		// loads hotspots ASD, SUM, RUM breaches & loads breaches chart data for ASD counters, SUM tests & RUM modules 
		getAllBreachesForHotSpot();
	};
	// sets in `$scope`, to use from UI; since error came of `$scope.loadHotSpotData()` using at top, tried added function & sets in `$scope`
	$scope.loadHotSpotData = loadHotSpotData;
	
	// loads chart data for breached ASD counters, SUM tests & RUM modules
	function loadBreachedCountersData(resp) {
		hideLoadingBreaches();
		$scope.lastRefreshedOn = new Date().getTime();
		
		if ( ! resp.success ) {
			// err
			messageService.showErrorMessage(resp.errorMessage);
		} else {
			var joRespMappedModulesDetails = resp.message;
			$scope.asdChartsData = joRespMappedModulesDetails.ASD;
			$scope.sumTests = joRespMappedModulesDetails.SUM;
			$scope.rumModules = joRespMappedModulesDetails.RUM;
			
			// loads ASD chart data
			if ( $scope.asdChartsData !== undefined ) {
				loadCountersChartdata();
			}
			
			// loads SUM test's chart data
			if ( $scope.sumTests !== undefined ) {
				loadSUMTestsChartData();
			}
			
			// loads RUM module's chart data
			if ( $scope.rumModules !== undefined ) {
				loadRUMModuleChartData();
			}
		}
	}
	
	
	// loads ASD's counter's chart data
	function loadCountersChartdata() {
		// get counters chart data
		for(var i = 0; i < $scope.asdChartsData.length; i = i + 1) {
			var joCounterSummary = $scope.asdChartsData[i];
			joCounterSummary.loadingChartData = true;
			// for hotspots
			joCounterSummary.label = joCounterSummary.displayName;
			joCounterSummary.breaches = [];
			
			// get counter chart data
			getModuleCountersChartdata(joCounterSummary.guid, joCounterSummary.counterId, joCounterSummary.maxTimeStamp != undefined ? joCounterSummary.maxTimeStamp : null, joCounterSummary.isAboveThreshold);
		}
	}
	
	
	function getModuleCountersChartdata(guid, counterId, maxTimeStamp, isAboveThreshold) {
		
		var resultModuleCountersChartdata = apmModulesService.getModuleCountersChartdata(guid, counterId, maxTimeStamp, isAboveThreshold, $scope.selectedInterval, $scope.selectedStartDateTime, $scope.selectedEndDateTime);
		resultModuleCountersChartdata.then(function(respGraph) {
			if( ! respGraph.success ) {
				// error msg
				messageService.showErrorMessage(respGraph.errorMessage);
			} else {
				var joResp = respGraph.message;
				var joRespCountersChartData = joResp.chartdata;
				var joRespCountersThresholdLimits = joResp.sla_threshold_limits;
				var joRespCountersException = joResp.countersException;
				var strRespAgentException = joResp.agentException || '';

				// To gets length of the JSON object
				var aryRespCounterIds = Object.keys(joRespCountersChartData);
				var nRespCounters = aryRespCounterIds.length;
				
	    		// TODO: push

				for(var i = 0; i < $scope.asdChartsData.length; i = i + 1) {
		    		var joCounterData = $scope.asdChartsData[i];
					
					joCounterData.maxTimeStamp = joResp['max_recieved_on'];
					joCounterData.serverCurrentTime = joResp['serverCurrentTime'];
					
					if( nRespCounters == 1 ) {
						var respCounterId = aryRespCounterIds[0];
						
						var nRespCounterSetsLength = 0;
						if ( joCounterData['guid'] === joResp.guid && joCounterData['counterId'] == respCounterId ) {
							joCounterData.loadingChartData = false;
							
							var aryRespCounterChartData = joRespCountersChartData[respCounterId];
							
							var aryChartData = joCounterData['data'] || [];
							
							if ( aryChartData.length > 0 ) {
								
								if ( aryRespCounterChartData.length > 0 ) {
					        		/* DON'T delete, break counter sets, commented 
									// slice
									nRespCounterSetsLength = apmModulesFactory.getCounterSetsLength(aryRespCounterChartData);
									aryChartData = apmModulesFactory.sliceCounterSets(aryChartData, nRespCounterSetsLength);
									
									// push
									aryChartData = apmModulesFactory.pushCounterSets(aryChartData, aryRespCounterChartData);

					        		// to append zero at first, if diff between now() - first point in arraySet < 60 min, for last 1 hour
									// commented, since tried in directive show hour interval in x-axis, instead of min/max
									//aryChartData = apmModulesFactory.appendZeroAtFirst(aryChartData);
									*/
									
									// based on new correction, Note: maxTS is not used, all response data is sets
									// 
									aryChartData = aryRespCounterChartData;
								}
							} else {
								aryChartData = aryRespCounterChartData;
							}
							
							// while use of slice/push, in below line respective `aryChartData` to set either `[aryChartData]` or `aryChartData`, thinks, 
							joCounterData['data'] = [aryChartData];
							// sets for hotspots
							//joCounterData.breaches = [];
							joCounterData['sla_threshold_limits'] = joRespCountersThresholdLimits;
							
							break;
						}
					} else {
						// TODO: for multi counters response
						break;
					}
				}
			}
		});
	}
	
	// loads SUM tests chart data
	function loadSUMTestsChartData() {
		var joTest = {};
		
		for (var i = 0; i < $scope.sumTests.length; i = i + 1) {
			joTest = $scope.sumTests[i];
			joTest.loadingChartData = true;
			
			validateTestType(joTest);
		}
	}
	
	// 
	function validateTestType(joTest) {
		
		if ( joTest.testtype === 'URL' ) {
			// gets SUM test chart data
			$scope.getSUMMultiLineChartData(joTest);
		} else {
			// gets test'stransaction pages
			getSUMTestPages(joTest);
		}
	};
	
	// gets test's transaction pages
	function getSUMTestPages(joParamTest) {
		sumModuleServices.getSUMTestPages(joParamTest.test_id, function(data) {
			if ( ! data.success ) {
				// err
				messageService.showErrorMessage(data.errorMessage);
			} else {
				var aryRespTestTransactionPages = data.message;
				var nRespTestId = parseInt(data.testId);
				var joTest = {};
				
				// sets test's transaction for the respective test
				for (var i = 0; i < $scope.sumTests.length; i = i + 1) {
					joTest = $scope.sumTests[i];
					
					if ( joTest.test_id === nRespTestId ) {
						joTest.testTransactionPages = aryRespTestTransactionPages;
						break;
					}
				}
				
				// selects & gets SUM test chart data
				if( joTest.testTransactionPages.length > 0 ) {
					joTest.selectedTransactionPage = joTest.testTransactionPages[0];
				} else {
					joTest.selectedTransactionPage = {}; // assigned empty object since currently we were not showing scanned pagewise har result
				}
				
				$scope.getSUMMultiLineChartData(joTest);
			}
		});
	};
	
	// gets test's chart data
	$scope.getSUMMultiLineChartData = function(joTest){
		//if($scope.selectedWebSite!=undefined){
		
			// selected Transaction page sets
			var pageId = '', pageName = '';
			if( joTest.selectedTransactionPage != undefined ) {
				pageId = joTest.pageId;
				pageName = joTest.pageName;
			}
			
			if ( joTest.testtype === 'TRANSACTION' && pageId === '' ) {
				// For SUM Transactions, Avoid to get chartdata when nullabel value of `Scanned Pages` selected 
			} else {
				var resultSUMMultiLine = sumModuleServices.getSUMMultiLine(joTest.test_id, pageId, pageName, $scope.selectedInterval, $scope.selectedStartDateTime, $scope.selectedEndDateTime);
				resultSUMMultiLine.then(function(resp) {
					if(resp.success){
						var aryRespChartData = resp.message;
						var nRespTestId = parseInt(resp.testId);
						var joRespCountersThresholdLimits = resp.sla_threshold_limits;
						var joTest = {};
						
						// sets test's chartdata for the respective test
						for (var i = 0; i < $scope.sumTests.length; i = i + 1) {
							joTest = $scope.sumTests[i];
							
							if ( joTest.test_id === nRespTestId ) {
								joTest.loadingChartData = false;
								joTest.chartData = aryRespChartData;
								joTest['sla_threshold_limits'] = joRespCountersThresholdLimits;
								break;
							}
						}
					}
				});
			}
		//}
	};
	
	

	// loads RUM module's chart data
	function loadRUMModuleChartData() {
		var joModule = {};
		
		for (var i = 0; i < $scope.rumModules.length; i = i + 1) {
			joModule = $scope.rumModules[i];
			joModule.loadingChartData = true;

			// gets RUM's page view(s) chartdata
			getRUMPageViewsChartData(joModule);
		}
	}
	
	// gets RUM's page view(s) chartdata
	function getRUMPageViewsChartData(joParamModule) {
		var resultRUMAreaChart = rumService.getRUMDashArea(joParamModule.uid, $scope.selectedInterval, $scope.selectedStartDateTime, $scope.selectedEndDateTime, $scope.selectedMetricHealthCode);
		resultRUMAreaChart.then(function(resp) {
			if( ! resp.success ){
				// err 
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				var respMsg = resp.message;
				var aryRespPageViewsChartData = respMsg.dailyVisitorsCount;
				var nRespUId = respMsg.uid;
				var nTotalVisitors = 0;
				// total visit count
				aryRespPageViewsChartData.forEach(function(d) {
					nTotalVisitors = nTotalVisitors + d.V;
				});
				
				// sets resp chartdata, for the respective uid 
				for (var i = 0; i < $scope.rumModules.length; i = i + 1) {
					var joModule = $scope.rumModules[i];
					if ( joModule.uid === nRespUId ) {
						joModule.loadingChartData = false;
						joModule.chartData = aryRespPageViewsChartData;
						joModule.totalVisitors = nTotalVisitors;
						
						break;
					}
				}
			}
		});
	};
	
	
	// back to Service map health dashboard page
	$scope.viewServiceMapHealth = function() {
		$state.transitionTo('/dashboard');
		
		$rootScope.backPageFrom = 'SM_HEALTH_DASHBOARD_CHARTS';
		
		// to restore previous selection 
		$rootScope.serviceMapHealthSelection = {
			serviceMapId: $scope.selectedServiceMapId,
			filtered_moduleCode: $scope.selectedFilteredModuleCode,
			module_healthCode: $scope.selectedModuleHealthCode,
			metricHealthCode: $scope.selectedMetricHealthCode,
			interval: $scope.selectedInterval,
			startDateTime: $scope.selectedStartDateTime,
			endDateTime: $scope.selectedEndDateTime
		};
	};
	
	// to go RUM/CI details page
	$scope.viewRUMDetailsPage = function(joModule) {
		// to filter health board selection's in `rum_details` page
		$rootScope.transitionFromHealthBoard = true;
		$rootScope.healthBoardFilters = { interval: $scope.selectedInterval, startDateTime: $scope.selectedStartDateTime, endDateTime: $scope.selectedEndDateTime, healthCode: $scope.selectedMetricHealthCode || '' };
		
		rumModuleFactory.viewRUMDetailsPage(joModule, 'RUM');
	};
	
	// to go SUM test's details page 
	$scope.viewSUMTestDetailsPage = function(joSUMTest) {
		sessionServices.set("selectedSumCardContent", JSON.stringify(joSUMTest));
		$rootScope.selectedSUMInterval = $scope.selectedInterval;
		
		$state.transitionTo('/sum_details');
	};
	
	function showLoadingBreaches() {
		$scope.loadingBreachesCounters = true;
	}
	function hideLoadingBreaches() {
		$scope.loadingBreachesCounters = false;
	}
	function clearChartData() {
		$scope.asdChartsData = [];
		$scope.sumTests = [];
		$scope.rumModules = [];
	}
	
	// TODO SUM graphs & 3rd grid header click of WARNING/CRITICAL, filter `module_code`'s WARNING/CRITCAL grpahs to show
	
	$scope.$on('$destroy', function() {
		// clears, 1st grid
		sessionServices.destroy('smh_serviceMapId');
		sessionServices.destroy('smh_serviceMapName');
		// clears, 2nd grid
		sessionServices.destroy("smh_filtered_moduleCode");
		sessionServices.destroy("smh_module_healthCode");
		// clears, 3rd grid
		sessionServices.destroy("smh_referenceId");
		sessionServices.destroy("smh_moduleCode");
		sessionServices.destroy("smh_guid");
		sessionServices.destroy("smh_moduleName");
		sessionServices.destroy("smh_metric_healthCode");
		
		sessionServices.destroy("smh_interval");
		sessionServices.destroy("smh_startDateTime");
		sessionServices.destroy("smh_endDateTime");
	});
}]);


/* used for first new dashbaord, old, not in use */
appedoApp.controller('weblfowDashboardSummaryControllerOld', ['$scope', 'dashboardSummaryService', 'serviceMapService', 'sessionServices', 'messageService', function($scope, dashboardSummaryService, serviceMapService, sessionServices, messageService) {
	var MODULES_DEFAULT_STATUS = {
		'APPLICATION': {
			moduleCode: 'APPLICATION', displayName: 'Application(s)',  totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0
		}, 
		'SERVER': {
			moduleCode: 'SERVER', displayName: 'Server(s)',  totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0
		}, 
		'DATABASE': {
			moduleCode: 'DATABASE', displayName: 'Database(s)',  totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0
		}, 
		'SUM': {
			moduleCode: 'SUM', displayName: 'SUM',  totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0
		}, 
		'RUM': {
			moduleCode: 'RUM', displayName: 'RUM/CI',  totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0
		},
	};
	
	$scope.showCardEmptyMsg = false;
	
	$scope.showModulesStatus = false;
	$scope.showModuleSummaries = false;
	
	$scope.showLoadingServiceMaps = false;
	$scope.showLoadingModuleSummaries = false;
	
	$scope.serviceMapCardData = [];
	$scope.selectedModuleStatuses = [];
	$scope.selectedModuleSummaries = [];
	
    // gets user ServiceMaps with mapped modules count
    $scope.getserviceMapCard = function() {
    	$scope.showLoadingServiceMaps = true;
    	
		serviceMapService.getServiceMapCardData($scope, function(resp){
	    	$scope.showLoadingServiceMaps = false;
	    	
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.serviceMapCardData = resp.message;
				
				if( $scope.serviceMapCardData.length > 0 ){
					$scope.showCardEmptyMsg = false;
				} else {
					$scope.showCardEmptyMsg = true;
				}
				
				// clears Module Statuses & Module Summaries, for previous selections
				clearModuleStatuses();
				clearModuleSummaries();
			}
		});
	};
	$scope.getserviceMapCard();
	
	// selected service map's, all modules statuses  
	$scope.getServiceMapModuleStatus = function() {
		$scope.selectedServiceMap = this.serviceMap;
		var aryModulesStatus = [], joModuleStatus = {};
		$scope.selectedModuleStatuses = [];
		
		$scope.showModulesStatus = true;
		
		// clears Module Summaries, for previous selections
		clearModuleSummaries();
		
		// TODO: get selected service map's mapped modules health
		
		for (var keyModuleCode in MODULES_DEFAULT_STATUS) {
			joModuleStatus = MODULES_DEFAULT_STATUS[keyModuleCode];
			// TODO set health, of totalGood, totalWarning, totalCritical
			
			/*
			// pushes all modules
			joModuleStatus.total = $scope.selectedServiceMap.modules_count[keyModuleCode] || joModuleStatus.total;
			aryModulesStatus.push(joModuleStatus);
			*/
			
			// pushes only mapped modules
			if ( $scope.selectedServiceMap.modules_count[keyModuleCode] !== undefined ) {
				joModuleStatus.total = $scope.selectedServiceMap.modules_count[keyModuleCode] || joModuleStatus.total;
				aryModulesStatus.push(joModuleStatus);
			}
		}
		$scope.selectedModuleStatuses = aryModulesStatus;
		
		//$scope.selectedServiceMap.modulesStatus = aryModulesStatus; tried not used
		/* sets in JSON
		{
			serviceMapId: <>,
			serviceMapName: <>,
			module_count: {
				'APPLICATION': <count>, 'SERVER': <count>, 'DATABASE': <count>, 'SUM': <count>
			},
			modulesStatus: [MODULES_DEFAULT_STATUS['APPLICATION'], MODULES_DEFAULT_STATUS['SERVER'], ...]// service map's mapped modules status
			(i.e. modulesStatus: [{moduleCode: 'APPLICATION', displayName: 'Application(s)',  totalGood: 0, totalWarning: 0, totalCritical: 0, total: 0}, ...])
		}*/
	};
	function clearModuleStatuses() {
		$scope.showModulesStatus = false;
		$scope.selectedModuleStatuses = [];
	}
	
	
	// gets service map's selected module's, say APPLICATION's OR ..., mapped `uid/test_id` summaries
	$scope.getSelectedModuleSummaries = function() {
		$scope.selectedModuleStatus = this.moduleStatus;
		$scope.showModuleSummaries = true;
		$scope.showLoadingModuleSummaries = true;
		$scope.selectedModuleSummaries = [];
		
		serviceMapService.getServiceMapMappedModuleSummaries($scope.selectedServiceMap.serviceMapId, $scope.selectedModuleStatus.moduleCode, function(resp) {
			$scope.showLoadingModuleSummaries = false;
			
			if ( ! resp.success ) {
				// err
				messageService.showErrorMessage(resp.errorMessage);
			} else {
				$scope.selectedModuleSummaries = resp.message;
				
				
				//$scope.selectedModuleStatus.moduleSummaries = aryModuleSummaries; tried not used
				/* sets in JSON
				{
					serviceMapId: <>,
					serviceMapName: <>,
					module_count: {
						'APPLICATION': <count>, 'SERVER': <count>, 'DATABASE': <count>, 'SUM': <count>
					},
					modulesStatus: [{moduleCode: 'APPLICATION', displayName: <?> ... total: 0, moduleSummaries: [resp.message]}, ...])
				}*/
			}
		});
	};
	
	function clearModuleSummaries() {
		$scope.showModuleSummaries = false;
		$scope.selectedModuleSummaries = [];
	}
}]);
appedoApp.controller("addLogController", function($scope, $uibModalInstance, $uibModal, logViewService, isFrom, successMsgService, $rootScope) {
	$scope.close = function() {
		$uibModalInstance.dismiss('cancel');
	};

	$scope.logViewData = {};
	$scope.dupCheck = true;
	$scope.logViewData.enableDefaultLogPath = true;
	$scope.showRestrictinfo = false;

	if (isFrom == 'fromEdit') {
		$scope.logViewData.logViewName = logViewEditData.log_view_name;

		$scope.formName = "Edit";
		$scope.saveBtn = "Update";
		$scope.showProceed = false;
	} else {
		$scope.formName = "Add";
		$scope.saveBtn = "Save";
		$scope.showProceed = true;
	}

	// To restrict user to add only one log.
	$scope.ValidateBeforeAdd = function() {
		logViewService.ValidateBeforeAdd(function(data) {
			$scope.isUserMappingExists = data.message;
			if (data.success == true) {
				$scope.showRestrictinfo = data.message === "true";

			} else {
				successMsgService.showSuccessOrErrorMsg(data);
			}
		});
	};
	//	$scope.ValidateBeforeAdd();

	// to validate Log name
	$scope.validateLogViewName = function() {
		if ($scope.logViewData.logViewName != '' && $scope.logViewData.logViewName != undefined) {
			$scope.dupCheck = false;
			logViewService.validateLogViewName($scope, $scope.logViewData.logViewName, function(data) {
				if (data.success) {
					$scope.showProceed = data.isNameExists ? false : true;
					if (data.isNameExists) {
						$scope.response = {};
						$scope.response.success = false;
						$scope.response.errorMessage = $scope.logViewData.logViewName + " is already exists.";
						successMsgService.showSuccessOrErrorMsg($scope.response);
						$scope.disableLogSaveButton = true;
					} else {
						$scope.disableLogSaveButton = false;
					}
				} else {
					$scope.showProceed = true;
				}
			});
		}
	};

	// gets log types
	$scope.getLogTypes = function() {
		logViewService.getLogTypes($scope, function(data) {
			if (data.success) {
				$scope.logTypes = data.message;
			} else {
				//error message
				successMsgService.showSuccessOrErrorMsg(data);
			}
		});
	};
	$scope.getLogTypes();
	// to validate IP address log types	
	$scope.validateIPAddress = function() {
		var logViewIpAddress = $scope.logViewData.logViewIpAddress;
		var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
		if (ipformat.test(logViewIpAddress)) {
			$scope.showInValidIpAddress = false;
			$scope.disableLogSaveButton = false;
		} else {
			$scope.showInValidIpAddress = true;
			$scope.disableLogSaveButton = true;
		}
	};

	$scope.disableLogSaveButton = false;
	$scope.saveLogDetailsData = function() {
		var url = '',
			params = {},
			logViewData = $scope.logViewData,
			logPathParam = $scope.logViewData.selectlogTypes.logPath;

		if (!logViewData.enableDefaultLogPath) {
			logPathParam = logViewData.logPath;
		}

		params = {
			logViewId: logViewData.logViewId,
			logName: logViewData.logViewName,
			logViewDescription: logViewData.logViewDescription,
			logType: logViewData.selectlogTypes.logType,
			logListId: logViewData.selectlogTypes.loglistId,
			logPath: logPathParam
		};

		if (params.logViewId == undefined) {
			url = './log/saveLogView';
		} else {
			url = './log/updateLogView';
		}
		$scope.disableLogSaveButton = true;
		logViewService.saveOrUpdateLogView($scope, params, url, function(data) {
			if (data.success == true) {
				/*$rootScope.$emit('close_servicemap_parent_popup');*/
				$uibModalInstance.dismiss();
				$rootScope.$emit('load_log_card_layout');

			} else {
				$scope.disableLogSaveButton = false;
				successMsgService.showSuccessOrErrorMsg(data);
			}
		});

	};

});

appedoApp.controller('logCardController', ['$scope', '$uibModal', 'logViewService', 'ngToast', 'sessionServices', 'messageService', 'successMsgService', 'moduleSelectorService', '$state', '$rootScope',
	function($scope, $uibModal, logViewService, ngToast, sessionServices, messageService, successMsgService, moduleSelectorService, $state, $rootScope) {

		$scope.showCardEmptyMsg = false;
		$scope.showUserLicMsg = false;
		$scope.showCard = false;
		$scope.loginUserData = JSON.parse(sessionServices.get('loginUser'));
		$scope.close = function() {
			$uibModalInstance.dismiss('cancel');
		};
		// TODO logcontent
		$scope.openLogDetailsView = function(index) {
			sessionServices.set("selectedLogCardContent", JSON.stringify(this.logcontent));
			$state.transitionTo('/log_details');

		};

		$scope.openAddModuleType = function() {
			var modalInstance = $uibModal.open({
				templateUrl: 'common/views/select_module.html',
				controller: 'add-model-instance-controller',
				size: 'lg',
				backdrop: 'static'
			});
		};

		$scope.getLogCardsData = function() {
			logViewService.getLogCardsData(function(data) {
				if (data.success == true) {
					$scope.logCardsContent = data.message;
					if ($scope.logCardsContent.length > 0) {
						$scope.showCardEmptyMsg = false;
						$scope.showCard = true;
					} else {
						// If we are showing the empty card message make ajax call to check whether user have lic for log view.
						if ($scope.loginUserData.License == "level0") {
							$scope.showUserLicMsg = true;
						} else {
							moduleSelectorService.getLogViewLicenseDetails($scope, function(data) {
								if (data.success) {
									$scope.islicenseValid = data.islicenseValid;

									if ($scope.islicenseValid) {
										$scope.showUserLicMsg = false;
									} else {
										$scope.showUserLicMsg = true;
									}
								} else {
									//Error response
									successMsgService.showSuccessOrErrorMsg(data);
								}
							});
						}
						$scope.showCardEmptyMsg = true;
						$scope.showCard = false;
					}
				} else {
					// Error response
					successMsgService.showSuccessOrErrorMsg(data);
				}
			});
		};
		$scope.getLogCardsData();

		var logCard = $rootScope.$on("load_log_card_layout", $scope.getLogCardsData);
		$scope.$on('$destroy', logCard);

		$scope.openDownloadWindow = function(index) {
			$scope.logcontent = this.logcontent;
			var modalInstance = $uibModal.open({
				templateUrl: 'modules/log/view/download_log_setup.html',
				controller: 'download_path_controller',
				size: 'lg',
				resolve: {
					logCardContent: function() {
						return $scope.logcontent;
					}
				}
			});
		};

		//to delete it in card as well as data
		$scope.deleteSelectedLogRow = function(index) {
			var result = confirm("You will lose agent records permanently!\nAre you sure you want to delete?");
			if (result == true) {
				$scope.logcontent = this.logcontent;
				var logViewId = $scope.logcontent.logViewId;
				var logName = $scope.logcontent.logName;
				logViewService.deleteLogViewRecord($scope, logViewId, logName, function(response) {
					if (response.success == true) {
						messageService.showSuccessMessage("Log " + $scope.logcontent.logName + " has been deleted successfully.");
						$rootScope.$emit('load_log_card_layout');
					} else {
						messageService.showWarningMessage('Unable to delete Log');
					}
				});
			}
		};

	}
]);

appedoApp.controller('logDetailsController', ['$scope', 'logViewService', '$appedoUtils', 'sessionServices', '$state', 'ngToast', '$rootScope', 'messageService', function($scope, logViewService, $appedoUtils, sessionServices, $state, ngToast, $rootScope, messageService, successMsgService) {

	$scope.backToLogCardPage = function() {
		$rootScope.backPageFrom = "LogDetails";
		$state.transitionTo('/logHome');
	};

	$scope.loginUser = JSON.parse(sessionServices.get('loginUser'));

	var selectedLogCardData = sessionServices.get("selectedLogCardContent");
	$scope.selectedLogCardContent = JSON.parse(sessionServices.get("selectedLogCardContent"));

	$scope.showIframeLoading = true;
	$scope.showSupportMsg = false;
	$scope.kibanaUserDomainUrl = '';

	// gets ip address and port
	$scope.getUserIpAndPort = function() {
		logViewService.getUserIpAndPort($scope, function(data) {
			if (data.success) {
				if (data.message != undefined && data.message.is_enabled) {
					$scope.UserIpAndPort = data.message;
					$scope.kibanaUserDomainUrl = 'https://' + $scope.UserIpAndPort.nginxIP + ':' + $scope.UserIpAndPort.nginxPort + '/app/kibana';
					$scope.showIframeLoading = false;
				} else {
					$scope.showSupportMsg = true;
					$scope.showIframeLoading = true;
				}
			} else {
				//error message
				successMsgService.showSuccessOrErrorMsg(data);
				$scope.showIframeLoading = false;
			}
		});
	};
	$scope.getUserIpAndPort();

}]);

appedoApp.controller('download_path_controller', function($scope, $uibModalInstance, logCardContent, $state, $location, logViewService, $appedoUtils, messageService, successMsgService) {

	$scope.log = logCardContent;
	$scope.logViewId = logCardContent.logViewId;
	$scope.logType = logCardContent.logType;

	$scope.appedoURL = $appedoUtils.getLocationTillPathName();

	$scope.close = function() {
		$uibModalInstance.dismiss('cancel');
	};

	$scope.showInstallerLoading = true;

	$scope.getLogstashIPAndPort = function() {
		logViewService.getLogstashIPAndPort($scope, $scope.logViewId, function(data) { // only logstash ip address:
			if (data.success) {
				$scope.UserLsIpAndPort = data.message;
				$scope.logstashIP = $scope.UserLsIpAndPort.lsIP;
				$scope.logstashPort = $scope.UserLsIpAndPort.lsPort;
				$scope.logPath = $scope.UserLsIpAndPort.logPath;
				if ($scope.logstashIP == -1) {
					$scope.showInstallerLoading = true;
				} else {
					$scope.showInstallerLoading = false;
				}
			} else {
				//error message
				successMsgService.showSuccessOrErrorMsg(data);
			}
		});
	};
	$scope.getLogstashIPAndPort();

});
appedoApp.controller("addChartController", function($scope, $uibModalInstance, $uibModal, chartViewService, 
		chartViewEditData, isFrom, successMsgService, $rootScope){
			$scope.close = function () {
				$uibModalInstance.dismiss('cancel');
			};
			$scope.chartViewData = {};
			if(isFrom == 'fromEdit') {
				$scope.chartViewData.chartViewName = chartViewEditData.chart_view_name;
				$scope.chartViewData.chartViewDescription = chartViewEditData.description;
				$scope.chartViewData.chart_view_id = chartViewEditData.chart_view_id;
				$scope.chartViewData.counterDetails = chartViewEditData.counterDetails;
				
				$scope.formName = "Edit";
		        $scope.saveBtn = "Update";
		        $scope.showProceed = false;
			} else {
				$scope.formName = "Add";
				$scope.saveBtn = "Save";
				$scope.showProceed = true;
			}
			
			$scope.validateChartViewName = function() {
				if($scope.chartViewData.chartViewName != '' && $scope.chartViewData.chartViewName != undefined) {
					chartViewService.validateChartViewName($scope, $scope.chartViewData.chartViewName, $scope.chartViewData.chart_view_id, function(data) {
			    		if(data.success){
			    			$scope.showProceed = data.message=="true"?true:false;
			    			if(data.message=='true'){
			    				$scope.response ={};
			            		$scope.response.success = false;
			            		$scope.response.errorMessage = $scope.chartViewData.chartViewName+" is already exists.";
			            		successMsgService.showSuccessOrErrorMsg($scope.response);
			    			}
			    		}else{
			    			$scope.showProceed = true;
			    		}
			    	});
				}
			};
			
			$scope.openChartViewForm = function(){
				$rootScope.$on("close_servicemap_parent_popup", function(event){
					$uibModalInstance.dismiss('cancel');
				});
				var modalInstance = $uibModal.open({
			        templateUrl: 'modules/charts/dashboard/chart_mapping.html',
			        controller: 'chartViewSelectionController',
			        size: 'lg',
			        resolve: {
			        	serviceAddData: function() {
			        		return $scope.chartViewData
			        	}, 
			        	saveBtn: function() {
			            	return $scope.saveBtn;
			            }, isFrom: function() {
			            	return isFrom;
			            }, counterDetails: function() {
			            	return $scope.chartViewData.counterDetails;
			            }
			        }
				});
			};
		});

		appedoApp.controller("chartViewSelectionController", function($scope, $uibModalInstance, $uibModal, isFrom, counterDetails, serviceAddData, chartViewService, ngToast, saveBtn, successMsgService, messageService, $rootScope){
			$scope.showCategoryLoading = false;
			$scope.customizedChartsData = {};
			$scope.applicationData = [];
			$scope.customizedCharts = [];
			$scope.configuredCategories = [];
			$scope.counters = [];
			$scope.results = [];
			
			if(isFrom == 'fromEdit') {
				$scope.results = counterDetails;
			}
			
			$scope.categories = {};
			$scope.module = {};
			$scope.counter = {};
			$scope.services = {};
			// $scope.disableChartSaveButton = true;
			if( $scope.results.length > 0 ){
				$scope.disableChartSaveButton = false;
			} else {
				$scope.disableChartSaveButton = true;
			}
			
			$scope.close = function () {
				$uibModalInstance.dismiss('cancel');
			};
			$scope.saveBtn = saveBtn;
			/*chartViewService.getServicesData($scope, serviceAddData, function(){
				if( $scope.module != undefined ){
					 $scope.getAgentAllCategoryCounters();
				}
			});*/
			//calling service 
			chartViewService.getServicesData($scope, serviceAddData, function(data){
				if(data.success == true){
					 $scope.customizedCharts = data.message;
				        $scope.services=$scope.customizedCharts[0];
				        $scope.applicationData = $scope.customizedCharts[0].modules;
						//$scope.module=$scope.applicationData[0];
						if( $scope.module != undefined ){
						//	 $scope.getAgentAllCategoryCounters();

							//clear values of drop down
							$scope.module = undefined;
							$scope.categories = undefined;
							$scope.counter = undefined;
						}
				}else{
					messageService.showWarningMessage('Unable to get Metrics');
				}
			});
			
			$scope.addToForm = function(){
				$scope.validator = [];
				$scope.selectedValue = {};
				$scope.selectedValue.service = $scope.services;
				$scope.selectedValue.module = $scope.module;
				$scope.selectedValue.categories = $scope.categories;
				$scope.selectedValue.counter = $scope.counter;
				//$scope.results.push($scope.selectedValue);
				// console.info($scope.results.length);

				var bflag = true;
				for(var i=0;i<$scope.results.length;i++){
					var itrId = null, itrCounterId = null;
					if( $scope.results[i].module == undefined ){
						itrId = $scope.results[i].module_or_test_id;
					} else {
						itrId = $scope.results[i].module.uid?$scope.results[i].module.uid:$scope.results[i].module.test_id;
					}
					 
					if( $scope.results[i].counter == undefined ){
						 itrCounterId = $scope.results[i].counter_id;
					} else {
						 itrCounterId = $scope.results[i].counter.counter_id?$scope.results[i].counter.counter_id:0;
					}
					
					var id = $scope.module.uid?$scope.module.uid:$scope.module.test_id;
					var counterId = $scope.counter.counter_id?$scope.counter.counter_id:0;
					
					if(itrId == id && itrCounterId == counterId){
						bflag = false;
						break;
					}
				}
				if(bflag){
					$scope.results.push($scope.selectedValue);
				}else{
					messageService.showWarningMessage('Selected metric already added');
				}
				
				if( $scope.results.length > 0 ){
					$scope.disableChartSaveButton = false;
				} else {
					$scope.disableChartSaveButton = true;
				}
			};
			
			$scope.deleteData = function(index){
				$scope.results.splice(index, 1);
				if( $scope.results.length > 0 ){
					$scope.disableChartSaveButton = false;
				} else {
					$scope.disableChartSaveButton = true;
				}
			};
			
			   $scope.getAgentAllCategoryCounters = function() {
				   
				   $scope.showCategoryLoading = true;
				   $scope.configuredCategories = [];
				   $scope.categories = {};
				   
				   $scope.counters = [];
				   $scope.counter = {};
				   var appcardcontent={};
				   appcardcontent.uid = $scope.module.uid ? $scope.module.uid : $scope.module.test_id;
				   appcardcontent.type = $scope.services.serviceType;
				   if(appcardcontent.type == 'RUM' || appcardcontent.type == 'SUM'){
					   $scope.showCategoryLoading = false;
				   }
				   chartViewService.getConfiguredCategories($scope, appcardcontent.uid, appcardcontent.type, function(responseData) {
			    		$scope.configuredCategories = responseData;
			    		$scope.categories = $scope.configuredCategories[0];
			    		$scope.counters = $scope.categories.counters;
			    		$scope.counter = $scope.counters[0];
			    		$scope.showCategoryLoading = false;
					});
				};

			$scope.getModulesData = function() {
				$scope.module = {};
				$scope.applicationData = [];
				$scope.categories = {};
				$scope.configuredCategories = [];
				$scope.counter = {};
				$scope.counters = [];
				$scope.applicationData = $scope.services.modules;
			//	$scope.module=$scope.applicationData[0];
				if( $scope.module != undefined ){
			//		 $scope.getAgentAllCategoryCounters();
					
					//clear values of drop down
					$scope.module=undefined;
					$scope.categories = undefined;
					$scope.counter = undefined;
				}
			};
			
			$scope.getCountersData = function() {
				$scope.counter = {};
				$scope.counters = [];
				$scope.counters = $scope.categories.counters;
				$scope.counter = $scope.counters[0];
			};
			
			$scope.saveChartDetailsData = function(){
				var outArr = [];
				var outObj={};
				for(var i=0;i<$scope.results.length;i++){
					outObj={};
					outObj.serviceType=$scope.results[i].service == undefined ? $scope.results[i].module_name : $scope.results[i].service.serviceType;
					outObj.uid=$scope.results[i].module == undefined ? $scope.results[i].module_or_test_id : $scope.results[i].module.uid?$scope.results[i].module.uid:$scope.results[i].module.test_id;
					outObj.counterID=$scope.results[i].counter == undefined ? $scope.results[i].counter_id : $scope.results[i].counter.counter_id?$scope.results[i].counter.counter_id:0;
					outObj.moduleName=$scope.results[i].module == undefined ? $scope.results[i].app_name : $scope.results[i].module.uid?$scope.results[i].module.module_name:$scope.results[i].module.testname;
					outArr.push(outObj);
				}
				
				var url = '', params = {};
				
				params = {
						chartViewId: serviceAddData.chart_view_id,
						chartName: serviceAddData.chartViewName,
						chartDescription: serviceAddData.chartViewDescription,
						selectedCounters: JSON.stringify( outArr )
					};
				
				if( params.chartViewId == undefined ){
					url = './chart/addChartView';
				} else {
					url = './chart/updateChartView';
				}
				
				chartViewService.saveOrUpdateChartView($scope, params, url, function(data){
					successMsgService.showSuccessOrErrorMsg(data);
					if(data.success == true){
		        		$rootScope.$emit('close_servicemap_parent_popup');
		        		$rootScope.$emit('load_chart_card_layout');        		
		        		$uibModalInstance.dismiss();
		        
		        	} else {
		        		$scope.disableChartSaveButton = false;
		        	}
				});
				
			};
			
		});

		appedoApp.controller('cardController', ['$scope', '$uibModal', 'chartViewService', 'ngToast', 'sessionServices', 'messageService', '$state', '$rootScope', function($scope, $uibModal, chartViewService, ngToast, sessionServices, messageService, $state, $rootScope) {

			$scope.showCardEmptyMsg = false;
			$scope.showCard = false;
			$scope.close = function() {
				$uibModalInstance.dismiss('cancel');
			};
			
			$scope.openAddModuleType = function () {
				var modalInstance = $uibModal.open({
					templateUrl: 'common/views/select_module.html',
					controller: 'add-modal-instance-controller',
					size: 'lg',
					backdrop : 'static'
				});
			};
			
			$scope.openChartDetailsView = function(index) {
				sessionServices.set("selectedChartsCardContent", JSON.stringify(this.chartcontent));
				$state.transitionTo('/chart_details');
				
			};
			
			$scope.getChartCardData = function() {
				chartViewService.getChartCardData(function(data) {
					$scope.chartcardscontent = data.message;
					if(data.success == true && $scope.chartcardscontent.length > 0){
						$scope.showCardEmptyMsg = false;
						$scope.showCard = true;
					} else {
						$scope.showCardEmptyMsg = true;
						$scope.showCard = false;
					}
				});
			};
			$scope.getChartCardData();
			
			var chartCard = $rootScope.$on("load_chart_card_layout", $scope.getChartCardData);
		    $scope.$on('$destroy', chartCard);
		    
		    //to delete it in card/ as well as data
			$scope.deleteSelectedChartRow = function(index) {
				var result = confirm("You will lose agent records permanently!\nAre you sure you want to delete?");
				if(result == true) {
					$scope.chartcontent = this.chartcontent;
					var chartViewId = $scope.chartcontent.chart_view_id;
					chartViewService.deleteChartViewRecord($scope, chartViewId, function (response) {
						if(response.success == true){
							messageService.showSuccessMessage("Chart "+$scope.chartcontent.chart_view_name +" has been deleted successfully.");
							$rootScope.$emit('load_chart_card_layout');
						} else {
							messageService.showWarningMessage('Unable to delete Chart');
						}
					});
				}
			};
			
			$scope.moduleCardEdit = function(index){
				$scope.chartcontent = this.chartcontent;
				var modalInstance = $uibModal.open({
					templateUrl: 'common/views/charts/add_chart_details.html',
					controller: 'addChartController',
					size: 'lg',
					resolve: {
						isFrom: function() {
							return 'fromEdit';
						},
						chartViewEditData: function() {
							return $scope.chartcontent;
						}
					}
				});
			};
		}]);

		appedoApp.controller('chartDetailsController', ['$scope', 'chartViewService', '$appedoUtils', 'sessionServices', '$state', 'ngToast', '$rootScope', 'messageService', 'chartModuleFactory', function($scope, chartViewService, $appedoUtils, sessionServices, $state, ngToast, $rootScope, messageService, chartModuleFactory) {
			$scope.backToChartCardPage = function() {
				$rootScope.backPageFrom = "ChartDetails";
				$state.transitionTo('/charts_home');
			};
			$scope.isLoading = false;
			$scope.chartMultiLine = {};
			$scope.chartMultiLine.startDate = '';
			$scope.chartMultiLine.endDate = '';
			$scope.chartMultiLine.startDateTime = '';
			$scope.chartMultiLine.endDateTime = '';
			$scope.chartMultiLine.startHour = 0;
			$scope.chartMultiLine.endHour = 23;
			$scope.chartMultiLine.startMins = 0;
			$scope.chartMultiLine.endMins = 59;
			$scope.chartMultiLine.enDateLimit = new Date();
			$scope.responseTimeChartData = [];
			//$scope.d3XaixsFormat = '%H:%M';
			$scope.d3ChartTimeFormatForChartPdf = "dd MMM HH:mm:ss";

			$scope.sliderOptions = chartModuleFactory.sliderOptions;
			$scope.sliderValue = 1;
			$scope.selectedTimeInterval = 1; // onloading setting the default time interval to 1
			$scope.endDateinMs = undefined;
			$scope.startDateinMs = undefined;
			$scope.sliderSelectedValue = $scope.sliderOptions.qry_intervals[0];
			$scope.loginUser = JSON.parse(sessionServices.get('loginUser'));
			
			
			var aryD3ChartTimeFormat = JSON.parse(sessionServices.get("d3ChartTimeFormatForLT"));
			// $scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormatForLT"))[0];
			
			var test = sessionServices.get("selectedChartsCardContent");
			$scope.selectedChartsCardContent = JSON.parse(sessionServices.get("selectedChartsCardContent"));
			
			$scope.lastRefreshedOn = '';
			
		    $scope.radioModel = 'Tile';
		    $scope.enableTile = true;
		    $scope.enableToggle = function(){
		    if($scope.radioModel == 'Tile'){
		       	$scope.enableTile = true;
		      } else {
		     	$scope.enableTile = false;
		      }
		    };
			
			$scope.getModules = function(){
				$scope.isLoading = true;
				$scope.responseTimeOriChartData = [];
				$scope.responseTimeChartData = [];
				
		/*    	var resultSUMDropdown = null;*/
		    	var sliderInterval = $scope.sliderSelectedValue;
		    	var startDateTime = null, endDateTime = null;
		    	
		    	if(($scope.chartMultiLine.startDateTime !='' ) && ($scope.chartMultiLine.endDateTime !='')){
		    		sliderInterval = null;
		    		startDateTime = $scope.chartMultiLine.startDateTime.getTime();
		    		endDateTime = $scope.chartMultiLine.endDateTime.getTime();
				} else {
					startDateTime = null;
					endDateTime = null;
				}

		    	$scope.chartCounters=[];
		    	$scope.selectedCounters=[];

				for(var i=0, j=0; i<$scope.selectedChartsCardContent.counterDetails.length; i++){
					var resultSUMDropdown = null;
					$scope.counterDetail = $scope.selectedChartsCardContent.counterDetails[i];
					resultSUMDropdown = chartViewService.getChartMultiLine($scope.counterDetail, sliderInterval, startDateTime, endDateTime);
					resultSUMDropdown.then(function(resp) {
						//$scope.sumMultiChartLoading = false;
						
						if( resp.success ){
							$scope.lastRefreshedOn = new Date().getTime();
							
							var aryRespChartData = resp.message;
							
							for (var k = 0; k < aryRespChartData.length; k = k + 1) {
								var joChartData = aryRespChartData[k];
								
								if ( joChartData.Data !== undefined ) {
									// formats to have respective format 
									if ( (joChartData.moduleName === 'SUM' || joChartData.moduleName === 'RUM') ) {
										joChartData.Data = [ joChartData.Data ];
									}
									
			        				// for multi select dropdown
			        				$scope.selectedCounters.push(joChartData.legendName);
			        				var label1 = joChartData.moduleName+' - '+joChartData.appName;
			        				var label2 = joChartData.category+' - '+joChartData.displayName; 

			        				$scope.chartCounters.push({label: joChartData.legendName, label1: label1, label2: label2});
									
			            			$scope.responseTimeOriChartData.push(joChartData);
			            			$scope.responseTimeChartData.push(joChartData);	
								}
		        			}
		        			$scope.sumMultiChartLoading = false;
		        			$scope.showEmptyMsg = $scope.responseTimeOriChartData.length == 0 ?true:false;
		    				$scope.isLoading = false;
							
		        			/*
		        			if(!(resp.message == undefined)){
		        				$scope.responseTimeOriChartData.push(resp.message);
		        				//$scope.responseTimeChartData.push(resp.message);
		        			}
							
		            		if(j == ($scope.selectedChartsCardContent.counterDetails.length-1)){
		            			$scope.responseTimeChartData = $scope.responseTimeOriChartData; 

		            			for(var l=0; l<$scope.responseTimeOriChartData.length; l++){
		            				if($scope.responseTimeOriChartData[l].legendName != undefined){
										$scope.selectedCounters.push($scope.responseTimeOriChartData[l].legendName);
										var s = {};
										s.label = $scope.responseTimeOriChartData[l].legendName;
										$scope.chartCounters.push(s);
									}
		        				}
		            			$scope.sumMultiChartLoading = false;
		        				$scope.showEmptyMsg = $scope.responseTimeOriChartData.length ==0?true:false;
		        				$scope.isLoading = false;
		            		}
		            		j++;*/
		        		}else{
		        			$scope.sumMultiChartLoading = false;
		        			$scope.isLoading = false;
		        		}
		        	});
		    	}

			};
			$scope.getModules();
			
			$scope.getSelectedSUMTestData = function()
		    {
			 $scope.sumMultiChartLoading = false;
				var selectedResponseTimeCount = [];
		    	for(var i=0; i<$scope.selectedCounters.length;i++){
		    		var locationContent = $scope.selectedCounters[i];
		    		for(var m=0; m < $scope.responseTimeOriChartData.length; m++) {
		    			var moduleContent = $scope.responseTimeOriChartData[m];
		    			if(moduleContent.legendName==locationContent){
		    				selectedResponseTimeCount.push(moduleContent);
		    			}
		    		}
		    	}
		    	$scope.responseTimeChartData = selectedResponseTimeCount;
		    };

		    // for legend on click
		    $scope.getSelectedLegendData= function(legendName, show){
		    	if(show){
		    		$scope.selectedCounters.push(legendName);
		    	}else{
		    		$scope.selectedCounters.splice($scope.selectedCounters.indexOf(legendName), 1);
		    	}
		    	$scope.getSelectedSUMTestData();
		    	$scope.$apply();
		    };
			
			$scope.loadSliderSelectionData = function() {
				$scope.chartMultiLine.startDate = '';
				$scope.chartMultiLine.endDate = '';
				$scope.chartMultiLine.startDateTime = '';
				$scope.chartMultiLine.endDateTime = '';
				$scope.chartMultiLine.startHour = 0;
				$scope.chartMultiLine.endHour = 23;
				$scope.chartMultiLine.startMins = 0;
				$scope.chartMultiLine.endMins = 59;
				$scope.endDateinMs = undefined;
				$scope.startDateinMs = undefined;
//				$scope.d3XaixsFormat = '%H:%M';
//				$scope.d3ChartTimeFormatForChartPdf = "H : M";
//				$scope.customDateStatus = false;
				$scope.sumMultiChartLoading = true;
				$scope.selectedCounters = [];
				$scope.selectedTimeInterval  = $scope.sliderOptions.interval_in_hours[$scope.sliderValue - 1];
				if( $scope.sliderValue == 1 ){
					$scope.sliderSelectedValue = $scope.sliderOptions.qry_intervals[$scope.sliderValue - 1];
					//$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[0];
				}else{
					$scope.sliderSelectedValue = $scope.sliderOptions.qry_intervals[$scope.sliderValue - 1];
			 		//$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[($scope.sliderValue/$scope.sliderOptions.step)];
					//$scope.d3XaixsFormat = aryD3ChartTimeFormat[(($scope.sliderValue-1)/$scope.sliderOptions.step)];
				}
				
				$scope.getModules();
		    };
			
		    $scope.getChartMultiLineWithDateRange = function(){
				$scope.selectedTimeInterval = undefined;
		    	var selectedDateCheck=false;
				var startHourCheck=false;
				var startMinsCheck=false;
				var endHourCheck=false;
				var endMinsCheck=false;
				$scope.sliderValue = 1;
				if(($scope.chartMultiLine.startHour == null) ||($scope.chartMultiLine.startHour.length == 0) || (parseInt($scope.chartMultiLine.startHour)>23)){
					$scope.chartMultiLine.startDateTime = '';
					$scope.chartMultiLine.endDateTime = '';
					messageService.showWarningMessage('Start Hour should not be either empty or greater than 23');
				}else{
					startHourCheck = true;
				}

				if(($scope.chartMultiLine.startMins == null) || ($scope.chartMultiLine.startMins.length ==0) || (parseInt($scope.chartMultiLine.startMins)>59)){
					$scope.chartMultiLine.startDateTime = '';
					$scope.chartMultiLine.endDateTime = '';
					messageService.showWarningMessage('Start Mins should not be either empty or greater than 59');
				}else{
					startMinsCheck = true;
				}

				if(($scope.chartMultiLine.endHour == null) || ($scope.chartMultiLine.endHour.length == 0) || (parseInt($scope.chartMultiLine.endHour)>23)){
					$scope.chartMultiLine.startDateTime = '';
					$scope.chartMultiLine.endDateTime = '';
					messageService.showWarningMessage('End Hour should not be either empty or greater than 23');
				}else{
					endHourCheck = true;
				}

				if(($scope.chartMultiLine.endMins == null ) || ($scope.chartMultiLine.endMins.length == 0) || (parseInt($scope.chartMultiLine.endMins) > 59)){
					$scope.chartMultiLine.startDateTime = '';
					$scope.chartMultiLine.endDateTime = '';
					messageService.showWarningMessage('End Mins should not be either empty or greater than 59');
				}else{
					endMinsCheck = true;
				}
				
				if(($scope.chartMultiLine.startDate == '' ) || ($scope.chartMultiLine.endDate =='')){
					$scope.chartMultiLine.startDateTime = '';
					$scope.chartMultiLine.endDateTime = '';
					messageService.showWarningMessage('Please select start date & end date');
				}else{
					selectedDateCheck = true;
				}

				if((selectedDateCheck == true ) && (startHourCheck == true ) && (startMinsCheck == true ) && (endHourCheck == true ) && (endMinsCheck == true ) ){
					$scope.chartMultiLine.startDateTime = $scope.chartMultiLine.startDate;
		    		$scope.chartMultiLine.startDateTime.setHours($scope.chartMultiLine.startHour);
		    		$scope.chartMultiLine.startDateTime.setMinutes($scope.chartMultiLine.startMins);
		    		
		    		$scope.chartMultiLine.endDateTime = $scope.chartMultiLine.endDate;
		    		$scope.chartMultiLine.endDateTime.setHours($scope.chartMultiLine.endHour);
		    		$scope.chartMultiLine.endDateTime.setMinutes($scope.chartMultiLine.endMins);
		    		
		    		if($scope.chartMultiLine.startDateTime <= $scope.chartMultiLine.endDateTime){
		    			$scope.startDateinMs = $scope.chartMultiLine.startDateTime.getTime();
						$scope.endDateinMs = $scope.chartMultiLine.endDateTime.getTime();
		/*
						if(checkSelectedDurationLessThanGivenHour(1,(endDateinMs - startDateinMs))){ //1 hour
							$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[0];
							$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[0];
						}else if(checkSelectedDurationLessThanGivenHour(24,(endDateinMs - startDateinMs))){ //24 hour
							$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[1];
							$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[1];
						}else if(checkSelectedDurationLessThanGivenHour(168,(endDateinMs - startDateinMs))){ //7 days
							$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[2];
							$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[2];
						}else if(checkSelectedDurationLessThanGivenHour(360,(endDateinMs - startDateinMs))){ //15 days
							$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[3];
							$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[3];
						}else if(checkSelectedDurationLessThanGivenHour(720,(endDateinMs - startDateinMs))){ //30 days
							$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[4];
							$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[4];
						}else if(checkSelectedDurationLessThanGivenHour(1440,(endDateinMs - startDateinMs))){ //60 days
							$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[5];
							$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[5];
						}else{ //  >= 120 days
							$scope.d3XaixsFormat = JSON.parse(sessionServices.get("d3ChartTimeFormat"))[6];
							$scope.d3ChartTimeFormatForChartPdf = JSON.parse(sessionServices.get("d3ChartTimeFormatForMyChartPdf"))[6];
						}
		*/
		    			$scope.sumMultiChartLoading = true;
//		        		$scope.d3XaixsFormat = "%d %b %H:%M";
		            	$scope.showMultiSelectDropdown = false;
		            	$scope.selectedLocations = [];
		            	$scope.selectedBrowsers = [];
		            	$scope.selectedConnections = [];
		        		$scope.responseTimeChartData=[];
		        		$scope.responseTimeOriChartData=[];
		        		$scope.getModules();
		    		}else{
		        		messageService.showWarningMessage('End datetime should be greater than or equal to start datetime');
		    		}
				}
		    };
		    
		    function checkSelectedDurationLessThanGivenHour(hour,runTime){
				return (1000 * 60 * 60 * Number(hour)) > Number(runTime) ? true : false;
			}
		    
			$scope.reloadMyChartData = function() {
				if ( $scope.chartMultiLine.startDate == '' || $scope.chartMultiLine.endDate =='' ) {
		    		// loads slider selection
					$scope.loadSliderSelectionData();
				} else {
		    		// loads date range
					$scope.getChartMultiLineWithDateRange();
				}
			};
		}]);