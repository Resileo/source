package com.appedo.manager;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.common.Constants;

public class LoginManager {
	
	/**
	 * updates login history's, logout comment column
	 * 
	 * @param lLoginHistoryId
	 * @param strLogoutComment
	 */
	public static void updateLogoutHistoryComment(long lLoginHistoryId, String strLogoutComment) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResponse = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("loginHistoryId", lLoginHistoryId+"");
			wsm.addParameter("logoutComment", strLogoutComment);
			wsm.sendRequest(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/updateLogoutHistoryComment");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				joResponse = JSONObject.fromObject(wsm.getResponse());
			} else {
				//throw new Exception("1");	// TODO Inform that Service has problem
				LogManager.errorLog("Problem with service.");
			}
			
			if( joResponse.getBoolean("success") ) {
				LogManager.infoLog("Successfully updated in login histroy for History-Id: "+lLoginHistoryId+", "+strLogoutComment);
			} else {
				LogManager.infoLog("Unable to update in login histroy for History-Id: "+lLoginHistoryId+", "+strLogoutComment);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	/**
	 * updates login history's, login comment column
	 * 
	 * @param lLoginHistoryId
	 * @param strLoginComment
	 * @throws Exception
	 */
	public static void updateLoginHistoryComment(long lLoginHistoryId, String strLoginComment) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResponse = null;
		
		try {
			// saves new session, updates new session for which terminated from
			// update message
			wsm = new WebServiceManager();
			wsm.addParameter("loginHistoryId", lLoginHistoryId+"");
			wsm.addParameter("loginComment", strLoginComment);
			wsm.sendRequest(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/updateLoginHistoryComment");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				joResponse = JSONObject.fromObject(wsm.getResponse());
			} else {
				//throw new Exception("1");	// TODO Inform that Service has problem
				LogManager.errorLog("Problem with service.");
			}
			
			if( joResponse.getBoolean("success") ) {
				LogManager.infoLog("Successfully updated in login histroy for History-Id: "+lLoginHistoryId+", "+strLoginComment);
			} else {
				LogManager.infoLog("Unable to updated in login histroy for History-Id: "+lLoginHistoryId+", "+strLoginComment);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
}
