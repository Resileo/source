package com.appedo.controller;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.bean.UserBean;
import com.appedo.common.Constants;
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.listener.AppedoHttpSessionListener;
import com.appedo.manager.LogManager;
import com.appedo.manager.LoginManager;
import com.appedo.manager.WebServiceManager;
import com.appedo.utils.UtilsFactory;

/**
 * Servlet implementation class ModuleController
 */
public class SUMDemoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SUMDemoController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		JSONArray jaNodes = null;
		String strMessage =  null;
		String pswd = "";
		
		JSONObject joRespHavingURL = null;
		
		LoginUserBean loginUserBean = null, alreadyLoggedInUserBean = null;
		
		try {
			request.setAttribute("userid", request.getParameter("demo_test_email_id"));
			request.setAttribute("company_name", request.getParameter("demo_test_company_name"));
			request.setAttribute("firstName", request.getParameter("demo_test_email_id").split("@")[0]);
			request.setAttribute("lastName", request.getParameter("demo_test_company_name"));
			if(request.getParameter("demo_test_pwd") == null){
				pswd = pswd+getRandomNumber(1, 999999);
			}else{
				pswd = request.getParameter("demo_test_pwd");
			}
			request.setAttribute("retypePwd", pswd);
			request.setAttribute("password", pswd);
			request.setAttribute("mobileNo", request.getParameter("demo_test_phone_number"));
			request.setAttribute("sumurl", request.getParameter("sumurl"));
			
			WebServiceManager wsm = new WebServiceManager();
			wsm.sendRequest(Constants.APPEDO_URL + "/userSignup", request );
			
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				JSONObject joSignUpResponse = JSONObject.fromObject(wsm.getResponse());
				
				UserBean userBean = new UserBean();
				userBean.fromJSONObject(joSignUpResponse);
				
				// already logged in user bean
				alreadyLoggedInUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
				
				// login session
				request.setAttribute("emailId", request.getParameter("demo_test_email_id").toLowerCase());
				request.setAttribute("password", userBean.getPassword());
				request.setAttribute("escape_login", true);
				LoginController loginController = new LoginController();
				loginController.doAction(request, response);
				
				//HttpSession session = request.getSession();
				
				// For valid user the connection is added to session, con carried out till session
				// expires or signout
				loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
				
				// tried, same session different user logged from quick-SUM, remove old logged user from sessionList 
				if ( alreadyLoggedInUserBean != null && loginUserBean != null && alreadyLoggedInUserBean.getUserId() != loginUserBean.getUserId() ) {
					/*
					 * updates login_history for the same session's old user (ie.. user who has logged in before quick-SUM from the same session/browser), 
					 *   as comment `Accepted new login from quick-SUM for the same session.`
					 */
					LoginManager.updateLogoutHistoryComment(alreadyLoggedInUserBean.getLoginHistoryId(), "Accepted new login from quick-SUM for the same session. History-Id: "+loginUserBean.getLoginHistoryId());
					
					// remove already different user logged from sessionList of sameSession
					AppedoHttpSessionListener.removeSession(alreadyLoggedInUserBean.getUserId()+"");
				}
				
				if( loginUserBean == null ){
					strMessage = (String)session.getAttribute("error");
					response.getWriter().write( UtilsFactory.getJSONSuccessReturn(strMessage).toString() );
				}
				
				if(strMessage == null){
					// sum test master
					request.setAttribute("login_user_bean", loginUserBean.toJSON());
					request.setAttribute("device_type", "Desktop");
					wsm.sendRequest(Constants.APPEDO_UI_SUM_SERVICES + "/sum/getQuickSUMNodes", request);
					if (wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK) {
						jaNodes = JSONObject.fromObject(wsm.getResponse()).getJSONArray("message");
					}
					
					jaNodes.getJSONObject(0).toString();
					JSONArray jacities = new JSONArray();
					jacities.add(jaNodes.getJSONObject(getRandomNumber(0, jaNodes.size() - 1)));
					String selectedCities = jacities.toString();
					Date startDate = new Date();
					Calendar endDate = Calendar.getInstance();
					endDate.add(Calendar.MONTH, 1);
					
					String strUrl = request.getParameter("sumurl");
					
					//
					request.setAttribute("url", strUrl);
					request.setAttribute("login_user_bean", loginUserBean.toJSON());
					JSONObject joExist = null;
					wsm.sendRequest(Constants.APPEDO_UI_SUM_SERVICES + "/sum/isUrlExist", request);
					if (wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK) {
						joRespHavingURL = JSONObject.fromObject(wsm.getResponse());
						joExist = joRespHavingURL.getJSONObject("message");
					}
					if( joExist.getBoolean("ishavingurl") ) {
						response.getWriter().write(UtilsFactory.getJSONSuccessReturn(joExist).toString());
					} else {
						String testName = "TestDrive - " + getRandomNumber(1, 10000);
						request.setAttribute("login_user_bean", loginUserBean);
						request.setAttribute("testName", testName);
						request.setAttribute("url", strUrl);
						request.setAttribute("runEveryMinutes", "240");
						request.setAttribute("status", true);
						request.setAttribute("testtype", "URL");
						request.setAttribute("selectedCities", selectedCities);
						request.setAttribute("startDate", startDate.toString());
						request.setAttribute("endDate", endDate.getTime().toString());
						request.setAttribute("login_user_bean", loginUserBean.toJSON());
						
						// WPT SUM parameters
						request.setAttribute("connectionId", "1");
						request.setAttribute("dobIds", "1");
						request.setAttribute("downloadLimit", "5000000");
						request.setAttribute("latencyLimit", "28");
						request.setAttribute("packetLoss", "0");
						request.setAttribute("repeatView", "false");
						request.setAttribute("responseAlert", "");
						request.setAttribute("uploadLimit", "1000000");
						request.setAttribute("errorLimit", "20");
						request.setAttribute("warningLimit", "5");
						request.setAttribute("minBreachCount", "1");
						request.setAttribute("downTimeAlert", true);
						
						wsm.sendRequest(Constants.APPEDO_UI_SUM_SERVICES + "/sum/addNewSUMTest", request);
						if (wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK) {
							// response.sendRedirect("#/loginResponse");
							response.getWriter().write(UtilsFactory.getJSONSuccessReturn(wsm.getResponse()).toString());
						}
					}
				}else{
					response.getWriter().write( UtilsFactory.getJSONSuccessReturn(strMessage).toString() );
				}
				
			} else {
				response.getWriter().write( UtilsFactory.getJSONFailureReturn("Problem with Services").toString() );
			}
			
		}catch(Exception e){
			LogManager.errorLog(e);
		}
	}
	
	public static int getRandomNumber(int min, int max) {
	    return (int) Math.floor(Math.random() * (max - min + 1)) + min;
	}
}
