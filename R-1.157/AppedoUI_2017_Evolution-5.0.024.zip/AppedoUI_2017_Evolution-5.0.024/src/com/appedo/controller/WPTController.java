package com.appedo.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.common.Constants;
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.WebServiceManager;
import com.appedo.utils.UtilsFactory;

/**
 * Servlet implementation class ModuleController
 */
@WebServlet("/WPTController")
public class WPTController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String METHOD_GET = "GET";
    private static final String METHOD_POST = "POST";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WPTController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response, request.getMethod());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response, request.getMethod());
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response, String requestMethod) throws ServletException, IOException {
		String strRequestAction = null;
		LoginUserBean loginUserBean = null;
		HttpSession session = request.getSession(false);
		String url = "";
				
		// return Exception if session is already expired.
		if ( session == null || session.getAttribute("login_user_bean") == null ) {
			throw new ServletException("SESSION_EXPIRED");
		}
		
		loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
		request.setAttribute("login_user_bean", loginUserBean.toJSON());
		
		// get the URI portion without Application Name
		strRequestAction = request.getRequestURI();
		strRequestAction = strRequestAction.substring( strRequestAction.indexOf("/", 1), strRequestAction.length());
		
		if(strRequestAction.contains("/wpt/")) {
			url = Constants.WPT_APPEDO_REDIRECTOR.getJSONObject(0).getString("wpt_server_url")+strRequestAction.substring( strRequestAction.indexOf("/wpt/")+5 );
		}
		
		WebServiceManager wsm = new WebServiceManager();
		
		if (requestMethod == METHOD_GET) {
			wsm.sendRequestUsingGet(url, request);
		} else if (requestMethod == METHOD_POST) {
			wsm.sendRequest(url, request);
		}
		
		if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
			
			String wsmResponse = wsm.getResponse();
			
			// `WPT SERVER` is restricted for the public access, only node machines and Appedo-UI instance can access it,
			// Hence, to avoid exposing the WPT's DNS in UI, WPT's url is replaced with the redirector url like below. 
			//  Ex: Replace `https://wpt.appedo.com/` as `https://apm.appedo.com/appedo/wpt/`
			// Now `Content  Breakdown` and `Domains Breakdown` screens from WPT SERVER were rendered in APPEDO-UI through redirection.
			
			if(url.endsWith("breakdown/") || url.endsWith("domains/") || url.endsWith("css") || url.endsWith("js")){
				wsmResponse = wsmResponse.replace("src=\"/", "src=\""+Constants.WPT_APPEDO_REDIRECTOR.getJSONObject(0).getString("redirector_url"));
				wsmResponse = wsmResponse.replace("href=\"/", "href=\""+Constants.WPT_APPEDO_REDIRECTOR.getJSONObject(0).getString("redirector_url"));
				wsmResponse = wsmResponse.replace("url(/", "url("+Constants.WPT_APPEDO_REDIRECTOR.getJSONObject(0).getString("redirector_url"));
				wsmResponse = wsmResponse.replace("url('/", "url('"+Constants.WPT_APPEDO_REDIRECTOR.getJSONObject(0).getString("redirector_url"));
			}
			
			response.getWriter().write(wsmResponse);
		} else {
			response.getWriter().write( UtilsFactory.getJSONFailureReturn("Problem with Services").toString() );
		}
		
		// clear used variables
		loginUserBean = null;
		strRequestAction = null;
	}
}
