package com.appedo.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.common.Constants;
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.listener.AppedoHttpSessionListener;
import com.appedo.manager.LogManager;
import com.appedo.manager.LoginManager;
import com.appedo.manager.WebServiceManager;
import com.appedo.utils.UtilsFactory;

/**
 * Executes HTTP request and response for User to signin
 * 
 */
public class LoginController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private ServletConfig config;
	private boolean bForceLogout = false;
	private long lForceLogoutHistoryId = -1;
	
	public void init(ServletConfig config) throws ServletException{
		this.config = config;
	}
	
	/**
	 * Do process when POST request comes.
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	/**
	 * Do process when GET request comes.
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	/**
	 * Get the request and do the needful.
	 * Call respective function flow in Customize Model for Settings operation.
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String action = request.getServletPath(), responseJSONStream = null, strRedirectUri = null;
		
		JSONObject joResponse = null, joLoginUserBean = null;
		
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession(false);
		WebServiceManager wsm = null;
		JSONArray jaEnterpriseLicense = null;
		
		if((action.equals("/loginSession") || action.equals("/addDemoSUM")) && ! bForceLogout) {
			Date dateLog = LogManager.logMethodStart();
			//session = null;
			request.getSession().removeAttribute("status");
			//String strEmailId = UtilsFactory.replaceNull(request.getParameter("emailId"), request.getAttribute("emailId").toString()).trim();
			String strEmailId = UtilsFactory.replaceNull(request.getParameter("emailId"), UtilsFactory.replaceNull(request.getAttribute("emailId"), "")).trim();
			String sumUrl = request.getParameter("sumurl");
			
			LoginUserBean loginUserBean = null, alreadyLoggedInUserBean = null;
			
			try {
				// redirect to login already logged in emailId and new given emailId are same from multiple tabs open in same session/browser
				if ( session != null && (alreadyLoggedInUserBean = (LoginUserBean) session.getAttribute("login_user_bean")) != null && alreadyLoggedInUserBean.getEmailId().equals(strEmailId)	) {
					/*
					 * same session, user has already logged in, but already opened multiple tabs of login page, 
					 *   already logged in email_id and new tab email_id are same, redirects to login page
					 */
					response.sendRedirect("#/loginResponse");
				} else {
					// login
					wsm = new WebServiceManager();
					wsm.sendRequest(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/loginSession", request);
					
					int statusCode = wsm.getStatusCode();
					responseJSONStream = wsm.getResponse().trim();
					
					if( statusCode != HttpStatus.SC_OK ) {
						throw new Exception("1");	// TODO Inform that Service has problem
					}
					
					if( responseJSONStream.startsWith("{") && responseJSONStream.endsWith("}") ) {
						joResponse = JSONObject.fromObject(responseJSONStream);
						jaEnterpriseLicense = new JSONArray();
						if( joResponse.getBoolean("success") ) {
							if( joResponse.containsKey("loginUserBean") ) {
								joLoginUserBean = joResponse.getJSONObject("loginUserBean");
								
								loginUserBean = new LoginUserBean();
								loginUserBean.fromJSONObject(joLoginUserBean);

							} else {
								throw new Exception("1");	// TODO Inform that Service has problem
							}
							if(joResponse.containsKey("enterpriseLicense")){
								jaEnterpriseLicense = joResponse.getJSONArray("enterpriseLicense");
							}
						} else {
							if( joResponse.containsKey("errorMessage") ) {
								throw new Exception( joResponse.getString("errorMessage") );
							}
						}
					}
					
					if ( loginUserBean == null ) {
						// Error message to show for if emailId or password not found  
						response.sendRedirect("#/loginResponse?_err=1&emailId="+strEmailId);
					} else {
						
						/*
						 * user has opened multiple tabs of login page (ie.. in same session/browser),
						 * in a first a tab logged in using emailId, say `navinb@appedo.com`, 
						 * in a next tab of same session/browser tries to login using different emailId, say `navinb@softsmith.com`, 
						 *   force logout of previous session of `navinb@appedo.com` and accepts the newly logged in session `navinb@appedo.com`
						 */
						if ( session != null && session.getAttribute("login_user_bean") != null ) {
							alreadyLoggedInUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
							bForceLogout = true;
							lForceLogoutHistoryId = loginUserBean.getLoginHistoryId();
							
							// calls logoutSession, based on handled the variable using `bForceLogout`
							doAction(request, response);
							LoginManager.updateLoginHistoryComment(lForceLogoutHistoryId, "Login after forcefully terminating session: "+alreadyLoggedInUserBean.getLoginHistoryId());
							
							bForceLogout = false;
						}
						session = request.getSession(true);
						
						
						// To check admin has logged in
						if( loginUserBean.getEmailId().equals("sysadmin@appedo.com") ){
							loginUserBean.setAdmin(true);
						}
						/* Multi-Login validation is not required for now
						
						// Check user has active loggedIn session 
						// Avoid the validation if it is sysadmin's login
						if ( loginUserBean.isAdmin() == false && AppedoHttpSessionListener.isSessionExists(loginUserBean.getUserId()+"") ) {
							// 
							session.setAttribute("multi_loginuserbean", loginUserBean);
							response.sendRedirect("#/multiLoginValidation");
							
							// to display Guessed User name in /manager/html/sessions page
							session.setAttribute("username", loginUserBean.getFirstName()+" "+loginUserBean.getLastName()+" - multiLogin");
						} else { */
							// to display Guessed User name in /manager/html/sessions page
							session.setAttribute("username", loginUserBean.getFirstName()+" "+loginUserBean.getLastName());
							
							// For valid user the connection is added to session, con carried out till session expires or signout
							session.setAttribute("login_user_bean", loginUserBean);
							session.setAttribute("enterpriseLicense", jaEnterpriseLicense);

							// maintain user's session, to avoid multiple login
							AppedoHttpSessionListener.addSession(loginUserBean.getUserId()+"", session);
							
							//TODO moved into loginUserBean session.setAttribute("login_history_id", lLoginHistoryId);
							if( sumUrl == null ){
								response.sendRedirect("#/loginResponse");
							}
						 // }	// Multi-Login  end 
					}
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				// Error message to show for Invalid login user
				if ( e.getMessage().equalsIgnoreCase("1") ) {
					strRedirectUri = "#/loginResponse?_err=1&emailId="+strEmailId;
				} else if(e.getMessage().equalsIgnoreCase("2")) {
					if( sumUrl == null){
						strRedirectUri = "#/loginResponse?_err=2&emailId="+strEmailId;
					}else{
						session = request.getSession(true);
						session.setAttribute("error", "emailid and pwd does not match.");
					}
				}else if(e.getMessage().equalsIgnoreCase("3")) {
					strRedirectUri = "#/loginResponse?_err=3&emailId="+strEmailId;
				}else if(e.getMessage().equalsIgnoreCase("5")) {
					strRedirectUri = "#/loginResponse?_err=5&emailId="+strEmailId;
				}
				response.sendRedirect(strRedirectUri);
			} finally {
				if ( wsm != null ) {
					wsm.destory();
					wsm = null;	
				}
				
				//UtilsFactory.clearCollectionHieracy(loginUserBean);
				loginUserBean = null;
				
				action = null;
				responseJSONStream = null;
				strRedirectUri = null;
				
				LogManager.logMethodEnd(dateLog);
			}
		} else if( action.equals("/logoutSession") || bForceLogout ){
			/* 1. logout user session, 
			 * 2. added `bForceLogout`, since user has opened multiple tabs in same session/browser 
			 *     and has logged in a tab and login with another id in a same tab, force logout previous session
			 */
			Date dateLog = LogManager.logMethodStart();
			LoginUserBean loginUserBean = null;
			
			try {
				// return Exception if session is already expired.
				session = request.getSession(false);
				if ( session == null || session.getAttribute("login_user_bean") == null ) {
					response.sendRedirect("#/login");
				} else {
					loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
					request.setAttribute("login_user_bean", loginUserBean.toJSON());
					request.setAttribute("forceLogout", bForceLogout);
					request.setAttribute("logoutComment", "Logout forcefully by another login in same session; History-Id: "+lForceLogoutHistoryId);
					
					wsm = new WebServiceManager();
					wsm.sendRequest(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/logoutSession", request);

					if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
						joResponse = JSONObject.fromObject(wsm.getResponse());
					} else {
						throw new Exception("1");	// TODO Inform that Service has problem
					}
					
					// removes user's session
					AppedoHttpSessionListener.removeSession(loginUserBean.getUserId()+"");
					session.removeAttribute("login_user_bean");
					session.invalidate();
					
					// redirects to login is avoided, for force logout is enabled
					if( joResponse.getBoolean("success") && ! bForceLogout ) {
						response.sendRedirect("#/loginResponse?_smsg=5");
					}
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				//response.getWriter().write("<B style=\"color: red; \">Exception occurred: "+(e.getMessage().equals("1") ? "Problem with Services" : e.getMessage())+"</B>");
			} finally {
				if ( wsm != null ) {
					wsm.destory();
					wsm = null;	
				}
				
				//UtilsFactory.clearCollectionHieracy(loginUserBean);
				loginUserBean = null;
				action = null;
				
				LogManager.logMethodEnd(dateLog);
			}
		} else if(action.equals("/isSessionExist")){
			Date dateLog = LogManager.logMethodStart();
			LoginUserBean loginUserBean = null;
			
			try {
				session = request.getSession(false);
				if ( session == null || session.getAttribute("login_user_bean") == null ) {
					response.getWriter().write( UtilsFactory.getJSONFailureReturn("Invalid Session").toString() );
				} else {
					loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
					request.setAttribute("login_user_bean", loginUserBean.toJSON());

					// to display Guessed User name in /manager/html/sessions page
					session.setAttribute("username", loginUserBean.getFirstName()+" "+loginUserBean.getLastName());
					
					// For valid user the connection is added to session, con carried out till session expires or signout
					session.setAttribute("login_user_bean", loginUserBean);
					
					response.getWriter().write( UtilsFactory.getJSONSuccessReturn("Valid Session").toString() );
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				
			} finally {
				loginUserBean = null;
				action = null;
				
				LogManager.logMethodEnd(dateLog);
			}
		} else if(action.equals("/multiLoginValidation")) {
			// 
			Date dateLog = LogManager.logMethodStart();
			String strRedirectURL = "";
			
			HttpSession alreadyLoggedInSession = null;
			
			LoginUserBean alreadyLoggedInUserBean = null, crossLoggedInUserBean = null;
			
			try {
				session = request.getSession(false);
				
				boolean bAcceptCurrentLoginSession = Boolean.parseBoolean(request.getParameter("accept"));
				
				// new login same user, crossLogin (ie.. login with other machine/browser when session already exists)
				crossLoggedInUserBean = (LoginUserBean) session.getAttribute("multi_loginuserbean");
				// removes attribute
				session.removeAttribute("multi_loginuserbean");
				
				// already logged in
				alreadyLoggedInSession = AppedoHttpSessionListener.getUserSession(crossLoggedInUserBean.getUserId()+"");
				alreadyLoggedInUserBean = (LoginUserBean) alreadyLoggedInSession.getAttribute("login_user_bean");
				
				if ( bAcceptCurrentLoginSession ) {
					// logout other session in from other browsers
					
					// Terminates another session login
					// for logout another session, to updates login_history as comment `Terminated by another session`
					LoginManager.updateLogoutHistoryComment(alreadyLoggedInUserBean.getLoginHistoryId(), "Terminated by another session login. History-Id: "+crossLoggedInUserBean.getLoginHistoryId());
					// removes alreadyLoggedUserSession
					alreadyLoggedInSession.removeAttribute("login_user_bean");
					alreadyLoggedInSession.invalidate();
					AppedoHttpSessionListener.removeSession(alreadyLoggedInUserBean.getUserId()+"");
					
					// saves new session, updates new session for which terminated from 
					// update message 
					LoginManager.updateLoginHistoryComment(crossLoggedInUserBean.getLoginHistoryId(), "Login after terminating session: "+alreadyLoggedInUserBean.getLoginHistoryId());
					// sets the new session, 
					// to display Guessed User name in /manager/html/sessions page
					session.setAttribute("username", crossLoggedInUserBean.getFirstName()+" "+crossLoggedInUserBean.getLastName());
					session.setAttribute("login_user_bean", crossLoggedInUserBean);
					// set new session, for the user maintain user's session, to avoid multiple login
					AppedoHttpSessionListener.addSession(crossLoggedInUserBean.getUserId()+"", session);
					
					strRedirectURL = "#/loginResponse";
				} else {
					// logout Current session 
					//session.removeAttribute("multi_loginuserbean");
					session.invalidate();
					
					// update Login History, as Cancel session, as session already exists.
					LoginManager.updateLogoutHistoryComment(crossLoggedInUserBean.getLoginHistoryId(), "Cancel session, as session already exists. History-Id: "+alreadyLoggedInUserBean.getLoginHistoryId());
					
					strRedirectURL = "#/login";
				}
			} catch (Exception e) {
				// Problem with services
				strRedirectURL = "#/loginResponse?_err=10";
				LogManager.errorLog(e);
			} finally {
				response.sendRedirect(strRedirectURL);
				
				LogManager.logMethodEnd(dateLog);
			}
		}
		
		
	}
}
