package com.appedo.controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;

import com.appedo.common.Constants;
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.manager.WebServiceManager;

/**
 * Servlet implementation class PaymentGetwayController
 */
@WebServlet("/PaymentGetwayController")
public class PaymentGatewayController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentGatewayController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doAction(request, response);
	}
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String strRequestAction = null;
		Integer nStatusCode = null;
		HttpClient client = new HttpClient();
		PostMethod method = null;
		Iterator<String> itrCustomData = null;
		
		LoginUserBean loginUserBean = null;
		HttpSession session = request.getSession(false);
		
		loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
		request.setAttribute("login_user_bean", loginUserBean.toJSON());
		
		// get the URI portion without Application Name
		strRequestAction = request.getRequestURI();
		strRequestAction = strRequestAction.substring( strRequestAction.indexOf("/", 1), strRequestAction.length());
		String strsendredirect = "";
				
		if(strRequestAction.endsWith("paypalCancel"))
		{
			strsendredirect = "../#/paymentResponse?payment_mode=Paypal&payment_status=cancel";
		}else{
		/*
		 * Once the Paypal payment gateway completes the process, it will be redirected here.
		 * All the Paypal parameters in the request are formed as JSON.
		 * /paymentGatewayResult is called to insert DB entry in `paypal_payment_master` with the above request-param JSON.
		 * Above request returns its PK value.
		 * Above PK & Paypal transaction-id are sent the actual license enabling service `/updateLiecnse`
		 */
		
		method = new PostMethod(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/paymentGatewayResult");
		JSONObject json = new JSONObject();
		JSONObject payment_details = new JSONObject();
		Enumeration paramNames = request.getParameterNames();
		while (paramNames.hasMoreElements()) 
		{
			String paramName = (String) paramNames.nextElement();
			String paramValue = request.getParameter(paramName);
			json.put(paramName, paramValue);
		}
		System.out.println("Paypal_Payment_Details : "+ json);
		method.setParameter("paymentResponse", json.toString());
		method.setParameter("login_user_bean", loginUserBean.toJSON());
		method.setParameter("UserId", loginUserBean.getUserId()+"");
		//method.setParameter("user_id", loginUserBean.getUserId()+"");
		
		nStatusCode = client.executeMethod(method);
		JSONObject jo = null; 
		long appedo_paypal_payment_id = 0 ;
		
		jo = JSONObject.fromObject( method.getResponseBodyAsString());
		if(jo.getString("appedo_paypal_payment_id") != null)
		{
			appedo_paypal_payment_id = Long.parseLong( jo.getString("appedo_paypal_payment_id") );
			String strPaypaltrns = json.getString("txn_id");
			payment_details.put("source", "Paypal");
			payment_details.put("paypal_txn_id", strPaypaltrns);
			payment_details.put("appedo_paypal_txn_id", appedo_paypal_payment_id);
		
			if (nStatusCode != HttpStatus.SC_OK) 
			{
				LogManager.infoLog("HTTP Failed for "+Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/paymentGatewayResult  <> StatusCode: "+nStatusCode+" <> StatusLine: "+method.getStatusLine());
			}else if( json.getString("payment_status").equalsIgnoreCase("Completed")){
				WebServiceManager wsm = new WebServiceManager();
				JSONObject joCustomData = null;
				joCustomData = JSONObject.fromObject( request.getParameter("custom") );
				itrCustomData = joCustomData.keys();
				while(itrCustomData.hasNext())
				{
					String strkey = itrCustomData.next();
					wsm.addParameter(strkey, joCustomData.getString(strkey));
				}
				wsm.addParameter("user_id", loginUserBean.getUserId()+"");
				wsm.addParameter("payment_details", payment_details.toString());
				//method.setParameter("user_id", loginUserBean.getUserId()+"");
				wsm.sendRequest(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/updateLicesense");
				String strresponse = wsm.getResponse();
				
				JSONObject jsonResponse = JSONObject.fromObject(strresponse);
				System.out.println("joResponse : "+jsonResponse);
				if(jsonResponse.getBoolean("failure") == true)
				{
					String strMessage = jsonResponse.getString("errorMessage");
					strsendredirect = "../#/paymentResponse?payment_mode=Paypal&payment_status=Error&errorMessage="+URLEncoder.encode(strMessage,"UTF-8");
					
				}else{
					strsendredirect = "../#/paymentResponse?payment_mode=Paypal&payment_status=Completed";
					
				}
			}else{
				strsendredirect = "../#/paymentResponse?payment_mode=Paypal&payment_status=pending";
				
			}
			}else{
				strsendredirect = "../#/paymentResponse?payment_mode=Paypal&payment_status=other";
			}
			response.sendRedirect(strsendredirect);
		}
	}

}
