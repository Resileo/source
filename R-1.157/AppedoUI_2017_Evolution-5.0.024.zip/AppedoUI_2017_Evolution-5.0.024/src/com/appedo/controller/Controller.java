package com.appedo.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.common.Constants;
import com.appedo.manager.AppedoConstants;
import com.appedo.manager.LogManager;
import com.appedo.manager.WebServiceManager;
import com.appedo.utils.UtilsFactory;

public class Controller extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Handles POST request
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Handles GET request comes
	 */	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Accessed in both GET and POSTrequests for the operations below, 
	 * 1. Loads agents latest build version
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		response.setContentType("text/html");
		String action = request.getServletPath();

		if(action.equals("/reloadAgentsLatestVersionAndFilePath")){
			// reload agents latest build version and agents download file path
			
			StringBuilder sbRtnAgentDetails = new StringBuilder();
			
			try {
				// loads agents latest build version and agents download file path
				Constants.loadAgentsLatestVersionAndFilePath(request);

				// html format
				sbRtnAgentDetails	.append("<B>Latest Build Version:</B> ").append(Constants.AGENT_LATEST_BUILD_VERSION).append("<BR><BR><BR>")
									.append("<B>Agents File Path:</B> ").append(Constants.COUNTER_TYPES_DOWNLOAD_FILE_PATH);
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				sbRtnAgentDetails.append("<B style=\"color: red; \">Exception occurred: "+e.getMessage()+"</B>");
			}finally {
				response.getWriter().write(sbRtnAgentDetails.toString());
				
				UtilsFactory.clearCollectionHieracy(sbRtnAgentDetails);
				sbRtnAgentDetails = null;
			}
		} else if(action.equals("/reloadConfigProperties")) {
			// to reload config and appedo_config properties 

			try {
				// Loads Constant properties
				Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);

				// Loads Appedo config properties from the system path
				Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
				
				// loads appedo constants; say loads appedoWhiteLabels, 
				Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
				
				response.getWriter().write("Loaded <B>Appedo-VelocityUI</B>, config, appedo_config properties & appedo whitelabels.");
			} catch (Exception e) {
				LogManager.errorLog(e);
				response.getWriter().write("<B style=\"color: red; \">Exception occurred Appedo-VelocityUI: "+e.getMessage()+"</B>");
			}
		} else if(action.equals("/reloadAllProjectsConfigProperties")) {
			// reload all projects config and mail properties services
			
			StringBuilder sbRtn = new StringBuilder();
			
			try {
				// Loads Constant properties
				Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);
				
				// Loads Appedo config properties from the system path
				Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
				
				// loads appedo constants; say loads appedoWhiteLabels, 
				Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
				
				sbRtn.append("Loaded <B>Appedo-VelocityUI</B>, config, appedo_config properties & appedo whitelabels.").append("<BR>");
				
				WebServiceManager wsm = new WebServiceManager();
				
				// Reloads Appedo-UI-Credential-Services
				wsm.sendRequest(Constants.APPEDO_UI_CREDENTIAL_SERVICES  + "/credentials/reloadConfigAndMailProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					//response.getWriter().write(wsm.getResponse());
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-Credential-Services</B><BR>");
				}
				
				// Reloads Appedo-UI-Log-Services
				wsm.sendRequest(Constants.APPEDO_UI_LOG_SERVICES + "/common/reloadConfigProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// Error msg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-Log-Services</B><BR>");
				}
				
				// Reloads Appedo-UI-Module-Services
				wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES + "/common/reloadConfigProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					//response.getWriter().write(wsm.getResponse());
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-Module-Services</B><BR>");
				}
				
				// Reloads Appedo-UI-RUM-Services
				wsm.sendRequest(Constants.APPEDO_UI_RUM_SERVICES + "/common/reloadConfigProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					//response.getWriter().write(wsm.getResponse());
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-RUM-Services</B><BR>");
				}
				
				// Reloads Appedo-UI-SUM-Services
				wsm.sendRequest(Constants.APPEDO_UI_SUM_SERVICES + "/common/reloadConfigProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-SUM-Services</B><BR>");
				}
				
				// Reloads Appedo-UI-LT-Services
				wsm.sendRequest(Constants.APPEDO_UI_LT_SERVICES + "/common/reloadConfigProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					//response.getWriter().write(wsm.getResponse());
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-LT-Services</B><BR>");
				}
				
				// Reloads Appedo-UI-SLA-Service
				wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES + "/common/reloadConfigAndMailProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					//response.getWriter().write(wsm.getResponse());
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-SLA-Service</B><BR>");
				}
				
				// Reloads Appedo-UI-AVM-Services
				wsm.sendRequest(Constants.APPEDO_UI_AVM_SERVICES + "/common/reloadConfigProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					//response.getWriter().write(wsm.getResponse());
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-UI-AVM-Services</B><BR>");
				}
				
				// Reloads Appedo-Resource-Shipping-Services
				wsm.sendRequest(Constants.APPEDO_URL_FILE_TRANSFER + "reloadConfigProperties", request );
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					//response.getWriter().write(wsm.getResponse());
					sbRtn.append(wsm.getResponse()).append("<BR>");
				} else {
					// errmsg for Problem with services
					sbRtn.append("<B style=\"color: red; \">Problem with Appedo-Resource-Shipping-Services</B><BR>");
				}
				
				sbRtn.append("<B>Appedo-VelocityUI's Appedo Whitelabels:</B> ").append(AppedoConstants.getAppedoWhiteLabels());
			} catch (Exception e) {
				LogManager.errorLog(e);
				sbRtn.append("<B style=\"color: red; \">Exception occurred: "+e.getMessage()+"</B>");
			} finally {
				response.getWriter().write(sbRtn.toString());
			}
		} else if(action.equals("/getAppedoWhiteLabels")) {
			// gets appedo whitelabels
			JSONObject joRtn = null;
			
			try {
				// gets appedo white lables
				if ( Constants.JO_APPEDO_WHITE_LABELS.size() == 0 ) {
					// loads appedo constants; say loads appedoWhiteLabels, 
					Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(Constants.JO_APPEDO_WHITE_LABELS);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get appedo white labels.");
			} finally {
				response.getWriter().write(joRtn.toString());
			}
		}else if(action.equals("/getGatewayDetails")) {
			// gets appedo whitelabels
			JSONObject joRtn = new JSONObject();
			JSONObject joRtn1 = new JSONObject();
			
			try {
				// gets appedo white lables
				
				joRtn1.put("Paypal_URL", Constants.PayPal_Payment_URL);
				joRtn1.put("Paypal_Business_Email_id", Constants.PayPal_Business_Email_Id);
				joRtn1.put("Paypal_Return_URL", Constants.APPEDO_URL);
				System.out.println("PayPal_Url:" + joRtn1);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtn1);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Paypal_URL.");
			} finally {
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.equals("/reloadAppedoWhiteLabels")) {

			StringBuilder sbRtnAppedoWhiteLabels = new StringBuilder();
			
			try {
				// loads appedo constants; say loads appedoWhiteLabels, 
				Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
				
				// html format
				sbRtnAppedoWhiteLabels.append("<B>Appedo WhiteLabels:</B> ").append(AppedoConstants.getAppedoWhiteLabels());
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				sbRtnAppedoWhiteLabels.append("<B style=\"color: red; \">Exception occurred: "+e.getMessage()+"</B>");
			}finally {
				response.getWriter().write(sbRtnAppedoWhiteLabels.toString());
				
				UtilsFactory.clearCollectionHieracy(sbRtnAppedoWhiteLabels);
				sbRtnAppedoWhiteLabels = null;
			}
		}
	}
}
