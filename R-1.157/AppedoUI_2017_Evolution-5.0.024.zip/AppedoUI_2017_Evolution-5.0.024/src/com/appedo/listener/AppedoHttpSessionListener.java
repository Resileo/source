package com.appedo.listener;

import java.util.HashMap;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.common.Constants;
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.manager.WebServiceManager;
import com.appedo.utils.UtilsFactory;


/**
 * Do the relative operation on Login & Logout.
 * Maintains and process the active sessions.
 * 
 * @author Venkateswaran
 *
 */
public class AppedoHttpSessionListener implements HttpSessionListener {
	
	// To maintain all active sessions of this application
	// all user's session is maintaining in hashmap, to avoid same user multiple login from different machine/browser
	private static HashMap<String, HttpSession> hmSessionsList = new HashMap<String, HttpSession>();
	
	
	/**
	 * Receives notification that a session has been created.
	 */
	public void sessionCreated(HttpSessionEvent se) {
		
		try {
			// TODO Keep the sessions in a DataStructure
			// HttpSession session = se.getSession();
			
			LogManager.infoLog("---------- sessionCreated ------------");
			LogManager.infoLog("Sesion Created: "+hmSessionsList);
			
		} catch(Exception e) {
			LogManager.errorLog(e);
		}
	}
	
	/**
	 * Receives notification that a session is about to be invalidated.
	 */
	public void sessionDestroyed(HttpSessionEvent se) {
		LoginUserBean loginUserBean = null;
		WebServiceManager wsm = null;
		JSONObject joResponse = null;
		
		try {
			HttpSession session = se.getSession();
			//UtilsFactory.clearAllSession( session );
			loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
			
			if( loginUserBean != null ) {
				// removes user's session on timeout, maintaining to avoid multiple login
				removeSession(loginUserBean.getUserId()+"");
				
				wsm = new WebServiceManager();
				wsm.addParameter("lLoginHistoryId", loginUserBean.getLoginHistoryId()+"");
				wsm.sendRequest(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/timeOutSession");
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					joResponse = JSONObject.fromObject(wsm.getResponse());
				} else {
					throw new Exception("1");	// TODO Inform that Service has problem
				}
				
				if( joResponse.getBoolean("success") ) {
					LogManager.infoLog("Successfully updated in login histroy for Session Time Out");
				} else {
					LogManager.infoLog("Unable to update in login histroy for Session Time Out. History-Id: "+loginUserBean.getLoginHistoryId());
				}
				
		        LogManager.infoLog("---------- sessionDestroyed ------------");
			}
			LogManager.infoLog("Session Destroyed: "+hmSessionsList);
		}catch(Exception e){
			LogManager.errorLog(e);
		} finally {
			loginUserBean = null;
			
			if ( wsm != null ) {
				wsm.destory();
				wsm = null;	
			}
			
			UtilsFactory.clearCollectionHieracy(joResponse);
			joResponse = null;
		}
	}
	
	/**
	 * adds user session
	 * 
	 * @param strUserId
	 * @param session
	 */
	public synchronized static void addSession(String strUserId, HttpSession session) {
		hmSessionsList.put(strUserId, session);
	}
	
	/**
	 * removes user session
	 * 
	 * @param strUserId
	 */
	public synchronized static void removeSession(String strUserId) {
		hmSessionsList.remove(strUserId);
	}
	
	/**
	 * to check user has already login
	 * 
	 * @param strUserId
	 * @return
	 */
	public static boolean isSessionExists(String strUserId) {
		return hmSessionsList.containsKey(strUserId);
	}
	
	/**
	 * gets user session
	 * 
	 * @param strUserId
	 * @return
	 */
	public static HttpSession getUserSession(String strUserId) {
		return hmSessionsList.get(strUserId);
	}
}
