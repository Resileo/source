package com.appedo.servlet;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;

import com.appedo.common.Constants;
import com.appedo.manager.LogManager;
import com.appedo.utils.UtilsFactory;


/**
 * Servlet to compress and download agent 
 * @author navin
 *
 */
public class DownloadXlsFile extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * Accessed for both GET and POST,
	 * Downloads the agent by adds to TAR archive and compressed gziped 
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		
		String strActionCommand = request.getRequestURI();
		HttpSession session = request.getSession(false);
		if ( session == null || session.getAttribute("login_user_bean") == null ) {
			throw new ServletException("SESSION_EXPIRED");
		}
		if(strActionCommand.endsWith("/xls/downloadContainer")) {
			Date dateLog = LogManager.logMethodStart();
			FileInputStream fis =null;
            BufferedOutputStream output =null;
			PostMethod method = null;
			BufferedInputStream bis = null;
			try{
				String dataContent =request.getParameter("dataContent");
				String reportName =request.getParameter("reportName");
				String reportStatus =request.getParameter("reportStatus");
				String runStartTime =request.getParameter("runStartTime");
				String runEndTime =request.getParameter("runEndTime");
				String runTime =request.getParameter("runTime");
				String reportId =request.getParameter("reportId");
				String scriptId =request.getParameter("scriptId");
				
				String outputFilePath=null;
				String filename = null;
				filename = "lt_script_contwise_"+reportId+"_"+scriptId+".xls";
				String downloadFilename = null;
				downloadFilename = reportName+"_ContainerWise_Report.xls";
				downloadFilename = downloadFilename.replaceAll("[!@#$%^&*]", "");
				downloadFilename = downloadFilename.replaceAll("\\s", "_");
				outputFilePath = Constants.SUMMARYREPORTPATH_SHIPPING+reportId;
				
				if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
					fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
	                bis = new BufferedInputStream(fis);
					response.setContentType("text/xls");
					response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
					output = new BufferedOutputStream(response.getOutputStream());
	                for (int data; (data = bis.read()) > -1;)
	                {
	                	output.write(data);
	                }
				}else{
					method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"writeContainerXlsFile");
					method.addParameter("dataContent", dataContent);
					method.addParameter("reportName", reportName);
					method.addParameter("reportStatus", reportStatus);
					method.addParameter("runStartTime", runStartTime);
					method.addParameter("runEndTime", runEndTime);
					method.addParameter("runTime", runTime);
					method.addParameter("filePath", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
					method.addParameter("overwrite", "true");
					method.setRequestHeader("Connection", "close");
					if(UtilsFactory.createFileFileForShipping(method)){
						fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
		                bis = new BufferedInputStream(fis);
						response.setContentType("text/xls");
						response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
						output = new BufferedOutputStream(response.getOutputStream());
		                for (int data; (data = bis.read()) > -1;)
		                {
		                	output.write(data);
		                }
					}else{
						LogManager.errorLog("Problem in downloadContainer ");
					}
				}
			} catch(Exception e) {
				e.printStackTrace();
				LogManager.errorLog("Exception in downloadContainer: "+e.getMessage());
			} finally {
				if(method!=null){
					method.releaseConnection();
					method = null;
				}
				if(fis!=null){
				    fis.close();
				}
				if(bis!=null){
				    bis.close();
				}
				output.flush();
				LogManager.logMethodEnd(dateLog);
			}
		}else if(strActionCommand.endsWith("/xls/downloadTransaction")) {
			Date dateLog = LogManager.logMethodStart();
			FileInputStream fis =null;
            BufferedOutputStream output =null;
			PostMethod method = null;
			BufferedInputStream bis = null;
			try{
				String dataContent =request.getParameter("dataContent");
				String reportName =request.getParameter("reportName");
				String reportStatus =request.getParameter("reportStatus");
				String runStartTime =request.getParameter("runStartTime");
				String runEndTime =request.getParameter("runEndTime");
				String runTime =request.getParameter("runTime");
				String reportId =request.getParameter("reportId");
				String scriptId =request.getParameter("scriptId");
				
				String outputFilePath=null;
				String filename = null;
				filename = "lt_transaction_summary_"+reportId+"_"+scriptId+".xls";
				String downloadFilename = null;
				downloadFilename = reportName+"_TransactionWise_Report.xls";
				downloadFilename = downloadFilename.replaceAll("[!@#$%^&*]", "");
				downloadFilename = downloadFilename.replaceAll("\\s", "_");
				outputFilePath = Constants.SUMMARYREPORTPATH_SHIPPING+reportId;

				if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
					fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
	                bis = new BufferedInputStream(fis);
					response.setContentType("text/xls");
					response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
					output = new BufferedOutputStream(response.getOutputStream());
	                for (int data; (data = bis.read()) > -1;)
	                {
	                	output.write(data);
	                }
				}else{
					method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"writeTransactionXlsFile");
					method.addParameter("dataContent", dataContent);
					method.addParameter("reportName", reportName);
					method.addParameter("reportStatus", reportStatus);
					method.addParameter("runStartTime", runStartTime);
					method.addParameter("runEndTime", runEndTime);
					method.addParameter("runTime", runTime);
					method.addParameter("filePath", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
					method.addParameter("overwrite", "true");
					method.setRequestHeader("Connection", "close");
					if(UtilsFactory.createFileFileForShipping(method)){
						fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
		                bis = new BufferedInputStream(fis);
						response.setContentType("text/xls");
						response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
						output = new BufferedOutputStream(response.getOutputStream());
		                for (int data; (data = bis.read()) > -1;)
		                {
		                	output.write(data);
		                }
					}else{
						LogManager.errorLog("Problem in downloadTransaction ");
					}
				}
			} catch(Exception e) {
				e.printStackTrace();
				LogManager.errorLog("Exception in downloadTransaction: "+e.getMessage());
			} finally {
				if(method!=null){
					method.releaseConnection();
					method = null;
				}
				if(fis!=null){
				    fis.close();
				} 
				if( bis != null ){
					bis.close();
				}
				output.flush();
				LogManager.logMethodEnd(dateLog);
			}
		}else if(strActionCommand.endsWith("/xls/downloadScenario")) {
			Date dateLog = LogManager.logMethodStart();
			FileInputStream fis =null;
            BufferedOutputStream output =null;
            BufferedInputStream bis = null;
			
			HttpClient client = null;
			PostMethod method = null;
			String responseStream = null;
			JSONArray joDataArray = new JSONArray();
			JSONObject joData = null,joChildData=null,joScriptContent=null;
			JSONArray jaScriptContent = null;
			int statusCode=0;
			try{
				String summaryContent =request.getParameter("summaryContent");
				String scriptContent =request.getParameter("scriptContent");
				String reportName =request.getParameter("reportName");
				String reportStatus =request.getParameter("reportStatus");
				String runStartTime =request.getParameter("runStartTime");
				String runEndTime =request.getParameter("runEndTime");
				String runTime =request.getParameter("runTime");
				String reportId =request.getParameter("reportId");
				String loadTestType =request.getParameter("loadTestType");
				
				String outputFilePath=null;
				String filename = null;
				filename = "lt_scenario_summary_"+reportId+".xls";
				String downloadFilename = null;
				downloadFilename = reportName+"_ScriptWise_Report.xls";
				downloadFilename = downloadFilename.replaceAll("[!@#$%^&*]", "");
				downloadFilename = downloadFilename.replaceAll("\\s", "_");
				outputFilePath = Constants.SUMMARYREPORTPATH_SHIPPING+reportId;
				
				jaScriptContent = JSONArray.fromObject(request.getParameter("scriptContent"));
				client = new HttpClient();
				for(int i=0;i<jaScriptContent.size(); i++){
					joScriptContent = jaScriptContent.getJSONObject(i);
					joChildData = new JSONObject();
					joData = new JSONObject();
					
					statusCode=0;
					responseStream = null;
					method = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getChildSummaryReportScriptWise");
					method.addParameter("runid", reportId);
					method.addParameter("testTypeScript", loadTestType);
					method.addParameter("scriptId", joScriptContent.getString("scriptId"));
					method.addParameter("reportType", Constants.CONTAINER_RESPONSE);
					method.setRequestHeader("Connection", "close");
					statusCode = client.executeMethod(method);
					LogManager.errorLog("statusCode: "+statusCode);
					if (statusCode != HttpStatus.SC_OK) {
						LogManager.errorLog("Method failed- /lt/getChildSummaryReportScriptWise - "+reportId+"/"+loadTestType+"/"+joScriptContent.getString("scriptId")+"/"+Constants.CONTAINER_RESPONSE+"/"+" : " + method.getStatusLine());
					}
					responseStream = method.getResponseBodyAsString();
					if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
						JSONObject joResponse = JSONObject.fromObject(responseStream);
						if( joResponse.getBoolean("success") ) {
							joResponse = JSONObject.fromObject(joResponse.get("message"));
							joChildData.put(Constants.CONTAINER_RESPONSE, joResponse.get("summaryData"));
						} else {
							if( joResponse.containsKey("errorMessage") ) {
								throw new Exception( joResponse.getString("errorMessage") );
							}
						}
					}
					
					statusCode=0;
					responseStream = null;
					method = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getChildSummaryReportScriptWise");
					method.addParameter("runid", reportId);
					method.addParameter("testTypeScript", loadTestType);
					method.addParameter("scriptId", joScriptContent.getString("scriptId"));
					method.addParameter("reportType", Constants.TRANSACTION_RESPONSE);
					method.setRequestHeader("Connection", "close");
					statusCode = client.executeMethod(method);
					LogManager.errorLog("statusCode: "+statusCode);
					if (statusCode != HttpStatus.SC_OK) {
						LogManager.errorLog("Method failed- /lt/getChildSummaryReportScriptWise - "+reportId+"/"+loadTestType+"/"+joScriptContent.getString("scriptId")+"/"+Constants.TRANSACTION_RESPONSE+"/"+" : " + method.getStatusLine());
					}
					responseStream = method.getResponseBodyAsString();
					if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
						JSONObject joResponse = JSONObject.fromObject(responseStream);
						if( joResponse.getBoolean("success") ) {
							joResponse = JSONObject.fromObject(joResponse.get("message"));
							joChildData.put(Constants.TRANSACTION_RESPONSE, joResponse.get("summaryData"));
						} else {
							if( joResponse.containsKey("errorMessage") ) {
								throw new Exception( joResponse.getString("errorMessage") );
							}
						}
					}
					joData.put("scriptId", joScriptContent.getString("scriptId"));
					joData.put("dataContent", joChildData);
					joDataArray.add(joData);
				}
				
				if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
					fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
	                bis = new BufferedInputStream(fis);
					response.setContentType("text/xls");
					response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
					output = new BufferedOutputStream(response.getOutputStream());
	                for (int data; (data = bis.read()) > -1;)
	                {
	                	output.write(data);
	                }
				}else{
					method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"writeScenarioXlsFile");
					method.addParameter("summaryContent", summaryContent);
					method.addParameter("scriptContent", scriptContent);
					method.addParameter("containerAndTransactionContent", joDataArray.toString());
					method.addParameter("reportName", reportName);
					method.addParameter("reportStatus", reportStatus);
					method.addParameter("runStartTime", runStartTime);
					method.addParameter("runEndTime", runEndTime);
					method.addParameter("runTime", runTime);
					method.addParameter("filePath", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
					method.addParameter("overwrite", "true");
					method.setRequestHeader("Connection", "close");
					if(UtilsFactory.createFileFileForShipping(method)){
						fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
		                bis = new BufferedInputStream(fis);
						response.setContentType("text/xls");
						response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
						output = new BufferedOutputStream(response.getOutputStream());
		                for (int data; (data = bis.read()) > -1;)
		                {
		                	output.write(data);
		                }
					}else{
						LogManager.errorLog("Problem in downloadScenario ");
					}
				}
			} catch(Exception e) {
				e.printStackTrace();
				LogManager.errorLog("Exception in downloadScenario: "+e.getMessage());
			} finally {
				if(method!=null){
					method.releaseConnection();
					method = null;
				}
				if(fis!=null){
				    fis.close();
				}
				if( bis != null ){
					bis.close();
				}
				output.flush();
				LogManager.logMethodEnd(dateLog);
			}
		}
	}
}
