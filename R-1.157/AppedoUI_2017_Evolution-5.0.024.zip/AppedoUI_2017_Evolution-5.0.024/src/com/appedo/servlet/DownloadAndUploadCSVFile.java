package com.appedo.servlet;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.appedo.common.Constants;
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.manager.WebServiceManager;
import com.appedo.utils.UtilsFactory;

/**
 * Servlet to compress and download agent 
 * @author navin
 */
public class DownloadAndUploadCSVFile extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * Accessed for both GET and POST,
	 * Downloads the agent by adds to TAR archive and compressed gziped 
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		
		String strActionCommand = request.getRequestURI();
		HttpSession session = request.getSession(false);
		
		if(strActionCommand.endsWith("/csv/downloadVariable")) {
			String strFileName = null, strContent = null;
			ServletOutputStream sos = null;
			byte[]  byteContent = null;
			
			LoginUserBean loginUserBean = null;
			try{
				
				loginUserBean = new LoginUserBean();
				loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
				strFileName = request.getParameter("name")+".csv";
//				strContent = request.getParameter("content").replaceAll("<br/>", "\r\n");
//				strContent = request.getParameter("content").replaceAll("<br/>", "\r\n");
				
				String strvariablespath = Constants.VARIABLESFOLDERPATH+File.separator+loginUserBean.getUserId()+"_variables.xml";
				
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(strvariablespath);
				
				NodeList variablelist = doc.getElementsByTagName("variable");
				for(int j=0; j<variablelist.getLength(); j++){
					Node nNode = variablelist.item(j);
					
					NamedNodeMap attr = nNode.getAttributes();
					if(attr.getNamedItem("name").getNodeValue().equalsIgnoreCase(request.getParameter("name"))){
						NodeList list = nNode.getChildNodes();
						for (int i = 0; i < list.getLength(); i++) {
							 
							Node node = list.item(i);
				 
						   // get the content element, and update the value
						   if ("content".equals(node.getNodeName())) {
							   strContent = node.getTextContent();
							   strContent = strContent.replaceAll("\r", "");
							   strContent = strContent.replaceAll("\n", "\r\n");
						   }
						}
					}
				}
				
				
				sos = response.getOutputStream();
				response.setContentType("text/csv");
				response.setHeader("Content-Disposition", "attachment; fileName=\""+strFileName+"\"");
				
				byteContent = strContent.getBytes();
				sos.write(byteContent, 0, byteContent.length);
				
			}catch(Exception e){
				LogManager.errorLog(e);
				e.printStackTrace();
			}
		}else if(strActionCommand.endsWith("/csv/downloadCounterData")) {
			String strFileName = null, strContent = null;
			ServletOutputStream sos = null;
			byte[]  byteContent = null;
			
			DateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
			JSONArray jaChartData = null;
			JSONObject joData = null, joChart = null;
			try{
				
				WebServiceManager wsm = new WebServiceManager();
				wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES + "/apmCounters/getCSVChartdata", request);
				
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					joData = JSONObject.fromObject(wsm.getResponse());
					strContent = "Module Type,"+joData.getString("module_code")+"\nModule Name,"+joData.getString("module_name")+"\nCounter Name,"+request.getParameter("countername")+"\n\nTime Stamp in UTC,Value"+(joData.getString("units")!=null?(joData.getString("units").length()>0?" in "+joData.getString("units")+"\n":""):"");
					jaChartData = joData.getJSONArray("data");
					for(int i=0; i<jaChartData.size(); i++) {
						joChart = jaChartData.getJSONObject(i);
						
						strContent = strContent+format.format(new Date(joChart.getLong("received_on")))+","+joChart.getLong("counter_value")+"\n";
					}
				} else {
					strContent = "Problem with Services";
				}
				
				strFileName = joData.getString("module_code")+"_"+joData.getString("module_name")+"_"+request.getParameter("countername").replaceAll("%", "Percentage")+".csv";
				strFileName = strFileName.replaceAll("(!|@|#|$|%|^|&)", "");
				
				sos = response.getOutputStream();
				response.setContentType("text/csv");
				response.setHeader("Content-Disposition", "attachment; fileName=\""+strFileName+"\"");
				
				byteContent = strContent.getBytes();
				sos.write(byteContent, 0, byteContent.length);
				
			}catch(Exception e){
				LogManager.errorLog(e);
				e.printStackTrace();
			}
		} else if(strActionCommand.endsWith("/csv/downloadLtLogData")) {
			String strFileName = null, strContent = null;
			ServletOutputStream sos = null;
			byte[]  byteContent = null;
			
			DateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
			JSONArray jaChartData = null;
			JSONObject joDetail = null, joData = null, joChart = null;
			try{
				joDetail = new JSONObject();
				joDetail.put("reportname", request.getParameter("reportname"));
				joDetail.put("runid", request.getParameter("runid"));
				 
				
				WebServiceManager wsm = new WebServiceManager();
				wsm.sendRequest(Constants.APPEDO_UI_LT_SERVICES + "/lt/getCSVlogReportdata", request);

				joData = JSONObject.fromObject(wsm.getResponse());
				LogManager.infoLog(joData.toString());
				
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					
					strFileName = joDetail.getString("reportname")+"_"+joDetail.getString("runid")+".csv";
					
					strContent = "Report Name,"+joDetail.getString("reportname")+"\n"+"Report Id,"+joDetail.getString("runid")+"\n\n"+"Log Time in UTC,Load Generator,Script Name,Vuser Id,Iteration,Log Details"+"\n";
					jaChartData = joData.getJSONArray("message");
					for(int i=0; i<jaChartData.size(); i++) {
						joChart = jaChartData.getJSONObject(i);
						
						strContent = strContent+format.format(new Date(joChart.getLong("log_time")))+","+joChart.getString("loadgen")+","+joChart.getString("scriptname")+","+joChart.getLong("user_id")+","+joChart.getLong("iteration_id")+","+joChart.getString("message")+"\n";
					}
				} else {
					strContent = "Problem with Services";
				}
				
				strFileName = strFileName.replaceAll("(!|@|#|$|%|^|&)", "");
				
				sos = response.getOutputStream();
				response.setContentType("text/csv");
				response.setHeader("Content-Disposition", "attachment; fileName=\""+strFileName+"\"");
				
				byteContent = strContent.getBytes();
				sos.write(byteContent, 0, byteContent.length);
				
			}catch(Exception e){
				LogManager.errorLog(e);
				e.printStackTrace();
			}
		} else if(strActionCommand.endsWith("/csv/downloadCounterDataWithDateRange")) {
			String strFileName = null, strContent = null;
			ServletOutputStream sos = null;
			byte[]  byteContent = null;
			
			DateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
			JSONArray jaChartData = null;
			JSONObject joData = null, joChart = null;
			
			try{
				WebServiceManager wsm = new WebServiceManager();
				wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES + "/apmCounters/getCSVChartdataWithDateRange", request );
				
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					joData = JSONObject.fromObject(wsm.getResponse());
					strContent = "Module Type,"+joData.getString("module_code")+"\nModule Name,"+joData.getString("module_name")+"\nCounter Name,"+request.getParameter("countername")+"\n\nTime Stamp in UTC,Value"+(joData.getString("units")!=null?(joData.getString("units").length()>0?" in "+joData.getString("units")+"\n":""):"");
					jaChartData = joData.getJSONArray("data");
					for(int i=0; i<jaChartData.size(); i++){
						joChart = jaChartData.getJSONObject(i);
						
						strContent = strContent+format.format(new Date(joChart.getLong("received_on")))+","+joChart.getLong("counter_value")+"\n";
					}
				} else {
					strContent = "Problem with Services";
				}
				
				strFileName = joData.getString("module_code")+"_"+joData.getString("module_name")+"_"+request.getParameter("countername").replaceAll("%", "Percentage")+".csv";
				strFileName = strFileName.replaceAll("(!|@|#|$|%|^|&)", "");
				
				sos = response.getOutputStream();
				response.setContentType("text/csv");
				response.setHeader("Content-Disposition", "attachment; fileName=\""+strFileName+"\"");
				
				byteContent = strContent.getBytes();
				sos.write(byteContent, 0, byteContent.length);
				
			}catch(Exception e){
				LogManager.errorLog(e);
				e.printStackTrace();
			}
		} else if(strActionCommand.endsWith("/csv/downloadSciptRequestWiseResponseReport")) {
			// download summary report's script's Request wise response in CSV 
			String strFileName = null;
			ServletOutputStream sos = null;
			byte[]  byteContent = null;
			
			LoginUserBean loginUserBean = null;
			
			StringBuilder sbCSVData = new StringBuilder();
			
			JSONObject joResp = null, joRequestWiseReportDatum = null;
			JSONArray jaRequestWiseReportData = null;
			
			WebServiceManager wsm = null;
			
			String strScenarioName = "", strReportName = "", strScriptName = "", strRunStartTime = "", strRunEndTime = "", strRunDuration = "", strRunId = "", strScriptId = "";
			
			try {
				strScenarioName = request.getParameter("scenarioName");
				strReportName = request.getParameter("reportName");
				strScriptName = request.getParameter("scriptName");
				strRunStartTime = request.getParameter("runStartTime");
				strRunEndTime = request.getParameter("runEndTime");
				strRunDuration = request.getParameter("runTime");
				
				strRunId = request.getParameter("runId");
				strScriptId = request.getParameter("scriptId");
				
				loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
				
				strFileName = strReportName +"_"+ strScriptName + "_Request_Wise_Response_Report.csv";
				
				wsm = new WebServiceManager();
				wsm.addParameter("login_user_bean", loginUserBean.toJSON());
				wsm.addParameter("runid", strRunId);
				wsm.addParameter("scriptId", strScriptId);
				wsm.addParameter("reportType", "requestResponse");
				wsm.addParameter("testTypeScript", "APPEDO_LT");
				
				// web service request
				wsm.sendRequest(Constants.APPEDO_UI_LT_SERVICES + "/lt/getChildSummaryReportScriptWise");
				if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
					// success
					joResp = JSONObject.fromObject(wsm.getResponse());
				} else {
					//throw new Exception("Problem with LT Services");
					sbCSVData.append("Problem with LT Services");
				}
				
				if ( ! joResp.getBoolean("success") ) {
					// err
					sbCSVData.append(joResp.getString("errorMessage"));
				} else {
					jaRequestWiseReportData = joResp.getJSONObject("message").getJSONArray("summaryData");
					
					// format CSV
					sbCSVData.append("Script's Request wise response report\n")
							.append("Report Name,").append(strReportName).append("\n")
							.append("Scenario Name,").append(strScenarioName).append("\n")
							.append("Script Name,").append(strScriptName).append("\n")
							.append("Run start time,").append(strRunStartTime).append("\n")
							.append("Run end time,").append(strRunEndTime).append("\n")
							.append("Run duration,").append(strRunDuration).append("\n").append("\n")
							// cols 
							.append("Container Name,Address,Hits,Throughput(mb),Min(ms),Avg(ms),Max(ms),Error 400,Error 500,Error Others\n");
					
					// data as CSV
					for(int i = 0; i < jaRequestWiseReportData.size(); i = i + 1) {
						joRequestWiseReportDatum = jaRequestWiseReportData.getJSONObject(i);
						sbCSVData.append("\"").append(joRequestWiseReportDatum.getString("containerName")).append("\"").append(",")
								.append("\"").append(joRequestWiseReportDatum.getString("address")).append("\"").append(",")
								.append(joRequestWiseReportDatum.getString("hits")).append(",")
								.append(joRequestWiseReportDatum.getString("tPutInMb")).append(",")
								.append(joRequestWiseReportDatum.getString("minInMs")).append(",")
								.append(joRequestWiseReportDatum.getString("avgInMs")).append(",")
								.append(joRequestWiseReportDatum.getString("maxInMs")).append(",")
								.append(joRequestWiseReportDatum.getString("error400")).append(",")
								.append(joRequestWiseReportDatum.getString("error500")).append(",")
								.append(joRequestWiseReportDatum.getString("error700")).append("\n");
					}
				}
				
				sos = response.getOutputStream();
				response.setContentType("text/csv");
				response.setHeader("Content-Disposition", "attachment; fileName=\""+strFileName+"\"");
				
				byteContent = sbCSVData.toString().getBytes();
				sos.write(byteContent, 0, byteContent.length);
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				if ( wsm != null ) {
					wsm.destory();
				}
				wsm = null;
				
				UtilsFactory.close(sos);
				sos = null;
				
				byteContent = null;
				
				UtilsFactory.clearCollectionHieracy(sbCSVData);
				sbCSVData = null;
				UtilsFactory.clearCollectionHieracy(jaRequestWiseReportData);
				jaRequestWiseReportData = null;
				
				loginUserBean = null;
				
				strScenarioName = null;
				strReportName = null;
				strScriptName = null;
				strRunStartTime = null;
				strRunEndTime = null;
				strRunDuration = null;
				strRunId = null;
				strScriptId = null;
			}
		}
	}
}
