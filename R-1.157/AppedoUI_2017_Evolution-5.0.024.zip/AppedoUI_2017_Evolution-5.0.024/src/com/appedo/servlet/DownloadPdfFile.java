package com.appedo.servlet;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;

import com.appedo.common.Constants;
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.utils.UtilsFactory;

public class DownloadPdfFile  extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * Accessed for both GET and POST,
	 * Downloads the agent by adds to TAR archive and compressed gziped 
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		
		String strActionCommand = request.getRequestURI();
		HttpSession session = request.getSession(false);
		LoginUserBean loginUserBean = null;

		if ( session == null || session.getAttribute("login_user_bean") == null ) {
			throw new ServletException("SESSION_EXPIRED");
		}
		
		loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");

		if(strActionCommand.endsWith("/pdf/downloadScenario")) {
			Date dateLog = LogManager.logMethodStart();
			FileInputStream fis =null;
            BufferedOutputStream output =null;
			
			HttpClient client = null;
			PostMethod method = null,methodASD = null, methodSetting = null;
			String responseStream = null;
			JSONObject joScriptContent=null,joSummaryContent=null,joFinalContent=null;
			JSONArray jaScriptContent = null,jaNewScriptContent=null;
			int statusCode=0;
			BufferedInputStream bis = null;
			try{
				String summaryContent =request.getParameter("summaryContent");
				String reportName =request.getParameter("reportName");
				String reportStatus =request.getParameter("reportStatus");
				String runStartTime =request.getParameter("runStartTime");
				String runEndTime =request.getParameter("runEndTime");
				String runTime =request.getParameter("runTime");
				String reportId =request.getParameter("reportId");
				String loadTestType =request.getParameter("loadTestType");
				String runEpochStartTime =request.getParameter("runEpochStartTime");
				String runEpochEndTime =request.getParameter("runEpochEndTime");
				String runEpochTime =request.getParameter("runEpochTime");
				String selectedTime =request.getParameter("selectedTime");
				String queryDuration =request.getParameter("queryDuration");
				String d3XaixsFormatForPdf =request.getParameter("d3XaixsFormatForPdf");
				String guid =request.getParameter("guid");
				
				
//				LogManager.infoLog("summaryContent 		: "+summaryContent   );
//				LogManager.infoLog("reportName 		    : "+reportName 		 );
//				LogManager.infoLog("reportStatus 	    : "+reportStatus 	 );
//				LogManager.infoLog("runStartTime 	    : "+runStartTime 	 );
//				LogManager.infoLog("runEndTime 		    : "+runEndTime 		 );
//				LogManager.infoLog("runTime 			: "+runTime 		 );
//				LogManager.infoLog("reportId 		    : "+reportId 		 );
//				LogManager.infoLog("loadTestType 	    : "+loadTestType 	 );
//				LogManager.infoLog("runEpochStartTime   : "+runEpochStartTime);
//				LogManager.infoLog("runEpochEndTime 	: "+runEpochEndTime  );
//				LogManager.infoLog("runEpochTime 	    : "+runEpochTime 	 );
//				LogManager.infoLog("selectedTime 	    : "+selectedTime 	 );
//				LogManager.infoLog("queryDuration 	    : "+queryDuration 	 );
//				LogManager.infoLog("guid 	    : "+guid 	 );

				String outputFilePath=null;
				String filename = null;
				filename = "lt_scenario_summary_"+reportId+".pdf";
				String downloadFilename = null;
				downloadFilename = reportName+"_ScriptWise_Report.pdf";
				downloadFilename = downloadFilename.replaceAll("[!@#$%^&*]", "");
				downloadFilename = downloadFilename.replaceAll("\\s", "_");
				outputFilePath = Constants.SUMMARYREPORTPATH_SHIPPING+reportId;
				
				joFinalContent = new JSONObject();
				joFinalContent.put("reportName", reportName);
				joFinalContent.put("reportStatus", reportStatus);
				joFinalContent.put("runStartTime", runStartTime);
				joFinalContent.put("runEndTime", runEndTime);
				joFinalContent.put("runTime", runTime);
				joFinalContent.put("reportId", reportId);
				joFinalContent.put("loadTestType", loadTestType);
				
				jaScriptContent = JSONArray.fromObject(request.getParameter("scriptContent"));
				joSummaryContent = JSONObject.fromObject(summaryContent);
				jaNewScriptContent = new JSONArray();
				client = new HttpClient();
				for(int i=0;i<jaScriptContent.size(); i++){
					joScriptContent = jaScriptContent.getJSONObject(i);
					statusCode=0;
					responseStream = null;
					method = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getChildSummaryReportScriptWise");
					method.addParameter("runid", reportId);
					method.addParameter("testTypeScript", loadTestType);
					method.addParameter("scriptId", joScriptContent.getString("scriptId"));
					method.addParameter("reportType", Constants.CONTAINER_RESPONSE);
					method.setRequestHeader("Connection", "close");
					statusCode = client.executeMethod(method);
					LogManager.errorLog("statusCode: "+statusCode);
					if (statusCode != HttpStatus.SC_OK) {
						LogManager.errorLog("Method failed- /lt/getChildSummaryReportScriptWise - "+reportId+"/"+loadTestType+"/"+joScriptContent.getString("scriptId")+"/"+Constants.CONTAINER_RESPONSE+"/"+" : " + method.getStatusLine());
					}
					responseStream = method.getResponseBodyAsString();
					if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
						JSONObject joResponse = JSONObject.fromObject(responseStream);
						if( joResponse.getBoolean("success") ) {
							joResponse = JSONObject.fromObject(joResponse.get("message"));
							joScriptContent.put(Constants.CONTAINER_RESPONSE, joResponse.get("summaryData"));
						} else {
							if( joResponse.containsKey("errorMessage") ) {
								throw new Exception( joResponse.getString("errorMessage") );
							}
						}
					}
					
					statusCode=0;
					responseStream = null;
					method = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getChildSummaryReportScriptWise");
					method.addParameter("runid", reportId);
					method.addParameter("testTypeScript", loadTestType);
					method.addParameter("scriptId", joScriptContent.getString("scriptId"));
					method.addParameter("reportType", Constants.TRANSACTION_RESPONSE);
					method.setRequestHeader("Connection", "close");
					statusCode = client.executeMethod(method);
					LogManager.errorLog("statusCode: "+statusCode);
					if (statusCode != HttpStatus.SC_OK) {
						LogManager.errorLog("Method failed- /lt/getChildSummaryReportScriptWise - "+reportId+"/"+loadTestType+"/"+joScriptContent.getString("scriptId")+"/"+Constants.TRANSACTION_RESPONSE+"/"+" : " + method.getStatusLine());
					}
					responseStream = method.getResponseBodyAsString();
					if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
						JSONObject joResponse = JSONObject.fromObject(responseStream);
						if( joResponse.getBoolean("success") ) {
							joResponse = JSONObject.fromObject(joResponse.get("message"));
							joScriptContent.put(Constants.TRANSACTION_RESPONSE, joResponse.get("summaryData"));
						} else {
							if( joResponse.containsKey("errorMessage") ) {
								throw new Exception( joResponse.getString("errorMessage") );
							}
						}
					}

					statusCode=0;
					responseStream = null;
					method = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getChildSummaryReportScriptWise");
					method.addParameter("runid", reportId);
					method.addParameter("testTypeScript", loadTestType);
					method.addParameter("scriptId", joScriptContent.getString("scriptId"));
					method.addParameter("reportType", Constants.REQUEST_RESPONSE);
					method.setRequestHeader("Connection", "close");
					statusCode = client.executeMethod(method);
					LogManager.errorLog("statusCode: "+statusCode);
					if (statusCode != HttpStatus.SC_OK) {
						LogManager.errorLog("Method failed- /lt/getChildSummaryReportScriptWise - "+reportId+"/"+loadTestType+"/"+joScriptContent.getString("scriptId")+"/"+Constants.REQUEST_RESPONSE+"/"+" : " + method.getStatusLine());
					}
					responseStream = method.getResponseBodyAsString();
					if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
						JSONObject joResponse = JSONObject.fromObject(responseStream);
						if( joResponse.getBoolean("success") ) {
							joResponse = JSONObject.fromObject(joResponse.get("message"));
							joScriptContent.put(Constants.REQUEST_RESPONSE, joResponse.get("summaryData"));
						} else {
							if( joResponse.containsKey("errorMessage") ) {
								throw new Exception( joResponse.getString("errorMessage") );
							}
						}
					}

					statusCode=0;
					responseStream = null;
					method = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getChildSummaryReportScriptWise");
					method.addParameter("runid", reportId);
					method.addParameter("testTypeScript", loadTestType);
					method.addParameter("scriptId", joScriptContent.getString("scriptId"));
					method.addParameter("reportType", Constants.ERROR_DESCRIPTION);
					method.setRequestHeader("Connection", "close");
					statusCode = client.executeMethod(method);
					LogManager.errorLog("statusCode: "+statusCode);
					if (statusCode != HttpStatus.SC_OK) {
						LogManager.errorLog("Method failed- /lt/getChildSummaryReportScriptWise - "+reportId+"/"+loadTestType+"/"+joScriptContent.getString("scriptId")+"/"+Constants.ERROR_DESCRIPTION+"/"+" : " + method.getStatusLine());
					}
					responseStream = method.getResponseBodyAsString();
					if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
						JSONObject joResponse = JSONObject.fromObject(responseStream);
						if( joResponse.getBoolean("success") ) {
							joResponse = JSONObject.fromObject(joResponse.get("message"));
							joScriptContent.put(Constants.ERROR_DESCRIPTION, joResponse.get("summaryData"));
						} else {
							if( joResponse.containsKey("errorMessage") ) {
								throw new Exception( joResponse.getString("errorMessage") );
							}
						}
					}
					
					if(i==jaScriptContent.size()-1)
					{
						JSONObject methodObject = new JSONObject();
						methodObject.put("url", Constants.APPEDO_UI_LT_SERVICES+"/lt/chartReport");
						methodObject.put("runid", reportId);
						methodObject.put("login_user_bean", loginUserBean.toJSON());
						methodObject.put("testTypeScript", loadTestType);
						methodObject.put("startTime", runEpochStartTime);
						methodObject.put("queryDuration", queryDuration);
						methodObject.put("selectedTime", selectedTime);
						methodObject.put("status", reportStatus);
						methodObject.put("runTime", runEpochTime);
						
						String jsonString = null;
						String jsonChildString = null;
						String maxAndMin = "0:0";
						jsonString = UtilsFactory.getChartDataForPdfFile(methodObject, Constants.APPEDO_LT_ERROR_COUNT);
						if(jsonString !=null){
							maxAndMin = "0:0";
							maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonString);
//							if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
//								joFinalContent.put("errorChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("errorChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("errorChartStatus", true);
//								joScriptContent.put(Constants.APPEDO_LT_ERROR_COUNT, jsonString);
//							}else{
//								joFinalContent.put("errorChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("errorChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("errorChartStatus", false);
//								joScriptContent.put(Constants.APPEDO_LT_ERROR_COUNT, "[]");
//							}
							joFinalContent.put("errorChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("errorChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("errorChartStatus", true);
							joScriptContent.put(Constants.APPEDO_LT_ERROR_COUNT, jsonString);
						}else{
							maxAndMin = "0:0";
							joFinalContent.put("errorChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("errorChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("errorChartStatus", false);
							joScriptContent.put(Constants.APPEDO_LT_ERROR_COUNT, "[]");
						}
						
						jsonString = null;
						jsonString = UtilsFactory.getChartDataForPdfFile(methodObject, Constants.APPEDO_LT_PAGE_RESPONSE);
						if(jsonString !=null){
							maxAndMin = "0:0";
							maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonString);
//							if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
//								joFinalContent.put("pageResponseChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("pageResponseChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("pageResponseChartStatus", true);
//								joScriptContent.put(Constants.APPEDO_LT_PAGE_RESPONSE, jsonString);
//							}else{
//								joFinalContent.put("pageResponseChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("pageResponseChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("pageResponseChartStatus", false );
//								joScriptContent.put(Constants.APPEDO_LT_PAGE_RESPONSE, "[]");
//							}
							joFinalContent.put("pageResponseChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("pageResponseChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("pageResponseChartStatus", true);
							joScriptContent.put(Constants.APPEDO_LT_PAGE_RESPONSE, jsonString);
						}else{
							maxAndMin = "0:0";
							joFinalContent.put("pageResponseChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("pageResponseChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("pageResponseChartStatus", false);
							joScriptContent.put(Constants.APPEDO_LT_PAGE_RESPONSE, "[]");
						}

						jsonString = null;
						jsonString = UtilsFactory.getChartDataForPdfFile(methodObject, Constants.APPEDO_LT_USER_COUNT);
						if(jsonString !=null){
							maxAndMin = "0:0";
							maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonString);
//							if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
//								joFinalContent.put("userChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("userChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("userChartStatus", true);
//								joScriptContent.put(Constants.APPEDO_LT_USER_COUNT, jsonString);
//							}else{
//								joFinalContent.put("userChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("userChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("userChartStatus", false);
//								joScriptContent.put(Constants.APPEDO_LT_USER_COUNT, "[]");
//							}
							joFinalContent.put("userChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("userChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("userChartStatus", true);
							joScriptContent.put(Constants.APPEDO_LT_USER_COUNT, jsonString);
						}else{
							maxAndMin = "0:0";
							joFinalContent.put("userChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("userChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("userChartStatus", false);
							joScriptContent.put(Constants.APPEDO_LT_USER_COUNT, "[]");
						}

						jsonString = null;
						jsonString = UtilsFactory.getChartDataForPdfFile(methodObject, Constants.APPEDO_LT_HIT_COUNT_THROUGHPUT_REQUEST_RESPONSE);
						if(jsonString !=null){
							String througputKey[] = {"T", "V", "Hour counts","Minute counts","Second counts","Bps","Bytes"}; 
							String hitCountKey[] = {"T", "V", "Total Hits", "Hits/Sec"}; 
							String requestResponseKey[] = {"T", "V", "Hour counts","Minute counts","Second counts","Min","Avg","Max"};

							jsonChildString = null;
							jsonChildString = UtilsFactory.getJsonDataForPdf(jsonString, hitCountKey, "Total Hits");
							maxAndMin = "0:0";
							maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonChildString);
//							if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
//								joFinalContent.put("hitChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("hitChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("hitChartStatus", true);
//								joScriptContent.put(Constants.APPEDO_LT_HIT_COUNT, jsonChildString);
//							}else{
//								joFinalContent.put("hitChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("hitChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("hitChartStatus", false);
//								joScriptContent.put(Constants.APPEDO_LT_HIT_COUNT, "[]");
//							}
							joFinalContent.put("hitChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("hitChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("hitChartStatus", true);
							joScriptContent.put(Constants.APPEDO_LT_HIT_COUNT, jsonChildString);
							
							jsonChildString = null;
							jsonChildString = UtilsFactory.getJsonDataForPdf(jsonString, througputKey, "Bps");
							maxAndMin = "0:0";
							maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonChildString);
//							if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
//								joFinalContent.put("throughputChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("throughputChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("throughputChartStatus", true);
//								joScriptContent.put(Constants.APPEDO_LT_THROUGHPUT, jsonChildString);
//							}else{
//								joFinalContent.put("throughputChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("throughputChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("throughputChartStatus", false);
//								joScriptContent.put(Constants.APPEDO_LT_THROUGHPUT, "[]");
//							}
							joFinalContent.put("throughputChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("throughputChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("throughputChartStatus", true);
							joScriptContent.put(Constants.APPEDO_LT_THROUGHPUT, jsonChildString);
							
							jsonChildString = null;
							jsonChildString = UtilsFactory.getJsonDataForPdf(jsonString, requestResponseKey, "Avg");
							maxAndMin = "0:0";
							maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonChildString);
//							if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
//								joFinalContent.put("requestResponseChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("requestResponseChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("requestResponseChartStatus", true);
//								joScriptContent.put(Constants.APPEDO_LT_REQUEST_RESPONSE, jsonChildString);
//							}else{
//								joFinalContent.put("requestResponseChartMin", maxAndMin.split(":")[0]);
//								joFinalContent.put("requestResponseChartMax", maxAndMin.split(":")[1]);
//								joFinalContent.put("requestResponseChartStatus", false);
//								joScriptContent.put(Constants.APPEDO_LT_REQUEST_RESPONSE, "[]");
//							}
							joFinalContent.put("requestResponseChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("requestResponseChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("requestResponseChartStatus", true);
							joScriptContent.put(Constants.APPEDO_LT_REQUEST_RESPONSE, jsonChildString);
						}else{
							maxAndMin = "0:0";
							joFinalContent.put("throughputChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("throughputChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("throughputChartStatus", false);
							joScriptContent.put(Constants.APPEDO_LT_THROUGHPUT, "[]");
							joFinalContent.put("requestResponseChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("requestResponseChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("requestResponseChartStatus", false);
							joScriptContent.put(Constants.APPEDO_LT_REQUEST_RESPONSE, "[]");
							joFinalContent.put("hitChartMin", maxAndMin.split(":")[0]);
							joFinalContent.put("hitChartMax", maxAndMin.split(":")[1]);
							joFinalContent.put("hitChartStatus", false);
							joScriptContent.put(Constants.APPEDO_LT_HIT_COUNT, "[]");
						}
						
						jsonString = null;
						jsonString = UtilsFactory.getChartDataForPdfFile(methodObject, Constants.APPEDO_LT_LOADGENS_AVG_REQ_RESPS);
						JSONArray jaLoadgenData = JSONArray.fromObject(jsonString);
						if(jsonString !=null){
							joScriptContent.put(Constants.APPEDO_LT_LOADGENS_AVG_REQ_RESPS, jaLoadgenData.getJSONObject(0).get("Data"));
						}else{
							joScriptContent.put(Constants.APPEDO_LT_LOADGENS_AVG_REQ_RESPS, "[]");
						}
						
						jsonString = null;
						jsonString = UtilsFactory.getChartDataForPdfFile(methodObject, Constants.APPEDO_LT_LOADGENS_AVG_PAGE_RESPS);
						jaLoadgenData = JSONArray.fromObject(jsonString);
						if(jsonString !=null){
							joScriptContent.put(Constants.APPEDO_LT_LOADGENS_AVG_PAGE_RESPS, jaLoadgenData.getJSONObject(0).get("Data"));
						}else{
							joScriptContent.put(Constants.APPEDO_LT_LOADGENS_AVG_PAGE_RESPS, "[]");
						}
						
						if(!guid.equalsIgnoreCase("0")){
							JSONArray jsonCounterArray,jsonASDChartArray;
							JSONObject jsonCounterObject,jsonASDChartObject;
							
							jsonASDChartArray = new JSONArray();
							String allGuids[] = guid.split(",");
							for(int guidLoop = 0; guidLoop < allGuids.length; guidLoop++) {
								method = new PostMethod(Constants.APPEDO_UI_MODULE_SERVICES+"/apmCounters/getPrimaryCountersForAllDetailsPage");
								method.addParameter("guid", allGuids[guidLoop]);
								method.addParameter("login_user_bean", loginUserBean.toJSON().toString());
								method.addParameter("showPrimaryCounters", "true");
								
								jsonString = null;
								jsonString = UtilsFactory.getJsonData(method);
								if(jsonString!=null){
									jsonCounterArray = JSONArray.fromObject(jsonString);
									if(jsonCounterArray.size()>0){
										for(int gLoop=0;gLoop<jsonCounterArray.size(); gLoop++){
											jsonCounterObject = jsonCounterArray.getJSONObject(gLoop);
											
											jsonASDChartObject = new JSONObject();
											jsonASDChartObject.put("guid", allGuids[guidLoop]);
											jsonASDChartObject.put("category", jsonCounterObject.getString("category"));
											jsonASDChartObject.put("title", jsonCounterObject.getString("title"));
											jsonASDChartObject.put("display_name", jsonCounterObject.getString("display_name"));
											jsonASDChartObject.put("counter_id", jsonCounterObject.getString("counter_id"));
		
											methodASD = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getNewModuleCountersChartdataForLoadTest");
											methodASD.addParameter("login_user_bean", loginUserBean.toJSON());
											methodASD.addParameter("startTime", runEpochStartTime);
											methodASD.addParameter("endTime", runEpochEndTime);
											methodASD.addParameter("queryDuration", queryDuration);
											methodASD.addParameter("selectedTime", selectedTime);
											methodASD.addParameter("status", reportStatus);
											methodASD.addParameter("runTime", runEpochTime);
											methodASD.addParameter("counterNames",  jsonCounterObject.getString("counter_id"));
											methodASD.addParameter("guid", allGuids[guidLoop]);
		
											jsonString = null;
											jsonString = UtilsFactory.getJsonData(methodASD);
											if(jsonString !=null){
												jsonChildString = null;
												jsonChildString = UtilsFactory.searchCounterIdInArray(jsonCounterObject.getString("counter_id"), jsonString); 
												if((jsonChildString!=null)&&(!jsonChildString.equalsIgnoreCase("null"))){
													maxAndMin = "0:0";
													maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonChildString);
		//											if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
		//												jsonASDChartObject.put("asdChartStatus", true);
		//												jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
		//												jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
		//												jsonASDChartObject.put("graphData", jsonChildString);
		//											}else{
		//												maxAndMin = "0:0";
		//												jsonASDChartObject.put("asdChartStatus", false);
		//												jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
		//												jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
		//												jsonASDChartObject.put("graphData", "[]");
		//											}
													jsonASDChartObject.put("asdChartStatus", true);
													jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
													jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
													jsonASDChartObject.put("graphData", jsonChildString);
												}else{
													maxAndMin = "0:0";
													jsonASDChartObject.put("asdChartStatus", false);
													jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
													jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
													jsonASDChartObject.put("graphData", "[]");
												}
											}else{
												maxAndMin = "0:0";
												jsonASDChartObject.put("asdChartStatus", false);
												jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
												jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
												jsonASDChartObject.put("graphData", "[]");
											}
											jsonASDChartArray.add(jsonASDChartObject);
										}
									}
								}
							}
							if(jsonASDChartArray.size()>0){
								joScriptContent.put("asdChartData", jsonASDChartArray);
							}else{
								joScriptContent.put("asdChartData", "[]");
							}
						}
					}
					
					methodSetting = new PostMethod(Constants.APPEDO_UI_LT_SERVICES+"/lt/getRunSettings");
					methodSetting.addParameter("login_user_bean", loginUserBean.toJSON());
					methodSetting.addParameter("runId", reportId);
					// methodSetting.addParameter("scriptId", "143");
					
					methodSetting.setRequestHeader("Connection", "close");

					String jsonSettings = null;
					jsonSettings = UtilsFactory.getJsonData(methodSetting);
					
					JSONArray jaSettings = JSONArray.fromObject(jsonSettings);
					for( int s = 0; s < jaSettings.size(); s++ ){
						JSONObject joSet = jaSettings.getJSONObject(s);
						if( joSet.getString("runtype").equalsIgnoreCase("Iteration") ){
							joSet.put("rampup", joSet.getString("v_users")+" Users " + joSet.getString("iteration")+ "Iterations" );
						} else {
							String[] dur = joSet.getString("duration").split(";");
							String hrMinSec = "";
							if( !dur[0].equalsIgnoreCase("0") ){
								hrMinSec = dur[0] + "Hours";
							}
							if( !dur[1].equalsIgnoreCase("0") ){
								hrMinSec += dur[1] + "Minutes";
							}
							if( !dur[2].equalsIgnoreCase("0") ){
								hrMinSec += dur[2] + "Seconds";
							}
							joSet.put("rampup", joSet.get("v_users")+" Users " + hrMinSec );
						}
					}
					
					joScriptContent.put("scriptSettings", JSONArray.fromObject(jaSettings));
					jaNewScriptContent.add(joScriptContent);
				}
				joSummaryContent.put("scriptContent", jaNewScriptContent);
				
				joFinalContent.put("summaryContent", joSummaryContent);
				joFinalContent.put("d3XaixsFormatForPdf", d3XaixsFormatForPdf);
				
//				LogManager.errorLog(joFinalContent.toString());

				if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
					fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
	                bis = new BufferedInputStream(fis);
					response.setContentType("text/xls");
					response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
					output = new BufferedOutputStream(response.getOutputStream());
	                for (int data; (data = bis.read()) > -1;)
	                {
	                	output.write(data);
	                }
				}else{
					method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"writeScenarioPdfFile");
					method.addParameter("joFinalContent", joFinalContent.toString());
					method.addParameter("filePath", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
					method.addParameter("jasperFilePath", Constants.JASPERFILEPATH);
					method.addParameter("jasperResouceFilePath", Constants.JASPERRESOURCEFILEPATH);
					method.addParameter("overwrite", "true");
					method.setRequestHeader("Connection", "close");
					if(UtilsFactory.createFileFileForShipping(method)){
						fis = new FileInputStream(new File(Constants.SUMMARYREPORTPATH+reportId+Constants.FILE_STRING_SEPARATOR+filename));
		                bis = new BufferedInputStream(fis);
						response.setContentType("text/xls");
						response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
						output = new BufferedOutputStream(response.getOutputStream());
		                for (int data; (data = bis.read()) > -1;)
		                {
		                	output.write(data);
		                }
					}else{
						LogManager.errorLog("Problem in DownloadPdfFile ");
					}
				}
			} catch(Exception e) {
				e.printStackTrace();
				LogManager.errorLog("Exception in DownloadPdfFile: "+e.getMessage());
			} finally {
				if(method!=null){
					method.releaseConnection();
					method = null;
				}
				if(methodASD!=null){
					methodASD.releaseConnection();
					methodASD = null;
				}
				if(fis!=null){
				    fis.close();
				}
				if( bis != null ){
					bis.close();
				}
				output.flush();
				LogManager.logMethodEnd(dateLog);
			}
		}else if(strActionCommand.endsWith("/pdf/downloadASDChart")) {
			Date dateLog = LogManager.logMethodStart();
			FileInputStream fis =null;
            BufferedOutputStream output =null;
			PostMethod method = null,methodASD = null;
			String jsonString=null,jsonChildString = null,maxAndMin=null;
			JSONObject joFinalASDContent=null;
			BufferedInputStream bis = null;
			try{
				String d3XaixsFormatForPdf =request.getParameter("d3XaixsFormatForPdf");
				String uid =request.getParameter("uid");
				String guid = (String) (request.getParameter("guid") ==null ? '0' :request.getParameter("guid"));
				String moduleName =request.getParameter("moduleName");
				String type =request.getParameter("type");
				String version =request.getParameter("version");
				String sliderValue =request.getParameter("sliderValue");
				String selectedDetailsModule =request.getParameter("selectedDetailsModule");
				String startDate =request.getParameter("startDate");
				String endDate=request.getParameter("endDate");
				String displayStartDate =request.getParameter("displayStartDate");
				String displayEndDate=request.getParameter("displayEndDate");
				
				String outputFilePath=null;
				String filename = null;
				filename = "asd_chart_"+uid+"_"+guid+"_"+sliderValue+".pdf";
				filename = filename.replaceAll("[!@#$%^&*]", "");
				filename = filename.replaceAll("\\s", "_");
				String downloadFilename = null;
				downloadFilename = moduleName+"_Charts_Report.pdf";
				downloadFilename = downloadFilename.replaceAll("[!@#$%^&*]", "");
				downloadFilename = downloadFilename.replaceAll("\\s", "_");
				outputFilePath = Constants.ASDCHARTSREPORTPATH_SHIPPING+uid;
				
				joFinalASDContent =  new JSONObject();
				
				joFinalASDContent.put("guid", guid);
				joFinalASDContent.put("d3XaixsFormatForPdf", d3XaixsFormatForPdf);
				joFinalASDContent.put("type", type);
				joFinalASDContent.put("version", version);
				joFinalASDContent.put("selectedDetailsModule", selectedDetailsModule);
				joFinalASDContent.put("moduleName", moduleName.substring(0, 1).toUpperCase()+moduleName.substring(1));
				
				if((startDate.equalsIgnoreCase(""))&&(endDate.equalsIgnoreCase(""))){
					joFinalASDContent.put("duration", "Last "+sliderValue);
				}else{
					joFinalASDContent.put("duration", displayStartDate +" ~ "+displayEndDate);
				}
				
				if(guid!="0"){
					method = new PostMethod(Constants.APPEDO_UI_MODULE_SERVICES+"/apmCounters/getSelectedCounterSummary");
					method.addParameter("guid", joFinalASDContent.getString("guid"));
					method.addParameter("agentVersion", type+" "+version);
					method.addParameter("login_user_bean", loginUserBean.toJSON().toString());
					
					JSONArray jsonCounterArray,jsonASDChartArray;
					JSONObject jsonCounterObject,jsonASDChartObject;
					jsonASDChartArray = new JSONArray();
					
					jsonString = null;
					jsonString = UtilsFactory.getJsonData(method);
					if(jsonString!=null){
						jsonCounterArray = JSONArray.fromObject(jsonString);
						
						if(jsonCounterArray.size()>0){
							for(int gLoop=0;gLoop<jsonCounterArray.size(); gLoop++){
								jsonCounterObject = jsonCounterArray.getJSONObject(gLoop);
								jsonASDChartObject = new JSONObject();
								jsonASDChartObject.put("category", jsonCounterObject.getString("category"));
								jsonASDChartObject.put("display_name", jsonCounterObject.getString("display_name"));
								jsonASDChartObject.put("counter_id", jsonCounterObject.getString("counter_id"));
								
								methodASD = new PostMethod(Constants.APPEDO_UI_MODULE_SERVICES + "/apmCounters/getModuleCountersChartdata");
								methodASD.addParameter("guid", joFinalASDContent.getString("guid"));
								methodASD.addParameter("login_user_bean", loginUserBean.toJSON().toString());
								methodASD.addParameter("counterNames", jsonCounterObject.getString("counter_id"));
								methodASD.addParameter("is_above_threshold", jsonCounterObject.getString("is_above_threshold"));
								if ((startDate.equalsIgnoreCase("")) && (endDate.equalsIgnoreCase(""))) {
									methodASD.addParameter("fromStartInterval", sliderValue);
								} else {
									methodASD.addParameter("startDate", startDate);
									methodASD.addParameter("endDate", endDate);
								}
								methodASD.addParameter("ispdf", "true");
								jsonString = null;
								jsonString = UtilsFactory.getJsonData(methodASD);
								if(jsonString !=null){
									jsonChildString = null;
									jsonChildString = JSONObject.fromObject(jsonString).getJSONObject("chartdata").getString(jsonCounterObject.getString("counter_id"));
									if((jsonChildString!=null)&&(!jsonChildString.equalsIgnoreCase("null"))){
										maxAndMin = "0:0";
										maxAndMin = UtilsFactory.getMaxAndMinFromJSONArray(jsonChildString);
//											if((Double.parseDouble(maxAndMin.split(":")[0]) >= 0) && (Double.parseDouble(maxAndMin.split(":")[1]) > 0)){
//												jsonASDChartObject.put("asdChartStatus", true);
//												jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
//												jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
//												jsonASDChartObject.put("graphData", jsonChildString);
//											}else{
//												maxAndMin = "0:0";
//												jsonASDChartObject.put("asdChartStatus", false);
//												jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
//												jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
//												jsonASDChartObject.put("graphData", "[]");
//											}
										jsonASDChartObject.put("asdChartStatus", true);
										jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
										jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
										jsonASDChartObject.put("graphData", jsonChildString);
									}else{
										maxAndMin = "0:0";
										jsonASDChartObject.put("asdChartStatus", false);
										jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
										jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
										jsonASDChartObject.put("graphData", "[]");
									}
								}else{
									maxAndMin = "0:0";
									jsonASDChartObject.put("asdChartStatus", false);
									jsonASDChartObject.put("asdChartMin", maxAndMin.split(":")[0]);
									jsonASDChartObject.put("asdChartMax", maxAndMin.split(":")[1]);
									jsonASDChartObject.put("graphData", "[]");
								}
								jsonASDChartArray.add(jsonASDChartObject);
							}
						}
					}
					if(jsonASDChartArray.size()>0){
						joFinalASDContent.put("asdChartData", jsonASDChartArray);
					}else{
						joFinalASDContent.put("asdChartData", "[]");
					}
					joFinalASDContent.put("generatedAt", new Date().getTime());
					//LogManager.infoLog("joFinalASDContent: "+joFinalASDContent.toString());
				}
				
//				if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
//					fis = new FileInputStream(new File(Constants.ASDCHARTSREPORTPATH+uid+Constants.FILE_STRING_SEPARATOR+filename));
//	                BufferedInputStream bis = new BufferedInputStream(fis);
//					response.setContentType("text/xls");
//					response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
//					output = new BufferedOutputStream(response.getOutputStream());
//	                for (int data; (data = bis.read()) > -1;)
//	                {
//	                	output.write(data);
//	                }
//				}else{
					method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"writeASDChartPdfFile");
					method.addParameter("joFinalContent", joFinalASDContent.toString());
					method.addParameter("filePath", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
					method.addParameter("jasperFilePath", Constants.JASPERFILEPATH);
					method.addParameter("jasperResouceFilePath", Constants.JASPERRESOURCEFILEPATH);
					method.addParameter("overwrite", "true");
					method.setRequestHeader("Connection", "close");
					if(UtilsFactory.createFileFileForShipping(method)){
						fis = new FileInputStream(new File(Constants.ASDCHARTSREPORTPATH+uid+Constants.FILE_STRING_SEPARATOR+filename));
		                bis = new BufferedInputStream(fis);
						response.setContentType("text/xls");
						response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
						output = new BufferedOutputStream(response.getOutputStream());
		                for (int data; (data = bis.read()) > -1;)
		                {
		                	output.write(data);
						}
					}else{
						LogManager.errorLog("Problem in DownloadASDChartPdfFile ");
					}
//				}
			} catch(Exception e) {
				e.printStackTrace();
				LogManager.errorLog("Exception in downloadASDChart: "+e.getMessage());
			} finally {
				if(method!=null){
					method.releaseConnection();
					method = null;
				}
				if(methodASD!=null){
					methodASD.releaseConnection();
					methodASD = null;
				}
				if(fis!=null){
				    fis.close();
				}
				if( bis != null ){
					bis.close();
				}
				output.flush();
				LogManager.logMethodEnd(dateLog);
			}
		} else if(strActionCommand.endsWith("/pdf/downloadMyCharts")) {
			Date dateLog = LogManager.logMethodStart();
			FileInputStream fis =null;
            BufferedOutputStream output =null;
			PostMethod method = null;
			String jsonString=null;
			JSONObject joFinalMyContent=null;
			BufferedInputStream bis = null;
			try{
				String d3XaixsFormatForPdf =request.getParameter("d3XaixsFormatForPdf");
				System.out.println("d3XaixsFormatForPdf: "+d3XaixsFormatForPdf);
				String sliderValue =request.getParameter("sliderValue");
				String startDate =request.getParameter("startDate");
				String endDate=request.getParameter("endDate");
				String displayStartDate =request.getParameter("displayStartDate");
				String displayEndDate=request.getParameter("displayEndDate");
				String chartId = request.getParameter("chart_view_id");
				String chartName = request.getParameter("chart_view_name");
				String selectedCounters = request.getParameter("selectedChartCounters");
				
				String mStringArray[] = selectedCounters.split(",");
				JSONArray JaSelectedCounters = new JSONArray();
				
				for(int i=0;i<mStringArray.length;i++){
					JaSelectedCounters.add(mStringArray[i]);
				}
				
				method = new PostMethod(Constants.APPEDO_UI_MODULE_SERVICES+"/chart/getChartCardData");
				method.addParameter("login_user_bean", loginUserBean.toJSON().toString());
				method.addParameter("chart_view_id", chartId);
				jsonString = UtilsFactory.getJsonData(method);
				JSONArray jo = JSONArray.fromObject(jsonString);
				//System.out.println(jsonString);
				
				String outputFilePath=null;
				String filename = null;
				
				joFinalMyContent =  new JSONObject();
				if((startDate.equalsIgnoreCase(""))&&(endDate.equalsIgnoreCase(""))){
					joFinalMyContent.put("duration", "Last "+sliderValue);
				}else{
					joFinalMyContent.put("duration", displayStartDate +" ~ "+displayEndDate);
					sliderValue = null;
				}
				
				if( sliderValue!= null ){
					filename = "my_chart"+"_"+chartName+"_"+sliderValue+".pdf";
				} else {
					filename = "my_chart"+"_"+chartName+".pdf";
				}
				
				filename = filename.replaceAll("[!@#$%^&*]", "");
				filename = filename.replaceAll("\\s", "_");
				String downloadFilename = null;
				downloadFilename = chartName+"_Charts_Report.pdf";
				downloadFilename = downloadFilename.replaceAll("[!@#$%^&*]", "");
				downloadFilename = downloadFilename.replaceAll("\\s", "_");
				outputFilePath = Constants.MYCHARTSREPORTPATH_SHIPPING+chartId;
				
				joFinalMyContent.put("d3XaixsFormatForPdf", d3XaixsFormatForPdf);
				
				if(jsonString.length() > 0){
					method = new PostMethod(Constants.APPEDO_UI_MODULE_SERVICES+"/chart/getChartMultiLineForPdf");
					method.addParameter("login_user_bean", loginUserBean.toJSON().toString());
					method.addParameter("chartContent", jo.getJSONObject(0).toString());
					if(sliderValue != null){
						method.addParameter("interval", sliderValue);
					} else {
						method.addParameter("startDate", startDate);
						method.addParameter("endDate", endDate);
					}

					JSONArray jsonCounterArray,jsonASDChartArray;
					JSONObject jsonCounterObject,jsonMYChartObject;
					jsonASDChartArray = new JSONArray();
					jsonString = null;
					jsonString = UtilsFactory.getJsonData(method);
					if(jsonString!=null){
						jsonCounterArray = JSONArray.fromObject(jsonString);
						if(jsonCounterArray.size()>0){
							for(int gLoop=0;gLoop<jsonCounterArray.size(); gLoop++){
								jsonCounterObject = jsonCounterArray.getJSONObject(gLoop);
								if(JaSelectedCounters.contains(jsonCounterObject.getString("legendName"))){
									jsonMYChartObject = new JSONObject();
									jsonMYChartObject.put("moduleName", jsonCounterObject.getString("moduleName"));
									jsonMYChartObject.put("appName", jsonCounterObject.getString("appName"));
									jsonMYChartObject.put("category", jsonCounterObject.getString("category"));
									//System.out.println(jsonMYChartObject);
									jsonMYChartObject.put("displayName", jsonCounterObject.getString("displayName"));
									jsonMYChartObject.put("counter_id", jsonCounterObject.getString("counter_id"));
									jsonMYChartObject.put("graphData", jsonCounterObject.getString("Data"));
									jsonMYChartObject.put("field_1_name", jsonCounterObject.getString("field_1_name"));
									jsonMYChartObject.put("field_2_name", jsonCounterObject.getString("field_2_name"));
									jsonMYChartObject.put("field_3_name", jsonCounterObject.getString("field_3_name"));
									jsonMYChartObject.put("field_1_value", jsonCounterObject.getString("field_1_value"));
									jsonMYChartObject.put("field_2_value", jsonCounterObject.getString("field_2_value"));
									jsonMYChartObject.put("field_3_value", jsonCounterObject.getString("field_3_value"));
									jsonASDChartArray.add(jsonMYChartObject);
								}
							}
						}
					}
					if(jsonASDChartArray.size()>0){
						joFinalMyContent.put("myChartData", jsonASDChartArray);
					}else{
						joFinalMyContent.put("myChartData", "[]");
					}
					joFinalMyContent.put("generatedAt", new Date().getTime());
//					LogManager.infoLog(joFinalASDContent.toString());
				}
				
//				if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
//					fis = new FileInputStream(new File(Constants.ASDCHARTSREPORTPATH+uid+Constants.FILE_STRING_SEPARATOR+filename));
//	                BufferedInputStream bis = new BufferedInputStream(fis);
//					response.setContentType("text/xls");
//					response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
//					output = new BufferedOutputStream(response.getOutputStream());
//	                for (int data; (data = bis.read()) > -1;)
//	                {
//	                	output.write(data);
//	                }
//				}else{
					method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"writeMyChartPdfFile");
					method.addParameter("joFinalContent", joFinalMyContent.toString());
					method.addParameter("filePath", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
					method.addParameter("jasperFilePath", Constants.JASPERFILEPATH);
					method.addParameter("jasperResouceFilePath", Constants.JASPERRESOURCEFILEPATH);
					method.addParameter("overwrite", "true");
					method.setRequestHeader("Connection", "close");
					if(UtilsFactory.createFileFileForShipping(method)){
						fis = new FileInputStream(new File(Constants.MYCHARTSREPORTPATH+chartId+Constants.FILE_STRING_SEPARATOR+filename));
		                bis = new BufferedInputStream(fis);
						response.setContentType("text/xls");
						response.setHeader("Content-Disposition", "attachment; fileName="+downloadFilename);
						output = new BufferedOutputStream(response.getOutputStream());
		                for (int data; (data = bis.read()) > -1;)
		                {
		                	output.write(data);
						}
					}else{
						LogManager.errorLog("Problem in DownloadMyChartPdfFile ");
					}
//				}
			} catch(Exception e) {
				e.printStackTrace();
				LogManager.errorLog("Exception in downloadMYChart: "+e.getMessage());
			} finally {
				if(method!=null){
					method.releaseConnection();
					method = null;
				}
				if(fis!=null){
				    fis.close();
				}
				if( bis != null){
					bis.close();
				}
				output.flush();
				LogManager.logMethodEnd(dateLog);
			}
		}
	}
}
