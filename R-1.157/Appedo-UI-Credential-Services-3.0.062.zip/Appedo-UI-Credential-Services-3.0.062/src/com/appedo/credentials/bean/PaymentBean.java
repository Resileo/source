package com.appedo.credentials.bean;

import java.util.Date;

import net.sf.json.JSON;

public class PaymentBean {
	
	private int userid;
	private Date txtDate;
	private String payerPaypalId;
	private String payerPaypalEmailID;
	private String txtUniqueId;
	private String txtType;
	private String mccurrency;
	private Float Amount;
	private String txtStstus;
	private String receviverPaypalId;
	private String receviverPaypalEmailId;
	private String licenseLevel;
	private JSON paymentResultJSON;
	
	public int getUserId() {
		return userid;
	}
	public void setUserId(int userid) {
		this.userid = userid;
	}
	public Float getAmount() {
		return Amount;
	}
	public void setAmount(Float amount) {
		Amount = amount;
	}
	public JSON getPaymentResultJSON() {
		return paymentResultJSON;
	}
	public void setPaymentResultJSON(JSON paymentResultJSON) {
		this.paymentResultJSON = paymentResultJSON;
	}
	public String getLicenseLevel() {
		return licenseLevel;
	}
	public void setLicenseLevel(String licenseLevel) {
		this.licenseLevel = licenseLevel;
	}
	public Date getTxtDate() {
		return txtDate;
	}
	public void setTxtDate(Date txtDate) {
		this.txtDate = txtDate;
	}
	public String getPayerPaypalId() {
		return payerPaypalId;
	}
	public void setPayerPaypalId(String payerPaypalId) {
		this.payerPaypalId = payerPaypalId;
	}
	public String getPayerPaypalEmailID() {
		return payerPaypalEmailID;
	}
	public void setPayerPaypalEmailID(String payerPaypalEmailID) {
		this.payerPaypalEmailID = payerPaypalEmailID;
	}
	public String getTxtUniqueId() {
		return txtUniqueId;
	}
	public void setTxtUniqueId(String txtUniqueId) {
		this.txtUniqueId = txtUniqueId;
	}
	public String getTxtType() {
		return txtType;
	}
	public void setTxtType(String txtType) {
		this.txtType = txtType;
	}
	public String getMCcurrency() {
		return mccurrency;
	}
	public void setMccurrency(String mccurrency) {
		this.mccurrency = mccurrency;
	}
	
	public String getTxtStstus() {
		return txtStstus;
	}
	public void setTxtStstus(String txtStstus) {
		this.txtStstus = txtStstus;
	}
	public String getReceiverPaypalId() {
		return receviverPaypalId;
	}
	public void setReceviverPaypalId(String receviverPaypalId) {
		this.receviverPaypalId = receviverPaypalId;
	}
	public String getReceiverPaypalEmailId() {
		return receviverPaypalEmailId;
	}
	public void setReceviverPaypalEmailId(String receviverPaypalEmailId) {
		this.receviverPaypalEmailId = receviverPaypalEmailId;
	}	
}
