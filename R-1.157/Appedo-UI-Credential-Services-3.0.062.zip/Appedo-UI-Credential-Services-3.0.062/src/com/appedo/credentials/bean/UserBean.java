package com.appedo.credentials.bean;

import net.sf.json.JSONObject;

/**
 * Userbean is for replica of usermaster table
 * @author navin
 *
 */
public class UserBean {

	private long lUserId;
	private String strEmailId;
	private String strPassword;
	private int nEnterpriseId;
	private String strFirstName;
	private String strLastName;
	private String strMobileNo;
	private String strTelephoneCode;
	private boolean bActiveFlag;
	private String sumUrl;
	private String addedVia;
	
	
	public boolean isActiveFlag() {
		return bActiveFlag;
	}
	public void setActiveFlag(boolean activeFlag) {
		bActiveFlag = activeFlag;
	}
	
	public int getEnterpriseId() {
		return nEnterpriseId;
	}
	public void setEnterpriseId(int enterpriseId) {
		nEnterpriseId = enterpriseId;
	}
	
	public String getEmailId() {
		return strEmailId;
	}
	public void setEmailId(String strEmailId) {
		this.strEmailId = strEmailId;
	}
	
	public String getFirstName() {
		return strFirstName;
	}
	public void setFirstName(String strFirstName) {
		this.strFirstName = strFirstName;
	}
	
	public String getLastName() {
		return strLastName;
	}
	public void setLastName(String strLastName) {
		this.strLastName = strLastName;
	}
	
	public String getMobileNo() {
		return strMobileNo;
	}
	public void setMobileNo(String strMobileNo) {
		this.strMobileNo = strMobileNo;
	}
	
	public String getTelephoneCode() {
		return strTelephoneCode;
	}
	public void setTelephoneCode(String strTelephoneCode) {
		this.strTelephoneCode = strTelephoneCode;
	}
	
	public String getPassword() {
		return strPassword;
	}
	public void setPassword(String strPassword) {
		this.strPassword = strPassword;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long userId) {
		lUserId = userId;
	}

	public void fromJSONObject(JSONObject joUserBean) {
		lUserId = joUserBean.getLong("userId");
		nEnterpriseId = joUserBean.getInt("enterpriseId");
		strEmailId = joUserBean.getString("emailId");
		strFirstName = joUserBean.getString("firstName");
		strLastName = joUserBean.getString("lastName");
		strMobileNo = joUserBean.getString("mobile");
		bActiveFlag = joUserBean.getBoolean("activeFlag");
		strPassword = joUserBean.getString("password");
	}
	
	public String toJSON() {
		JSONObject joUser = new JSONObject();
		
		joUser.put("userId", lUserId);
		joUser.put("enterpriseId", nEnterpriseId);
		joUser.put("emailId", strEmailId);
		joUser.put("firstName", strFirstName);
		joUser.put("lastName", strLastName);
		joUser.put("mobile", strMobileNo);
		joUser.put("activeFlag", bActiveFlag);
		joUser.put("sumUrl", sumUrl);
		joUser.put("password", strPassword);
		
		return joUser.toString();
	}
	public String getSumUrl() {
		return sumUrl;
	}
	public void setSumUrl(String sumUrl) {
		this.sumUrl = sumUrl;
	}
	public String getAddedVia() {
		return addedVia;
	}
	public void setAddedVia(String addedVia) {
		this.addedVia = addedVia;
	}
}
