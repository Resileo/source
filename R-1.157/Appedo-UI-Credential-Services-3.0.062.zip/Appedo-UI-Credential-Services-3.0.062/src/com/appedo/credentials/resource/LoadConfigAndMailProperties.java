package com.appedo.credentials.resource;


import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import com.appedo.manager.LogManager;
import com.appedo.commons.manager.AppedoMailer;
import com.appedo.credentials.util.AppedoMobileManager;
import com.appedo.credentials.util.Constants;

/**
 * Performance Counter Collector Resource
 * This service will receive all the counter data and pass it to respective Manager.
 * 
 * @author Ramkumar
 *
 */
public class LoadConfigAndMailProperties extends Resource {
	
	public LoadConfigAndMailProperties(Context context, Request request, Response response) {
		super(context, request, response);
		
		// Declare the kind of representations supported by this resource.
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
		
		// Allow modifications of this resource via POST requests.
		setModifiable(true);
	}

	@Override
	/**
	 * Handle GET requests: Validate a login & send Course details
	 * 
	 * @param Variant
	 * @throws ResourceException
	 */
	public Representation represent(Variant arg0) throws ResourceException {
		String strResponse = null;
		
		// 
		strResponse = loadConfigAndMailProperties();
		
		Representation rep = new StringRepresentation(strResponse);
		return rep;
	}
	
	@Override
	/**
	 * Handle POST requests: Receive the Counter data with agent_type
	 * 
	 * @param entity
	 *            Form entity
	 * @throws ResourceException
	 */
	public void acceptRepresentation(Representation entity) throws ResourceException {
		String strResponse = null;
		
		// 
		strResponse = loadConfigAndMailProperties();
		
		Representation rep = new StringRepresentation(strResponse);
		getResponse().setEntity(rep);
	}
	
	public String loadConfigAndMailProperties() {
		String strResp = "";
		
		try {
			// Loads Constants properties 
			Constants.loadConstantsProperties(Constants.CONFIG_FILE_PATH);
			
			// Loads Appedo config properties from the system path
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Load mail config properties
			AppedoMailer.loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
			//responseXml	.append("{\"success\": true, \"failure\": false}");
			
			// Load mobile config properties
			AppedoMobileManager.loadPropertyFileConstants(Constants.MOBILE_CONFIG_FILE_PATH);
			
			// load appedo constants; say loads appedoWhiteLabels, 
			Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
			
			strResp = "Loaded <B>Appedo-UI-Credential-Services</B>, config, appedo_config, mail, mobile properties & appedo whitelabels.";
		} catch (Exception e) {
			LogManager.errorLog(e);
			strResp = "<B style=\"color: red; \">Exception occurred Appedo-UI-Credential-Services: "+e.getMessage()+"</B>";
		}
		
		return strResp;
	}
}
