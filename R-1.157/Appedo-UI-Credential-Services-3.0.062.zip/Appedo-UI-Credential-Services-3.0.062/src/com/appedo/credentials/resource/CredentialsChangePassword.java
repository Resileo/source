package com.appedo.credentials.resource;

import java.sql.Connection;

import org.restlet.Context;
import org.restlet.data.Form;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.manager.LogManager;
import com.appedo.credentials.manager.UserManager;
import com.appedo.credentials.util.UtilsFactory;

/**
 * Performance Counter Collector Resource
 * This service will receive all the counter data and pass it to respective Manager.
 * 
 * @author Ramkumar
 *
 */
public class CredentialsChangePassword extends Resource {
	
	public CredentialsChangePassword(Context context, Request request, Response response) {
		super(context, request, response);
		
		// Declare the kind of representations supported by this resource.
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
		
		// Allow modifications of this resource via POST requests.
		setModifiable(true);
	}
	
	@Override
	/**
	 * Handle POST requests: Receive the Counter data with agent_type
	 * 
	 * @param entity
	 *            Form entity
	 * @throws ResourceException
	 */
	public void acceptRepresentation(Representation entity) throws ResourceException {
		
		StringBuilder responseXml = new StringBuilder();
		Form frm = new Form(entity);
		
		Connection con = null;
		
		UserManager userManager = null;
		
		// get data from the request
		long lUserId = Long.valueOf(frm.getFirstValue("userId"));
		
		String strOldPassword = frm.getFirstValue("oldPassword");
		String strNewPassword = frm.getFirstValue("newPassword");
		String strReTypePassword = frm.getFirstValue("retypePassword");
		
		try {
			userManager = new UserManager();
			con = DataBaseManager.giveConnection();
			
			userManager.changePassword(con, lUserId, strOldPassword, strNewPassword, strReTypePassword);
			
			responseXml	.append("{\"success\": true, \"failure\": false}");
			DataBaseManager.commitConnection(con);
		} catch (Exception e) {
			LogManager.errorLog(e);
			responseXml.append( UtilsFactory.getJSONFailureReturn(e.getMessage()) );
			
			DataBaseManager.rollbackConnection(con);
		} finally {
			// To Close the connection when emailId or password were wrong
			DataBaseManager.close(con);
			con = null;
			strNewPassword = null;
		}
		
		Representation rep = new StringRepresentation(responseXml);
		getResponse().setEntity(rep);
	}
	
}
