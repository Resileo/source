package com.appedo.credentials.resource;

import java.sql.Connection;
import java.util.Date;

import org.restlet.Context;
import org.restlet.data.Form;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.manager.LogManager;
import com.appedo.credentials.manager.LoginManager;
import com.appedo.credentials.util.UtilsFactory;

public class CredentialsUpdateLogoutHistoryResource extends Resource {
	
	public CredentialsUpdateLogoutHistoryResource(Context context, Request request, Response response) {
		super(context, request, response);
		
		// Declare the kind of representations supported by this resource.
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
		
		// Allow modifications of this resource via POST requests.
		setModifiable(true);
	}
	
	@Override
	/**
	 * Handle POST requests: Receive the Counter data with agent_type
	 * 
	 * @param entity
	 *            Form entity
	 * @throws ResourceException
	 */
	public void acceptRepresentation(Representation entity) throws ResourceException {
		Date dateLog = LogManager.logMethodStart();
		StringBuilder responseXml = new StringBuilder();
		Form frm = new Form(entity);
		
		Connection con = null;
		
		LoginManager loginManager = null;
		
		// get data from the request
		
		try {
			loginManager = new LoginManager();
			
			Long lLoginHistoryId = Long.parseLong(frm.getFirstValue("loginHistoryId"));
			String strLogoutComment = frm.getFirstValue("logoutComment");
			con = DataBaseManager.giveConnection();
			
			loginManager.updateLogoutHistoryComment(con, lLoginHistoryId, strLogoutComment);
			
			// TODO UtilsFactory.getJSONSuccessReturn(loginUserBean.toString());
			//responseXml	.append("{\"success\": true, \"failure\": false }");
			
			responseXml.append(UtilsFactory.getJSONSuccessReturn("Updated login history."));
			
			DataBaseManager.commitConnection(con);
		} catch (Exception e) {
			LogManager.errorLog(e);
			responseXml.append( UtilsFactory.getJSONFailureReturn(e.getMessage()) );
			
			DataBaseManager.rollbackConnection(con);
		} finally {
			// To Close the connection when emailId or password were wrong
			DataBaseManager.close(con);
			con = null;
			
			LogManager.logMethodEnd(dateLog);
		}
		
		Representation rep = new StringRepresentation(responseXml);
		getResponse().setEntity(rep);
	}
}