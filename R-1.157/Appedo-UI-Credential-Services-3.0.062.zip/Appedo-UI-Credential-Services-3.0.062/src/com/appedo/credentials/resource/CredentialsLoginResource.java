package com.appedo.credentials.resource;

import java.sql.Connection;
import java.util.Date;

import net.sf.json.JSONArray;

import org.restlet.Context;
import org.restlet.data.Form;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.manager.LoginManager;
import com.appedo.credentials.util.UtilsFactory;
import com.appedo.credentials.util.WebServiceManager;
import com.appedo.manager.LogManager;

/**
 * Performance Counter Collector Resource
 * This service will receive all the counter data and pass it to respective Manager.
 * 
 * @author Ramkumar
 *
 */
public class CredentialsLoginResource extends Resource {
	
	public CredentialsLoginResource(Context context, Request request, Response response) {
		super(context, request, response);
		
		// Declare the kind of representations supported by this resource.
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
		
		// Allow modifications of this resource via POST requests.
		setModifiable(true);
	}
	
	@Override
	/**
	 * Handle POST requests: Receive the Counter data with agent_type
	 * 
	 * @param entity
	 *            Form entity
	 * @throws ResourceException
	 */
	public void acceptRepresentation(Representation entity) throws ResourceException {
		Date dateLog = LogManager.logMethodStart();
		StringBuilder responseXml = new StringBuilder();
		Form frm = new Form(entity);
		
		Connection con = null;
		
		LoginManager loginManager = null;
		LoginUserBean loginUserBean = null;
		
		// get data from the request
		String strEmailId = frm.getFirstValue("emailId").toLowerCase();
		String strPassword = frm.getFirstValue("password");
		//String strClientIPAddress = frm.getFirstValue("client_ip_address");
		String strClientIPAddress = "";
		boolean escapeVerification = false;
		JSONArray jaEnterprise = null;
		
		try {
			loginManager = new LoginManager();
			
			con = DataBaseManager.giveConnection();
			
			strClientIPAddress = WebServiceManager.getClientIpAddr(getRequest());
			
			jaEnterprise = new JSONArray();
			
			if(frm.getFirstValue("escape_login")!=null){
				escapeVerification = Boolean.valueOf(frm.getFirstValue("escape_login"));
			}
			
			loginUserBean = loginManager.loginUser(con, strEmailId, strPassword, strClientIPAddress, escapeVerification);
			/*
			Form headers = (Form) getRequest().getAttributes().get("org.restlet.http.headers");
			String ltpaToken = headers.getFirstValue("_APP_X-Forwarded-For");

			System.out.println("ltpaToken: "+ltpaToken);
			System.out.println("headers.getNames(): "+headers.getNames());
			System.out.println("_APP_X-Forwarded-For: "+headers.getFirstValue("_APP_X-Forwarded-For"));
			System.out.println("_APP_Proxy-Client-IP: "+headers.getFirstValue("_APP_Proxy-Client-IP"));
			System.out.println("_APP_WL-Proxy-Client-IP: "+headers.getFirstValue("_APP_WL-Proxy-Client-IP"));
			System.out.println("_app_remote_addr: "+headers.getFirstValue("_app_remote_addr"));
			*/
			
			if( loginUserBean != null ){
				// To get default settings of dashboard & card layout details
				loginUserBean = loginManager.getSetAsDefaultValue(con, loginUserBean);
				
				jaEnterprise = loginManager.getEnterpriseLicense(con, loginUserBean);
				// inserting login history
				long lLoginHistoryId = loginManager.addLoginHistory(con, loginUserBean.getUserId(), strClientIPAddress, "Successful Login");
				loginUserBean.setLoginHistoryId(lLoginHistoryId);
				
				responseXml	.append("{\"success\": true, \"failure\": false, ")
							.append("loginUserBean:").append(loginUserBean.toJSON())
							.append(",enterpriseLicense:").append(jaEnterprise.toString())
							.append("}");
			} else {
				responseXml	.append("{\"success\": false, \"failure\": true, ")
							.append("errorMessage:").append("1")
							.append("}");
			}
			
			DataBaseManager.commitConnection(con);
		} catch (Exception e) {
			LogManager.errorLog(e);
			responseXml.append( UtilsFactory.getJSONFailureReturn(e.getMessage()) );
			
			DataBaseManager.rollbackConnection(con);
		} finally {
			// To Close the connection when emailId or password were wrong
			DataBaseManager.close(con);
			con = null;
			
			LogManager.logMethodEnd(dateLog);
		}
		
		Representation rep = new StringRepresentation(responseXml);
		getResponse().setEntity(rep);
	}
}
