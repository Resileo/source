package com.appedo.credentials.resource;

import java.sql.Connection;
import java.util.Date;

import net.sf.json.JSONObject;

import org.restlet.Context;
import org.restlet.data.Form;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import com.appedo.credentials.bean.PaymentBean;
import com.appedo.credentials.bean.UserBean;
import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.manager.UserManager;
import com.appedo.credentials.util.UtilsFactory;
import com.appedo.manager.LogManager;


public class CredentialsPaymentGateway extends Resource {
	
	public CredentialsPaymentGateway(Context context, Request request, Response response) {
		super(context, request, response);
		
		// Declare the kind of representations supported by this resource.
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
		
		// Allow modifications of this resource via POST requests.
		setModifiable(true);
	}
	public void acceptRepresentation(Representation entity) throws ResourceException {
		Form frm = new Form(entity);
		Connection con = null;

		UserManager userManager = null;
		UserBean userBean = null;
		PaymentBean paymentBean = new PaymentBean();
		JSONObject joPayment = new JSONObject();
		JSONObject joCustom = new JSONObject();
		String paymentStatus = frm.getFirstValue("paymentResponse");
		joPayment = JSONObject.fromObject(paymentStatus);
		String userId = frm.getFirstValue("UserId");
//		LoginUserBean loginUserBean = new LoginUserBean();
		String strCustom = joPayment.getString("custom");
		System.out.println("1.jocustom :" + strCustom);
		joCustom = JSONObject.fromObject(strCustom);
		long lAppedoPaypalPaypentId = 0;
		StringBuilder responseXml = null;
		
		try
		{
			paymentBean.setPaymentResultJSON(joPayment);
			paymentBean.setLicenseLevel(joCustom.getString("lic_type"));
			//paymentBean.setAmount(joPayment.getInt("mc_gross"));
			paymentBean.setAmount(Float.parseFloat(joPayment.getString("mc_gross")));
			paymentBean.setMccurrency(joPayment.getString("mc_currency"));
			paymentBean.setPayerPaypalEmailID(joPayment.getString("payer_email"));
			paymentBean.setPayerPaypalId(joPayment.getString("payer_id"));
			paymentBean.setReceviverPaypalEmailId(joPayment.getString("receiver_email"));
			paymentBean.setReceviverPaypalId(joPayment.getString("receiver_id"));
			Date dt = UtilsFactory.toDate(joPayment.getString("payment_date"), "kk:mm:ss MMM dd, yyyy z");
			System.out.println(dt);
			System.out.println(dt.getTime());
			paymentBean.setTxtDate(dt);
			paymentBean.setTxtStstus(joPayment.getString("payment_status"));
			paymentBean.setTxtType(joPayment.getString("txn_type"));
			paymentBean.setTxtUniqueId(joPayment.getString("txn_id"));
			paymentBean.setUserId(Integer.parseInt(userId));
	
			userManager = new UserManager();
			con = DataBaseManager.giveConnection();
			lAppedoPaypalPaypentId = userManager.addPaymentResult(con, paymentBean);
			responseXml = UtilsFactory.getJSONSuccessReturn("appedo_paypal_payment_id", lAppedoPaypalPaypentId+"");
			DataBaseManager.commitConnection(con);
			
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			e.printStackTrace();
			System.out.println(e);
			
			//responseXml = UtilsFactory.getJSONFailureReturn(e.getMessage());
			responseXml = UtilsFactory.getJSONFailureReturn("Unable to add payment details.");
			DataBaseManager.rollbackConnection(con);
		} finally {
			// To Close the connection when emailId or password were wrong
			DataBaseManager.close(con);
			con = null;
			
			Representation rep = new StringRepresentation(responseXml);
			getResponse().setEntity(rep);
		}
	}
}
