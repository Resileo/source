package com.appedo.credentials.resource;

import java.sql.Connection;

import net.sf.json.JSONObject;

import org.restlet.Context;
import org.restlet.data.Form;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Representation;
import org.restlet.resource.Resource;
import org.restlet.resource.ResourceException;
import org.restlet.resource.StringRepresentation;
import org.restlet.resource.Variant;

import com.appedo.credentials.bean.UserBean;
import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.manager.UserManager;
import com.appedo.credentials.util.UtilsFactory;
import com.appedo.manager.LogManager;

/**
 * Performance Counter Collector Resource
 * This service will receive all the counter data and pass it to respective Manager.
 * 
 * @author Ramkumar
 *
 */
public class CredentialsSignUpResource extends Resource {
	
	public CredentialsSignUpResource(Context context, Request request, Response response) {
		super(context, request, response);
		
		// Declare the kind of representations supported by this resource.
		getVariants().add(new Variant(MediaType.APPLICATION_JSON));
		
		// Allow modifications of this resource via POST requests.
		setModifiable(true);
	}
	
	@Override
	/**
	 * Handle POST requests: Receive the Counter data with agent_type
	 * 
	 * @param entity
	 *            Form entity
	 * @throws ResourceException
	 */
	public void acceptRepresentation(Representation entity) throws ResourceException {
		StringBuilder responseXml = new StringBuilder();
		Form frm = new Form(entity);
		
		Connection con = null;
		
		UserManager userManager = null;
		UserBean userBean = null;
		
		// get data from the request
		String strEmailId = frm.getFirstValue("user_email_id");
		String strPassword = frm.getFirstValue("user_password");
		String strFirstName = frm.getFirstValue("user_first_name");
		String strLastName = frm.getFirstValue("user_last_name");
		String strMobileNo = frm.getFirstValue("user_mobileno");
		String strTelephoneCode = frm.getFirstValue("user_telephone_code");
		String sumUrl = frm.getFirstValue("sumurl");
		String addedVia = frm.getFirstValue("addedVia");
		
		try {
			userManager = new UserManager();
			
			con = DataBaseManager.giveConnection();
			
			userBean = new UserBean();
			userBean.setEmailId(strEmailId);
			userBean.setPassword(strPassword);
			userBean.setFirstName(strFirstName);
			userBean.setLastName(strLastName);
			userBean.setMobileNo(strMobileNo);
			userBean.setTelephoneCode(strTelephoneCode);
			userBean.setSumUrl(sumUrl);
			userBean.setAddedVia(addedVia);
			
			// Enterprise id is hardcoded here need to be changed
			// userBean.setEnterpriseId(1);
			userBean.setActiveFlag(true);
			
			JSONObject joObject = userManager.addUser(con, userBean);
			userBean.setUserId(joObject.getInt("user_id"));
			userBean.setEmailId(joObject.getString("email_id"));
			userBean.setPassword(joObject.getString("password"));
			userBean.setFirstName(joObject.getString("first_name"));
			userBean.setLastName(joObject.getString("last_name"));
			userBean.setMobileNo(joObject.getString("mobile_no"));
			userBean.setTelephoneCode(joObject.getString("telephone_code"));
			// TODO UtilsFactory.getJSONSuccessReturn(loginUserBean.toString());
			responseXml	.append("{\"success\": true, \"failure\": false, ")
						.append("userBean:").append(userBean.toJSON())
						.append("}");
			
			DataBaseManager.commitConnection(con);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			responseXml.append( UtilsFactory.getJSONFailureReturn(e.getMessage()) );
			DataBaseManager.rollbackConnection(con);
		} finally {
			// To Close the connection when emailId or password were wrong
			DataBaseManager.close(con);
			con = null;
		}
		
		Representation rep = new StringRepresentation(responseXml);
		getResponse().setEntity(rep);
	}
	
}
