package com.appedo.credentials.DBI;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.util.Constants;
import com.appedo.credentials.util.UtilsFactory;
import com.appedo.manager.LogManager;

/**
 * DBI handles the database operation for User signin
 * @author navin
 *
 */
public class LoginDBI {

	/**
	 * Validates user signin
	 * 
	 * @param con
	 * @param strEmailId
	 * @param strPassword
	 * @param escapeVerification 
	 * @return
	 * @throws Exception
	 */
	public LoginUserBean loginUser(Connection con, String strEmailId, String strPassword, String strClientIPAddress, boolean escapeVerification) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		LoginUserBean loginUserBean = null;
		
		String strUserPassword = "", strLicenseLevel = "";
		
		boolean bLicenseDegradedToLevel0 = false;
		
		UserDBI userDBI = null;
		
		try {
			userDBI = new UserDBI();
			
			sbQuery	.append("SELECT *, pgp_sym_decrypt(password, ?) AS decrypted_password FROM usermaster WHERE email_id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString(), ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			pstmt.setString(1, Constants.getPasswordSaltKey());
			pstmt.setString(2, strEmailId);
			rst = pstmt.executeQuery();
			
			if (rst.next()) {
				// Validation added, if query returns more than one row 
				if (rst.next()) {
					// Exception to throw for Invalid Login when query returns more than one row
					addLoginHistory(con, rst.getInt("user_id"), strClientIPAddress, "Duplicate Email-Ids found in usermaster");
					throw new Exception("2");
				} else {
					rst.previous();
					if(rst.getBoolean("active_flag")==false){
					//if(!new UserDBI().isUserActive(con, strEmailId)){
						addLoginHistory(con, rst.getInt("user_id"), strClientIPAddress, "Email-Id is inactive");
						throw new Exception("5");
					}else{
						if(rst.getTimestamp("email_verified_on")==null && !escapeVerification){
							addLoginHistory(con, rst.getInt("user_id"), strClientIPAddress, "Email-Id is not verified");
							throw new Exception("3");
						} else {
							strUserPassword = rst.getString("decrypted_password");
							
							if( !strUserPassword.equals(strPassword) ) {
								loginUserBean = new LoginUserBean();
								loginUserBean.setUserId(rst.getInt("user_id"));
								loginUserBean.setEmailId(rst.getString("email_id"));
								addLoginHistory(con, rst.getInt("user_id"), strClientIPAddress, "Email-Id and password do not match");
								throw new Exception("2");
							} else {
								loginUserBean = new LoginUserBean();
								
								loginUserBean.setUserId(rst.getInt("user_id"));
								loginUserBean.setEncryptedUserId(rst.getString("encrypted_user_id"));
								loginUserBean.setEnterpriseId(rst.getInt("enterprise_id"));
								loginUserBean.setEmailId(rst.getString("email_id"));
								loginUserBean.setFirstName(rst.getString("first_name"));
								loginUserBean.setLastName(rst.getString("last_name")==null?"":rst.getString("last_name"));
								loginUserBean.setMobile(rst.getString("mobile_no"));
								loginUserBean.setActiveFlag(rst.getBoolean("active_flag"));
								
//								loginUserBean.setSUMLicense(rst.getString("lic_sum"));
//								loginUserBean.setSumLicStartDate(rst.getTimestamp("sum_lic_start_date"));
// 								loginUserBean.setSumLicRenewalDate(rst.getTimestamp("sum_lic_renewal_date"));
//								loginUserBean.setSumLicEndDate(rst.getTimestamp("sum_lic_end_date"));
//								loginUserBean.setAPMLicense(rst.getString("lic_apm"));
//								loginUserBean.setRUMLicense(rst.getString("lic_rum"));
//								loginUserBean.setDDLicense(rst.getString("lic_dd"));
								
								loginUserBean.setAdminUser(rst.getBoolean("is_admin_user"));
								loginUserBean.setManageLicense(rst.getBoolean("manage_license"));
								loginUserBean.setViewUsageReports(rst.getBoolean("view_usage_reports"));
								loginUserBean.setEnableAccessRights(rst.getBoolean("enable_access_rights"));
								loginUserBean.setViewAllUsers(rst.getBoolean("view_all_users"));
								loginUserBean.setEnableJMETER(rst.getBoolean("enable_jmeter"));
								loginUserBean.setshowLevel3License(rst.getBoolean("show_level3_license"));
								loginUserBean.setshowPaypalButton(rst.getBoolean("show_paypal_button"));
								loginUserBean.setshowLicenseAddButton(rst.getBoolean("show_license_add_button"));

								
								strLicenseLevel = rst.getString("license_level");
								
								// If User license is expired then update records as LEVEL0 (Free/Lite)
								
								System.out.println("LoginUserDetails.getLicense : "+loginUserBean.getLicense());
								if( ! strLicenseLevel.equals("level0") ) {
									bLicenseDegradedToLevel0 = userDBI.updateExpiredLicenseToFREE(con, loginUserBean.getUserId(), strLicenseLevel);
									
									if ( bLicenseDegradedToLevel0 ) {
										strLicenseLevel = "level0";
									}
								}
								loginUserBean.setLicense(strLicenseLevel);
								loginUserBean.setLicenseDegradedToLevel0(bLicenseDegradedToLevel0);
								
								if( loginUserBean.getLicense().equalsIgnoreCase("level0") ){
									loginUserBean.setLicStartDate(rst.getTimestamp("created_on"));
									loginUserBean.setLicEndDate(null);
								} else {
									getAPMUserWiseLicenseMonthWise(con, loginUserBean);
								}
								
								/*
								// TODO: thinks to set `loginUserBean` isRUMLicExpired for user
								// updates user's RUM (ie.. used for RUM/CI) license to `level0` for PAID user, say other than `level0`
								if( ! loginUserBean.getLicense().equals("level0")) {
									userDBI.updateExpiredLicense(con, loginUserBean.getUserId(), loginUserBean.getLicense());
								}*/
								
								// TODO: updates user's expired DD license to `level0` for PAID user, say other than `level0`
							}
						}
					}
				}
			} else {
				addLoginHistory(con, -1, strClientIPAddress, "Email-Id not found - "+strEmailId);
			}
			
			userDBI = null;
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			strUserPassword = null;
		}
		
		return loginUserBean;
	}
	
	public LoginUserBean getSetAsDefaultValue(Connection con, LoginUserBean loginUserBean) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery	.append("SELECT service_map_id, crit_warn_name, module_type FROM default_page_settings WHERE user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			
			if (rst.next()) {
				loginUserBean.setDefaultServiceMapId(rst.getLong("service_map_id"));
				loginUserBean.setDefaultCritWarn(rst.getString("crit_warn_name"));
				loginUserBean.setDefaultCardLayout(rst.getString("module_type"));
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return loginUserBean;
	}
	
	public JSONArray getEnterpriseLicense(Connection con, LoginUserBean loginUserBean) throws Exception{
		JSONObject joEnterprise = null;
		JSONArray jaEnterprise = null;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			joEnterprise = new JSONObject();
			jaEnterprise = new JSONArray();
			sbQuery	.append("select em.e_name, uem.e_id, em.user_id, CASE WHEN em.user_id = ? THEN 'true' ELSE 'false' END AS is_owner from user_enterprise_mapping uem INNER JOIN enterprise_master em ON uem.e_id = em.e_id where uem.user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setLong(2, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			
			while (rst.next()) {
				joEnterprise.put("e_id", rst.getInt("e_id"));
				joEnterprise.put("e_name", rst.getString("e_name"));
				joEnterprise.put("e_user_id", rst.getString("user_id"));
				joEnterprise.put("is_owner", rst.getBoolean("is_owner"));
				jaEnterprise.add(joEnterprise);
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return jaEnterprise;
	}
	
	/**
	 * Inserting login history
	 * 
	 * @param con
	 * @param nUserId
	 * @param strIpAddress
	 * @param strComment
	 * @return
	 * @throws Exception
	 */
	public long addLoginHistory(Connection con, long nUserId, String strIpAddress, String strComment) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		long lLoginHistoryId = -1L;
		
		try{
			sbQuery	.append("INSERT INTO login_history(user_id, ip_details, login_on, login_comment)")
					.append("values(?, ?, now(), ?)");
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, nUserId);
			pstmt.setString(2, strIpAddress);
			pstmt.setString(3, strComment);
			pstmt.executeUpdate();
			lLoginHistoryId = DataBaseManager.returnKey(pstmt);
			
			DataBaseManager.commitConnection(con);
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return lLoginHistoryId;
	}
	/**
	 * Updating Login History details
	 * 
	 * @param con
	 * @param lLoginHistoryId
	 * @param strComment
	 * @throws Exception
	 */
	public void updateLogoutHistoryComment(Connection con,  Long lLoginHistoryId, String strComment) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery	.append("UPDATE login_history SET logout_on=NOW(), logout_comment='")
					.append(strComment).append("'")
					.append(" where id=")
					.append(lLoginHistoryId);
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public LoginUserBean getAPMUserWiseLicenseMonthWise(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null;
		ResultSet rst = null, rst1 = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			
			sbQuery .append("SELECT EXISTS(SELECT 1 FROM userwise_lic_monthwise  WHERE user_id = ? LIMIT 1) as record_exists");
			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.setLong(1, loginUserBean.getUserId());
			rst1 = pstmt1.executeQuery();
			if(rst1.next() && rst1.getBoolean("record_exists")){
				sbQuery.setLength(0);
				// For PAID user
				sbQuery	.append("SELECT start_date, end_date, license_level ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? ")
						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date LIMIT 1");
			
				pstmt = con.prepareStatement( sbQuery.toString() );
				pstmt.setLong(1, loginUserBean.getUserId());
				rst = pstmt.executeQuery();
				if( rst.next() ) {
					loginUserBean.setLicStartDate(rst.getTimestamp("start_date"));
					loginUserBean.setLicEndDate(rst.getTimestamp("end_date"));
					loginUserBean.setLicense(rst.getString("license_level") != null ? rst.getString("license_level") : loginUserBean.getLicense());
//					loginUserBean.setLtLicense(rst.getString("license_level") != null ? rst.getString("license_level") : loginUserBean.getLtLicense());
//					loginUserBean.setSUMLicense(rst.getString("license_level") != null ? rst.getString("license_level") : loginUserBean.getSUMLicense());
//					loginUserBean.setDDLicense(rst.getString("license_level") != null ? rst.getString("license_level") : loginUserBean.getDDLicense());
//					loginUserBean.setRUMLicense(rst.getString("license_level") != null ? rst.getString("license_level") : loginUserBean.getRUMLicense());
				}
			}

		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return loginUserBean;
	}
	
	public JSONArray getSelectedCounters(Connection con, int nModuleId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joCounter = null;
		JSONArray jaCounters = new JSONArray();
		
		try{
			sbQuery .append("select * from counter_master_")
					.append(nModuleId)
					.append(" where is_selected=true")
					.append(" ORDER BY counter_name");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joCounter = new JSONObject();
				joCounter.put("counter_id", rs.getInt("counter_id"));
				joCounter.put("query", rs.getString("query_string"));
				jaCounters.add(joCounter);
				joCounter = null;
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jaCounters;
	}
	
	public boolean isUserPAIDLicenseExpired(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bLicenseExpired = false;
		
		try {
			sbQuery	.append("SELECT EXISTS ( ")
					.append("  SELECT lic_schedule_id, module_type, start_date, end_date ")
					.append("  FROM userwise_lic_monthwise  ")
					.append("  WHERE  user_id = ? ")
					.append("    AND start_date <= now() AND end_date >= now() ")
					.append(") AS is_license_expired ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				bLicenseExpired = rst.getBoolean("is_license_expired");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return bLicenseExpired;
	}
	
	/**
	 * updates login_comment in login_history
	 * 
	 * @param con
	 * @param nLoginHistoryId
	 * @param strLoginComment
	 * @throws Exception
	 */
	public void updateLoginHistoryComment(Connection con, int nLoginHistoryId, String strLoginComment) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE login_history SET ")
					.append("  login_comment = ? ")
					.append("WHERE id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strLoginComment);
			pstmt.setInt(2, nLoginHistoryId);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			LogManager.logMethodEnd(dateLog);
		}
	}
}
