package com.appedo.credentials.DBI;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;

import net.sf.json.JSONObject;

import com.appedo.credentials.bean.PaymentBean;
import com.appedo.credentials.bean.UserBean;
import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.manager.CryptManager;
import com.appedo.credentials.util.Constants;
import com.appedo.credentials.util.UtilsFactory;
import com.appedo.manager.LogManager;

/**
 * DBI handles the database operation for User module 
 * @author navin
 *
 */
public class UserDBI {

	/**
	 * Updates password requested on 
	 * NOT_IN_USE
	 * 
	 * @param con
	 * @param strEmail
	 * @return
	 * @throws Exception
	 */
	public HashMap<Object, Object> requestForPasswordReset(Connection con, String strEmail) throws Exception
	{
		PreparedStatement pstmtUpdate = null, pstmtSelect = null;
		StringBuilder sbQuery = new StringBuilder();
		HashMap<Object, Object> hmUserDetails = new HashMap<Object, Object>();
		
		ResultSet rs = null;
		
		try {
			sbQuery	.append("update usermaster set password_reset_request_on=now() where email_id=?");
			
			pstmtUpdate = con.prepareStatement( sbQuery.toString() );
			pstmtUpdate.setString(1, strEmail);
			pstmtUpdate.executeUpdate();
			
			sbQuery.setLength(0);
			sbQuery.append("select user_id, first_name from usermaster where email_id=?");
			pstmtSelect = con.prepareStatement( sbQuery.toString() );
			pstmtSelect.setString(1, strEmail);
			
			rs = pstmtSelect.executeQuery();
			while( rs.next() ) {
				hmUserDetails.put("user_id", rs.getInt("user_id"));
				hmUserDetails.put("first_name", rs.getString("first_name"));
			}	
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;

			DataBaseManager.close(pstmtUpdate);
			pstmtUpdate = null;
			DataBaseManager.close(pstmtSelect);
			pstmtSelect = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return hmUserDetails;
	}
	
	/**
	 * Checks emailid already exists
	 * 
	 * @param con
	 * @param strEmailId
	 * @return
	 * @throws Exception
	 */
	public boolean isUserExists(Connection con, String strEmailId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bUsersExixts = false;
		
		try {
			sbQuery.append("SELECT EXISTS(SELECT email_id FROM usermaster WHERE LOWER(email_id) = LOWER(?) LIMIT 1) AS user_exists");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strEmailId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				bUsersExixts = rst.getBoolean("user_exists");
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return bUsersExixts;
	}
	
	
	public String isUserExist(Connection con, String strEmailId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strRtn = "";
		
		try {
			sbQuery.append("SELECT email_verified_on FROM usermaster WHERE LOWER(email_id) = LOWER(?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strEmailId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				if(rst.getTimestamp("email_verified_on") != null){
					strRtn =  "valid";
				}else{
					strRtn =  "notverified";
				}
			}else {
				strRtn =  "invalid";
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return strRtn;
	}
	/**
	 * Addes new user
	 * 
	 * @param con
	 * @param userBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long insertUser(Connection con, UserBean userBean) throws Exception {
		long lUserId ;
		PreparedStatement pstmtCreate = null, pstmtUpdate = null;
		
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joDefaultValues = null;
		
		try {
//			sbQuery	.append("SELECT * create_user(?, ?, ?, ?, ?, ?, ?, ? )");
			if( Constants.IS_CAPTCHA_VALIDATION_ENABLE ) {
				sbQuery	.append("INSERT INTO usermaster (email_id, password /* ? */, enterprise_id, first_name, last_name, ")
						.append("mobile_no, telephone_code, active_flag, created_by, created_on, license_level, email_verified_on, sum_measurements_used_today) ")
						.append("VALUES (?, pgp_sym_encrypt(?, ?), ?, ?, ?, ?, ?,?, ?, now(), ?, NULL, 0)");
			} else {
				sbQuery	.append("INSERT INTO usermaster (email_id, password /* ? */, enterprise_id, first_name, last_name, ")
						.append("mobile_no, telephone_code, active_flag, created_by, created_on, license_level, email_verified_on, sum_measurements_used_today) ")
						.append("VALUES (?, pgp_sym_encrypt(?, ?), ?, ?, ?, ?, ?, ?, now(), ?, now(), 0)");
			}
			pstmtCreate = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			
			pstmtCreate.setString(1, userBean.getEmailId());
			pstmtCreate.setString(2, userBean.getPassword());
			pstmtCreate.setString(3, Constants.getPasswordSaltKey());	// to Encrypt password
			if( userBean.getEnterpriseId() == 0 ) {
				pstmtCreate.setNull(4, Types.INTEGER);
			} else {
				pstmtCreate.setInt(4, userBean.getEnterpriseId());
			}
			pstmtCreate.setString(5, userBean.getFirstName());
			pstmtCreate.setString(6, userBean.getLastName());
			pstmtCreate.setString(7, UtilsFactory.replaceNull(userBean.getMobileNo(), ""));
			if( userBean.getMobileNo() == null ) {
				pstmtCreate.setNull(8, Types.INTEGER);
			} else {
				pstmtCreate.setInt(8, Integer.parseInt(userBean.getTelephoneCode()));
			}
			
			pstmtCreate.setBoolean(9, userBean.isActiveFlag());
			pstmtCreate.setLong(10, 0);	// Created-By
			pstmtCreate.setString(11, "level0");
			pstmtCreate.executeUpdate();
			lUserId = DataBaseManager.returnKey(pstmtCreate);
			
			// Update the User-Id in LoginUserBean
			//loginUserBean.setUserId(lUserId);
			
			// get license values
			joDefaultValues = getDefaultValues(con, lUserId);
			
			// updating default values.
			 
			sbQuery.setLength(0);
			sbQuery	.append("UPDATE usermaster SET apm_max_agents=?, apm_max_counters=?, lt_max_vusers=?, sum_desktop_max_measurements=?, sum_mobile_max_measurements=?, dd_max_profilers=?, rum_max_test=?, ci_max_events=?, ci_max_properties=? WHERE user_id=? ");
			pstmtUpdate = con.prepareStatement(sbQuery.toString());
			pstmtUpdate.setLong(1, joDefaultValues.getLong("max_agents"));
			pstmtUpdate.setLong(2, joDefaultValues.getLong("max_counters_per_agent"));
			pstmtUpdate.setLong(3, joDefaultValues.getLong("max_vusers"));
			pstmtUpdate.setLong(4, joDefaultValues.getLong("max_measurement_per_day"));
			pstmtUpdate.setLong(5, joDefaultValues.getLong("max_measurement_per_day"));
			pstmtUpdate.setLong(6, joDefaultValues.getLong("max_profiler_per_user"));
			pstmtUpdate.setLong(7, joDefaultValues.getLong("rum_max_test"));
			pstmtUpdate.setLong(8, joDefaultValues.getLong("max_events"));
			pstmtUpdate.setLong(9, joDefaultValues.getLong("max_properties"));
			pstmtUpdate.setLong(10, lUserId);
			pstmtUpdate.executeUpdate();
			
			// updating encrypted userid
			updateEncryptedUserId(con, lUserId);
			
//			if(userBean.getSumUrl() != null){
//				sbQuery.setLength(0);
//				
//				sbQuery	.append("UPDATE usermaster SET email_verified_on = now() WHERE user_id = ? ");
//				pstmtquicksum = con.prepareStatement(sbQuery.toString());
//				pstmtquicksum.setLong(1, lUserId);
//				pstmtquicksum.executeUpdate();
//			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(pstmtCreate);
			pstmtCreate = null;
			
			DataBaseManager.close(pstmtUpdate);
			pstmtUpdate = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return lUserId;
	}
	
	public long insertPaymentResult(Connection con, PaymentBean paymentBean)throws Exception
	{
		PreparedStatement pstmtCreate = null;
		StringBuilder sbQuery = new StringBuilder();
		
		ResultSet rstPrimaryKey = null;
    	long lGeneratedKey = -1l;
		
		try
		{
			sbQuery	.append("INSERT INTO paypal_payment_master(user_id, license_level, tx_date, payer_paypal_id, payer_paypal_email_id, ")
			.append("tx_unique_id, transaction_type, mc_currency, amount, tx_status, receiver_paypal_id, receiver_paypal_email_id, remarks, paypal_tx_full_response) ")
			.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?::json)"); 
			
			pstmtCreate = con.prepareStatement(sbQuery.toString(), Statement.RETURN_GENERATED_KEYS);
			//stmt.execute(strQuery, Statement.RETURN_GENERATED_KEYS);
			//pstmtCreate.execute(sbQuery.toString(), Statement.RETURN_GENERATED_KEYS);
	
			pstmtCreate.setInt(1, paymentBean.getUserId());
			pstmtCreate.setString(2, paymentBean.getLicenseLevel());
			pstmtCreate.setTimestamp(3, new Timestamp(paymentBean.getTxtDate().getTime()));
			pstmtCreate.setString(4, paymentBean.getPayerPaypalId());
			pstmtCreate.setString(5, paymentBean.getPayerPaypalEmailID());
			pstmtCreate.setString(6, paymentBean.getTxtUniqueId());
			pstmtCreate.setString(7, paymentBean.getTxtType());
			pstmtCreate.setString(8, paymentBean.getMCcurrency());
			pstmtCreate.setFloat(9, paymentBean.getAmount());
			pstmtCreate.setString(10, paymentBean.getTxtStstus());
			pstmtCreate.setString(11, paymentBean.getReceiverPaypalId());
			pstmtCreate.setString(12, paymentBean.getReceiverPaypalEmailId());
			pstmtCreate.setString(13, paymentBean.getPaymentResultJSON().toString());
			pstmtCreate.executeUpdate();
			
			// get the auto increamented value, which got created
			rstPrimaryKey = pstmtCreate.getGeneratedKeys();
			while( rstPrimaryKey.next() ){
				lGeneratedKey = rstPrimaryKey.getLong(1);
			}
		}catch (Exception e) {
			LogManager.errorLog(e);

			e.printStackTrace();
			throw e;
		} finally {
			DataBaseManager.close(pstmtCreate);
			pstmtCreate = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return lGeneratedKey;
	}
	
	public JSONObject getDefaultValues(Connection con, long lUserId) throws Exception {
		
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rs = null;
		
		JSONObject joDefaultValues = null;
		try{
			sbQuery .append("SELECT max_agents, max_counters_per_agent, max_vusers, scp.max_measurement_per_day, ")
					.append("max_profiler_per_user, rum_max_test, ccp.max_events, ccp.max_properties ")
					.append("FROM apm_config_parameters acp ")
					.append("INNER JOIN sum_config_parameters scp on scp.lic_internal_name = acp.lic_internal_name ")
					.append("INNER JOIN lt_config_parameters lcp on lcp.lt_license = acp.lic_internal_name ")
					.append("INNER JOIN dd_config_parameters dcp on dcp.lic_internal_name = acp.lic_internal_name ")
					.append("INNER JOIN rum_config_parameters rcp on rcp.lic_internal_name = acp.lic_internal_name ")
					.append("INNER JOIN ci_config_parameters ccp on ccp.lic_internal_name = acp.lic_internal_name and acp.lic_internal_name='level0'");
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			if(rs.next()){
				joDefaultValues = new JSONObject();
				joDefaultValues.put("max_agents", rs.getLong("max_agents"));
				joDefaultValues.put("max_counters_per_agent", rs.getLong("max_counters_per_agent"));
				joDefaultValues.put("max_vusers", rs.getLong("max_vusers"));
				joDefaultValues.put("max_measurement_per_day", rs.getLong("max_measurement_per_day"));
				joDefaultValues.put("max_profiler_per_user", rs.getLong("max_profiler_per_user"));
				joDefaultValues.put("rum_max_test", rs.getLong("rum_max_test"));
				joDefaultValues.put("max_events", rs.getLong("max_events"));
				joDefaultValues.put("max_properties", rs.getLong("max_properties"));
				
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return joDefaultValues;
	}

	public void  updateEncryptedUserId(Connection con, long lUserId) throws Exception {
	
		PreparedStatement pstmt1 = null;
		StringBuilder sbQuery = new StringBuilder();
		String strEncryptedUserId;
		try{
			strEncryptedUserId = CryptManager.encryptEncodeURL((""+lUserId).trim());	
			sbQuery.setLength(0);
			
			sbQuery	.append("UPDATE usermaster SET encrypted_user_id=? WHERE user_id=?");
			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.setString(1, strEncryptedUserId);
			pstmt1.setLong(2, lUserId);
			pstmt1.executeUpdate();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
			
		}finally {
			DataBaseManager.close(pstmt1);
			pstmt1 = null;
			
			sbQuery = null;
		}
	}
	
	public void verifyEmailAddress(Connection con, long lUserID) throws Exception
	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery	.append("update usermaster set email_verified_on=now() where user_id=?");
			
			pstmt = con.prepareStatement( sbQuery.toString() );
			pstmt.setLong(1, lUserID);
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	public void checkInviteUsers(Connection con, long lUserId) throws Exception
	{
		PreparedStatement pstmt = null, pstmtUpdate = null, pstmstSelectEId = null, pstmtUpdEnt = null;
		ResultSet rst = null, rstEId = null;
		String emailId = null;
		int e_id = 0;
		StringBuilder sbQuery = new StringBuilder();

		try {
			// Selecting emailId for the given user_id to update user_enterprise_mapping.
			sbQuery.append("select email_id from usermaster where user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				emailId = rst.getString("email_id");
			}
			if( emailId!= null ){
				sbQuery = new StringBuilder();
				sbQuery	.append("update user_enterprise_mapping set user_id=?, status=? where email_id=?");
				pstmtUpdate = con.prepareStatement(sbQuery.toString());
				pstmtUpdate.setLong(1, lUserId);
				pstmtUpdate.setString(2, "Connected");
				pstmtUpdate.setString(3, emailId);
				int resCount = pstmtUpdate.executeUpdate();

				if(resCount > 0){
					// Selecting enterpriseId from user_enterprise_mapping by passing emailId, to update user_permission.
					sbQuery = new StringBuilder();
					sbQuery.append("select e_id from user_enterprise_mapping where email_id =? and user_id = ?");
					pstmstSelectEId = con.prepareStatement(sbQuery.toString());
					pstmstSelectEId.setString(1, emailId);
					pstmstSelectEId.setLong(2, lUserId);
					rstEId = pstmstSelectEId.executeQuery();
					UtilsFactory.clearCollectionHieracy( sbQuery );
					while( rstEId.next() ) {
						e_id = rstEId.getInt("e_id");
						if( e_id != 0 ){
							sbQuery = new StringBuilder();
							sbQuery	.append("update user_permission set user_id=? where e_id=? and email_id=?" );
							String updateUserEnterprise = sbQuery.toString();
							pstmtUpdEnt = con.prepareStatement(updateUserEnterprise);
							pstmtUpdEnt.setLong(1, lUserId);
							pstmtUpdEnt.setInt(2, e_id);
							pstmtUpdEnt.setString(3, emailId);
							pstmtUpdEnt.executeUpdate();
						}
						UtilsFactory.clearCollectionHieracy( sbQuery );
					}
				}
			}
			emailId = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(rstEId);
			rstEId = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtUpdate);
			pstmtUpdate = null;
			DataBaseManager.close(pstmstSelectEId);
			pstmstSelectEId = null;
			DataBaseManager.close(pstmtUpdEnt);
			pstmtUpdEnt = null;
		}
	}
	
	/**
	 * Updates user's RUM/CI license to `level0` for PAID-expired user
	 * 
	 * @param con
	 * @param lUserId
	 * @param strUserRUMLicLevel
	 * @return
	 * @throws Exception
	 */
	public boolean updateExpiredLicense(Connection con, long lUserId, String strUserLicLevel) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		boolean bUpdateExpiredRUMLicense = false;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT update_expired_rum_license FROM update_expired_rum_license(?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strUserLicLevel);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				bUpdateExpiredRUMLicense = rst.getBoolean("update_expired_rum_license");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return bUpdateExpiredRUMLicense;
	}
	
	/**
	 * Updates new password
	 * NOT_IN_USE
	 * 
	 * @param con
	 * @param strUserId
	 * @param strPassword
	 * @throws Exception
	 *
	public void setPassword(Connection con, String strUserId, String strPassword) throws Exception
	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery	.append("update usermaster set password=?, password_reset_request_on=null,email_verified_on=CASE WHEN email_verified_on is null THEN now() ELSE email_verified_on END where user_id=?");
			
			pstmt = con.prepareStatement( sbQuery.toString() );
			pstmt.setString(1, strPassword);
			pstmt.setLong(2, Long.parseLong(strUserId));
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	*/
	
	/**
	 * Validates the resetPassword link to be used with in 24 hrs
	 * NOT_IN_USE
	 * 
	 * @param con
	 * @param strUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isPasswordResetRequestExpired(Connection con, String strUserId) throws Exception
	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		String strStatus = null;
		boolean bStatus = false;
		ResultSet rs = null;
		
		try {
			sbQuery	.append("select CASE WHEN (now()- interval '24 hours')<password_reset_request_on or password_reset_request_on=null THEN 'active' ELSE 'expired' END as status from usermaster where user_id=?");
			pstmt = con.prepareStatement( sbQuery.toString() );
			pstmt.setLong(1, Long.parseLong(strUserId));
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				strStatus = rs.getString("status");
			}
			if(strStatus.equalsIgnoreCase("active"))
				bStatus = true;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			strStatus = null;
		}
		
		return bStatus;
	}
	
	/**
	 * gets user details based on userId
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public UserBean getUserDetails(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		
		//JSONObject joUserDetails = null;
		
		//String strPassword = "";
		
		UserBean userBean = null;
		
		try {
			strQuery = "SELECT user_id, email_id, first_name, last_name, mobile_no FROM usermaster WHERE user_id = ? ";
			
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				//strPassword = rst.getString("password");
				
				userBean = new UserBean();
				userBean.setUserId( rst.getLong("user_id") );
				userBean.setEmailId(rst.getString("email_id"));
				userBean.setFirstName(rst.getString("first_name"));
				userBean.setLastName(rst.getString("last_name"));
				userBean.setMobileNo(rst.getString("mobile_no"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return userBean;
	}
	
	/**
	 * gets user details based on emailId
	 * 
	 * @param con
	 * @param strEmailId
	 * @return
	 * @throws Exception
	 */
	public UserBean getUserDetails(Connection con, String strEmailId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		
		UserBean userBean = null;
		
		try {
			strQuery = "SELECT user_id, email_id, first_name, last_name, mobile_no, telephone_code FROM usermaster WHERE email_id = ? ";
			
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setString(1, strEmailId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				userBean = new UserBean();
				userBean.setUserId( rst.getLong("user_id") );
				userBean.setEmailId(rst.getString("email_id"));
				userBean.setFirstName(rst.getString("first_name"));
				userBean.setLastName(rst.getString("last_name"));
				userBean.setMobileNo(rst.getString("mobile_no"));
				userBean.setTelephoneCode(rst.getString("telephone_code"));
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return userBean;
	}
	
	public String getUserPassword(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "", strPassword = "";
		
		try {
			strQuery = "SELECT pgp_sym_decrypt(password, ?) AS decrypted_password FROM usermaster WHERE user_id = ?";
			
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setString(1, Constants.getPasswordSaltKey());
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				strPassword = rst.getString("decrypted_password");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return strPassword;
	}

	public void changePassword(Connection con,  Long lUserId, String strPassword) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery	.append("UPDATE usermaster SET ")
					.append("password = pgp_sym_encrypt(?, ?) ")
					.append("WHERE user_id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strPassword);
			pstmt.setString(2, Constants.getPasswordSaltKey());
			pstmt.setLong(3, lUserId);
			pstmt.execute();
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
	}
	

	public void updateProfile(Connection con, UserBean userBean) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE usermaster SET ")
					.append("first_name = ?, ")
					.append("last_name = ?, ")
					.append("mobile_no = ?, ")
					.append("modified_by = ?, ")
					.append("modified_on = NOW() ")
					.append("WHERE user_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, userBean.getFirstName());
			pstmt.setString(2, userBean.getLastName());
			pstmt.setString(3, userBean.getMobileNo());
			pstmt.setLong(4, userBean.getUserId());
			pstmt.setLong(5, userBean.getUserId());
			pstmt.execute();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
	}
	
	/**
	 * User license is expired then update records as LEVEL0 (Free/Lite)
	 * 
	 * @param con
	 * @param lUserId
	 * @param strUserLicenseLevel
	 * @throws Exception
	 */
	public boolean updateExpiredLicenseToFREE(Connection con, long lUserId, String strUserLicenseLevel) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		boolean bLicenseDegradedToLevel0 = false;
		
		try {
			strQuery = "SELECT update_expired_license_to_free(?, ?) AS has_license_degraded_to_level0";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strUserLicenseLevel);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				bLicenseDegradedToLevel0 = rst.getBoolean("has_license_degraded_to_level0");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return bLicenseDegradedToLevel0;
	}
	
	public long insertEmailVerificationHistory(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQurey = "";
		
		long lVerificationHistoryId;
		
		try {
			strQurey = "INSERT INTO login_verification_history (user_id, activity, created_on) VALUES (?, 'EMAIL_ID_VERIFICATION', now()) ";
			
			pstmt = con.prepareStatement(strQurey, PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, lUserId);
			pstmt.executeUpdate();
			
			lVerificationHistoryId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQurey = null;
		}
		
		return lVerificationHistoryId;
	}

	public long insertForgotPasswordHistory(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQurey = "";
		
		long lVerificationHistoryId = -1L;
		
		try {
			strQurey = "INSERT INTO login_verification_history (user_id, activity, created_on) VALUES (?, 'FORGOT_PASSWORD', now()) ";
			
			pstmt = con.prepareStatement(strQurey, PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, lUserId);
			pstmt.executeUpdate();
			
			lVerificationHistoryId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQurey = null;
		}
		
		return lVerificationHistoryId;
	}
	
	public boolean isVerificationLinkExpired(Connection con, long lUserId, long lVerificationHistoryId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bVerificationLinkExpired = false;
		
		try {
			sbQuery	.append("SELECT created_on < now() - interval '").append(Constants.VERIFICATION_LINK_EXPIRE_WITHIN_HOURS).append(" hours' AS is_verification_link_expired ")
					.append("FROM login_verification_history ")
					.append("WHERE id = ? ")
					.append("  AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lVerificationHistoryId);
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bVerificationLinkExpired = rst.getBoolean("is_verification_link_expired");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return bVerificationLinkExpired;
	}
	
	public void updateVerificationHistoryComment(Connection con, long lUserId, long lVerificationHistoryId, String strComment) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE login_verification_history SET ")
					.append("  first_opened_on = now(), ")
					.append("  first_opened_comment = ? ")
					.append("WHERE id = ? ")
					.append("  AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strComment);
			pstmt.setLong(2, lVerificationHistoryId);
			pstmt.setLong(3, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * Create the tables required for the SUM HeartBeat Monitor, for the given UserId.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void setupSUMHeartBeat(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT create_sum_heartbeat_tables(?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.execute();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	public void addDefaultPageSettingDetails(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "INSERT INTO default_page_settings(user_id, crit_warn_name, service_map_id, module_type, created_on, created_by) SELECT user_id, 'CRITICAL', service_map_id, 'OAD', now(), created_by FROM service_map WHERE user_id = ? AND is_system = TRUE";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	public void createChartVisualTable(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT create_chart_visualization_table(?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.execute();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
}
