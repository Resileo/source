package com.appedo.credentials.DBI;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.util.Constants;
import com.appedo.credentials.util.UtilsFactory;
import com.appedo.manager.LogManager;

public class AdminDBI {
	
	/**
	 * Pricing details from appedo_licensing
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAppedoPricingFeature(Connection con) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaPricings = new JSONArray();
		JSONObject joRtn = null, joPricing = null;
		try{
			sbQuery.append("SELECT lic_id, module_name, feature, column_name FROM appedo_licensing WHERE column_name IS NOT NULL ORDER BY lic_id");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			
			joRtn = new JSONObject();
			while(rst.next()){
				joPricing = new JSONObject();
				joPricing.put("lic_id", rst.getLong("lic_id"));
				joPricing.put("module_name",rst.getString("module_name"));
				joPricing.put("feature",rst.getString("feature"));
				joPricing.put("column_name", rst.getString("column_name"));
				
				jaPricings.add(joPricing);
				UtilsFactory.clearCollectionHieracy( joPricing );
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	 	return jaPricings;
	}
	/**
	 * Pricing details from appedo_licensing
	 * @param con
	 * @param strSelectedPeriod
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAppedoPricing(Connection con) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null;
		ResultSet rst = null, rst1 = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaPricings = new JSONArray();
		JSONArray jaLicesence = new JSONArray();
		JSONArray jaRtn = new JSONArray();
		JSONObject joPricing = null, joRtn = null;
		

		try{
			//sbQuery .append("SELECT lic_id, module_name, feature, column_name, l0 as level0, l1 as level1, l2 as level2, l3 as level3, payment_code FROM appedo_licensing ORDER BY lic_id");
			sbQuery .append("SELECT lic_id, module_name, feature, column_name, l0 as level0, l1 as level1, l2 as level2, l3 as level3, payment_code FROM appedo_licensing ORDER BY order_no");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();

			joRtn = new JSONObject();
			while(rst.next()) {
				joPricing = new JSONObject();
				joPricing.put("lic_id", rst.getLong("lic_id"));
				joPricing.put("module_name",rst.getString("module_name"));
				joPricing.put("feature",rst.getString("feature"));
				joPricing.put("level0",rst.getInt("level0"));
				joPricing.put("level1",rst.getInt("level1"));
				joPricing.put("level2",rst.getInt("level2"));
				joPricing.put("level3",rst.getInt("level3"));
				joPricing.put("column_name", rst.getString("column_name"));
				joPricing.put("payment_code", rst.getString("payment_code"));
				// added, for enterprise edit
				joPricing.put("is_edit", true);
				
				jaPricings.add(joPricing);
				
				UtilsFactory.clearCollectionHieracy( joPricing );
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(rst1);
			rst1 = null;
			DataBaseManager.close(pstmt1);
			pstmt1 = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	 	return jaPricings;
	}
	
	public JSONArray getLicesingEmails(Connection con, String strEmailId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaEmails = new JSONArray();
		JSONObject joEmail = null;
		
		try {
			
			sbQuery .append("SELECT email_id FROM usermaster WHERE CASE WHEN (SELECT view_all_users FROM usermaster WHERE email_id=?) THEN email_id IS NOT NULL ELSE email_id=? END ORDER BY email_id");			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strEmailId);
			pstmt.setString(2, strEmailId);
			rst = pstmt.executeQuery();

			while(rst.next()) {
				joEmail = new JSONObject();
				joEmail.put("email_id",rst.getString("email_id"));
				jaEmails.add(joEmail);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	 	return jaEmails;
	}

	public JSONObject getUsageDetails(Connection con, String code) throws Exception{
		ResultSet rst = null;
		PreparedStatement pstmt = null;
		JSONObject json = new JSONObject();;
		try{
			LinkedHashMap<String,String> queries = getQueries(code);
			//iterate the map and form jsonarray
			int i =1;
			if(code.equals("sumtest")){
				i =2;
			}
			for (Map.Entry<String, String> entry : queries.entrySet()){
				json.put("label_name"+i, entry.getKey());
				pstmt = con.prepareStatement(entry.getValue());
				if(code.equalsIgnoreCase("rummst")){
					switch(entry.getKey()){
					case "Last 180 Days" :
						pstmt.setString(1,"180 days");
						break;
					case "Last 30 Days" :
						pstmt.setString(1,"30 days");
						break;
					case "Last 7 Days" :
						pstmt.setString(1,"7 days");
						break;
					case "Last 24 Hours" :
						pstmt.setString(1,"1 days");
						break;
					}
				}
				rst = pstmt.executeQuery();
				if(rst.next()){
					if(code.equalsIgnoreCase("rummst")){
						json.put("label_value"+i, rst.getLong("get_rum_msmt"));
					}else{
						json.put("label_value"+i, rst.getLong("count"));
					}
				}
				i++;
			}
		}catch(Exception ex){
			LogManager.errorLog(ex);
			throw ex;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return json;
	}

	private LinkedHashMap<String,String> getQueries(String code) throws Exception{
		LinkedHashMap<String,String> queries = new LinkedHashMap<String,String>();
		switch(code){
		case "signup" :
			queries.put("Till Date","select count(*) as count from usermaster");
			queries.put("Last 30 Days","select count(*) as count from usermaster where created_on > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from usermaster where created_on > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from usermaster where created_on > now() - interval '1 days'");
			break;
		case "loggedin" :
			queries.put("Current Active","select count(*) as count from login_history where login_on > now() - interval '1 hours' and logout_on is NULL");
			queries.put("Last 30 Days","select count(*) as count from login_history where logout_on > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from login_history where logout_on > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from login_history where logout_on > now() - interval '1 days'");
			break;
		case "lt" :
			queries.put("Current Active","select count(*) as count from tblreportmaster where is_deleted = false and runstarttime <= now() and runendtime is null");
			queries.put("Last 30 Days","select count(*) as count from tblreportmaster where is_deleted = false and runendtime > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from tblreportmaster where is_deleted = false and runendtime > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from tblreportmaster where is_deleted = false and runendtime > now() - interval '1 days'");
			break;
		case "sla" :
			queries.put("Last One Hour","select count(*) as count from sla_alert_log where received_on >  now() - interval '1 hours'");
			queries.put("Last 30 Days","select count(*) as count from sla_alert_log where received_on >  now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from sla_alert_log where received_on >  now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from sla_alert_log where received_on >  now() - interval '24 hours'");
			break;
		case "agents" : 
			queries.put("Till Date","select count(*) as count from module_master WHERE module_code in ("+Constants.APM_GROUP+")");
			queries.put("Last 30 Days","select count(*) as count from module_master where created_on > now() - interval '30 days' AND module_code in ("+Constants.APM_GROUP+")");
			queries.put("Last 7 Days","select count(*) as count from module_master where created_on > now() - interval '7 days' AND module_code in ("+Constants.APM_GROUP+")");
			queries.put("Last 24 Hours","select count(*) as count from module_master where created_on > now() - interval '1 days' AND module_code in ("+Constants.APM_GROUP+")");
			break;
		case "app" :
			queries.put("Till Date","select count(*) as count from module_master  where module_code = 'APPLICATION'");
			queries.put("Last 30 Days","select count(*) as count from module_master  where module_code = 'APPLICATION' AND created_on > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from module_master  where module_code = 'APPLICATION' AND created_on > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from module_master  where module_code = 'APPLICATION' AND created_on > now() - interval '1 days'");
			break;
		case "db" :
			queries.put("Till Date","select count(*) as count from module_master  where module_code = 'DATABASE'");
			queries.put("Last 30 Days","select count(*) as count from module_master  where module_code = 'DATABASE' AND created_on > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from module_master  where module_code = 'DATABASE' AND created_on > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from module_master  where module_code = 'DATABASE' AND created_on > now() - interval '1 days'");
			break;
		case "svr" :
			queries.put("Till Date","select count(*) as count from module_master  where module_code = 'SERVER'");
			queries.put("Last 30 Days","select count(*) as count from module_master  where module_code = 'SERVER' AND created_on > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from module_master  where module_code = 'SERVER' AND created_on > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from module_master  where module_code = 'SERVER' AND created_on > now() - interval '1 days'");
			break;
		case "sumtest" :
			queries.put("Last 30 Days","select count(*) as count from sum_test_master where created_on > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from sum_test_master where created_on > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from sum_test_master where created_on > now() - interval '1 days'");
			break;
		case "sumnode" :
			queries.put("Current Active","select count(*) as count from sum_node_details where sum_node_status = 'active'");
			queries.put("Last 30 Days","select count(*) as count from sum_node_details where sum_node_status = 'active' and created_on >  now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from sum_node_details where sum_node_status = 'active' and created_on >  now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from sum_node_details where sum_node_status = 'active' and created_on >  now() - interval '1 days'");
			break;
		case "summst" :
			queries.put("Last 180 Days","select count(*) as count from sum_har_test_results where received_on > now() - interval '180 days'");
			queries.put("Last 30 Days","select count(*) as count from sum_har_test_results where received_on > now() - interval '30 days'");
			queries.put("Last 7 Days","select count(*) as count from sum_har_test_results where received_on > now() - interval '7 days'");
			queries.put("Last 24 Hours","select count(*) as count from sum_har_test_results where received_on > now() - interval '1 days'");
			break;
		case "rummst" :
			queries.put("Last 180 Days","select * from get_rum_msmt(?)");
			queries.put("Last 30 Days","select * from get_rum_msmt(?)");
			queries.put("Last 7 Days","select * from get_rum_msmt(?)");
			queries.put("Last 24 Hours","select * from get_rum_msmt(?)");
			break;
		}
		return queries;
	}
	
	public String updateLicesense(Connection con, JSONObject joLicense) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null, pstmt3 = null;
		ResultSet rst = null, rst1 = null;
		StringBuilder sbQuery = new StringBuilder();
		String strRtn = "";
		long lUserId = -1;
		try {
			
			lUserId = getUserId(con, joLicense.getString("email_id"));
			joLicense.put("lUserId", lUserId);
//			strRtn = returnExistingLic(con, joLicense);
//			if(strRtn.length()==0){}else{
//				return strRtn;
//			}
			sbQuery .append("UPDATE usermaster SET license_level = ? ")
			//					.append("apm_lic_start_date = ?::timestamp, sum_lic_start_date = ?::timestamp, lt_lic_start_date = ?::timestamp, rum_lic_start_date = ?::timestamp, dd_lic_start_date = ?::timestamp, sla_lic_start_date = ?::timestamp, ")
			//					.append("apm_lic_end_date = ?::timestamp, sum_lic_end_date = ?::timestamp, lt_lic_end_date = ?::timestamp, rum_lic_end_date = ?::timestamp, dd_lic_end_date = ?::timestamp, sla_lic_end_date = ?::timestamp, ")
			//					.append("apm_lic_renewal_date = now(), sum_lic_renewal_date = now(), lt_lic_renewal_date = now(), rum_lic_renewal_date = now(), dd_lic_renewal_date = now(), sla_lic_renewal_date = now() ")
								.append("WHERE email_id=? ");
						
						pstmt1 = con.prepareStatement(sbQuery.toString());
			//			for(int i=1; i<=8; i++){
							pstmt1.setString(1, joLicense.getString("lic_type"));
			//			}
			//			for(int j=9; j<=14; j++){
			//				pstmt1.setString(j, joLicense.getString("lic_start_date"));
			//			}
			//			for(int k=15; k<=20; k++){
			//				pstmt1.setString(k, joLicense.getString("lic_end_date"));
			//			}
						pstmt1.setString(2, joLicense.getString("email_id"));
						pstmt1.execute();
						
						
						sbQuery.setLength(0);
						
						switch(joLicense.getString("lic_category")) {
						
							case "New License" : {
								strRtn = updateRenewalLicense(con, joLicense, lUserId);
								break;
							}
							case "Renewal" : {
								strRtn = updateRenewalLicense(con, joLicense, lUserId);
								break;
							}
							case "Top-Up" : {
								strRtn = updateExtensionLicense(con, joLicense, lUserId);
								break;
							}
						
						}
						return strRtn;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmt1);
			pstmt1 = null;
			DataBaseManager.close(pstmt3);
			pstmt3 = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
	}

	public String updateRenewalLicense(Connection con, JSONObject joLicense, long lUserId) throws Exception {
		

		String strPaymentDetails = null;
		StringBuilder sbQuery = new StringBuilder(); 
		Statement stmt = null;
		PreparedStatement pstmt = null, pstmt1 = null, pStatement = null;
		ResultSet rs = null;
		String strModules[] = "APM,PROFILER,LT,SUM,RUM,COMMON,SLA,ENTERPRISE".split(",");
		HashMap<String, Long> hm = null;
		String strRtn ;
		try{
//			strRtn = returnExistingLic(con, joLicense);
//			if(strRtn.length() !=0 ){
//				return strRtn;
//			}else{
				String strStartDate = joLicense.getString("lic_start_date");
				String strEndDate = joLicense.getString("lic_end_date");
				// For existing license update
				/*if(joLicense.containsKey("lic_schedule_id") && joLicense.get("lic_schedule_id") != null){*/
				if(joLicense.optLong("lic_schedule_id")>0){
					// For monthly license
					if(!joLicense.getString("lic_period").equals("Annual")){
						
						// For Enterprise license
						if(joLicense.getString("lic_type").equalsIgnoreCase("level3")){
							strRtn = returnExistingLic(con, joLicense, true);
							if(strRtn.length() !=0 ){
								strRtn = "License already available for these periods:<br/>" + strRtn + "So please do <b>Daily Renewal</b> for the required days.";
								return strRtn;
							}else{
								sbQuery.setLength(0);
								sbQuery .append("UPDATE userwise_lic_monthwise SET ")
										.append("lic_type= ?")
										.append(", license_level= ?")
										.append(", lic_category= ?, ")
										.append("start_date = '")
										.append(strStartDate)
										.append("'::timestamp, end_date ='")
										.append(strEndDate)
										.append("'::timestamp ")
										.append(", reference = CONCAT(reference ,' ")
										.append(joLicense.getString("reference"))
										.append("') WHERE user_id = ? AND start_date = ")
										.append(" (SELECT start_date FROM userwise_lic_monthwise WHERE lic_schedule_id = ")
										.append(joLicense.getLong("lic_schedule_id"))
										.append(" )");
								pStatement = con.prepareStatement(sbQuery.toString());
								pStatement.setString(1, joLicense.getString("lic_period"));
								pStatement.setString(2, joLicense.getString("lic_type"));
								pStatement.setString(3, joLicense.getString("lic_category").equals("Top-Up")?"Top-Up":"Renewal");
								pStatement.setLong(4, lUserId);
								
								pStatement.execute();
								sbQuery.setLength(0);
								JSONArray jaPricingData = joLicense.getJSONArray("pricing_data");
								for(int i=0; i<jaPricingData.size(); i++){
									JSONObject joPriceData = jaPricingData.getJSONObject(i);
									if(joPriceData.getString("payment_code").length() != 0 ) {
										continue;
									}
									String strColumnName = "", strTableName = "";
									sbQuery .append("SELECT table_name, userwise_column FROM appedo_licensing WHERE lic_id=?");
									pstmt = con.prepareStatement(sbQuery.toString());
									pstmt.setLong(1, joPriceData.getLong("lic_id"));
									rs = pstmt.executeQuery();
									if(rs.next()){
										strTableName = rs.getString("table_name");
										strColumnName = rs.getString("userwise_column");
									}
									sbQuery.setLength(0);
									sbQuery	.append("UPDATE userwise_lic_monthwise SET ")
											.append(strColumnName)
											.append(" = ")
											.append(joPriceData.getLong("enterprise"))
											.append(" WHERE user_id = '")
											.append(lUserId)
											.append("' AND start_date = '")
											.append(strStartDate)
											.append("' AND end_date ='")
											.append(strEndDate)
											.append("' AND license_level='")
											.append(joLicense.getString("lic_type")+"'");
									
									pstmt1 = con.prepareStatement(sbQuery.toString());
									pstmt1.execute();
									sbQuery.setLength(0);
								}
							}
						}
						// For non Enterprise license
						else{
							strRtn = returnExistingLic(con, joLicense, true);
							if(strRtn.length() !=0 ){
								strRtn = "License already available for these periods:<br/>" + strRtn + "So please do <b>Daily Renewal</b> for the required days.";
								return strRtn;
							}else{
								sbQuery .append("SELECT max_agents, max_counters_per_agent, ")
								.append("scp.max_measurement_per_day, scp.max_measurement_per_day, max_location as sum_max_cities_per_test, ")
								.append("max_profiler_per_user, ")
								.append("max_vusers, lt_max_run_per_day as  lt_max_run_per_day, ")
								.append("rum_max_test, max_events as ci_max_events, max_properties  as ci_max_properties, ")
								.append("max_sla, max_actions, ")
								.append("max_duration, max_load_gen, rum_max_measurement_per_month, named_user, acp.report_retention_in_days ")
								.append("FROM apm_config_parameters acp  ")
								.append("INNER JOIN sum_config_parameters scp on acp.lic_internal_name = scp.lic_internal_name ")
								.append("INNER JOIN dd_config_parameters dcp on dcp.lic_internal_name = scp.lic_internal_name ")
								.append("INNER JOIN rum_config_parameters rcp on rcp.lic_internal_name = scp.lic_internal_name ")
								.append("INNER JOIN lt_config_parameters lcp on lcp.lt_license = scp.lic_internal_name ")
								.append("INNER JOIN ci_config_parameters ccp on ccp.lic_internal_name = scp.lic_internal_name ")
								.append("INNER JOIN sla_config_parameters slacp on slacp.lic_internal_name = scp.lic_internal_name AND scp.lic_internal_name = ?");
								pstmt = con.prepareStatement(sbQuery.toString());
								pstmt.setString(1, joLicense.getString("lic_type"));
								rs = pstmt.executeQuery();
								if(rs.next()){
									hm = new HashMap<String, Long>();
									hm.put("max_agents", rs.getLong("max_agents"));
									hm.put("max_counters_per_agent", rs.getLong("max_counters_per_agent"));
									hm.put("max_measurement_per_day", rs.getLong("max_measurement_per_day"));
									hm.put("sum_max_cities_per_test", rs.getLong("sum_max_cities_per_test"));
									hm.put("max_profiler_per_user", rs.getLong("max_profiler_per_user"));
									hm.put("max_vusers", rs.getLong("max_vusers"));
									hm.put("lt_max_run_per_day", rs.getLong("lt_max_run_per_day"));
									hm.put("rum_max_test", rs.getLong("rum_max_test"));
									hm.put("ci_max_events", rs.getLong("ci_max_events"));
									hm.put("ci_max_properties", rs.getLong("ci_max_properties"));
									hm.put("max_sla", rs.getLong("max_sla"));
									hm.put("max_actions", rs.getLong("max_actions"));
									hm.put("max_duration", rs.getLong("max_duration"));
									hm.put("max_load_gen", rs.getLong("max_load_gen"));
									hm.put("rum_max_measurement_per_month", rs.getLong("rum_max_measurement_per_month"));
									hm.put("named_user", rs.getLong("named_user"));
									hm.put("report_retention_in_days", rs.getLong("report_retention_in_days"));
									
								}
								
								sbQuery.setLength(0);
								
								sbQuery .append("UPDATE userwise_lic_monthwise SET  apm_max_agents = ")
										.append(hm.get("max_agents"))
										.append(", apm_max_counters = ")
										.append(hm.get("max_counters_per_agent"))
										.append(", sum_desktop_max_measurements = ")
										.append(hm.get("max_measurement_per_day"))
										.append(", sum_mobile_max_measurements = ")
										.append(hm.get("max_measurement_per_day"))
										.append(", sum_max_cities_per_test = ")
										.append(hm.get("sum_max_cities_per_test"))
										.append(", dd_max_profilers = ")
										.append(hm.get("max_profiler_per_user"))
										.append(", lt_max_vusers = ")
										.append(hm.get("max_vusers"))
										.append(", lt_max_run_per_day = ")
										.append(hm.get("lt_max_run_per_day"))
										.append(", rum_max_test = ")
										.append(hm.get("rum_max_test"))
										.append(", ci_max_events = ")
										.append(hm.get("ci_max_events"))
										.append(", ci_max_properties = ")
										.append(hm.get("ci_max_properties"))
										.append(", sla_max_sla = ")
										.append(hm.get("max_sla"))
										.append(", sla_max_actions = ")
										.append(hm.get("max_actions"))
										.append(", lic_type= ?")
										.append(", license_level= ?")
										.append(", lic_category= ?")
										.append(", max_duration = ")
										.append(hm.get("max_duration"))
										.append(", max_load_gen = ")
										.append(hm.get("max_load_gen"))
										.append(", rum_max_measurement_per_month = ")
										.append(hm.get("rum_max_measurement_per_month"))
										.append(", named_user = ")
										.append(hm.get("named_user"))
										.append(", report_retention_in_days = ")
										.append(hm.get("report_retention_in_days"))
										.append(", reference = CONCAT(reference ,' ")
										.append(joLicense.getString("reference"))
										.append("'), start_date = '")
										.append(strStartDate)
										.append("'::timestamp, end_date ='")
										.append(strEndDate)
										.append("'::timestamp ")
										.append("WHERE user_id = ? AND lic_category = ? AND start_date = ")
										.append(" (SELECT start_date FROM userwise_lic_monthwise WHERE lic_schedule_id = ")
										.append(joLicense.getLong("lic_schedule_id"))
										.append(" ) AND end_date = (SELECT end_date FROM userwise_lic_monthwise WHERE lic_schedule_id = ")
										.append(joLicense.getLong("lic_schedule_id"))
										.append(" )");
								pstmt1 = con.prepareStatement(sbQuery.toString());
								pstmt1.setString(1, joLicense.getString("lic_period"));
								pstmt1.setString(2, joLicense.getString("lic_type"));
								pstmt1.setString(3, joLicense.getString("lic_category").equals("Top-Up")?"Top-Up":"Renewal");
								pstmt1.setLong(4, lUserId);
								pstmt1.setString(5, joLicense.getString("lic_category"));
								
								pstmt1.execute();
							}
						}
						
					}else{
						strRtn = returnExistingLic(con, joLicense, false);
						if(strRtn.length() !=0 ){
							strRtn = "License already available for these periods:<br/>" + strRtn + "So please do <b>Daily Renewal</b> for the required days.";
							return strRtn;
						}else{
							updateAnnualLicense(con, joLicense, lUserId);
						}
					}
				}
				// For new license
				
				// For Enterprise(level3) license
				else if(joLicense.getString("lic_type").equalsIgnoreCase("level3")){
					
					strRtn = returnExistingLic(con, joLicense, false);
					if(strRtn.length() !=0 ){
						strRtn = "License already available for these periods:<br/>" + strRtn + "So please do <b>Daily Renewal</b> for the required days.";
						return strRtn;
					}
					//For non Enterprise license
					else{
						// For Monthly new license
						if(!joLicense.getString("lic_period").equals("Annual")){
							stmt = con.createStatement();
							for(int j=0; j<strModules.length; j++){
							sbQuery .append("INSERT INTO userwise_lic_monthwise (user_id, enterprise_id, module_type, start_date, end_date, lic_type, license_level, lic_category, reference, created_on, created_by) ")
									.append("SELECT user_id, enterprise_id,'")
									.append(strModules[j])
									.append("','")
									.append(strStartDate)
									.append("'::timestamp as start_date , '")
									.append(strEndDate)
									.append("'::timestamp as end_date, '")
									.append(joLicense.getString("lic_period"))
									.append("' as lic_type, '")
									.append(joLicense.getString("lic_type"))
									.append("' as license_level, '")
									.append(joLicense.getString("lic_category").equals("Top-Up")?"Top-Up":"Renewal")
									.append("' as lic_category, '")
									.append(joLicense.getString("reference"))
									.append("', now() as created_on, ").append(joLicense.getLong("user_id"))
									.append(" FROM usermaster WHERE email_id='")
									.append(joLicense.getString("email_id")).append("'");
							stmt.addBatch(sbQuery.toString());
							sbQuery.setLength(0);
							}
							int x[] = stmt.executeBatch();
							sbQuery.setLength(0);
							JSONArray jaPricingData = joLicense.getJSONArray("pricing_data");
							for(int i=0; i<jaPricingData.size(); i++){
								JSONObject joPriceData = jaPricingData.getJSONObject(i);
								
								if(joPriceData.getString("payment_code").length() != 0 ) {
									continue;
								}
								
								String strColumnName = "", strTableName = "";
								sbQuery .append("SELECT table_name, userwise_column FROM appedo_licensing WHERE lic_id=?");
								pstmt = con.prepareStatement(sbQuery.toString());
								pstmt.setLong(1, joPriceData.getLong("lic_id"));
								rs = pstmt.executeQuery();
								if(rs.next()){
									strTableName = rs.getString("table_name");
									strColumnName = rs.getString("userwise_column");
								}
								//LogManager.errorLog("joPriceData: "+joPriceData);
								sbQuery.setLength(0);
								sbQuery	.append("UPDATE userwise_lic_monthwise SET ")
										.append(strColumnName)
										.append(" = ")
										.append(joPriceData.getLong("enterprise"))
										.append(" WHERE user_id = ")
										.append(lUserId);
								pstmt1 = con.prepareStatement(sbQuery.toString());
								pstmt1.execute();
								sbQuery.setLength(0);
							}
						}else{
							updateAnnualLicense(con, joLicense, lUserId);
						}
					}
					
				}else{
					strRtn = returnExistingLic(con, joLicense, false);
					if(strRtn.length() !=0 ){
						strRtn = "License already available for these periods:<br/>" + strRtn + "So please do <b>Daily Renewal</b> for the required days.";
						return strRtn;
					}else{
						if(!joLicense.getString("lic_period").equals("Annual")){
							stmt = con.createStatement();

							if(joLicense.containsKey("payment_details"))
							{
								strPaymentDetails = UtilsFactory.makeValidVarchar(joLicense.getString("payment_details"));
							}
							else
							{
								strPaymentDetails = null;
							}
							for(int i=0; i<strModules.length; i++){
							sbQuery .append("INSERT INTO userwise_lic_monthwise (user_id, enterprise_id, module_type, ")
									.append("apm_max_agents, apm_max_counters, ")
									.append("sum_desktop_max_measurements, sum_mobile_max_measurements, sum_max_cities_per_test, ")
									.append("dd_max_profilers, ")
									.append("lt_max_vusers, lt_max_run_per_day, ")
									.append("rum_max_test, ")
									.append("ci_max_events, ci_max_properties, ")
									.append("sla_max_sla, sla_max_actions, ")
									.append("start_date, end_date, lic_type, license_level, lic_category, reference, payment_details, ")
									.append("max_duration, max_load_gen, rum_max_measurement_per_month, named_user, report_retention_in_days,")
									.append(" created_on, created_by, digest_send_to_alert_emailIds) ")
									.append("SELECT user_id, enterprise_id, '")
									.append(strModules[i])
									.append("' as module_type, sample.* FROM usermaster ")
									.append("LEFT JOIN ( ")
									.append("SELECT max_agents, max_counters_per_agent, ")
									.append("scp.max_measurement_per_day, scp.max_measurement_per_day, max_location as sum_max_cities_per_test, ")
									.append("max_profiler_per_user, ")
									.append("max_vusers, lt_max_run_per_day as  lt_max_run_per_day, ")
									.append("rum_max_test, max_events as ci_max_events, max_properties  as ci_max_properties, ")
									.append("max_sla, max_actions, '")
									.append(strStartDate)
									.append("'::timestamp as start_date , '")
									.append(strEndDate)
									.append("'::timestamp as end_date, '")
									.append(joLicense.getString("lic_period"))
									.append("' as lic_type, '")
									.append(joLicense.getString("lic_type"))
									.append("' as license_level, '")
									.append(joLicense.getString("lic_category").equals("Top-Up")?"Top-Up":"Renewal")
									.append("' as lic_category, '")
									.append(joLicense.getString("reference"))
									/*.append("','").append(joLicense.getString("payment_details"))
									.append("'::json as payment_details, ")
									*/
									.append("',").append(strPaymentDetails)
									.append("::json as payment_details, ")
									.append("max_duration, max_load_gen, rum_max_measurement_per_month, named_user, acp.report_retention_in_days,")
									.append("now() as created_on, ")
									.append(joLicense.getLong("user_id"))
									.append(" as created_by, ")
									.append(joLicense.getString("lic_type").equals("level2")?true:false)
									.append(" FROM apm_config_parameters acp ")
									.append("INNER JOIN sum_config_parameters scp on acp.lic_internal_name = scp.lic_internal_name ")
									.append("INNER JOIN dd_config_parameters dcp on dcp.lic_internal_name = scp.lic_internal_name ")
									.append("INNER JOIN rum_config_parameters rcp on rcp.lic_internal_name = scp.lic_internal_name ")
									.append("INNER JOIN lt_config_parameters lcp on lcp.lt_license = scp.lic_internal_name ")
									.append("INNER JOIN ci_config_parameters ccp on ccp.lic_internal_name = scp.lic_internal_name ")
									.append("INNER JOIN sla_config_parameters slacp on slacp.lic_internal_name = scp.lic_internal_name AND scp.lic_internal_name = '")
									.append(joLicense.getString("lic_type"))
									.append("') as  sample ON 1=1 ")
									.append("WHERE email_id='")
									.append(joLicense.getString("email_id"))
									.append("'");
							
								stmt.addBatch(sbQuery.toString());
								sbQuery.setLength(0);
							}
							int exe[] = stmt.executeBatch();
						}else{
							updateAnnualLicense(con, joLicense, lUserId);
						}
					}
				}
				strRtn = "License upgraded successfully.";
				return strRtn;
//			}
		}catch(Exception e){
			LogManager.errorLog(e);
			 SQLException sqlExcpNext = null;
			   if( e instanceof SQLException ) {
			    while( (sqlExcpNext = ((SQLException)e).getNextException()) != null) {
			     LogManager.errorLog(sqlExcpNext);
			     sqlExcpNext.printStackTrace();
			    }
			   }
			throw e;
		}finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(stmt);
			stmt = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmt1);
			pstmt1 = null;
		}
	}
	
	public void updateAnnualLicense(Connection con, JSONObject joLicense, long lUserId) throws Exception {
		
		Statement stmt = null;
		PreparedStatement pstmt = null, pstmt1 = null, pstmt2 = null;
		ResultSet rs = null;
		String strModules[] = "APM,PROFILER,LT,SUM,RUM,COMMON,SLA,ENTERPRISE".split(",");
		StringBuilder sbQuery = new StringBuilder();
		try{
			String strStartDate = joLicense.getString("lic_start_date");
			String strEndDate = joLicense.getString("lic_end_date");
			
//			sbQuery .append("DELETE FROM userwise_lic_monthwise where user_id = ? AND end_date >= ?::timestamp");
//			
//			pstmt2 = con.prepareStatement(sbQuery.toString());
//			pstmt2.setLong(1, lUserId);
//			pstmt2.setString(2, strStartDate);
//			pstmt2.execute();
			
			
			sbQuery.setLength(0);
			for(int k=0; k<12; k++){
				if(joLicense.getString("lic_type").equalsIgnoreCase("level3")){
					stmt = con.createStatement();
					for(int j=0; j<strModules.length; j++){
					sbQuery .append("INSERT INTO userwise_lic_monthwise (user_id, enterprise_id, module_type, start_date, end_date, lic_type, license_level, lic_category, reference, created_on, created_by) ")
							.append("SELECT user_id, enterprise_id,'")
							.append(strModules[j])
							.append("','")
							.append(strStartDate)
							.append("'::timestamp +'").append(k)
							.append("mon' as start_date , '")
							.append(strStartDate)
							.append("'::timestamp +'").append(k+1)
							.append(" mon' - interval '1sec' as end_date , '")
							.append("Monthly")
							.append("' as lic_type, '")
							.append(joLicense.getString("lic_type"))
							.append("' as license_level, '")
							.append(joLicense.getString("lic_category").equals("Top-Up")?"Top-Up":"Renewal")
							.append("' as lic_category, '")
							.append(joLicense.getString("reference"))
							.append("', now() as created_on, ").append(joLicense.getLong("user_id"))
							.append(" FROM usermaster WHERE email_id='")
							.append(joLicense.getString("email_id")).append("'");
					stmt.addBatch(sbQuery.toString());
					sbQuery.setLength(0);
					}
					int x[] = stmt.executeBatch();
					sbQuery.setLength(0);
					JSONArray jaPricingData = joLicense.getJSONArray("pricing_data");
					for(int i=0; i<jaPricingData.size(); i++){
						JSONObject joPriceData = jaPricingData.getJSONObject(i);
						String strColumnName = "", strTableName = "";
						sbQuery .append("SELECT table_name, userwise_column FROM appedo_licensing WHERE lic_id=?");
						pstmt = con.prepareStatement(sbQuery.toString());
						pstmt.setLong(1, joPriceData.getLong("lic_id"));
						rs = pstmt.executeQuery();
						if(rs.next()){
							strTableName = rs.getString("table_name");
							strColumnName = rs.getString("userwise_column");
						}
						sbQuery.setLength(0);
						sbQuery	.append("UPDATE userwise_lic_monthwise SET ")
								.append(strColumnName)
								.append(" = ")
								.append(joPriceData.getLong("enterprise"))
								.append(" WHERE user_id = ")
								.append(lUserId);
						pstmt1 = con.prepareStatement(sbQuery.toString());
						pstmt1.execute();
						sbQuery.setLength(0);
					}
				}else{
					stmt = con.createStatement();
					for(int i=0; i<strModules.length; i++){
					sbQuery .append("INSERT INTO userwise_lic_monthwise (user_id, enterprise_id, module_type, ")
							.append("apm_max_agents, apm_max_counters, ")
							.append("sum_desktop_max_measurements, sum_mobile_max_measurements, sum_max_cities_per_test, ")
							.append("dd_max_profilers, ")
							.append("lt_max_vusers, lt_max_run_per_day, ")
							.append("rum_max_test, ")
							.append("ci_max_events, ci_max_properties, ")
							.append("sla_max_sla, sla_max_actions, ")
							.append("start_date, end_date, lic_type, license_level, lic_category, reference, ")
							.append("max_duration, max_load_gen, rum_max_measurement_per_month, named_user, report_retention_in_days,")
							.append(" created_on, created_by) ")
							.append("SELECT user_id, enterprise_id, '")
							.append(strModules[i])
							.append("' as module_type, sample.* FROM usermaster ")
							.append("LEFT JOIN ( ")
							.append("SELECT max_agents, max_counters_per_agent, ")
							.append("scp.max_measurement_per_day, scp.max_measurement_per_day, max_location as sum_max_cities_per_test, ")
							.append("max_profiler_per_user, ")
							.append("max_vusers, lt_max_run_per_day as  lt_max_run_per_day, ")
							.append("rum_max_test, max_events as ci_max_events, max_properties  as ci_max_properties, ")
							.append("max_sla, max_actions, '")
							.append(strStartDate)
							.append("'::timestamp +'").append(k)
							.append(" mon' as start_date , '")
							.append(strStartDate)
							.append("'::timestamp +'").append(k+1)
							.append(" mon' - interval '1sec' as end_date , '")
							.append("Monthly")
							.append("' as lic_type, '")
							.append(joLicense.getString("lic_type"))
							.append("' as license_level, '")
							.append(joLicense.getString("lic_category").equals("Top-Up")?"Top-Up":"Renewal")
							.append("' as lic_category, '")	
							.append(joLicense.getString("reference"))
							.append("', max_duration, max_load_gen, rum_max_measurement_per_month, named_user, acp.report_retention_in_days,")
							.append("now() as created_on, ")
							.append(joLicense.getLong("user_id"))
							.append(" as created_by ")
							.append("FROM apm_config_parameters acp ")
							.append("INNER JOIN sum_config_parameters scp on acp.lic_internal_name = scp.lic_internal_name ")
							.append("INNER JOIN dd_config_parameters dcp on dcp.lic_internal_name = scp.lic_internal_name ")
							.append("INNER JOIN rum_config_parameters rcp on rcp.lic_internal_name = scp.lic_internal_name ")
							.append("INNER JOIN lt_config_parameters lcp on lcp.lt_license = scp.lic_internal_name ")
							.append("INNER JOIN ci_config_parameters ccp on ccp.lic_internal_name = scp.lic_internal_name ")
							.append("INNER JOIN sla_config_parameters slacp on slacp.lic_internal_name = scp.lic_internal_name AND scp.lic_internal_name = '")
							.append(joLicense.getString("lic_type"))
							.append("') as  sample ON 1=1 ")
							.append("WHERE email_id='")
							.append(joLicense.getString("email_id"))
							.append("'");
					
						stmt.addBatch(sbQuery.toString());
						sbQuery.setLength(0);
					}
					int exe[] = stmt.executeBatch();
				}
			}
		} catch (Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(stmt);
			stmt = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmt1);
			pstmt1 = null;
		}
	}
	
	public String updateExtensionLicense(Connection con, JSONObject jolic, long lUserId) throws Exception {
		
		Statement stmt = null;
		StringBuilder sbQuery = new StringBuilder();
		String strModules[] = "LT,SUM".split(",");
		try{
//			if(jolic.containsKey("lic_schedule_id")){
//				// top up update
//				updateExtensionDetails(con, jolic, lUserId);
//			}else{
				// top up insert
				stmt = con.createStatement();
				for(int i = 0; i<strModules.length; i++){
					sbQuery .append("INSERT INTO userwise_lic_monthwise(user_id, module_type, start_date, end_date, ")
							.append("sum_desktop_max_measurements, sum_mobile_max_measurements, lt_max_run_per_day, lic_type, license_level, lic_category, reference, created_on) ")
							.append("SELECT ")
							.append(lUserId).append(", '")
							.append(strModules[i])
							.append("', '")
							.append(jolic.getString("lic_start_date"))
							.append("'::timestamp, '")
							.append(jolic.getString("lic_end_date"))
							.append("'::timestamp, ")
							.append("max_measurement_per_day as sum_desktop_max_measurements, max_measurement_per_day as sum_mobile_max_measurements, lt_max_run_per_day, '")
							.append(jolic.getString("lic_period")).append("', '")
							.append(jolic.getString("lic_type")).append("', '")
							.append(jolic.getString("lic_category")).append("', '")
							.append(jolic.getString("reference")).append("', now() as created_on FROM lt_config_parameters lcp ")
							.append("INNER JOIN sum_config_parameters scp on lcp.lt_license = scp.lic_internal_name AND lcp.lt_license = '")
							.append(jolic.getString("lic_type"))
							.append("'");
							
					stmt.addBatch(sbQuery.toString());
					sbQuery.setLength(0);
				}
				int exe[] = stmt.executeBatch();
//			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(stmt);
			stmt = null;
		}
		return "License upgraded successfully.";
	}

	/**
	 * update access rights for a user 
	 * (ie.. user has privilege to access License management/Usage metrics)
	 * 
	 * @param con
	 * @param strEmailId
	 * @param bUseLiceseManagement
	 * @param bUseUsageMetric
	 * @param nModifiedUserId
	 * @return
	 * @throws Exception
	 */
	public int updateUserAccessRights(Connection con, String strEmailId, boolean bUseLiceseManagement, boolean bUseUsageMetric, int nModifiedUserId) throws Exception {
		PreparedStatement pstmt = null;

		StringBuilder sbQuery = new StringBuilder();
		
		int nRowsUpdated = 0;
		
		try {
			sbQuery	.append("UPDATE usermaster SET")
					.append("  is_admin_user = ?, ")
					.append("  manage_license = ?, ")
					.append("  view_usage_reports = ?, ")
					.append("  modified_by = ?, ")
					.append("  modified_on = now() ")
					.append("WHERE email_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			
			// tried, to update is_admin_user column to show, if either UseLiceseManagement OR UseUsageMetric is sets to true
			if ( bUseLiceseManagement || bUseUsageMetric ) {
				pstmt.setBoolean(1, true);
			} else {
				pstmt.setBoolean(1, false);
			}
			pstmt.setBoolean(2, bUseLiceseManagement);
			pstmt.setBoolean(3, bUseUsageMetric);
			pstmt.setInt(4, nModifiedUserId);
			pstmt.setString(5, strEmailId);

			nRowsUpdated = pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return nRowsUpdated;
	}
	
	public JSONObject getExtensionDetails( Connection con, String strEmailId, String strStartDate, String strEndDate) throws Exception{
		ResultSet rst = null, rs = null, rs1 = null;
		PreparedStatement pstmt = null, prprstmt = null, prprstmt1 = null;
		JSONObject json = new JSONObject();
		StringBuilder sbQuery = new StringBuilder();
		long lUserId = -1;
		String strLicense = "";
		HashMap<String, Long> hm = null;
		JSONArray jaPricings = new JSONArray();
		JSONObject joPricing = null;
		
		try{
//			sbQuery .append("SELECT user_id FROM usermaster where lower(email_id) = lower(?) LIMIT 1 ");
//			pstmt = con.prepareStatement(sbQuery.toString());
//			pstmt.setString(1, strEmailId);
//			rst = pstmt.executeQuery();
//			if(rst.next()) {
//				lUserId = rst.getLong("user_id");
//			}
			lUserId = getUserId(con, strEmailId);
			sbQuery.setLength(0);
			sbQuery .append("SELECT EXISTS(SELECT 1 FROM userwise_lic_monthwise  WHERE user_id = ? LIMIT 1) as record_exists");
			prprstmt = con.prepareStatement(sbQuery.toString());
			prprstmt.setLong(1, lUserId);
			rs1 = prprstmt.executeQuery();
			if(rs1.next() && !rs1.getBoolean("record_exists")){
				
			}else{
				sbQuery.setLength(0);
				sbQuery .append("SELECT lic_schedule_id, start_date, end_date, sum_desktop_max_measurements, lt_max_run_per_day, lic_type, license_level, lic_category FROM userwise_lic_monthwise where user_id = ? AND lic_category = 'extension' AND ")
						.append("start_date>= '")
						.append(strStartDate)
						.append("'::timestamp  AND end_date<= '")
						.append(strEndDate)
						.append("' ::timestamp ")
						.append("ORDER BY created_on desc LIMIT 1");
				
				prprstmt = con.prepareStatement(sbQuery.toString());
				prprstmt.setLong(1, lUserId);
				rs = prprstmt.executeQuery();
				if(rs.next()){
					json.put("lic_period", rs.getString("lic_type"));
					json.put("lic_type", rs.getString("license_level"));
					json.put("lic_category", rs.getString("lic_category"));
					json.put("lic_schedule_id", rs.getLong("lic_schedule_id"));
					
					Timestamp startdate = rs.getTimestamp("start_date");
					String stdate = startdate.toString();
					stdate = stdate.replace(" ", "T");
					stdate = stdate + "00Z";
					json.put("start_date", stdate);

					Timestamp enddate = rs.getTimestamp("end_date");
					String eddate = enddate.toString();
					eddate = eddate.replace(" ", "T");
					eddate = eddate + "00Z";
					json.put("end_date", eddate);
					
					hm = new HashMap<String, Long>();
					hm.put("sum_max_measurement_per_day", rs.getLong("sum_desktop_max_measurements"));
					hm.put("max_runs", rs.getLong("lt_max_run_per_day"));
					
					sbQuery.setLength(0);
					sbQuery .append("SELECT lic_id, module_name, column_name, feature, l0 as lite, l1 as essentials, l2 as pro, l3 as enterprise FROM appedo_licensing WHERE column_name IS NOT NULL ORDER BY module_name");
					prprstmt1 = con.prepareStatement(sbQuery.toString());
					
					rs1 = prprstmt1.executeQuery();
					
					while(rs1.next()) {
						joPricing = new JSONObject();
						joPricing.put("lic_id", rs1.getLong("lic_id"));
						joPricing.put("module_name",rs1.getString("module_name"));
						joPricing.put("feature",rs1.getString("feature"));
						joPricing.put("lite",rs1.getInt("lite"));
						joPricing.put("essentials",strLicense.equals("level1")?hm.get(rs1.getString("column_name")):rs1.getInt("essentials"));
						joPricing.put("pro", strLicense.equals("level2")?hm.get(rs1.getString("column_name")):rs1.getInt("pro"));
						joPricing.put("enterprise", strLicense.equals("level3")?hm.get(rs1.getString("column_name")):rs1.getInt("enterprise"));
						joPricing.put("is_edit", true);
						jaPricings.add(joPricing);
						
						UtilsFactory.clearCollectionHieracy( joPricing );
					}
					json.put("pricings", jaPricings);
				}
			}
			
		}catch(Exception ex){
			LogManager.errorLog(ex);
			throw ex;
		}
		return json;
	}

	public void updateExtensionDetails(Connection con, JSONObject joExtension, long lUserId) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null;
		ResultSet rs = null;
		StringBuffer sbQuery = new StringBuffer();
		long lsum_max_measurement_per_day = -1, llt_max_run_per_day = -1;
		try{
			
			sbQuery .append("SELECT max_measurement_per_day, lt_max_run_per_day FROM lt_config_parameters lcp ")
					.append("INNER JOIN sum_config_parameters scp on lcp.lt_license = scp.lic_internal_name AND lcp.lt_license = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, joExtension.getString("lic_type"));
			rs = pstmt.executeQuery();
			if(rs.next()){
				lsum_max_measurement_per_day = rs.getLong("max_measurement_per_day");
				llt_max_run_per_day = rs.getLong("lt_max_run_per_day");
			}
			
			sbQuery.setLength(0);
			
			sbQuery .append("UPDATE userwise_lic_monthwise SET ")
					.append("sum_desktop_max_measurements = sum_desktop_max_measurements + ? , ")
					.append("sum_mobile_max_measurements = sum_mobile_max_measurements + ?, ")
					.append("lt_max_run_per_day = lt_max_run_per_day + ?, ")
					.append("reference = ? ")
					.append("WHERE user_id = ? AND start_date = ")
					.append("(SELECT start_date from userwise_lic_monthwise  where lic_schedule_id = ?)");
			
			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.setLong(1, lsum_max_measurement_per_day);
			pstmt1.setLong(2, lsum_max_measurement_per_day);
			pstmt1.setLong(3, llt_max_run_per_day);
			pstmt1.setString(4, joExtension.getString("reference"));
			pstmt1.setLong(5, lUserId);
			pstmt1.setLong(6, joExtension.getLong("lic_schedule_id"));
			
			pstmt1.executeUpdate();
					
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			
		}
	}
	
	public JSONObject getLicesenseDetails(Connection con, String strEmailId) throws Exception{
		ResultSet rst = null, rst1 = null, rs = null, rs1 = null, rst2 = null;
		PreparedStatement pstmt = null, pstmt1 = null, pstmt2 = null, prprstmt = null, prprstmt1 = null;
		JSONObject json = new JSONObject();
		StringBuilder sbQuery = new StringBuilder();
		long lUserId = -1;
		String strLicense = "";
		HashMap<String, Long> hm = null;
		JSONArray jaPricings = null;
		JSONObject joPricing = null;
		
		try{
			sbQuery .append("SELECT user_id, license_level FROM usermaster where lower(email_id) = lower(?) LIMIT 1 ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strEmailId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				lUserId = rst.getLong("user_id");
				strLicense = rst.getString("license_level");
			}
			
			sbQuery.setLength(0);
			sbQuery .append("SELECT EXISTS(SELECT 1 FROM userwise_lic_monthwise  WHERE user_id = ? LIMIT 1) as record_exists");
			prprstmt = con.prepareStatement(sbQuery.toString());
			prprstmt.setLong(1, lUserId);
			rs1 = prprstmt.executeQuery();
			if(rs1.next() && !rs1.getBoolean("record_exists")){
				sbQuery.setLength(0);
				json.put("current_license", "level0");
				json.put("license_history", new JSONArray());
			}else{
				sbQuery.setLength(0);
/*				sbQuery .append("SELECT lic_schedule_id, start_date, end_date, lic_type, license_level, lic_category, reference, ")
						.append("CASE WHEN start_date<=now() AND end_date>=now() THEN true ELSE false END as active_lic, ")
						.append("CASE WHEN start_date<=now() AND end_date<=now() THEN true ELSE false END as is_expired, ")
						.append("created_on, payment_details ->> 'source' as source, payment_details ->> 'paypal_txn_id' as paypal_txn_id ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type='LT' ")
						.append("ORDER BY end_date DESC");*/
				
				sbQuery .append("SELECT lic_schedule_id, start_date, end_date, lic_type, license_level, lic_category, reference, ")
						.append("CASE WHEN start_date<=now() AND end_date>=now() THEN true ELSE false END as active_lic, ")
						.append("CASE WHEN start_date<=now() AND end_date<=now() THEN true ELSE false END as is_expired, ")
						.append("created_on, payment_details ->> 'source' as source, payment_details ->> 'paypal_txn_id' as paypal_txn_id, ")
						.append("sum_max_cities_per_test, dd_max_profilers, sum_desktop_max_measurements, apm_max_agents, apm_max_counters, ")
						.append("lt_max_vusers, lt_max_run_per_day, max_duration, max_load_gen, rum_max_measurement_per_month, ")
						.append("rum_max_test, max_enterprises, ent_max_allowed_users, named_user, report_retention_in_days ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type='LT' ")
						.append("ORDER BY end_date DESC");
				
				pstmt1 = con.prepareStatement(sbQuery.toString());
				pstmt1.setLong(1, lUserId);
				rst1 = pstmt1.executeQuery();
				JSONArray jalicense = new JSONArray();
				JSONObject jolic = null;
				while(rst1.next()){
					jolic = new JSONObject();
					jolic.put("lic_schedule_id", rst1.getLong("lic_schedule_id"));
					
					Timestamp startdate = rst1.getTimestamp("start_date");
					String stdate = startdate.toString();
					stdate = stdate.replace(" ", "T");
					stdate = stdate + "00Z";
					jolic.put("start_date", stdate);

					Timestamp enddate = rst1.getTimestamp("end_date");
					String eddate = enddate.toString();
					eddate = eddate.replace(" ", "T");
					eddate = eddate + "00Z";
					jolic.put("end_date", eddate);
					
					jolic.put("created_on", rst1.getTimestamp("created_on").getTime());
					
					if(rst1.getString("paypal_txn_id")==null) {
						jolic.put("paypal_txn_id","");
					} else {
						jolic.put("paypal_txn_id", rst1.getString("source")+": "+rst1.getString("paypal_txn_id"));
					}
				
					jolic.put("lic_type", rst1.getString("license_level"));
					jolic.put("lic_period", rst1.getString("lic_type"));
					jolic.put("lic_category", rst1.getString("lic_category"));
					jolic.put("reference", rst1.getString("reference"));
					jolic.put("active_lic", rst1.getBoolean("active_lic"));
					jolic.put("is_expired", rst1.getBoolean("is_expired"));
					
					//check the jolic data 
					
					if(jolic.containsKey("lic_category") && jolic.getString("lic_category").equalsIgnoreCase("Top-Up")){
						sbQuery.setLength(0);
						sbQuery .append("SELECT SUM(sum_max_cities_per_test) AS sum_max_cities_per_test, ")
								.append("SUM(lt_max_run_per_day) AS lt_max_run_per_day, ")
								.append("SUM(sum_desktop_max_measurements) AS sum_desktop_max_measurements, ")
								.append("SUM(dd_max_profilers) AS dd_max_profilers, ")
								.append("SUM(apm_max_agents) AS apm_max_agents, ")
								.append("SUM(apm_max_counters) AS apm_max_counters, ")
								.append("SUM(lt_max_vusers) AS lt_max_vusers, ")
								.append("SUM(max_duration) AS max_duration, ")
								.append("SUM(max_load_gen) AS max_load_gen, ")
								.append("SUM(rum_max_measurement_per_month) AS rum_max_measurement_per_month, ")
								.append("SUM(rum_max_test) AS rum_max_test, ")
								.append("SUM(named_user) AS named_user, ")
								.append("SUM(report_retention_in_days) AS report_retention_in_days ")
								
								.append("FROM userwise_lic_monthwise ")
								.append("WHERE start_date<= ?::timestamp AND end_date >= ?::timestamp AND user_id = ? AND module_type='LT'");
						
						PreparedStatement pStatement = con.prepareStatement(sbQuery.toString());
						pStatement.setString(1, jolic.getString("start_date"));
						pStatement.setString(2, jolic.getString("end_date"));
						pStatement.setLong(3, lUserId);
						
						ResultSet resultSet = pStatement.executeQuery();
						if(resultSet.next()){
							hm = new HashMap<String, Long>();
							hm.put("max_location", resultSet.getLong("sum_max_cities_per_test"));
							hm.put("max_profiler_per_user", resultSet.getLong("dd_max_profilers"));
							hm.put("max_measurement_per_day", resultSet.getLong("sum_desktop_max_measurements"));
							hm.put("max_agents", resultSet.getLong("apm_max_agents"));
							hm.put("max_counters_per_agent", resultSet.getLong("apm_max_counters"));
							hm.put("max_vusers", resultSet.getLong("lt_max_vusers"));
							hm.put("max_runs", resultSet.getLong("lt_max_run_per_day"));
							hm.put("max_duration", resultSet.getLong("max_duration"));//
							hm.put("max_load_gen", resultSet.getLong("max_load_gen"));//
							hm.put("rum_max_measurement_per_month", resultSet.getLong("rum_max_measurement_per_month"));//
							hm.put("max_events", resultSet.getLong("rum_max_test"));
							hm.put("named_user", resultSet.getLong("named_user"));//
							hm.put("report_retention_in_days", resultSet.getLong("report_retention_in_days"));//
						}
					}else{
						hm = new HashMap<String, Long>();
						
						hm.put("max_location", rst1.getLong("sum_max_cities_per_test"));
						hm.put("max_profiler_per_user", rst1.getLong("dd_max_profilers"));
						hm.put("max_measurement_per_day", rst1.getLong("sum_desktop_max_measurements"));
						hm.put("max_agents", rst1.getLong("apm_max_agents"));
						hm.put("max_counters_per_agent", rst1.getLong("apm_max_counters"));
						hm.put("max_vusers", rst1.getLong("lt_max_vusers"));
						hm.put("max_runs", rst1.getLong("lt_max_run_per_day"));
						hm.put("max_duration", rst1.getLong("max_duration"));//
						hm.put("max_load_gen", rst1.getLong("max_load_gen"));//
						hm.put("rum_max_measurement_per_month", rst1.getLong("rum_max_measurement_per_month"));//
						hm.put("max_events", rst1.getLong("rum_max_test"));
						hm.put("max_enterprises", rst1.getLong("max_enterprises"));
						hm.put("ent_max_allowed_users", rst1.getLong("ent_max_allowed_users"));
						hm.put("named_user", rst1.getLong("named_user"));//
						hm.put("report_retention_in_days", rst1.getLong("report_retention_in_days"));//
						
						
						
					}
					// for pricings from appedo_licensing
					
					jaPricings = new JSONArray();
					
					//JSONArray jaAppedoPricing = getAppedoPricing(con, (String)jolic.get("lic_period"));
					JSONArray jaAppedoPricing = getAppedoPricingFeature(con);
					for(int i = 0; i<jaAppedoPricing.size(); i++){
						joPricing = jaAppedoPricing.getJSONObject(i);
						if(joPricing.containsKey("lic_id")) {
							joPricing.put("value", hm.get(joPricing.getString("column_name")));
						}
						jaPricings.add(joPricing);
					}
					jolic.put("pricings", jaPricings);
					jalicense.add(jolic);
					jolic = null;
					jaPricings = null;
				}
				json.put("license_history", jalicense);
			}
			
		}catch(Exception ex){
			LogManager.errorLog(ex);
			throw ex;
		}
		return json;
	}

	public JSONObject getMonthwiseLicesenseDetails(Connection con, JSONObject joLicense) throws Exception{
		JSONObject json = new JSONObject();
		StringBuilder sbQuery = new StringBuilder();
		PreparedStatement pstmt = null, pstmt1 = null, pstmt2 = null;
		ResultSet rs = null, rs1 = null, rs2 = null;;
		long lUserId = -1;
		String strLicense = "";
		HashMap<String, Long> hm = null;
		JSONArray jaPricings = new JSONArray();
		JSONObject joPricing = null;
		
		try{
			
			sbQuery .append("SELECT user_id FROM usermaster where lower(email_id) = lower(?) LIMIT 1 ");
			pstmt2 = con.prepareStatement(sbQuery.toString());
			pstmt2.setString(1, joLicense.getString("email_id"));
			rs2 = pstmt2.executeQuery();
			if(rs2.next()) {
				lUserId = rs2.getLong("user_id");
			}
			
			sbQuery.setLength(0);
			sbQuery .append("select * from userwise_lic_monthwise where lic_schedule_id = ")
					.append(joLicense.getLong("lic_schedule_id"));
//					.append(" AND start_date>= '")
//					.append(joLicense.getString("lic_start_date"))
//					.append("'::timestamp  AND end_date<= '")
//					.append(joLicense.getString("lic_end_date"))
//					.append("' ::timestamp LIMIT 1");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			if(rs.next()){
				json.put("lic_period", rs.getString("lic_type"));
				strLicense = rs.getString("license_level");
				json.put("lic_type", strLicense);
				hm = new HashMap<String, Long>();
				hm.put("max_location", rs.getLong("sum_max_cities_per_test"));
				hm.put("max_profiler_per_user", rs.getLong("dd_max_profilers"));
				hm.put("sum_max_measurement_per_day", rs.getLong("sum_desktop_max_measurements"));
				hm.put("max_agents", rs.getLong("apm_max_agents"));
				hm.put("max_counters_per_agent", rs.getLong("apm_max_counters"));
				hm.put("max_vusers", rs.getLong("lt_max_vusers"));
				hm.put("max_runs", rs.getLong("lt_max_run_per_day"));
				hm.put("max_duration", rs.getLong("max_duration"));//
				hm.put("max_load_gen", rs.getLong("max_load_gen"));//
				hm.put("rum_max_measurement_per_day", rs.getLong("rum_max_measurement_per_day"));//
				hm.put("max_events", rs.getLong("rum_max_test"));
				hm.put("named_user", rs.getLong("named_user"));//
				hm.put("report_retention_in_days", rs.getLong("report_retention_in_days"));//
			}
			
			sbQuery.setLength(0);
			sbQuery .append("SELECT lic_id, module_name, column_name, feature, l0 as lite, l1 as essentials, l2 as pro, l3 as enterprise FROM appedo_licensing WHERE column_name IS NOT NULL ORDER BY module_name");
			pstmt1 = con.prepareStatement(sbQuery.toString());
			
			rs1 = pstmt1.executeQuery();
			
			while(rs1.next()) {
				joPricing = new JSONObject();
				joPricing.put("lic_id", rs1.getLong("lic_id"));
				joPricing.put("module_name",rs1.getString("module_name"));
				joPricing.put("feature",rs1.getString("feature"));
				joPricing.put("lite",rs1.getInt("lite"));
				joPricing.put("essentials",strLicense.equals("level1")?hm.get(rs1.getString("column_name")):rs1.getInt("essentials"));
				joPricing.put("pro", strLicense.equals("level2")?hm.get(rs1.getString("column_name")):rs1.getInt("pro"));
				joPricing.put("enterprise", strLicense.equals("level3")?hm.get(rs1.getString("column_name")):rs1.getInt("enterprise"));
				joPricing.put("is_edit", true);
				jaPricings.add(joPricing);
				
				UtilsFactory.clearCollectionHieracy( joPricing );
			}
			json.put("pricings", jaPricings);
		
		}catch(Exception ex){
			LogManager.errorLog(ex);
			throw ex;
		}
		return json;
	}
	/**
	 * gets users has either license can manage or view usage reports is enabled
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUsersAdminPrivilege(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaUsersAdminPrivilege = null;
		JSONObject joUserAdminPrivilege = null;
		
		try {
			jaUsersAdminPrivilege = new JSONArray();
			
			
			sbQuery	.append("SELECT user_id, email_id, company_name, manage_license, view_usage_reports ")
					.append("FROM usermaster ")
					.append("WHERE manage_license = true OR view_usage_reports = true ")
					.append("ORDER BY email_id ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joUserAdminPrivilege = new JSONObject();
				joUserAdminPrivilege.put("emailId", rst.getString("email_id"));
				joUserAdminPrivilege.put("companyName", rst.getString("company_name"));
				joUserAdminPrivilege.put("canManageLicense", rst.getBoolean("manage_license"));
				joUserAdminPrivilege.put("canViewUsageReports", rst.getBoolean("view_usage_reports"));
				
				jaUsersAdminPrivilege.add(joUserAdminPrivilege);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;


			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaUsersAdminPrivilege;
	}
	
	/**
	 * gets users whose license is expired
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLicenseExpiredUsers(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaLicenseExpiredUsers = null;
		JSONObject joLicenseExpiredUser = null;
		
		try {
			jaLicenseExpiredUsers = new JSONArray();
			
			// TODO: Ask if module_type group is necessary
			
			sbQuery	.append("SELECT um.email_id, um.first_name||' '||um.last_name AS name, um.company_name, um.mobile_no, MAX(end_date) AS expire_on ")
					.append("FROM userwise_lic_monthwise  ulm ")
					.append("INNER JOIN usermaster um ON um.user_id = ulm.user_id ")
					.append("GROUP BY um.email_id, name, um.company_name, um.mobile_no ")
					.append("HAVING MAX(end_date) <= now() ")
					.append("ORDER BY expire_on DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joLicenseExpiredUser = new JSONObject();
				joLicenseExpiredUser.put("emailId", rst.getString("email_id"));
				joLicenseExpiredUser.put("name", rst.getString("name"));
				joLicenseExpiredUser.put("companyName", rst.getString("company_name"));
				joLicenseExpiredUser.put("mobileNo", rst.getString("mobile_no"));
				joLicenseExpiredUser.put("expireOn", rst.getTimestamp("expire_on").getTime());
				
				jaLicenseExpiredUsers.add(joLicenseExpiredUser);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaLicenseExpiredUsers;
	}
	
	/**
	 * gets users whose license will expire in next given days
	 * 
	 * @param con
	 * @param nExpireInNextDays
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLicenseWillExipreUsers(Connection con, int nExpireInNextDays) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaLicenseWillExipreUsers = null;
		JSONObject joLicenseWillExipreUser = null;
		
		try {
			jaLicenseWillExipreUsers = new JSONArray();

			// TODO: Ask if module_type group is necessary
			
			sbQuery	.append("SELECT um.email_id, um.first_name||' '||um.last_name AS name, um.company_name, um.mobile_no, MAX(end_date) AS expire_on ")
					.append("FROM userwise_lic_monthwise  ulm ")
					.append("INNER JOIN usermaster um ON um.user_id = ulm.user_id ")
					.append("GROUP BY um.email_id, name, um.company_name, um.mobile_no ")
					.append("HAVING MAX(end_date) BETWEEN NOW() AND now() + interval '").append(nExpireInNextDays).append(" day' ")
					.append("ORDER BY expire_on ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joLicenseWillExipreUser = new JSONObject();
				joLicenseWillExipreUser.put("emailId", rst.getString("email_id"));
				joLicenseWillExipreUser.put("name", rst.getString("name"));
				joLicenseWillExipreUser.put("companyName", rst.getString("company_name"));
				joLicenseWillExipreUser.put("mobileNo", rst.getString("mobile_no"));
				joLicenseWillExipreUser.put("expireOn", rst.getTimestamp("expire_on").getTime());
				
				jaLicenseWillExipreUsers.add(joLicenseWillExipreUser);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaLicenseWillExipreUsers;
	}
	
	public long getUserId(Connection con, String strEmailId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuffer sbQuery = new StringBuffer();
		long lUserId = -1;
		try{
			sbQuery .append("SELECT user_id FROM usermaster where email_id=?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strEmailId);
			rs = pstmt.executeQuery();
			if(rs.next()){
				lUserId = rs.getLong("user_id");
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return lUserId;
	}
	
	public String returnExistingLic(Connection con, JSONObject joLicense, boolean isLicScheduleId) throws Exception {
//		String strRtn = "License already available for these periods:<br/>";
		String strRtn = "";
		StringBuffer sbQuery = new StringBuffer();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		try{
			if(isLicScheduleId){
				long lScheduleId = joLicense.getLong("lic_schedule_id");
				sbQuery .append("SELECT to_char(start_date, 'dd-MON-yyyy') AS start_date, to_char(end_date, 'dd-MON-yyyy') AS end_date FROM userwise_lic_monthwise  ")
						.append("WHERE ('")
						.append(joLicense.getString("lic_start_date"))
						.append("'::timestamp BETWEEN start_date AND end_date OR '")
						.append(joLicense.getString("lic_end_date"))
						.append("'::timestamp BETWEEN start_date AND end_date) ")
						.append("AND user_id = ? AND lic_category = 'Renewal' AND lic_schedule_id NOT IN (")
						.append(lScheduleId-2).append(", ")
						.append(lScheduleId-1).append(", ")
						.append(lScheduleId).append(", ")
						.append(lScheduleId+1).append(", ")
						.append(lScheduleId+2).append(", ")
						.append(lScheduleId+3).append(", ")
						.append(lScheduleId+4).append(") ")
						.append("GROUP BY start_date, end_date");
			}else{
				sbQuery .append("SELECT to_char(start_date, 'dd-MON-yyyy') AS start_date, to_char(end_date, 'dd-MON-yyyy') AS end_date FROM userwise_lic_monthwise  ")
						.append("WHERE ('")
						.append(joLicense.getString("lic_start_date"))
						.append("'::timestamp BETWEEN start_date AND end_date OR '")
						.append(joLicense.getString("lic_end_date"))
						.append("'::timestamp BETWEEN start_date AND end_date) ")
						.append("AND user_id = ? AND lic_category = 'Renewal' GROUP BY start_date, end_date");
			}
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, joLicense.getLong("lUserId"));
			
			rst = pstmt.executeQuery();
			while(rst.next()){
				strRtn = strRtn + rst.getString("start_date");
				strRtn = strRtn + " to "+ rst.getString("end_date") +"<br/> ";
			}
//			strRtn = strRtn + "So please do <b>Daily Renewal</b> for the required days.";
			sbQuery.setLength(0);
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			
		}
		
		return strRtn;
	} 
	
	public JSONObject getUserDetails(Connection con, long userId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joUserDetails = new JSONObject();
		try {
			sbQuery.append("select * from usermaster where user_id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, userId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				joUserDetails.put("user_id", rst.getInt("user_id"));
				joUserDetails.put("email_id", rst.getString("email_id"));
				joUserDetails.put("password", rst.getString("password"));
				joUserDetails.put("first_name", rst.getString("first_name"));
				joUserDetails.put("last_name", rst.getString("last_name")!=null?rst.getString("last_name"):"");
				joUserDetails.put("mobile_no", rst.getString("mobile_no"));
				joUserDetails.put("telephone_code", UtilsFactory.replaceNull( rst.getString("telephone_code"), ""));
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
//			rst = null;
			DataBaseManager.close(pstmt);
//			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return joUserDetails;
	}

}
