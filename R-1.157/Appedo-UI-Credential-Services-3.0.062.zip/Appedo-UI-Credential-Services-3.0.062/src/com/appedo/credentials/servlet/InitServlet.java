package com.appedo.credentials.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appedo.commons.manager.AppedoMailer;
import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.util.AppedoMobileManager;
import com.appedo.credentials.util.Constants;
import com.appedo.manager.LogManager;

/**
 * This class does the initialization operation for this application
 * 
 * @author Ramkumar R
 *
 */
public class InitServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public static String version = null;
	public static String realPath = null;
	
	public static TimerTask ttBackup = null;
	public static Timer timerBackup = null;
	
	/**
	 * Do the initialization operation of this application like:
	 * - Get the configuration data from configuration files.
	 * - Schedule & Start all the counter class timers.
	 * 
	 */
	public void init() {
		//super();
		// declare servlet context
		ServletContext context = getServletContext();
		
		realPath = context.getRealPath("//");
		version = (String) context.getInitParameter("version");
		Connection con = null;
		try{
			String strConfigFilePath = context.getInitParameter("CONFIG_PROPERTIES_FILE_PATH");
			String strLog4jFilePath = context.getInitParameter("LOG4J_PROPERTIES_FILE_PATH");
			
			// Loads log4j configuration properties
			Constants.LOG4J_PROPERTIES_FILE = InitServlet.realPath+strLog4jFilePath;
			LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
			
			// Load config.properties
			Constants.CONFIG_FILE_PATH = InitServlet.realPath+strConfigFilePath;
			
			// Loads Constants properties 
			Constants.loadConstantsProperties(Constants.CONFIG_FILE_PATH);
			
			// Loads Appedo config properties from the system path
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Initiate the DB Pool
			DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
			
			AppedoMailer.loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
			
			// load mobile properties from file
			AppedoMobileManager.loadPropertyFileConstants(Constants.MOBILE_CONFIG_FILE_PATH);
			
			// DataBase connection
			con = DataBaseManager.giveConnection();
			
			AppedoMobileManager.populateCountryISDCodes(con);
			
			// load appedo constants; say loads appedoWhiteLabels, 
			Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
			
		} catch(Throwable e) {
        	System.out.println("Exception in InitServlet.init: "+e.getMessage());
        	e.printStackTrace();
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(con);
			con = null;
		}
		
		// TODO initialing process
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
}
