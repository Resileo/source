package com.appedo.credentials.controller;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.Router;

import com.appedo.credentials.resource.CheckingIsExistedUser;
import com.appedo.credentials.resource.CredentialEmails;
import com.appedo.credentials.resource.CredentialResendVerificationEmail;
import com.appedo.credentials.resource.CredentialsAppedoPricing;
import com.appedo.credentials.resource.CredentialsChangePassword;
import com.appedo.credentials.resource.CredentialsLoginResource;
import com.appedo.credentials.resource.CredentialsLogoutResource;
import com.appedo.credentials.resource.CredentialsNewPassword;
import com.appedo.credentials.resource.CredentialsPaymentGateway;
import com.appedo.credentials.resource.CredentialsRequestResetPassword;
import com.appedo.credentials.resource.CredentialsSignUpResource;
import com.appedo.credentials.resource.CredentialsTimeOutResource;
import com.appedo.credentials.resource.CredentialsUpdateAccessRights;
import com.appedo.credentials.resource.CredentialsUpdateLoginHistoryResource;
import com.appedo.credentials.resource.CredentialsUpdateLogoutHistoryResource;
import com.appedo.credentials.resource.CredentialsUpdateProfile;
import com.appedo.credentials.resource.CredentialsUsageMetrics;
import com.appedo.credentials.resource.CredentialsUserDetails;
import com.appedo.credentials.resource.CredentialsUsersAdminPrivilege;
import com.appedo.credentials.resource.CredentialsVerifyEmail;
import com.appedo.credentials.resource.GetLicesense;
import com.appedo.credentials.resource.GetMonthWiseLicense;
import com.appedo.credentials.resource.GetTopUpDetails;
import com.appedo.credentials.resource.LicenseExpiredUsers;
import com.appedo.credentials.resource.LicenseWillExipreUsers;
import com.appedo.credentials.resource.LoadConfigAndMailProperties;
import com.appedo.credentials.resource.UpdateLicense;
import com.appedo.manager.LogManager;

/**
 * Class which receives the HTTP request and routes the said resource class.
 * 
 * @author Ramkumar R
 *
 */
public class AppedoCredentials_WebApplication extends Application {

	// set log access
	//private static final Category log = Category.getInstance(SPCG_WebApplication.class.getName());
	
	/**
	 * Creates a root Restlet that will receive all incoming calls.
	 */
	@Override
	public synchronized Restlet createRoot() {
		// Create a router Restlet that routes each call to a
		// specific resources based on a given URI pattern.
		Router router = new Router(getContext());
		
		LogManager.infoLog("Appedo-Credentials-UI-Services webservice");
		
		// Attach default route
		//router.attachDefault(HelloResource.class);
		
		// URI pattern: (POST) This service will receive and process the login validation and session initialization
		router.attach("/credentials/loginSession", CredentialsLoginResource.class);
		
		router.attach("/credentials/requestResetPassword", CredentialsRequestResetPassword.class);
		
		router.attach("/credentials/userSignup", CredentialsSignUpResource.class);
		
		router.attach("/credentials/paymentGatewayResult", CredentialsPaymentGateway.class);
		
		router.attach("/credentials/verifyEmailAddress", CredentialsVerifyEmail.class);
		
		//router.attach("/credentials/resetPassword", CredentialsResetPassword.class);
		
		router.attach("/credentials/newPassword", CredentialsNewPassword.class);
		
		router.attach("/credentials/logoutSession", CredentialsLogoutResource.class);
		
		router.attach("/credentials/changePassword", CredentialsChangePassword.class);

		router.attach("/credentials/updateProfile", CredentialsUpdateProfile.class);
		
		router.attach("/credentials/getUserDetails", CredentialsUserDetails.class);
		
		router.attach("/credentials/getAppedoPricing", CredentialsAppedoPricing.class);

		router.attach("/credentials/timeOutSession", CredentialsTimeOutResource.class);

		
		// license
		router.attach("/credentials/getLicesingEmails", CredentialEmails.class);
		
		router.attach("/credentials/getUsageMetrics", CredentialsUsageMetrics.class);
		
		router.attach("/credentials/updateLicesense", UpdateLicense.class);

		router.attach("/credentials/updateUserAccessRights", CredentialsUpdateAccessRights.class);
		
		router.attach("/credentials/getUsersAdminPrivilege", CredentialsUsersAdminPrivilege.class);
		
		router.attach("/credentials/getLicesenseDetails", GetLicesense.class);
		
		router.attach("/credentials/getLicenseExpiredUsers", LicenseExpiredUsers.class);
		
		router.attach("/credentials/getLicenseWillExipreUsers", LicenseWillExipreUsers.class);
		
		//
		router.attach("/credentials/reloadConfigAndMailProperties", LoadConfigAndMailProperties.class);
		
		router.attach("/credentials/getLicesenseMonthWiseDetails", GetMonthWiseLicense.class);
		
		router.attach("/credentials/getTopUpDetails", GetTopUpDetails.class);
		
		router.attach("/credentials/isExistedUser", CheckingIsExistedUser.class);

		router.attach("/credentials/updateLogoutHistoryComment", CredentialsUpdateLogoutHistoryResource.class);
		
		router.attach("/credentials/updateLoginHistoryComment", CredentialsUpdateLoginHistoryResource.class);
		
		router.attach("/credentials/resendEmailVerfication", CredentialResendVerificationEmail.class);
		
		return router;
	}
}
