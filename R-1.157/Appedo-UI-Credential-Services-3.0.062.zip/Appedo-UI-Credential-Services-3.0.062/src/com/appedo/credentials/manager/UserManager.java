package com.appedo.credentials.manager;

import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.commons.manager.AppedoMailer;
import com.appedo.commons.manager.AppedoMailer.MODULE_ID;
import com.appedo.credentials.DBI.AdminDBI;
import com.appedo.credentials.DBI.UserDBI;
import com.appedo.credentials.bean.PaymentBean;
import com.appedo.credentials.bean.UserBean;
import com.appedo.credentials.util.AppedoMobileManager;
import com.appedo.credentials.util.Constants;
import com.appedo.credentials.util.UtilsFactory;
import com.appedo.credentials.util.WebServiceManager;
import com.appedo.manager.AppedoConstants;
import com.appedo.manager.LogManager;

/**
 * Manager handles the business logic for user signin operation
 * @author navin
 *
 */
public class UserManager {
	
	/**
	 * Send a mail to user with a link to reset their password
	 * 
	 * @param con
	 * @param strAppedourl
	 * @param strEmailId
	 * @throws Exception
	 */
	public void requestForPasswordReset(Connection con, String strEmailId) throws Exception {
		String strSubject = "";
		
		HashMap<String, Object> hmMailDetails = null;
		
		long lVerificationHistoryId = -1L;
		boolean bUserExists;

		AppedoMailer appedoMailer = null;
		
		UserDBI userDBI = null;
		UserBean userBean = null;
		
		try {
			userDBI = new UserDBI();
			userBean = new UserBean();
			appedoMailer = new AppedoMailer( Constants.EMAIL_TEMPLATES_PATH );
			
			// check user exists
			bUserExists = userDBI.isUserExists(con, strEmailId);
			if( ! bUserExists ) {
				// to throw Exception for forgot password email doesn't exists
				throw new Exception("4");
			} else {
				// gets user details
				userBean = userDBI.getUserDetails(con, strEmailId);
				
				// forgot password history
				lVerificationHistoryId = userDBI.insertForgotPasswordHistory(con, userBean.getUserId());
				
				hmMailDetails = new HashMap<String, Object>();
				hmMailDetails.put("USERNAME", userBean.getFirstName());
				hmMailDetails.put("EMAIL", strEmailId);
				hmMailDetails.put("LINK", Constants.APPEDO_URL+"resetPassword?uid="+CryptManager.encryptEncodeURL(userBean.getUserId()+"")+"&vh_id="+CryptManager.encryptEncodeURL(lVerificationHistoryId+"")+"&email="+strEmailId);
				strSubject = "Password recovery";
				appedoMailer.sendMail(MODULE_ID.PASSWORD_RESET, hmMailDetails, strEmailId.split(","), strSubject);
			}
		} catch(Exception e) {
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( hmMailDetails );
			hmMailDetails = null;
			
			strSubject = null;
			appedoMailer = null;
			userDBI = null;
		}
	}
	
	/**
	 * Addes new user
	 * 
	 * @param con
	 * @param strAppedourl
	 * @param userBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public JSONObject addUser(Connection con, UserBean userBean) throws Exception {
		JSONObject joObject = null;
		long lUserId, lVerificationHistoryId = -1L;
		
		boolean bUserExists = false; 
		
		UserDBI userDBI = null;
		
		try {
			userDBI = new UserDBI();
			
			bUserExists = userDBI.isUserExists(con, userBean.getEmailId());
			
			if( bUserExists == true ) {
				// if the call is for Quick-SUM Add then UserID is required
				if( userBean.getSumUrl() != null ){
					lUserId = new AdminDBI().getUserId(con, userBean.getEmailId());
				} else {
					// To throw the user defined exception foe Email Id already exists
					throw new Exception("1");
				}
			} else {
				// Add's user
				lUserId = userDBI.insertUser(con, userBean);
				
				userBean.setUserId(lUserId);
				
				// setup ASD, for the user 
				setupASDForUser(lUserId);
				
				// setup SLA, for the user 
				setupSLAForUser(lUserId, userBean.getEmailId());
				
				// setup SUM, for the user
				userDBI.setupSUMHeartBeat(con, lUserId);

				// To insert Default page setting page details
				//userDBI.addDefaultPageSettingDetails(con, lUserId);
				
				// create Chart Visual table
				userDBI.createChartVisualTable(con, lUserId);
				
				// to send mail when captcha validation is enabled
				if( Constants.IS_CAPTCHA_VALIDATION_ENABLE && userBean.getAddedVia() == null ) {
					// adds verification history 
					lVerificationHistoryId = userDBI.insertEmailVerificationHistory(con, lUserId);
					
					// send verification mail for the user
					sendVerificationMail(lVerificationHistoryId, userBean);
				}
			}
			
			joObject = new AdminDBI().getUserDetails(con, lUserId);
			joObject.put("password", userBean.getPassword());
			userDBI = null;
		} catch(Exception e) {
			throw e;
		}
		
		return joObject;
	}
	
	public long addPaymentResult(Connection con, PaymentBean paymentBean) throws Exception
	{
		UserDBI userDBI = null;
		long lAppedoPaypalPaypentId = 0;
		
		try
		{
			userDBI = new UserDBI();
			lAppedoPaypalPaypentId = userDBI.insertPaymentResult(con, paymentBean);
			
		}catch(Exception e){
			LogManager.errorLog(e);

			e.printStackTrace();
			throw e;
		}
		
		return lAppedoPaypalPaypentId;
	}
	public JSONObject isExistedUser(Connection con, String strEamild) throws Exception {
		UserDBI userDBI = null;
		JSONObject joObject = null;
		String strRtn = "";
		
		try {
			userDBI = new UserDBI();
			strRtn = userDBI.isUserExist(con, strEamild);
			joObject = new JSONObject();
			joObject.put("success", true);
			joObject.put("failure", false);
			joObject.put("isUserExist", strRtn);
			
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return joObject;
	}
	
	public void verifyEmailAddress(Connection con, long lUserId, long lVerificationHistoryId) throws Exception {
		UserDBI userDBI = null;
		
		boolean bVerificationLinkExpired = false;
		
		try {
			userDBI = new UserDBI();
			
			// 
			bVerificationLinkExpired = userDBI.isVerificationLinkExpired(con, lUserId, lVerificationHistoryId);
			
			if ( bVerificationLinkExpired ) {	// verification link is expired
				userDBI.updateVerificationHistoryComment(con, lUserId, lVerificationHistoryId, "Link expired.");
				
				throw new Exception("1");
			} else {
				// Update the log table
				userDBI.updateVerificationHistoryComment(con, lUserId, lVerificationHistoryId, "Email verified with valid link.");
				
				// DO verification process
				userDBI.verifyEmailAddress(con, lUserId);
				
				// TODO Need Confirmation for updating userid in enterprise mapping table.
				userDBI.checkInviteUsers(con, lUserId);
			}
			
			userDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	/*
	public void setPassword(Connection con, String strUserId, String strPassword) throws Exception {
		UserDBI userDBI = null;
		
		try {
			userDBI = new UserDBI();
			userDBI.setPassword(con, strUserId, strPassword);
			userDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	*/
	
	/**
	 * Validates the resetPassword link to be used with in 24 hrs
	 * 
	 * @param con
	 * @param strUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isPasswordResetRequestExpired(Connection con, String strUserId ) throws Exception {
		UserDBI userDBI = null;
		boolean bStatus = false;
		
		try {
			userDBI = new UserDBI();
			bStatus = userDBI.isPasswordResetRequestExpired(con, strUserId);
			userDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bStatus;
	}
	
	public UserBean getUserDetails(Connection con, long lUserId) throws Exception {
		UserBean userBean = null;

		UserDBI userDBI = null;
		
		try {
			userDBI = new UserDBI();
			
			userBean = userDBI.getUserDetails(con, lUserId);

			userDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return userBean;
	}

	public void changePassword(Connection con, long lUserId, String strOldPassword, String strNewPassword, String strReTypePassword) throws Exception {
		UserDBI userDBI = null;
		
		String strPassword = "";
		
		try{
			userDBI = new UserDBI();
			
			strPassword = userDBI.getUserPassword(con, lUserId);
			
			if( ! strPassword.equals(strOldPassword) ) {
				// old password -doesn't match
				throw new Exception("1");
			} else if ( ! strNewPassword.equals(strReTypePassword) ) {
				// new & retype password doesn't match
				throw new Exception("2");
			}
			
			// update new password
			userDBI.changePassword(con, lUserId, strNewPassword);
			
			userDBI = null;
		}catch(Exception e){
			throw e;
		}
	}
	
	public void updateProfile(Connection con, UserBean userBean) throws Exception {
		UserDBI userDBI = null;
		
		try {
			userDBI = new UserDBI();
			
			userDBI.updateProfile(con, userBean);
			
			userDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * Initialize or Setup ASD for the new user.
	 * This will call UI-Module-Service's api "/apm/setupASD"
	 * 
	 * @param lUserId
	 * @throws Exception
	 */
	public void setupASDForUser(long lUserId) throws Exception {
		WebServiceManager wsm = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("user_id", lUserId+"");
			
			wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES+"/apm/setupASD");
			if ( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				LogManager.infoLog("Success of user /apm/setupASD, userId: "+lUserId);
			} else {
				// err
				LogManager.infoLog("Error of user /apm/setupASD, userId: "+lUserId);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	/**
	 * Initialize or Setup SLA for the new user.
	 * This will call UI-SLA-Service's api "/apm/setupASD"
	 * 
	 * @param lUserId
	 * @throws Exception
	 */
	public void setupSLAForUser(long lUserId, String strEmailId) throws Exception {
		WebServiceManager wsm = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("user_id", lUserId+"");
			wsm.addParameter("emailId", strEmailId);
			
			wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES+"/sla/setupSLA");
			if ( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				LogManager.infoLog("Success of user /sla/setupSLA, userId: "+lUserId);
			} else {
				// err
				LogManager.infoLog("Error of user /sla/setupSLA, userId: "+lUserId);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	/**
	 * send verification mail for the user
	 * 
	 * @param strAppedourl
	 * @param userBean
	 * @throws Exception
	 */
	public void sendVerificationMail(long lVerificationHistoryId, UserBean userBean) throws Exception {
		AppedoMailer appedoMailer = null;
		AppedoMobileManager appedoMobileMan = null;
		
		HashMap<String, Object> hmMailDetails = null;
		
		String strSubject = "";
		
		try {
			appedoMailer = new AppedoMailer( Constants.EMAIL_TEMPLATES_PATH );
			
			if( userBean.getSumUrl()!= null ){
				//calling sendmail method(module)
				hmMailDetails = new HashMap<String, Object>();
				hmMailDetails.put("USERNAME", userBean.getFirstName());
				hmMailDetails.put("PASSWORD", userBean.getPassword());
				hmMailDetails.put("LINK", Constants.APPEDO_URL+"verifyEmailAddress?uid="+CryptManager.encryptEncodeURL(userBean.getUserId()+"")+"&vh_id="+CryptManager.encryptEncodeURL(lVerificationHistoryId+"")+"&email="+userBean.getEmailId());
				strSubject = "{{ appln_heading }}: Email-Id Verification";
				appedoMailer.sendMail(MODULE_ID.SIGNUP_QUICKSUM_VERIFICATION, hmMailDetails, userBean.getEmailId().split(","), strSubject);
			} else {
				//calling sendmail method(module)
				hmMailDetails = new HashMap<String, Object>();
				hmMailDetails.put("USERNAME", userBean.getFirstName());
				// vh_id means verification_history_id from `login_verification_history`
				hmMailDetails.put("LINK", Constants.APPEDO_URL+"verifyEmailAddress?uid="+CryptManager.encryptEncodeURL(userBean.getUserId()+"")+"&vh_id="+CryptManager.encryptEncodeURL(lVerificationHistoryId+"")+"&email="+userBean.getEmailId());
				strSubject = "{{ appln_heading }}: Email-Id Verification";
				appedoMailer.sendMail(MODULE_ID.VERIFY_USER_EMAIL, hmMailDetails, userBean.getEmailId().split(","), strSubject);
			}
			
			if((userBean.getMobileNo()!=null)&&(userBean.getMobileNo().length()>0)){
				// Send Welcome SMS
				appedoMobileMan = new AppedoMobileManager();
				appedoMobileMan.sendSMS(userBean.getTelephoneCode(),userBean.getTelephoneCode()+userBean.getMobileNo(), "Dear "+userBean.getFirstName()+" "+userBean.getLastName()+", Thanks for registering with "+AppedoConstants.getAppedoWhiteLabel("download_appln_name_camelcase")+". Check your inbox for more details.");
			}
			UtilsFactory.clearCollectionHieracy(hmMailDetails);
		} catch (Exception e) {
			throw e;
		} finally {
			appedoMailer = null;
			appedoMobileMan = null;
			strSubject = null;
		}
	}
	
	/**
	 * resend verification for the user's given email_id
	 * 
	 * @param con
	 * @param strAppedourl
	 * @param strEmailId
	 * @throws Exception
	 */
	public void resendVerificationMail(Connection con, String strEmailId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		UserDBI userDBI = null;
		
		UserBean userBean = null;
		
		long lVerificationHistoryId = -1L;
		
		try {
			userDBI = new UserDBI();
			
			// gets user details 
			userBean = userDBI.getUserDetails(con, strEmailId);
			
			// add email verification into log table
			lVerificationHistoryId = userDBI.insertEmailVerificationHistory(con, userBean.getUserId());
			
			// send mail
			sendVerificationMail(lVerificationHistoryId, userBean);
		} catch (Exception e) {
			throw e;
		} finally {
			userDBI = null;
			userBean = null;

			LogManager.logMethodEnd(dateLog);
		}
	}
	
	/**
	 * reset the new password, if the link has not expired 
	 * 
	 * @param con
	 * @param strPassword
	 * @param lUserId
	 * @param lVerificationHistoryId
	 * @throws Exception
	 */
	public void resetNewPassword(Connection con, String strPassword, long lUserId, long lVerificationHistoryId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		boolean bVerificationLinkExpired = false;
		
		UserDBI userDBI = null;
		
		try {
			userDBI = new UserDBI();
			
			bVerificationLinkExpired = userDBI.isVerificationLinkExpired(con, lUserId, lVerificationHistoryId);
			
			if( bVerificationLinkExpired ) {	// verification link is expired
				userDBI.updateVerificationHistoryComment(con, lUserId, lVerificationHistoryId, "Link expired.");
				
				throw new Exception("1");
			} else {
				// Update the log table
				userDBI.updateVerificationHistoryComment(con, lUserId, lVerificationHistoryId, "Password reset with valid link.");
				
				// change new password
				userDBI.changePassword(con, lUserId, strPassword);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			userDBI = null;
			
			LogManager.logMethodEnd(dateLog);
		}
	}
}
