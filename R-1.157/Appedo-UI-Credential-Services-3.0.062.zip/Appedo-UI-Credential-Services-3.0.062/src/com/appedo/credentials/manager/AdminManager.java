package com.appedo.credentials.manager;

import java.sql.Connection;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.credentials.DBI.AdminDBI;
import com.appedo.manager.LogManager;

public class AdminManager {
	
	public JSONArray getAppedoPricing(Connection con) {
    	JSONArray jaAPMModule = null;
		AdminDBI apmDBI = null;
		try {
			apmDBI = new AdminDBI();
			jaAPMModule = apmDBI.getAppedoPricing(con);
			apmDBI = null;
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return jaAPMModule;
		
	}
	
	public JSONArray getLicesingEmails(Connection con, String strEmailId) {
    	JSONArray jaEmails = null;
		AdminDBI apmDBI = null;
		try {
			apmDBI = new AdminDBI();
			jaEmails = apmDBI.getLicesingEmails(con, strEmailId);
			apmDBI = null;
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return jaEmails;
		
	}
	
	public JSONObject getUsageDetails(Connection con, String code) throws Exception {
    	JSONObject json = null;
		AdminDBI apmDBI = null;
		try {
			apmDBI = new AdminDBI();
			json = apmDBI.getUsageDetails(con,code);
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return json;
		
	}
	
	public String updateLicesense(Connection con, JSONObject joLicense) throws Exception {
		AdminDBI apmDBI = null;
		String strRtn;
		try {
			apmDBI = new AdminDBI();
			strRtn = apmDBI.updateLicesense(con, joLicense);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			apmDBI = null;
		}
		return strRtn;
	}
	
	public JSONObject getLicesenseDetails(Connection con, String strEmail) throws Exception {
    	JSONObject joLicense = null;
		AdminDBI apmDBI = null;
		try {
			apmDBI = new AdminDBI();
			joLicense = apmDBI.getLicesenseDetails(con, strEmail);
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return joLicense;
	}
	
	public JSONObject getExtensionDetails(Connection con, String strEmaildId, String strStartDate, String strEndDate) throws Exception {
    	JSONObject joLicense = null;
		AdminDBI apmDBI = null;
		try {
			apmDBI = new AdminDBI();
			joLicense = apmDBI.getExtensionDetails(con, strEmaildId, strStartDate, strEndDate);
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return joLicense;
	}
	
	public JSONObject getMonthwiseLicesenseDetails(Connection con, JSONObject joLic) throws Exception {
    	JSONObject joLicense = null;
		AdminDBI apmDBI = null;
		try {
			apmDBI = new AdminDBI();
			joLicense = apmDBI.getMonthwiseLicesenseDetails(con, joLic);
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return joLicense;
	}
	
	/**
	 * update access rights for a user,
	 * (ie.. user has privilege to access License management/Usage metrics)
	 * 
	 * @param con
	 * @param strEmailId
	 * @param bUseLiceseManagement
	 * @param bUseUsageMetric
	 * @param nModifiedUserId
	 * @return
	 * @throws Exception
	 */
	public int updateUserAccessRights(Connection con, String strEmailId, boolean bUseLiceseManagement, boolean bUseUsageMetric, int nModifiedUserId) throws Exception {
		AdminDBI adminDBI = null;

		int nRtnRowsUpdated = 0;
		
		try {
			adminDBI = new AdminDBI();
			
			nRtnRowsUpdated = adminDBI.updateUserAccessRights(con, strEmailId, bUseLiceseManagement, bUseUsageMetric, nModifiedUserId);

			adminDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return nRtnRowsUpdated;
	}
	
	/**
	 * gets users has either license can manage or view usage reports is enabled
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUsersAdminPrivilege(Connection con) throws Exception {
		AdminDBI adminDBI = null;
		
		JSONArray jaUsersAdminPrivilege = null;
		
		try {
			adminDBI = new AdminDBI();

			jaUsersAdminPrivilege = adminDBI.getUsersAdminPrivilege(con);
			
			adminDBI = null;
		} catch (Exception e) {
			throw e;
		}

		
		return jaUsersAdminPrivilege;
	}
	
	/**
	 * gets users whose license is expired
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLicenseExpiredUsers(Connection con) throws Exception {
		AdminDBI adminDBI = null;
		
		JSONArray jaLicenseExpiredUsers = null;
		
		try {
			adminDBI = new AdminDBI();
			
			jaLicenseExpiredUsers = adminDBI.getLicenseExpiredUsers(con);
			
			adminDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaLicenseExpiredUsers;
	}

	/**
	 * gets users whose license will expire in next given days
	 * 
	 * @param con
	 * @param nExpireInNextDays
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLicenseWillExipreUsers(Connection con, int nExpireInNextDays) throws Exception {
		AdminDBI adminDBI = null;
		
		JSONArray jaLicenseWillExipreUsers = null;
		
		try {
			adminDBI = new AdminDBI();
			
			jaLicenseWillExipreUsers = adminDBI.getLicenseWillExipreUsers(con, nExpireInNextDays);
			
			adminDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaLicenseWillExipreUsers;
	}
}
