package com.appedo.credentials.manager;

import java.sql.Connection;
import java.util.Date;

import net.sf.json.JSONArray;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.credentials.DBI.LoginDBI;
import com.appedo.manager.LogManager;


/**
 * Manager handles the business logic for user signin operation
 * @author navin
 *
 */
public class LoginManager {

	/**
	 * Validates user signin
	 * 
	 * @param con
	 * @param strEmailId
	 * @param strPassword
	 * @param escapeVerification 
	 * @return
	 * @throws Exception
	 */
	public LoginUserBean loginUser(Connection con, String strEmailId, String strPassword, String strClientIPAddress, boolean escapeVerification) throws Exception {
		LoginDBI loginDBI = null;
		
		LoginUserBean loginUserBean = null;
		try {
			loginDBI = new LoginDBI();
			
			loginUserBean = loginDBI.loginUser(con, strEmailId, strPassword, strClientIPAddress, escapeVerification);
			
			
			
			loginDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return loginUserBean;
	}
	
	public LoginUserBean getSetAsDefaultValue(Connection con, LoginUserBean loginUserBean)  throws Exception {
		LoginDBI loginDBI = null;
		try {
			loginDBI = new LoginDBI();
			
			loginUserBean = loginDBI.getSetAsDefaultValue(con, loginUserBean);
			
			loginDBI = null;
		} catch (Exception e) {
			throw e;
		}
		return loginUserBean;
	}
	
	public JSONArray getEnterpriseLicense(Connection con, LoginUserBean loginUserBean)  throws Exception {
		JSONArray jaEnterprise = null;
		LoginDBI loginDBI = null;
		try {
			loginDBI = new LoginDBI();
			jaEnterprise = loginDBI.getEnterpriseLicense(con, loginUserBean);
			loginDBI = null;
		} catch (Exception e) {
			throw e;
		}
		return jaEnterprise;
	}
	/**
	 * Inserting login history
	 * 
	 * @param con
	 * @param nUserId
	 * @param strClientIpAddress
	 * @param strComment
	 * @return
	 * @throws Exception
	 */
	public long addLoginHistory(Connection con, long nUserId, String strClientIpAddress, String strComment) throws Exception {
		LoginDBI loginDBI = null;
		long lLoginHistoryId = -1L;
		try{
			loginDBI = new LoginDBI();
			lLoginHistoryId = loginDBI.addLoginHistory(con, nUserId, strClientIpAddress, strComment);
			loginDBI = null;
		}catch(Exception e){
			throw e;
		}
		return lLoginHistoryId;
	}
	
	/**
	 * Updating login history details
	 * @param con
	 * @param lLoginHistoryId
	 * @param strComment
	 * @throws Exception
	 */
	public void updateLogoutHistoryComment(Connection con,  Long lLoginHistoryId, String strComment) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		LoginDBI loginDBI = null;
		try{
			loginDBI = new LoginDBI();
			loginDBI.updateLogoutHistoryComment(con, lLoginHistoryId, strComment);
			loginDBI = null;
		}catch(Exception e){
			throw e;
		} finally {
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	/**
	 * updates login_comment in login_history
	 * 
	 * @param con
	 * @param nLoginHistoryId
	 * @param strComment
	 * @throws Exception
	 */
	public void updateLoginHistoryComment(Connection con, int nLoginHistoryId, String strComment) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		LoginDBI loginDBI = null;
		
		try {
			loginDBI = new LoginDBI();
			
			loginDBI.updateLoginHistoryComment(con, nLoginHistoryId, strComment);
			
			loginDBI = null;
		} catch (Exception e) {
			throw e;
		} finally {
			LogManager.logMethodEnd(dateLog);
		}
	}
}
