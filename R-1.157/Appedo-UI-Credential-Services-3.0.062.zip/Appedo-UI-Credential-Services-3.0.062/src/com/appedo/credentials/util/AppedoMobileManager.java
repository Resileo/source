package com.appedo.credentials.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Properties;

import com.appedo.credentials.connect.DataBaseManager;
import com.appedo.credentials.manager.CryptManager;
import com.appedo.manager.LogManager;

public class AppedoMobileManager {
	
	boolean bSentStatus = false;
	
	// Set which Vendor to be used.
	private static SMS_VENDOR sms_vendor = null;
	
	/* TANLA Properties */
	private static String TANLA_USER = null;
	private static String TANLA_PASSWORD = null;
	private static String TANLA_FROM = null;
	private static String TANLA_MSG_TYPE = null;
	private static String TANLA_DCS = null;
	private static String TANLA_DELIV_ACK = null;
	private static String TANLA_UDH = null;

	/* SSD India Properties */
	// Your authentication key
	private static String SSD_AUTHKEY = null;
	// Sender ID, while using route4 sender id should be 6 characters long.
	private static String SSD_SENDERID = null;
	private static String SSD_ROUTE = null;// 1- Promotional; 4- Transactional

	/* NEXMO Properties */

	private static String NEXMO_API_KEY = null;
	private static String NEXMO_API_SECRET = null;
	private static String NEXMO_SENDERID = null;
	
	static HashMap<String, SMS_VENDOR> countrycode = new HashMap<String, SMS_VENDOR>();

	public enum SMS_VENDOR {
		TANLA("TANLA"), SSD("SSD"), NEXMO("NEXMO"), NONE("NONE");
		
		private String name;
		
		private SMS_VENDOR(String strName) {
			name = strName;
		}
		
		public String getVendorName() {
			return name;
		}
	}
	
	/**
	 * Load the selected the Vendor and its API's properties
	 * 
	 * @param strFilePath
	 * @return
	 * @throws Exception
	 */
	public static boolean loadPropertyFileConstants(String strFilePath) throws Exception {
		Properties prop = new Properties();
		
		InputStream is = null;
		
		String strMailingSystem = "";
		
		try {
			is = new FileInputStream(strFilePath);
			prop.load(is);
			
			strMailingSystem = prop.getProperty("mailing_system");
			
			if( strMailingSystem == null || strMailingSystem.length() == 0 ) {
				//sms_vendor = SMS_VENDOR.NONE;
				
				TANLA_USER = null;
				TANLA_PASSWORD = null;
				TANLA_FROM = null;
				TANLA_MSG_TYPE = null;
				TANLA_DCS = null;
				TANLA_DELIV_ACK = null;
				TANLA_UDH = null;
				
				SSD_SENDERID = null;
				SSD_AUTHKEY = null;
				SSD_ROUTE = null;
				
				NEXMO_API_KEY = null;
				NEXMO_API_SECRET = null;
				NEXMO_SENDERID = null;
			} else {
				//sms_vendor = SMS_VENDOR.valueOf(strMailingSystem);
				
				TANLA_USER = prop.getProperty("TANLA_USER");
				TANLA_PASSWORD = prop.getProperty("TANLA_PASSWORD");
				TANLA_FROM = prop.getProperty("TANLA_FROM");
				TANLA_MSG_TYPE = prop.getProperty("TANLA_MSG_TYPE");
				TANLA_DCS = prop.getProperty("TANLA_DCS");
				TANLA_DELIV_ACK = prop.getProperty("TANLA_DELIV_ACK");
				TANLA_UDH = prop.getProperty("TANLA_UDH");
				
				SSD_SENDERID = prop.getProperty("SSD_SENDERID");
				SSD_AUTHKEY = prop.getProperty("SSD_AUTHKEY");
				SSD_ROUTE = prop.getProperty("SSD_ROUTE");
				
				NEXMO_API_KEY = prop.getProperty("NEXMO_API_KEY");
				NEXMO_API_SECRET = prop.getProperty("NEXMO_API_SECRET");
				NEXMO_SENDERID = prop.getProperty("NEXMO_SENDERID");
			}
		} catch(Exception e) {
			throw e;
		} finally {
			UtilsFactory.close(is);
			is = null;
			
			strMailingSystem = null;
		}
		
		return true;
	}
	
	public static void populateCountryISDCodes(Connection con) throws Exception {
		PreparedStatement pstmtSelect = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rs = null;
		try {
			sbQuery.append("SELECT telephone_code, sms_vendor FROM countries_master WHERE hide = false");
			pstmtSelect = con.prepareStatement(sbQuery.toString());

			rs = pstmtSelect.executeQuery();
			while (rs.next()) {
				countrycode.put(rs.getString("telephone_code"), SMS_VENDOR.valueOf(rs.getString("sms_vendor")));
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;

			DataBaseManager.close(pstmtSelect);
			pstmtSelect = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}

	/**
	 * Call Vendor's API to send SMS.
	 *  
	 * @param strPhoneNumber
	 * @param strMessage
	 * @return
	 * @throws Exception
	 */
	public boolean sendSMS(String strISDCode, String strPhoneNumberWithISDCode, String strMessage) throws Exception {
		StringBuilder sbURL = new StringBuilder();
		
		WebServiceManager wsm = null;
		sms_vendor = countrycode.get(strISDCode);
		
		// Validate Mobile Number
		if( strPhoneNumberWithISDCode == null || strPhoneNumberWithISDCode.length() <= 0 ) {
			throw new Exception("Blank Mobile Number found while sending SMS: "+strPhoneNumberWithISDCode);
		}
		
		// Valid Message
		if( strMessage == null || strMessage.length() <= 0 ) {
			throw new Exception("Blank Message found while sending SMS: "+strMessage);
		}
		
		if( sms_vendor == SMS_VENDOR.TANLA ) {
			try{
				sbURL.append("http://xxx.xxx.xxx.xxx/httpapi/sendmsg.php?")
					.append("user=").append(TANLA_USER)
					.append("&password=").append(TANLA_PASSWORD)
					.append("&from=").append(TANLA_FROM)
					.append("&to=").append(strPhoneNumberWithISDCode)
					.append("&message=").append(CryptManager.encodeURL(strMessage))
					.append("&msg_type=").append(TANLA_MSG_TYPE)
					.append("&dcs=").append(TANLA_DCS)
					.append("&deliv_ack=").append(TANLA_DELIV_ACK)
					.append("&udh=").append(TANLA_UDH);
				
				wsm = new WebServiceManager();
				wsm.sendRequest(sbURL.toString());
				
				if( wsm.getStatusCode() == 200 ) {
					LogManager.infoLog("SMS sent to "+strPhoneNumberWithISDCode+" <> Response: "+wsm.getResponse());
					
					bSentStatus = true;
				} else {
					LogManager.errorLog("SMS sent failed to "+strPhoneNumberWithISDCode+" <> StatusCode: "+wsm.getStatusCode()+" <> Response: "+wsm.getResponse());
				}
			} catch (Throwable th) {
				LogManager.errorLog(th);
			}
		} else if( sms_vendor == SMS_VENDOR.SSD ) {
			try{
				sbURL.append("http://sms.ssdindia.com/sendhttp.php?")
					.append("authkey=").append(SSD_AUTHKEY)
					.append("&sender=").append(SSD_SENDERID)
					.append("&route=").append(SSD_ROUTE)
					.append("&mobiles=").append(strPhoneNumberWithISDCode)	// strPhoneNumber can be comma separated
					.append("&message=").append(CryptManager.encodeURL(strMessage));
				
				wsm = new WebServiceManager();
				wsm.sendRequest(sbURL.toString());

				if( wsm.getStatusCode() == 200 ) {
					LogManager.infoLog("SMS sent to "+strPhoneNumberWithISDCode+" <> Response: "+wsm.getResponse());
					
					bSentStatus = true;
				} else {
					LogManager.errorLog("SMS sent failed to "+strPhoneNumberWithISDCode+" <> StatusCode: "+wsm.getStatusCode()+" <> Response: "+wsm.getResponse());
				}
			} catch (Throwable th) {
				System.out.println(th.getLocalizedMessage());
				th.printStackTrace();
				LogManager.errorLog(th);
			}
		} else if(sms_vendor == SMS_VENDOR.NEXMO ){
			try{
				sbURL.append("https://rest.nexmo.com/sms/json?")
					.append("api_key=").append(NEXMO_API_KEY)
					.append("&api_secret=").append(NEXMO_API_SECRET)
					.append("&from=").append(NEXMO_SENDERID)
					.append("&to=").append(strPhoneNumberWithISDCode)
					.append("&text=").append(CryptManager.encodeURL(strMessage));
				
				wsm = new WebServiceManager();
				wsm.sendRequest(sbURL.toString());

				if( wsm.getStatusCode() == 200 ) {
					LogManager.infoLog("SMS sent to "+strPhoneNumberWithISDCode+" <> Response: "+wsm.getResponse());
					
					bSentStatus = true;
				} else {
					LogManager.errorLog("SMS sent failed to "+strPhoneNumberWithISDCode+" <> StatusCode: "+wsm.getStatusCode()+" <> Response: "+wsm.getResponse());
				}
			} catch (Throwable th) {
				System.out.println(th.getLocalizedMessage());
				th.printStackTrace();
				LogManager.errorLog(th);
			}
		}
		
		return bSentStatus;
	}
	
	public static void main(String[] args) {
		AppedoMobileManager man = new AppedoMobileManager();
		try{
			System.out.println("Send SMS.");
		} catch( Exception e ) {
			System.out.println("e: "+e.getLocalizedMessage());
			e.printStackTrace();
		}
	}
}
