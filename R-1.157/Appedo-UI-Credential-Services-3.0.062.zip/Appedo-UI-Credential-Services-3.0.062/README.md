# Appedo-UI-Credential-Services



# to reload config, appedo_config & mail properties 
/<Appedo-UI-Credential-Services>/credentials/reloadConfigAndMailProperties