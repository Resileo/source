package com.appedo.processing.init;

import java.util.Timer;
import java.util.TimerTask;

import com.appedo.manager.LogManager;
import com.appedo.processing.common.Constants;
import com.appedo.processing.connect.DataBaseManager;
import com.appedo.processing.tcpserver.ReloadConfigTimerTask;
import com.appedo.processing.timer.CIDrainingTimerTask;
import com.appedo.processing.utils.TaskExecutor;

public class CIProcessInit {

	public static TimerTask ciDrainTimerTask= null, reloadTimerTask = null;
	public static Timer ciDrainTimer = new Timer(), ciReloadTimer = new Timer();

	public static void main(String[] args) throws Throwable {
		
		Constants.loadConstantsProperties();
		
		LogManager.initializePropertyConfigurator( Constants.LOG4J_PROPERTIES_FILE );
		
		reloadTimerTask = new ReloadConfigTimerTask();
		ciReloadTimer.schedule(reloadTimerTask, 1000*60*10, 1000*60*10);
		
		Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
		
		DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
		
		TaskExecutor.newExecutor(Constants.DEFAULT_CI_THREADPOOL_NAME, 10, 100, 1); // PoolName, minthread, maxthread, queue
		
		ciDrainTimerTask = new CIDrainingTimerTask();
		ciDrainTimer.scheduleAtFixedRate(ciDrainTimerTask, 150, 3000);
	}
}
