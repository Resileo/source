package com.appedo.processing.init;

import java.util.Timer;
import java.util.TimerTask;

import com.appedo.manager.LogManager;
import com.appedo.processing.common.Constants;
import com.appedo.processing.connect.DataBaseManager;
import com.appedo.processing.tcpserver.LTDrainingTimerTask;
import com.appedo.processing.tcpserver.LoadGenServer;
import com.appedo.processing.tcpserver.LoadGenTerminationTimerTask;
import com.appedo.processing.tcpserver.ReloadConfigTimerTask;
import com.appedo.processing.utils.TaskExecutor;

public class LTProcessInit {

	public static TimerTask ltDrainTimerTask= null, reloadTimerTask = null, timerTerminationTaskLoadTest = null;
	public static Timer ltDrainTimer = new Timer(), ltReloadTimer = new Timer(), timerTerminationLT = new Timer();

	public static void main(String[] args) throws Throwable {
		
		Constants.loadConstantsProperties();
		
		LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
		
		reloadTimerTask = new ReloadConfigTimerTask();
		ltReloadTimer.schedule(reloadTimerTask, 1000*60*10, 1000*60*10);
		
		// System.out.println(Constants.APPEDO_CONFIG_FILE_PATH);
		Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
		
		DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
		
		Thread t1 = new LoadGenServer();
		t1.start();
		
		TaskExecutor.newExecutor(Constants.DEFAULT_LT_THREADPOOL_NAME, 10, 100, 1); // PoolName, minthread, maxthread, queue
		
		ltDrainTimerTask = new LTDrainingTimerTask();
		ltDrainTimer.scheduleAtFixedRate(ltDrainTimerTask, 150, 1000);
		
		timerTerminationTaskLoadTest = new LoadGenTerminationTimerTask();
		timerTerminationLT.schedule(timerTerminationTaskLoadTest, 500, 1000*60);
		
	}

	
}
