package com.appedo.processing.init;

import java.util.Timer;
import java.util.TimerTask;

import com.appedo.manager.LogManager;
import com.appedo.processing.common.Constants;
import com.appedo.processing.connect.DataBaseManager;
import com.appedo.processing.tcpserver.ReloadConfigTimerTask;
import com.appedo.processing.timer.RumDrainingTimerTask;
import com.appedo.processing.utils.TaskExecutor;

public class RumProcessInit {

	public static TimerTask rumDrainTimerTask= null, reloadTimerTask = null;
	public static Timer rumDrainTimer = new Timer(), rumReloadTimer = new Timer();

	public static void main(String[] args) throws Throwable {
		
		Constants.loadConstantsProperties();
		
		LogManager.initializePropertyConfigurator( Constants.LOG4J_PROPERTIES_FILE );
		
		reloadTimerTask = new ReloadConfigTimerTask();
		rumReloadTimer.schedule(reloadTimerTask, 1000*60*10, 1000*60*10);
		
		Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
		
		DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
		
		TaskExecutor.newExecutor(Constants.DEFAULT_RUM_THREADPOOL_NAME, 10, 100, 1); // PoolName, minthread, maxthread, queue
		
		rumDrainTimerTask = new RumDrainingTimerTask();
		rumDrainTimer.scheduleAtFixedRate(rumDrainTimerTask, 150, 3000);
	}
}
