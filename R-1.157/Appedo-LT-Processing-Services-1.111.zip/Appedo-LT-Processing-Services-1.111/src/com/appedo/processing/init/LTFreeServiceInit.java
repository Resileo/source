package com.appedo.processing.init;

import java.util.Timer;
import java.util.TimerTask;

import com.appedo.manager.LogManager;
import com.appedo.processing.common.Constants;
import com.appedo.processing.connect.DataBaseManager;
import com.appedo.processing.tcpserver.LTFreeQueueCountTimerTask;
import com.appedo.processing.utils.TaskExecutor;

public class LTFreeServiceInit {

	public static TimerTask timerTaskFree = null;
	public static Timer timerCount = new Timer();

	public static void main(String[] args) throws Throwable {

		Constants.loadConstantsProperties();
		
		LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
		
		Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
		
		DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
		
		TaskExecutor.newExecutor(Constants.DEFAULT_LT_FREE_SERVICE, 1, 5, 1); // PoolName, minthread, maxthread, queue
		
		timerTaskFree = new LTFreeQueueCountTimerTask();
		timerCount.schedule(timerTaskFree, 500, 1000*10);
		
	}

}
