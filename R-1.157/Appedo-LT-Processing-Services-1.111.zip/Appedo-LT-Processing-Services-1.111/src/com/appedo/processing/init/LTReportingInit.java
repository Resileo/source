package com.appedo.processing.init;

import java.util.Timer;
import java.util.TimerTask;

import com.appedo.manager.LogManager;
import com.appedo.processing.common.Constants;
import com.appedo.processing.connect.DataBaseManager;
import com.appedo.processing.tcpserver.LTReportTimerTask;
import com.appedo.processing.tcpserver.ReloadConfigTimerTask;
import com.appedo.processing.utils.TaskExecutor;

public class LTReportingInit {

	public static TimerTask ltReportTimerTask= null, reloadTimerTask = null;;
	public static Timer ltReportTimer = new Timer(), ltReloadTimer = new Timer();

	public static void main(String[] args) throws Throwable {

		Constants.loadConstantsProperties();
		
		LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
		
		reloadTimerTask = new ReloadConfigTimerTask();
		ltReloadTimer.schedule(reloadTimerTask, 1000*60*10, 1000*60*10);
		
		Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
		
		DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
		
		TaskExecutor.newExecutor(Constants.DEFAULT_LT_REPORTING_NAME, 2, 2, 1); // PoolName, minthread, maxthread, queue
		
		ltReportTimerTask = new LTReportTimerTask();
		ltReportTimer.scheduleAtFixedRate(ltReportTimerTask, 150, 1000*30);
		
	}

}
