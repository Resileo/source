package com.appedo.processing.init;

import java.util.Timer;
import java.util.TimerTask;

import com.appedo.manager.LogManager;
import com.appedo.processing.common.Constants;
import com.appedo.processing.connect.DataBaseManager;
import com.appedo.processing.tcpserver.LTPaidQueueTimerTask;
import com.appedo.processing.utils.TaskExecutor;

public class LTPaidServiceInit {

	public static TimerTask timerTaskPaid = null;
	public static Timer timerPaid = new Timer();

	public static void main(String[] args) throws Throwable {

		Constants.loadConstantsProperties();
		
		LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
		
		Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
		
		DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
		
		TaskExecutor.newExecutor(Constants.DEFAULT_LT_PAID_SERVICE, 1, 20, 1); // PoolName, minthread, maxthread, queue
		
		timerTaskPaid = new LTPaidQueueTimerTask();
		timerPaid.schedule(timerTaskPaid, 500, 1000*10);
	}

}
