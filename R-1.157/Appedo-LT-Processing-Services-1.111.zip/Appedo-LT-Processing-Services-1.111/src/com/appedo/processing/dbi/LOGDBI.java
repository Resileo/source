package com.appedo.processing.dbi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.appedo.manager.LogManager;
import com.appedo.processing.bean.LOGDataBean;
import com.appedo.processing.connect.DataBaseManager;
import com.appedo.processing.utils.UtilsFactory;

/**
 * To insert the log details
 * 
 */
public class LOGDBI { 
	
	/**
	 * To insert the log messages into their respective tables according to their log type
	 * 
	 * @param con
	 * @param logBean
	 * @throws Throwable
	 */
	public void addLOGDataToBatch(PreparedStatement pstmt, LOGDataBean logBean) throws Throwable {
		StringBuilder sbQuery = new StringBuilder();
		
		//System.out.println(logBean.getLogData().toString());
		
		try {
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        
	        String strDate = sdf.format(UtilsFactory.toDate(logBean.getLogData().getString("@timestamp"), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
	        //System.out.println(strDate);
			pstmt.setString(1, logBean.getLogData().getString("guid"));
			pstmt.setString(2, logBean.getLogData().getString("type"));
			pstmt.setString(3, strDate);
			pstmt.setString(4, logBean.getLogData().toString());
			//Add to Batch
			pstmt.addBatch();
		} catch (Throwable t) {
			LogManager.errorLog("Exception while processing: "+logBean.toString());
			LogManager.errorLog(t, sbQuery);
			throw t;
		} /*finally {
			//DataBaseManager.close(pstmt);
			//pstmt = null;
			
			//UtilsFactory.clearCollectionHieracy( sbQuery );
		}*/
	}
	
	public PreparedStatement createLogTablePrepredstmt(Connection con) throws Throwable {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery.append("SELECT insert_log_entry(?, ?, ?, ?::json)");
			pstmt = con.prepareStatement(sbQuery.toString());
		} catch (Throwable t) {
			LogManager.errorLog("Exception while preparing connection statement for LOG Batch : ");
			LogManager.errorLog(t, sbQuery);
			throw t;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return pstmt;
	}
	
	public int insertBatch(PreparedStatement pstmt) throws Throwable {
		int ins[], nInserted = 0;
		
		try {
			ins = pstmt.executeBatch();
			nInserted = ins.length;
		} catch (Throwable t) {
			LogManager.errorLog("Exception while processing executeBatch of LOG Data : ");
			//LogManager.errorLog(t, sbQuery);
			throw t;
		}
		return nInserted;
	}
	
	/**
	 * Returns the UID of the Rum Module, for the given encrypted UID.
	 * 
	 * @param con
	 * @param strEncryptedUID
	 * @return
	 * @throws Exception
	 */
	public long getModuleUID(Connection con, String strGUID, String module_code) throws Exception {
		long lUID = -1l;
		
		String strQuery = null;
		Statement stmt = null;
		ResultSet rst = null;
		
		try{
			strQuery = "SELECT uid FROM module_master WHERE guid = '"+strGUID+"' and module_code like '"+module_code+"'";
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(strQuery);
			
			while( rst.next() ){
				lUID = rst.getLong("uid");
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			strQuery = null;
		}
		
		return lUID;
	}
	
}
