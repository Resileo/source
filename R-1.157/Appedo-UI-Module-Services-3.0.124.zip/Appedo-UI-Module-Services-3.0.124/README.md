# Appedo-UI-Module-Services


# to reload agents latest version and download file path
/<Appedo-UI-Module-Services>/common/getAgentsLatestVersionAndFilePath


# to reload config and appedo_config properties 
/<Appedo-UI-Module-Services>/common/reloadConfigProperties


# to reload minichart counters for the respective agent's
/<Appedo-UI-Module-Services>/common/reloadMiniChartCounters