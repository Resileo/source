package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.appedo.commons.manager.AppedoMailer;
import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.dbi.ModuleDBI;
import com.appedo.module.utils.UtilsFactory;

public class Controller extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Handles POST request
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Handles GET request comes
	 */	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Accessed in both GET and POSTrequests for the operations below, 
	 * 1. Loads agents latest build version
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();
		
		
		if (strActionCommand.endsWith("/common/getAgentsLatestVersionAndFilePath")) {
			// reload agents latest build version and agents download file path
			Connection con = null;
			
			JSONObject joRtn = null, joResult = new JSONObject();
			
			try {
				con = DataBaseManager.giveConnection();

				// loads latest agent's build version
				ModuleDBI.loadAgentsLatestVersion(con);

				// loads agents(counter_types) download file paths 
				ModuleDBI.loadAgentsDownloadFilePath(con);
				
				//Added manual entry for Filebeat Installer
				Constants.AGENT_LATEST_BUILD_VERSION.put("FILEBEAT_INSTALLER_LINUX", "XX");
				
				//Added manual entry for Linux Monitor Installer
				Constants.AGENT_LATEST_BUILD_VERSION.put("LINUX_MONITOR_INSTALLER", "XX");
				
				joResult.put("AGENT_LATEST_BUILD_VERSION", Constants.AGENT_LATEST_BUILD_VERSION);
				joResult.put("COUNTER_TYPES_DOWNLOAD_FILE_PATH", Constants.COUNTER_TYPES_DOWNLOAD_FILE_PATH);

				joRtn = UtilsFactory.getJSONSuccessReturn(joResult);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Exception in /module/getAgentsLatestVersionAndFilePath "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/common/reloadConfigProperties")) {
			// to reload config and appedo_config properties 
			
			try {
				// Loads Constant properties
				Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);

				// Loads Appedo config properties from the system path
				Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
				
				// loads appedo constants; say loads appedoWhiteLabels, 
				Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
				
				response.getWriter().write("Loaded <B>Appedo-UI-Module-Services</B>, config, appedo_config properties & appedo whitelabels.");
			} catch (Exception e) {
				LogManager.errorLog(e);
				response.getWriter().write("<B style=\"color: red; \">Exception occurred in Appedo-UI-Module-Services: "+e.getMessage()+"</B>");
			}
		} else if (strActionCommand.endsWith("/common/reloadMiniChartCounters")) {
			// reload minichart counter template ids for the agent 
			Connection con = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				// loads minichart counters for the respective agent's
				ModuleDBI.loadMiniChartCounters(con);
				
				// TODO: print counter_template_id 
				response.getWriter().write("Loaded <B>Appedo-UI-Module-Services minichart counters</B>,<BR>"+Constants.MINICHART_COUNTERS.toString());
			} catch (Exception e) {
				LogManager.errorLog(e);
				response.getWriter().write("<B style=\"color: red; \">Exception in /module/reloadMiniChartCounters: "+e.getMessage()+"</B>");
			} finally {
				DataBaseManager.close(con);
				con = null;
			}
		}else if(strActionCommand.endsWith("/common/reloadConfigAndMailProperties")) {
			// to reload config and appedo_config properties 
			
			try {
				// Loads Constant properties
				Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);
				
				// Loads Appedo config properties from the system path
				Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
				
				// Loads mail config
				AppedoMailer.loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
				
				// load appedo constants; say loads appedoWhiteLabels, 
				Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
				
				response.getWriter().write("Loaded <B>Appedo-UI-SLA-Service</B>, config, appedo_config, mail properties & appedo whitelabels.");
			} catch (Exception e) {
				LogManager.errorLog(e);
				response.getWriter().write("<B style=\"color: red; \">Exception occurred Appedo-UI-SLA-Service: "+e.getMessage()+"</B>");
			}
		}
	}
}
