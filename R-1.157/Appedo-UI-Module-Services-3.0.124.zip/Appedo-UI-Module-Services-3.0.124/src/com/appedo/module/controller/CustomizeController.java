package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.manager.LogManager;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.CustomizeManager;
import com.appedo.module.utils.UtilsFactory;

/**
 * Servlet implementation class CustomizeController
 */
public class CustomizeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomizeController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();
		Connection con = null;
		
		if(strActionCommand.endsWith("/customize/getCountryCodeDetails")) {
			// gets particular RUM uid's details, with configured threshold 
			CustomizeManager customizeManager = null;
			
			JSONObject joRtn = null; 
			JSONArray jaCountryCodes = null;
			
			try { 
				customizeManager = new CustomizeManager();
				
				con = DataBaseManager.giveConnection();
				
				jaCountryCodes = customizeManager.getCountryCodeDetails(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaCountryCodes);
				
				customizeManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Country Code Details.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}
