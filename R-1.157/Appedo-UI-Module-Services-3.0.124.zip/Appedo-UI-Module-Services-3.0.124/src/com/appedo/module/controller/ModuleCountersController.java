package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.DDLicenseBean;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.ModuleCounterManager;
import com.appedo.module.model.ModuleManager;
import com.appedo.module.model.SLAManager;
import com.appedo.module.utils.UtilsFactory;

public class ModuleCountersController extends HttpServlet {

	//do when post request comes
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		doAction(request, response);
	}
	
	//	do when Get request comes
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		doAction(request, response);
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();


		if(strActionCommand.endsWith("/apmCounters/getModuleCountersChartdata")) {
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null, joChartModuleCounters = null;
			
			StringBuilder sbCounterValues = new StringBuilder();

			//LoginUserBean loginUserBean = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				//loginUserBean = new LoginUserBean();
				//loginUserBean.fromJSONObject( JSONObject.fromObject(request.getAttribute("login_user_bean")));

				String strGUID = request.getParameter("guid");
				boolean bPdf = Boolean.valueOf(request.getParameter("ispdf"));
				Boolean bAboveThreshold = Boolean.valueOf(request.getParameter("is_above_threshold"));
				boolean bStaticCounter = Boolean.valueOf(request.getParameter("isStaticCounter"));
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// after counters from db, counterIds will comes as param
				//String[] saCounterIds = UtilsFactory.replaceNull(request.getParameter("counterNames"), "").split(",");
				// thinks, since above replaceNull as blank `""` adds in saCounterIds, then its length is 1, 
				String[] saCounterIds = UtilsFactory.replaceNull(request.getParameter("counterNames"), UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")).split(",");
				if( request.getParameter("counterNames") == null && saCounterIds.length == 0 ){
					saCounterIds = new String[]{UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")};
				}
				//String strMaxTimeStamp = UtilsFactory.replaceNull(request.getParameter("maxTimeStamp"), "");
				String strMaxTimeStamp = request.getParameter("maxTimeStamp");
				Long lMaxTimeStamp = strMaxTimeStamp != null ? Long.parseLong(strMaxTimeStamp) : null;
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), "1 hour");
				String startDateTime = request.getParameter("startDate");
				String endDateTime = request.getParameter("endDate");
				Long lStartDateTime = startDateTime != null ? Long.parseLong(startDateTime) : null;
				Long lEndDateTime = endDateTime != null ? Long.parseLong(endDateTime) : null;
				String strMaxValueCounterId = request.getParameter("maxValueCounterId");
				
				for(int i = 0; i < saCounterIds.length; i = i + 1) {
					String strCounterId = saCounterIds[i].trim();
					
					if( i != 0 ) sbCounterValues.append(",");
					
					sbCounterValues.append( strCounterId );
				}
				
				// System.out.println( strGUID+" " + sbCounterValues.toString()+" "+lMaxTimeStamp+" "+strFromStartInterval+" "+lStartDateTime+" "+lEndDateTime+" " +isPdf);
				// counter values data for real time plot chart 
				joChartModuleCounters = counterManager.getModuleCountersChartData(con, loginUserBean.getUserId(), strGUID, sbCounterValues.toString(), lMaxTimeStamp, strFromStartInterval, lStartDateTime, lEndDateTime, bPdf, bAboveThreshold, bStaticCounter, strMaxValueCounterId);
				joRtn = UtilsFactory.getJSONSuccessReturn(joChartModuleCounters);
				
				strGUID = null;
				strMaxTimeStamp = null;
				lMaxTimeStamp = null;
				strFromStartInterval = null;
				sbCounterValues = null;
				bAboveThreshold = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getModuleCountersChartdata_v1")) {
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null, joChartModuleCounters = null, joEnt = null;
			
			StringBuilder sbCounterValues = new StringBuilder();

			long user_id = -1L;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				Long lUID = Long.parseLong(request.getParameter("uid"));
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				
				// after counters from db, counterIds will comes as param
				//String[] saCounterIds = UtilsFactory.replaceNull(request.getParameter("counterNames"), "").split(",");
				// thinks, since above replaceNull as blank `""` adds in saCounterIds, then its length is 1, 
				String[] saCounterIds = UtilsFactory.replaceNull(request.getParameter("counterNames"), UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")).split(",");
				if( request.getParameter("counterNames") == null && saCounterIds.length == 0 ){
					saCounterIds = new String[]{UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")};
				}
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), "1 hour");
				String startDateTime = request.getParameter("startDate");
				String endDateTime = request.getParameter("endDate");
				Long lStartDateTime = startDateTime != null ? Long.parseLong(startDateTime) : null;
				Long lEndDateTime = endDateTime != null ? Long.parseLong(endDateTime) : null;
				Long metricId = Long.parseLong(request.getParameter("metricId"));
				//String defaultYAxisKey = request.getParameter("defaultYAxisKey");
				String xyLabel = request.getParameter("xyLabel");
				
				for(int i = 0; i < saCounterIds.length; i = i + 1) {
					String strCounterId = saCounterIds[i].trim();
					
					if( i != 0 ) sbCounterValues.append(",");
					
					sbCounterValues.append( strCounterId );
				}
				
				

				if(joEnt.getLong("e_id") != 0){
					user_id = joEnt.getLong("e_user_id");
				}else {
					user_id = loginUserBean.getUserId();
				}
				joChartModuleCounters = counterManager.getModuleCountersChartData_v2(con,  /*loginUserBean.getUserId()*/user_id, lUID, sbCounterValues.toString(), strFromStartInterval, lStartDateTime, lEndDateTime, metricId, xyLabel);
				joRtn = UtilsFactory.getJSONSuccessReturn(joChartModuleCounters);
				
				strFromStartInterval = null;
				sbCounterValues = null;
			} catch (Exception e) {
				if (e.getMessage().equals("1")) {
					LogManager.errorLog("Metric/Chart ID passed as null");
				} else {
					LogManager.errorLog(e);
				}
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getLOGCountersChartdata_v1")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			ModuleCounterManager counterManager = null;
			JSONObject joRtn = null, joChartModuleCounters = null;
			StringBuilder sbCounterValues = new StringBuilder();
			
			try {
				counterManager = new ModuleCounterManager();
				con = DataBaseManager.giveConnection();
				Long lUID = Long.parseLong(request.getParameter("uid"));
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), "1 hour");
				String startDateTime = request.getParameter("startDate");
				String endDateTime = request.getParameter("endDate");
				Long lStartDateTime = startDateTime != null ? Long.parseLong(startDateTime) : null;
				Long lEndDateTime = endDateTime != null ? Long.parseLong(endDateTime) : null;
				String query = request.getParameter("query");
				joChartModuleCounters = counterManager.getLOGModuleCountersChartData_v1(con, loginUserBean.getUserId(), lUID, strFromStartInterval, lStartDateTime, lEndDateTime, query);
				joRtn = UtilsFactory.getJSONSuccessReturn(joChartModuleCounters);
				strFromStartInterval = null;
				sbCounterValues = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getLOGCountersChartdata_v2")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			ModuleCounterManager counterManager = null;
			JSONObject joRtn = null, joChartModuleCounters = null, joEnt =null;
			long user_id = -1L;
			try {
				counterManager = new ModuleCounterManager();
				con = DataBaseManager.giveConnection();
				Long lUID = Long.parseLong(request.getParameter("uid"));
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), "1 hour");
				String startDateTime = request.getParameter("startDate");
				String endDateTime = request.getParameter("endDate");
				Long lStartDateTime = startDateTime != null ? Long.parseLong(startDateTime) : null;
				Long lEndDateTime = endDateTime != null ? Long.parseLong(endDateTime) : null;
				Long lMetricId = Long.parseLong(request.getParameter("metricId"));
				String xyLabel = request.getParameter("xyLabel");
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getLong("e_id") != 0){
					user_id = joEnt.getLong("e_user_id");
				}else {
					user_id = loginUserBean.getUserId();
				}
				
				joChartModuleCounters = counterManager.getLOGModuleCountersChartData_v2(con, /*loginUserBean.getUserId()*/ user_id, lUID, strFromStartInterval, lStartDateTime, lEndDateTime, lMetricId, xyLabel);
				joRtn = UtilsFactory.getJSONSuccessReturn(joChartModuleCounters);
				strFromStartInterval = null;
			} catch (Exception e) {
				if (e.getMessage().equals("1")) {
					LogManager.errorLog("Metric/Chart ID passed as null");
				} else {
				LogManager.errorLog(e);
				}
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} 
		else if(strActionCommand.endsWith("/apmCounters/getLogTypes")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			ModuleCounterManager counterManager = null;
			JSONObject joRtn = null, joChartModuleCounters = null;
			
			try {
				counterManager = new ModuleCounterManager();
				con = DataBaseManager.giveConnection();
				Long lUID = Long.parseLong(request.getParameter("uid"));
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), "1 hour");
				String startDateTime = request.getParameter("startDate");
				String endDateTime = request.getParameter("endDate");
				Long lStartDateTime = startDateTime != null ? Long.parseLong(startDateTime) : null;
				Long lEndDateTime = endDateTime != null ? Long.parseLong(endDateTime) : null;
				joChartModuleCounters = counterManager.getLOGTypes(con, loginUserBean.getUserId(), lUID);
				joRtn = UtilsFactory.getJSONSuccessReturn(joChartModuleCounters);
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getLogsData")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			ModuleCounterManager counterManager = null;
			JSONObject joRtn = null, joEnt = null;
			JSONArray jaLogData = null;
			long user_id =-1L;
			try {
				counterManager = new ModuleCounterManager();
				con = DataBaseManager.giveConnection();
				Long lUID = Long.parseLong(request.getParameter("uid"));
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), "1 hour");
				String startDateTime = request.getParameter("startDate");
				String endDateTime = request.getParameter("endDate");
				Long lStartDateTime = startDateTime != null ? Long.parseLong(startDateTime) : null;
				Long lEndDateTime = endDateTime != null ? Long.parseLong(endDateTime) : null;
				if (lStartDateTime != null && lEndDateTime != null) {
					strFromStartInterval = null;
				}
				String tableName = request.getParameter("tableName");
				String logLevel = request.getParameter("logLevel");
				String logName = request.getParameter("logName");
				
				//Enterprise implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getLong("e_id") != 0){
					user_id = joEnt.getLong("e_user_id");
				}else {
					user_id = loginUserBean.getUserId();
				}
				
				jaLogData = counterManager.getLogsData(con, user_id, lUID, null, strFromStartInterval, lStartDateTime, lEndDateTime, logName, tableName, logLevel);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaLogData);
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get log data. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getSearchLOGSData")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			ModuleCounterManager counterManager = null;
			JSONObject joRtn = null, joEnt = null;
			JSONArray jaLogData = null;
			long user_id =-1L;
			try {
				counterManager = new ModuleCounterManager();
				con = DataBaseManager.giveConnection();
				Long lUID = Long.parseLong(request.getParameter("uid"));
				String strSearchText = request.getParameter("logSearchText");
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), "1 hour");
				String startDateTime = request.getParameter("startDate");
				String endDateTime = request.getParameter("endDate");
				Long lStartDateTime = startDateTime != null ? Long.parseLong(startDateTime) : null;
				Long lEndDateTime = endDateTime != null ? Long.parseLong(endDateTime) : null;
				if (lStartDateTime != null && lEndDateTime != null) {
					strFromStartInterval = null;
				}
				String tableName = request.getParameter("tableName");
				String logLevel = request.getParameter("logLevel");
				String logName = request.getParameter("logName");
				
				//Enterprise implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getLong("e_id") != 0){
					user_id = joEnt.getLong("e_user_id");
				}else {
					user_id = loginUserBean.getUserId();
				}
				
				jaLogData = counterManager.getLogsData(con, user_id, lUID, strSearchText, strFromStartInterval, lStartDateTime, lEndDateTime, logName, tableName, logLevel);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaLogData);
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get log data. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getPrimaryCountersChartdata")) {
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null, joPrimaryCountersChartdata = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				
				joPrimaryCountersChartdata = counterManager.getPrimaryCountersChartdata(con, strGUID);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joPrimaryCountersChartdata);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get PrimaryCountersChartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getPrimaryCountersForAllDetailsPage")) {
			Connection con = null;

			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null;
			JSONArray jaPrimaryCountersChartdata = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				boolean bShowPrimaryCounters = Boolean.parseBoolean( UtilsFactory.replaceNull(request.getParameter("showPrimaryCounters"), "false") );
				jaPrimaryCountersChartdata = counterManager.getPrimaryCountersForAllDetailsPage(con, strGUID, bShowPrimaryCounters);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaPrimaryCountersChartdata);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get PrimaryCountersChartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getSelectedCounterSummary")) {
			Connection con = null;

			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null;
			JSONArray jaPrimaryCountersChartdata = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strAgentVersion = request.getParameter("agentVersion");
				
				jaPrimaryCountersChartdata = counterManager.getSelectedCounterSummary(con, strGUID, strAgentVersion);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaPrimaryCountersChartdata);
				
				strGUID = null;
				strAgentVersion = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getSelectedCounterSummary. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}

		} else if(strActionCommand.endsWith("/apmCounters/getProfilerTransactions")) {
			// PROFILER, gets Transactions
			Connection con = null;

			LoginUserBean loginUserBean = null;
			DDLicenseBean ddLicenseBean = null;
			
			ModuleCounterManager counterManager = null;
			ModuleManager moduleManager = null;

			boolean bProfilerEnabled = false;
			
			JSONArray jaTransactionTree = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();
				moduleManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strCounterTypeName = request.getParameter("counterTypeName");
				String strFromStartInterval = request.getParameter("fromStartInterval");

/* disable profiler validation
				// gets license details from `userwise_lic_monthwise` and `dd_config_param` tables
				ddLicenseBean = moduleManager.getDDUserLicenseDetails(con, loginUserBean);
				if( ddLicenseBean == null ) {
					// License expired
					throw new Exception("1");
				} else {
					if ( ddLicenseBean.getMaxProfilers() != -1 ) {
						bProfilerEnabled = moduleManager.isProfilerEnabled(con, strGUID, ddLicenseBean.getMaxProfilers(), loginUserBean);
					} else {
						// enabled for all modules
						bProfilerEnabled = true;
					}
					
					if ( ! bProfilerEnabled ) {
						// Upgrade your license to enable profiling.
						throw new Exception("2");
					} else {
*/						
						// 
						jaTransactionTree = counterManager.getProfilerTransactionTree(con, strGUID, strCounterTypeName, strFromStartInterval, false);
						joRtn = UtilsFactory.getJSONSuccessReturn(jaTransactionTree);
/*						
					}
				}
*/
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getProfilerTransactions. ");
			} finally {
				counterManager = null;
				loginUserBean = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getProfilerTransactionsWithDateRange")) {
			// PROFILER, gets Transactions
			Connection con = null;

			LoginUserBean loginUserBean = null;
			DDLicenseBean ddLicenseBean = null;
			
			ModuleCounterManager counterManager = null;
			ModuleManager moduleManager = null;

			boolean bProfilerEnabled = false;
			
			JSONArray jaTransactionTree = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();
				moduleManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strCounterTypeName = request.getParameter("counterTypeName");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");

				jaTransactionTree = counterManager.getProfilerTransactionsWithDateRange(con, strGUID, strCounterTypeName, strFromStartInterval, strToInterval, false);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaTransactionTree);
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getProfilerTransactionsWithDateRange. ");
			} finally {
				counterManager = null;
				loginUserBean = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getKeyProfilerTransactions")) {
			// PROFILER, gets Transactions
			Connection con = null;

			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager counterManager = null;
			
			JSONArray jaTransactionTree = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strCounterTypeName = request.getParameter("counterTypeName");
				String strFromStartInterval = request.getParameter("fromStartInterval");

				jaTransactionTree = counterManager.getProfilerTransactionTree(con, strGUID, strCounterTypeName, strFromStartInterval, true);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaTransactionTree);
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getProfilerTransactions. ");
			} finally {
				counterManager = null;
				loginUserBean = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getKeyProfilerTransactionsWithDateRange")) {
			// PROFILER, gets Transactions
			Connection con = null;

			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager counterManager = null;
			
			JSONArray jaTransactionTree = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strCounterTypeName = request.getParameter("counterTypeName");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");

				jaTransactionTree = counterManager.getProfilerTransactionsWithDateRange(con, strGUID, strCounterTypeName, strFromStartInterval, strToInterval, true);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaTransactionTree);
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getKeyProfilerTransactionsWithDateRange. ");
			} finally {
				counterManager = null;
				loginUserBean = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getProfilerTransactionTimeTaken")) {
			// PROFILER, particular Transaction's time taken
			ModuleCounterManager  counterManager = null;
			Connection con = null;

			LoginUserBean loginUserBean = null;
			
			JSONArray jaTransactionTree = null;
			ArrayList altransactionsTimeTaken = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();

				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strLocalhostNameIP = request.getParameter("localhost_name_ip");
				String strTransactionType = request.getParameter("transactionType");
				String strTransactionName = request.getParameter("transactionName");
				String strCounterTypeName = request.getParameter("counterTypeName");
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				// 
				//TransactionTree = counterManager.getProfilerTransactionTimeTaken(con, strGUID, strTransactionName);
				//t.print(jaTransactionTree.toString());
				altransactionsTimeTaken = counterManager.getProfilerTransactionTimeTaken(con, strTransactionType, strGUID, strLocalhostNameIP, strTransactionName, strCounterTypeName, strFromStartInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(altransactionsTimeTaken.toString());
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getProfilerTransactions. ");
			} finally {
				counterManager = null;
				loginUserBean = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getProfilerTransactionTimeTakenWithDateRange")) {
			// PROFILER, particular Transaction's time taken
			ModuleCounterManager  counterManager = null;
			Connection con = null;

			LoginUserBean loginUserBean = null;
			
			JSONArray jaTransactionTree = null;
			ArrayList altransactionsTimeTaken = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();

				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strLocalhostNameIP = request.getParameter("localhost_name_ip");
				String strTransactionType = request.getParameter("transactionType");
				String strTransactionName = request.getParameter("transactionName");
				String strCounterTypeName = request.getParameter("counterTypeName");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				altransactionsTimeTaken = counterManager.getProfilerTransactionTimeTakenWithDateRange(con, strGUID, strLocalhostNameIP, strTransactionType, strTransactionName, strCounterTypeName, strFromStartInterval, strToInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(altransactionsTimeTaken.toString());
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getProfilerTransactions. ");
			} finally {
				counterManager = null;
				loginUserBean = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getProfilerMethods")) {
			// PROFILER, method trace
			ModuleCounterManager  counterManager = null;
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			ArrayList<LinkedHashMap<String, Object>> jaMethodsTrace = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strLocalNameIP = request.getParameter("localhost_name_ip");
				String strTransactionType = request.getParameter("transactionType");
				String strTransactionName = request.getParameter("transactionName");
				//String strId = request.getParameter("pId");
				String strTime = request.getParameter("time");
				String strDuration = request.getParameter("duration");
				String strCounterTypeName = request.getParameter("counterTypeName");
				
				String strTimeStamp = UtilsFactory.formatDateToTimestamp(Long.parseLong(strTime));
				
				jaMethodsTrace = counterManager.getProfilerMethodsTrace(con, strGUID, strLocalNameIP, strTransactionType, strTransactionName, strTimeStamp, strDuration, strCounterTypeName);
				//System.out.println("jaMethodsTrace: "+jaMethodsTrace);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaMethodsTrace.toString().replaceAll("=", ":"));
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getProfilerMethods. ");
			} finally {
				counterManager = null;
				loginUserBean = null;

				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/updateChartStausForDashboard")) {
			Connection con = null;
			
			ModuleCounterManager counterManager = null;

			LoginUserBean loginUserBean = null;
			
			boolean chartStatus = false;
			long lChartId = -1L;
			
			JSONObject joRtn = null;
			
			try {
				
				String strGUID = request.getParameter("guid");
				String strCounterId = request.getParameter("counterid");
				if (request.getParameter("status").equals("true")) {
					chartStatus = true;
				} else {
					chartStatus = false;
				}
				
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lChartId = counterManager.updateChartStausForDashboard(con, strGUID, strCounterId, chartStatus);
				//System.out.println(lChartId);
				if(lChartId>0){
					if (chartStatus == true) {
						joRtn = UtilsFactory.getJSONSuccessReturn("Added to dashboard successfully.");
					} else {
						joRtn = UtilsFactory.getJSONSuccessReturn("Successfully removed from dashboard.");
					}
					DataBaseManager.commitConnection(con);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("Unexpected error occur.");
					DataBaseManager.rollbackConnection(con);
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to Update updateChartStausForDashboard. ");
				DataBaseManager.rollbackConnection(con);
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/updateApmKeyTransaction")) {
			Connection con = null;
			
			ModuleCounterManager counterManager = null;

			LoginUserBean loginUserBean = null;
			
			long lKeyId = -1L;
			
			JSONObject joRtn = null;
			
			try {
				
				String strGUID = request.getParameter("guid");
				String uri = request.getParameter("uri");
				String keyTransactionId = request.getParameter("keyTransactionId");
				String keyTransactionName = request.getParameter("keyTransactionName");
				String keyTransactionDescription = request.getParameter("keyTransactionDescription");
				String status = request.getParameter("status");
				
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				joRtn = counterManager.updateApmKeyTransaction(con, strGUID, uri, keyTransactionId,keyTransactionName,keyTransactionDescription,status,loginUserBean.getUserId());
				boolean keyTransactionStatus = (Boolean) joRtn.get("success") ;
				if(keyTransactionStatus){
					DataBaseManager.commitConnection(con);
				}else{
					DataBaseManager.rollbackConnection(con);
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to Update updateApmKeyTransaction. ");
				DataBaseManager.rollbackConnection(con);
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getModuleCountersBreaches")) {
			// gets SLA counters breaches
			Connection con = null;
			
			SLAManager slaManager = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null, joRtnCountersBreaches = null;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strCounterIds = request.getParameter("counterIds");
				String strSLAIdsForAnalytics = request.getParameter("slaIdsForAnalytics");
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				joRtnCountersBreaches = slaManager.getCountersBreaches(con, strGUID, strSLAIdsForAnalytics, strCounterIds, strFromStartInterval, null, null, loginUserBean.getUserId());
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnCountersBreaches);
				
				strGUID = null;
				strCounterIds = null;
				slaManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getModuleCountersBreches. ");
			} finally {
				slaManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getPrimaryCountersChartdataWithBreaches")) {
			// gets primary counters chartdata with respective counter's mapped SLA breaches for particular the module's guid
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ModuleCounterManager moduleCounterManager = null;
			
			JSONObject joRtn = null, joRtnPrimaryCountersDataWithBreaches = null;
			
			try {
				moduleCounterManager = new ModuleCounterManager();

				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				
				joRtnPrimaryCountersDataWithBreaches = moduleCounterManager.getPrimaryCountersChartdataWithBreaches(con, strGUID, loginUserBean.getUserId());
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnPrimaryCountersDataWithBreaches);
				
				moduleCounterManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getPrimaryCountersDataWithBreches. ");
			} finally {
				moduleCounterManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getProfilerTimeTakenMethods")) {
			// PROFILER, gets profiler top 10 time taken methods
			Date dateLog = LogManager.logMethodStart();
			Connection con = null;
			ModuleCounterManager  counterManager = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONArray jaTimetakenMethods = null;
			JSONObject joRtn = null;
			
			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strGUID = request.getParameter("guid");
				String strLocalNameIP = request.getParameter("localhost_name_ip");
				String strTransactionType = request.getParameter("transactionType");
				String strTransactionName = request.getParameter("transactionName");
				//String strId = request.getParameter("pId");
				String strTime = request.getParameter("time");
				String strDuration = request.getParameter("duration");
				String strCounterTypeName = request.getParameter("counterTypeName");
				
				String strTimeStamp = UtilsFactory.formatDateToTimestamp(Long.parseLong(strTime));
				
				// gets profiler time taken methods
				jaTimetakenMethods = counterManager.getProfilerTimeTakenMethods(con, strGUID, strLocalNameIP, strTransactionType, strTransactionName, strTimeStamp, strDuration, strCounterTypeName);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaTimetakenMethods);
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getProfilerTimeTakenMethods. ");
			} finally {
				counterManager = null;
				loginUserBean = null;

				DataBaseManager.close(con);
				con = null;

			    LogManager.logMethodEnd(dateLog);
			    
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apmCounters/getCSVChartdata")) {
			Connection con = null;

			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null;
			Date dateLog = LogManager.logMethodStart();

			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				joRtn = counterManager.getCSVChartdata(con, request.getParameter("guid"), request.getParameter("counterNames"), request.getParameter("fromStartInterval"));
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
			    LogManager.logMethodEnd(dateLog);
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apmCounters/getCSVChartdataWithDateRange")) {
			Connection con = null;

			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null;
			Date dateLog = LogManager.logMethodStart();

			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				joRtn = counterManager.getCSVChartdataWithDateRange(con, request.getParameter("guid"), request.getParameter("counterNames"), request.getParameter("startDateTime"), request.getParameter("endDateTime"));
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata with date range. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
			    LogManager.logMethodEnd(dateLog);
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apmCounters/getTopProcess")) {
			Connection con = null;

			ModuleCounterManager counterManager = null;
			
			JSONObject joRtn = null;
			Date dateLog = LogManager.logMethodStart();
			String topProcess = null;

			try {
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				String strUID = request.getParameter("uid");
				String strCounterId = request.getParameter("counter_id");
				String strCategory = request.getParameter("category");
				String strSliderValue = request.getParameter("sliderValue");
				String selectedTime = request.getParameter("selectedTime");
				
				topProcess = counterManager.getTopProcess(con, strUID, strCounterId, strCategory, strSliderValue, selectedTime);

				if(topProcess!=null){
					joRtn = UtilsFactory.getJSONSuccessReturn(topProcess);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("No Record(s) Found. ");
				}
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
			    LogManager.logMethodEnd(dateLog);
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apmCounters/getBreachedCountersDataForHotspot")) {
			// get users all ASDs breached counters data
			Date dateLog = LogManager.logMethodStart();
			
			Connection con = null;
			
			JSONObject joRtn = null;
			JSONArray jaRtnBreachedCounters = null;
			
			ModuleCounterManager counterManager = null;
			
			LoginUserBean loginUserBean = null;
			
			try {
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				String strFromStartInterval = null;
				Long lStartDateTime = null;
				Long lEndDateTime = null;
				
				if ( request.getParameter("sliderValue") != null ) {
					strFromStartInterval = request.getParameter("sliderValue");
					lStartDateTime = null;
					lEndDateTime = null;
				} else {
					strFromStartInterval = null;
					lStartDateTime = Long.parseLong( request.getParameter("startDateTime") );
					lEndDateTime = Long.parseLong( request.getParameter("endDateTime") );
				}
				
				// gets user's breached counters data
				jaRtnBreachedCounters = counterManager.getBreachedCountersDataForHotspot(con, strFromStartInterval, lStartDateTime, lEndDateTime, loginUserBean.getUserId());
				
				if( jaRtnBreachedCounters != null ){
					joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBreachedCounters);
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("No Record(s) Found.");
				}
				
				strFromStartInterval = null;
				lStartDateTime = null;
				lEndDateTime = null;
			} catch (Throwable th) {
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get data.");
			} finally {
				counterManager = null;
				
				DataBaseManager.close(con);
				con = null;
			    LogManager.logMethodEnd(dateLog);
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apmCounters/getModuleStaticCountersData")) {
			// gets static counter(s) data 
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null, joRtnStaticCounterData = null;
			
			ModuleCounterManager counterManager = null;
			
			try {
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				counterManager = new ModuleCounterManager();
				
				con = DataBaseManager.giveConnection();
				
				String strGUID = request.getParameter("guid");
				String strCounters = request.getParameter("counterIds");
				
				// get static counter(s) data
				joRtnStaticCounterData = counterManager.getModuleStaticCountersData(con, strGUID, strCounters, loginUserBean.getUserId(), false);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnStaticCounterData);
				
				counterManager = null;
				strGUID = null;
				strCounters = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getModuleStaticCountersData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} /*else if(strActionCommand.endsWith("/apmCounters/getBreachedCountersForHotspot")) {
			// gets all `WARNING` & `CRITICAL` breaches, of ASD counters, SUM tests & RUM modules 
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null, joRtnBreachedModules = null;
			
			String strInterval = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			ModuleCounterManager counterManager = null;
			
			try {
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				
				counterManager = new ModuleCounterManager();

				strInterval = request.getParameter("interval");
				
				if ( strInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong( request.getParameter("startDateTime") );
					lEndDateTimeInMills = Long.parseLong( request.getParameter("endDateTime") );
				}
				
				// gets all `WARNING` & `CRITICAL` breaches, of ASD counters, SUM tests & RUM modules 
				joRtnBreachedModules = counterManager.getBreachedCountersForHotspot(con, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnBreachedModules);

				counterManager = null;
				strInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get breached counters for hotspot.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}*/
	}
}
