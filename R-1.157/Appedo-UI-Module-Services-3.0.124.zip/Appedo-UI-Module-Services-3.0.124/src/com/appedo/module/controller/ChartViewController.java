package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.ChartManager;
import com.appedo.module.utils.UtilsFactory;

public class ChartViewController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Handles POST request
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Handles GET request comes
	 */	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Accessed in both GET and POSTrequests for the operations below, 
	 * 
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("text/html");
		
		String strActionCommand = request.getRequestURI();
		
		
		if (strActionCommand.endsWith("/chart/addChartView")) {
			Connection con = null;
			JSONObject joRtn = null;
			JSONObject joChartDetails = null;
			JSONArray jaSelectedCounters = null;
			
			long lChartViewId = -1L;
			
			LoginUserBean loginUserBean = null;
			
			ChartManager chartManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				chartManager = new ChartManager();
				
				joChartDetails = new JSONObject();
				jaSelectedCounters = JSONArray.fromObject(request.getParameter("selectedCounters"));
				
				joChartDetails.put("chartName", request.getParameter("chartName").trim());
				joChartDetails.put("chartDescription", request.getParameter("chartDescription").trim());
				joChartDetails.put("selectedCounters", jaSelectedCounters);
				
				lChartViewId = chartManager.addChartView(con, joChartDetails, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Chart view added. ");
				
				
				DataBaseManager.commitConnection(con);
				
				loginUserBean = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);
                
                if( e.getMessage().equals("Chart name already exists") ) {
                    joRtn = UtilsFactory.getJSONFailureReturn("Chart name already exists. ");
                } else {
                    joRtn = UtilsFactory.getJSONFailureReturn("Exception in addServiceMap "+e.getMessage());	
                }
                e.printStackTrace();
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/chart/getModulesTypesDetails")) {
			//			
			Connection con = null;

			JSONObject joRtn = null;
			// Application/Server/Database/SUM
			JSONArray jaRtnModulesDetails = null;
			
			LoginUserBean loginUserBean = null;
			ChartManager chartManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				chartManager = new ChartManager();

				long lServiceMapId = Long.parseLong( UtilsFactory.replaceNull(request.getParameter("serviceMapId"), "-1") );
				
				// 
				jaRtnModulesDetails = chartManager.getModuleTypesDetails(con, lServiceMapId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnModulesDetails);
				
				chartManager = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in getModuleTypesDetails "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/chart/getCategories")) {
			Connection con = null;
            JSONArray jaCategoriesCounters = null, alCounters = null;
            JSONObject joCategoryCounters = null, joCounters = null;
            ChartManager chartManager = null;
            
            long lUId = -1;
            
            try {
                chartManager = new ChartManager();
                
                con = DataBaseManager.giveConnection();
                
                lUId = Long.valueOf(request.getParameter("uid"));
                
                String module_name=request.getParameter("type");
                
                if(module_name.equalsIgnoreCase("SUM")  || module_name.equalsIgnoreCase("RUM")){
                	jaCategoriesCounters = new JSONArray();
                	joCategoryCounters = new JSONObject();
                   	joCategoryCounters.put("category", "Response Time");
                   	alCounters = new JSONArray();
                   	
                   	joCounters = new JSONObject();
                   	joCounters.put("category", "Response Time");
                   	joCounters.put("name", "Pageload Time");
                   	joCounters.put("displayName", "Pageload Time");
                   	joCounters.put("isDefault", false);
                   	joCounters.put("isSelected", false);
                   	joCounters.put("showCounter", false);
                   	joCounters.put("isPublic", true);
                   	joCounters.put("show_in_primary", false);
                   	joCounters.put("show_in_secondary", false);
                   	joCounters.put("isMandatory", false);
                   	
                   	alCounters.add(joCounters);
                   	
                   	joCategoryCounters.put("counters", alCounters);
                   	jaCategoriesCounters.add(joCategoryCounters);
                }else{
                	jaCategoriesCounters = chartManager.getAgentAllCategoryWiseCounters(con, lUId, module_name);
                }
            } catch(Exception e) {
            	LogManager.errorLog(e);
            } finally {
            	DataBaseManager.close(con);
                con = null;
                chartManager = null;
                response.getWriter().write(jaCategoriesCounters.toString());
            }
		} else if (strActionCommand.endsWith("/chart/checkChartViewNameExists")) {
			//	
			Connection con = null;

			JSONObject joRtn = null;

			LoginUserBean loginUserBean = null;

			ChartManager chartManager = null;

			boolean bChartNameExists = false;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				chartManager = new ChartManager();

				Long lChartViewId = Long.parseLong( UtilsFactory.replaceNull(request.getParameter("chartId"), "-1") );
				String strChartName = request.getParameter("chartName").trim();

				// checks is chartname exists, tried while insert "-1" to check all user's service name, while update to check other than respective user's and serviceId
				bChartNameExists = chartManager.isChartNameExists(con, strChartName, lChartViewId, loginUserBean.getUserId());
				
				joRtn = UtilsFactory.getJSONSuccessReturn(bChartNameExists+"");
				
				chartManager = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in checkChartViewNameExists "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/chart/getChartCardData")) {
			
			Connection con = null;
			String jaUserChartViews = null;
			JSONObject joRtn = null;
			LoginUserBean loginUserBean = null;
			ChartManager chartManager = null;
			long chartId = 0L;
			
			try {
				con = DataBaseManager.giveConnection();
				chartManager = new ChartManager();

				if( request.getParameter("chart_view_id")!= null ){
					chartId = Long.valueOf( request.getParameter("chart_view_id") );
				}
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				jaUserChartViews = chartManager.getUserChartViewsWithCounterDetails(con, loginUserBean, chartId);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserChartViews);
				
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in getChartCardData "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/chart/getChartMultiLine")) {
			// 
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ChartManager chartManager = null;
			
			JSONObject joRtn = null, joModuleDetails = null;
			JSONArray jaRtnChartData = null;
			
			String strInterval = null, strJoRtnChartData = null;
			
			Long lStartDateTime = null, lEndDateTime = null;
			
			try {
				con = DataBaseManager.giveConnection();
				chartManager = new ChartManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
			//	JSONObject j = JSONObject.fromObject(request.getParameter("chartContent"));
			//	JSONArray content = JSONArray.fromObject(j.get("counterDetails"));
				
				joModuleDetails = JSONObject.fromObject(request.getParameter("chartContent"));
				strInterval = request.getParameter("interval");
				if ( strInterval == null ) {
					lStartDateTime = Long.parseLong( request.getParameter("startDate") );
					lEndDateTime = Long.parseLong( request.getParameter("endDate") );	
				}
				
				jaRtnChartData = new JSONArray();
				/*for ( int i = 0; i < content.size(); i++ ){
					JSONObject jo = content.getJSONObject(i);*/
					if(joModuleDetails.getString("module_name").equals("SUM")){
						String locations = chartManager.getSUMLocations(con, joModuleDetails.getLong("module_or_test_id"));
						String saLocations[] = locations.split(",");
						
						for( int k = 0; k < saLocations.length; k++){
							strJoRtnChartData = chartManager.getMyChartData(con, joModuleDetails, saLocations[k], strInterval, lStartDateTime, lEndDateTime);
							if( strJoRtnChartData != null ){
								jaRtnChartData.add(strJoRtnChartData);
							}
						}
					} else {
						strJoRtnChartData = chartManager.getMyChartData(con, joModuleDetails, null, strInterval, lStartDateTime, lEndDateTime);
						if( strJoRtnChartData != null ){
							jaRtnChartData.add(strJoRtnChartData);
						}
					}
				/*}*/
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnChartData);
				
				
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in getChartCardData "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				UtilsFactory.clearCollectionHieracy(joModuleDetails);
				joModuleDetails = null;
				
				strInterval = null;
				lStartDateTime = null;
				lEndDateTime = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/chart/getChartMultiLineForPdf")) {
			
			Connection con = null;
			JSONArray jaUserChartViews = new JSONArray();
			JSONObject joRtn = null;
			LoginUserBean loginUserBean = null;
			ChartManager chartManager = null;

			String strInterval = null;
			
			Long lStartDateTime = null, lEndDateTime = null;
			
			try {
				con = DataBaseManager.giveConnection();
				chartManager = new ChartManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				JSONObject j = JSONObject.fromObject(request.getParameter("chartContent"));
				JSONArray content = JSONArray.fromObject(j.get("counterDetails"));
				strInterval = request.getParameter("interval");
				if ( strInterval == null ) {
					lStartDateTime = Long.parseLong( request.getParameter("startDate") );
					lEndDateTime = Long.parseLong( request.getParameter("endDate") );	
				}
				String ja = null;
				for ( int i = 0; i < content.size(); i++ ){
					JSONObject jo = content.getJSONObject(i);
					if(jo.getString("module_name").equalsIgnoreCase("SUM")){
						String locations = chartManager.getSUMLocations(con, jo.getLong("module_or_test_id"));
						String loc[] = locations.split(",");
						for( int k = 0; k < loc.length; k++){
							//ja = chartManager.getChartMultiLine(con, jo.getString("module_name"), jo.getLong("module_or_test_id"), jo.getLong("counter_id"), jo.getString("display_name"), jo.getString("unit"), interval, jo.getString("app_name"), jo.getString("module_name"), jo.getString("category"),  loc[k]);
							ja = chartManager.getChartMultiLine(con, jo, strInterval, loc[k], lStartDateTime, lEndDateTime);
							if( ja != null ){
								jaUserChartViews.add(ja);
							}
						}
					} else {
						ja = chartManager.getChartMultiLine(con, jo, strInterval, null, lStartDateTime, lEndDateTime );
						if( ja != null ){
							jaUserChartViews.add(ja);
						}
					}
				}
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserChartViews);
				
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in getChartCardData "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;

				strInterval = null;
				lStartDateTime = null;
				lEndDateTime = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/chart/deleteChartView")) {
			// 
			Connection con = null;
			
			JSONObject joRtn = null;

			long lChartViewId = -1L;
			
			LoginUserBean loginUserBean = null;
			
			ChartManager chartManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				chartManager = new ChartManager();
				
				lChartViewId = Long.parseLong(request.getParameter("chartViewId"));
				
				// deletes chart_view and chart_view_details delete on cascade and foreign key constraint added
				chartManager.deleteChartView(con, lChartViewId, loginUserBean.getUserId());
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Chart View deleted.");
				
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception while deleting Chart View "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				chartManager = null;
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/chart/updateChartView")) {
			Connection con = null;
			JSONObject joRtn = null;
			JSONObject joChartDetails = null;
			JSONArray jaSelectedCounters = null;
			
			long lChartViewId = -1L;
			
			LoginUserBean loginUserBean = null;
			
			ChartManager chartManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				chartManager = new ChartManager();
				
				joChartDetails = new JSONObject();
				jaSelectedCounters = JSONArray.fromObject(request.getParameter("selectedCounters"));
				
				joChartDetails.put("chartName", request.getParameter("chartName").trim());
				joChartDetails.put("chartViewId", request.getParameter("chartViewId").trim());
				joChartDetails.put("chartDescription", request.getParameter("chartDescription").trim());
				joChartDetails.put("selectedCounters", jaSelectedCounters);
				
				lChartViewId = chartManager.updateChartView(con, joChartDetails, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Chart View Updated. ");
				
				DataBaseManager.commitConnection(con);
				
				loginUserBean = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);
                
                if( e.getMessage().equals("Chart name already exists") ) {
                    joRtn = UtilsFactory.getJSONFailureReturn("Chart name already exists. ");
                } else {
                    joRtn = UtilsFactory.getJSONFailureReturn("Exception in addServiceMap "+e.getMessage());	
                }
                e.printStackTrace();
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/chart/getChartVisualizerData_v2")) {
			Connection con = null;
			JSONObject joRtn = null;
			JSONArray jaChartDetails = null;
			
			LoginUserBean loginUserBean = null;
			
			ChartManager chartManager = null;
			Long lCounterTemplateId = null, lRefId = null;
			String strModuleType = null, strCounterId = null, strModuleName = null, category = null, strInterval = null;
			Long lSecRefId, lStartDate = -1L, lEndDate = -1L;
			JSONObject joEnt = null;
			long user_id = -1L;
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				chartManager = new ChartManager();
				
				//uid, counterId, moduleType, counterTemplateId
				strCounterId = request.getParameter("counterId");
				lRefId = Long.parseLong(request.getParameter("refId"));
				strModuleType = request.getParameter("moduleType");
				strModuleName = request.getParameter("moduleName");
				category = request.getParameter("category");
				strInterval = request.getParameter("interval");
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				System.out.println(joEnt);
				
				if (request.getParameter("startDate") != null && request.getParameter("endDate") != null) {
					lStartDate = Long.parseLong(request.getParameter("startDate"));
					lEndDate = Long.parseLong(request.getParameter("endDate"));
				}
				
				if (request.getParameter("counterTemplateId") != null) {
					lCounterTemplateId = Long.parseLong(request.getParameter("counterTemplateId"));
				}
				
				if(strModuleType.equals("LOG") && request.getParameter("secRefId") != null) {
					lSecRefId = Long.parseLong(request.getParameter("secRefId"));
				} else {
					lSecRefId = -1L;
				}
				
				if(joEnt.getLong("e_id") != 0){
					user_id = joEnt.getLong("e_user_id");
				}else {
					user_id = loginUserBean.getUserId();
				}
				
				String strSecRefName = request.getParameter("secRefName");
				
				jaChartDetails = chartManager.getChartVisualizerData_v1(con, /*loginUserBean.getUserId()*/ user_id , lRefId, strCounterId, strModuleType, lCounterTemplateId, strModuleName, lSecRefId, strSecRefName, category, strInterval, lStartDate, lEndDate);
				if (jaChartDetails.size() > 0) {
					joRtn = UtilsFactory.getJSONSuccessReturn(jaChartDetails);
				} else {
	                joRtn = UtilsFactory.getJSONFailureReturn("Chart Visualizer not found");
				}
				loginUserBean = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("get Chart visualizer failed.");	
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/chart/getAllMyCharts")) {
				Connection con = null;
				JSONObject joRtn = null, joEnt = null;
				JSONArray jaMyCharts = null;
				
				LoginUserBean loginUserBean = null;
				
				ChartManager chartManager = null;
				try {
					con = DataBaseManager.giveConnection();

					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

					chartManager = new ChartManager();
					
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					
					jaMyCharts = chartManager.getAllMyCharts(con, loginUserBean.getUserId(), joEnt.getLong("e_id"));
					joRtn = UtilsFactory.getJSONSuccessReturn(jaMyCharts);
					loginUserBean = null;
				} catch (Exception e) {
	                LogManager.errorLog(e);
	                joRtn = UtilsFactory.getJSONFailureReturn("get Chart visualizer failed.");	
				} finally {
					DataBaseManager.close(con);
					con = null;
					
					response.getWriter().write(joRtn.toString());
				}
			} else if (strActionCommand.endsWith("/chart/addToMyChart")) {
				Connection con = null;
				JSONObject joRtn = null, joEnt = null;
				String strMyChartName = null, strModuleType = null;
				Long lChartId = -1L, lRefId = -1L;
				boolean isNewChart = false;
				boolean isMyChartExist = false;
				LoginUserBean loginUserBean = null;
				
				ChartManager chartManager = null;
				try {
					strMyChartName = request.getParameter("myChartName");
					lChartId = Long.parseLong(request.getParameter("chartId"));
					strModuleType= request.getParameter("moduleType");
					lRefId = Long.parseLong(request.getParameter("refId"));
					isNewChart = Boolean.parseBoolean(request.getParameter("isNewMyChart"));
					isMyChartExist = Boolean.parseBoolean(request.getParameter("isMyChartExist"));

					con = DataBaseManager.giveConnection();
				//	System.out.println("isNewChart" +isNewChart);

					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
					
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
										
					chartManager = new ChartManager();
					
					chartManager.addToMyChart(con, loginUserBean.getUserId(), lChartId, strMyChartName, strModuleType, lRefId, isNewChart, isMyChartExist, joEnt.getLong("e_id"));
					joRtn = UtilsFactory.getJSONSuccessReturn("Selected graph added to "+strMyChartName);
					
					DataBaseManager.commitConnection(con);
					
					loginUserBean = null;
				} catch (Exception e) {
	                LogManager.errorLog(e);
	                if( e.getMessage().contains("duplicate key value violates unique constraint") ) {
	                	joRtn = UtilsFactory.getJSONFailureReturn("Selected graph already available in "+strMyChartName);
					} else if (e.getMessage().equals("1")) {
						joRtn = UtilsFactory.getJSONFailureReturn("Entered new chart name already exists, please enter another name.");
					} else {
						joRtn = UtilsFactory.getJSONFailureReturn("Unable to add/update My Charts");
					}
	                	
				} finally {
					DataBaseManager.close(con);
					con = null;
					
					response.getWriter().write(joRtn.toString());
				}
			} else if (strActionCommand.endsWith("/chart/getMyChartIds")) {
				Connection con = null;
				JSONObject joRtn = null, joEnt = null;
				String strMyChartName = null;
				LoginUserBean loginUserBean = null;
				JSONArray jaMyChartIds = null;
				
				ChartManager chartManager = null;
				try {
				//	jaMyChartIds = new JSONArray();
					strMyChartName = request.getParameter("chartName");

					con = DataBaseManager.giveConnection();

					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
					
					chartManager = new ChartManager();
					
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					
					jaMyChartIds = chartManager.getMyChartIds(con, loginUserBean.getUserId(), strMyChartName, joEnt.getLong("e_id"));
					joRtn = UtilsFactory.getJSONSuccessReturn(jaMyChartIds);
					
					loginUserBean = null;
				} catch (Exception e) {
	                LogManager.errorLog(e);
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chart IDs");
	                	
				} finally {
					DataBaseManager.close(con);
					con = null;
					
					response.getWriter().write(joRtn.toString());
				}
			} else if (strActionCommand.endsWith("/chart/getChartVisualDataWithChartId")) {
				Connection con = null;
				JSONObject joRtn = null;
				Long lChartId = -1L, lUserId = -1L;
				LoginUserBean loginUserBean = null;
				JSONObject jaChartData = null, joEnt = null;
				
				ChartManager chartManager = null;
				try {

					con = DataBaseManager.giveConnection();

					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
					
					lChartId = Long.parseLong(request.getParameter("chartId"));

					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					if(joEnt.getInt("e_id")!=0){
						lUserId = joEnt.getLong("e_user_id");
					}else{
						lUserId = loginUserBean.getUserId();
					}
					
					chartManager = new ChartManager();
					
					jaChartData = chartManager.getMyChartVisualizerWithChartId(con, lUserId, lChartId);
					joRtn = UtilsFactory.getJSONSuccessReturn(jaChartData);
					
					loginUserBean = null;
				} catch (Exception e) {
	                LogManager.errorLog(e);
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chart visualizer data");
	                	
				} finally {
					DataBaseManager.close(con);
					con = null;
					
					response.getWriter().write(joRtn.toString());
				}
			} else if (strActionCommand.endsWith("/chart/getChartDataPoints")) {
				Connection con = null;
				JSONObject joRtn = null;
				Long lrefId = -1L, lStartDate= null, lEndDate = null, lMetricId = -1L, lUserId= -1L;
				String strCounterId = null, strModuleType = null, strSliderValue = null, strXYaxisLabel = null, strLocation = null, strRumType = null;
				LoginUserBean loginUserBean = null;
				JSONObject joChartData = null, joEnt = null;
				
				ChartManager chartManager = null;
				try {

					con = DataBaseManager.giveConnection();

					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
					
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					if(joEnt.getInt("e_id")!=0){
						lUserId = joEnt.getLong("e_user_id");
					}else{
						lUserId = loginUserBean.getUserId();
					}
					
					lrefId = Long.parseLong(request.getParameter("refId"));
					lMetricId = Long.parseLong(request.getParameter("metricId"));
					strSliderValue = request.getParameter("sliderValue");
					if (request.getParameter("startTime") != null && request.getParameter("endTime") != null) {
						lStartDate = Long.parseLong(request.getParameter("startTime"));
						lEndDate = Long.parseLong(request.getParameter("endTime"));
						strSliderValue = null;
					}
					strCounterId = request.getParameter("counterId");
					strModuleType = request.getParameter("moduleType");
					
					strXYaxisLabel = request.getParameter("xyAxisLabel");
					strLocation = request.getParameter("location");
					strRumType = request.getParameter("rumType");
					

					chartManager = new ChartManager();
					
					joChartData = chartManager.getChartDataPoint(con, lUserId, lrefId, lMetricId, strSliderValue, lStartDate, lEndDate, strCounterId, strModuleType, strXYaxisLabel, strLocation, strRumType);
					joRtn = UtilsFactory.getJSONSuccessReturn(joChartData);
					
					loginUserBean = null;
				} catch (Exception e) {
	                LogManager.errorLog(e);
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chart visualizer data");
	                	
				} finally {
					DataBaseManager.close(con);
					con = null;
					
					response.getWriter().write(joRtn.toString());
				}
			} else if (strActionCommand.endsWith("/chart/removeFromMyChart")) {
				Connection con = null;
				JSONObject joRtn = null, joEnt = null;
				String strMyChartName = null;
				Long lChartId = -1L;
				LoginUserBean loginUserBean = null;
				
				ChartManager chartManager = null;
				try {
					strMyChartName = request.getParameter("myChartName");
					lChartId = Long.parseLong(request.getParameter("chartId"));
					
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
										
					con = DataBaseManager.giveConnection();
		
					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
		
					chartManager = new ChartManager();
					
					chartManager.removeFromMyChart(con, loginUserBean.getUserId(), lChartId, strMyChartName, joEnt.getLong("e_id"));
					joRtn = UtilsFactory.getJSONSuccessReturn("Selected graph removed from "+strMyChartName);
					
					DataBaseManager.commitConnection(con);
					
					loginUserBean = null;
				} catch (Exception e) {
		            LogManager.errorLog(e);
						joRtn = UtilsFactory.getJSONFailureReturn("Unable to remove chart from My Charts");
				} finally {
					DataBaseManager.close(con);
					con = null;
					
					response.getWriter().write(joRtn.toString());
				}
			}
		
	}
}
