package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.ServiceMapBean;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.ServiceManager;
import com.appedo.module.utils.UtilsFactory;

public class ServiceMapController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Handles POST request
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Handles GET request comes
	 */	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * Accessed in both GET and POSTrequests for the operations below, 
	 * 
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("text/html");
		
		String strActionCommand = request.getRequestURI();
		
		
		if (strActionCommand.endsWith("/service/addServiceMap")) {
			// 
			Connection con = null;
			
			JSONObject joRtn = null, joEnt = null;

			long lServiceMapId = -1L;
			
			LoginUserBean loginUserBean = null;
			ServiceMapBean serviceMapBean = null;
			
			ServiceManager serviceManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();
				
				serviceMapBean = new ServiceMapBean();
				serviceMapBean.setName(request.getParameter("serviceName").trim());
				serviceMapBean.setDescription(request.getParameter("serviceDescription").trim());
				//serviceMapBean.setMappedService(JSONObject.fromObject(request.getParameter("selectedServiceMaps")));
				serviceMapBean.setSystemGenerated(false);
				
				JSONArray jaSelectedServiceMaps = JSONArray.fromObject(request.getParameter("selectedServiceMaps"));
				for(int i = 0; i < jaSelectedServiceMaps.size(); i = i + 1) {
					serviceMapBean.addServiceMap((JSONObject) jaSelectedServiceMaps.get(i));
				}
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				lServiceMapId = serviceManager.addServiceMap(con, serviceMapBean, loginUserBean, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn("Service map added. ");
				
				
				DataBaseManager.commitConnection(con);
				
				jaSelectedServiceMaps = null;
				loginUserBean = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);
                
                if( e.getMessage().equals("1") ) {
                    joRtn = UtilsFactory.getJSONFailureReturn("Service name already exists. ");
                } else {
                    joRtn = UtilsFactory.getJSONFailureReturn("Exception in addServiceMap "+e.getMessage());	
                }
                e.printStackTrace();
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/getModulesTypesDetails")) {
			//
			
			Connection con = null;

			JSONObject joRtn = null, joEnt = null;
			// Application/Server/Database/SUM
			JSONArray jaRtnModulesDetails = null;
			
			LoginUserBean loginUserBean = null;

			ServiceManager serviceManager = null;
			
			long lUser_id =-1L;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();

				long lServiceMapId = Long.parseLong( UtilsFactory.replaceNull(request.getParameter("serviceMapId"), "-1") );
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getInt("e_id")!=0){
					lUser_id = joEnt.getLong("e_user_id");
				}else{
					lUser_id = loginUserBean.getUserId();
				}
				
				jaRtnModulesDetails = serviceManager.getModuleTypesDetails(con, lServiceMapId, /*loginUserBean*/ lUser_id, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnModulesDetails);
				
				serviceManager = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in getModuleTypesDetails "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/checkServiceNameExists")) {
			//
			
			Connection con = null;

			JSONObject joRtn = null;

			LoginUserBean loginUserBean = null;

			ServiceManager serviceManager = null;

			boolean bServiceNameExists = false;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();

				Long lServiceMapId = Long.parseLong( UtilsFactory.replaceNull(request.getParameter("serviceMapId"), "-1") );
				String strServiceName = request.getParameter("serviceName").trim();

				// checks is serviceaname exists, tried while insert "-1" to check all user's service name, while update to check other than respective user's and serviceId
				bServiceNameExists = serviceManager.isServiceNameExists(con, strServiceName, lServiceMapId, loginUserBean.getUserId());
				
				joRtn = UtilsFactory.getJSONSuccessReturn(bServiceNameExists+"");
				
				serviceManager = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in checkIsServiceNameExists "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/getUserServiceMapsWithMapCountDetails")) {
			// gets user service maps with total count of modules mapped for a ServiceMap
			Connection con = null;

			LoginUserBean loginUserBean = null;

			ServiceManager serviceManager = null;

			JSONArray jaUserServiceMaps = null;
			JSONObject joRtn = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();
				
				// 
				jaUserServiceMaps = serviceManager.getUserServiceMapsWithMapCountDetails(con, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserServiceMaps);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Unable to getUserServiceMapsWithMapCountDetails.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/service/getUserServiceMapsWithMapCountDetails_v1")) {
			// gets user service maps with total count of modules mapped for a ServiceMap
			Connection con = null;

			LoginUserBean loginUserBean = null;

			ServiceManager serviceManager = null;

			JSONArray jaUserServiceMaps = null;
			JSONObject joRtn = null;
			JSONObject joEnt = null;
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();
				
				//enterpriseLicense
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				
				jaUserServiceMaps = serviceManager.getUserServiceMapsWithMapCountDetails_v1(con, loginUserBean, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserServiceMaps);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn("Unable to getUserServiceMapsWithMapCountDetails.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/updateServiceMap")) {
			// 
			Connection con = null;
			
			JSONObject joRtn = null;

			long lServiceMapId = -1L;
			
			LoginUserBean loginUserBean = null;
			ServiceMapBean serviceMapBean = null;
			
			ServiceManager serviceManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();
				
				serviceMapBean = new ServiceMapBean();
				serviceMapBean.setServiceMapId(Long.parseLong(request.getParameter("serviceMapId")));
				serviceMapBean.setName(request.getParameter("serviceName").trim());
				serviceMapBean.setDescription(request.getParameter("serviceDescription").trim());
				//serviceMapBean.setMappedService(JSONObject.fromObject(request.getParameter("selectedServiceMaps")));
				
				
				JSONArray jaSelectedServiceMaps = JSONArray.fromObject(request.getParameter("selectedServiceMaps"));
				for(int i = 0; i < jaSelectedServiceMaps.size(); i = i + 1) {
					serviceMapBean.addServiceMap((JSONObject) jaSelectedServiceMaps.get(i));
				}
				
				// 
				serviceManager.updateServiceMap(con, serviceMapBean, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Service map updated. ");
				
				DataBaseManager.commitConnection(con);
				
				loginUserBean = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);

                if( e.getMessage().equals("1") ) {
                	joRtn = UtilsFactory.getJSONFailureReturn("Service name already exists. ");
                } else {
                	joRtn = UtilsFactory.getJSONFailureReturn("Exception in updateServiceMap "+e.getMessage());	
                }
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/service/updateServiceMap_v1")) {
			// 
			Connection con = null;
			
			JSONObject joRtn = null, joEnt = null;

			long lServiceMapId = -1L;
			
			LoginUserBean loginUserBean = null;
			ServiceMapBean serviceMapBean = null;
			
			ServiceManager serviceManager = null;
			
			long lUser_id = -1L;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();
				
				serviceMapBean = new ServiceMapBean();
				serviceMapBean.setServiceMapId(Long.parseLong(request.getParameter("serviceMapId")));
				serviceMapBean.setName(request.getParameter("serviceName").trim());
				serviceMapBean.setDescription(request.getParameter("serviceDescription").trim());
				//serviceMapBean.setMappedService(JSONObject.fromObject(request.getParameter("selectedServiceMaps")));
				
				
				if(Boolean.parseBoolean(request.getParameter("updateServiceMapDetails"))) {
					JSONArray jaSelectedServiceMaps = JSONArray.fromObject(request.getParameter("selectedServiceMaps"));
					for(int i = 0; i < jaSelectedServiceMaps.size(); i = i + 1) {
						serviceMapBean.addServiceMap((JSONObject) jaSelectedServiceMaps.get(i));
					}
				}
				
				boolean updateServiceMapDetails = Boolean.parseBoolean(request.getParameter("updateServiceMapDetails"));
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getInt("e_id")!=0){
					lUser_id = joEnt.getLong("e_user_id");
				}else{
					lUser_id = loginUserBean.getUserId();
				}
				
				serviceManager.updateServiceMap_v1(con, serviceMapBean, loginUserBean, lUser_id, updateServiceMapDetails);
				joRtn = UtilsFactory.getJSONSuccessReturn("Service map updated. ");
				
				DataBaseManager.commitConnection(con);
				
				loginUserBean = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);

                if( e.getMessage().equals("1") ) {
                	joRtn = UtilsFactory.getJSONFailureReturn("Service name already exists. ");
                } else {
                	joRtn = UtilsFactory.getJSONFailureReturn("Exception in updateServiceMap "+e.getMessage());	
                }
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}/* else if (strActionCommand.endsWith("/service/addServiceMapToExiting")) {
			// 
			Connection con = null;
			
			JSONObject joRtn = null;

			long lServiceMapId = -1L;
			
			LoginUserBean loginUserBean = null;
			ServiceMapBean serviceMapBean = null;
			
			ServiceManager serviceManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();
				
				serviceMapBean = new ServiceMapBean();
				serviceMapBean.setServiceMapId(Long.parseLong(request.getParameter("serviceMapId")));
				serviceMapBean.setName(request.getParameter("serviceName").trim());
				serviceMapBean.setDescription(request.getParameter("serviceDescription").trim());
				//serviceMapBean.setMappedService(JSONObject.fromObject(request.getParameter("selectedServiceMaps")));
				
				JSONArray jaSelectedServiceMaps = JSONArray.fromObject(request.getParameter("selectedServiceMaps"));
				for(int i = 0; i < jaSelectedServiceMaps.size(); i = i + 1) {
					serviceMapBean.addServiceMap((JSONObject) jaSelectedServiceMaps.get(i));
				}
				
				// 
				serviceManager.insertServiceMapDetails(con, serviceMapBean, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Service map updated. ");
				
				DataBaseManager.commitConnection(con);
				
				loginUserBean = null;
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);

                if( e.getMessage().equals("1") ) {
                	joRtn = UtilsFactory.getJSONFailureReturn("Service name already exists. ");
                } else {
                	joRtn = UtilsFactory.getJSONFailureReturn("Exception in updateServiceMap "+e.getMessage());	
                }
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}*/ else if (strActionCommand.endsWith("/service/deleteServiceMap")) {
			// 
			Connection con = null;
			
			JSONObject joRtn = null;

			long lServiceMapId = -1L;
			
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			try {
				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );

				serviceManager = new ServiceManager();
				
				lServiceMapId = Long.parseLong(request.getParameter("serviceMapId"));
				
				// deletes service_map_details & service_map
				serviceManager.deleteServiceMap(con, lServiceMapId, loginUserBean.getUserId());
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Service map deleted.");
				
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
                LogManager.errorLog(e);
                
                DataBaseManager.rollbackConnection(con);
                joRtn = UtilsFactory.getJSONFailureReturn("Exception in deleteServiceMap "+e.getMessage());
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/service/getServiceMapData")) {
			Connection con = null;

			ServiceManager serviceManager = null;

			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null;
			JSONArray joArr = null;
			
			try {
				serviceManager = new ServiceManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				joArr = serviceManager.getServiceMapData(con, loginUserBean.getUserId());
				joRtn = UtilsFactory.getJSONSuccessReturn(joArr);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to Update updateChartStausForDashboard. ");
			} finally {
				serviceManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/getUserServiceMaps")) {
			// gets user service maps
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONArray jaUserServiceMaps = null;
			JSONObject joRtn = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				
				// 
				jaUserServiceMaps = serviceManager.getUserServiceMaps(con, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserServiceMaps);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getUserServiceMaps.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/getServiceMapMappedModules")) {
			// gets mapped_modules/mapped_services for a particular ServiceMap's 
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONObject joRtn = null, joRtnServiceMapMappedModules = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				
				long lServiceMapId = Long.parseLong(request.getParameter("serviceMapId"));
				
				// gets mapped_modules/mapped_services
				joRtnServiceMapMappedModules = serviceManager.getServiceMapMappedModules(con, lServiceMapId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnServiceMapMappedModules);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getServiceMapMappedModules.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/getServiceMapMappedModuleSummaries")) {
			// gets service map's selected module's, say APPLICATION's OR SERVER's OR ..., module's mapped `uid/test_id`s summaries 
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONObject joRtn = null;
			JSONArray jaRtnMappedModuleSummaries = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				
				long lServiceMapId = Long.parseLong(request.getParameter("serviceMapId"));
				String strModuleCode = request.getParameter("moduleCode");
				
				// get mapped module's summaries
				jaRtnMappedModuleSummaries = serviceManager.getServiceMapMappedModuleSummaries(con, lServiceMapId, strModuleCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnMappedModuleSummaries);
				
				strModuleCode = null;
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getServiceMap mapped module summary.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
		/**
		 * New-Dashboard's first grid.
		 * Get all service-map's health status.
		 */
		else if (strActionCommand.endsWith("/service/getServiceMapsHealth")) {
			// gets Service Maps overall health
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONObject joRtn = null;
			JSONArray jaRtnServiceMapsHealth = null;
			
			String strInterval = "";
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				
				strInterval = request.getParameter("interval");
				if ( strInterval != null ) {
					// slider
					lStartDateTimeInMills = null;
					lEndDateTimeInMills = null;
				} else {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				
				// gets Service Maps health
				jaRtnServiceMapsHealth = serviceManager.getServiceMapsHealth(con, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnServiceMapsHealth);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Service Maps health.");
			} finally {
				DataBaseManager.close(con);
				con = null;

				strInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
		else if (strActionCommand.endsWith("/service/getServiceMaps_v1")) {
			// gets Service Maps overall health
			Connection con = null;
			LoginUserBean loginUserBean = null;
			ServiceManager serviceManager = null;
			JSONObject joRtn = null,  joEnterpriseData = null;
			JSONArray jaRtnServiceMapsHealth = null;
			long lUserId =-1L;
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				//Enterprise implemented.
				joEnterpriseData = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnterpriseData.getLong("e_id") != 0){
					lUserId = joEnterpriseData.getLong("e_user_id");
				}else {
					lUserId = loginUserBean.getUserId();
				}
				
				serviceManager = new ServiceManager();
				jaRtnServiceMapsHealth = serviceManager.getServiceMaps_v1(con, joEnterpriseData.getLong("e_id"), lUserId);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnServiceMapsHealth);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Service Maps health.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
		
		/**
		 * New-Dashboard's second grid.
		 * Get Service-Map-module's, module code wise health
		 * 
		 */
		else if (strActionCommand.endsWith("/service/getModuleCodeWiseHealth")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONObject joRtn = null, joRtnModuleCodesHealth = null;
			
			String strInterval = "";
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				
				long lServiceMapId = Long.parseLong(request.getParameter("serviceMapId"));
				strInterval = request.getParameter("interval");
				if ( strInterval != null ) {
					// slider
					lStartDateTimeInMills = null;
					lEndDateTimeInMills = null;
				} else {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				
				// gets Service Map's mapped modules, module code wise health
				joRtnModuleCodesHealth = serviceManager.getModuleCodeWiseHealth(con, lServiceMapId, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnModuleCodesHealth);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get module code wise health.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				strInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/getModulesCountersWiseHealth")) {
			// gets Service Map's mapped modules, each module's selected counters statuses
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONArray jaRtnModulesCountersStatuses = null;
			JSONObject joRtn = null;
			
			String strModuleCode = "", strHealthCode = "", strInterval = "";
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				
				long lServiceMapId = Long.parseLong(request.getParameter("serviceMapId"));
				strModuleCode = request.getParameter("moduleCode");
				strHealthCode = request.getParameter("healthCode");
				strInterval = request.getParameter("interval");
				if ( strInterval != null ) {
					// slider
					lStartDateTimeInMills = null;
					lEndDateTimeInMills = null;
				} else {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				
				// gets Service Map's mapped modules, each module's selected counters statuses
				jaRtnModulesCountersStatuses = serviceManager.getModulesCountersWiseHealth(con, lServiceMapId, strModuleCode, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnModulesCountersStatuses);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get module counter wise health.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				strModuleCode = null;
				strHealthCode = null;
				strInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/mapModuleToSystemServiceMap")) {
			// map the added `uid/test_id` to user's system Service Map
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONObject joModule = null, joRtn = null;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				joModule = JSONObject.fromObject(request.getParameter("moduleDetails"));
				
				// map the added module, to System generated Service Map
				serviceManager.mapModuleToSystemServiceMap(con, joModule, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Module mapped to system Service Map");
				
				DataBaseManager.commitConnection(con);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					// more than one System generated ServiceMap available for the user
					joRtn = UtilsFactory.getJSONFailureReturn("User has more than one system generated Service Map.");	
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map module to system Service Map.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/getModuleCounters_v1")) {
			// gets module's selected counters OR module's breached counters based given healthCode (`WARNING/CRITICAL`)
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			ServiceManager serviceManager = null;
			
			JSONObject joRtn = null, joRtnMappedModulesDetails = null, joEnterpriseData = null;
			JSONArray jaRtnCounters = null;
			
			String strModuleCode = "", strHealthCode = "", strInterval = "";
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			long lReferenceId = -1L, lServiceMapId = -1L, lUserId = -1L;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				serviceManager = new ServiceManager();
				
				joEnterpriseData = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnterpriseData.getLong("e_id") != 0){
					lUserId = joEnterpriseData.getLong("e_user_id");
				}else {
					lUserId = loginUserBean.getUserId();
				}
				
				lServiceMapId = Long.parseLong(request.getParameter("serviceMapId"));
				lReferenceId = Long.parseLong(UtilsFactory.replaceNull(request.getParameter("referenceId"), "-1") );
				strModuleCode =  UtilsFactory.replaceNull(request.getParameter("moduleCode"), "");
				strHealthCode = UtilsFactory.replaceNull(request.getParameter("healthCode"), "");
				strInterval = request.getParameter("interval");
				if ( strInterval != null ) {
					// slider
					lStartDateTimeInMills = null;
					lEndDateTimeInMills = null;
				} else {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				
				// gets module's selected counters OR module's breached counters based given healthCode (`WARNING/CRITICAL`)
				joRtnMappedModulesDetails = serviceManager.getModuleCounters_v1(con, joEnterpriseData.getLong("e_id"), lUserId, lServiceMapId, lReferenceId, strModuleCode, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnMappedModulesDetails);
				
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get module counters.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				strHealthCode = null;
				strInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/service/addToServiceMap")) {
			// gets module's selected counters OR module's breached counters based given healthCode (`WARNING/CRITICAL`)
			Connection con = null;
			LoginUserBean loginUserBean = null;
			ServiceManager serviceManager = null;
			JSONObject joRtn = null;
			String strModuleCode = null;
			Long lUid = null;
			boolean isDataReceived = false;
			
			try {
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				//loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				serviceManager = new ServiceManager();
				if(request.getParameter("userId") != null && request.getParameter("UID") != null) {
					loginUserBean.setUserId(Long.parseLong(request.getParameter("userId")));
					lUid = Long.parseLong(request.getParameter("UID"));
					isDataReceived = true;
				}
				strModuleCode =  UtilsFactory.replaceNull(request.getParameter("moduleCode"), "");
				if (isDataReceived) {
					serviceManager.v1_addToServiceMap(con, strModuleCode, lUid, loginUserBean);
					joRtn = UtilsFactory.getJSONSuccessReturn("Log added to Service Map.");
					DataBaseManager.commitConnection(con);
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to Add Log to Service Map.");
				}
				serviceManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn(" Adding Log to Service Map failed.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}
