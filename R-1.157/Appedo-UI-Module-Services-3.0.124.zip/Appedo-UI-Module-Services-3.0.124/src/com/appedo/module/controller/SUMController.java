package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.SUMTestBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.SUMManager;
import com.appedo.module.utils.UtilsFactory;
import com.appedo.utils.CryptManager;

/**
 * Servlet implementation class SUMController
 */
@WebServlet("/SUMController")
public class SUMController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	* @see HttpServlet#HttpServlet()
	*/
	public SUMController() {
		super();
	}

	/**
	* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	*/
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	*/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);	
	}

	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();

		if(strActionCommand.endsWith("/sum/getUserTests")) {
			LoginUserBean loginUserBean = null;

			SUMManager manager = null;

			JSONArray jaSUMTests = null;
			JSONObject joRtn = null;

			Connection con = null;

			try {
				manager = new SUMManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				// get connection 
				con = DataBaseManager.giveConnection();

				jaSUMTests = manager.getSUMTests(con, loginUserBean);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaSUMTests);

				DataBaseManager.commitConnection(con);

				loginUserBean = null;
				manager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to sum getUserTests. ");

				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/getNewUserTests")) {
				LoginUserBean loginUserBean = null;

				SUMManager manager = null;

				JSONArray jaSUMTests = null;
				JSONObject joRtn = null;

				Connection con = null;

				try {
					manager = new SUMManager();

					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

					// get connection 
					con = DataBaseManager.giveConnection();

					jaSUMTests = manager.getNewSUMTests(con, loginUserBean);

					joRtn = UtilsFactory.getJSONSuccessReturn(jaSUMTests);

					DataBaseManager.commitConnection(con);

					loginUserBean = null;
					manager = null;
				} catch (Exception e) {
					LogManager.errorLog(e);
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to sum getNewUserTests. ");

					DataBaseManager.rollbackConnection(con);
				} finally {
					DataBaseManager.close(con);
					con = null;

					response.getWriter().write(joRtn.toString());
				}
		} else if (strActionCommand.endsWith("/addSUMTest")) {
			boolean bReturn = false;
			LoginUserBean loginUserBean = null;
			SUMManager manager = null;
			SUMTestBean testBean = null;
			Connection con = null;
			String saCities = null;

			JSONArray jaCities = null;
			JSONObject joRtn = null, joLicDetails = null, joCity = null;
			HashMap<String, String> joQuicksum = null;

			try {
				manager = new SUMManager();
				testBean = new SUMTestBean();

				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				testBean.setTestName(request.getParameter("testName").trim());
				testBean.setTestType(request.getParameter("testtype"));
				if( testBean.getTestType().equals("URL") ) {
					// for URL type
					testBean.setURL( request.getParameter("url").trim() );
					testBean.setSeleniumScriptPackages("");
					testBean.setTransaction("");
				} else {
					// for TRANSACTION type
					testBean.setURL("");
					testBean.setSeleniumScriptPackages( request.getParameter("seleniumScriptPackages").trim() );
					testBean.setTransaction( request.getParameter("transaction").trim() );
				}
				testBean.setRunEveryMinute( Integer.parseInt(request.getParameter("runEveryMinutes")) );
				testBean.setStartDate(request.getParameter("startDate").trim().replace("\"", ""));
				testBean.setEndDate(request.getParameter("endDate").trim().replace("\"", ""));
				// Response monitoring status
				testBean.setStatus( Boolean.parseBoolean(request.getParameter("status")) );

				//String[] saCities = request.getParameterValues("selectedCities");
				saCities = request.getParameter("selectedCities");
				jaCities = JSONArray.fromObject(saCities);

				// MaxLocation exceeds than lt_sum_settings
				joLicDetails = manager.getLicenseSUMDetails(con, loginUserBean);

				// TODO: Thinks, for licensing getMaxTestCount & getMaxNodeCount date validation to change

				// TODO: end date must be > start date validation

				if( jaCities.size() > joLicDetails.getInt("max_location") && joLicDetails.getInt("max_location")!=-1){
					throw new Exception("1");
				}

//				int maxTestCount = manager.getMaxTestCount(con, loginUserBean);
//				if( maxTestCount >= joLicDetails.getInt("max_test") && joLicDetails.getInt("max_test")!=-1 ){
//					throw new Exception("2");	
//				}
				int maxNodeCount = manager.getMaxNodeCount(con, loginUserBean);
				if( maxNodeCount >= joLicDetails.getInt("max_measurement_per_day") && joLicDetails.getInt("max_measurement_per_day")!=-1){
					throw new Exception("3");
				}

				for( int i=0; i<jaCities.size(); i++ ){
					joCity = jaCities.getJSONObject(i);
					testBean.addTargetLocation(joCity.getString("location"));
					UtilsFactory.clearCollectionHieracy( joCity );
				}

				joRtn = manager.addSUMTest(con, testBean, loginUserBean);
				//save quick sum details
				if(request.getParameter("demo_test_email_id") != null){
					joQuicksum = new HashMap<String, String>();
					joQuicksum.put("email_id", request.getParameter("demo_test_email_id"));
					joQuicksum.put("company_name", request.getParameter("demo_test_company_name")==null?"":request.getParameter("demo_test_company_name"));
					joQuicksum.put("phone_number", request.getParameter("demo_test_phone_number")==null?"":request.getParameter("demo_test_phone_number"));
					joQuicksum.put("url", request.getParameter("url"));
					joQuicksum.put("sum_test_id", ""+joRtn.getLong("sum_test_id"));
					manager.saveQuickSUMDetails(con, joQuicksum);
					joRtn.put("sum_test_id", CryptManager.encryptEncodeURL(Long.toString(joRtn.getLong("sum_test_id"))));
					joRtn.put("HAR_FILE_PATH", Constants.APPEDO_HARFILES);
				}

				if( joRtn.getBoolean("success")){
					DataBaseManager.commitConnection(con);

					// IMP: Call the Scheduler only after the DB Commit.
					bReturn = manager.sendTestToScheduler(testBean, false);
					joRtn.put("message","SUM Test has been added."+(bReturn?"":" <br/>But unable to start the Test."));
//					joRtn = UtilsFactory.getJSONSuccessReturn("SUM Test has been added."+(bReturn?"":" <br/>But unable to start the Test."));
				}else{
					DataBaseManager.rollbackConnection(con);
				}
			} catch (Throwable e) {
				LogManager.errorLog(e);

				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else if(e.getMessage().equals("1")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max location per test should not exceed "+joLicDetails.getInt("max_location"));
				} else if(e.getMessage().equals("2")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max Test Count/Month should not exceed "+joLicDetails.getInt("max_test"));
				} else if(e.getMessage().equals("3")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max Node Count/Day should not exceed "+joLicDetails.getInt("max_measurement_per_day"));
				} else if(e.getMessage().equals("4")){
					joRtn = UtilsFactory.getJSONFailureReturn("License Expired for User. Test cannot be Added");
				} else if(e.getMessage().equals("5")){
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. Name already exist.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());
				}

				DataBaseManager.rollbackConnection(con);
			} finally {
				response.getWriter().write(joRtn.toString());

				DataBaseManager.close(con);
				con = null;

				UtilsFactory.clearCollectionHieracy( joLicDetails );
				joLicDetails = null;
				UtilsFactory.clearCollectionHieracy( joCity );
				joCity = null;
				UtilsFactory.clearCollectionHieracy( jaCities );
				jaCities = null;
				UtilsFactory.clearCollectionHieracy( joRtn );
				joRtn = null;

				UtilsFactory.clearCollectionHieracy( loginUserBean );
				loginUserBean = null;

				saCities = null;
				testBean = null;
				manager = null;
			}
		} else if (strActionCommand.endsWith("/addNewSUMTest")) {
			boolean bReturn = false;
			LoginUserBean loginUserBean = null;
			SUMManager manager = null;
			SUMTestBean testBean = null;
			Connection con = null;
			String saCities = null;

			JSONArray jaCities = null;
			JSONObject joRtn = null, joLicDetails = null, joCity = null, joEnt = null;
			HashMap<String, String> joQuicksum = null;

			try {
				manager = new SUMManager();
				testBean = new SUMTestBean();

				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				testBean.setTestName(request.getParameter("testName").trim());
				testBean.setURL(request.getParameter("url").trim());
				testBean.setRunEveryMinute( Integer.parseInt(request.getParameter("runEveryMinutes")) );
				testBean.setStartDate(request.getParameter("startDate").trim().replace("\"", ""));
				testBean.setEndDate(request.getParameter("endDate").trim().replace("\"", ""));
				testBean.setDobIds(request.getParameter("dobIds").trim());

				testBean.setStatus( Boolean.parseBoolean(request.getParameter("status").trim()) );
				testBean.setTestType(request.getParameter("testtype").trim());
				testBean.setConnectionId(Integer.parseInt(request.getParameter("connectionId")));
				testBean.setDownTimeAlert( Boolean.parseBoolean(request.getParameter("downTimeAlert")) );

				if(testBean.getTestType().equalsIgnoreCase("url")){
					testBean.setDownloadLimit(Integer.parseInt(request.getParameter("downloadLimit")));
					testBean.setUploadLimit(Integer.parseInt(request.getParameter("uploadLimit")));
					testBean.setLatencyLimit(Integer.parseInt(request.getParameter("latencyLimit")));
					testBean.setPacketLoss(Integer.parseInt(request.getParameter("packetLoss")));
					testBean.setResponseAlert( Boolean.parseBoolean(request.getParameter("responseAlert")) );

				} else {
					testBean.setSeleniumScriptPackages(request.getParameter("seleniumScriptPackages").trim());
					testBean.setTransaction(request.getParameter("transaction").trim());
					testBean.setDobIds("1");
				}

				if(testBean.isResponseAlert()){
					testBean.setSmsAlert( Boolean.parseBoolean(request.getParameter("smsAlert")) );
					testBean.setEmailAlert( Boolean.parseBoolean(request.getParameter("emailAlert")) );
					testBean.setWarningLimit( Integer.parseInt(request.getParameter("warningLimit"))*1000 );
					testBean.setErrorLimit( Integer.parseInt(request.getParameter("errorLimit"))*1000 );
					testBean.setRmMinBreachCount( Integer.parseInt(request.getParameter("rmMinBreachCount")) );
				}

				if( request.getParameter("repeatView")!=null ){
					testBean.setRepeatView(Boolean.parseBoolean(request.getParameter("repeatView")));
				}

				//Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// MaxLocation exceeds than lt_sum_settings
				joLicDetails = manager.getLicenseSUMDetails(con, loginUserBean);

	            // if Response Monitor is disabled then, 
	            // No need to fetch existing SUM-Locations
				if( testBean.isStatus() ) {
					//String[] saCities = request.getParameterValues("selectedCities");
					saCities = request.getParameter("selectedCities");
					jaCities = JSONArray.fromObject(saCities);

					// TODO: Thinks, for licensing getMaxTestCount & getMaxNodeCount date validation to change

					// TODO: end date must be > start date validation

					if( jaCities.size() > joLicDetails.getInt("max_location") && joLicDetails.getInt("max_location")!=-1){
						throw new Exception("1");
					}

					for( int i=0; i<jaCities.size(); i++ ){
						joCity = jaCities.getJSONObject(i);
						testBean.addTargetLocation(joCity.getString("location"));
						UtilsFactory.clearCollectionHieracy( joCity );
					}
				}

				// TODO RAM, this validation is not required. Confirm with Nagoji
				int maxNodeCount = manager.getMaxNodeCount(con, loginUserBean);
				if( maxNodeCount >= joLicDetails.getInt("max_measurement_per_day") && joLicDetails.getInt("max_measurement_per_day")!=-1){
					throw new Exception("3");
				}

				joRtn = manager.addNewSUMTest(con, testBean, loginUserBean, joEnt);

				//save quick sum details
				if(request.getParameter("demo_test_email_id") != null){
					joQuicksum = new HashMap<String, String>();
					joQuicksum.put("email_id", request.getParameter("demo_test_email_id"));
					joQuicksum.put("company_name", request.getParameter("demo_test_company_name")==null?"":request.getParameter("demo_test_company_name"));
					joQuicksum.put("phone_number", request.getParameter("demo_test_phone_number")==null?"":request.getParameter("demo_test_phone_number"));
					joQuicksum.put("url", request.getParameter("url"));
					joQuicksum.put("sum_test_id", ""+joRtn.getLong("sum_test_id"));
					manager.saveQuickSUMDetails(con, joQuicksum);
					joRtn.put("sum_test_id", CryptManager.encryptEncodeURL(Long.toString(joRtn.getLong("sum_test_id"))));
					joRtn.put("HAR_FILE_PATH", Constants.APPEDO_HARFILES);
				}

				if( joRtn.getBoolean("success")){
					DataBaseManager.commitConnection(con);

		            // if Response Monitor is disabled then, 
		            // No need to communicate WPT-Server.
					if( testBean.isStatus() ) {
						// IMP: Call the Scheduler only after the DB Commit.
						/**
						 * Multiple points were showing in graph , 
						 * hence commented the below in order to ignore the earlier process of sending a test to scheduler while add or edit
						 */
						//bReturn = manager.sendTestToScheduler(testBean, false);
						bReturn = true;

					} else {
						bReturn = true;
					}

					joRtn.put("message", "SUM Test has been added."+(bReturn?"":" <br/>But unable to start the Test."));
//					joRtn = UtilsFactory.getJSONSuccessReturn("SUM Test has been added."+(bReturn?"":" <br/>But unable to start the Test."));
				}else{
					DataBaseManager.rollbackConnection(con);
				}
			} catch (Throwable e) {
				LogManager.errorLog(e);

				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else if(e.getMessage().equals("1")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max location per test should not exceed "+joLicDetails.getInt("max_location"));
				} else if(e.getMessage().equals("2")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max Test Count/Month should not exceed "+joLicDetails.getInt("max_test"));
				} else if(e.getMessage().equals("3")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max Node Count/Day should not exceed "+joLicDetails.getInt("max_measurement_per_day"));
				} else if(e.getMessage().equals("4")){
					joRtn = UtilsFactory.getJSONFailureReturn("License Expired for User. Test cannot be Added");
				} else if(e.getMessage().equals("5")){
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. Name already exist.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to save.");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				response.getWriter().write(joRtn.toString());
				
				DataBaseManager.close(con);
				con = null;
				
				UtilsFactory.clearCollectionHieracy( joLicDetails );
				joLicDetails = null;
				UtilsFactory.clearCollectionHieracy( joCity );
				joCity = null;
				UtilsFactory.clearCollectionHieracy( jaCities );
				jaCities = null;
				UtilsFactory.clearCollectionHieracy( joRtn );
				joRtn = null;
				
				UtilsFactory.clearCollectionHieracy( loginUserBean );
				loginUserBean = null;
				
				saCities = null;
				testBean = null;
				manager = null;
			}
		}else if(strActionCommand.endsWith("/sum/getMaxLocation")){
			JSONObject joLicDetails = null, joRtn = null;
			LoginUserBean loginUserBean = null;
			SUMManager manager = null;
			Connection con = null;
			
			try{
				manager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// MaxLocation exceeds than lt_sum_settings
				joLicDetails = manager.getLicenseSUMDetails(con, loginUserBean);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("max_location", joLicDetails.getInt("max_location"));
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get max_locations");
			}finally{
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/isUrlExist")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			SUMManager manager = null;
			
			String strUrl = null;
			JSONObject joRtn = null, joRtnSUMURLTest = null;
			try {
				manager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				strUrl = request.getParameter("url").trim();
				
				joRtnSUMURLTest = manager.ishavingSUMURLTest(con, strUrl, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnSUMURLTest);
				
			} catch (Throwable e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to check isUrlExist. ");
			} finally {
				response.getWriter().write(joRtn.toString());
				
				DataBaseManager.close(con);
				con = null;
			}
		} else if (strActionCommand.endsWith("/updateNewSUMTest")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			SUMManager manager = null;
			SUMTestBean testBean = null;
			boolean bReturn = false;
			String saCities = null, strSchedulerURL = null;
			
			JSONArray jaCities = null;
			JSONObject joRtn = null, joLicDetails = null, joCity = null, joEnt = null;
			long user_id = -1L;
			
			try {
				manager = new SUMManager();
				testBean = new SUMTestBean();
				
				con = DataBaseManager.giveConnection();
				
				strSchedulerURL = Constants.APPEDO_WPT_SCHEDULER;
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				////Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				testBean.setTestId(Long.parseLong(request.getParameter("testid").trim()));
				testBean.setTestName(request.getParameter("testName").trim());
				testBean.setURL(request.getParameter("url").trim());
				testBean.setRunEveryMinute( Integer.parseInt(request.getParameter("runEveryMinutes")) );
				testBean.setStartDate(request.getParameter("startDate").trim().replace("\"", ""));
				testBean.setEndDate(request.getParameter("endDate").trim().replace("\"", ""));
				testBean.setStatus(Boolean.parseBoolean(request.getParameter("status").trim()));
				testBean.setTestType(request.getParameter("testtype").trim());
				testBean.setDobIds(request.getParameter("dobIds").trim());
				testBean.setConnectionId(Integer.parseInt(request.getParameter("connectionId")));
				testBean.setDownTimeAlert( Boolean.parseBoolean(request.getParameter("downTimeAlert")) );
				
				if(testBean.getTestType().equalsIgnoreCase("url")){
					testBean.setDownloadLimit(Integer.parseInt(request.getParameter("downloadLimit")));
					testBean.setUploadLimit(Integer.parseInt(request.getParameter("uploadLimit")));
					testBean.setLatencyLimit(Integer.parseInt(request.getParameter("latencyLimit")));
					testBean.setPacketLoss(Integer.parseInt(request.getParameter("packetLoss")));
					testBean.setResponseAlert( Boolean.parseBoolean(request.getParameter("responseAlert")) );
				} else {
					testBean.setSeleniumScriptPackages(request.getParameter("seleniumScriptPackages").trim());
					testBean.setTransaction(request.getParameter("transaction").trim());
					testBean.setDobIds("1");
				}
				
				if(testBean.isResponseAlert()){
					testBean.setSmsAlert( Boolean.parseBoolean(request.getParameter("smsAlert")) );
					testBean.setEmailAlert( Boolean.parseBoolean(request.getParameter("emailAlert")) );
					testBean.setWarningLimit( Integer.parseInt(request.getParameter("warningLimit"))*1000 );
					testBean.setErrorLimit( Integer.parseInt(request.getParameter("errorLimit"))*1000 );
					testBean.setRmMinBreachCount( Integer.parseInt(request.getParameter("rmMinBreachCount")) );
				}
				
				if( request.getParameter("repeatView")!=null ){
					testBean.setRepeatView(Boolean.parseBoolean(request.getParameter("repeatView")));
				}
				
				if( request.getParameter("isStartDateChanged")!= null ){
					testBean.setChangedStDate(Boolean.parseBoolean(request.getParameter("isStartDateChanged")));
				}
				
	            // if Response Monitor is disabled then, 
	            // No need to fetch existing SUM-Locations
				if( testBean.isStatus() ) {
					saCities = request.getParameter("selectedCities");
					jaCities = JSONArray.fromObject(saCities);
					
					// If MaxLocation exceeds than lt_sum_settings 
					joLicDetails = manager.getLicenseSUMDetails(con, loginUserBean);
					if( jaCities.size() > joLicDetails.getInt("max_location") && joLicDetails.getInt("max_location")!=-1){
						throw new Exception("1");
					}
					
	//				int maxNodeCount = manager.getMaxNodeCount(con, loginUserBean);
	//				if( maxNodeCount >= joLicDetails.getInt("max_measurement_per_day") && joLicDetails.getInt("max_measurement_per_day")!=-1){
	//					throw new Exception("3");	
	//				}
					
					for( int i=0; i < jaCities.size(); i++ ){
						joCity = jaCities.getJSONObject(i);
						testBean.addTargetLocation(joCity.getString("location"));
						UtilsFactory.clearCollectionHieracy( joCity );
					}
				}
				
				joRtn = manager.updateNewSUMTest(con, testBean, loginUserBean, strSchedulerURL, request, joEnt);
				
				if( joRtn.getBoolean("success")){
					DataBaseManager.commitConnection(con);
					
					// IMP: Call the Scheduler only after the DB Commit.
					/**
					 * Multiple points were showing in graph , 
					 * hence commented the below in order to ignore the earlier process of sending a test to scheduler while add or edit/update
					 */
					//bReturn = manager.sendTestToScheduler(testBean, false);
					bReturn =true;
					
					joRtn = UtilsFactory.getJSONSuccessReturn("SUM Test has been updated successfully."+(bReturn?"":" <br/>Scheduler could't restart Test."));
				}else{
					DataBaseManager.rollbackConnection(con);
				}
				
				
			} catch (Throwable e) {
				LogManager.errorLog(e);

				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else if(e.getMessage().equals("1")){
					joRtn = UtilsFactory.getJSONFailureReturn("Location(s) exceeds limit of "+joLicDetails.getInt("max_location"));
				} else if(e.getMessage().equals("3")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max Node Count/Day should not exceed "+joLicDetails.getInt("max_measurement_per_day"));
				} else if(e.getMessage().equals("4")){
					joRtn = UtilsFactory.getJSONFailureReturn("License Expired for User. Test cannot be Added");
				} else if(e.getMessage().equals("5")){
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. Name already exist.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update.");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				response.getWriter().write(joRtn.toString());
				
				DataBaseManager.close(con);
				con = null;
				
				UtilsFactory.clearCollectionHieracy( joRtn );
				joRtn = null;
				UtilsFactory.clearCollectionHieracy( joLicDetails );
				joLicDetails = null;
				UtilsFactory.clearCollectionHieracy( joCity );
				joCity = null;
				UtilsFactory.clearCollectionHieracy( jaCities );
				jaCities = null;
				UtilsFactory.clearCollectionHieracy( loginUserBean );
				loginUserBean = null;
				
				saCities = null;
				strSchedulerURL = null;
				testBean = null;
				manager = null;
			}
		} else if (strActionCommand.endsWith("/updateSUMTest")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			SUMManager manager = null;
			SUMTestBean testBean = null;
			boolean bReturn = false;
			String saCities = null, strSchedulerURL = null;
			
			JSONArray jaCities = null;
			JSONObject joRtn = null, joLicDetails = null, joCity = null;
			
			try {
				manager = new SUMManager();
				testBean = new SUMTestBean();
				
				con = DataBaseManager.giveConnection();
				
				strSchedulerURL = Constants.APPEDO_WPT_SCHEDULER;
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				testBean.setTestId(Long.parseLong(request.getParameter("testid").trim()));
				testBean.setTestName(request.getParameter("testName").trim());
				testBean.setTestType(request.getParameter("testtype"));
				if( testBean.getTestType().equals("URL") ) {
					// for URL type
					testBean.setURL( request.getParameter("url").trim() );
					testBean.setSeleniumScriptPackages("");
					testBean.setTransaction("");
				} else {
					// for TRANSACTION type
					testBean.setURL("");
					testBean.setSeleniumScriptPackages( request.getParameter("seleniumScriptPackages").trim() );
					testBean.setTransaction( request.getParameter("transaction").trim() );
				}
				testBean.setRunEveryMinute( Integer.parseInt(request.getParameter("runEveryMinutes")) );
				testBean.setStartDate(request.getParameter("startDate").trim().replace("\"", ""));
				testBean.setEndDate(request.getParameter("endDate").trim().replace("\"", ""));
				testBean.setStatus(Boolean.parseBoolean(request.getParameter("status")));
				
				saCities = request.getParameter("selectedCities");
				jaCities = JSONArray.fromObject(saCities);
				
				// If MaxLocation exceeds than lt_sum_settings 
				joLicDetails = manager.getLicenseSUMDetails(con, loginUserBean);
				if( jaCities.size() > joLicDetails.getInt("max_location") && joLicDetails.getInt("max_location")!=-1){
					throw new Exception("1");
				}
				
				int maxNodeCount = manager.getMaxNodeCount(con, loginUserBean);
				if( maxNodeCount >= joLicDetails.getInt("max_measurement_per_day") && joLicDetails.getInt("max_measurement_per_day")!=-1){
					throw new Exception("3");	
				}
				
				for( int i=0; i<jaCities.size(); i++ ){
					joCity = jaCities.getJSONObject(i);
					testBean.addTargetLocation(joCity.getString("location"));
					UtilsFactory.clearCollectionHieracy( joCity );
				}
				joRtn = manager.updateSUMTest(con, testBean, loginUserBean, strSchedulerURL);
				if( joRtn.getBoolean("success")){
					DataBaseManager.commitConnection(con);
					
					// IMP: Call the Scheduler only after the DB Commit.
					bReturn = manager.sendTestToScheduler(testBean, false);
					
					joRtn = UtilsFactory.getJSONSuccessReturn("SUM Test has been updated successfully."+(bReturn?"":" <br/>Scheduler could't restart Test."));
				}else{
					DataBaseManager.rollbackConnection(con);
				}
				
				
			} catch (Throwable e) {
				LogManager.errorLog(e);

				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else if(e.getMessage().equals("1")){
					joRtn = UtilsFactory.getJSONFailureReturn("Location(s) exceeds limit of "+joLicDetails.getInt("max_location"));
				} else if(e.getMessage().equals("3")){
					joRtn = UtilsFactory.getJSONFailureReturn("Max Node Count/Day should not exceed "+joLicDetails.getInt("max_measurement_per_day"));
				} else if(e.getMessage().equals("4")){
					joRtn = UtilsFactory.getJSONFailureReturn("License Expired for User. Test cannot be Added");
				} else if(e.getMessage().equals("5")){
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. Name already exist.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update.");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				response.getWriter().write(joRtn.toString());
				
				DataBaseManager.close(con);
				con = null;
				
				UtilsFactory.clearCollectionHieracy( joRtn );
				joRtn = null;
				UtilsFactory.clearCollectionHieracy( joLicDetails );
				joLicDetails = null;
				UtilsFactory.clearCollectionHieracy( joCity );
				joCity = null;
				UtilsFactory.clearCollectionHieracy( jaCities );
				jaCities = null;
				UtilsFactory.clearCollectionHieracy( loginUserBean );
				loginUserBean = null;
				
				saCities = null;
				strSchedulerURL = null;
				testBean = null;
				manager = null;
			}
		}
		else if (strActionCommand.endsWith("/deleteSUMTest")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			SUMManager manager = null;
			SUMTestBean testBean = null;
			JSONObject joRtn = null;
			boolean bReturn = false;
			
			try {
				manager = new SUMManager();
				testBean = new SUMTestBean();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				testBean.setTestId(Long.parseLong(request.getParameter("testid").trim()));
				
				testBean.setTestType(String.valueOf(request.getParameter("testtype").trim()));
				
				testBean.setStatus(Boolean.valueOf(String.valueOf(request.getParameter("status"))));
				
				manager.deleteSUMTest(con, testBean, loginUserBean, "",request);
				
				DataBaseManager.commitConnection(con);
				
				// Delete HAR files form HAR Repo
				manager.deleteHarRepo(request.getParameter("testid").trim());
				
				// IMP: Call the Scheduler only after the DB Commit.
				bReturn =true;// manager.sendTestToScheduler(testBean, true);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("SUM Test has been deleted successfully."+(bReturn?"":" <br/>Scheduler could't stop Test."));
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update.");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				response.getWriter().write(joRtn.toString());
				
				DataBaseManager.close(con);
				con = null;
				
				loginUserBean = null;
				manager = null;
				
			}
		} else if (strActionCommand.endsWith("/sum/getUserNodes")) {
			LoginUserBean loginUserBean = null;
			SUMManager sumManager = null;
			JSONArray jaData = new JSONArray();
			Connection con = null;
			
			try {
				sumManager = new SUMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				
				jaData = sumManager.getUserCountries(con);
				
				DataBaseManager.commitConnection(con);
				
				sumManager = null;
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jaData.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMNodes")) {
			// gets available SUM nodes, private node configured by a user also retrived
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			SUMManager sumManager = null;
			
			JSONArray jaRtnNodes = null;
			JSONObject joRtn = null;
			
			try {
				sumManager = new SUMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lTestId = Long.parseLong( UtilsFactory.replaceNull(request.getParameter("testid"), "-1") );
				String dobIds = request.getParameter("dobIds");
				
				con = DataBaseManager.giveConnection();
				
				// 
				jaRtnNodes = sumManager.getSUMNodes(con, lTestId, loginUserBean.getUserId(), dobIds);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnNodes);
				
				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMNodes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/getUserCities")) {
			
			String strCountry = request.getParameter("country");
			SUMManager sumManager = null;
			JSONArray jaData = new JSONArray();
			Connection con = null;
			
			try {
				sumManager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				jaData = sumManager.getUserCities(con, strCountry);
				
				DataBaseManager.commitConnection(con);
				
				strCountry = null;
				sumManager = null;
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				DataBaseManager.rollbackConnection(con);
				
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jaData.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getPackages")) {
			JSONObject joRtn = null;

			try {
				joRtn = new JSONObject();
				joRtn.put("success", true);
				joRtn.put("failure", false);
				joRtn.put("packages", Constants.SELENIUM_SCRIPT_PACKAGES);
				joRtn.put("script", Constants.SELENIUM_SCRIPT);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get transaction packages. ");

			} finally {
				LogManager.infoLog("getPackages "+joRtn.toString());
				response.getWriter().write(joRtn.toString());
			}

		} else if (strActionCommand.endsWith("/sum/getSUMMultiDropDown")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			JSONArray json = new JSONArray();
			SUMManager sumManager = null;
			
			try {
				sumManager = new SUMManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				
				json = sumManager.getSUMMultiDropDown(con, loginUserBean.getUserId());
				
				DataBaseManager.commitConnection(con);
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				if (e.getMessage().equals("SESSION_EXPIRED")) {
					throw new ServletException("SESSION_EXPIRED");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(json.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMMultiLine")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			//JSONArray json = new JSONArray();
			JSONObject joRtn = null, joRtnChartDataResult = null;
			
			SUMManager sumManager = null;
			
			String strInterval = null, strTestId = null, strPageId = null, strPageName = null;
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				sumManager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strInterval = request.getParameter("interval");
				strTestId = request.getParameter("testId");
				strPageId = UtilsFactory.replaceNull(request.getParameter("pageId"), "");
				strPageName = UtilsFactory.replaceNull(request.getParameter("pageName"), "");
				if ( strInterval != null ) {
					// slider
					lStartDateTimeInMills = null;
					lEndDateTimeInMills = null;
				} else {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				
				// gets test's chart data & breached limit
				joRtnChartDataResult = sumManager.getSUMMultiLine(con, strTestId, strPageId, strPageName, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnChartDataResult.getJSONArray("chartData"));
				joRtn.put("testId", strTestId);
				joRtn.put("sla_threshold_limits", joRtnChartDataResult.getJSONObject("sla_threshold_limits"));
				
				strInterval = null;
				strTestId = null;
				strPageId = null;
				strPageName = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				
				loginUserBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMMultiLine_v1")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			//JSONArray json = new JSONArray();
			JSONObject joRtn = null, joRtnChartDataResult = null, joEnt = null;
			
			SUMManager sumManager = null;
			
			String strInterval = null, strTestId = null, strPageId = null, strPageName = null, strLocation = null;
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null, lMetricId = null, lTestId = null, lUserId=null;
			
			try {
				sumManager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				strInterval = request.getParameter("interval");
				lTestId = Long.parseLong(request.getParameter("testId"));
				strPageId = UtilsFactory.replaceNull(request.getParameter("pageId"), "");
				strPageName = UtilsFactory.replaceNull(request.getParameter("pageName"), "");
				lMetricId= Long.parseLong(request.getParameter("metricId"));
				strLocation = request.getParameter("location");
				
				if(joEnt.getLong("e_id") != 0){
					lUserId = joEnt.getLong("e_user_id");
				}else {
					lUserId = loginUserBean.getUserId();
				}
				
				if ( strInterval != null ) {
					// slider
					lStartDateTimeInMills = null;
					lEndDateTimeInMills = null;
				} else {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				
				// gets test's chart data & breached limit
				joRtnChartDataResult = sumManager.getSUMChartData_v1(con, lTestId, strPageId, strPageName, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, lUserId, lMetricId, strLocation);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnChartDataResult);
				
				strInterval = null;
				strTestId = null;
				strPageId = null;
				strPageName = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
			} catch (Exception e) {
				if (e.getMessage().equals("1")) {
					LogManager.errorLog("Metric/Chart ID passed as null");
				} else {
					LogManager.errorLog(e);
				}
				joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				
				loginUserBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMMultiLineWithLocationBrowserConnection")) {
			Connection con = null;
			//JSONArray json = new JSONArray();
			JSONObject jsonChild = new JSONObject();
			JSONArray[] jaScreens = null;
			SUMManager sumManager = null;
			String strInterval = null, strTestId = null, strPageId = null, strPageName = null, strLocation, strStartDate, strEndDate;;
			LoginUserBean loginUserBean = null;
			
			try {
				sumManager = new SUMManager();
				
				strLocation = request.getParameter("location");
				strInterval = request.getParameter("interval");
				strStartDate = request.getParameter("startDate");
				strEndDate = request.getParameter("endDate");
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strInterval = request.getParameter("interval");
				strTestId = request.getParameter("testId");
				strPageId = UtilsFactory.replaceNull(request.getParameter("pageId"), "");
				strPageName = UtilsFactory.replaceNull(request.getParameter("pageName"), "");
				
				jsonChild = UtilsFactory.getJSONSuccessReturn(sumManager.getSUMMultiLineWithLocationBrowserConnection(con, strTestId, strPageId, strPageName, strInterval));
				
				// Commented below, since the availability is excluded from `SUM`. 
				// jaScreens = sumManager.getSUMTestUnavailability(con, loginUserBean, strTestId, strInterval, strStartDate, strEndDate);
				
				jsonChild.put("successResults", new JSONArray());
				jsonChild.put("failureResults", new JSONArray());
				jsonChild.put("testId", strTestId);
				
				strInterval = null;
				strTestId = null;
				strPageId = null;
				strPageName = null;
			} catch (Throwable e) {
				LogManager.errorLog(e);
				jsonChild = UtilsFactory.getJSONFailureReturn(e.getMessage());
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jsonChild.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMMultiLineWithDateRange")) {
			Connection con = null;
			JSONObject jsonChild = new JSONObject();
			SUMManager sumManager = null;
			String strStartDate = null,strEndDate = null, strTestId = null, strPageId = null, strPageName = null;
			JSONArray[] jaScreens = null;
			LoginUserBean loginUserBean = null;
			
			try {
				sumManager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strStartDate = request.getParameter("startDate");
				strEndDate = request.getParameter("endDate");
				strTestId = request.getParameter("testId");
				strPageId = UtilsFactory.replaceNull(request.getParameter("pageId"), "");
				strPageName = UtilsFactory.replaceNull(request.getParameter("pageName"), "");
				
				jsonChild = UtilsFactory.getJSONSuccessReturn(sumManager.getSUMMultiLineWithDateRange(con, strTestId, strPageId, strPageName, strStartDate, strEndDate));
				
				// Commented below, since the availability is excluded from `SUM`. 
				// jaScreens = sumManager.getSUMTestUnavailability(con, loginUserBean, strTestId, null, strStartDate, strEndDate);
						
				jsonChild.put("successResults", new JSONArray());
				jsonChild.put("failureResults", new JSONArray());
				
				strStartDate = null;
				strEndDate = null;
				strTestId = null;
				strPageId = null;
				strPageName = null;
			} catch (Throwable e) {
				LogManager.errorLog(e);
				jsonChild = UtilsFactory.getJSONFailureReturn(e.getMessage());
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jsonChild.toString());
			}
		} else if (strActionCommand.endsWith("/sum/isHavingChartPoint")) {
			Connection con = null;
			JSONObject joRtn = new JSONObject();
			SUMManager sumManager = null;
			String strTestId = null;
			boolean bExist = false;
			try {
				sumManager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				
				strTestId = request.getParameter("testId");
				
				bExist = sumManager.isResultAvailable(con, strTestId);
				
				joRtn.put("success", true);
				joRtn.put("failure", false);
				joRtn.put("message", bExist);
				
				strTestId = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMLicense")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			JSONArray json = new JSONArray();
			SUMManager sumManager = null;
			
			try {
				sumManager = new SUMManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				json = sumManager.getSumLicense(con, loginUserBean.getUserId());
				
				DataBaseManager.commitConnection(con);
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				if (e.getMessage().equals("SESSION_EXPIRED")) {
					throw new ServletException("SESSION_EXPIRED");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(json.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMSummary")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			JSONArray json = new JSONArray();
			SUMManager sumManager = null;
			String strModuleCode = null;
			JSONObject joRtn = null;
			
			try {
				sumManager = new SUMManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				strModuleCode = request.getParameter("moduleCode");
				
				json = sumManager.getSumSummary(con, loginUserBean.getUserId(),strModuleCode);
				joRtn = UtilsFactory.getJSONSuccessReturn(json);
				
				DataBaseManager.commitConnection(con);
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());
				if (e.getMessage().equals("SESSION_EXPIRED")) {
					throw new ServletException("SESSION_EXPIRED");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMWorldMap")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			JSONArray json = new JSONArray();
			SUMManager sumManager = null;
			JSONObject joRtn = null;
			
			try {
				sumManager = new SUMManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				
				json = sumManager.getSUMWorldMap(con, loginUserBean.getUserId());
				joRtn = UtilsFactory.getJSONSuccessReturn(json);
				
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());
				if (e.getMessage().equals("SESSION_EXPIRED")) {
					throw new ServletException("SESSION_EXPIRED");
				}
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMDetailsDropDown")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			
			JSONObject joRtn = null, joEnt = null;
			JSONArray jaRtnSUMTests = null;
			
			SUMManager sumManager = null;
			
			try {
				sumManager = new SUMManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				jaRtnSUMTests = sumManager.getSUMDetailsDropDown(con, loginUserBean.getUserId(), joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnSUMTests);
				
				DataBaseManager.commitConnection(con);
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get SUM test(s).");
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getLicenseSUMDetails")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			JSONObject jsonChild = new JSONObject();
			SUMManager sumManager = null;
			try {
				sumManager = new SUMManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				jsonChild.put("success", true);
				jsonChild.put("failure", false);
				jsonChild.put("message", sumManager.getLicenseSUMDetails(con, loginUserBean));
			} catch (Exception e) {
				LogManager.errorLog(e);
				jsonChild.put("success", false);
				jsonChild.put("failure", true);
				jsonChild.put("message", e.getMessage());
				if (e.getMessage().equals("SESSION_EXPIRED")) {
					throw new ServletException("SESSION_EXPIRED");
				}
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jsonChild.toString());
			}
		} else if (strActionCommand.endsWith("/sum/checkVaildHarURL")) {
			JSONObject jsonChild = new JSONObject();
			String harUrl=null;
			SUMManager sumManager = null;

			try {
				harUrl = request.getParameter("harUrl");
				sumManager = new SUMManager();
				int respCode = sumManager.getResponseCode( harUrl);
				if(respCode<399){
					jsonChild.put("success", true);
					jsonChild.put("failure", false);
					jsonChild.put("message", "URL is Up");
				}else{
					jsonChild.put("success", false);
					jsonChild.put("failure", true);
					jsonChild.put("message", "URL is down");
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				jsonChild.put("success", false);
				jsonChild.put("failure", true);
				jsonChild.put("message", e.getMessage());
				if (e.getMessage().equals("SESSION_EXPIRED")) {
					throw new ServletException("SESSION_EXPIRED");
				}
			} finally {
				sumManager = null;
				response.getWriter().write(jsonChild.toString());
			}
/*		} else if (strActionCommand.endsWith("/sum/getSUMPageMultiLine")) {
			LoginUserBean loginUserBean = null;
			Connection con = null;
			//JSONArray json = new JSONArray();
			JSONObject jsonChild = new JSONObject();
			SUMManager sumManager = null;
			String interval = null;
			String testId = null;
			String pageId = null;
			
			try {
				sumManager = new SUMManager();
				con = DataBaseManager.giveConnection();
				interval = request.getParameter("interval");
				testId = request.getParameter("testId");
				pageId = request.getParameter("pageId");
				
				jsonChild.put("success", true);
				jsonChild.put("failure", false);
				jsonChild.put("message", sumManager.getSUMPageMultiLine(con, testId, pageId, interval));
			} catch (Exception e) {
				LogManager.errorLog(e);
				jsonChild.put("success", false);
				jsonChild.put("failure", true);
				jsonChild.put("message", e.getMessage());
				if (e.getMessage().equals("SESSION_EXPIRED")) {
					throw new ServletException("SESSION_EXPIRED");
				}
			} finally {
				sumManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jsonChild.toString());
			}
*/		}else if(strActionCommand.endsWith("/sum/validateSUMTestName")) {
			// gets rules which were mapped
			JSONObject joRtn = null;
			SUMManager sumManager = null;
			LoginUserBean loginBean = null;
			SUMTestBean sumBean = null;
			boolean bexist = false;
			Connection con = null; 
			
			try {
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				sumBean = new SUMTestBean();
				sumBean.setTestName(request.getParameter("testName"));
				sumBean.setTestId(Long.parseLong(UtilsFactory.replaceNullBlank(request.getParameter("testId"), "-1")));
				sumManager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				
				bexist = sumManager.validateSUMTestName(con, sumBean, loginBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("isvalid", bexist);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get status. ");
				
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMTestsResults")) {
			// thinks, gets SUM tests which has HAR results
			SUMManager manager = null;
			JSONArray jaSUMTests = null;
			JSONObject joRtn = null;

			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			try {
				manager = new SUMManager();

				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// 
				jaSUMTests = manager.getSUMTestsResults(con, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaSUMTests);
				
				loginUserBean = null;
				manager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMTestsResults. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMTestPages")) {
			//
			SUMManager manager = null;
			JSONArray jaSUMTestPages = null;
			JSONObject joRtn = null;
			
			Connection con = null;
			
			try {
				manager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				
				long lTestId = Long.parseLong(request.getParameter("testId"));
				
				//
				jaSUMTestPages = manager.getSUMTestPages(con, lTestId);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaSUMTestPages);
				joRtn.put("testId", lTestId);
				
				manager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMTestPages. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getQuickSUMNodes")) {
			// gets available SUM nodes, private node configured by a user also retrived
			Connection con = null;
			LoginUserBean loginUserBean = null;

			SUMManager sumManager = null;

			JSONArray jaRtnNodes = null;
			JSONObject joRtn = null;

			try {
				sumManager = new SUMManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));

				// long lTestId = Long.parseLong(
				// UtilsFactory.replaceNull(request.getParameter("testid"), "-1") );
				String deviceType = request.getParameter("device_type");

				con = DataBaseManager.giveConnection();

				//
				jaRtnNodes = sumManager.getQuickSUMNodes(con, deviceType);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnNodes);

				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMNodes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMTestDetails")) {
			// gets SUM test id based encrypted SUM test_id
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			SUMManager sumManager = null;
			
			JSONObject joRtn = null, joRtnSUMTestDetails = null;
			
			try {
				sumManager = new SUMManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lSUMTestId = Long.parseLong( CryptManager.decodeDecryptURL(request.getParameter("encryptSUMTestId")) );
				
				joRtnSUMTestDetails = sumManager.getSUMTestDetails(con, lSUMTestId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnSUMTestDetails);
						
				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMTestDetails. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMConnectivity")) {
			Connection con = null;
			SUMManager sumManager = null;
			String jsonString = null;
			JSONObject jaRtnConnectivity = null;
			JSONObject joRtn = null;
			try {
				sumManager = new SUMManager();
				jaRtnConnectivity = new JSONObject();
				con = DataBaseManager.giveConnection();

				jsonString = sumManager.getSUMConnectivity(con);
				if(jsonString !=null){
					jaRtnConnectivity.put("connectivity", jsonString);
				}else{
					jaRtnConnectivity.put("connectivity", "[]");
				}
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnConnectivity);
				joRtn.put("sumDownloadLimit", Constants.SUM_DOWNLOAD_LIMIT);
				joRtn.put("sumUploadLimit", Constants.SUM_UPLOAD_LIMIT);
				joRtn.put("sumLatencyLimit", Constants.SUM_LATENCY_LIMIT);
				joRtn.put("sumPacketLossLimit", Constants.SUM_PACKET_LOSS_LIMIT);
				joRtn.put("sumWarningLimit", Constants.SUM_WARNING_LIMIT);
				joRtn.put("sumErrorLimit", Constants.SUM_ERROR_LIMIT);
				joRtn.put("sumDefaultWarningLimit", Constants.SUM_DEFAULT_WARNING_LIMIT);
				joRtn.put("sumDefaultErrorLimit", Constants.SUM_DEFAULT_ERROR_LIMIT);
				joRtn.put("sumDefaultMinBreachCount", Constants.SUM_DEFAULT_MIN_BREACH_COUNT);
				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMConnectivity. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMDeviceTypes")) {
			Connection con = null;
			SUMManager sumManager = null;
			String jsonString = null;
			JSONObject jaRtnDeviceTypes = null;
			JSONObject joRtn = null;
			try {
				sumManager = new SUMManager();
				jaRtnDeviceTypes = new JSONObject();
				con = DataBaseManager.giveConnection();

				jsonString = sumManager.getSUMDeviceTypes(con);
				if(jsonString !=null){
					jaRtnDeviceTypes.put("deviceTypes", jsonString);
				}else{
					jaRtnDeviceTypes.put("deviceTypes", "[]");
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceTypes);

				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMDeviceTypes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMOsNames")) {
			Connection con = null;
			SUMManager sumManager = null;
			String jsonString = null;
			JSONObject jaRtnOsNames = null;
			JSONObject joRtn = null;
			try {
				sumManager = new SUMManager();
				jaRtnOsNames = new JSONObject();
				con = DataBaseManager.giveConnection();
				String deviceType = request.getParameter("device_type");
				jsonString = sumManager.getSUMOsNames(con, deviceType);
				if(jsonString !=null){
					jaRtnOsNames.put("osNames", jsonString);
				}else{
					jaRtnOsNames.put("osNames", "[]");
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnOsNames);

				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMOsNames. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSUMBrowserNames")) {
			Connection con = null;
			SUMManager sumManager = null;
			String jsonString = null;
			JSONObject jaRtnBrowserNames = null;
			JSONObject joRtn = null;
			try {
				sumManager = new SUMManager();
				jaRtnBrowserNames = new JSONObject();
				con = DataBaseManager.giveConnection();
				String deviceType = request.getParameter("device_type");
				String osName = request.getParameter("os_name");
				jsonString = sumManager.getSUMBrowserNames(con, deviceType, osName);
				if(jsonString !=null){
					jaRtnBrowserNames.put("browserNames", jsonString);
				}else{
					jaRtnBrowserNames.put("browserNames", "[]");
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBrowserNames);
				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSUMBrowserNames. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getSumAvgPageLoadTimeDonutCount")) {
			// gets SUM test id based encrypted SUM test_id
			Connection con = null;
			LoginUserBean loginUserBean = null;
			String donutCount = null;
			SUMManager sumManager = null;
			
			JSONObject joRtn = null;
			
			try {
				sumManager = new SUMManager();

				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				String interval = request.getParameter("interval")==null?"1 day":request.getParameter("interval");

				donutCount = sumManager.getSumAvgPageLoadTimeDonutCount(con, loginUserBean,interval);
				if(donutCount!=null){
					joRtn = UtilsFactory.getJSONSuccessReturn(donutCount);

				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSumAvgPageLoadTimeDonutCount. ");

				}
				
				loginUserBean = null;
				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getSumAvgPageLoadTimeDonutCount. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sum/getFirstByte")){
			Connection con = null;
			JSONArray jaFirstByte = null;
			SUMManager sumManager = null;
			
			JSONObject jaRtn = null;
			
			try {
				sumManager = new SUMManager();

				con = DataBaseManager.giveConnection();
				long lharId = Long.parseLong(request.getParameter("har_Id"));
			//	String harFileName =filePath.substring(filePath.lastIndexOf("/")).replaceAll("/", "");

				jaFirstByte = sumManager.getFirstByte(con, lharId);
				
				//if((jaFirstByte!=null)&&(jaFirstByte.getString(0).contains("loadTime"))){
				if((jaFirstByte!=null)&&(jaFirstByte.getJSONObject(0).containsValue("FirstView"))){
					jaRtn = UtilsFactory.getJSONSuccessReturn(jaFirstByte);

				}else{
					jaRtn = UtilsFactory.getJSONFailureReturn("Unable to getFirstByte. ");

				}
				
				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				jaRtn = UtilsFactory.getJSONFailureReturn("Unable to getFirstByte. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jaRtn.toString());
			}
		}
		else if (strActionCommand.endsWith("/sum/fetchScreen")){
			Connection con = null;
			JSONObject jaScreens = null;
			SUMManager sumManager = null;
			JSONObject jaRtn = null;
			try {
				sumManager = new SUMManager();
				con = DataBaseManager.giveConnection();
				long lharId = Long.parseLong(request.getParameter("har_Id"));	
				jaScreens = sumManager.fetchScreen(con, lharId);

				jaRtn = UtilsFactory.getJSONSuccessReturn(jaScreens);
				sumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				jaRtn = UtilsFactory.getJSONFailureReturn("Unable to getFirstByte. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jaRtn.toString());
			}
		}
		// Get the Unavailability History for the given Test-Id
		else if (strActionCommand.endsWith("/sum/getSUMTestUnavailability")){
			Connection con = null;
			JSONObject joRtn = null;
			JSONArray[] jaScreens = null;
			SUMManager sumManager = null;
			LoginUserBean loginUserBean = null;
			// As the below parameters are gng to be used in StringBuilder, they are not parsed into Long
			String strTestId, strLocation, strInterval, strStartDate, strEndDate;
			
			try {
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strTestId = request.getParameter("testId");
				strLocation = request.getParameter("location");
				strInterval = request.getParameter("interval");
				strStartDate = request.getParameter("startDate");
				strEndDate = request.getParameter("endDate");
				
				sumManager = new SUMManager();
				
				jaScreens = sumManager.getSUMTestUnavailability(con, loginUserBean, strTestId, strInterval, strStartDate, strEndDate);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaScreens);
			} catch (Throwable th) {
				LogManager.errorLog(th);
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get unavailablity records.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}
