package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.Set;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/*import com.appedo.avm.bean.AVMAgentAlertAddressBean;
import com.appedo.avm.bean.AVMAgentBean;
import com.appedo.avm.bean.AVMTestBean;
import com.appedo.avm.connect.DataBaseManager;
import com.appedo.avm.model.AVMManager;
import com.appedo.avm.model.CryptManager;
import com.appedo.avm.utils.UtilsFactory;*/
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.AVMAgentAlertAddressBean;
import com.appedo.module.bean.AVMAgentBean;
import com.appedo.module.bean.AVMTestBean;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.AVMManager;
import com.appedo.module.model.CryptManager;
import com.appedo.module.utils.UtilsFactory;

/**
 * Servlet implementation class AMController
 */
@WebServlet("/AVMController")
public class AVMController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	* @see HttpServlet#HttpServlet()
	*/
	public AVMController() {
		super();
	}

	/**
	* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	*/
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	*/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);	
	}

	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();
		
		Connection con = null;
		AVMManager avmManager = null;
		LoginUserBean loginUserBean = null;
		
		
		if (strActionCommand.endsWith("/avm/getAVMUserTests")) {
			JSONArray jaAVMTests = null;
			JSONObject joRtn = null;
			JSONObject joEnt = null;
			try {
				avmManager = new AVMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));

				// get connection
				con = DataBaseManager.giveConnection();
				
				//Enterprise License Details
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				

				jaAVMTests = avmManager.getAVMTests(con, loginUserBean, joEnt);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaAVMTests);

				DataBaseManager.commitConnection(con);


			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get AVM Tests. ");

				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				avmManager = null;
				loginUserBean = null;

				response.getWriter().write(joRtn.toString());
				
			}
		} else if (strActionCommand.endsWith("/avm/getEditAVMUserTests")) {
			//JSONArray jaAVMTests = null;
			JSONObject jaAVMTests = null;
			JSONObject joRtn = null;
			AVMTestBean testBean= null;
			
			try {
				avmManager = new AVMManager();
				testBean = new AVMTestBean();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				testBean.setTestId(Long.parseLong(UtilsFactory.replaceNullBlank(request.getParameter("testId"), "-1")));

				// get connection
				con = DataBaseManager.giveConnection();

				jaAVMTests = avmManager.getEditAVMTests(con, loginUserBean, testBean);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaAVMTests);

				DataBaseManager.commitConnection(con);


			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get AVM Tests. ");

				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				avmManager = null;
				loginUserBean = null;

				response.getWriter().write(joRtn.toString());
				
			}
		}else if (strActionCommand.endsWith("/avm/getAVMAgents")) {
			// gets available heart-beat agents, private node configured by a user also retrieved
			
			JSONArray jaRtnNodes = null;
			JSONObject joRtn = null, joEnt =null;
			
			try {
				avmManager = new AVMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lTestId = Long.parseLong( UtilsFactory.replaceNull(request.getParameter("testid"), "-1") );
				
				con = DataBaseManager.giveConnection();
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				jaRtnNodes = avmManager.getAVMAgents(con, lTestId, loginUserBean.getUserId(), joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnNodes);
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get heart beat agents details. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				avmManager = null;
				loginUserBean = null;
				response.getWriter().write(joRtn.toString());
			}
		
		} else if(strActionCommand.endsWith("/avm/validateAVMTestName")) {
			JSONObject joRtn = null;
			LoginUserBean loginBean = null;
			AVMTestBean testBean = null;
			boolean bexist = false;
			
			try {
				loginBean = new LoginUserBean();
				testBean = new AVMTestBean();
				avmManager = new AVMManager();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();				

				testBean.setTestName(request.getParameter("testName"));
				testBean.setTestId(Long.parseLong(UtilsFactory.replaceNullBlank(request.getParameter("testId"), "-1")));
				
				bexist = avmManager.isAVMTestExist(con, testBean, loginBean);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("isExist", bexist);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to vaildate AVM testname. ");
				
			} finally {
				DataBaseManager.close(con);
				con = null;
				avmManager = null;
				loginUserBean = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/addAVMTest")) {
			loginUserBean = null;
			AVMTestBean testBean = null;
			con = null;
			String saCities = null;
			long lTestId = -1l;
			
			JSONArray jaCities = null, jaDays = null;
			JSONObject joRtn = null, joLicDetails = null, joCity = null, joDays = null, joEnt = null;
			
			try {
				avmManager = new AVMManager();
				testBean = new AVMTestBean();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				testBean.setTestName(request.getParameter("testName").trim());
				testBean.setURL(request.getParameter("url").trim());
				testBean.setRequestMethod( request.getParameter("requestMethod") );
				testBean.setTestHeadMethodFirst( Boolean.parseBoolean( request.getParameter("testHeadMethodFirst") ) );
				testBean.setRequestHeaders( JSONArray.fromObject( request.getParameter("requestHeaders") ) );
				testBean.setRequestParameters( JSONArray.fromObject( request.getParameter("requestParameters") ) );
				testBean.setRunEveryMinute( Integer.parseInt(request.getParameter("frequency")) );
				testBean.setStartDate(request.getParameter("startDate").trim().replace("\"", ""));
				testBean.setEndDate(request.getParameter("endDate").trim().replace("\"", ""));
				testBean.setStatus( Boolean.parseBoolean(request.getParameter("status").trim()) );
				testBean.setAvmMinBreachCount(Integer.parseInt(request.getParameter("avmMinBreachCount")));
				testBean.setTestId(Long.parseLong(UtilsFactory.replaceNullBlank(request.getParameter("testId"), "-1")));
				
				testBean.setStartTime(request.getParameter("startHourAndMins"));
				testBean.setEndTime(request.getParameter("endHourAndMins"));
				testBean.setTimezone_offset(Integer.parseInt(request.getParameter("timezoneOffset")));
				
				jaDays = JSONArray.fromObject(request.getParameter("days"));
				
				// Convert JSONArray to JSONObject
				if (jaDays.size() > 0) {
					joDays = new JSONObject();
					
					for (int i = 0; i < jaDays.size(); i++) {
						JSONObject joDay = jaDays.getJSONObject(i);
						Set<String> keySet = joDay.keySet();
						for (String key : keySet) {
							joDays.put(key, (boolean) joDay.get(key));
						}
					}
					
					testBean.setJoDays(joDays);
				}

				saCities = request.getParameter("selectedCities");
				// If Availability Monitor is disabled then, 
	            // No need to fetch existing AVM-Locations
				if (testBean.isStatus()) {
					saCities = request.getParameter("selectedCities");
					jaCities = JSONArray.fromObject(saCities);
					
					for (int i = 0; i < jaCities.size(); i++) {
						joCity = jaCities.getJSONObject(i);
						testBean.addTargetLocation(joCity);
					}
				}
				
				//Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				lTestId = avmManager.addAVMTest(con, testBean, loginUserBean, joEnt);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Availability Monitor has been added successfully.");
				joRtn.put("sum_test_id", lTestId);
				
				DataBaseManager.commitConnection(con);
			} catch (Throwable e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else if(e.getMessage().equals("5")){
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add Availability Monitor. Name already exist.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to save.");
				}
			} finally {
				response.getWriter().write(joRtn.toString());
				
				DataBaseManager.close(con);
				con = null;
				
				UtilsFactory.clearCollectionHieracy( joLicDetails );
				joLicDetails = null;
				UtilsFactory.clearCollectionHieracy( joCity );
				joCity = null;
				UtilsFactory.clearCollectionHieracy( jaCities );
				jaCities = null;
				UtilsFactory.clearCollectionHieracy( joRtn );
				joRtn = null;
				
				avmManager = null;
				UtilsFactory.clearCollectionHieracy( loginUserBean );
				loginUserBean = null;
				
				saCities = null;
				testBean = null;
			}
		}else if (strActionCommand.endsWith("/avm/updateAVMTest")) {
			loginUserBean = null;
			AVMTestBean testBean = null;
			con = null;
			String saCities = null;
			
			JSONArray jaCities = null;
			JSONObject joRtn = null, joLicDetails = null, joCity = null, joEnt = null;
			
			try {
				avmManager = new AVMManager();
				testBean = new AVMTestBean();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				testBean.setTestName(request.getParameter("testName").trim());
				testBean.setTestId(Long.parseLong(request.getParameter("testid").trim()));
				testBean.setURL(request.getParameter("url").trim());
				testBean.setRequestMethod( request.getParameter("requestMethod") );
				testBean.setTestHeadMethodFirst( Boolean.parseBoolean( request.getParameter("testHeadMethodFirst") ) );
				testBean.setRequestHeaders( JSONArray.fromObject( request.getParameter("requestHeaders") ) );
				testBean.setRequestParameters( JSONArray.fromObject( request.getParameter("requestParameters") ) );
				testBean.setRunEveryMinute( Integer.parseInt(request.getParameter("frequency")) );
				testBean.setStartDate(request.getParameter("startDate").trim().replace("\"", ""));
				testBean.setEndDate(request.getParameter("endDate").trim().replace("\"", ""));
				testBean.setStatus( Boolean.parseBoolean(request.getParameter("status").trim()) );
				testBean.setAvmMinBreachCount(Integer.parseInt(request.getParameter("avmMinBreachCount")));
				
				testBean.setStartTime(request.getParameter("startHourAndMins"));
				testBean.setEndTime(request.getParameter("endHourAndMins"));
				testBean.setTimezone_offset(Integer.parseInt(request.getParameter("timezoneOffset")));
				
	            // if Availability Monitor is disabled then, 
	            // No need to fetch existing AVM-Locations
				if (testBean.isStatus()) {
					saCities = request.getParameter("selectedCities");
					jaCities = JSONArray.fromObject(saCities);
					
					for (int i = 0; i < jaCities.size(); i++) {
						joCity = jaCities.getJSONObject(i);
						testBean.addTargetLocation(joCity);
					}
				}
				//Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// Updates the avm test
				avmManager.updateAVMTest(con, testBean, loginUserBean, joEnt);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Availability Monitor has been updated.");
				
				DataBaseManager.commitConnection(con);
			} catch (Throwable e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else if(e.getMessage().equals("5")){
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add Availability Monitor. Name already exist.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to save.");
				}
			} finally {
				response.getWriter().write(joRtn.toString());
				
				DataBaseManager.close(con);
				con = null;
				
				UtilsFactory.clearCollectionHieracy( joLicDetails );
				joLicDetails = null;
				UtilsFactory.clearCollectionHieracy( joCity );
				joCity = null;
				UtilsFactory.clearCollectionHieracy( jaCities );
				jaCities = null;
				UtilsFactory.clearCollectionHieracy( joRtn );
				joRtn = null;
				
				avmManager = null;
				UtilsFactory.clearCollectionHieracy( loginUserBean );
				loginUserBean = null;
				
				saCities = null;
				testBean = null;
			}
		} else if (strActionCommand.endsWith("/avm/deleteAVMTest")) {
			AVMTestBean testBean = null;
			JSONObject joRtn = null;
			
			try {
				avmManager = new AVMManager();
				testBean = new AVMTestBean();

				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				testBean.setTestId(Long.parseLong(request.getParameter("testid").trim()));

				avmManager.deleteAVMTest(con, testBean, loginUserBean, request);

				DataBaseManager.commitConnection(con);

				joRtn = UtilsFactory.getJSONSuccessReturn("AVM Test has been deleted successfully.");

			} catch (Exception e) {
				LogManager.errorLog(e);
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete AVM Test.");
				}

				DataBaseManager.rollbackConnection(con);
			} finally {
				response.getWriter().write(joRtn.toString());

				DataBaseManager.close(con);
				con = null;

				loginUserBean = null;
				avmManager = null;
			}
		} else if (strActionCommand.endsWith("/avm/getAVMUserDashboardSummary")) {
			// gets user's availability monitor summary 
			JSONObject joRtn = null, joRtnAVMUserSummary = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// gets user's availability monitor summary
				joRtnAVMUserSummary = avmManager.getAVMUserDashboardSummary(con, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnAVMUserSummary);
				
				avmManager = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get AVM Summary.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/getUserDownLocationsStatus")) {
			// gets user's down locations status 
			JSONObject joRtn = null;
			long lLimit = -1l, lOffSet = -1l;
			
			JSONArray jaDownLocationsStatus = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				lLimit = Long.parseLong(request.getParameter("limit"));
				lOffSet = Long.parseLong(request.getParameter("offset"));

				jaDownLocationsStatus = avmManager.getUserDownLocationsStatus(con, loginUserBean, lLimit, lOffSet);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaDownLocationsStatus);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get down locations status.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/avm/getUrlDownLocations")) {
			// gets user's down locations status 
			JSONObject joRtn = null;
			//long lLimit = -1l, lOffSet = -1l;
			
			JSONArray jaDownLocationsStatus = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				//lLimit = Long.parseLong(request.getParameter("limit"));
				//lOffSet = Long.parseLong(request.getParameter("offset"));

				jaDownLocationsStatus = avmManager.getUrlDownLocationsStatus(con, loginUserBean);
				//jaDownLocationsStatus = avmManager.getUserDownLocationsStatus(con, loginUserBean, lLimit, lOffSet);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaDownLocationsStatus);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get down locations status.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/getUserApplicationsStatus")) {
			// gets user's applications status 
			JSONObject joRtn = null, joEnt = null;
			JSONArray jaApplicationStatus = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				//Enterprise License Details
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// gets user's applications status 
				jaApplicationStatus = avmManager.getUserApplicationsStatus(con, loginUserBean, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaApplicationStatus);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get User Application Status.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/addAgentLocation")) {
			// add user's AVM agent location 
			JSONObject joRtn = null, joEnt = null;
			String strGUID = "";
			
			boolean bFromAVMController = false, bPrivateAgent = true;
			long lRtnAgentId = -1L;
			
			AVMAgentBean avmAgentBean = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				if( request.getParameter("from_avm_controller_20160629") != null ) {
					bFromAVMController = true;
				}
				
				if( bFromAVMController ) {
					loginUserBean = new LoginUserBean();
					loginUserBean.setEnterpriseId( Long.parseLong(request.getParameter("enterprise_id")) );
					loginUserBean.setUserId( Long.parseLong(request.getParameter("user_id")) );
					
					strGUID = request.getParameter("GUID");
					bPrivateAgent = true;
					
					LogManager.infoLog("New GUID found for UserId "+loginUserBean.getUserId()+" <> "+strGUID);
					
				} else {
					loginUserBean = new LoginUserBean();
					loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
					
					strGUID = UUID.randomUUID().toString();
					
					bPrivateAgent = Boolean.parseBoolean( UtilsFactory.replaceNullBlank( request.getParameter("private"), "TRUE" ) );
				}
				
				avmAgentBean = new AVMAgentBean();
				avmAgentBean.setEnterpriseId(loginUserBean.getEnterpriseId());
				avmAgentBean.setUserId(loginUserBean.getUserId());
				avmAgentBean.setPrivate( bPrivateAgent );
				avmAgentBean.setCountry(request.getParameter("country"));
				avmAgentBean.setState( UtilsFactory.replaceNull(request.getParameter("state"), "") );
				avmAgentBean.setCity(request.getParameter("city"));
				avmAgentBean.setRegion( UtilsFactory.replaceNull(request.getParameter("region"), "") );
				avmAgentBean.setZone( UtilsFactory.replaceNull(request.getParameter("zone"), "") );
				avmAgentBean.setGUID(strGUID);
				avmAgentBean.setStatus("JUST_ADDED");
				//Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// add user's AVM agent
				lRtnAgentId = avmManager.addAVMAgent(con, avmAgentBean, loginUserBean, joEnt);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Location saved.");
				joRtn.put("agentId", lRtnAgentId);
				
				DataBaseManager.commitConnection(con);
				
				avmManager = null;
				avmAgentBean = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Location already exists.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add Location.");	
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/avm/getUserLocations")) {
			// gets user's locations
			JSONObject joRtn = null;
			JSONObject joEnt = null;
			JSONArray jaRtnUserLocations = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				//Enterprise License Details
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				
				// gets user's locations
				jaRtnUserLocations = avmManager.getUserLocations(con, loginUserBean, joEnt);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnUserLocations);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Locations.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/avm/DeleteAVMUserLocations")) {
			// gets user's locations
			JSONObject joRtn = null;
			JSONArray jaRtnUserLocations = null;
			AVMAgentBean avmAgentBean = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				avmAgentBean = new AVMAgentBean();
				avmAgentBean.setAgentId(Long.parseLong(request.getParameter("agentId")));
				avmAgentBean.setEnterpriseId(loginUserBean.getEnterpriseId());
				avmAgentBean.setUserId(loginUserBean.getUserId());
				avmAgentBean.setCountry(request.getParameter("country"));
				avmAgentBean.setState( UtilsFactory.replaceNull(request.getParameter("state"), "") );
				avmAgentBean.setCity(request.getParameter("city"));
				avmAgentBean.setRegion( UtilsFactory.replaceNull(request.getParameter("region"), "") );
				avmAgentBean.setZone( UtilsFactory.replaceNull(request.getParameter("zone"), "") );
				
				// gets user's locations
				//jaRtnUserLocations = avmManager.deleteAVMUserLocations(con, loginUserBean, avmAgentBean);
				avmManager.deleteAVMUserLocations(con, loginUserBean, avmAgentBean);
				
				DataBaseManager.commitConnection(con);
				joRtn = UtilsFactory.getJSONSuccessReturn("AVM Location is successfully Deleted.");
				
				avmManager = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				if ( e.getMessage().equals("5") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Agent is mapped with Test. So unmap them first.");
				}else {
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to Delete User Locations.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if (strActionCommand.endsWith("/avm/updateAgentLocation")) {
			// update's user's AVM agent location for status `Just Added`
			JSONObject joRtn = null;
			
			AVMAgentBean avmAgentBean = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				avmAgentBean = new AVMAgentBean();
				avmAgentBean.setAgentId(Long.parseLong(request.getParameter("agentId")));
				avmAgentBean.setEnterpriseId(loginUserBean.getEnterpriseId());
				avmAgentBean.setUserId(loginUserBean.getUserId());
				avmAgentBean.setCountry(request.getParameter("country"));
				avmAgentBean.setState( UtilsFactory.replaceNull(request.getParameter("state"), "") );
				avmAgentBean.setCity(request.getParameter("city"));
				avmAgentBean.setRegion( UtilsFactory.replaceNull(request.getParameter("region"), "") );
				avmAgentBean.setZone( UtilsFactory.replaceNull(request.getParameter("zone"), "") );
				
				// update's user's AVM agent location for status `Just Added`
				avmManager.updateAgentLocation(con, avmAgentBean, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Location updated.");
				joRtn.put("agentId", avmAgentBean.getAgentId());
				
				DataBaseManager.commitConnection(con);
				
				avmManager = null;
				avmAgentBean = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Location already exists.");
				} else if ( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Update denied.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update Location.");	
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/addLocationAlertAddress")) {
			// adds AVM agent's alert address 
			JSONObject joRtn = null, joEnt = null;
			
			AVMAgentAlertAddressBean agentAlertAddressBean = null;
			
			boolean bRtnEmailSent = false;
			
			long luser_id = -1L;
			try {
				avmManager = new AVMManager();
				agentAlertAddressBean = new AVMAgentAlertAddressBean();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				agentAlertAddressBean.setUserId(loginUserBean.getUserId());
				agentAlertAddressBean.setAgentId( Long.parseLong( request.getParameter("agentId") ) );
				agentAlertAddressBean.setGUID( request.getParameter("guid") );
				agentAlertAddressBean.setAlertType(request.getParameter("alertType"));
				agentAlertAddressBean.setEmailMobile(request.getParameter("emailOrMobileNumber"));
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getInt("e_id")!=0){
					luser_id = joEnt.getLong("e_user_id");
				}else{
					luser_id = loginUserBean.getUserId();
				}
				
				// adds agent's alert address
				bRtnEmailSent = avmManager.addLocationAlertAddress(con, agentAlertAddressBean, loginUserBean, luser_id);
				joRtn = UtilsFactory.getJSONSuccessReturn("Location's alert address added.");
				joRtn.put("emailSent", bRtnEmailSent);
				
				DataBaseManager.commitConnection(con);
				
				avmManager = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					// throw exception, email_mobile already added for the agent
					joRtn = UtilsFactory.getJSONFailureReturn("Alert address already exists.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add alert address.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/getLocationAlertAddresses")) {
			// gets location's added alert addresses
			JSONObject joRtn = null, joEnt = null;
			JSONArray jaRtnAlertAddresses = null;
			
			long luser_id = -1L; 
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lAgentId = Long.parseLong( request.getParameter("agentId") );
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getInt("e_id")!=0){
					luser_id = joEnt.getLong("e_user_id");
				}else{
					luser_id = loginUserBean.getUserId();
				}
				
				// gets location's added alert addresses 
				jaRtnAlertAddresses = avmManager.getLocationAlertAddresses(con, lAgentId, /*loginUserBean*/ luser_id);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnAlertAddresses);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Location Alert Addresses.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/deleteLocationAlertAddress")) {
			// delete agent's address
			JSONObject joRtn = null, joEnt = null;
			long luser_id = -1L;
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lAgentAlertId = Long.parseLong( request.getParameter("agentAlertId") );
				long lAgentId = Long.parseLong( request.getParameter("agentId") );
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getInt("e_id")!=0){
					luser_id = joEnt.getLong("e_user_id");
				}else{
					luser_id = loginUserBean.getUserId();
				}
				
				// deletes agent/location's alert address 
				avmManager.deleteLocationAlertAddress(con, lAgentAlertId, lAgentId, /*loginUserBean*/luser_id);
				joRtn = UtilsFactory.getJSONSuccessReturn("Alert address deleted.");
				
				DataBaseManager.commitConnection(con);
				
				avmManager = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete Location Alert Address.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/verifyAlertEmailAddress")) {
			// updates alert address verification 
			JSONObject joRtn = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				long lAgentAlertId = Long.parseLong( CryptManager.decodeDecryptURL( request.getParameter("_aid") ) );
				
				// updates alert address verification
				avmManager.verifyAlertEmailAddress(con, lAgentAlertId);
				joRtn = UtilsFactory.getJSONSuccessReturn("Email address verified.");
				
				DataBaseManager.commitConnection(con);
				
				avmManager = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to update alert verification.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/getLocationDetails")) {
			// gets particular location details 
			JSONObject joRtn = null, joEnt = null;
			
			AVMAgentBean avmAgentBean = null;
			JSONObject joAgentLocationDetails = null;
			
			long luser_id = -1L;
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				long lAgentId = Long.parseLong( request.getParameter("agentId") );
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getInt("e_id")!=0){
					luser_id = joEnt.getLong("e_user_id");
				}else{
					luser_id = loginUserBean.getUserId();
				}
				
				// get particular location/agent details 
				avmAgentBean = avmManager.getAgentLocation(con, lAgentId, /*loginUserBean.getUserId()*/ luser_id);
				joAgentLocationDetails = avmAgentBean.toJSON();
				joRtn = UtilsFactory.getJSONSuccessReturn(joAgentLocationDetails);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Location Details.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/getTestLocationsStatus")) {
			// gets test's locations status 
			JSONObject joRtn = null, joEnt = null;
			
			JSONArray jaRtnLocationsStatus = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				long lTestId = Long.parseLong( request.getParameter("testId") );
				long lLimit = Long.parseLong(request.getParameter("limit"));
				long lOffSet = Long.parseLong(request.getParameter("offset"));
				
				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				// gets test's locations status 
				jaRtnLocationsStatus = avmManager.getTestLocationsStatus(con, lTestId, lLimit, lOffSet, loginUserBean, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnLocationsStatus);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Test Locations Status.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/avm/getUserTestSummary")) {
			// get user's test summary 
			JSONObject joRtn = null, joEnt = null;
			
			JSONObject joRtnUserTestSummary = null;
			
			try {
				avmManager = new AVMManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")) );
				
				long lTestId = Long.parseLong( request.getParameter("testId") );

				//enterprise license implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// get user's test summary 
				joRtnUserTestSummary = avmManager.getUserTestSummary(con, lTestId, loginUserBean, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnUserTestSummary);
				
				avmManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get User Test Summary.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}