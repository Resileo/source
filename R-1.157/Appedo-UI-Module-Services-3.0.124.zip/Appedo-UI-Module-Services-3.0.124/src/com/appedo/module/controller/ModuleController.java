package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.AppedoConstants;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.APMLicenseBean;
import com.appedo.module.bean.DDLicenseBean;
import com.appedo.module.bean.ModuleBean;
import com.appedo.module.bean.RUMSLABean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.ModuleManager;
import com.appedo.module.model.SLAManager;
import com.appedo.module.model.ServiceManager;
import com.appedo.module.utils.UtilsFactory;

/**
 * Servlet implementation class ModuleController
 */
public class ModuleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();
		Connection con = null;
		
		if(strActionCommand.endsWith("/apm/getModules")) {
			ModuleManager apmManager = null;				
			LoginUserBean loginBean = null;
			String strModuleType = null;
			String strLimit = null;
			String strOffset = null;
			JSONObject joAPMModules = null;
			
			try {
				// get connection 
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				// capture
				
				strModuleType = request.getParameter("moduleType");
				strLimit = request.getParameter("pageLimit");
				strOffset = request.getParameter("pageOffset");					
				apmManager = new ModuleManager();
				
				joAPMModules = apmManager.getAPMModules(con, loginBean, strModuleType, strLimit, strOffset);

			} catch(Exception e) {
				LogManager.errorLog(e);
			} finally {
				apmManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joAPMModules.toString());
			}
		}else if(strActionCommand.endsWith("/apm/getEditSUM")) {
			ModuleManager apmManager = null;
			//String testid = null;
			long testid = -1;
			JSONObject joEditSUMModules = null;
			
			try {
				// get connection 
				con = DataBaseManager.giveConnection();
				testid = Long.parseLong(request.getParameter("testid"));
				apmManager = new ModuleManager();
				
				joEditSUMModules = apmManager.getEditSUMModules(con, testid);
			}catch(Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joEditSUMModules.toString());
			}	
		}else if(strActionCommand.endsWith("/apm/getModulesData")) {
			ModuleManager apmManager = null;				
			LoginUserBean loginBean = null;
			String strModuleType = null;
			String strLimit = null;
			String strOffset = null;
			JSONObject joAPMModules = null;
			JSONObject joSUMModules = null;
			JSONObject joRtn = null;
			JSONObject joEnt = null;
			try {
				// get connection 
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				

				// capture
				if(request.getParameter("moduleType").equalsIgnoreCase("OAD")) {
					strModuleType = "'APPLICATION','SERVER','DATABASE'";
				}else if(request.getParameter("moduleType").equalsIgnoreCase("Operating System")) {
					strModuleType = "'SERVER'";
				}else if(request.getParameter("moduleType").equalsIgnoreCase("Application")) {
					strModuleType = "'APPLICATION'";
				}else if(request.getParameter("moduleType").equalsIgnoreCase("DataBase")) {
					strModuleType = "'DATABASE'";
				}else if(request.getParameter("moduleType").equalsIgnoreCase("RUM")) {
					strModuleType = "'RUM'";
				}else if(request.getParameter("moduleType").equalsIgnoreCase("LOG")) {
					strModuleType = "'LOG'";
				}
				
				
				//strModuleType = request.getParameter("moduleType");
				strLimit = request.getParameter("pageLimit");
				strOffset = request.getParameter("pageOffset");					
				apmManager = new ModuleManager();
				
				if(request.getParameter("moduleType").equalsIgnoreCase("SUM")) {
					//joSUMModules = apmManager.getSUMModule(con, loginBean);
					joAPMModules = apmManager.getSUMModule(con, loginBean, joEnt);
				}else if(request.getParameter("moduleType").equalsIgnoreCase("Enterprise")) {
					joAPMModules = apmManager.getEnterpriseModule(con, loginBean);
				}else{
					joAPMModules = apmManager.getAPMModules01(con, loginBean, strModuleType, strLimit, strOffset, joEnt);
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(joAPMModules);

			} catch(Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get APM Tests. ");
			} finally {
				apmManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apm/getModulesAvailableData")) {
			ModuleManager apmManager = null;				
			LoginUserBean loginBean = null;
			//String strModuleType = null;
			//String strLimit = null;
			//String strOffset = null;
			String strUid = null;
			JSONObject joAPMModules = null;
			
			try {
				// get connection 
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				// capture
			
				strUid = request.getParameter("uid");
				apmManager = new ModuleManager();
				
				joAPMModules = apmManager.getAPMModulesData(con, loginBean, strUid);

			} catch(Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
			} finally {
				apmManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joAPMModules.toString());
			}
		}else if(strActionCommand.endsWith("apm/setAsDefaultInCard")){
			ModuleManager apmManager = null;				
			LoginUserBean loginBean = null;
			String strModuleType = null;
			JSONObject joRtn = null;
			
			try{
				// get connection 
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				apmManager = new ModuleManager();
				
				strModuleType = request.getParameter("moduleType");
				
				apmManager.setAsDefaultInCard(con, loginBean, strModuleType);
				
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("'"+strModuleType +"' is set as default successfully, Reflect in Next login");
			}catch(Exception e){
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to update Default Settings. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
			
		} else if(strActionCommand.endsWith("apm/setAsDefaultDashboard")){
			ModuleManager apmManager = null;				
			LoginUserBean loginBean = null;
			String strHealthCode = null;
			Long lServiceMapId = null;
			JSONObject joRtn = null;
			
			try{
				// get connection 
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				apmManager = new ModuleManager();
				
				strHealthCode = request.getParameter("healthCode");
				if (request.getParameter("serviceMapId") != null) {
					lServiceMapId = Long.parseLong(request.getParameter("serviceMapId"));
				}
				
				apmManager.setAsDefaultDashboard(con, loginBean, strHealthCode, lServiceMapId);
				
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Default settings saved, reflect in next login");
			}catch(Exception e){
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to update Default Settings. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
			
		} else if(strActionCommand.endsWith("/apm/getLogRunningStatus")) {
			ModuleManager apmManager = null;				
			LoginUserBean loginBean = null;
			String strUid = null;
			JSONObject joAPMModules = null;
			JSONObject joRtn = null;
			
			try {
				// get connection 
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				// capture
			
				strUid = request.getParameter("uid");
				apmManager = new ModuleManager();
				
				joAPMModules = apmManager.getLogRunningStatus(con, loginBean, strUid);
				joRtn = UtilsFactory.getJSONSuccessReturn(joAPMModules);

			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to geting LOG Status.");
			} finally {
				apmManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apm/checkModuleLimit")) {
			JSONObject joRtn = null;
			ModuleManager apmManager = null;
			LoginUserBean loginBean = null;
			boolean isLimitExceeded = false;

			try {
				// get connection 
				con = DataBaseManager.giveConnection();

				apmManager = new ModuleManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				isLimitExceeded = apmManager.isModuleLimitExceded(con, loginBean);

				joRtn = UtilsFactory.getJSONSuccessReturn(""+isLimitExceeded);	// `\nCounters were mapped to SLA.` // default counters were mapped to SLA ploicy
				joRtn.put("isLimitExceeded", isLimitExceeded);

			} catch(Exception e) {
				LogManager.errorLog(e);
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("License expired.\n Please contact "+AppedoConstants.getAppedoWhiteLabel("support_emailid"));
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. "+e.getMessage());
				}
			} finally {
				apmManager = null;

				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/addModule")) {
			JSONObject joRtn = null, joEnt = null;
			
			String strModuleVersionType = null;
			
			ModuleBean moduleBean = null;
			RUMSLABean rumslaBean = null;
			ModuleManager moduleManager = null;
			
			SLAManager slaManager = null;
			
			LoginUserBean loginUserBean = null;
			
			Boolean bRUMResponseAlert = null;
			
			try {
				moduleBean = new ModuleBean();
				moduleManager = new ModuleManager();
				slaManager = new SLAManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				moduleBean.setUserId(loginUserBean.getUserId());
				moduleBean.setModuleName(request.getParameter("moduleName").trim());
				moduleBean.setDescription(request.getParameter("moduleDescription").trim());
				moduleBean.setAgentVersionId(Integer.parseInt(request.getParameter("moduleVersion")));
				moduleBean.setModuleType(request.getParameter("moduleType").toUpperCase());
				moduleBean.setGuid(UUID.randomUUID().toString());
				moduleBean.setCLRVersion( UtilsFactory.replaceNull(request.getParameter("clrVersion"), "") );
				strModuleVersionType = request.getParameter("type");
				// RUM response time alert
				bRUMResponseAlert = Boolean.parseBoolean(request.getParameter("responseAlert"));
				
				//Enterprise Details
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// add the module
				moduleManager.addModule(con, moduleBean, loginUserBean, joEnt);
				
				DataBaseManager.commitConnection(con);
				
				// TODO: Add SLA as separate Thread
				
				// add SLAs for all Linux flavours
//				if( strModuleVersionType.equals("Fedora") || strModuleVersionType.equals("RedHat") || strModuleVersionType.equals("CentOS") || strModuleVersionType.equals("Ubuntu") ) { 
				if ( ! moduleBean.getModuleType().equals("RUM") ) {
					slaManager = new SLAManager();
					
					// add SLA Policies map to counters for primary counters of SLA `Error`, `Warning`, & `Threshold Breach` alerts
					slaManager.addSLAPoliciesMapToCounters(con, moduleBean, loginUserBean, joEnt);
				} else if ( moduleBean.getModuleType().equals("RUM") && bRUMResponseAlert ) {
					// add SLA for RUM module/uid, if response time alert is enabled 
					rumslaBean = new RUMSLABean();
					rumslaBean.setUserId(loginUserBean.getUserId());
					// saved in milli sec.
					rumslaBean.setCriticalThresholdValue(Integer.parseInt(request.getParameter("critical")) * 1000);
					rumslaBean.setWarningThresholdValue(Integer.parseInt(request.getParameter("warning")) * 1000);
					rumslaBean.setMinBreachCount(Integer.parseInt(request.getParameter("breachCount")));
					rumslaBean.setModuleName(moduleBean.getModuleName());
					rumslaBean.setGUID(moduleBean.getGuid());
					rumslaBean.setUId(moduleBean.getModuleId());
					rumslaBean.setEnableResponseAlert(bRUMResponseAlert);
					
					// add SLA policy and map to RUM module, with the input threshold 
					slaManager.configureSLAToRUMModule(rumslaBean, loginUserBean, joEnt);
				}
				
				// rtn resp
				joRtn = UtilsFactory.getJSONSuccessReturn(moduleBean.getModuleType()+"'s `"+moduleBean.getModuleName()+"` added.");	// `\nCounters were mapped to SLA.` // default counters were mapped to SLA ploicy
				joRtn.put("guid", moduleBean.getGuid());
				joRtn.put("type", strModuleVersionType);
				joRtn.put("moduleName", moduleBean.getModuleName());
			} catch(Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("License expired.\n Please contact "+AppedoConstants.getAppedoWhiteLabel("support_emailid"));
				} else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to save. Max "+moduleBean.getModuleType()+" exceeds the limit.");
				}  else if( e.getMessage().equals("3") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. Name already exist. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. "+e.getMessage());
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
				
				moduleManager = null;
				moduleBean = null;
				rumslaBean = null;
				bRUMResponseAlert = null;
			}
		} else if(strActionCommand.endsWith("/apm/getModuleVersions")) {
			
			String strModuleType = null;
			JSONArray jaTypeVersions = null;
			ModuleManager moduleManager = null;
			
			try {
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				strModuleType = request.getParameter("moduleName");
				 
				jaTypeVersions = moduleManager.getModuleTypeVersions(con, strModuleType.toUpperCase());
				
				moduleManager = null;
				strModuleType = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(jaTypeVersions.toString());
			}
		}else if(strActionCommand.endsWith("apm/getMappedUsers")) {
			
			
			JSONArray jaMapUser = null;
			ModuleManager moduleManager = null;
			LoginUserBean loginBean = null;
			int e_id;
			JSONObject joRtn = null;
			try {
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				e_id = Integer.parseInt(request.getParameter("e_Id"));
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				jaMapUser = moduleManager.getMapUsers(con, e_id, loginBean.getUserId() );
				joRtn = UtilsFactory.getJSONSuccessReturn(jaMapUser);
				
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get mapped users.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				moduleManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/deleteMapUser")){
			ModuleManager moduleManager = null;
			LoginUserBean loginBean = null;
			String strUserName;
			int e_id;
			JSONObject joRtn = null;
			
			try {
				moduleManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				e_id = Integer.parseInt(request.getParameter("e_id"));
				strUserName = request.getParameter("userName");
				
				moduleManager.deleteMapUser(con, e_id, strUserName);
				DataBaseManager.commitConnection(con);

				
				joRtn = UtilsFactory.getJSONSuccessReturn("User has been removed.");
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to remove the User.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				
				strUserName = null;
				loginBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/deleteEnterprise")){
			ModuleManager moduleManager = null;
			LoginUserBean loginBean = null;
			int e_id;
			JSONObject joRtn = null;
			
			try {
				moduleManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				e_id = Integer.parseInt(request.getParameter("e_Id"));
				
				moduleManager.deleteEnterprise(con, e_id);
				DataBaseManager.commitConnection(con);

				joRtn = UtilsFactory.getJSONSuccessReturn("Enterprise has been removed.");
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to remove the Enterprise.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/addEnterpriseData")) {
			
			String strEnterpriseName = null;
			JSONObject joRtn = null;
			ModuleManager moduleManager = null;
			//boolean bexist = false;
			ModuleBean moduleBean = null;
			LoginUserBean loginUserBean = null;
			long lEnterpriseId = -1L;
			try {
				moduleBean = new ModuleBean();
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				strEnterpriseName = request.getParameter("enterpriseName");
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				moduleBean.setUserId(loginUserBean.getUserId());
				moduleBean.setModuleName(request.getParameter("enterpriseName").trim());
				moduleBean.setDescription(request.getParameter("enterpriseDescription").trim());
				
				// add Enterprise Module
				lEnterpriseId = moduleManager.addEnterprise(con, moduleBean, loginUserBean);
				DataBaseManager.commitConnection(con);
				
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Enterprises "+ strEnterpriseName + " added");
				joRtn.put("e_id", lEnterpriseId);
			} catch (Exception e) {
				LogManager.errorLog(e);
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to save. Max Enterprise exceeds the limit.");
				}else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to mapped user. Max mapped user exceeds the limit.");
				}else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. "+e.getMessage());
				}
			} finally {
				moduleManager = null;
				strEnterpriseName = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apm/isValidEnterpriseName")) {
			
			String strEnterpriseName = null;
			JSONObject joRtn = null;
			ModuleManager moduleManager = null;
			boolean bexist = false;
			
			try {
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				strEnterpriseName = request.getParameter("enterpriseName");
				 
				bexist = moduleManager.isValidEnterpriseName(con, strEnterpriseName);
				
				moduleManager = null;
				strEnterpriseName = null;
				joRtn = UtilsFactory.getJSONSuccessReturn(bexist+"");
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apm/addUserEnterpriseMapping")) {
			
			JSONObject joUserDetails = null, joRtn = null;
			ModuleManager moduleManager = null;
			boolean bexist = false;
			LoginUserBean loginUserBean = null;
			long lEnterpriseId = -1L;
			String strEntName = null;
			try {
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				joUserDetails = JSONObject.fromObject(request.getParameter("userDetails"));
				lEnterpriseId = Long.parseLong(request.getParameter("EnterpriseId"));
				strEntName = request.getParameter("enterpriseName");
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				

				moduleManager.addUserEnterpriseMapping(con, joUserDetails, lEnterpriseId, loginUserBean, strEntName);
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("successfully mapped");
			} catch (Exception e) {
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("User is not existing in Appedo and User creation is failed");
				} else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map user. Max mapped user exceeds the limit.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map user");
				}
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				moduleManager = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apm/readModules")) {
			LoginUserBean loginUserBean = null;
			JSONObject joRtnModules = null, joRtn = null;
			ModuleManager moduleManager = null;
			String strModuleType = null;
			try {
				moduleManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();
				//loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
				strModuleType = request.getParameter("moduleType");

				String strLimit = UtilsFactory.replaceNull(request.getParameter("limit"), "");
				String strOffset = UtilsFactory.replaceNull(request.getParameter("offset"), "");
				
				joRtnModules = moduleManager.getModules(con, strModuleType, strLimit, strOffset, loginUserBean);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnModules);
				
				loginUserBean = null;
				moduleManager = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get modules. Please try after sometimes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/getAPMDropDown")) {
			JSONArray joAPMModules = null;
			ModuleManager apmManager = null;
			LoginUserBean loginBean = null;
			String strModuleName = null;
			try {
				apmManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();
				//loginUserBean = (LoginUserBean) session.getAttribute("login_user_bean");
				strModuleName = request.getParameter("moduleCode");
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				joAPMModules = apmManager.getAppDropDown(con, loginBean.getUserId(), strModuleName);
			} catch(Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				apmManager = null;
				response.getWriter().write(joAPMModules.toString());
			}
		}else if(strActionCommand.endsWith("/apm/updateEnterpriseModule")) { 
			ModuleManager moduleManager = null;
			LoginUserBean loginUserBean = null;
			ModuleBean moduleBean = null;
			JSONObject joRtn = null;
			
			try {
				loginUserBean = new LoginUserBean();
				moduleBean = new ModuleBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				
				moduleBean.setModuleId(Long.parseLong(request.getParameter("e_id")));
				moduleBean.setModuleName(request.getParameter("enterpriseName"));
				moduleBean.setDescription(request.getParameter("enterpriseDescription"));
				
				moduleManager.updateEnterpriseModule(con, moduleBean, loginUserBean);
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Enterprise's `"+moduleBean.getModuleName()+"` updated.");
			}catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update. Name already exist. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update module.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				moduleManager = null;
				moduleBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
			
		}else if(strActionCommand.endsWith("/apm/updateModule")) {
			
			ModuleManager moduleManager = null;
			SLAManager slaManager = null;
			
			LoginUserBean loginUserBean = null;
			
			ModuleBean moduleBean = null;
			RUMSLABean rumslaBean = null;
			
			Boolean bRUMResponseAlert = null;
			
			JSONObject joRtn = null, joEnt = null;
			
			try {
				loginUserBean = new LoginUserBean();
				moduleBean = new ModuleBean();
				
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				
				moduleBean.setModuleId(Long.parseLong(request.getParameter("uid")));
				moduleBean.setGuid(request.getParameter("guid"));
				moduleBean.setModuleType(request.getParameter("moduleType"));
				moduleBean.setModuleName(request.getParameter("moduleName"));
				moduleBean.setDescription(request.getParameter("moduleDescription"));
				
				//Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// update module & chart visual data
				moduleManager.updateModule(con, moduleBean, loginUserBean);

				DataBaseManager.commitConnection(con);
				
				
				// RUM response time alert
				bRUMResponseAlert = Boolean.parseBoolean(request.getParameter("responseAlert"));
				
				/*
				 * TODO: while update RUM threshold, need to check
				 *   1. threshold value update
				 *   2. if response alert disabled, update only in `so_sla` is_active = false;
				 *   3. for RUM SLA, the sla_id not insert into `so_sla_rule`, common for all ASD, SUM & RUM
				 */
				
				if ( moduleBean.getModuleType().equals("RUM")  ) {
					slaManager = new SLAManager();
					
					rumslaBean = new RUMSLABean();
					rumslaBean.setUserId(loginUserBean.getUserId());
					rumslaBean.setCriticalThresholdValue(Integer.parseInt( UtilsFactory.replaceNull(request.getParameter("critical"), "0") ) * 1000);
					rumslaBean.setWarningThresholdValue(Integer.parseInt( UtilsFactory.replaceNull(request.getParameter("warning"), "0") ) * 1000);
					rumslaBean.setMinBreachCount(Integer.parseInt( UtilsFactory.replaceNull(request.getParameter("breachCount"), "0") ));
					rumslaBean.setModuleName(moduleBean.getModuleName());
					rumslaBean.setGUID(moduleBean.getGuid());
					rumslaBean.setUId(moduleBean.getModuleId());
					rumslaBean.setEnableResponseAlert(bRUMResponseAlert);
					
					// add SLA policy and map to RUM module, with given thresholds 
					slaManager.configureSLAToRUMModule(rumslaBean, loginUserBean, joEnt);
				}
				
				joRtn = UtilsFactory.getJSONSuccessReturn(moduleBean.getModuleType()+"'s `"+moduleBean.getModuleName()+"` updated.");
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update. Name already exist. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update module.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				moduleManager = null;
				slaManager = null;
				moduleBean = null;
				rumslaBean = null;
				bRUMResponseAlert = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/deleteModule")) {
			String strModuleId = null, strModuleType = null, strGUID = null;
			
			JSONObject joRtn = null, joEnt = null;
			
			ModuleManager moduleManager = null;
			
			LoginUserBean loginUserBean = null;
			
			try {
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				strModuleId = request.getParameter("moduleId");
				strGUID = request.getParameter("guid");
				strModuleType = request.getParameter("moduleType");
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				// delete the module, partitions; the module is deleted, if the module/guid doesn't has user generated SLA(s)
				moduleManager.deleteModule(con, Long.parseLong(strModuleId), strGUID, strModuleType, loginUserBean, joEnt.getLong("e_id"));
				joRtn = UtilsFactory.getJSONSuccessReturn("Module has been removed");
				joRtn.put("deleted_SLAs", moduleManager.getDeletedGUIDSLAs());
				
				DataBaseManager.commitConnection(con);
				
				moduleManager = null;
				strModuleId = null;
				strGUID = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				if ( e.getMessage().equals("1") ) {
					// the guid has user generated SLA(s)
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete `#MODULE_NAME#`. Alert(s) has been mapped for the module. ");
				} else {
	                joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());	
				}
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}  else if(strActionCommand.endsWith("/apm/getAPMSummary")) {
            JSONArray joAPMModules = null;
            JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginBean = null;
            String strModuleName = null;
            
            try {
                    apmManager = new ModuleManager();
                    con = DataBaseManager.giveConnection();
                    strModuleName = request.getParameter("moduleCode");
                    loginBean = new LoginUserBean();
                    loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
                    joAPMModules = apmManager.getAppSummary(con, loginBean.getUserId(), strModuleName);
                    joRtn = UtilsFactory.getJSONSuccessReturn(joAPMModules);
            } catch(Exception e) {
                    LogManager.errorLog(e);
                    joRtn = UtilsFactory.getJSONFailureReturn(e.getMessage());
            } finally {
                    DataBaseManager.close(con);
                    con = null;
                    apmManager = null;
                    response.getWriter().write(joRtn.toString());
            }
		}	else if(strActionCommand.endsWith("/apm/getAPMLicense")) {
            JSONArray joAPMModules = null;
            ModuleManager apmManager = null;
            LoginUserBean loginBean = null;
            try {
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                loginBean = new LoginUserBean();
                loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
                joAPMModules = apmManager.getAppLicense(con, loginBean.getUserId());
            } catch(Exception e) {
                LogManager.errorLog(e);
            } finally {
                DataBaseManager.close(con);
                con = null;
                
                apmManager = null;
                response.getWriter().write(joAPMModules.toString());
            }
		}/*else if(strActionCommand.endsWith("/apm/getVersions")){
			JSONObject joRtn = new JSONObject();
			try{
				con = DataBaseManager.giveConnection();
				
				joRtn.put("COUNTER_TYPES_DOWNLOAD_FILE_PATH", ModuleDBI.loadAgentsDownloadFilePath(con).toString());
				joRtn.put("AGENT_LATEST_BUILD_VERSION", Constants.AGENT_LATEST_BUILD_VERSION.toString());
			}catch(Exception e){
				LogManager.errorLog(e);
			} finally {
	            DataBaseManager.close(con);
	            con = null;
	        }
			response.getWriter().write(joRtn.toString());
		}*/ else if(strActionCommand.endsWith("/apm/getCategories")) {
            JSONArray jaCategoriesCounters = null;
            
            ModuleManager moduleManager = null;
            
            long lUId = -1;
            
            try {
                moduleManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                
                lUId = Long.valueOf(request.getParameter("uid"));
                String strAgentVersion = request.getParameter("agentVersion");
                
                jaCategoriesCounters = moduleManager.getAgentAllCategoryWiseCounters(con, lUId, strAgentVersion);
            } catch(Exception e) {
            	LogManager.errorLog(e);
            } finally {
            	DataBaseManager.close(con);
                con = null;
                moduleManager = null;
                response.getWriter().write(jaCategoriesCounters.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getMaxCounters")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            APMLicenseBean apmLicenseBean = null;
            try {
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

        		apmLicenseBean = apmManager.getAPMUserLicenseDetails(con, loginUserBean);
        		joRtn = UtilsFactory.getJSONSuccessReturn("");
        		joRtn.put("max_counters", apmLicenseBean.getMaxCounters());
            } catch(Exception e) {
                LogManager.errorLog(e);

                DataBaseManager.rollbackConnection(con);

            } finally {
                DataBaseManager.close(con);
                con = null;

                apmManager = null;
                response.getWriter().write(joRtn.toString());
            }
		} else if(strActionCommand.endsWith("/apm/updateCounters")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            APMLicenseBean apmLicenseBean = null;
            ModuleBean moduleBean = null;
            String strCounterIds = null;
            try {
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

            	moduleBean = new ModuleBean();
            	moduleBean.setModuleId(Integer.parseInt(request.getParameter("uid")));
				moduleBean.setGuid(request.getParameter("guid"));
				moduleBean.setModuleName(request.getParameter("moduleName"));
				moduleBean.setModuleType(request.getParameter("moduleCode"));

				strCounterIds = request.getParameter("moduleCounters");
        		apmLicenseBean = apmManager.getAPMUserLicenseDetails(con, loginUserBean);
        		if( apmLicenseBean != null ){
        			apmManager.updateAPMModuleAndCounters(con, moduleBean, apmLicenseBean, strCounterIds, loginUserBean);
        			
        			//To delete and insert the modified counters
        			apmManager.updateChartData(con, moduleBean, loginUserBean, strCounterIds);
        			
        			DataBaseManager.commitConnection(con);
        			joRtn = UtilsFactory.getJSONSuccessReturn("Metrics(s) list has been updated.");
        		} else {
        			joRtn = UtilsFactory.getJSONSuccessReturn("License Expired");
        		}

				// update selected counters to Collector
        		apmManager.updateSelectedCountersToCollector(con, moduleBean.getGuid());
            } catch(Exception e) {
                LogManager.errorLog(e);

                DataBaseManager.rollbackConnection(con);

                if( e.getMessage().equals("3") ) {
                	joRtn = UtilsFactory.getJSONFailureReturn("Unable to update. Number of Metrics exceeds the license limit. ");
				} else if( e.getMessage().equals("4") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update. "+e.getCause().getMessage()+" should be selected, since it is used in Alerts.");
				}else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update metrics");
				}
            } finally {
                DataBaseManager.close(con);
                con = null;

                apmManager = null;
                response.getWriter().write(joRtn.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getSlowQuery")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            String strGUID = null, strFromStartInterval = null;
            try {
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	strFromStartInterval = request.getParameter("fromStartInterval");
            	strGUID = request.getParameter("guid");
        		joRtn = apmManager.getSlowQuery(con, strFromStartInterval, strGUID);
            } catch(Exception e) {
                LogManager.errorLog(e);
            } finally {
                DataBaseManager.close(con);
                con = null;
                apmManager = null;
                response.getWriter().write(joRtn.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getSlowQueryWithDateRange")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            String strGUID = null, strFromStartInterval = null, strToInterval = null;
            try {
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	strFromStartInterval = request.getParameter("startDate");
				strToInterval = request.getParameter("endDate");
            	strGUID = request.getParameter("guid");
        		joRtn = apmManager.getSlowQueryWithDateRange(con, strFromStartInterval, strToInterval, strGUID);
            } catch(Exception e) {
                LogManager.errorLog(e);
            } finally {
                DataBaseManager.close(con);
                con = null;
                apmManager = null;
                response.getWriter().write(joRtn.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getSecondaryCounter")) {
            JSONArray joAPMModules = null;
            ModuleManager apmManager = null;
            LoginUserBean loginBean = null;
            String guid = null;
            String strModuleCode = null;
            try {
                    apmManager = new ModuleManager();
                    con = DataBaseManager.giveConnection();
                    loginBean = new LoginUserBean();
                    loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
                    guid = request.getParameter("guid");
                    strModuleCode = request.getParameter("moduleCode");
                    joAPMModules = apmManager.getSecCounter(con, loginBean.getUserId(),strModuleCode,guid);
            } catch(Exception e) {
                    LogManager.errorLog(e);
            } finally {
                    DataBaseManager.close(con);
                    con = null;
                    apmManager = null;
                    response.getWriter().write(joAPMModules.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getModuleCounterData")) {
			// gets guids agent status and data for minichart (i.e. ASD cardlayout counters data)
			ModuleManager apmManager = null;
			LoginUserBean loginBean = null;
			
			JSONArray joRequest = null;
			JSONObject joRtnGUIDWiseData = null, joRtn = null;
			
			try {
				// get connection 
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				joRequest = JSONArray.fromObject(request.getParameter("moduleCounter"));
				
				apmManager = new ModuleManager();
				
				joRtnGUIDWiseData = apmManager.getAPMModuleCounters(con, loginBean, joRequest);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnGUIDWiseData);
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Module Counter Data.");
			} finally {
				apmManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/apm/getSecondaryCounterValues")) {
            JSONArray joAPMModules = null;
            ModuleManager apmManager = null;
            LoginUserBean loginBean = null;
            String guid = null;
            String strModuleCode = null;
            String counterId = null;
			try {
				apmManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				guid = request.getParameter("guid");
				strModuleCode = request.getParameter("moduleCode");
				counterId = request.getParameter("counterIds");
				joAPMModules = apmManager.getSecCounterValues(con, loginBean.getUserId(), strModuleCode, guid, counterId);
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				apmManager = null;
				response.getWriter().write(joAPMModules.toString());
			}
		} else if(strActionCommand.endsWith("/apm/getDDUserLicenseDetails")) {
			// gets deep dive license details from `userwise_lic_monthwise` and `dd_config_param` tables
			LoginUserBean loginUserBean = null;
			
			ModuleManager moduleManager = null;

			DDLicenseBean ddLicenseBean = null;
			
			JSONObject joRtn = null, joRtnDDUserLicenseDetails = null;
			
			try {
				moduleManager = new ModuleManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

                con = DataBaseManager.giveConnection();
                
				// gets license details from `userwise_lic_monthwise` and `dd_config_param` tables
				ddLicenseBean = moduleManager.getDDUserLicenseDetails(con, loginUserBean);
				
				if (ddLicenseBean != null) {
					joRtnDDUserLicenseDetails = ddLicenseBean.toJSON(); 
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(UtilsFactory.replaceNull(joRtnDDUserLicenseDetails, ""));
				
				loginUserBean = null;
				moduleManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDDUserLicenseDetails. ");
			} finally {
                DataBaseManager.close(con);
                con = null;
                
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/ltExecutionServiceFailed")) {
			JSONObject joRtn = null;
			ModuleManager moduleManager = null;
			try {
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				moduleManager.updateExecutionServiceFailedStatus(con);
				joRtn = UtilsFactory.getJSONSuccessReturn("Updated Appedo Private Counters");
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				DataBaseManager.rollbackConnection(con);

				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get ltExecutionServiceFailed.");
			} finally {
                DataBaseManager.close(con);
                con = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/getPostgresSlowQuery")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            String strGUID = null, strFromStartInterval = null;
            try {
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	strFromStartInterval = request.getParameter("fromStartInterval");
            	strGUID = request.getParameter("guid");
        		joRtn = apmManager.getPostgresSlowQuery(con, strFromStartInterval, strGUID, Constants.SLOW_QRY_LIMIT);
            } catch(Exception e) {
                LogManager.errorLog(e);
            } finally {
                DataBaseManager.close(con);
                con = null;
                apmManager = null;
                response.getWriter().write(joRtn.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getDatabaseSlowQuery")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            String strGUID = null, strFromStartInterval = null, strDatabaseType = null;            
            
            try {
            	strFromStartInterval = request.getParameter("fromStartInterval");
            	strGUID = request.getParameter("guid");
            	strDatabaseType = request.getParameter("databaseType");
            	
                loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                
        		joRtn = apmManager.getDatabaseSlowQuery(con, strFromStartInterval, strGUID, Constants.SLOW_QRY_LIMIT, strDatabaseType);
            } catch(Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn(e.getLocalizedMessage());
            } finally {
                DataBaseManager.close(con);
                con = null;
                apmManager = null;
                
                response.getWriter().write(joRtn.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getDatabaseSlowQueryWithDateRange")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            String strGUID = null, strFromStartInterval = null, strDatabaseType = null, strToInterval = null;            
            
            try {
            	strFromStartInterval = request.getParameter("startDate");
				strToInterval = request.getParameter("endDate");
            	strGUID = request.getParameter("guid");
            	strDatabaseType = request.getParameter("databaseType");
            	
                loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                
        		joRtn = apmManager.getDatabaseSlowQueryWithDateRange(con, strFromStartInterval, strToInterval, strGUID, Constants.SLOW_QRY_LIMIT, strDatabaseType);
            } catch(Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn(e.getLocalizedMessage());
            } finally {
                DataBaseManager.close(con);
                con = null;
                apmManager = null;
                
                response.getWriter().write(joRtn.toString());
            }
		} else if(strActionCommand.endsWith("/apm/getDatabaseSlowProcedure")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            String strGUID = null, strFromStartInterval = null, strDatabaseType = null;            
            
            try {
            	strFromStartInterval = request.getParameter("fromStartInterval");
            	strGUID = request.getParameter("guid");
            	strDatabaseType = request.getParameter("databaseType");
            	
            	loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                
            	joRtn = apmManager.getDatabaseSlowProcedure(con, strFromStartInterval, strGUID, Constants.SLOW_QRY_LIMIT, strDatabaseType);
            } catch(Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn(e.getLocalizedMessage());
            } finally {
                DataBaseManager.close(con);
                con = null;
                apmManager = null;
                
                response.getWriter().write(joRtn.toString());
            }

		} else if(strActionCommand.endsWith("/apm/getDatabaseSlowProcedureWithDateRange")) {
			JSONObject joRtn = null;
            ModuleManager apmManager = null;
            LoginUserBean loginUserBean = null;
            String strGUID = null, strFromStartInterval = null, strDatabaseType = null, strToInterval = null;            
            
            try {
            	strFromStartInterval = request.getParameter("startDate");
				strToInterval = request.getParameter("endDate");
            	strGUID = request.getParameter("guid");
            	strDatabaseType = request.getParameter("databaseType");
            	
            	loginUserBean = new LoginUserBean();
            	loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	
                apmManager = new ModuleManager();
                con = DataBaseManager.giveConnection();
                
            	joRtn = apmManager.getDatabaseSlowProcedureWithDateRange(con, strFromStartInterval, strToInterval, strGUID, Constants.SLOW_QRY_LIMIT, strDatabaseType);
            } catch(Exception e) {
                LogManager.errorLog(e);
                joRtn = UtilsFactory.getJSONFailureReturn(e.getLocalizedMessage());
            } finally {
                DataBaseManager.close(con);
                con = null;
                apmManager = null;
                
                response.getWriter().write(joRtn.toString());
            }

		} else if(strActionCommand.endsWith("/apm/setupASD")){
			// Create ASD all module tables view for this User.
			JSONObject joRtn = null;
			
			ModuleManager apmManager = null;
			ServiceManager serviceManager = null;
			
			long lUserId = -1L;
			
			long lServiceMapId = -1L;
			
			try {
				apmManager = new ModuleManager();
				serviceManager = new ServiceManager();
				
				con = DataBaseManager.giveConnection();
				
				lUserId = Long.parseLong(request.getParameter("user_id"));
				
				apmManager.createAllModuleLastCounterView(con, lUserId);
				
				// add user's system Service Map, where on add of ASD, RUM, SUM `uid/test_id`'s mapped, in the created Service Map  
				lServiceMapId = serviceManager.addUserSystemServiceMap(con, lUserId);
				
				//add user's set as default 
				serviceManager.addUserSetAsDefault(con, lUserId, lServiceMapId);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("ASD setup is done for the user.");
				
				DataBaseManager.commitConnection(con);
				
				serviceManager = null;
				apmManager = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to setup ASD.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/getAllASDModulesActiveAgents")) {
			// gets all ASD module's active agents 
			ModuleManager moduleManager = null;
			JSONObject joRtnModuleTypesActiveAgents = null, joRtn = null;

			LoginUserBean loginUserBean = null;
            
			try {
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
            	
				moduleManager = new ModuleManager();
				con = DataBaseManager.giveConnection();
				
				// 
				joRtnModuleTypesActiveAgents = moduleManager.getAllASDModulesActiveAgents(con, loginUserBean.getUserId());
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnModuleTypesActiveAgents);
                
				moduleManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get all ASD modules active agents.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				moduleManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/removeCounterFromMonitor")) {
			// update the counter to FALSE for particular guid/uid; remove counter from monitor for the particular guid/uid's
			Date dateLog = LogManager.logMethodStart();
			ModuleManager moduleManager = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null;
			String strGUID = null;
			
			try {
				moduleManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				Long lUID = Long.parseLong(request.getParameter("uid"));
				Long lCounterId = Long.parseLong(request.getParameter("counterId") );
				
				// update the counter to FALSE for particular guid/uid
				strGUID = moduleManager.removeCounterFromMonitor(con, lUID, lCounterId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Removed metric stopped in Agent.");
				
				DataBaseManager.commitConnection(con);
				// update selected counters to Collector; collector will update in agent
				moduleManager.updateSelectedCountersToCollector(con, strGUID);
				moduleManager = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to remove metric from monitor. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
			    LogManager.logMethodEnd(dateLog);
			    
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/apm/getRUMModuleDetails")) {
			// gets particular RUM uid's details, with configured threshold 
			ModuleManager moduleManager = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null, joModule = null;
			
			try {
				moduleManager = new ModuleManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong(request.getParameter("uid"));
				
				joModule = moduleManager.getRUMModuleDetails(con, lUId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joModule);
				
				moduleManager = null;
				loginUserBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get RUM module details.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}
