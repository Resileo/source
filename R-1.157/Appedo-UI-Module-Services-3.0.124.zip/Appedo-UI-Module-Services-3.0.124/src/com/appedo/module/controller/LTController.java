package com.appedo.module.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.LTLicenseBean;
import com.appedo.module.bean.LoadTestBean;
import com.appedo.module.bean.LoadTestSchedulerBean;
import com.appedo.module.bean.SummaryReportNotesBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.JmeterScriptManager;
import com.appedo.module.model.LTManager;
import com.appedo.module.model.LTScheduler;
import com.appedo.module.tcpserver.FloodgatesXMLAppend;
import com.appedo.module.utils.UtilsFactory;
import com.appedo.module.xml.AppedoXMLAppend;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

/**
 * to get the script details from scenarios xml which is located in the \
 * appedo repo
 * @author Anand
 *
 */
public class LTController extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	//static Properties prop = new Properties();
	static InputStream input = null;
	static String scenariosxmlPath="",floodgatesvuscriptsPath="",jmetervuscriptsPath="",expression="";
	/**
	 * do when post request comes
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	
	/**
	 * do when post request comes
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException,IOException{
		doAction(request, response);
	}
	
	/**
	 * To get the floodgates scripts from the scenario's xml
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("application/json");
		
		String strActionCommand = request.getRequestURI();
		
		if(strActionCommand.endsWith("/lt/getVUScripts")) {
			JSONArray javuscripts = null;
			LoginUserBean loginUserBean = null;
			LTManager manager = null;
			Connection con = null;
			
			try {
				con = DataBaseManager.giveConnection();
				manager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strTestType = request.getParameter("testTypeScript").trim();
				
				javuscripts = manager.getVUScripts(con, loginUserBean, strTestType);
				loginUserBean = null;
				manager = null;
				
			}catch(Exception ioe) {
				LogManager.errorLog(ioe);
			} finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(javuscripts.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getLTScripts")) {
			JSONArray javuscripts = null;
			LoginUserBean loginUserBean = null;
			LTManager manager = null;
			Connection con = null;
			JSONObject joRtn = null;
			
			try {
				con = DataBaseManager.giveConnection();
				manager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				javuscripts = manager.getLTScripts(con, loginUserBean);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(javuscripts);
				
				loginUserBean = null;
				manager = null;

			}catch(Exception ioe) {
				LogManager.errorLog(ioe);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get LT Scripts. ");
				
			} finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getLTScriptStatus")) {
			//JSONArray javuscripts = null;
			LoginUserBean loginUserBean = null;
			LTManager manager = null;
			Connection con = null;
			JSONObject joRtn = new JSONObject();
			long lScriptId = -1L;
			String strLTScriptStatus = null;
			JSONObject josetval = new JSONObject();
			
			try {
				con = DataBaseManager.giveConnection();
				manager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lScriptId = Long.valueOf(request.getParameter("scriptId"));
				strLTScriptStatus = manager.getLTScriptStatus(con,lScriptId);
				
				joRtn.put("success", true);
				joRtn.put("failure", false);
				josetval.put("script_id", lScriptId);
				josetval.put("status", strLTScriptStatus);
				joRtn.put("message", josetval);
		
				loginUserBean = null;
				manager = null;
				//System.out.println("LT Result :"+ javuscripts);
				
				
			}catch(Exception ioe) {
				LogManager.errorLog(ioe);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get LT Scripts. ");
				
			} finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getVUScenarios")) {
			
			JSONArray javuscripts = null;
			LoginUserBean loginUserBean = null;
			LTManager manager = null;
			Connection con = null;
			
			try {
				manager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();

				javuscripts = manager.getVUScenarios(con, loginUserBean);
				loginUserBean = null;
				manager = null;
				
			} catch(Throwable th) {
				LogManager.errorLog(th);
			} finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(javuscripts.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getLTScenarios")) {
			
			JSONArray javuscripts = null;
			LoginUserBean loginUserBean = null;
			LTManager manager = null;
			Connection con = null;
			JSONObject joRtn = null;
			
			try {
				manager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();

				javuscripts = manager.getLTScenarios(con, loginUserBean);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(javuscripts);
				loginUserBean = null;
				manager = null;
				
			}catch(Exception ioe) {
				LogManager.errorLog(ioe);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get LT Scenarios. ");
			} finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getDataFiles")) {
			
			JSONArray jaVariables = null;
			LoginUserBean loginUserBean = null;
			AppedoXMLAppend axa = null;
			String strVariablesFilePath = "";
			try {
				axa = new AppedoXMLAppend();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strVariablesFilePath = strVariablesFilePath + Constants.VARIABLESFOLDERPATH+File.separator+loginUserBean.getUserId()+"_variables.xml";
				String strTestType = request.getParameter("testTypeScript").trim();

				jaVariables = axa.getVariables(strVariablesFilePath);
				
			}catch(Exception ioe) {
				LogManager.errorLog(ioe);
			} finally{
				
				response.getWriter().write(jaVariables.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getLTDataFiles")) {
			
			JSONArray jaVariables = null;
			LoginUserBean loginUserBean = null;
			AppedoXMLAppend axa = null;
			String strVariablesFilePath = "";
			JSONObject joRtn = null;
			try {
				axa = new AppedoXMLAppend();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strVariablesFilePath = Constants.VARIABLESFOLDERPATH+File.separator+loginUserBean.getUserId()+"_variables.xml";

				jaVariables = axa.getLTVariables(strVariablesFilePath, loginUserBean);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaVariables);
				
			}catch(Exception ioe) {
				LogManager.errorLog(ioe);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get LT User Variables. ");
			} finally{
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getScriptwiseData")){
			LTManager runManager = null;
			JSONObject joScriptwise = null, joRtn = null;
			LoginUserBean loginUserBean = null;
			Connection con = null;
			try{
				runManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long runid = Long.valueOf(request.getParameter("runid").trim());
				String strTestType = request.getParameter("testTypeScript").trim();
				con = DataBaseManager.giveConnection();
				
				joScriptwise = runManager.getRunningScriptData(con, runid, loginUserBean.getUserId(), strTestType);
				joRtn = UtilsFactory.getJSONSuccessReturn(joScriptwise);
				
				loginUserBean = null;
				runManager = null;
				strTestType = null;
				joScriptwise = null;
				
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get ScriptwiseData.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getRunningScenarioForChart")){
			LTManager runManager = null;
			JSONObject joScriptwise = null, joRtn = null;
			Connection con = null;
			try{
				runManager = new LTManager();
				
				long runid = Long.valueOf(request.getParameter("runid").trim());
				con = DataBaseManager.giveConnection();
				
				joScriptwise = runManager.getRunningScriptDataForChart(con, runid);
				joRtn = UtilsFactory.getJSONSuccessReturn(joScriptwise);
				
				runManager = null;
				joScriptwise = null;
				
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get getRunningScenarioForChart.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getMasterSummaryReport")){
			LTManager ltManager = null;
			JSONObject joRtn = null;
			LoginUserBean loginUserBean = null;
			Connection con = null;
			String jsonString = null;
			try{
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long runid = Long.valueOf(request.getParameter("runid").trim());
				String strTestType = request.getParameter("testTypeScript").trim();
				con = DataBaseManager.giveConnection();
				
				String outputFilePath=null;
				outputFilePath = Constants.SUMMARYREPORTPATH_SHIPPING+runid;
				String filename = null;
				filename = "lt_summary_report_"+runid+".json";
				if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
					jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
					if((jsonString.length()==0)||(jsonString==null)){
						jsonString = ltManager.getMasterSummaryReport(con, runid, loginUserBean.getUserId(), strTestType);
						if(jsonString !=null){
							if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
								jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
							}else{
								jsonString = null;
							}
						}
					}
				}else{
					UtilsFactory.createParentDirectory(outputFilePath);
					jsonString = ltManager.getMasterSummaryReport(con, runid, loginUserBean.getUserId(), strTestType);
					if(jsonString !=null){
						if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
							jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
						}else{
							jsonString = null;
						}
					}
				}
				
				if(jsonString !=null){
					joRtn = UtilsFactory.getJSONSuccessReturn(jsonString);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn(jsonString);
				}
				
				loginUserBean = null;
				ltManager = null;
				strTestType = null;
				jsonString = null;
				
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get MasterSummaryReport.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getScriptSummaryReport")){
			LTManager ltManager = null;
			JSONArray joReportsArray = null;
			JSONObject joRtn = null;
			Connection con = null;
			try {
				ltManager = new LTManager();
				String runid = request.getParameter("runid").trim();
				String strTestTypeScript = request.getParameter("testTypeScript").trim();
				String scriptIds = request.getParameter("scriptIds")==null?"":request.getParameter("scriptIds");
				String[] script_Ids = scriptIds.split(",");
				String jsonString = null;
				con = DataBaseManager.giveConnection();
				String outputFilePath=null;
				String filename = null;
				if ( strTestTypeScript.equals(Constants.APPEDO_LT) ) {
					joReportsArray = new JSONArray();
					outputFilePath = Constants.SUMMARYREPORTPATH_SHIPPING+runid;
					for(int i=0;i<script_Ids.length; i++){
						filename = "lt_scriptwise_"+runid+"_"+script_Ids[i]+".json";
						if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
							jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
							if((jsonString.length()==0)||(jsonString==null)){
								jsonString = ltManager.getScriptSummaryReport(con, runid, strTestTypeScript, script_Ids[i]);
								if(jsonString!=null){
									if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
										jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
									}else{
										jsonString = null;
									}
								}
							}
						}else{
							jsonString = ltManager.getScriptSummaryReport(con, runid, strTestTypeScript, script_Ids[i]);
							if(jsonString!=null){
								if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
									jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
								}else{
									jsonString = null;
								}
							}
						}
						if(jsonString !=null){
							joReportsArray.add(jsonString);
						}
					}
					joRtn = UtilsFactory.getJSONSuccessReturn(joReportsArray);
				}
				
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get ScriptSummaryReport.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getChildSummaryReportScriptWise")){
			LTManager ltManager = null;
			
			JSONObject joReports = null;
			JSONObject joRtn = null;
			String jsonString = null;
			
			Connection con = null;
			try {
				ltManager = new LTManager();

				String runid = request.getParameter("runid").trim();
				String strTestTypeScript = request.getParameter("testTypeScript").trim();
				String scriptId = request.getParameter("scriptId")==null?"":request.getParameter("scriptId");
				String reportType = request.getParameter("reportType")==null?"":request.getParameter("reportType");
				String outputFilePath=null;
				String filename = null;
				
				con = DataBaseManager.giveConnection();
				if ( strTestTypeScript.equals(Constants.APPEDO_LT) ) {
					outputFilePath = Constants.SUMMARYREPORTPATH_SHIPPING+runid;
					joReports = new JSONObject();
					filename = "";
					
					if(reportType.equalsIgnoreCase(Constants.REQUEST_RESPONSE)){
						filename = "lt_script_requestwise_"+runid+"_"+scriptId+".json";
						if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
							jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
							if((jsonString.length()==0)||(jsonString==null)){
								jsonString = ltManager.getSummaryDataForRequestResponse(con, runid, strTestTypeScript, scriptId);
								if(jsonString !=null){
									if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
										jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
									}else{
										jsonString = null;
									}
								}
							}
						}else{
							jsonString = ltManager.getSummaryDataForRequestResponse(con, runid, strTestTypeScript, scriptId);
							if(jsonString !=null){
								if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
									jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
								}else{
									jsonString = null;
								}
							}
						}
					}else if(reportType.equalsIgnoreCase(Constants.CONTAINER_RESPONSE)){
						filename = "lt_script_contwise_"+runid+"_"+scriptId+".json";
						if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
							jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
							if((jsonString.length()==0)||(jsonString==null)){
								jsonString = ltManager.getSummaryDataForContainerResponse(con, runid, strTestTypeScript, scriptId);
								if(jsonString !=null){
									if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
										jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
									}else{
										jsonString = null;
									}
								}
							}
						}else{
							jsonString = ltManager.getSummaryDataForContainerResponse(con, runid, strTestTypeScript, scriptId);
							if(jsonString !=null){
								if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
									jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
								}else{
									jsonString = null;
								}
							}
						}
						
					}else if(reportType.equalsIgnoreCase(Constants.TRANSACTION_RESPONSE)){
						filename = "lt_transaction_summary_"+runid+"_"+scriptId+".json";
						if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
							jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
							if((jsonString.length()==0)||(jsonString==null)){
								jsonString = ltManager.getSummaryDataForTransactionResponse(con, runid, strTestTypeScript, scriptId);
								if(jsonString !=null){
									if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
										jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
									}else{
										jsonString = null;
									}
								}
							}
						}else{
							jsonString = ltManager.getSummaryDataForTransactionResponse(con, runid, strTestTypeScript, scriptId);
							if(jsonString !=null){
								if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
									jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
								}else{
									jsonString = null;
								}
							}
						}
					}else if(reportType.equalsIgnoreCase(Constants.ERROR_COUNT)){
						filename = "lt_rep_error_msg_summary_"+runid+"_"+scriptId+".json";
						if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
							jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
							if((jsonString.length()==0)||(jsonString==null)){
								jsonString = ltManager.getSummaryDataForErrorCount(con, runid, strTestTypeScript, scriptId);
								if(jsonString !=null){
									if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
										jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
									}else{
										jsonString = null;
									}
								}
							}
						}else{
							jsonString = ltManager.getSummaryDataForErrorCount(con, runid, strTestTypeScript, scriptId);
							if(jsonString !=null){
								if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
									jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
								}else{
									jsonString = null;
								}
							}
						}
					}else if(reportType.equalsIgnoreCase(Constants.ERROR_DESCRIPTION)){
						filename = "lt_error_count_"+runid+"_"+scriptId+".json";
						if(UtilsFactory.checkFileExistsForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
							jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
							if((jsonString.length()==0)||(jsonString==null)){
								jsonString = ltManager.getSummaryDataForErrorDescription(con, runid, strTestTypeScript, scriptId);
								if(jsonString !=null){
									if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
										jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
									}else{
										jsonString = null;
									}
								}
							}
						}else{
							jsonString = ltManager.getSummaryDataForErrorDescription(con, runid, strTestTypeScript, scriptId);
							if(jsonString !=null){
								if(UtilsFactory.createFileForShipping(jsonString, "true", outputFilePath+Constants.FILE_STRING_SEPARATOR+filename)){
									jsonString = UtilsFactory.readFileForShipping(outputFilePath+Constants.FILE_STRING_SEPARATOR+filename);
								}else{
									jsonString = null;
								}
							}
						}
					}
					if(jsonString !=null){
						joReports.put("summaryData", jsonString);
					}else{
						joReports.put("summaryData", "[]");
					}
					joRtn = UtilsFactory.getJSONSuccessReturn(joReports);
				}
				
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get ChildSummaryReportScriptWise.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
				
				// Clearing the used Objects
				jsonString = null;
				UtilsFactory.clearCollectionHieracy(joReports);
				joReports = null;
				UtilsFactory.clearCollectionHieracy(joRtn);
				joRtn = null;
				
			}
		} else if(strActionCommand.endsWith("/lt/runManualSummaryReport")){
			LTManager ltManager = null;
			JSONObject joRtn = null;
			Connection con = null;
			Boolean status = false;
			String runid = request.getParameter("runid").trim();
			try {
				ltManager = new LTManager();

				con = DataBaseManager.giveConnection();
				ltManager.updateReportMaster(con, Long.parseLong(runid), Constants.MANUAL_REPORT_PREPARATION_STARTED);
				DataBaseManager.commitConnection(con);
				Calendar cal = Calendar.getInstance();
				Constants.MANUAL_REPORT_START_TIME = cal.getTimeInMillis();
				if(ltManager.manualReportPreparation(con, Long.parseLong(runid))){
					status = ltManager.manualReportGeneration(con, Long.parseLong(runid));
				}
				if(status){
					cal = Calendar.getInstance();
					ltManager.updateManualReportRuntime(con, Long.parseLong(runid), cal.getTimeInMillis() - Constants.MANUAL_REPORT_START_TIME);
					Constants.MANUAL_REPORT_START_TIME = 0;
					joRtn = UtilsFactory.getJSONSuccessReturn(Constants.MANUAL_REPORT_GENERATION_COMPLETED);
					UtilsFactory.removeFolderForShipping(Constants.SUMMARYREPORTPATH_SHIPPING+runid);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("Problem in Manual Report Generation");
				}
				DataBaseManager.commitConnection(con);

				ltManager = null;
			} catch (Throwable e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				DataBaseManager.rollbackConnection(con);
				try {
					ltManager.updateReportMaster(con, Long.parseLong(runid), Constants.MANUAL_REPORT_GENERATION_FAILED);
					DataBaseManager.commitConnection(con);
				} catch (Exception e1) {
					LogManager.errorLog("LT Report Status Updation Failed For Runid :: "+runid +" ,Status :: "+Constants.MANUAL_REPORT_GENERATION_FAILED);
					LogManager.errorLog(e1);
					e1.printStackTrace();
				}
				joRtn = UtilsFactory.getJSONFailureReturn("Problem in Manual Report Generation");
			}finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getScenarioReports")){
			// gets user's load test type `APPEDO_LT/JMETER`'s all reports OR particular scenario reports 
			LTManager ltManager = null;
			
			JSONArray jaRtnReports = null;
			JSONObject joRtn = null;
			
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			Long lScenarioId = null;
			String strLoadTestType = "";
			
			try {
				ltManager = new LTManager();

				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				if ( request.getParameter("scenarioid") != null ) {
					lScenarioId = Long.valueOf(request.getParameter("scenarioid"));
				}
				strLoadTestType = request.getParameter("testTypeScript");
				
				// gets user's load test type's all reports OR scenario's reports
				jaRtnReports = ltManager.getScenarioReports(con, lScenarioId, strLoadTestType, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnReports);
				
				ltManager = null;
				loginUserBean = null;
				strLoadTestType = null;
				jaRtnReports = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get ScenarioReports.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/logReport")){

			LTManager ltManager = null;
			JSONArray jaResults = null;
			JSONObject joRtn = null;
			LoginUserBean loginUserBean = null;
			Connection con = null;
			try {
				ltManager = new LTManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long runid = Long.valueOf(request.getParameter("runid").trim());
				
				con = DataBaseManager.giveConnection();
				jaResults = ltManager.getLogReports(con, runid);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaResults);
				
				ltManager = null;
				loginUserBean = null;
				jaResults = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get logReport.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getCSVlogReportdata")){

			LTManager ltManager = null;
			JSONArray jaResults = null;
			JSONObject joRtn = null;
			Connection con = null;
			try {
				ltManager = new LTManager();
				long runid = Long.valueOf(request.getParameter("runid").trim());

				con = DataBaseManager.giveConnection();
				jaResults = ltManager.getLogReports(con, runid);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaResults);

				ltManager = null;
				jaResults = null;

			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get logReport CSV data.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/errorReport")){

			LTManager ltManager = null;
			JSONArray jaResults = null;
			JSONObject joRtn = null;
			LoginUserBean loginUserBean = null;
			Connection con = null;
			try {
				ltManager = new LTManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long runid = Long.valueOf(request.getParameter("runid").trim());
				
				con = DataBaseManager.giveConnection();
				jaResults = ltManager.getErrorReports(con, runid);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaResults);
				
				ltManager = null;
				loginUserBean = null;
				jaResults = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get errorReport.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("lt/readRegions")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONArray jaRtnRegions = null;
			JSONObject joRtn = null;
			LTManager ltManager = null;
			String testTypeScript = null, osType = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				testTypeScript = request.getParameter("testTypeScript").trim();
				if( testTypeScript.equalsIgnoreCase("JMETER") ){
					osType = "FEDORA";
				}else{
					osType = "WINDOWS";
				}
				jaRtnRegions = ltManager.getRegions(con, loginUserBean, osType);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnRegions);
				
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get readRegions.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				testTypeScript = null;
				osType = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/summaryReport")){
			// Jmeter report
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtnReportDetails = null;
			
			LTManager ltManager = null;
			
			//String strRtnReportHTMLFilePath = "", strXMLPath = "", strXSLTPath = "", strGenereateFilePath = "";
			String strHTMLSummaryReportPath = "";
			
			try {
				ltManager = new LTManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lRunId = Long.valueOf(request.getParameter("runid").trim());
				
				con = DataBaseManager.giveConnection();
				
				joRtnReportDetails = ltManager.getReportDetails(con, lRunId);
				/* 
				 * used for older report generation
				
				if(joRtnReportDetails.getString("reporttype").equals("JMETER")) {
					strXMLPath = Constants.JMETERSUMMARYREPORTPATH + joRtnReportDetails.getString("runid") + ".xml";
					strXSLTPath = Constants.JMETERSUMMARYREPORTPATH + "reportjmeter.xslt";
					strGenereateFilePath = Constants.JMETERSUMMARYREPORTPATH;
				} else if( joRtnReportDetails.getString("reporttype").equals("APPEDO_LT") ) {
					strXMLPath = Constants.SUMMARYREPORTPATH + joRtnReportDetails.getString("runid") + ".xml";
					strXSLTPath = Constants.SUMMARYREPORTPATH + "report.xslt";
					strGenereateFilePath = Constants.SUMMARYREPORTPATH;
				}
				strRtnReportHTMLFilePath = ltManager.generateReport(joRtnReportDetails, strXMLPath, strXSLTPath, strGenereateFilePath);

				strHTMLSummaryReportPath = Constants.JMETERSUMMARYREPORTPATH + lRunId + File.separator + ""
				ltManager.writeFileInResponse(strRtnReportHTMLFilePath, response.getWriter());
				
				strXMLPath = null;
				strXSLTPath = null;
				strGenereateFilePath = null;
				strRtnReportHTMLFilePath = null;
				*/
				
				strHTMLSummaryReportPath = Constants.JMETERSUMMARYREPORTPATH + lRunId + File.separator + joRtnReportDetails.getString("scenarioname")+".html";
				ltManager.writeFileInResponse(strHTMLSummaryReportPath, response.getWriter());
				
				strHTMLSummaryReportPath = null;
				ltManager = null;
				loginUserBean = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
			}finally {
				DataBaseManager.close(con);
				con = null;
			}
		} else if(strActionCommand.endsWith("/lt/mappingScripts")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null;
			
			LTManager ltManager = null;
			
			String strTestTypeScript = null, strScenarioName = null, strFilepath = null;//, scriptIds = null;
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = null;
			Document doc =  null;
			NodeList nodeListScenarios = null;
			Node rootElement = null;
			Node nodeScenarios = null;
			Element elementScenario = null;
			TransformerFactory transformerFactory = null;
			Transformer transformer = null;
			DOMSource source = null;
			StreamResult result = null;
			
			try {
				// String scriptNames = null;
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				strTestTypeScript = request.getParameter("testTypeScript").trim();
				strScenarioName = request.getParameter("scenarioName").trim();
				// scriptNames = request.getParameter("scriptNames");
				// scriptIds = request.getParameter("scriptIds");
				
				JSONArray jaScripts = new JSONArray();
				if( request.getParameter("scriptDetails") != null ){
					jaScripts = JSONArray.fromObject(request.getParameter("scriptDetails"));
				}
				
				//System.out.println("jaArray: "+jaArray.size());
				long lScenarioId = ltManager.insertScenarioName(con, strScenarioName, strTestTypeScript, loginUserBean);
				if ( lScenarioId > 0 ){
					// try {
					docBuilder = docFactory.newDocumentBuilder();
					// root elements "scenarios"
					strFilepath = Constants.FLOODGATESSCENARIOXMLFOLDERPATH+File.separator+loginUserBean.getUserId()+"_scenarios.xml";
					if( new FloodgatesXMLAppend().isScenarioFileExist(strFilepath) ){
						doc = docBuilder.parse(strFilepath);
						nodeListScenarios = doc.getElementsByTagName("scenario");
						if( nodeListScenarios.getLength() == 0 ) {
							//scenarioid = 0;
							rootElement = doc.getFirstChild();
							nodeScenarios = doc.getElementsByTagName("scenarios").item(0);
							//scenarioId = String.valueOf(scenarioid + 1);
							elementScenario = doc.createElement("scenario");
							elementScenario.setAttribute("enableipspoofing", "False");
							
							elementScenario.setAttribute("id", String.valueOf(lScenarioId) );
							
							elementScenario.setAttribute("name", strScenarioName);
							nodeScenarios.appendChild(elementScenario);
							for ( int i= 0; i< jaScripts.size(); i++ ){
								JSONObject joObject = jaScripts.getJSONObject(i);
								Element elementScript = doc.createElement("script");			
								elementScript.setAttribute("id", joObject.getString("script_id"));
								elementScript.setAttribute("name", joObject.getString("scriptName"));
								elementScenario.appendChild(elementScript);
								JSONObject joSetting = new JSONObject();
								if( joObject.get("settings") != null){
									joSetting = JSONObject.fromObject(joObject.get("settings"));
								}
								Element eleScriptSetting = doc.createElement("setting");
								if( joSetting.size() > 0){
									eleScriptSetting.setAttribute("browsercache", joSetting.getString("browsercache"));
									eleScriptSetting.setAttribute("durationtime", joSetting.getString("durationtime"));
									eleScriptSetting.setAttribute("incrementtime", joSetting.getString("incrementtime"));
									eleScriptSetting.setAttribute("incrementuser", joSetting.getString("incrementuser"));
									eleScriptSetting.setAttribute("iterations", joSetting.getString("iterations"));			
									eleScriptSetting.setAttribute("maxuser", joSetting.getString("maxuser"));		
									eleScriptSetting.setAttribute("startuser", joSetting.getString("startuser"));
									eleScriptSetting.setAttribute("currentloadgenid", joSetting.getString("currentloadgenid"));
									eleScriptSetting.setAttribute("durationmode", joSetting.getString("durationmode"));
									eleScriptSetting.setAttribute("startuserid", joSetting.getString("startuserid"));
									eleScriptSetting.setAttribute("totalloadgen", joSetting.getString("totalloadgen"));
									eleScriptSetting.setAttribute("type", joSetting.getString("type"));
								} else {
									// sets default script settings
									AppedoXMLAppend.setDefaultScriptSettings(eleScriptSetting);
								}
								elementScript.appendChild(eleScriptSetting);
							}
						} else {
							//int mnum = nodeListScenarios.getLength() - 1;
							String[] strUserScenarioName = new String[nodeListScenarios.getLength()];
							for(int i=0; i<nodeListScenarios.getLength(); i++){
								Node mnode = (Node) nodeListScenarios.item(i);
								String scenario = mnode.getAttributes().getNamedItem("name").getNodeValue();
								strUserScenarioName[i] = scenario;
								scenario = null;
							}/*
							for (int i=mnum; i<nodeListScenarios.getLength(); i++) {
								Node mnode = (Node) nodeListScenarios.item(i);
								//scenarioid = Integer.parseInt(mnode.getAttributes().getNamedItem("id").getNodeValue());
							}*/
							rootElement = doc.getFirstChild();
							nodeScenarios = doc.getElementsByTagName("scenarios").item(0);
							
							//scenarioId = String.valueOf(scenarioid + 1);
							boolean isExist = false;
							for(int i=0; i<strUserScenarioName.length;i++){
								if(strUserScenarioName[i].equalsIgnoreCase(strScenarioName)){
									isExist = true;
								}
							}
							
							if(isExist){
								joRtn = UtilsFactory.getJSONFailureReturn("Scenario name already exist.");
							} else {
								elementScenario = doc.createElement("scenario");
								elementScenario.setAttribute("enableipspoofing", "False");
								
								elementScenario.setAttribute("id", String.valueOf(lScenarioId) );
								elementScenario.setAttribute("name", strScenarioName);
								nodeScenarios.appendChild(elementScenario);
								for ( int i= 0; i< jaScripts.size(); i++ ){
									JSONObject joObject = jaScripts.getJSONObject(i);
									Element elementScript = doc.createElement("script");			
									elementScript.setAttribute("id", joObject.getString("script_id"));
									elementScript.setAttribute("name", joObject.getString("scriptName"));
									elementScenario.appendChild(elementScript);
									JSONObject joSetting = new JSONObject();
									if( joObject.get("settings") != null){
										joSetting = JSONObject.fromObject(joObject.get("settings"));
									}
									Element eleScriptSetting = doc.createElement("setting");
									if( joSetting.size() > 0){
										eleScriptSetting.setAttribute("browsercache", joSetting.getString("browsercache"));
										eleScriptSetting.setAttribute("durationtime", joSetting.getString("durationtime"));
										eleScriptSetting.setAttribute("incrementtime", joSetting.getString("incrementtime"));
										eleScriptSetting.setAttribute("incrementuser", joSetting.getString("incrementuser"));
										eleScriptSetting.setAttribute("iterations", joSetting.getString("iterations"));			
										eleScriptSetting.setAttribute("maxuser", joSetting.getString("maxuser"));		
										eleScriptSetting.setAttribute("startuser", joSetting.getString("startuser"));
										eleScriptSetting.setAttribute("currentloadgenid", joSetting.getString("currentloadgenid"));
										eleScriptSetting.setAttribute("durationmode", joSetting.getString("durationmode"));
										eleScriptSetting.setAttribute("startuserid", joSetting.getString("startuserid"));
										eleScriptSetting.setAttribute("totalloadgen", joSetting.getString("totalloadgen"));
										eleScriptSetting.setAttribute("type", joSetting.getString("type"));
									} else {
										// sets default script settings
										AppedoXMLAppend.setDefaultScriptSettings(eleScriptSetting);
									}
									elementScript.appendChild(eleScriptSetting);
								}
							}
						}
						
						transformerFactory = TransformerFactory.newInstance();
						transformer = transformerFactory.newTransformer();
						source = new DOMSource(doc);
						result = new StreamResult(strFilepath);
						
						transformer.transform(source, result);
					}
					LogManager.infoLog("File saved!");
					
					ltManager.mappingScripts(con, loginUserBean, strTestTypeScript, strScenarioName, jaScripts, lScenarioId);
					joRtn = UtilsFactory.getJSONSuccessReturn("Scenario added.");
					joRtn.put("scenario_id", lScenarioId);
					joRtn.put("scenarioName", strScenarioName);
					
					DataBaseManager.commitConnection(con);
				}

			  } catch (ParserConfigurationException pce) {
				  LogManager.errorLog(pce);
			  } catch (TransformerException tfe) {
				  LogManager.errorLog(tfe);
			  } catch(Exception e) {
				LogManager.errorLog(e);
				if(e.getMessage().equals("1")){
					joRtn = UtilsFactory.getJSONFailureReturn("Scenario Name already exist");
				}else if(e.getMessage().equals("2")){
					joRtn = UtilsFactory.getJSONFailureReturn("License expired. Please contact appedo.com. ");
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map scripts with scenarios.");
				}
				// joRtn = UtilsFactory.getJSONFailureReturn("Unable to add Scenario");
				
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				strTestTypeScript = null;
				strScenarioName = null;
				// scriptIds = null;

				loginUserBean = null;
				docBuilder = null;
				doc =  null;
				nodeListScenarios = null;
				rootElement = null;
				nodeScenarios = null;
				elementScenario = null;
				transformerFactory = null;
				transformer = null;
				source = null;
				result = null;
				strFilepath = null;
				// scenarioId = null;
				strScenarioName = null;
				// scriptNames = null;
				loginUserBean = null;
				ltManager = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/editScenarios")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null, joScenarioDetails = null;
			LTManager ltManager = null;
			String testTypeScript = null;
			
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				testTypeScript = request.getParameter("testTypeScript").trim();
				long scenarioId = Long.valueOf(request.getParameter("scenarioId").trim());
				joScenarioDetails = ltManager.getScenarioDetails(con, scenarioId, testTypeScript, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(joScenarioDetails);
				joScenarioDetails = null;
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to edit Scenarios.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				testTypeScript = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/updateScenarios")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			LTLicenseBean ltLicBean = null;
			JSONObject joRtn = null;
			LTManager ltManager = null;
			String strTestTypeScript = null, strScenarioName = null;//, scriptIds = null, scriptNames = null;
			
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				ltLicBean = ltManager.getLTLicenseDetails(con, loginUserBean);
				if(ltLicBean == null){
					throw new Exception("2");
				} else{
					strTestTypeScript = request.getParameter("testTypeScript").trim();
					strScenarioName = request.getParameter("scenarioName").trim();
					long lScenarioId = Long.valueOf(request.getParameter("scenarioId").trim());
//					scriptIds = request.getParameter("scriptIds").trim();
//					scriptNames = request.getParameter("scriptNames");
					JSONArray jaArray = new JSONArray();
					if ( request.getParameter("scriptDetails") != null ){
						jaArray = JSONArray.fromObject(request.getParameter("scriptDetails"));
					}
					DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
					
					DocumentBuilder docBuilder = null;
					Document doc =  null;
					NodeList mentries = null;
					Node rootElement = null;
					Node scenarios = null;
					Element scenarioElement = null;
					TransformerFactory transformerFactory = null;
					Transformer transformer = null;
					DOMSource source = null;
					StreamResult result = null;
					
					String filepath = null;
					
					try {
						docBuilder = docFactory.newDocumentBuilder();
						filepath = Constants.FLOODGATESSCENARIOXMLFOLDERPATH+File.separator+loginUserBean.getUserId()+"_scenarios.xml";
						new FloodgatesXMLAppend().deleteScenario(String.valueOf(lScenarioId), strScenarioName, filepath);
						if(new FloodgatesXMLAppend().isScenarioFileExist(filepath)){
							doc = docBuilder.parse(filepath);
							mentries = doc.getElementsByTagName("scenario");
							if(mentries.getLength() == 0)
							{
								//scenarioid = 0;
								rootElement = doc.getFirstChild();
								scenarios = doc.getElementsByTagName("scenarios").item(0);
								//scenarioId = String.valueOf(scenarioid + 1);
								scenarioElement = doc.createElement("scenario");
								scenarioElement.setAttribute("enableipspoofing", "False");
								
								
								scenarioElement.setAttribute("id", String.valueOf(lScenarioId) );
								scenarioElement.setAttribute("name", strScenarioName);
								scenarios.appendChild(scenarioElement);
								for ( int i= 0; i< jaArray.size(); i++ ){
									JSONObject joObject = jaArray.getJSONObject(i);
									Element elementScript = doc.createElement("script");			
									elementScript.setAttribute("id", joObject.getString("script_id"));
									elementScript.setAttribute("name", joObject.getString("scriptName"));
									scenarioElement.appendChild(elementScript);
									JSONObject joSetting = new JSONObject();
									if( joObject.get("settings") != null){
										joSetting = JSONObject.fromObject(joObject.get("settings"));
									}
									Element eleScriptSetting = doc.createElement("setting");
									if( joSetting.size() > 0){
										eleScriptSetting.setAttribute("browsercache", joSetting.getString("browsercache"));
										eleScriptSetting.setAttribute("durationtime", joSetting.getString("durationtime"));
										eleScriptSetting.setAttribute("incrementtime", joSetting.getString("incrementtime"));
										eleScriptSetting.setAttribute("incrementuser", joSetting.getString("incrementuser"));
										eleScriptSetting.setAttribute("iterations", joSetting.getString("iterations"));			
										eleScriptSetting.setAttribute("maxuser", joSetting.getString("maxuser"));		
										eleScriptSetting.setAttribute("startuser", joSetting.getString("startuser"));
										eleScriptSetting.setAttribute("currentloadgenid", joSetting.getString("currentloadgenid"));
										eleScriptSetting.setAttribute("durationmode", joSetting.getString("durationmode"));
										eleScriptSetting.setAttribute("startuserid", joSetting.getString("startuserid"));
										eleScriptSetting.setAttribute("totalloadgen", joSetting.getString("totalloadgen"));
										eleScriptSetting.setAttribute("type", joSetting.getString("type"));
									} else {
										// sets default script settings
										AppedoXMLAppend.setDefaultScriptSettings(eleScriptSetting);
									}
									elementScript.appendChild(eleScriptSetting);
								}
							}
							else
							{
								int mnum = mentries.getLength() - 1;
								String[] strUserScenarioName = new String[mentries.getLength()];
								for(int i=0; i<mentries.getLength(); i++){
									Node mnode = (Node) mentries.item(i);
									String scenario = mnode.getAttributes().getNamedItem("name").getNodeValue();
									strUserScenarioName[i] = scenario;
									scenario = null;
								}
								for (int i=mnum; i<mentries.getLength(); i++) 
								{
									Node mnode = (Node) mentries.item(i);
									//scenarioid = Integer.parseInt(mnode.getAttributes().getNamedItem("id").getNodeValue());
								}
								rootElement = doc.getFirstChild();
								scenarios = doc.getElementsByTagName("scenarios").item(0);
								
								//scenarioId = String.valueOf(scenarioid + 1);
								boolean isExist = false;
								for(int i=0; i<strUserScenarioName.length;i++){
									if(strUserScenarioName[i].equalsIgnoreCase(strScenarioName)){
										isExist = true;
									}
								}
								
								if(isExist){
									joRtn = UtilsFactory.getJSONFailureReturn("Scenario name already exist.");
								}else{
									scenarioElement = doc.createElement("scenario");
									scenarioElement.setAttribute("enableipspoofing", "False");
									
									scenarioElement.setAttribute("id", String.valueOf(lScenarioId) );
									scenarioElement.setAttribute("name", strScenarioName);
									scenarios.appendChild(scenarioElement);
									
									for ( int i= 0; i< jaArray.size(); i++ ){
										JSONObject joObject = jaArray.getJSONObject(i);
										Element elementScript = doc.createElement("script");			
										elementScript.setAttribute("id", joObject.getString("script_id"));
										elementScript.setAttribute("name", joObject.getString("scriptName"));
										scenarioElement.appendChild(elementScript);
										JSONObject joSetting = new JSONObject();
										if( joObject.get("settings") != null){
											joSetting = JSONObject.fromObject(joObject.get("settings"));
										}
										Element eleScriptSetting = doc.createElement("setting");
										if( joSetting.size() > 0){
											eleScriptSetting.setAttribute("browsercache", joSetting.getString("browsercache"));
											eleScriptSetting.setAttribute("durationtime", joSetting.getString("durationtime"));
											eleScriptSetting.setAttribute("incrementtime", joSetting.getString("incrementtime"));
											eleScriptSetting.setAttribute("incrementuser", joSetting.getString("incrementuser"));
											eleScriptSetting.setAttribute("iterations", joSetting.getString("iterations"));			
											eleScriptSetting.setAttribute("maxuser", joSetting.getString("maxuser"));		
											eleScriptSetting.setAttribute("startuser", joSetting.getString("startuser"));
											eleScriptSetting.setAttribute("currentloadgenid", joSetting.getString("currentloadgenid"));
											eleScriptSetting.setAttribute("durationmode", joSetting.getString("durationmode"));
											eleScriptSetting.setAttribute("startuserid", joSetting.getString("startuserid"));
											eleScriptSetting.setAttribute("totalloadgen", joSetting.getString("totalloadgen"));
											eleScriptSetting.setAttribute("type", joSetting.getString("type"));
										} else {
											// sets default script settings
											AppedoXMLAppend.setDefaultScriptSettings(eleScriptSetting);
										}
										elementScript.appendChild(eleScriptSetting);
									}
								}
							}
							
							transformerFactory = TransformerFactory.newInstance();
							transformer = transformerFactory.newTransformer();
							source = new DOMSource(doc);
							result = new StreamResult(filepath);
							
							transformer.transform(source, result);
						}
						
						LogManager.infoLog("File saved!");
						ltManager.updateScenarios(con, loginUserBean, strTestTypeScript, strScenarioName, lScenarioId, jaArray);
						joRtn = UtilsFactory.getJSONSuccessReturn("Scenario Updated");
						joRtn.put("scenario_id", lScenarioId);
						joRtn.put("scenarioName", strScenarioName);
	
						DataBaseManager.commitConnection(con);
						
					  } catch (ParserConfigurationException pce) {
						pce.printStackTrace();
					  } catch (TransformerException tfe) {
						tfe.printStackTrace();
					  }catch (Exception tfe) {
						tfe.printStackTrace();
						if( tfe.getMessage().equals("SESSION_EXPIRED") ) {
							throw new ServletException("SESSION_EXPIRED");
						}
					  } catch (Throwable t) {
							t.printStackTrace();
					  }finally{
						  docBuilder = null;
						  doc =  null;
						  mentries = null;
						  rootElement = null;
						  scenarios = null;
						  scenarioElement = null;
						  transformerFactory = null;
						  transformer = null;
						  source = null;
						  result = null;
						  filepath = null;
						 // scenarioId = null;
						  strScenarioName = null;
						  
					  }

					loginUserBean = null;
					ltLicBean = null;
					ltManager = null;
				}
			} catch(Exception e) {
				LogManager.errorLog(e);
				if(e.getMessage().equalsIgnoreCase("2")){
					joRtn = UtilsFactory.getJSONFailureReturn("License expired. Please contact appedo.com.");
				}
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to map scripts with scenarios.");
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				strTestTypeScript = null;
				strScenarioName = null;
//				scriptIds = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/deleteScenarios")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null;
			LTManager ltManager = null;
			String testTypeScript = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				testTypeScript = request.getParameter("testTypeScript").trim();
				long scenarioId = Long.valueOf(request.getParameter("scenarioId").trim());
				long completedRuns = ltManager.scenarioReferenceFromReportMaster(con, loginUserBean.getUserId(), scenarioId);
				String scenarioName = request.getParameter("scenarioName");
				if( completedRuns > 0 ){
					joRtn = UtilsFactory.getJSONFailureReturn("Scenario has reference with Run and Report. Hence, cannot be deleted.");
				} else {
					String filepath = Constants.FLOODGATESSCENARIOXMLFOLDERPATH+File.separator+loginUserBean.getUserId()+"_scenarios.xml";
					new FloodgatesXMLAppend().deleteScenario(String.valueOf(scenarioId), scenarioName, filepath);
					ltManager.deleteScenarios(con, loginUserBean, testTypeScript, scenarioId);
					joRtn = UtilsFactory.getJSONSuccessReturn("Scenario Deleted");
				}
				
				DataBaseManager.commitConnection(con);
				
				loginUserBean = null;
				ltManager = null;
				
			} catch(Throwable e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to map scripts with scenarios.");
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				testTypeScript = null;
				response.getWriter().write(joRtn.toString());
			}
		}  else if(strActionCommand.endsWith("/lt/getRunAgentMapping")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null;
			JSONArray jaRunAgent = null;
			LTManager ltManager = null;
			String testTypeScript = null, apmGroup = null, scenarioId = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				testTypeScript = request.getParameter("testTypeScript").trim();
				apmGroup = request.getParameter("apmGroup").trim();
				scenarioId = request.getParameter("scenarioId");
				jaRunAgent = ltManager.mappingAgent(con, loginUserBean, testTypeScript, apmGroup, scenarioId);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRunAgent);
				
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to map scripts with scenarios.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				testTypeScript = null;
				apmGroup = null;
				scenarioId = null; 
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getLTDashDonut")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null;
			JSONArray jaRunAgent = null;
			LTManager ltManager = null;
			String type = null;
			String runid = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				
				type = request.getParameter("type");
				runid = request.getParameter("runid");
				jaRunAgent = ltManager.getLTDashDonut(con, loginUserBean.getUserId(), type, runid);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRunAgent);
				
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to map scripts with scenarios.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/getScenarioSettings")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null;
			JSONArray jaScenarios = null;
			LTManager ltManager = null;
			String testTypeScript = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				testTypeScript = request.getParameter("testTypeScript").trim();
				long scenarioId = Long.valueOf(request.getParameter("scenarioId").trim());
				jaScenarios = ltManager.getScenarioSettings(con, loginUserBean.getUserId(), testTypeScript, scenarioId);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaScenarios);
				
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getScenarioSettings.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				testTypeScript = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/updateScenarioSettings")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null, joSetting  = null;
			
			LTManager ltManager = null;
			
			String strTestTypeScript = null, strScriptIds = null, strScenarioSettings = null, strScriptNames = null, strScenarioName = null;
			String strScenarioXmlPath = null;
			
			TransformerFactory transformerFactory = null;
			Transformer transformer = null;
			DOMSource source = null;
			StreamResult result = null;
			NodeList nodeListScenarios = null;
			Node rootElement = null;
			Node nodeScenarios = null;
			Element elementScenario = null;
			
			JmeterScriptManager jmeterScriptManager = null;
			
			LoadTestBean loadTestBean = null;
			
			//StringBuffer jb = null;
			//String line = null;
			int nScriptHourToMin = 0, nScriptMin = 0, nTotalScenariosUserMaxUser = 0;
			float fScriptSecToMin = 0, fTotalScenariosUserMaxDuration = 0;
			
			int nTotalScenariosUserMaxIteration = 0, nScenarioStartUserCount = 0, nDurationSce = 0, nDurationMin = 0;
			int nMaxUser = 0, nMaxDuration = 0, nMaxIteration = 0, nType = 0;
			int nIncrimentUser = 0;
			long lForEverySec = -1, lForEveryMin = -1, lForEveryHour = -1, lIncrementTimeInSeconds = -1l, lDurationTimeInSeconds = -1l;
			
			try {
				ltManager = new LTManager();
				jmeterScriptManager = new JmeterScriptManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				strTestTypeScript = request.getParameter("testTypeScript").trim();
				long lScenarioId = Long.valueOf(request.getParameter("scenarioId").trim());
				strScriptIds = request.getParameter("scriptIds").trim();
				strScriptNames = request.getParameter("scriptNames").trim();
				strScenarioSettings = request.getParameter("scenarioSettings").trim();
				joSetting = JSONObject.fromObject(strScenarioSettings);
				strScenarioName = request.getParameter("scenarioName");
				
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				
				JSONObject joLicense = null;
				
				DocumentBuilder docBuilder = null;
				Document doc = null;
				Element scenariosElement = null;
				
				joLicense = ltManager.loadLoadTestLicenseDetails(con, loginUserBean);
				
				/* thinks, not in use; used for input params are read
				jb = new StringBuffer();
				try {
					BufferedReader reader = request.getReader();
					while ((line = reader.readLine()) != null)jb.append(line);
				} catch (Exception e) {
					LogManager.errorLog(e);
				}
				System.out.println("jb: "+jb.toString());
				*/
			  	
			  	nMaxUser = Integer.parseInt(joLicense.getString("maxuser"));
				nMaxDuration = Integer.parseInt(joLicense.getString("maxduration"));
				nMaxIteration = Integer.parseInt(joLicense.getString("maxiteration"));
				
				//try {
				String[] saScriptIds = strScriptIds.split(",");
				String[] saScriptName = strScriptNames.split(",");
				for(int i=0; i<saScriptIds.length; i++){
					loadTestBean = new LoadTestBean();
					loadTestBean.setScenarioName(strScenarioName);
					loadTestBean.setScriptName(saScriptName[i]);
					String[] timeSplit = joSetting.getString("durationtime").split(";");
					nScriptHourToMin = Integer.parseInt(timeSplit[0]) * 60;
					nScriptMin = Integer.parseInt(timeSplit[1]);
					fScriptSecToMin = Float.parseFloat(timeSplit[2]) / 60;
					fTotalScenariosUserMaxDuration = nScriptHourToMin + nScriptMin + fScriptSecToMin;
					nScenarioStartUserCount = Integer.parseInt(joSetting.getString("startuser"));
					nType = Integer.parseInt(joSetting.getString("type"));
					nDurationSce = Integer.parseInt(timeSplit[2]);
					nDurationMin = Integer.parseInt(timeSplit[1]);
					nTotalScenariosUserMaxIteration = Integer.parseInt(joSetting.getString("iterations"));
					nIncrimentUser = Integer.parseInt(joSetting.getString("incrementuser"));
					String[] incrementTime = joSetting.getString("incrementtime").split(";");
					lForEverySec = Long.parseLong(incrementTime[2]);
					lForEveryMin = Long.parseLong(incrementTime[1]);
					lForEveryHour = Long.parseLong(incrementTime[0]);
					nTotalScenariosUserMaxUser = nTotalScenariosUserMaxUser + Integer.parseInt(joSetting.getString("maxuser"));
					if(nScenarioStartUserCount <= 0){
						throw new Exception("1");
					}else if(nDurationSce<0 || nDurationSce>59){
						throw new Exception("8");
					}else if(nDurationMin<0 || nDurationMin>59){
						throw new Exception("9");
					}else if( nType == 2 && fTotalScenariosUserMaxDuration > nMaxDuration ) {
						throw new Exception("3");
				  	}else if( nType == 2 && fTotalScenariosUserMaxDuration <=0 ) {
						throw new Exception("4");
				  	}else if( nType == 1 && nTotalScenariosUserMaxIteration > nMaxIteration ) {
				  		throw new Exception("5");
				  	}else if( nType == 1 && nTotalScenariosUserMaxIteration <= 0 ) {
				  		throw new Exception("6");
				  	}else if(nIncrimentUser <= 0){
				  		throw new Exception("7");
				  	}else if(lForEverySec<0 || lForEverySec>59){
				  		throw new Exception("10");
				  	}else if(lForEveryMin<0 || lForEveryMin>59){
				  		throw new Exception("11");
				  	}else if(lForEveryHour<0){
				  		throw new Exception("12");
				  	}
					
					lDurationTimeInSeconds = (Long.parseLong(timeSplit[0])*3600)+(Long.parseLong(timeSplit[1])*60)+Long.parseLong(timeSplit[2]);
					
					// For jmeter RAMP time is equivalent to increment time  
					lIncrementTimeInSeconds = (lForEveryHour*3600)+(lForEveryMin*60)+lForEverySec;
					
					if( joSetting.getString("type").equalsIgnoreCase("1") ) {
						// For type iteration
						loadTestBean.setIteration(true);
						loadTestBean.setDuration(false);
						//loadTestBean.setLoops("-1");
						loadTestBean.setLoops(joSetting.getString("iterations"));
						loadTestBean.setNoOfThreads(joSetting.getString("maxuser"));
						loadTestBean.setRAMPTime("1");
						loadTestBean.setSchedular("false");
						loadTestBean.setDurationTime("");
						loadTestBean.setDelay("");
						loadTestBean.setDelayStart("");
					} else if ( joSetting.getString("type").equalsIgnoreCase("2") ) {
						// For type duration
						loadTestBean.setIteration(false);
						loadTestBean.setDuration(true);
						loadTestBean.setLoops("-1");
						loadTestBean.setNoOfThreads(joSetting.getString("maxuser"));
						loadTestBean.setRAMPTime(lIncrementTimeInSeconds+"");
						loadTestBean.setSchedular("true");
						loadTestBean.setDurationTime(lDurationTimeInSeconds+"");
						loadTestBean.setDelay("10");
						loadTestBean.setDelayStart("true");
					}
					loadTestBean.setStartTime(System.currentTimeMillis()+"");
					loadTestBean.setEndTime(System.currentTimeMillis()+"");
					
					if ( strTestTypeScript.equalsIgnoreCase("JMETER") ) {
						jmeterScriptManager.updateJmxFile(Constants.JMETERSCENARIOFOLDERPATH+loginUserBean.getUserId()+File.separator+loadTestBean.getScenarioName()+".jmx", loadTestBean);
					}
				}
				
				if( nTotalScenariosUserMaxUser > nMaxUser ) {
			  		joRtn = UtilsFactory.getJSONFailureReturn("User count must not exceed "+nMaxUser); 
			  	} else {
					docBuilder = docFactory.newDocumentBuilder();
					// root elements "scenarios"
					doc = docBuilder.newDocument();
					rootElement = doc.createElement("root");
					doc.appendChild(rootElement);
					
					scenariosElement = doc.createElement("scenarios");
					rootElement.appendChild(scenariosElement);
					
					
					// Based on the testType "FLOODGATES/JMETER" the respective secenario path to be updated is taken
					
					if ( strTestTypeScript.equalsIgnoreCase("APPEDO_LT") ) {
						strScenarioXmlPath = Constants.FLOODGATESSCENARIOXMLFOLDERPATH+File.separator+loginUserBean.getUserId()+"_scenarios.xml";
					} else if ( strTestTypeScript.equalsIgnoreCase("JMETER") ) {
						strScenarioXmlPath = Constants.JMETERSCENARIOXMLFOLDERPATH+loginUserBean.getUserId()+File.separator+loginUserBean.getUserId()+"_scenarios.xml";
					}
			  		// gets user max runcount for the current month 
					//validate scenario max users
					//new FloodgatesXMLAppend().deleteScenario(String.valueOf(scenarioId), scenarioName, strScenarioXmlPath);
					
					
					doc = docBuilder.parse(strScenarioXmlPath);
					nodeListScenarios = doc.getElementsByTagName("scenario");
					if(nodeListScenarios.getLength() == 0) {
						//scenarioid = 0;
						rootElement = doc.getFirstChild();
						nodeScenarios = doc.getElementsByTagName("scenarios").item(0);
						//scenarioId = String.valueOf(scenarioid + 1);
						elementScenario = doc.createElement("scenario");
						elementScenario.setAttribute("enableipspoofing", "False");
						
						elementScenario.setAttribute("id", String.valueOf(lScenarioId) );
						
						elementScenario.setAttribute("name", strScenarioName);
						nodeScenarios.appendChild(elementScenario);
					
						for(int i=0; i<saScriptIds.length; i++){
							Element scriptsElement = doc.createElement("script");
							scriptsElement.setAttribute("id", String.valueOf(saScriptIds[i]));
							scriptsElement.setAttribute("name", saScriptName[i]);
							elementScenario.appendChild(scriptsElement);
							
							//JSONObject joSetting = JSONObject.fromObject(scenarioSettings);
							Element settingElement = doc.createElement("setting");	
							settingElement.setAttribute("browsercache", joSetting.getString("browsercache"));
							settingElement.setAttribute("parallelconnections", joSetting.getString("parallelconnections"));
							settingElement.setAttribute("durationtime", joSetting.getString("durationtime"));
							settingElement.setAttribute("incrementtime", joSetting.getString("incrementtime"));
							settingElement.setAttribute("incrementuser", joSetting.getString("incrementuser"));
							settingElement.setAttribute("iterations", joSetting.getString("iterations"));			
							settingElement.setAttribute("maxuser", joSetting.getString("maxuser"));		
							settingElement.setAttribute("startuser", joSetting.getString("startuser"));
							settingElement.setAttribute("currentloadgenid", joSetting.getString("currentloadgenid"));
							settingElement.setAttribute("durationmode", joSetting.getString("durationmode"));
							settingElement.setAttribute("startuserid", joSetting.getString("startuserid"));
							settingElement.setAttribute("totalloadgen", joSetting.getString("totalloadgen"));
							settingElement.setAttribute("type", joSetting.getString("type"));
							scriptsElement.appendChild(settingElement);
						}
					} else {
						/*
						int mnum = nodeListScenarios.getLength() - 1;
						
						String[] strUserScenarioName = new String[mentries.getLength()];
						for(int i=0; i<mentries.getLength(); i++){
							Node mnode = (Node) mentries.item(i);
							String scenario = mnode.getAttributes().getNamedItem("name").getNodeValue();
							strUserScenarioName[i] = scenario;
							scenario = null;
						}
						for (int i=mnum; i<mentries.getLength(); i++) 
						{
							Node mnode = (Node) mentries.item(i);
							//scenarioid = Integer.parseInt(mnode.getAttributes().getNamedItem("id").getNodeValue());
						}*/
						rootElement = doc.getFirstChild();
						nodeScenarios = doc.getElementsByTagName("scenarios").item(0);
						
						for(int idxScenarioNode = 0; idxScenarioNode < nodeListScenarios.getLength(); idxScenarioNode++){
							Node nodeScenario = (Node) nodeListScenarios.item(idxScenarioNode);
							String strScenarioNameFromXML = nodeScenario.getAttributes().getNamedItem("name").getNodeValue();
							if( strScenarioNameFromXML.equals(strScenarioName) ){
								NodeList nodeListScripts = nodeScenario.getChildNodes();
								
								for(int idxScriptNode = 0; idxScriptNode < nodeListScripts.getLength(); idxScriptNode++){
									Node nodeScript = (Node) nodeListScripts.item(idxScriptNode);
									int idxScript = UtilsFactory.indexOf(saScriptIds, nodeScript.getAttributes().getNamedItem("id").getNodeValue());
									
									if( idxScript != -1 ){
										nodeScenario.removeChild(nodeScript);
										
										Element scriptsElement = doc.createElement("script");
										scriptsElement.setAttribute("id", String.valueOf(saScriptIds[idxScript]));
										scriptsElement.setAttribute("name", saScriptName[idxScript]);
										nodeScenario.appendChild(scriptsElement);
										
										Element settingElement = doc.createElement("setting");	
										settingElement.setAttribute("browsercache", joSetting.getString("browsercache"));
										settingElement.setAttribute("parallelconnections", joSetting.getString("parallelconnections"));
										settingElement.setAttribute("durationtime", joSetting.getString("durationtime"));
										settingElement.setAttribute("incrementtime", joSetting.getString("incrementtime"));
										settingElement.setAttribute("incrementuser", joSetting.getString("incrementuser"));
										settingElement.setAttribute("iterations", joSetting.getString("iterations"));			
										settingElement.setAttribute("maxuser", joSetting.getString("maxuser"));		
										settingElement.setAttribute("startuser", joSetting.getString("startuser"));
										settingElement.setAttribute("currentloadgenid", joSetting.getString("currentloadgenid"));
										if( joSetting.containsKey("durationmode") ){
											settingElement.setAttribute("durationmode", joSetting.getString("durationmode"));
										}
										settingElement.setAttribute("startuserid", joSetting.getString("startuserid"));
										settingElement.setAttribute("totalloadgen", joSetting.getString("totalloadgen"));
										settingElement.setAttribute("type", joSetting.getString("type"));
										scriptsElement.appendChild(settingElement);
										//mnoded.getAttributes().getNamedItem("setting");
										
										break;
									}
								}
							}
							strScenarioNameFromXML = null;
						}
					}
				
					transformerFactory = TransformerFactory.newInstance();
					transformer = transformerFactory.newTransformer();
					source = new DOMSource(doc);
					result = new StreamResult(strScenarioXmlPath);
					
					transformer.transform(source, result);
					
					ltManager.updateScenarioSettings(con, loginUserBean, strTestTypeScript, strScenarioSettings, lScenarioId, strScriptIds);
					joRtn = UtilsFactory.getJSONSuccessReturn("Updated Scenario Settings");
					
					DataBaseManager.commitConnection(con);
					
				  	// validation
					joLicense = null;
					loginUserBean = null;
					docBuilder = null;
					doc = null;
					rootElement = null;
					scenariosElement = null;
					//jb = null;
					//line = null;
					strScenarioXmlPath = null;
					saScriptIds = null;
					saScriptName = null;
			  	}
				
				ltManager = null;
			} catch (ParseException e) {
				// crash and burn
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Scenarios failed to save.\nException "+e.getMessage());
				throw new IOException("Error parsing JSON request string");
			} catch (Exception e) {
				// crash and burn
				LogManager.errorLog(e);
				
				if(e.getMessage().equals("1")){
					joRtn = UtilsFactory.getJSONFailureReturn("Start user count must not "+nScenarioStartUserCount);  
				}else if(e.getMessage().equals("2")){
					joRtn = UtilsFactory.getJSONFailureReturn("Start user count must not exceed max user");
				}else if(e.getMessage().equals("3")){
					joRtn = UtilsFactory.getJSONFailureReturn("Duration must not exceed "+nMaxDuration+" minutes.");
				}else if(e.getMessage().equals("4")){
					joRtn = UtilsFactory.getJSONFailureReturn("Duration must be greater than 00:00:00");
				}else if(e.getMessage().equals("5")){
					joRtn = UtilsFactory.getJSONFailureReturn("Iteration must not exceed "+nMaxIteration+" iterations.");
				}else if(e.getMessage().equals("6")){
					joRtn = UtilsFactory.getJSONFailureReturn("Iteration must not "+nTotalScenariosUserMaxIteration+" iterations.");
				}else if(e.getMessage().equals("7")){
					joRtn = UtilsFactory.getJSONFailureReturn("Incriment user must not "+nIncrimentUser);
				}else if(e.getMessage().equals("8")){
					joRtn = UtilsFactory.getJSONFailureReturn("Seconds must not be "+nDurationSce);
				}else if(e.getMessage().equals("9")){
					joRtn = UtilsFactory.getJSONFailureReturn("Min must not be "+nDurationMin);
				}else if(e.getMessage().equals("10")){
					joRtn = UtilsFactory.getJSONFailureReturn("Seconds must not be "+lForEverySec);
				}else if(e.getMessage().equals("11")){
					joRtn = UtilsFactory.getJSONFailureReturn("Minutes must not be "+lForEveryMin);
				}else if(e.getMessage().equals("12")){
					joRtn = UtilsFactory.getJSONFailureReturn("Hour must not be "+lForEveryHour);
				}/*else if( e.getMessage().equals("SESSION_EXPIRED") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Scenarios failed to save.\nException "+e.getMessage());
					throw new ServletException("SESSION_EXPIRED");
				}*/ else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update ScenarioSettings.");
				}
				DataBaseManager.rollbackConnection(con);
			} catch (Throwable e) {
				// crash and burn
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Scenarios failed to save.\nException "+e.getMessage()); 
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				strTestTypeScript = null;
				strScriptIds = null;
				strScenarioSettings = null;
				transformerFactory = null;
				transformer = null;
				source = null;
				result = null;
				
				jmeterScriptManager = null;
				loadTestBean = null;
				
				UtilsFactory.clearCollectionHieracy(joSetting);
				joSetting = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/uploadJmeterScript")){

			LoginUserBean loginUserBean = null;
			JmeterScriptManager manager = null;
			LTManager ltManager = null;
			Connection con = null;
			String strSavePath = "", strSaveJmeterScenarioXml = "", strFileName = "", strFileExtension = "", strErrorMessage = "";
			String testTypeScript = null;
			File uploadedFile = null;
			LTLicenseBean ltLicBean = null;
			ArrayList<String> alJmeterUploadedFileNames = new ArrayList<String>(); 
			
			JSONObject joRtn = null;
			
			try {
				ltManager = new LTManager();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				manager = new JmeterScriptManager();

				con = DataBaseManager.giveConnection();
				testTypeScript = "JMETER";
				
				ltLicBean = ltManager.getLTLicenseDetails(con, loginUserBean);
				if(ltLicBean != null){
					String upload_file_count = request.getParameter("upload_file_count")==null?"0":request.getParameter("upload_file_count");
					for(int mIndex=0; mIndex < Integer.parseInt(upload_file_count); mIndex++){

						strFileName = request.getParameter("file_name_"+mIndex);
						strFileName = strFileName.replace(" ", "");
						if(strFileExtension.equals("jmx")){
							strFileName = loginUserBean.getUserId()+"_"+strFileName;
						}else if(strFileExtension.equals("csv")){
							strFileName = strFileName;
						}
						
						strFileExtension = strFileName.substring(strFileName.lastIndexOf(".")+1).toLowerCase();
						if( ! (strFileExtension.equals("jmx") || strFileExtension.equals("csv") ) ){
							strErrorMessage = "1"; //"doc, docs, pdf or rtf file extensions are only allowed.";
							throw new Exception(strErrorMessage);
						}
						
						// save's file in the system
						File f = new File(Constants.JMETERSCENARIOSPATH+loginUserBean.getUserId());
						if(!f.exists()){
							f.mkdir();
						}
						strSaveJmeterScenarioXml = Constants.JMETERSCENARIOSPATH+loginUserBean.getUserId()+File.separator+strFileName;
						if(UtilsFactory.removeFile(strSaveJmeterScenarioXml)){
							if(UtilsFactory.createFile(request.getParameter("file_content_"+mIndex).getBytes(), request.getParameter("file_content_"+mIndex).length(), strSaveJmeterScenarioXml)){
								alJmeterUploadedFileNames.add(strFileName);
							}
						}
						
					}	
					
			        // constructs path of the directory to save uploaded file
			        strSavePath = Constants.JMETERSCENARIOSPATH+loginUserBean.getUserId()+File.separator;
			        
					List<String> list = new ArrayList();
					// Updating VUscripts
					for(int i = 0; i < alJmeterUploadedFileNames.size(); i = i + 1) {
						String strUploadedFileName = alJmeterUploadedFileNames.get(i);
						// System.out.println("FILE NAME :::: "+strUploadedFileName);
						String strUploadedFileExtension = strUploadedFileName.substring(strUploadedFileName.lastIndexOf(".")+1).toLowerCase();
						String strUploadedFilePath = Constants.JMETERSCENARIOSPATH+loginUserBean.getUserId()+File.separator+strUploadedFileName;
						String strvuscriptspath = Constants.JMETERVUSCRIPTSFOLDERPATH+loginUserBean.getUserId()+"_vuscripts.xml";
						String strscenariopath = Constants.JMETERSCENARIOXMLFOLDERPATH+loginUserBean.getUserId()+File.separator+loginUserBean.getUserId()+"_scenarios.xml";
						if( strUploadedFileExtension.equalsIgnoreCase("jmx") ) {
							if ( manager.isScriptFileExist(strvuscriptspath) && manager.isScenarioFileExist(strscenariopath)) {
								//manager.addScript(strFileName, Constants.JMETERVUSCRIPTSPATH);
								String fileName = strUploadedFileName.replace(strUploadedFileExtension, "").replace(".", "");
								long scenarioId = ltManager.insertScenarioName(con, fileName, testTypeScript, loginUserBean);
								// long scriptId = ltManager.insertJmeterScriptName(con, fileName, testTypeScript, loginUserBean);
								// ltManager.mappingScripts(con, loginUserBean, testTypeScript, fileName, String.valueOf(scriptId), scenarioId);
								manager.getScriptNames(con, strUploadedFilePath , strvuscriptspath, strUploadedFileName, strscenariopath, scenarioId, testTypeScript, loginUserBean);
								

								// validating the upload scripts
								if(manager.isJmxContainsCsvFile(strUploadedFilePath)); {
									list=manager.getParametersFile(strUploadedFilePath);
									if(list.size()>0) {
										if(!manager.isParamFilesExist(strUploadedFilePath, Constants.JMETERSCENARIOSPATH+loginUserBean.getUserId()+File.separator)){
											throw new Exception("Files are not uploaded");
										}	
									}
								}
								fileName = null;
							}
						}
						
						strUploadedFileName = null;
						strUploadedFileExtension = null;
						strUploadedFilePath = null;
						strvuscriptspath = null;
						strscenariopath = null;
					}
					
					DataBaseManager.commitConnection(con);
					joRtn = UtilsFactory.getJSONSuccessReturn("Script(s) are uploaded");
				}else{
					throw new Exception("2");
				}

			} catch (Throwable e) {
				LogManager.errorLog(e);
				if(e.getMessage().equalsIgnoreCase("1")){
					joRtn = UtilsFactory.getJSONFailureReturn("Script(s) were not uploaded.\n Files must be jmx/csv type.");
				}if(e.getMessage().equalsIgnoreCase("2")){
					joRtn = UtilsFactory.getJSONFailureReturn("License expired. Please contact appedo.com.");
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("Script(s) were not uploaded.\nException "+e.getMessage());
				}
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				manager = null;
				ltManager = null;
				testTypeScript = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/getLTLicense")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONArray joRtn = null;
			LTManager ltManager = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				joRtn =ltManager.getLTLicense(con, loginUserBean);
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getDashResponseArea")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONArray joRtn = null;
			LTManager ltManager = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				long runid = Long.valueOf(request.getParameter("runid"));
				joRtn =ltManager.getDashResponseArea(con, loginUserBean,runid);
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getDashVUsersArea")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONArray joRtn = null;
			LTManager ltManager = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				con = DataBaseManager.giveConnection();
				long runid = Long.valueOf(request.getParameter("runid"));
				String scenarioName = request.getParameter("scenarioName");
				joRtn =ltManager.getDashVUsersArea(con, loginUserBean,runid,scenarioName);
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/checkEndTimeFormatForExistingTest")){
			Connection con = null;
			JSONObject joReports = null;
			JSONObject joRtn = null;
			LTManager ltManager = null;
			try {
				joReports = new JSONObject();
				ltManager = new LTManager();
				con = DataBaseManager.giveConnection();
				String runid = request.getParameter("runid");
				Boolean chartReportStatus = false;
				chartReportStatus = ltManager.checkEndTimeFormatForExistingTest(con, runid);
				joReports.put("status", chartReportStatus);
				joRtn = UtilsFactory.getJSONSuccessReturn(joReports);
			} catch(Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/runEndTimeFormatForExistingTest")){
			Connection con = null;
			JSONObject joReports = null;
			JSONObject joRtn = null;
			LTManager ltManager = null;
			try {
				joReports = new JSONObject();
				ltManager = new LTManager();
				con = DataBaseManager.giveConnection();
				String runid = request.getParameter("runid");
				Boolean chartReportStatus = false;
				chartReportStatus = ltManager.runEndTimeFormatForExistingTest(con, runid);
				joReports.put("status", chartReportStatus);
				joRtn = UtilsFactory.getJSONSuccessReturn(joReports);
				DataBaseManager.commitConnection(con);
			} catch(Exception e) {
				LogManager.errorLog(e);
				DataBaseManager.rollbackConnection(con);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/chartReport")){
			LTManager ltManager = null;
			
			JSONObject joReports = null;
			JSONObject joRtn = null;
			LoginUserBean loginUserBean = null;
			Connection con = null;
			try {
				ltManager = new LTManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String runid = request.getParameter("runid").trim();
				String strTestTypeScript = request.getParameter("testTypeScript").trim();
				String startTime = request.getParameter("startTime").trim();
				String queryDuration = request.getParameter("queryDuration")==null?"":request.getParameter("queryDuration");
				String selectedTime = request.getParameter("selectedTime")==null?"0":request.getParameter("selectedTime");
				String status = request.getParameter("status")==null?"":request.getParameter("status");
				String runTime = request.getParameter("runTime")==null?"0":request.getParameter("runTime");
				String chartType = request.getParameter("chartType")==null?"":request.getParameter("chartType");
				String jsonString = null;
				con = DataBaseManager.giveConnection();
				
				if ( strTestTypeScript.equals(Constants.APPEDO_LT) ) {
					joReports = new JSONObject();
					if(chartType.equalsIgnoreCase(Constants.APPEDO_LT_USER_COUNT)){
						jsonString = ltManager.getChartDataForAppdeoLTUserCounts(con, runid, strTestTypeScript, startTime, queryDuration , selectedTime , status, runTime);
						if(jsonString !=null){
							joReports.put(Constants.APPEDO_LT_USER_COUNT, jsonString);
						}else{
							joReports.put(Constants.APPEDO_LT_USER_COUNT, "[]");
						}
					}else if(chartType.equalsIgnoreCase(Constants.APPEDO_LT_ERROR_COUNT)){
						jsonString = ltManager.getChartDataForAppdeoLTErrorCounts(con, runid, strTestTypeScript, startTime, queryDuration , selectedTime , status, runTime);
						if(jsonString !=null){
							joReports.put(Constants.APPEDO_LT_ERROR_COUNT, jsonString);
						}else{
							joReports.put(Constants.APPEDO_LT_ERROR_COUNT, "[]");
						}
					}else if(chartType.equalsIgnoreCase(Constants.APPEDO_LT_PAGE_RESPONSE)){
						jsonString = ltManager.getChartDataForAppdeoLTPageResponse(con, runid, strTestTypeScript, startTime, queryDuration , selectedTime , status, runTime);
						if(jsonString !=null){
							joReports.put(Constants.APPEDO_LT_PAGE_RESPONSE, jsonString);
						}else{
							joReports.put(Constants.APPEDO_LT_PAGE_RESPONSE, "[]");
						}
					}else if(chartType.equalsIgnoreCase(Constants.APPEDO_LT_LOADGENS_AVG_REQ_RESPS)){
						jsonString = ltManager.getLoadgensAvgReqResp(con, runid, strTestTypeScript, startTime, queryDuration , selectedTime , status, runTime);
						if(jsonString !=null){
							joReports.put(Constants.APPEDO_LT_LOADGENS_AVG_REQ_RESPS, jsonString);
						}else{
							joReports.put(Constants.APPEDO_LT_LOADGENS_AVG_REQ_RESPS, "[]");
						}
					}else if(chartType.equalsIgnoreCase(Constants.APPEDO_LT_LOADGENS_AVG_PAGE_RESPS)){
						jsonString = ltManager.getLoadgensAvgPageResp(con, runid, strTestTypeScript, startTime, queryDuration , selectedTime , status, runTime);
						if(jsonString !=null){
							joReports.put(Constants.APPEDO_LT_LOADGENS_AVG_PAGE_RESPS, jsonString);
						}else{
							joReports.put(Constants.APPEDO_LT_LOADGENS_AVG_PAGE_RESPS, "[]");
						}
					}else if(chartType.equalsIgnoreCase(Constants.APPEDO_LT_HIT_COUNT_THROUGHPUT_REQUEST_RESPONSE)){
						jsonString = ltManager.getChartDataForAppdeoLTThroughputHitCountsAndReqResponse(con, runid, strTestTypeScript, startTime, queryDuration , selectedTime , status, runTime);
						if(jsonString !=null){
							joReports.put(Constants.APPEDO_LT_HIT_COUNT_THROUGHPUT_REQUEST_RESPONSE, jsonString);
						}else{
							joReports.put(Constants.APPEDO_LT_HIT_COUNT_THROUGHPUT_REQUEST_RESPONSE, "[]");
						}
					}
					if(jsonString !=null){
						joRtn = UtilsFactory.getJSONSuccessReturn(joReports);
					}else{
						joRtn = UtilsFactory.getJSONFailureReturn(joReports);
					}
				}else if ( strTestTypeScript.equals(Constants.JMETER) ) {
					joReports = ltManager.getReportsChart(con, runid, strTestTypeScript, startTime);
					joRtn = UtilsFactory.getJSONSuccessReturn(joReports);
				}
				
				ltManager = null;
				loginUserBean = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get logReport.");
			}finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getModuleCountersChartdataForLoadTest")) {
			Connection con = null;

			LTManager ltManager = null;
			
			JSONObject joRtn = null, joFlotChartModuleCounters = null, joChartTypes = new JSONObject();
			
			//HashMap<String, JSONObject> hmVendorCounters = new HashMap<String, JSONObject>();
			
			StringBuilder sbCounterValues = new StringBuilder();

			LoginUserBean loginUserBean = null;
			
			try {
				ltManager = new LTManager();
				
				con = DataBaseManager.giveConnection();
				
				String strGUID = request.getParameter("guid");
				
				String[] saCounterIds = UtilsFactory.replaceNull(request.getParameter("counterNames"), UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")).split(",");
				if( request.getParameter("counterNames") == null && saCounterIds.length == 0 ){
					saCounterIds = new String[]{UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")};
				}
				String strMaxTimeStamp = UtilsFactory.replaceNull(request.getParameter("maxTimeStamp"), "");
				String startTime = UtilsFactory.replaceNull(request.getParameter("startTime"), "");
				String endTime = UtilsFactory.replaceNull(request.getParameter("endTime"), "");
				String runTime = UtilsFactory.replaceNull(request.getParameter("runTime"), "0");
				String strFromStartInterval = UtilsFactory.replaceNull(request.getParameter("fromStartInterval"), ""); 
				
				
				for(int i = 0; i < saCounterIds.length; i = i + 1) {
					String strCounterId = saCounterIds[i].trim();
					
					if( i != 0 ) sbCounterValues.append(",");

					sbCounterValues.append( strCounterId );
				}

				// counter values data for real time plot chart 
				joFlotChartModuleCounters = ltManager.getCountersForLoadTest(con, strGUID, sbCounterValues.toString(), strMaxTimeStamp, strFromStartInterval, startTime, endTime, runTime,false);

				//joChartTypes.put("flotChartData", joFlotChartModuleCounters);
				joRtn = UtilsFactory.getJSONSuccessReturn(joFlotChartModuleCounters);
				
			} catch (Exception e) {
				System.out.println("Exception in /lt/getModuleCountersChartdataForLoadTest: "+e.getMessage());
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
				e.printStackTrace();
			} finally {
				ltManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getNewModuleCountersChartdataForLoadTest")) {
			Connection con = null;

			LTManager ltManager = null;
			
			JSONObject joReports = null;
			JSONObject joRtn = null;
			String jsonString = null;
			
			StringBuilder sbCounterValues = new StringBuilder();

			try {
				ltManager = new LTManager();
				
				con = DataBaseManager.giveConnection();
				
				String strGUID = request.getParameter("guid");
				
				String[] saCounterIds = UtilsFactory.replaceNull(request.getParameter("counterNames"), UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")).split(",");
				if( request.getParameter("counterNames") == null && saCounterIds.length == 0 ){
					saCounterIds = new String[]{UtilsFactory.replaceNull(request.getParameter("counter_id"), "-1")};
				}
				String startTime = UtilsFactory.replaceNull(request.getParameter("startTime"), "0");
				String endTime = UtilsFactory.replaceNull(request.getParameter("endTime"), "0");
				String runTime = UtilsFactory.replaceNull(request.getParameter("runTime"), "0");
				String queryDuration = request.getParameter("queryDuration")==null?"":request.getParameter("queryDuration");
				String selectedTime = request.getParameter("selectedTime")==null?"0":request.getParameter("selectedTime");
				String status = request.getParameter("status")==null?"":request.getParameter("status");

				
				for(int i = 0; i < saCounterIds.length; i = i + 1) {
					String strCounterId = saCounterIds[i].trim();
					
					if( i != 0 ) sbCounterValues.append(",");

					sbCounterValues.append( strCounterId );
				}
				
				jsonString = ltManager.getCountersForLoadTest(con, strGUID, sbCounterValues.toString(),startTime, endTime, runTime,queryDuration,selectedTime,status);
				if(jsonString !=null){
					joRtn = UtilsFactory.getJSONSuccessReturn(jsonString);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("[]");
				}
			} catch (Exception e) {
				System.out.println("Exception in /lt/getNewModuleCountersChartdataForLoadTest: "+e.getMessage());
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get chartdata. ");
				e.printStackTrace();
			} finally {
				ltManager = null;
				
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getLTScenarioReports")) {
			Connection con = null;
			LTManager ltManager = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null;
			String strjaReports = null;
			
			try {
				ltManager = new LTManager();
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String scenarioId = request.getParameter("scenarioid").trim();
				String strTestType = request.getParameter("testTypeScript").trim();
				
				strjaReports = ltManager.getLTScenarioReports(con, scenarioId, strTestType,loginUserBean.getUserId());
				if( strjaReports != null ){
					joRtn = UtilsFactory.getJSONSuccessReturn(strjaReports);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("No reports found.");
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Get LTScenarioReports . ");
			} finally {
				ltManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getselectedReportRunStartAndEndTime")) {
			Connection con = null;
			LTManager ltManager = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null;
			String jsonString = null;
			try {
				ltManager = new LTManager();
				con = DataBaseManager.giveConnection();
				long runid = Long.valueOf(request.getParameter("runid").trim());
				String strTestType = request.getParameter("testTypeScript").trim();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				jsonString = ltManager.getselectedReportRunStartAndEndTime(con, runid, strTestType,loginUserBean.getUserId());
				if(jsonString !=null){
					joRtn = UtilsFactory.getJSONSuccessReturn(jsonString);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("[]");
				}
			} catch (Exception e) {
				System.out.println("Exception in /lt/getselectedReportRunStartAndEndTime: "+e.getMessage());
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Get getselectedReportRunStartAndEndTime . ");
				e.printStackTrace();
			} finally {
				ltManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/getselectedReportGuid")) {
			Connection con = null;
			LTManager ltManager = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null,joReports=null;
			String jsonString = null;
			try {
				ltManager = new LTManager();
				con = DataBaseManager.giveConnection();
				long runid = Long.valueOf(request.getParameter("runid").trim());
				String strTestType = request.getParameter("testTypeScript").trim();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				jsonString = ltManager.getselectedReportGuid(con, runid, strTestType,loginUserBean.getUserId());
				joReports = new JSONObject();
				if(jsonString !=null){
					joReports.put("guid",jsonString);
					joRtn = UtilsFactory.getJSONSuccessReturn(joReports);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("[]");
				}
			} catch (Exception e) {
				System.out.println("Exception in /lt/getselectedReportGuid: "+e.getMessage());
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Get getselectedReportGuid . ");
				e.printStackTrace();
			} finally {
				ltManager = null;
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/lt/runScenario")) {
			Connection con = null;
			JSONObject joMessage = null;
			JSONObject joUserRunningScenario = null;
			LoginUserBean loginUserBean = null;
			LTManager runManager = null;
			JSONObject joLicense = null;
			long nUserId = 0;
//			int nMaxRuncount = 0;
			int nMaxRuncountperday = 0;
			int nUserTotalRuncount = 0;
			int nUserTotalRundaycount = 0;
			
			String strTestType =  null;
			String strRunType = null;
			String loadgenRegions = null;
			String loadgenDistributions = null;
			String strScenarioId = null;
			String strScenarioName = null;
			String strReportName = null;
			String strScriptName = null;
			String strScriptId = null;
			String guids = null;
			String userAgent = null;
			
			JSONArray jaScriptDetails = null;
			
			try	{
				con = DataBaseManager.giveConnection();
				LoadTestSchedulerBean schedulerBean = new LoadTestSchedulerBean();
				LTScheduler ltScheduler = new LTScheduler();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				runManager = new LTManager();
				
				joLicense = runManager.loadLoadTestLicenseDetails(con, loginUserBean);

				//nMaxRuncount = Integer.parseInt(joLicense.getString("maxruncount"));
				nMaxRuncountperday = joLicense.getInt("maxruncountperday");
				
				strTestType =  request.getParameter("testType");
				strRunType = request.getParameter("runType");
				loadgenRegions = request.getParameter("regions");
				loadgenDistributions = request.getParameter("distributions");
				strScenarioId = request.getParameter("scenarioId");
				strScenarioName = request.getParameter("scenarioName");
				strReportName = request.getParameter("reportName");
				int nMaxUser = Integer.parseInt(request.getParameter("maxUserCount"));
				userAgent = request.getParameter("userAgent");
				int startMonitor = Integer.parseInt(request.getParameter("startMonitor"));
				int endMonitor = Integer.parseInt(request.getParameter("endMonitor"));
				
				nUserId = loginUserBean.getUserId();
				guids = request.getParameter("guids");
				
				if( strTestType.equals("JMETER") ) {
					boolean isFirst = true;
					
					jaScriptDetails = runManager.getScriptDetails(con, Long.valueOf(strScenarioId));
					for( int i =0; i<jaScriptDetails.size(); i++ ){
						JSONObject joScript = jaScriptDetails.getJSONObject(i);
						if( isFirst ) {
							strScriptName = joScript.getString("scriptName");
							strScriptId = joScript.getString("scriptId");
							isFirst = false;
						} else{
							strScriptName = strScriptName+","+ joScript.getString("scriptName");
							strScriptId = strScriptId+","+ joScript.getString("scriptId");
						}
					}
					
					schedulerBean.setScriptId(strScriptId);
					schedulerBean.setScriptName(strScriptName);
				}
//				nUserTotalRuncount = runManager.getUserMaxRunCount(con, loginUserBean);
//				
//				if( nMaxRuncount <= nUserTotalRuncount ) {
//					throw new Exception("nMaxRuncount");
//			  	}
				
				nUserTotalRundaycount = runManager.getUserMaxRunCountPerDay(con, loginUserBean);
				
				if( nMaxRuncountperday <= nUserTotalRundaycount ) {
					throw new Exception("nMaxRuncountPerDay");
			  	}
				try {
					schedulerBean.setLoadGenRegions(loadgenRegions);
					schedulerBean.setDistributions(loadgenDistributions);
					schedulerBean.setReportName(strReportName);
					schedulerBean.setScenarioId(strScenarioId);
					schedulerBean.setScenarioName(strScenarioName.toLowerCase());
					schedulerBean.setTestType(strTestType);
					schedulerBean.setUserId(nUserId);
					schedulerBean.setLicense(loginUserBean.getLicense());
					schedulerBean.setMaxUserCount(nMaxUser);
					schedulerBean.setRunType(strRunType);
					schedulerBean.setUserAgent(userAgent);
					schedulerBean.setStartMonitor(startMonitor);
					schedulerBean.setEndMonitor(endMonitor);
					
					synchronized (ltScheduler) {
						joUserRunningScenario = runManager.isUserRunningScenario(con, loginUserBean, strTestType);
						if(joUserRunningScenario.containsKey("isActive") && joUserRunningScenario.getBoolean("isActive")){
							joMessage = UtilsFactory.getJSONFailureReturn("Another Run is in progress. Please wait!");
							
						}else{
							long lRunId = runManager.insertIntoReportMaster(con, schedulerBean, loginUserBean);
							schedulerBean.setRunId(lRunId);
							int i = 0;
							String queueIP = "inactive";
							while( i <= 3){
							  // processingIP = runManager.getIPStatus(Constants.LT_PROCESSING_IP, Integer.valueOf(Constants.LT_PROCESSING_PORT));
							  queueIP = runManager.getIPStatus(Constants.LT_QUEUE_IP, Integer.valueOf(Constants.LT_QUEUE_PORT));
								if( queueIP.equalsIgnoreCase("active") ){
									break;
								}
								i++;
							}
							if( queueIP.equalsIgnoreCase("active") ){
								ltScheduler.putTestInQueue(schedulerBean);
								
								if( guids.length()>0 ){
									runManager.insertAgentMapping(con, guids, lRunId);
								}
								joMessage = UtilsFactory.getJSONSuccessReturn("Your test is in queue, as soon as the Run starts, status will change to GREEN ");
							} else {
								runManager.updateProcessServiceFailed(con, "Queue Service is unavailable", lRunId);
								joMessage = UtilsFactory.getJSONSuccessReturn("Queue Service is Down. Please try after sometime");
							}
							DataBaseManager.commitConnection(con);	
						}
					}
					
				} catch(Throwable t) {
					DataBaseManager.rollbackConnection(con);
					t.printStackTrace();
					if(t.getMessage().equals("ReportNameExist")){
						joMessage = UtilsFactory.getJSONFailureReturn("Report Name already exist.");
					} else if(t.getMessage().equals("2")){
						joMessage = UtilsFactory.getJSONFailureReturn("License expired. Please contact appedo.com.");
					}
					
				} finally {
					schedulerBean = null;
					ltScheduler = null;
				}
					
			}catch(Exception e){
//				if(e.getMessage().equals("nMaxRuncount")){
//					joMessage = UtilsFactory.getJSONFailureReturn("Total run count must not exceed "+nMaxRuncount+" for the month.");
//				}
				if(e.getMessage().equals("nMaxRuncountPerDay")){
					joMessage = UtilsFactory.getJSONFailureReturn("Total run count must not exceed "+nMaxRuncountperday+" for the day.");
				}else if(e.getMessage().equals("1")){
					joMessage = UtilsFactory.getJSONFailureReturn("Report name already exist.");
				}
			}
			catch(Throwable t)
			{
				LogManager.errorLog(t);
				joMessage = UtilsFactory.getJSONFailureReturn("Exception occured while run.\n" +t.getMessage());
				if( t.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				}
			}finally {
				DataBaseManager.close(con);
				con = null;
				joUserRunningScenario = null;
				loginUserBean = null;
				runManager = null;
				joLicense = null;
				strTestType =  null;
				strRunType = null;
				loadgenRegions = null;
				loadgenDistributions = null;
				strScenarioId = null;
				strScenarioName = null;
				strReportName = null;
				strScriptName = null;
				strScriptId = null;
				guids = null;
				response.getWriter().write(joMessage.toString());			
			}
		} else if(strActionCommand.endsWith("/lt/uploadcsvdata")) {

			LoginUserBean loginUserBean = null;
			String strFileName = "", strFileExtension = "";
			JSONObject joRtn = null;
			boolean bupdated = false;
			try{
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				String upload_file_count = request.getParameter("upload_file_count")==null?"0":request.getParameter("upload_file_count");
				for(int mIndex=0; mIndex < Integer.parseInt(upload_file_count); mIndex++){

					strFileName = request.getParameter("file_name_"+mIndex);
					strFileName = strFileName.replace(" ", "").toLowerCase();
					strFileExtension = strFileName.substring(strFileName.lastIndexOf(".")+1).toLowerCase();
					strFileName = strFileName.substring(0, strFileName.lastIndexOf("."));
					
					if( !(strFileExtension.equals("csv")) ){
						throw new Exception("Not CSV");
					}
					
					String strvariablespath = Constants.VARIABLESFOLDERPATH+File.separator+loginUserBean.getUserId()+"_variables.xml";
					
					DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
					Document doc = docBuilder.parse(strvariablespath);
					
					NodeList variablelist = doc.getElementsByTagName("variable");
					for(int j=0; j<variablelist.getLength(); j++){
						Node nNode = variablelist.item(j);
						
						NamedNodeMap attr = nNode.getAttributes();
						if(attr.getNamedItem("name").getNodeValue().equalsIgnoreCase(request.getParameter("variableName"))){
							NodeList list = nNode.getChildNodes();
							for (int i = 0; i < list.getLength(); i++) {
								 
								Node node = list.item(i);
					 
							   // get the content element, and update the value
							   if ("content".equals(node.getNodeName())) {
								node.setTextContent(request.getParameter("file_content_"+mIndex));
							   }
							}
							bupdated = true;
						}
					}
					
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();
					DOMSource source = new DOMSource(doc);
					StreamResult result = new StreamResult(new File(strvariablespath));
					transformer.transform(source, result);
					if(bupdated){
						joRtn = UtilsFactory.getJSONSuccessReturn("Content has been successfully updated.");
					}else{
						joRtn = UtilsFactory.getJSONFailureReturn("Content was not updated.");
					}
				}
			}catch(Exception e){
				if(e.getMessage().equals("Not CSV")){
					joRtn = UtilsFactory.getJSONFailureReturn("Only CSV files can be uploaded");
				}
				LogManager.errorLog(e);
				e.printStackTrace();
			}finally{
				response.getWriter().write(joRtn.toString());
			}
		
		} else if(strActionCommand.endsWith("/lt/updateVariable")) {

			LoginUserBean loginUserBean = null;
			String strVariableName = "", strPolicy = "", strStartsFrom = "";
			JSONObject joRtn = null;
			boolean bupdated = false;
			try{
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				strVariableName = request.getParameter("variableName");
				strPolicy = request.getParameter("policy");
				strStartsFrom = request.getParameter("startsFrom");
				
					String strvariablespath = Constants.VARIABLESFOLDERPATH+File.separator+loginUserBean.getUserId()+"_variables.xml";
					
					DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
					Document doc = docBuilder.parse(strvariablespath);
					
					NodeList variablelist = doc.getElementsByTagName("variable");
					for(int j=0; j<variablelist.getLength(); j++){
						Node nNode = variablelist.item(j);
						
						NamedNodeMap attr = nNode.getAttributes();
						if(attr.getNamedItem("name").getNodeValue().equalsIgnoreCase(strVariableName)){
							
							Node nodeAttr = attr.getNamedItem("policy");
							nodeAttr.setTextContent(strPolicy);
							
							Node nodeAttr1 = attr.getNamedItem("start");
							nodeAttr1.setTextContent(strStartsFrom);
							
							bupdated = true;
						}
					}
					
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();
					DOMSource source = new DOMSource(doc);
					StreamResult result = new StreamResult(new File(strvariablespath));
					transformer.transform(source, result);
					if(bupdated){
						joRtn = UtilsFactory.getJSONSuccessReturn("Variable has been successfully updated.");
					}else{
						joRtn = UtilsFactory.getJSONFailureReturn("Variable  were not updated.");
					}
			}catch(Exception e){
				LogManager.errorLog(e);
				e.printStackTrace();
			}finally{
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/lt/deleteVariable")) {

			LoginUserBean loginUserBean = null;
			String strVariableName = "", expression = "";
			JSONObject joRtn = null;
			boolean bupdated = false;
			try{
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				strVariableName = request.getParameter("variableName");
				
				String strvariablespath = Constants.VARIABLESFOLDERPATH+File.separator+loginUserBean.getUserId()+"_variables.xml";
				
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(strvariablespath);
				
				XPath varxPath =  XPathFactory.newInstance().newXPath();
				expression = "/variables/variable[@name='"+strVariableName+"']";
				
				NodeList recfiletypeList = (NodeList) varxPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
				LogManager.infoLog("size="+recfiletypeList.getLength());
				int mnum = recfiletypeList.getLength();
				if(mnum>0){
					Element mnode = (Element) recfiletypeList.item(0);
					mnode.getParentNode().removeChild(mnode);
				}
				
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(new File(strvariablespath));
				transformer.transform(source, result);
				joRtn = UtilsFactory.getJSONSuccessReturn("Variable has been successfully removed.");
				
			}catch(Exception e){
				LogManager.errorLog(e);
				e.printStackTrace();
			}finally{
				response.getWriter().write(joRtn.toString());
			}
		
		} else if(strActionCommand.endsWith("/lt/getUserAgentDetails")) {
			JSONArray jaUserAgent = null;
			LTManager manager = null;
			Connection con = null;
			JSONObject joRtn = null;
			try {
				con = DataBaseManager.giveConnection();
				manager = new LTManager();
				
				jaUserAgent = manager.getUserAgentDetails(con);
				if((jaUserAgent != null) && (jaUserAgent.size() > 0)){
					joRtn = UtilsFactory.getJSONSuccessReturn(jaUserAgent);
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("No Data Available");
				}
				
				manager = null;
				
			}catch(Exception ioe) {
				LogManager.errorLog(ioe);
				joRtn = UtilsFactory.getJSONFailureReturn("Problem with Services");
			} finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/getRunSettings")){
			Connection con = null;
			LoginUserBean loginUserBean = null;
			JSONObject joRtn = null;
			JSONArray jaScenarios = null;
			LTManager ltManager = null;
			try {
				ltManager = new LTManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				con = DataBaseManager.giveConnection();
				long runId = Long.valueOf(request.getParameter("runId").trim());
				String scriptId = request.getParameter("scriptId") != null ? request.getParameter("scriptId") : "0";
				
				jaScenarios = ltManager.getRunSettings(con, loginUserBean.getUserId(), runId, Long.valueOf(scriptId));
				joRtn = UtilsFactory.getJSONSuccessReturn(jaScenarios);
				
				loginUserBean = null;
				ltManager = null;
				
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getRunSettings.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/getSummaryReportCategoryNote")){
			// gets runId's particular category's notes OR runId's particular category's script_id's notes
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			LTManager ltManager = null;
			
			JSONObject joRtn = null;
			
			SummaryReportNotesBean notesBean = null;
			
			long lRunId = -1L;
			String strCategory = "";
			Long lScriptId = null;
			
			try {
				ltManager = new LTManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lRunId = Long.parseLong( request.getParameter("runid") );
				strCategory = request.getParameter("category");
				if ( request.getParameter("scriptId") != null ) {
					// runid's category's script wise notes
					lScriptId = Long.parseLong( request.getParameter("scriptId") );	
				} else {
					// runid's category's notes
					lScriptId = -1L;
				}
				
				// gets runId's particular category's notes OR runId's particular category's script_id notes 
				notesBean = ltManager.getSummaryReportCategoryNote(con, lRunId, strCategory, lScriptId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn( notesBean != null ? notesBean.toJSON() : null );
				
				ltManager = null;
				loginUserBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Summary Report Category Note.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/insertSummaryReportCategoryNote")) {
			// inserts notes for the summary report categories
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			LTManager ltManager = null;
			
			JSONObject joRtn = null;
			
			SummaryReportNotesBean notesBean = null;
			
			try {
				ltManager = new LTManager();
				notesBean = new SummaryReportNotesBean();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				notesBean.setRunId( Long.parseLong(request.getParameter("runid")) );
				notesBean.setCategory( request.getParameter("category") );
				if ( request.getParameter("scriptId") != null ) {
					// runid's category's script wise notes
					notesBean.setScriptId( Long.parseLong(request.getParameter("scriptId")) );	
				} else {
					// runid's category's notes
					notesBean.setScriptId(-1L);
				}
				notesBean.setNotes(request.getParameter("notes"));
				
				// inserts for the notes for the user's run's 
				ltManager.insertSummaryReportCategoryNote(con, notesBean, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Notes added.");

				DataBaseManager.commitConnection(con);
				
				ltManager = null;
				loginUserBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Invalid user.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add Notes.");	
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/updateSummaryReportCategoryNote")) {
			// update notes for the summary report categories; update notes for the runid's OR runid's script's category
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			LTManager ltManager = null;
			
			JSONObject joRtn = null;
			
			SummaryReportNotesBean notesBean = null;
			
			try {
				ltManager = new LTManager();
				notesBean = new SummaryReportNotesBean();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				notesBean.setNoteId( Long.parseLong(request.getParameter("noteId")) );
				notesBean.setRunId( Long.parseLong(request.getParameter("runid")) );
				notesBean.setCategory( request.getParameter("category") );
				if ( request.getParameter("scriptId") != null ) {
					notesBean.setScriptId( Long.parseLong(request.getParameter("scriptId")) );	
				}
				notesBean.setNotes(request.getParameter("notes"));
				
				// update notes
				ltManager.updateSummaryReportCategoryNote(con, notesBean, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Notes updated.");
				
				
				DataBaseManager.commitConnection(con);
				
				ltManager = null;
				loginUserBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to update Notes.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/lt/getRunSummaryReportNotes")) {
			// gets run_id's category wise notes,
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			LTManager ltManager = null;
			
			HashMap<String, Object> hmRtnCategoryWiseNotes = null;
			
			JSONObject joRtn = null, joCategoryWiseNotes = null;
			
			long lRunId = -1L;
			
			try {
				ltManager = new LTManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lRunId = Long.parseLong(request.getParameter("runId"));
				
				// gets run_id's category wise notes,
				hmRtnCategoryWiseNotes = ltManager.getRunSummaryReportNotes(con, lRunId, loginUserBean);
				joCategoryWiseNotes = JSONObject.fromObject( hmRtnCategoryWiseNotes );
				joRtn = UtilsFactory.getJSONSuccessReturn( UtilsFactory.replaceNull(joCategoryWiseNotes, "") );
				
				
				ltManager = null;
				loginUserBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to update Notes.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
	}
	
}
