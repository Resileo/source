package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.RUMManager;
import com.appedo.module.utils.UtilsFactory;

/**
 * Servlet implementation class RUMController
 */
public class RUMController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RUMController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		
		response.setContentType("text/html");
		String action = request.getRequestURI();
		
		/*
		if(action.endsWith("/rum/getRUMTests")){
			RUMManager rumManager = null;
			Connection con = null;
			
			JSONArray jaRUMTests = null;
			String strGUID = null;
			long lUID = -1L;
			
			try{
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				
				strGUID = request.getParameter("guid");
				
				lUID = rumManager.getUID(con, strGUID);
				jaRUMTests = rumManager.getRUMTests(con, lUID);
				
				rumManager = null;
				strGUID = null;
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(jaRUMTests.toString());
			}
		} else */
		if(action.endsWith("/rum/getPagesLoadTime")){
			//
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			JSONArray jaRtnPagesLoadTime = null;
			JSONObject joRtn = null;
			
			String strFromStartInterval = null, strHealthCode = null;
			
			long lUID = -1L;
			
			RUMManager rumManager = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lUID = Long.parseLong(request.getParameter("uid"));
				strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				jaRtnPagesLoadTime = rumManager.getPagesLoadTime(con, lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnPagesLoadTime);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				strHealthCode = null;
				loginUserBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getPagesLoadTime. ");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getPagesLoadTimeWithDateRange")){
			//
			Connection con = null;
			
			JSONArray jaRtnPagesLoadTime = null;
			JSONObject joRtn = null;
			
			String strFromStartInterval = null, strToInterval = null;

			long lUID = -1L;
			
			RUMManager rumManager = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				lUID = Long.parseLong(request.getParameter("uid"));
				strFromStartInterval = request.getParameter("startDate");
				strToInterval = request.getParameter("endDate");
				
				jaRtnPagesLoadTime = rumManager.getPagesLoadTimeWithDateRange(con, lUID, strFromStartInterval, strToInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnPagesLoadTime);
				
				rumManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getPagesLoadTimeWithDateRange. ");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getPageLoadTimeChartData")){
			// gets page loaded times
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			RUMManager rumManager = null;
			
			JSONArray jaRtnPageLoadTimes = null;
			JSONObject joRtn = null;
			
			String strUID = null, strURL = null, strFromStartInterval = null, strHealthCode = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strUID = request.getParameter("uid");
				strFromStartInterval = request.getParameter("fromStartInterval");
				strURL = request.getParameter("url");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				// 
				jaRtnPageLoadTimes = rumManager.getPageLoadTimeChartData(con, strUID, strFromStartInterval, strURL, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnPageLoadTimes);
				
				rumManager = null;
				strUID = null;
				strFromStartInterval = null;
				strURL = null;
				strHealthCode = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				loginUserBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getPageLoadTimeChartData. ");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getPageLoadTimeChartDataWithDateRange")){
			// gets page loaded times
			Connection con = null;
			
			RUMManager rumManager = null;
			
			JSONArray jaRtnPageLoadTimes = null;
			JSONObject joRtn = null;
			
			String strUID = null, strURL = null, strFromStartInterval = null, strToInterval = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				strUID = request.getParameter("uid");
				strFromStartInterval = request.getParameter("startDate");
				strToInterval = request.getParameter("endDate");
				strURL = request.getParameter("url");
				
				jaRtnPageLoadTimes = rumManager.getPageLoadTimeChartDataWithDateRange(con, strUID, strFromStartInterval, strToInterval, strURL);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnPageLoadTimes);
				
				rumManager = null;
				strUID = null;
				strFromStartInterval = null;
				strToInterval = null;
				strURL = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getPageLoadTimeChartDataWithDateRange. ");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getPageBreakDownDetails")){
			Connection con = null;
			
			RUMManager rumManager = null;
			
			JSONObject joRtnPageBreakDownDetails = null;
			JSONObject joRtn = null;
			String strFromStartInterval = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lRUMId = Long.parseLong( request.getParameter("rumId") );
				strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				
				joRtnPageBreakDownDetails = rumManager.getPageBreakDownDetails(con, lUID, lRUMId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnPageBreakDownDetails);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getPageBreakDownDetails. ");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getPageBreakDownDetailsWithDateRange")){
			Connection con = null;
			
			RUMManager rumManager = null;
			
			JSONArray jaRtnPageBreakDownDetails = null;
			JSONObject joRtn = null;
			String strUID = null, strRUMId = null, strFromStartInterval = null, strToInterval = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				strUID = request.getParameter("uid");
				strRUMId = request.getParameter("rumId");
				strFromStartInterval = request.getParameter("startDate");
				strToInterval = request.getParameter("endDate");
				
				jaRtnPageBreakDownDetails = rumManager.getPageBreakDownDetailsWithDateRange(con, strUID, strFromStartInterval, strToInterval, strRUMId);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnPageBreakDownDetails);
				
				rumManager = null;
				strUID = null;
				strFromStartInterval = null;
				strRUMId = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getPageBreakDownDetailsWithDateRange. ");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getBrowserChartdata")){
			Connection con = null;
			RUMManager rumManager = null;

			LoginUserBean loginUserBean = null;
			
			JSONArray jaRtnBrowserWiseData = null;
			JSONObject joRtn = null;
			
			String strFromStartInterval = null, strHealthCode = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				//
				jaRtnBrowserWiseData = rumManager.getBrowserChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBrowserWiseData);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				strHealthCode = null;
				loginUserBean = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get browser wise data.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} /*else if(action.endsWith("/rum/getRumAllCharts_v1")){
			Connection con = null;
			RUMManager rumManager = null;

			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null, joRtnBrowserWiseData = null;
			
			String strFromStartInterval = null, strHealthCode = null, chartQuery = null, legendText = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				chartQuery = request.getParameter("chartQuery");
				legendText = request.getParameter("legendText");
				//
				joRtnBrowserWiseData = rumManager.getRumAllCharts_v1(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean, legendText, chartQuery);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnBrowserWiseData);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				strHealthCode = null;
				loginUserBean = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get browser wise data.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		}*/ else if(action.endsWith("/rum/getBrowserChartdataWithDateRange")){
			Connection con = null;
			RUMManager rumManager = null;
			
			JSONArray jaRtnBrowserWiseData = null;
			JSONObject joRtn = null;
			
			String strUID = null, strFromStartInterval = null, strToInterval = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				strUID = request.getParameter("uid");
				strFromStartInterval = request.getParameter("startDate");
				strToInterval = request.getParameter("endDate");
				
				jaRtnBrowserWiseData = rumManager.getBrowserChartdataWithDateRange(con, strUID, strFromStartInterval, strToInterval);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBrowserWiseData);
				
				rumManager = null;
				strUID = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get BrowserChartdataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getOSChartdata")){
			Connection con = null;
			LoginUserBean loginUserBean = null;

			RUMManager rumManager = null;
			
			JSONArray jaRtnOSWiseData = null;
			JSONObject joRtn = null;
			
			String strHealthCode = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				jaRtnOSWiseData = rumManager.getOSChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnOSWiseData);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				strHealthCode = null;
				loginUserBean = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get OS wise data.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getOSChartdataWithDateRange")){
			Connection con = null;

			RUMManager rumManager = null;
			
			JSONArray jaRtnOSWiseData = null;
			JSONObject joRtn = null;
			
			String strUID = null;
			
			try {
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				strUID = request.getParameter("uid");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnOSWiseData = rumManager.getOSChartdataWithDateRange(con, strUID, strFromStartInterval, strToInterval);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnOSWiseData);
				
				rumManager = null;
				strFromStartInterval = null;
				strToInterval = null;
				strUID = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getOSChartdataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getDeviceTypeChartdata")){
			
			Connection con = null;
			RUMManager rumManager = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONArray jaRtnDeviceTypeWiseData = null;
			JSONObject joRtn = null;
			
			String strUID = null, strHealthCode = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				jaRtnDeviceTypeWiseData = rumManager.getDeviceTypeChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceTypeWiseData);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				strHealthCode = null;
				loginUserBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get device type wise data.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getDeviceTypeChartdataWithDateRange")){
			
			Connection con = null;
			
			RUMManager rumManager = null;
			
			JSONArray jaRtnDeviceTypeWiseData = null;
			JSONObject joRtn = null;
			
			String strUID = null;
			
			try {
				con = DataBaseManager.giveConnection();

				rumManager = new RUMManager();
				
				strUID = request.getParameter("uid");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnDeviceTypeWiseData = rumManager.getDeviceTypeChartdataWithDateRange(con, strUID, strFromStartInterval, strToInterval);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceTypeWiseData);
				
				rumManager = null;
				strFromStartInterval = null;
				strToInterval = null;
				strUID = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceTypeChartdataWithDateRange.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getDeviceNamesChartdata")){
			
			Connection con = null;
			RUMManager rumManager = null;

			LoginUserBean loginUserBean = null;
			
			JSONArray jaRtnDeviceNameWiseData = null;
			JSONObject joRtn = null;
			
			String strHealthCode = null;

			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try{
				con = DataBaseManager.giveConnection();

				rumManager = new RUMManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong(request.getParameter("uid"));
				String strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				jaRtnDeviceNameWiseData = rumManager.getDeviceNamesChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceNameWiseData);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				loginUserBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get device name wise data.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getRUMLocationChartData")){
			
			Connection con = null;

			RUMManager rumManager = null;

			LoginUserBean loginUserBean = null;
			
			JSONArray jaLocationData = null;
			JSONObject joRtn = null;
			
			String strHealthCode = null;

			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try{
				con = DataBaseManager.giveConnection();
				rumManager = new RUMManager();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				jaLocationData = rumManager.getLocationChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaLocationData);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				loginUserBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get location wise data.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getRUMLocationWiseDataForWorldMap")){
			
			Connection con = null;

			RUMManager rumManager = null;
			
			String jaLocationData = null;
			JSONObject joRtn = null;
			
			String strUID = null;
			
			try{
				con = DataBaseManager.giveConnection();

				rumManager = new RUMManager();
				
				strUID = request.getParameter("uid");
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaLocationData = rumManager.getLocationChartdataForWorldMap(con, strUID, strFromStartInterval);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaLocationData);
				
				rumManager = null;
				strFromStartInterval = null;
				strUID = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get device name wise data.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getRUMLocationChartDataWithDateRange")){
			
			Connection con = null;

			RUMManager rumManager = null;
			
			JSONArray jaLocationData = null;
			JSONObject joRtn = null;
			
			String strUID = null;
			
			try{
				con = DataBaseManager.giveConnection();

				rumManager = new RUMManager();
				
				strUID = request.getParameter("uid");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaLocationData = rumManager.getRUMLocationChartDataWithDateRange(con, strUID, strFromStartInterval, strToInterval);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaLocationData);
				
				rumManager = null;
				strFromStartInterval = null;
				strToInterval = null;
				strUID = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getRUMLocationChartDataWithDateRange.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getVisitorsCount")) {
			// Gets Total Visitors count for the particular User's UID
			// For the given time interval
			Date dateLog = LogManager.logMethodStart();
			
			Connection con = null;
			
			JSONObject joRtn = null, joRtnVisitorsCount = null;
			
			RUMManager rumManager = null;
			
			try {
				rumManager = new RUMManager();
				
				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				// gets visitors count
				joRtnVisitorsCount = rumManager.getVisitorsCount(con, lUID, strFromStartInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnVisitorsCount);
				
				rumManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get VisitorsCount.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				LogManager.logMethodEnd(dateLog);
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getDailyVisitorsCount")) {
			// gets daily visitors count chart data for the particular user's uid
			Connection con = null;
			
			JSONObject joRtn = null, joRtnDailyVisitorsCount = null;
			
			RUMManager rumManager = null;
			
			LoginUserBean loginUserBean = null;
			
			String strFromStartInterval = null, strHealthCode = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = UtilsFactory.replaceNull(request.getParameter("healthCode"), "");
				
				// gets daily visitors count
				joRtnDailyVisitorsCount = rumManager.getDailyVisitorsCount(con, loginUserBean.getUserId(), lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode);
				joRtnDailyVisitorsCount.put("uid", lUID);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnDailyVisitorsCount);
				
				rumManager = null;
				strFromStartInterval = null;
				strHealthCode = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				loginUserBean = null;
			} catch (Throwable th) {
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDailyVisitorsCount.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getDailyVisitorsCount_v1")) {
			// gets daily visitors count chart data for the particular user's uid
			Connection con = null;
			
			JSONObject joRtn = null, joRtnDailyVisitorsCount = null;
			
			RUMManager rumManager = null;
			
			LoginUserBean loginUserBean = null;
			
			String strFromStartInterval = null, strHealthCode = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = UtilsFactory.replaceNull(request.getParameter("healthCode"), "");
				String query = request.getParameter("query");
				
				// gets daily visitors count
				joRtnDailyVisitorsCount = rumManager.getDailyVisitorsCount_v1(con, loginUserBean.getUserId(), lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, query);
				joRtnDailyVisitorsCount.put("uid", lUID);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnDailyVisitorsCount);
				
				rumManager = null;
				strFromStartInterval = null;
				strHealthCode = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				loginUserBean = null;
			} catch (Throwable th) {
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDailyVisitorsCount.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getDailyVisitorsCount_v2")) {
			// gets daily visitors count chart data for the particular user's uid
			Connection con = null;
			
			JSONObject joRtn = null, joRtnDailyVisitorsCount = null, joEnt = null;
			
			RUMManager rumManager = null;
			
			LoginUserBean loginUserBean = null;
			
			String strFromStartInterval = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null, user_id = -1L;
			String strXYLabel, strRumType;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				strFromStartInterval = request.getParameter("fromStartInterval");
				if ( strFromStartInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				Long lMetricId = Long.parseLong(request.getParameter("metricId"));
				strXYLabel = request.getParameter("xyLabel");
				strRumType = request.getParameter("rumType");
				
				//Enterprise implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getLong("e_id") != 0){
					user_id = joEnt.getLong("e_user_id");
				}else {
					user_id = loginUserBean.getUserId();
				}
				// gets daily visitors count
				joRtnDailyVisitorsCount = rumManager.getDailyVisitorsCount_v2(con, /*loginUserBean.getUserId()*/user_id, lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, lMetricId, strXYLabel, strRumType);

				joRtnDailyVisitorsCount.put("uid", lUID);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnDailyVisitorsCount);
				
				rumManager = null;
				strFromStartInterval = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				loginUserBean = null;
			} catch (Exception ex) {
				LogManager.errorLog(ex);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to RUM chart data.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
			
		} 
		else if(action.endsWith("/rum/getRUMCards")) {
			Connection con = null;
			
			JSONObject joRtn = null, joEnt = null;
			JSONArray jaRUMCardsData = null;
			
			RUMManager rumManager = null;
			
			LoginUserBean loginUserBean = null;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				jaRUMCardsData = rumManager.getRUMCards(con, loginUserBean.getUserId(), joEnt);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRUMCardsData);
				
			} catch (Throwable th) {
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get RUM cards.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				rumManager = null;
				loginUserBean = null;
				response.getWriter().write(joRtn.toString());
			}
			
		} else if(action.endsWith("/rum/getRUMFilterValues")) {
			Connection con = null;
			
			JSONObject joRtn = null;
			JSONArray jaRUMFilters = null;
			
			RUMManager rumManager = null;
			
			Long lUID = -1L; 
			long lStartDateTimeInMills = -1L, lEndDateTimeInMills = -1L;
			String filterType = null, sliderInterval;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				
				lUID = Long.parseLong( request.getParameter("uid") );
				sliderInterval = request.getParameter("fromStartInterval");
				if ( sliderInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				filterType = request.getParameter("filterType");
				
				jaRUMFilters = rumManager.getRUMFilterValues(con, lUID, filterType, sliderInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRUMFilters);
				
			} catch (Throwable th) {
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get RUM Filters data.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				rumManager = null;
				response.getWriter().write(joRtn.toString());
			}
			
		} else if(action.endsWith("/rum/getRUMDatas")) {
			Connection con = null;
			
			JSONObject joRtn = null;
			JSONArray jaRUMDatas = null;
			
			RUMManager rumManager = null;
			
			Long lUID = -1L; 
			long lStartDateTimeInMills = -1L, lEndDateTimeInMills = -1L;
			String filterType = null, sliderInterval = null, filterValue = null;
			
			try {
				rumManager = new RUMManager();
	
				con = DataBaseManager.giveConnection();
				
				lUID = Long.parseLong( request.getParameter("uid") );
				sliderInterval = request.getParameter("fromStartInterval");
				if ( sliderInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				filterType = request.getParameter("filterType");
				filterValue = request.getParameter("filterValue");
				
				jaRUMDatas = rumManager.getRUMDatas(con, lUID, null, filterType, filterValue, sliderInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRUMDatas);
				
			} catch (Throwable th) {
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get RUM data.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				rumManager = null;
				response.getWriter().write(joRtn.toString());
			}
			
		} else if(action.endsWith("/rum/getRUMSearchDatas")) {
			Connection con = null;
			
			JSONObject joRtn = null;
			JSONArray jaRUMDatas = null;
			
			RUMManager rumManager = null;
			
			Long lUID = -1L; 
			long lStartDateTimeInMills = -1L, lEndDateTimeInMills = -1L;
			String filterType = null, sliderInterval = null, filterValue = null, strSearchText = null;
			
			try {
				rumManager = new RUMManager();
	
				con = DataBaseManager.giveConnection();
				
				lUID = Long.parseLong( request.getParameter("uid") );
				sliderInterval = request.getParameter("fromStartInterval");
				
				if ( sliderInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				filterType = request.getParameter("filterType");
				filterValue = request.getParameter("filterValue");
				strSearchText = request.getParameter("rumSearchText");
				
				jaRUMDatas = rumManager.getRUMDatas(con, lUID, strSearchText, filterType, filterValue, sliderInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRUMDatas);
				
			} catch (Throwable th) {
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get RUM data.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				rumManager = null;
				response.getWriter().write(joRtn.toString());
			}
			
		} else if(action.endsWith("/rum/getDailyVisitorsCountWithDateRange")) {
			// gets daily visitors count chart data for the particular user's uid
			Connection con = null;
			
			JSONObject joRtn = null, joRtnDailyVisitorsCount = null;
			
			RUMManager rumManager = null;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				// gets daily visitors count
				joRtnDailyVisitorsCount = rumManager.getDailyVisitorsCountWithDateRange(con, lUID, strFromStartInterval, strToInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnDailyVisitorsCount);

				rumManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDailyVisitorsCountWithDateRange");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/rum/getRUMSiteDetails")) {
			// gets daily visitors count chart data for the particular user's uid
			Connection con = null;
			
			JSONArray json = null;
			
			
			RUMManager rumManager = null;
			LoginUserBean loginBean = null;
			try {
				rumManager = new RUMManager();
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				json = rumManager.getRUMSiteDetails(con, loginBean);
				
				loginBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(json.toString());
			}
		}else if(action.endsWith("/rum/getRUMSiteTransDetails")) {
			Connection con = null;
			JSONArray json = null;
			RUMManager rumManager = null;
			LoginUserBean loginBean = null;
			JSONObject joEnt = null;
			try {
				rumManager = new RUMManager();
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				long lUID = loginBean.getUserId();
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				json = rumManager.getRUMSiteTransDetails(con,lUID,"RUM", joEnt);
				
				loginBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(json.toString());
			}
		}else if(action.endsWith("/rum/getRUMAgentStatus")) {
			Connection con = null;
			JSONArray json = null;
			RUMManager rumManager = null;
			LoginUserBean loginBean = null;
			try {
				rumManager = new RUMManager();
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				long lUID = loginBean.getUserId();
				json = rumManager.getRUMAgentStatus(con,lUID);
				
				loginBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(json.toString());
			}
		}else if(action.endsWith("/rum/getRUMDashDonut")) {
			Connection con = null;
			JSONArray json = null;
			RUMManager rumManager = null;
			try {
				rumManager = new RUMManager();
				con = DataBaseManager.giveConnection();
                String moduleType = request.getParameter("moduleCode");
                String uid = request.getParameter("uid");
                String interval = request.getParameter("fromStartInterval") == null ?"1 hour":request.getParameter("fromStartInterval");
				json = rumManager.getRUMDashDonut(con,interval,moduleType,uid);
			} catch (Exception e) {
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(json.toString());
			}
		}else if(action.endsWith("/rum/getRUMLastReceivedOn")) {
			// gets last received on for particular rum uid
			Connection con = null;
			
			RUMManager rumManager = null;
			
			JSONObject joRtn = null;
			
			long lLastReceivedOn = 0L;
			
			try {
				con = DataBaseManager.giveConnection();

				rumManager = new RUMManager();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				
				lLastReceivedOn = rumManager.getRUMLastReceivedOn(con, lUID);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(lLastReceivedOn+"");
				
				rumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getRUMLastReceivedOn. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (action.endsWith("/rum/getRumAvgPageLoadTimeDonutCount")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			String donutCount = null;
			RUMManager rumManager = null;
			
			JSONObject joRtn = null;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				String interval = request.getParameter("interval")==null?"1 day":request.getParameter("interval");

				donutCount = rumManager.getRumAvgPageLoadTimeDonutCount(con, loginUserBean,interval);
				if(donutCount!=null){
					joRtn = UtilsFactory.getJSONSuccessReturn(donutCount);

				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getRumAvgPageLoadTimeDonutCount. ");

				}
				
				loginUserBean = null;
				rumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				e.printStackTrace();
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getRumAvgPageLoadTimeDonutCount. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (action.endsWith("/rum/getRumUrlWisePageView")) {
			Connection con = null;
			LoginUserBean loginUserBean = null;
			String barChart = null;
			RUMManager rumManager = null;
			
			JSONObject joRtn = null;
			
			try {
				rumManager = new RUMManager();

				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				String interval = request.getParameter("interval")==null?"1 day":request.getParameter("interval");

				barChart = rumManager.getRumUrlWisePageView(con, loginUserBean,interval);
				if(barChart!=null){
					if(barChart.length()>0){
						joRtn = UtilsFactory.getJSONSuccessReturn(barChart);
					}else{
						joRtn = UtilsFactory.getJSONSuccessReturn("[]");
					}
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("No Data Found. ");

				}
				
				loginUserBean = null;
				rumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getRumUrlWisePageView. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (action.endsWith("/rum/getTopRUMResponses")) {
			// gets RUM's most time taken responses, based on Browser, City, Device or Os
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			RUMManager rumManager = null;
			
			JSONObject joRtn = null;
			JSONArray jaRtnTopRUMResponses = null;
			
			String strInterval = null, strType = null, strTypeValue = null, strHealthCode = null;
			
			Long lStartDateTimeInMills = null, lEndDateTimeInMills = null;
			
			try {
				rumManager = new RUMManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				strType = request.getParameter("type");
				strTypeValue = request.getParameter("typeValue");
				strInterval = request.getParameter("interval");
				if ( strInterval == null ) {
					// custom date time interval 
					lStartDateTimeInMills = Long.parseLong(request.getParameter("startDateTime"));
					lEndDateTimeInMills = Long.parseLong(request.getParameter("endDateTime"));
				}
				strHealthCode = request.getParameter("healthCode");
				
				// gets RUM's most time taken responses, based on Browser, City, Device or Os
				jaRtnTopRUMResponses = rumManager.getTopRUMResponses(con, lUId, strType, strTypeValue, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnTopRUMResponses);

				loginUserBean = null;
				rumManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getTopRUMResponses.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				strInterval = null;
				strType = null;
				strTypeValue = null;
				lStartDateTimeInMills = null;
				lEndDateTimeInMills = null;
				strHealthCode = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}
