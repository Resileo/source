package com.appedo.module.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.MapCounterBean;
import com.appedo.module.bean.RUMSLABean;
import com.appedo.module.bean.SLAActionBean;
import com.appedo.module.bean.SLABean;
import com.appedo.module.bean.SLARuleBean;
import com.appedo.module.bean.SLASUMBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.dbi.SLADBI;
import com.appedo.module.model.CryptManager;
import com.appedo.module.model.SLAManager;
import com.appedo.module.utils.UtilsFactory;


/**
 * Servlet implementation class ModuleController
 */
public class SlaController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SlaController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		response.setContentType("text/html");
		String strActionCommand = request.getRequestURI();
		Connection con = null;
		
		if(strActionCommand.endsWith("/sla/getActionsCardLayout")) {
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaActions = null;
			
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				
				jaActions = slaManager.getSLAActions(con, loginBean);
				
				loginBean = null;
				slaManager = null;
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				
				loginBean = null;
				slaManager = null;
				response.getWriter().write(jaActions.toString());
			}
		}else if(strActionCommand.endsWith("/sla/getRulesCardLayout")) {
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaRules = null;
			
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				
				jaRules = slaManager.getSLARules(con, loginBean);
				
				loginBean = null;
				slaManager = null;
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(jaRules.toString());
			}
		}else if(strActionCommand.endsWith("/sla/getSLAsCardLayout")) {
			// gets SLA(s) for ASD's either (User generated or System generate), or SUM SLAs or RUM SLAs
			SLAManager slaManager = null;
			
			LoginUserBean loginBean = null;
			
			JSONArray jaSLAs = null;
			JSONObject joRtn = null;
			JSONObject joEnt = null;
			try {
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				
				boolean bSystemGenerated = Boolean.parseBoolean( request.getParameter("isSystem") );
				String strModuleCode = request.getParameter("moduleCode");
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				
				// gets SLAs either User added OR System generated OR SUM's, based respective boolean
				jaSLAs = slaManager.getSLAs(con, bSystemGenerated, strModuleCode, loginBean, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaSLAs);
				
				loginBean = null;
				slaManager = null;
			} catch(Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get SLAs.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				loginBean = null;
				slaManager = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/sla/getSlaveStatusCardLayout")) {
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaSlaSlaveCardLayout = null;
			
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				
				jaSlaSlaveCardLayout = slaManager.getSlaSlaveStatusCardLayout(con, loginBean);
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(jaSlaSlaveCardLayout.toString());
			}
		}else if(strActionCommand.endsWith("/sla/getSlaAlertCardLayout")) {
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joSlaAlertCardLayout = null, joEnt = null;
			long lSlaId = -1l, lLimit = -1l, lOffSet = -1l, lUser_id = -1L;
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lSlaId = Long.parseLong(request.getParameter("slaid"));
				lLimit = Long.parseLong(request.getParameter("limit"));
				lOffSet = Long.parseLong(request.getParameter("offset"));
				con = DataBaseManager.giveConnection();
				
				//Enterprise License Implemented.
				if(request.getParameter("e_data")!= null){
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					if(joEnt.getInt("e_id")!=0){
						lUser_id = joEnt.getLong("e_user_id");
					}else{
						lUser_id = loginBean.getUserId();
					}
				}else{
					lUser_id = loginBean.getUserId();
				}
				
				joSlaAlertCardLayout = slaManager.getSlaAlertCardLayout(con, /*loginBean*/ lUser_id, lSlaId, lLimit, lOffSet);
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joSlaAlertCardLayout.toString());
			}
		}else if(strActionCommand.endsWith("/sla/getSlaHealCardLayout")) {
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaSlaHealCardLayouts = null;
			long lSlaId = -1l;
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lSlaId = Long.parseLong(request.getParameter("slaid"));
				con = DataBaseManager.giveConnection();
				
				jaSlaHealCardLayouts = slaManager.getSlaHealCardLayout(con, loginBean, lSlaId);
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(jaSlaHealCardLayouts.toString());
			}
		} else if(strActionCommand.endsWith("/sla/addAction")){

			LoginUserBean loginBean = null;

			JSONObject joRtn = null;
			
			SLAManager slaManager = null;
			SLAActionBean actionBean = null;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				actionBean = new SLAActionBean();
				
				// TODO: Add one more column counter_id from counter_mater_<uid>, based on counter_id, counter_template_id, counter_version_id should come "UsePublicAction" field
				
				actionBean.setActionName(request.getParameter("actionName"));
				actionBean.setActionDescription(request.getParameter("actionDescription"));
				actionBean.setPublic(Boolean.parseBoolean(request.getParameter("isPublic")));
				actionBean.setParameterFormat(request.getParameter("parameterFormat"));
				actionBean.setParameterValues(request.getParameter("parameterValues"));
				actionBean.setScript(request.getParameter("script"));
				actionBean.setExecutionType(request.getParameter("executionType"));
				
				slaManager.addAction(con, actionBean, loginBean);
				
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Action saved.");
			} catch (Exception e) {
				
				DataBaseManager.rollbackConnection(con);		
				
				LogManager.errorLog(e);
				
				if( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Action name already exists. ");	
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to save action. Please try after sometimes. ");
				}
				
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/updateAction")){

			LoginUserBean loginBean = null;

			JSONObject joRtn = null;
			
			SLAManager slaManager = null;
			SLAActionBean actionBean = null;
			
			try {
				slaManager = new SLAManager();

				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				actionBean = new SLAActionBean();
				
				actionBean.setActionId( Long.parseLong(request.getParameter("actionId")) );
				actionBean.setActionName(request.getParameter("actionName"));
				actionBean.setActionDescription(request.getParameter("actionDescription"));
				actionBean.setPublic(Boolean.parseBoolean(request.getParameter("isPublic")));
				actionBean.setParameterFormat(request.getParameter("parameterFormat"));
				actionBean.setParameterValues(request.getParameter("parameterValues"));
				actionBean.setScript(request.getParameter("script"));
				actionBean.setExecutionType(request.getParameter("executionType"));
				
				slaManager.updateAction(con, actionBean, loginBean);
				
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Action updated.");
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update action. Action name already exists. ");
				} else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update action. An action is mapped to rule(s). ");
				} else if( e.getMessage().equals("3") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update action. An action is referred to other action(s). ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update action. Please try after sometimes. ");	
				}
				
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/deleteAction")){

			LoginUserBean loginBean = null;
			
			JSONObject joRtn = null;
			
			SLAManager slaManager = null;
			
			try {
				slaManager = new SLAManager();

				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lActionId = Long.parseLong(request.getParameter("actionId"));
				
				slaManager.deleteAction(con, lActionId, loginBean);
				
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Action deleted.");
			} catch (Exception e) {
				
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete action. An action is mapped to rule(s). ");
				} else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete action. An action is referred to other action(s). ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete action. Please try after sometimes. ");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		}  else if(strActionCommand.endsWith("/sla/getActionsForMapping")){

			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			JSONArray jaUserActions = null;			
			SLAManager slaManager = null;
			//String strActionType = null;
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				//strActionType = UtilsFactory.replaceNull(request.getParameter("actionType"), "");
				
				
				jaUserActions = slaManager.getActions(con,  loginBean); 
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserActions);
				
			} catch (Exception e) {
				LogManager.errorLog(e);

				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getUserPublicActions. Please try after sometimes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/getRulesForMapping")){

			LoginUserBean loginBean = null;
			JSONObject joRtn = null, joEnt;
			JSONArray jaUserActions = null;
			SLAManager slaManager = null;
			//String strActionType = null;
			long lUser_id = -1L;
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				//strActionType = UtilsFactory.replaceNull(request.getParameter("actionType"), "");
				
				//Enterprise License Implemented.
				if(request.getParameter("e_data")!= null){
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					if(joEnt.getInt("e_id")!=0){
						lUser_id = joEnt.getLong("e_user_id");
					}else{
						lUser_id = loginBean.getUserId();
					}
				}else{
					lUser_id = loginBean.getUserId();
				}
				
				jaUserActions = slaManager.getRules(con,  /*loginBean*/lUser_id); 
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaUserActions);
				
			} catch (Exception e) {
				LogManager.errorLog(e);

				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getUserPublicActions. Please try after sometimes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/addSlaRule")){

			LoginUserBean loginBean = null;

			JSONObject joRtn = null;
			
			SLAManager slaManager = null;
			SLARuleBean ruleBean = null;
			try {
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				ruleBean = new SLARuleBean();
				//List<String> actionIds = new ArrayList<String>();
				
				ruleBean.setRuleName(request.getParameter("ruleName"));
				ruleBean.setRuleDescription(request.getParameter("ruleDescription"));
				//ruleBean.setPublic(Boolean.parseBoolean(request.getParameter("isPublic")));
				//ruleBean.setActionId(Long.parseLong(request.getParameter("actionId")));
				//actionIds = (ArrayList<Long>)(request.getParameterValues("actionIds");
				//String[] actIds = request.getParameterValues("actionIds");
				//actionIds = (ArrayList<String>)request.getParameter("actionIds");
				//List<String> actionIds = Arrays.asList(actIds);
				
				JSONArray jaActions = JSONArray.fromObject(request.getParameter("actionIds"));
				
				//[{"action_id":18,"action_name":"Action","isSelected":true,"$$hashKey":"object:40"},{"action_id":"19","action_name":"Action Name","isSelected":true,"$$hashKey":"object:41"}]
				
				joRtn = slaManager.addRule(con, ruleBean, loginBean, jaActions);
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Rule saved.");
				
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to add rule. Please try after sometimes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/updateSlaRule")){
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			SLAManager slaManager = null;
			SLARuleBean ruleBean = null;
			
			try {
				slaManager = new SLAManager();

				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				ruleBean = new SLARuleBean();

				ruleBean.setRuleId(Long.parseLong(request.getParameter("ruleId")));
				ruleBean.setRuleName(request.getParameter("ruleName"));
				ruleBean.setRuleDescription(request.getParameter("ruleDescription"));
				//ruleBean.setPublic(Boolean.parseBoolean(request.getParameter("isPublic")));
				//ruleBean.setActionId(Long.parseLong(request.getParameter("actionId")));
				//actionIds = (ArrayList<Long>)(request.getParameterValues("actionIds");
				//String[] actIds = request.getParameterValues("actionIds");
				//actionIds = (ArrayList<String>)request.getParameter("actionIds");
				//List<String> actionIds = Arrays.asList(actIds);
				
				JSONArray jaActions = JSONArray.fromObject(request.getParameter("actionIds"));
				
				joRtn = slaManager.updateSlaRule(con, ruleBean, loginBean, jaActions);
				DataBaseManager.commitConnection(con);
				
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to update rule. Please try after sometimes. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/sla/deleteRule")){

			LoginUserBean loginBean = null;
			
			JSONObject joRtn = null;
			
			SLAManager slaManager = null;
			
			try {
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long ruleId = Long.parseLong(request.getParameter("ruleId"));
				
				joRtn = slaManager.deleteRule(con, ruleId, loginBean);
				DataBaseManager.commitConnection(con);
				
			} catch (Exception e) {
				
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				
				if( e.getMessage().equals("1") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete rule. Rule is associated.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete Rule. Please try after sometime.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/addSLAPolicy")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null, joEnt = null;
			long lSLAID = -1L;
			SLABean slaBean = null;
			JSONObject joRule =  null;
			int nSlaMapRuleId = -1;
			try{
				slaManager = new SLAManager();
				slaBean = new SLABean();

				String strSlaPolicyName = request.getParameter("policyName");
				String strSlaPolicyDesc = request.getParameter("policyDesc");
				String strpolicySvrType = request.getParameter("policySvrType");
				// 
				joRule = JSONObject.fromObject(request.getParameter("mapRuleId"));
				
				nSlaMapRuleId = joRule.containsKey("ruleId")? joRule.getInt("ruleId"): -1;
				String strAlertType = request.getParameter("alertType");
				JSONObject joSlaConfigServFormat = JSONObject.fromObject(request.getParameter("configServFormat"));
				
				
				slaBean.setSLAName(strSlaPolicyName);
				slaBean.setSLADescription(strSlaPolicyDesc);
				slaBean.setMapRuleId(nSlaMapRuleId);
				slaBean.setJoSlaConfigServFormat(joSlaConfigServFormat);
				slaBean.setSLAType(strAlertType);
				slaBean.setPolicySvrType(strpolicySvrType);
				slaBean.setSystemGeneratedSLA(false);
				slaBean.setActivePolicy( Boolean.parseBoolean(request.getParameter("activePolicy")) );
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				//implemented Enterprise License.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				lSLAID = slaManager.addSla(con, slaBean, loginBean, joEnt);
				if(lSLAID != -1l) {
					joRtn = UtilsFactory.getJSONSuccessReturn("SLA Record has been added.");
					joRtn.put("slaId", lSLAID);
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("SLA Name already Exist.");
				}
				
				DataBaseManager.commitConnection(con);
				slaManager = null;
				slaBean = null;
			}catch(Exception e){
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to add");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaBean = null;
				joRule = null;
				slaManager = null;
				slaBean = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/addSlaSum")){
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			long lSLAID = -1L;
			SLASUMBean slaSUMBean = null;
			try{
				slaManager = new SLAManager();
				slaSUMBean = new SLASUMBean();

				String slaId = request.getParameter("sla_id");
				String sumTestId = request.getParameter("sum_test_id");
				Boolean aboveThreashold = Boolean.parseBoolean(request.getParameter("is_above_threashold")==null?"true":request.getParameter("is_above_threashold"));
				String sumCounterName = request.getParameter("sum_counter_name")==null?"pageloadtime":request.getParameter("sum_counter_name");
				String warningLimit = request.getParameter("warning_limit");
				String errorLimit = request.getParameter("error_limit");
				String minBreachCount = request.getParameter("min_breach_count");
				String breachTypeId = request.getParameter("breach_type_id")==null?"3":request.getParameter("breach_type_id");
				
				slaSUMBean.setSlaId(Long.parseLong(slaId));
				slaSUMBean.setSumTestId(Long.parseLong(sumTestId));
				slaSUMBean.setAboveThreashold(aboveThreashold);
				slaSUMBean.setSumCounterName(sumCounterName);
				slaSUMBean.setWarningLimit(Integer.parseInt(warningLimit));
				slaSUMBean.setErrorLimit(Integer.parseInt(errorLimit));
				slaSUMBean.setMinBreachCount(Integer.parseInt(minBreachCount));
				slaSUMBean.setBreachTypeId(Integer.parseInt(breachTypeId));
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lSLAID = slaManager.addSlaSum(con, slaSUMBean, loginBean);
				if(lSLAID != -1l) {
					joRtn = UtilsFactory.getJSONSuccessReturn("SUM SLA Record has been added.");
					joRtn.put("lSLASumId", lSLAID);
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("SLA Name already Exist.");
				}
				
				DataBaseManager.commitConnection(con);
				slaManager = null;
				slaSUMBean = null;
			}catch(Exception e){
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to add SLA SUM");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaSUMBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/deleteSlaSum")){
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			try{
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lSUMTestId = Long.parseLong( request.getParameter("sum_test_id") );
				
				// delete SUM Test's SLA refs
				slaManager.deleteSUMSLA(con, lSUMTestId, loginBean);
				
				DataBaseManager.commitConnection(con);
				joRtn = UtilsFactory.getJSONSuccessReturn("SUM SLA Record has been deleted.");
				slaManager = null;
			}catch(Exception e){
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to Delete SLA SUM");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/deleteSlaAvm")){
			//  Controller which deletes AVM's sla policy 
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			try{
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();

				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				long lAVMTestId = Long.parseLong( request.getParameter("avm_test_id") );

				// delete AVM Test's SLA refs
				slaManager.deleteAVMSLA(con, lAVMTestId, loginBean);

				DataBaseManager.commitConnection(con);
				joRtn = UtilsFactory.getJSONSuccessReturn("AVM SLA Record has been deleted.");
				slaManager = null;
			}catch(Exception e){
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to Delete SLA AVM");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/addSUMSLAPolicy")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			long lSLAID = -1L;
			SLABean slaBean = null;
			JSONObject joRule =  null;
			int nSlaMapRuleId = -1;
			try{
				slaManager = new SLAManager();
				slaBean = new SLABean();

				String strSlaPolicyName = request.getParameter("policyName");
				String strSlaPolicyDesc = request.getParameter("policyDesc");
				String strpolicySvrType = request.getParameter("policySvrType");
				// 
				joRule = JSONObject.fromObject(request.getParameter("mapRuleId"));
				
				nSlaMapRuleId = joRule.containsKey("ruleId")? joRule.getInt("ruleId"): -1;
				String strAlertType = request.getParameter("alertType");
				JSONObject joSlaConfigServFormat = JSONObject.fromObject(request.getParameter("configServFormat"));
				
				
				slaBean.setSLAName(strSlaPolicyName);
				slaBean.setSLADescription(strSlaPolicyDesc);
				slaBean.setMapRuleId(nSlaMapRuleId);
				slaBean.setJoSlaConfigServFormat(joSlaConfigServFormat);
				slaBean.setSLAType(strAlertType);
				slaBean.setPolicySvrType(strpolicySvrType);
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lSLAID = slaManager.addSUMSla(con, slaBean, loginBean);
				if(lSLAID != -1l) {
					joRtn = UtilsFactory.getJSONSuccessReturn("SLA Record has been added.");
					joRtn.put("slaId", lSLAID);
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("SLA Name already Exist.");
				}
				
				DataBaseManager.commitConnection(con);
				slaManager = null;
				slaBean = null;
			}catch(Exception e){
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to add");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaBean = null;
				joRule = null;
				slaManager = null;
				slaBean = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/updateSLAPolicy")){
			SLAManager slaManager = null;
			
			LoginUserBean loginBean = null;
			JSONObject joRtn = null , joEnt = null;
			
			SLABean slaBean = null;
			String strSLAMappedGUIDs = "";
			
			JSONObject joRule =  null;
			long lUser_id = -1L;
			
			try{
				slaManager = new SLAManager();
				slaBean = new SLABean();
				
				String strSlaPolicyName = request.getParameter("policyName");
				String strSlaPolicyDesc = request.getParameter("policyDesc");
				String strpolicySvrType = request.getParameter("policySvrType");
				// 
				joRule = JSONObject.fromObject(request.getParameter("mapRuleId"));
				
				int nSlaMapRuleId = joRule.containsKey("ruleId")?joRule.getInt("ruleId"):-1;
				String strAlertType = request.getParameter("alertType");
				JSONObject joSlaConfigServFormat = new JSONObject();
				if(strAlertType.equalsIgnoreCase("Alert&Heal")){
					joSlaConfigServFormat = JSONObject.fromObject(request.getParameter("configServFormat"));
				}
				
				slaBean.setSLAId(Integer.parseInt(request.getParameter("slaId")));
				
				slaBean.setSLAName(strSlaPolicyName);
				slaBean.setSLADescription(strSlaPolicyDesc);
				slaBean.setMapRuleId(nSlaMapRuleId);
				slaBean.setJoSlaConfigServFormat(joSlaConfigServFormat);
				slaBean.setSLAType(strAlertType);
				slaBean.setPolicySvrType(strpolicySvrType);
				slaBean.setActivePolicy( Boolean.parseBoolean(request.getParameter("activePolicy")) );
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				//Enterprise License Implemented.
				if(request.getParameter("e_data")!= null){
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					if(joEnt.getInt("e_id")!=0){
						lUser_id = joEnt.getLong("e_user_id");
					}else{
						lUser_id = loginBean.getUserId();
					}
				}else{
					lUser_id = loginBean.getUserId();
				}
				
				slaManager.updateSLA(con, slaBean, /*loginBean*/ lUser_id);
				joRtn = UtilsFactory.getJSONSuccessReturn("SLA updated.");
				
				DataBaseManager.commitConnection(con);
				
				/*
				 * send counters to collector for change of Activate or Deactivate, 
				 * mapped GUIDs would be `null`/"" for SUM SLAPolicy, OR policy might have no counter(s) mapped;
				 * Note: Send request only after con's commit
				 */
				strSLAMappedGUIDs = slaManager.getSLAMappedActiveGUIDs(con, slaBean.getSLAId());
				if ( strSLAMappedGUIDs.length() > 0 ) {
					slaManager.sendGUIDsActiveSLAsToCollector(strSLAMappedGUIDs);	
				}
				
				slaManager = null;
				loginBean = null;
			}catch(Exception e){
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				
				if ( e.getMessage().equals("1") ) {
					// err, SLA Name already Exist.
					joRtn = UtilsFactory.getJSONFailureReturn("SLA Name already Exist.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to update SLA policy.");	
				}
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				loginBean = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/enableOrDisableSLAPolicy")){
			// added to active or deactivate SLA policy
			JSONObject joRtn = null;
			
			LoginUserBean loginUserBean = null;
			
			SLAManager slaManager = null;
			
			String strSLAMappedGUIDs = "";
			
			boolean bActivePolicy = false;
			long lSLAId = -1L;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				bActivePolicy = Boolean.parseBoolean( request.getParameter("activePolicy") );
				lSLAId = Long.parseLong( request.getParameter("slaId") );
				
				// activate or deactivate SLA policy
				slaManager.enableOrDisableSLA(con, lSLAId, bActivePolicy, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Alert "+(bActivePolicy ? "enabled" : "disabled")+".");

				DataBaseManager.commitConnection(con);
				
				/*
				 * send counters to collector for change of Activate or Deactivate, 
				 * Note: Send request only after con's commit
				 */
				strSLAMappedGUIDs = slaManager.getSLAMappedActiveGUIDs(con, lSLAId);
				if ( strSLAMappedGUIDs.length() > 0 ) {
					slaManager.sendGUIDsActiveSLAsToCollector(strSLAMappedGUIDs);	
				}
				
				slaManager = null;
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to "+(bActivePolicy ? "enabled" : "disabled")+" alert.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				slaManager = null;
				loginUserBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/deleteSLAPolicy")){
			SLAManager slaManager = null;
			
			LoginUserBean loginBean = null;
			
			JSONObject joRtn = null;
			
			String strSLAMappedGUIDs = "";
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lSLAId = Long.parseLong(request.getParameter("slaId"));

				// gets guid(s) mapped to SLA, send to collector, for update SLAs in agent
				strSLAMappedGUIDs = slaManager.getSLAMappedActiveGUIDs(con, lSLAId);
				
				// delete record logically
				slaManager.logicallyDeleteSLAs(con, lSLAId, loginBean);
				DataBaseManager.commitConnection(con);
				
				// send guid(s) active SLA to collector, to updated latest SLA(s) in the agent,
				// Note: Send request only after con's commit
				if ( strSLAMappedGUIDs.length() > 0 ) {
					slaManager.sendGUIDsActiveSLAsToCollector(strSLAMappedGUIDs);	
				}
				
				joRtn = UtilsFactory.getJSONSuccessReturn("SLA policy deleted.");
				slaManager = null;
				loginBean = null;
			} catch(Exception e) {
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete policy.");
				LogManager.errorLog(e);
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				slaManager = null;
				loginBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/getModuleTypeValues")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaModules = null;
			JSONObject joEnt = null;
			String strType = null;
			try{
				slaManager = new SLAManager();
				strType = request.getParameter("type");

				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				//Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				
				jaModules = slaManager.getModuleTypeValues(con, strType, loginBean, joEnt);
				
				strType = null;
				slaManager = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				strType = null;
				slaManager = null;
				loginBean = null;
				response.getWriter().write(jaModules.toString());
			}
		} else if(strActionCommand.endsWith("/categories")){
			
			SLAManager slaManager = null;
			JSONArray jaCategories = null;
			LoginUserBean loginBean = null;
			
			String strUid = null;
			try{
				slaManager = new SLAManager();
				strUid = request.getParameter("uid");

				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				jaCategories = slaManager.getCategory(con, Integer.parseInt(strUid));
				
				strUid = null;
				slaManager = null;
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				strUid = null;
				slaManager = null;
				response.getWriter().write(jaCategories.toString());
			}
		} else if(strActionCommand.endsWith("/sla/getCounters")){
			
			SLAManager slaManager = null;
			JSONArray jaCounters = null;
			JSONObject joRtn = null;
			
			try{
				slaManager = new SLAManager();
				long lUID = Long.parseLong(request.getParameter("uid"));
				//strCategory = request.getParameter("category");
				
				con = DataBaseManager.giveConnection();
				
				jaCounters = slaManager.getCounters(con, lUID);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaCounters);
				
				slaManager = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get metrics.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				
				slaManager = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/addMapCounter")){
			SLAManager slaManager = null;
			MapCounterBean mapCounterBean = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;

			try{
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				mapCounterBean = new MapCounterBean();
				mapCounterBean.setBreachId(Integer.parseInt(request.getParameter("breachId")));
				mapCounterBean.setCounterId(Integer.parseInt(request.getParameter("counterId")));
				mapCounterBean.setCounterName(request.getParameter("counterName"));
				mapCounterBean.setCounterTemplateId(Integer.parseInt(request.getParameter("ctId")));
				mapCounterBean.setCounterTypeVersionId(Integer.parseInt(request.getParameter("ctvId")));
				mapCounterBean.setGuid(request.getParameter("guid"));
				mapCounterBean.setInPercentage(Boolean.parseBoolean(request.getParameter("inPercentage")));
				mapCounterBean.setIsThresholdAbove(Boolean.parseBoolean(request.getParameter("isThresholdAbove")));
				mapCounterBean.setMinBreachCount(Integer.parseInt(request.getParameter("minBreachCount")));
				mapCounterBean.setModuleName(request.getParameter("moduleName"));
				mapCounterBean.setModuleDetailedValue(request.getParameter("moduleValue"));
				mapCounterBean.setWarningThresholdValue(Long.parseLong(request.getParameter("warning_threshold_value")));
				mapCounterBean.setCriticalThresholdValue(Long.parseLong(request.getParameter("critical_threshold_value")));
				mapCounterBean.setUId(Integer.parseInt(request.getParameter("uid")));
				mapCounterBean.setSLAId(Integer.parseInt(request.getParameter("slaId")));
				mapCounterBean.setCategory(request.getParameter("category"));
				mapCounterBean.setDenominatorCounteId(Integer.parseInt(request.getParameter("denominator_counter_id")));
				mapCounterBean.setIsPercentageCalculation(Boolean.parseBoolean(request.getParameter("percentage_calculation")));

				// map module's/uid's counter to SLA
				slaManager.addMapCounter(con, mapCounterBean, loginBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Metric has been mapped successfully.");

				DataBaseManager.commitConnection(con);

				// sends guid(s)'s counters SLA to collector, to update in agent;
				// Note: Send request only after con's commit
				slaManager.sendGUIDsActiveSLAsToCollector(mapCounterBean.getGuid());

				slaManager = null;
				mapCounterBean = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					// err, the module's counter is already mapped to the policy
					joRtn = UtilsFactory.getJSONFailureReturn("Metric is already mapped to the policy.");
				} else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map metric. As its relative metric \""+e.getCause().getMessage()+"\" is not configured.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map metric to policy.");
				}
			}finally{
				DataBaseManager.close(con);
				con = null;

				slaManager = null;
				mapCounterBean = null;
				loginBean = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/updateMapCounter")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			MapCounterBean mapCounterBean = null;
			
			JSONObject joRtn = null;
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				mapCounterBean = new MapCounterBean();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				mapCounterBean.setMapCounterId(Integer.parseInt(request.getParameter("mapCounterId")));
				mapCounterBean.setWarningThresholdValue(Long.parseLong(request.getParameter("warning_threshold_value")));
				mapCounterBean.setCriticalThresholdValue(Long.parseLong(request.getParameter("critical_threshold_value")));
				mapCounterBean.setMinBreachCount(Integer.parseInt(request.getParameter("minBreachCount")));
				mapCounterBean.setInPercentage(Boolean.parseBoolean(request.getParameter("inPercentage")));
				mapCounterBean.setIsThresholdAbove(Boolean.parseBoolean(request.getParameter("isThresholdAbove")));
				mapCounterBean.setGuid(request.getParameter("guid"));
				
				slaManager.updateMapCounter(con, mapCounterBean, loginBean);
				DataBaseManager.commitConnection(con);
				
				// sends guid(s)'s counters SLA to collector, to update in agent; 
				// Note: Send request only after con's commit
				slaManager.sendGUIDsActiveSLAsToCollector(mapCounterBean.getGuid());
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Metric updated.");
				
				slaManager = null;
				loginBean = null;
				mapCounterBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/getAllSLAAlert")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null, joEnt = null;
			JSONArray joAlertData = null;
			
			long lUserId = -1L;
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				String strModuleType = request.getParameter("moduleType");
				Long lUID = Long.parseLong(request.getParameter("uid"));
				Long lCounterId = Long.parseLong(request.getParameter("counterId"));
				
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));
				if(joEnt.getInt("e_id")!=0){
					lUserId = joEnt.getLong("e_user_id");
				}else{
					lUserId = loginBean.getUserId();
				}
				
				joAlertData = slaManager.getAllSLAAlert(con, lUserId, joEnt.getLong("e_id"), strModuleType, lUID, lCounterId);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joAlertData);
				
				slaManager = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get alerts");
			}finally{
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/getMapCounters")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaMapCounters = null;
			JSONObject joRtn = null, joEnt = null;
			long lUser_id =-1L;
			try{
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lSLAId = Long.parseLong(request.getParameter("slaId"));
				
				//Enterprise License Implemented.
				if(request.getParameter("e_data")!= null){
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					if(joEnt.getInt("e_id")!=0){
						lUser_id = joEnt.getLong("e_user_id");
					}else{
						lUser_id = loginBean.getUserId();
					}
				}else{
					lUser_id = loginBean.getUserId();
				}
				
				jaMapCounters = slaManager.getMapCounters(con, lSLAId, /*loginBean*/ lUser_id);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaMapCounters);
				
				slaManager = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get mapped metrics.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				loginBean = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/getCounterMappedAlerts")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaMapCounters = null;
			JSONObject joRtn = null;
			try{
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				Long lUID = Long.parseLong(request.getParameter("uid"));
				Long lCounterId = Long.parseLong(request.getParameter("counterId"));
				
				jaMapCounters = slaManager.getCounterMappedAlerts(con, lUID, lCounterId);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaMapCounters);
				
				slaManager = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get mapped metrics.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				loginBean = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/setSlaSettings")) {
			
			LoginUserBean loginBean = null;
			SLAManager manager = null;
			
			JSONObject joRtn = null;
			
			int nMaxTryCount = 0;
			int nTryCountDuration = 0;
			int nTriggerAlertDuration = 0;
			try {
				manager =  new SLAManager();	
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
								
				nMaxTryCount = Integer.parseInt(request.getParameter("maxTry"));
				nTryCountDuration = Integer.parseInt(request.getParameter("maxTryDuration"));
				nTriggerAlertDuration = Integer.parseInt(request.getParameter("alertTriggerFrequency"));
							
				manager.slaSettings(con, nMaxTryCount, nTryCountDuration, nTriggerAlertDuration, loginBean);
				
				DataBaseManager.commitConnection(con);
				
				loginBean = null;
				manager = null;
				joRtn = UtilsFactory.getJSONSuccessReturn("SLA Alert has been saved.");
			} catch (Exception e) {
				
				LogManager.errorLog(e);
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				}
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to save.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				manager = null;
				response.getWriter().write(joRtn.toString());
			} 
		} else if(strActionCommand.endsWith("/sla/saveAlerts")) {
			// adds SLA alert address
			LoginUserBean loginBean = null;
			SLAManager manager = null;
			JSONObject joRtn = null;
			
			String strMobileOrEmail = null , strType = null;
			int nTelephoneCode;
			
			boolean bMailSent = false;
			
			try {
				manager =  new SLAManager();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strType = request.getParameter("type");
				strMobileOrEmail = request.getParameter("emailornumber");
				nTelephoneCode = Integer.parseInt(request.getParameter("telephoneCode"));
				
				// adds alert address 
				bMailSent = manager.addAlertAddress(con, strType, strMobileOrEmail, nTelephoneCode, loginBean.getUserId(), loginBean, true);
				joRtn = UtilsFactory.getJSONSuccessReturn("SLA Alert has been saved.");
				joRtn.put("emailSent", bMailSent);
				
				DataBaseManager.commitConnection(con);
				
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(e);
				
				if ( e.getMessage().equals("1") ) {
					// throw exception, email_mobile already added for the agent
					joRtn = UtilsFactory.getJSONFailureReturn("Alert email address/mobile already exists.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to save alert address.");	
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				loginBean = null;
				manager = null;
				
				response.getWriter().write(joRtn.toString());
			} 
		} else if(strActionCommand.endsWith("/sla/getSLASettings")) {
			SLAManager manager = null;
			LoginUserBean loginBean = null;
			JSONObject joSetting = null;
			try {
				manager =  new SLAManager();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// Get the sla settings 
				joSetting = manager.getSLASettings(con, loginBean);
				
				manager = null;
				loginBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				manager = null;
				loginBean = null;
				response.getWriter().write(joSetting.toString());
			} 
		} else if(strActionCommand.endsWith("/sla/getAlertsSettings")) {
			
			LoginUserBean loginBean = null;
			SLAManager manager = null;
			
			JSONObject joRtn = null;
			JSONArray jaSLARecords = null;
			
			try {
				manager =  new SLAManager();

				//getAlertsSettings
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				jaSLARecords = manager.getAlertsSettings(con, loginBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaSLARecords);
						
				loginBean = null;
				manager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get SLA alert addresses.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				loginBean = null;
				manager = null;
				
				response.getWriter().write(joRtn.toString());
			} 
		} else if(strActionCommand.endsWith("/sla/deleteMapCounter")){
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			
			long lSlaId, lMapCounterId;
			
			String strGUID = null;
			
			JSONObject joRtn = null;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject(JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				lSlaId = Long.parseLong(request.getParameter("slaId"));
				lMapCounterId = Long.parseLong(request.getParameter("counterId"));
				strGUID = request.getParameter("guid");
				
				slaManager.deleteMapCounter(con, lSlaId, lMapCounterId, loginBean);
				DataBaseManager.commitConnection(con);
				
				// sends guid(s)'s counters SLA to collector, to update in agent; 
				// Note: Send request only after con's commit
				slaManager.sendGUIDsActiveSLAsToCollector(strGUID);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Metric has been removed.");
			}catch(Exception e){
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONSuccessReturn("Unable to remove the metric.");
			}finally{
				DataBaseManager.close(con);
				con = null;
				
				strGUID = null;
				slaManager = null;
				loginBean = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/getBreachType")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaBreches = null;
			
			try{
				slaManager = new SLAManager();

				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				jaBreches = slaManager.getBrechTypes(con, loginBean);
				
				slaManager = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				loginBean = null;
				response.getWriter().write(jaBreches.toString());
			}
		} else if(strActionCommand.endsWith("/mapToAlert")){
			SLAManager slaManager = null;
			MapCounterBean mapCounterBean = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;

			try{
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				mapCounterBean = new MapCounterBean();
				mapCounterBean.setBreachId(Integer.parseInt(request.getParameter("breachId")));
				mapCounterBean.setCounterId(Integer.parseInt(request.getParameter("counterId")));
				mapCounterBean.setGuid(request.getParameter("guid"));
				mapCounterBean.setUId(Integer.parseInt(request.getParameter("uid")));
				mapCounterBean.setInPercentage(Boolean.parseBoolean(request.getParameter("inPercentage")));
				mapCounterBean.setIsThresholdAbove(Boolean.parseBoolean(request.getParameter("isThresholdAbove")));
				mapCounterBean.setMinBreachCount(Integer.parseInt(request.getParameter("minBreachCount")));
				mapCounterBean.setWarningThresholdValue(Long.parseLong(request.getParameter("warning_threshold_value")));
				mapCounterBean.setCriticalThresholdValue(Long.parseLong(request.getParameter("critical_threshold_value")));
				mapCounterBean.setSLAId(Integer.parseInt(request.getParameter("slaId")));

				// map module's/uid's counter to SLA
				slaManager.mapToAlert(con, mapCounterBean, loginBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Metric has been mapped to selected alert.");

				DataBaseManager.commitConnection(con);

				// sends guid(s)'s counters SLA to collector, to update in agent;
				// Note: Send request only after con's commit
				slaManager.sendGUIDsActiveSLAsToCollector(mapCounterBean.getGuid());

				slaManager = null;
				mapCounterBean = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					// err, the module's counter is already mapped to the policy
					joRtn = UtilsFactory.getJSONFailureReturn("Metric is already mapped to the policy.");
				} else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map metric. As its relative metric \""+e.getCause().getMessage()+"\" is not configured.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map metric to policy.");
				}
			}finally{
				DataBaseManager.close(con);
				con = null;

				slaManager = null;
				mapCounterBean = null;
				loginBean = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/addAlertAndCounter")){
			SLAManager slaManager = null;
			MapCounterBean mapCounterBean = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null, joEnt = null;
			JSONObject joRule = null;
			int nSlaMapRuleId = 0;
			try{
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				mapCounterBean = new MapCounterBean();
				mapCounterBean.setPolicyName(request.getParameter("policyName"));
				mapCounterBean.setPolicyDesc(request.getParameter("policyDescription"));
				mapCounterBean.setBreachId(Integer.parseInt(request.getParameter("breachId")));
				mapCounterBean.setCounterId(Integer.parseInt(request.getParameter("counterId")));
				mapCounterBean.setGuid(request.getParameter("guid"));
				mapCounterBean.setUId(Integer.parseInt(request.getParameter("uid")));
				mapCounterBean.setInPercentage(Boolean.parseBoolean(request.getParameter("inPercentage")));
				mapCounterBean.setIsThresholdAbove(Boolean.parseBoolean(request.getParameter("isThresholdAbove")));
				mapCounterBean.setMinBreachCount(Integer.parseInt(request.getParameter("minBreachCount")));
				mapCounterBean.setWarningThresholdValue(Long.parseLong(request.getParameter("warning_threshold_value")));
				mapCounterBean.setCriticalThresholdValue(Long.parseLong(request.getParameter("critical_threshold_value")));
				//mapCounterBean.setSLAId(Integer.parseInt(request.getParameter("slaId")));
				
				joRule = JSONObject.fromObject(request.getParameter("mapRuleId"));
				
				nSlaMapRuleId = joRule.containsKey("ruleId")? joRule.getInt("ruleId"): -1;
				
				//Enterprise License Implemented.
				joEnt = JSONObject.fromObject(request.getParameter("e_data"));

				// map module's/uid's counter to SLA
				slaManager.addAlertAddCounter(con, mapCounterBean, loginBean, nSlaMapRuleId, joEnt);
				joRtn = UtilsFactory.getJSONSuccessReturn("Metric has been mapped to selected alert.");

				DataBaseManager.commitConnection(con);

				// sends guid(s)'s counters SLA to collector, to update in agent;
				// Note: Send request only after con's commit
				slaManager.sendGUIDsActiveSLAsToCollector(mapCounterBean.getGuid());

				slaManager = null;
				mapCounterBean = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1") ) {
					// err, the module's counter is already mapped to the policy
					joRtn = UtilsFactory.getJSONFailureReturn("Metric is already mapped to the policy.");
				} else if( e.getMessage().equals("2") ) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map metric. As its relative metric \""+e.getCause().getMessage()+"\" is not configured.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to map metric to policy.");
				}
			}finally{
				DataBaseManager.close(con);
				con = null;

				slaManager = null;
				mapCounterBean = null;
				loginBean = null;

				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/deleteSlaAlert")) {
			
			SLAManager manager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			int nSLASettingId = 0;
			try {
				manager =  new SLAManager();

				
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				nSLASettingId = Integer.parseInt(request.getParameter("alertId"));
				
				manager.deleteSLARecord(con, nSLASettingId);
				
				DataBaseManager.commitConnection(con);
				manager = null;
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Your SLA Alert has been removed.");
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				if( e.getMessage().equals("SESSION_EXPIRED") ) {
					throw new ServletException("SESSION_EXPIRED");
				}
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to remove.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				manager = null;
				loginBean = null;
				response.getWriter().write(joRtn.toString());
			} 
		} else if(strActionCommand.endsWith("/sla/getSlaMenuBadge")) {
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONObject joRtn = null;
			
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				con = DataBaseManager.giveConnection();
				
				joRtn = slaManager.getSlaMenuBadge(con, loginBean);
				
				loginBean = null;
				slaManager = null;
			}catch(Exception e){
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get sla menu badges.");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				loginBean = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/getMappedRuleActions")){
			
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			JSONArray jaRuleActions = null;
			String strRuleId = null;
			try{
				slaManager = new SLAManager();
				loginBean = new LoginUserBean();
				
				strRuleId = request.getParameter("ruleId");
				con = DataBaseManager.giveConnection();
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				jaRuleActions = slaManager.getMappedRuleActions(con, strRuleId, loginBean);
				
				slaManager = null;
				loginBean = null;
			}catch(Exception e){
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				loginBean = null;
				response.getWriter().write(jaRuleActions.toString());
			}
		} else if(strActionCommand.endsWith("/verifySLAEmailAddress")) {
			// verify SLA email address
			SLAManager manager = null;
			
			String strEncryptedSLAId = null, strSLASettingId = null;
			String strEmailId = null;
			
			JSONObject joRtn = null;
			
			try {
				manager =  new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				strEncryptedSLAId = request.getParameter("lSLASettingId");
				
				// 
				if ( strEncryptedSLAId != null ) {
					// manual user verification 
					strSLASettingId = CryptManager.decodeDecryptURL(strEncryptedSLAId);
					manager.verifySLAEmailAddress(con, Long.parseLong(strSLASettingId));	
				} else {
					// added for auto verification of when user's email is verified for `usermaster` table
					long lUserId = Long.parseLong( request.getParameter("userId") );
					strEmailId = request.getParameter("emailId");
					
					manager.verifySLAEmailAddress(con, lUserId, strEmailId);
				}
				joRtn = UtilsFactory.getJSONSuccessReturn("Email has been verified successfully");
				
				DataBaseManager.commitConnection(con);
				
				manager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to verifySLAEmailAddress. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				strEncryptedSLAId = null;
				strSLASettingId = null;
				
				response.getWriter().write(joRtn.toString());
			} 
		} else if(strActionCommand.endsWith("/sla/readLogData")) {
			// gets rules which were mapped
			BufferedReader br = null;
			
			String strLogFile = null, strLogFilePath = null, strLine = null;
			StringBuilder sbData = new StringBuilder();
			JSONObject joRtn = null;
			
			try {
				strLogFile = request.getParameter("logFile");
				strLogFilePath = Constants.RESOURCE_PATH+"resource"+File.separator+"actionlog"+File.separator+strLogFile;
				br = new BufferedReader(new FileReader(strLogFilePath));
				while ((strLine = br.readLine()) != null) {
					sbData.append(strLine);
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(sbData.toString());
				strLogFile = null;
				strLogFilePath = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get log file. Please try after sometimes. ");
				
			} finally {
				strLogFile = null;
				strLogFilePath = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/actionLog")) {
			final int BUFFER_SIZE = 4096;
			try {
				
				// Gets file name for HTTP header
		        String fileName = request.getHeader("fileName");
		        File saveFile = new File(Constants.ACTION_LOG_FILE_FOLDER + fileName);
		         
		        // prints out all header values
		        LogManager.infoLog("===== Begin headers =====");
		        Enumeration<String> names = request.getHeaderNames();
		        while (names.hasMoreElements()) {
		            String headerName = names.nextElement();
		            LogManager.infoLog(headerName + " = " + request.getHeader(headerName));        
		        }
		        LogManager.infoLog("===== End headers =====\n");
		         
		        // opens input stream of the request for reading data
		        InputStream inputStream = request.getInputStream();
		         
		        // opens an output stream for writing file
		        FileOutputStream outputStream = new FileOutputStream(saveFile);
		         
		        byte[] buffer = new byte[BUFFER_SIZE];
		        int bytesRead = -1;
		        LogManager.infoLog("Receiving data...");
		         
		        while ((bytesRead = inputStream.read(buffer)) != -1) {
		            outputStream.write(buffer, 0, bytesRead);
		        }
		         
		        LogManager.infoLog("Data received.");
		        outputStream.close();
		        inputStream.close();
		         
		        LogManager.infoLog("File written to: " + saveFile.getAbsolutePath());
		         
		        // sends response to client
		        response.getWriter().print("UPLOAD DONE");
				
			}catch(Throwable t) {
				LogManager.infoLog("Exception in doUpload()"+t.getMessage());
				throw t;
			}
		}else if(strActionCommand.endsWith("/sla/isValidActionName")) {
			// gets rules which were mapped
			JSONObject joRtn = null;
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			SLAActionBean slaActionBean = null;
			boolean bexist = false;
			
			try {
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				slaActionBean = new SLAActionBean();
				slaActionBean.setActionName(request.getParameter("actionName"));
				slaActionBean.setActionId(Long.parseLong(UtilsFactory.replaceNullBlank(request.getParameter("actionId"), "-1")));
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				bexist = slaManager.isValidActionName(con, slaActionBean, loginBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("isAvailable", bexist);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get status. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/sla/isValidRuleName")) {
			// gets rules which were mapped
			JSONObject joRtn = null;
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			SLARuleBean slaRuleBean = null;
			boolean bexist = false;
			
			try {
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				slaRuleBean = new SLARuleBean();
				slaRuleBean.setRuleName(request.getParameter("ruleName"));
				slaRuleBean.setRuleId(Long.parseLong(UtilsFactory.replaceNullBlank(request.getParameter("ruleId"), "-1")));
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				bexist = slaManager.isValidRuleName(con, slaRuleBean, loginBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("isAvailable", bexist);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get status. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}else if(strActionCommand.endsWith("/sla/isValidPolicyName")) {
			// gets rules which were mapped
			JSONObject joRtn = null, joEnt;
			SLAManager slaManager = null;
			LoginUserBean loginBean = null;
			SLABean slaBean = null;
			boolean bexist = false;
			long lUser_id = -1L;
			
			try {
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				slaBean = new SLABean();
				slaBean.setSLAName(request.getParameter("policyName"));
				slaBean.setSLAId(Integer.parseInt(UtilsFactory.replaceNullBlank(request.getParameter("policyId"), "-1")));
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				//Enterprise License Implemented.
				if(request.getParameter("e_data")!= null){
					joEnt = JSONObject.fromObject(request.getParameter("e_data"));
					if(joEnt.getInt("e_id")!=0){
						lUser_id = joEnt.getLong("e_user_id");
					}else{
						lUser_id = loginBean.getUserId();
					}
				}else{
					lUser_id = loginBean.getUserId();
				}
				
				bexist = slaManager.isValidPolicyName(con, slaBean, /*loginBean*/lUser_id);
				joRtn = UtilsFactory.getJSONSuccessReturn("");
				joRtn.put("isAvailable", bexist);
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get status. ");
				
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sla/isMaxValueCounterIdSelected")) {

			SLAManager slaManager = null;
			JSONObject joMaxCounterDetail = null, joRtn = null;
			long lUID = -1l, lCounterId = -1l;

			try{
				slaManager = new SLAManager();
				lUID = Long.parseLong(request.getParameter("uid"));
				lCounterId = Long.parseLong(request.getParameter("counterId"));
				con = DataBaseManager.giveConnection();

				joMaxCounterDetail = slaManager.getMaxCounterDetail(con, lUID, lCounterId);
				joRtn = UtilsFactory.getJSONSuccessReturn(joMaxCounterDetail);
			}catch(Exception e){
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Max Metric's details.");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if (strActionCommand.endsWith("/sla/addSLAPolicyMapToCounterForThresholdBreach")) {
			// adds SLA policy and map with counters with given threshold_limits for the `Alert` type 
			Date dateLog = LogManager.logMethodStart();
			JSONObject joRtn = null, joEnt = null;
			
			LoginUserBean loginUserBean = null;
			
			SLAManager slaManager = null;
			
			SLABean slaBean = null;
			MapCounterBean mapCounterBean = null;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// loads default SLA breach types, if its empty, loaded at InitServlet
				if( Constants.SLA_BREACH_TYPES.isEmpty() ) {
					SLADBI.loadSLABreachTypes(con);
				}
				
				// add SLA Policy 
				slaBean = new SLABean();
				slaBean.setSLAName(request.getParameter("policyName"));
				slaBean.setSLADescription(request.getParameter("policyDesc"));
				slaBean.setSLAType(request.getParameter("alertType"));
				slaBean.setSystemGeneratedSLA(true);
				slaBean.setActivePolicy(true);
				// TODO: ASK, delete `Alert` type SLA ids mapped to rule `so_sla_rule` 
				// since rule not to map for `Alert` type added -1; rule is for heal
				slaBean.setMapRuleId(-1);
				
				// map counter to created SLA Policy
				mapCounterBean = new MapCounterBean();
				mapCounterBean.setBreachId( Constants.SLA_BREACH_TYPES.get("Threshold Breach") );
				
				// sets of added SLA policy id in manager
				//mapCounterBean.setSLAId( );
				
				mapCounterBean.setCounterId(Integer.parseInt(request.getParameter("counterId")));
				mapCounterBean.setCounterTemplateId(Integer.parseInt(request.getParameter("ctId")));
				mapCounterBean.setCategory(request.getParameter("category"));
				mapCounterBean.setCounterName(request.getParameter("counterName"));
				mapCounterBean.setWarningThresholdValue(Long.parseLong(request.getParameter("warning_threshold_value")));
				mapCounterBean.setCriticalThresholdValue(Long.parseLong(request.getParameter("critical_threshold_value")));
				mapCounterBean.setInPercentage(Boolean.parseBoolean(request.getParameter("inPercentage")));
				mapCounterBean.setIsThresholdAbove(Boolean.parseBoolean(request.getParameter("isThresholdAbove")));
				
				mapCounterBean.setMinBreachCount(Integer.parseInt(request.getParameter("minBreachCount")));
				
				mapCounterBean.setUId(Integer.parseInt(request.getParameter("uid")));
				mapCounterBean.setModuleName(request.getParameter("moduleName"));
				mapCounterBean.setModuleDetailedValue(request.getParameter("moduleValue"));
				mapCounterBean.setGuid(request.getParameter("guid"));
				mapCounterBean.setCounterTypeVersionId(Integer.parseInt(request.getParameter("ctvId")));
				
				//implemented enterprise Details
				joEnt = JSONObject.fromObject(request.getParameter("EnterpriseDetails"));
				
				// add SLA policy, map module's/uid's counter to the created policy & update sla_id in `counter_master_<uid>` 
				slaManager.addSLAPolicyMapToCounterForThresholdBreach(con, slaBean, mapCounterBean, loginUserBean, joEnt);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Created SLA policy which is mapped to metric. ");
				joRtn.put("slaId", slaBean.getSLAId());
				
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				
				if ( e.getMessage().equals("1") ) {
					// SLA policy already exists
					joRtn = UtilsFactory.getJSONFailureReturn("SLA policy already Exists.");
				} else if ( e.getMessage().equals("2") ) {
					// Counter already mapped to SLA policy
					joRtn = UtilsFactory.getJSONFailureReturn("Metric is already mapped to the policy.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add SLAs for primary metrics of Error. ");	
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
				
				loginUserBean = null;
				slaManager = null;
				slaBean = null;
				mapCounterBean = null;
				
				LogManager.logMethodEnd(dateLog);
			}
		} else if(strActionCommand.endsWith("/sla/setupSLA")){
			// setup SLA for the user 
			JSONObject joRtn = null;
			
			SLAManager slaManager = null;

			boolean bMailSent = false;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				long lUserId = Long.parseLong( request.getParameter("user_id") );
				String strEmailId = request.getParameter("emailId");
				
				// Add SLA Settings for the user
				slaManager.insertSLASettings(con, lUserId);
				
				// Add the User's Email-Id into SO-Alerts-Settings, login userBean added null since, mail is avoided
				bMailSent = slaManager.addAlertAddress(con, "Email", strEmailId, -1, lUserId, null, false);
				
				// Create ASD & SUM module's SLA breach history table for this User.
				slaManager.createSLABreachPartitionTable(con, lUserId) ;
				
				joRtn = UtilsFactory.getJSONSuccessReturn("SLA setup is done for the user.");
				
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);				
				LogManager.errorLog(e);

				if ( e.getMessage().equals("1") ) {
					// throw exception, email_mobile already added for the agent
					joRtn = UtilsFactory.getJSONFailureReturn("Alert address already exists.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to setup SLA.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
				
				slaManager = null;
			}
		} else if(strActionCommand.endsWith("/sla/getAllModuleSLAStatus")){
			// setup SLA for the user 
			JSONObject joRtn = null;
			JSONArray jaAllModuleSLABreachStatus = null;
			
			SLAManager slaManager = null;
			LoginUserBean loginUserBean = null;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// Add SLA Settings for the user
				jaAllModuleSLABreachStatus = slaManager.getAllModuleSLABreachStatus(con, loginUserBean.getUserId());
				
				DataBaseManager.commitConnection(con);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaAllModuleSLABreachStatus);
			} catch (Throwable th) {
				DataBaseManager.rollbackConnection(con);
				
				LogManager.errorLog(th);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get SLA Summary.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
				
				slaManager = null;
			}
		} else if(strActionCommand.endsWith("/sla/getModuleAutogeneratedSLAs")) {
			// get user's module's/uid's auto generated SLAs (ie.. SLAs which are added after ASD add)
			Date dateLog = LogManager.logMethodStart();
			SLAManager slaManager = null;
			LoginUserBean loginUserBean = null;

			JSONArray jaRtnModuleAutogeneratedSLAs = null;
			
			JSONObject joRtn = null;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				
				// gets uid's SLAs
				jaRtnModuleAutogeneratedSLAs = slaManager.getModuleAutogeneratedSLAs(con, lUId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnModuleAutogeneratedSLAs);
				
				slaManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to get Module Autogenerated SLAs.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
				
				slaManager = null;
				LogManager.logMethodEnd(dateLog);
			}
		}  else if(strActionCommand.endsWith("/sla/configureSLAToSUMTestForThresholdBreach")){
			// add or update, SLA policy and map to SUM test with SUM alert configs. for the `Alert` type
			Date dateLog = LogManager.logMethodStart();
			JSONObject joRtn = null, joEnt = null;

			LoginUserBean loginUserBean = null;

			SLAManager slaManager = null;

			SLABean slaBean = null;
			SLASUMBean slasumBean = null;

			boolean bEnableSUMAlert = false;

			try {
				slaManager = new SLAManager();

				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				// loads default SLA breach types, if its empty, loaded at InitServlet
				if( Constants.SLA_BREACH_TYPES.isEmpty() ) {
					SLADBI.loadSLABreachTypes(con);
				}

				bEnableSUMAlert = Boolean.parseBoolean(request.getParameter("enable_alert"));

				// add SLA Policy 
				slaBean = new SLABean();
				slaBean.setSLAName(request.getParameter("policyName"));
				slaBean.setSLADescription(request.getParameter("policyDesc"));
				slaBean.setSLAType(request.getParameter("alertType"));
				slaBean.setSystemGeneratedSLA(true);
				slaBean.setActivePolicy(bEnableSUMAlert);
				// TODO: ASK, delete `Alert` type SLA ids mapped to rule `so_sla_rule` 
				// since rule not to map for `Alert` type added -1; rule is for heal
				slaBean.setMapRuleId(-1);

				// map SUM test to SLA
				slasumBean = new SLASUMBean();
				slasumBean.setBreachTypeId( Constants.SLA_BREACH_TYPES.get("Threshold Breach") );
				// sets of added SLA policy id in manager
				// slasumBean.setSlaId( );
				slasumBean.setSumTestId(Long.parseLong(request.getParameter("sum_test_id")));
				slasumBean.setAboveThreashold(Boolean.parseBoolean(request.getParameter("is_above_threashold")));
				slasumBean.setSumCounterName(UtilsFactory.replaceNull(request.getParameter("sum_counter_name"), "pageloadtime"));
				slasumBean.setSumType(request.getParameter("sum_type"));
				slasumBean.setWarningLimit(Integer.parseInt(UtilsFactory.replaceNullBlank(request.getParameter("warning_limit"), "-1")));
				slasumBean.setErrorLimit(Integer.parseInt(UtilsFactory.replaceNullBlank(request.getParameter("error_limit"), "-1")));
				slasumBean.setMinBreachCount(Integer.parseInt(request.getParameter("min_breach_count")));
				slasumBean.setEnableAlert(bEnableSUMAlert);

				//implemented enterprise Details
				joEnt = JSONObject.fromObject(request.getParameter("EnterpriseDetails"));

				// add or update, SLA policy and map to SUM test with SUM alert configs. for the `Alert` type
				slaManager.configureSLAToSUMTestForThresholdBreach(con, slaBean, slasumBean, loginUserBean, joEnt);

				joRtn = UtilsFactory.getJSONSuccessReturn("Created SLA policy which is mapped to SUM test. ");
				joRtn.put("slaId", slaBean.getSLAId());

				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);

				if ( e.getMessage().equals("1") ) {
					// SLA policy already exists
					joRtn = UtilsFactory.getJSONFailureReturn("SLA policy already Exists.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add SLAs for primary metrics of Error. ");	
				}
			} finally {
				DataBaseManager.close(con);
				con = null;

				response.getWriter().write(joRtn.toString());

				loginUserBean = null;
				slaManager = null;
				slaBean = null;
				slasumBean = null;

				LogManager.logMethodEnd(dateLog);
			}
		} else if(strActionCommand.endsWith("/sla/deleteASDSLAs")) {
			/*
			 * while delete ASD/guid from UI,
			 *   deletes SLA(s) which are mapped with the GUID,
			 *   disable SLA(s) which has the GUID of delete and another GUID mapped
			 */
			JSONObject joRtn = null;
			LoginUserBean loginUserBean = null;

			SLAManager slaManager = null;
			
			String strGUID = "";
			
			ArrayList<HashMap<String, Object>> alDisabledSLAsHasDiffGUIDMapped = null;
			
			Object[] objRtn = null;
			
			HashMap<String, ArrayList<HashMap<String, Object>>> hmRtnDeleteSLAs = null;
			String strDisabledSLAGUIDs = null;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				strGUID = request.getParameter("guid");
				
				// delete GUID's SLA(s) AND disable SLA(s) which has another GUID(s) mapped
				objRtn = slaManager.deleteASDSLAs(con, strGUID, loginUserBean);
				
				hmRtnDeleteSLAs = (HashMap<String, ArrayList<HashMap<String, Object>>>) objRtn[0];
				alDisabledSLAsHasDiffGUIDMapped = hmRtnDeleteSLAs.get("different_guid_mapped_with_slas");
				strDisabledSLAGUIDs = (String) objRtn[1];
				
				DataBaseManager.commitConnection(con);
				
				
				/* sends the disabled SLA(s) has the another guid(s)'s, to update in agent;
				 * Note: Send request only after con's commit
				 */
				if ( strDisabledSLAGUIDs.length() > 0 ) {
					slaManager.sendGUIDsActiveSLAsToCollector(strDisabledSLAGUIDs);
				}
				
				joRtn = UtilsFactory.getJSONSuccessReturn("The GUID's mapped SLA(s) are deleted.");
				joRtn.put("disabled_sla", alDisabledSLAsHasDiffGUIDMapped);
				
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to delete SLA(s).");	
			} finally {

				strGUID = null;
				slaManager = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(strActionCommand.endsWith("/sla/configureSLAToRUMModule")){
			// add or update, SLA policy and map to RUM module/uid with alert configs. for `Alert`s, for the breach type `Threshold Breach`
			Date dateLog = LogManager.logMethodStart();
			JSONObject joRtn = null, joEnt = null;
			
			LoginUserBean loginUserBean = null;
			
			SLAManager slaManager = null;
			
			SLABean slaBean = null;
			RUMSLABean rumslaBean = null;
			
			boolean bEnableRUMResponseAlert = false;
			
			try {
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// loads default SLA breach types, if its empty, loaded at InitServlet
				if( Constants.SLA_BREACH_TYPES.isEmpty() ) {
					SLADBI.loadSLABreachTypes(con);
				}
				
				bEnableRUMResponseAlert = Boolean.parseBoolean(request.getParameter("enable_response_alert"));
				
				/*
				 * TODO: while update RUM threshold, need to check
				 *   1. threshold value update
				 *   2. if response alert disabled, update only in `so_sla` is_active = false;
				 *   3. for RUM SLA, the sla_id not insert into `so_sla_rule`, common for all ASD, SUM & RUM
				 */
				
				// add SLA Policy 
				slaBean = new SLABean();
				slaBean.setSLAName(request.getParameter("policyName"));
				slaBean.setSLADescription(request.getParameter("policyDesc"));
				slaBean.setSLAType(request.getParameter("alertType"));
				slaBean.setSystemGeneratedSLA(true);
				slaBean.setActivePolicy(bEnableRUMResponseAlert);
				// TODO: ASK, delete `Alert` type SLA ids mapped to rule `so_sla_rule` 
				// since rule not to map for `Alert` type added -1; rule is for heal
				slaBean.setMapRuleId(-1);
				
				// map SUM test to SLA
				rumslaBean = new RUMSLABean();
				rumslaBean.setBreachTypeId( Constants.SLA_BREACH_TYPES.get("Threshold Breach") );
				// sets of added SLA policy id in manager
				// slasumBean.setSlaId( );
				rumslaBean.setUId(Long.parseLong(request.getParameter("uid")));
				rumslaBean.setModuleName(request.getParameter("moduleName"));
				rumslaBean.setGUID(request.getParameter("guid"));
				rumslaBean.setUserId(loginUserBean.getUserId());
				
				rumslaBean.setAboveThreshold(Boolean.parseBoolean(request.getParameter("is_above_threashold")));
				rumslaBean.setWarningThresholdValue(Integer.parseInt(request.getParameter("warning_threshold_value")));
				rumslaBean.setCriticalThresholdValue(Integer.parseInt(request.getParameter("critical_threshold_value")));
				rumslaBean.setMinBreachCount(Integer.parseInt(request.getParameter("min_breach_count")));
				rumslaBean.setEnableResponseAlert(bEnableRUMResponseAlert);
				
				//implemented enterprise Details
				joEnt = JSONObject.fromObject(request.getParameter("EnterpriseDetails"));
				
				// add or update, SLA policy and map to SUM test with SUM alert configs. for the `Alert` type
				slaManager.configureSLAToRUMModule(con, slaBean, rumslaBean, loginUserBean, joEnt);
				
				joRtn = UtilsFactory.getJSONSuccessReturn("Alert policy created, which is mapped to the RUM module.");
				joRtn.put("slaId", slaBean.getSLAId());
				
				DataBaseManager.commitConnection(con);
			} catch (Exception e) {
				DataBaseManager.rollbackConnection(con);
				LogManager.errorLog(e);
				
				if ( e.getMessage().equals("1") ) {
					// SLA policy already exists
					joRtn = UtilsFactory.getJSONFailureReturn("SLA policy already Exists.");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to add SLA for the RUM module.");	
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
				
				loginUserBean = null;
				slaManager = null;
				slaBean = null;
				rumslaBean = null;
				
				LogManager.logMethodEnd(dateLog);
			}
		} else if(strActionCommand.endsWith("/sla/deleteRUMSLA")){
			// deletes RUM module SLA references
			SLAManager slaManager = null;
			
			LoginUserBean loginBean = null;
			
			JSONObject joRtn = null;
			
			try{
				slaManager = new SLAManager();
				
				con = DataBaseManager.giveConnection();
				
				loginBean = new LoginUserBean();
				loginBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				long lUId = Long.parseLong( request.getParameter("uid") );
				
				// delete SUM Test's SLA refs
				slaManager.deleteRUMSLA(con, lUId , loginBean);
				
				DataBaseManager.commitConnection(con);
				joRtn = UtilsFactory.getJSONSuccessReturn("SUM SLA Record has been deleted.");
				slaManager = null;
			}catch(Exception e){
				DataBaseManager.rollbackConnection(con);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to Delete SLA SUM");
				LogManager.errorLog(e);
			}finally{
				DataBaseManager.close(con);
				con = null;
				slaManager = null;
				response.getWriter().write(joRtn.toString());
			}
		} 
	}
}
