package com.appedo.module.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.CILicenseBean;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.model.CIManager;
import com.appedo.module.utils.UtilsFactory;

/**
 * Servlet implementation class RUMController
 */
public class CIController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CIController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doAction(request, response);
	}
	
	public void doAction(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		response.setContentType("text/html");
		String action = request.getRequestURI();
		
		//System.out.println("action URI: "+action);
		//System.out.println("action ServletPath: "+request.getServletPath());
		
		if(action.endsWith("/ci/getEventsSummary")) {
			// gets 
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null;
			JSONArray jaRtnEventSummaries = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				String strAgentType = request.getParameter("agentType");
				String strEnvironmnet = request.getParameter("environmnet");
				
				//long lUserId = Long.parseLong(request.getAttribute("login_user_id")+"");
				//String strRUMLicLevel = request.getAttribute("user_lic_rum").toString();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// gets events load time 
				jaRtnEventSummaries = ciManager.getEventsSummary(con, lUID, strFromStartInterval, strAgentType, strEnvironmnet, loginUserBean.getUserId(), loginUserBean.getLicense());
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnEventSummaries);

				ciManager = null;
				strFromStartInterval = null;
				loginUserBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				if ( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventsSummary. License expired. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventsSummary.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventsSummaryWithDateRange")) {
			// gets 
			Connection con = null;
			
			LoginUserBean loginUserBean = null;
			
			JSONObject joRtn = null;
			JSONArray jaRtnEventSummaries = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				String strAgentType = request.getParameter("agentType");
				String strEnvironmnet = request.getParameter("environmnet");
				
				//long lUserId = Long.parseLong(request.getAttribute("login_user_id")+"");
				//String strRUMLicLevel = request.getAttribute("user_lic_rum").toString();
				
				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				// gets events load time 
				jaRtnEventSummaries = ciManager.getEventsSummaryWithDateRange(con, lUID, strFromStartInterval, strToInterval, strAgentType, strEnvironmnet, loginUserBean.getUserId(), loginUserBean.getLicense());
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnEventSummaries);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
				loginUserBean = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				
				if ( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventsSummaryWithDateRange. License expired. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventsSummaryWithDateRange.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventLoadTime")) {
			Connection con = null;

			JSONObject joRtn = null, joRtnEventLoadTime = null;;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				joRtnEventLoadTime = ciManager.getEventLoadTime(con, lUID, lEventId, strFromStartInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnEventLoadTime);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventLoadTime.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventLoadTimeWithDateRange")) {
			Connection con = null;

			JSONObject joRtn = null, joRtnEventLoadTime = null;;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				joRtnEventLoadTime = ciManager.getEventLoadTimeWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnEventLoadTime);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventLoadTimeWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getBrowserWiseData")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnBrowserShareData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnBrowserShareData = ciManager.getBrowserWiseData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBrowserShareData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getBrowserWiseData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getBrowserWiseDataWithDateRange")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnBrowserShareData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnBrowserShareData = ciManager.getBrowserWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBrowserShareData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getBrowserWiseDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceTypeWiseData")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceTypeWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnDeviceTypeWiseData = ciManager.getDeviceTypeWiseData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceTypeWiseData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				System.out.println("Exception in /ci/getDeviceTypeWiseData: "+e.getMessage());
				e.printStackTrace();

				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceTypeWiseData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceTypeWiseDataWithDateRange")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceTypeWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnDeviceTypeWiseData = ciManager.getDeviceTypeWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceTypeWiseData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				System.out.println("Exception in /ci/getDeviceTypeWiseDataWithDateRange: "+e.getMessage());
				e.printStackTrace();

				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceTypeWiseDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getOSWiseData")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnOSWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnOSWiseData = ciManager.getOSWiseData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnOSWiseData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getOSWiseData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getOSWiseDataWithDateRange")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnOSWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnOSWiseData = ciManager.getOSWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnOSWiseData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getOSWiseDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceNameWiseData")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceNameWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnDeviceNameWiseData = ciManager.getDeviceNameWiseData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceNameWiseData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceNameWiseData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceNameWiseDataWithDateRange")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceNameWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnDeviceNameWiseData = ciManager.getDeviceNameWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceNameWiseData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceNameWiseDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDailyVisitorsCount")) {
			Connection con = null;

			JSONObject joRtn = null, joRtnDailyVisitorsCount = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");

				// gets daily visitors count
				joRtnDailyVisitorsCount = ciManager.getDailyVisitorsCount(con, lUID, lEventId, strFromStartInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnDailyVisitorsCount);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDailyVisitorsCount.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDailyVisitorsCountWithDateRange")) {
			Connection con = null;

			JSONObject joRtn = null, joRtnDailyVisitorsCount = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");

				// gets daily visitors count
				joRtnDailyVisitorsCount = ciManager.getDailyVisitorsCountWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnDailyVisitorsCount);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDailyVisitorsCountWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventProperties")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnEventProperties = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );

				long lUserId = Long.parseLong(request.getAttribute("login_user_id")+"");
				String strRUMLicLevel = request.getAttribute("user_lic_rum").toString();
				
				jaRtnEventProperties = ciManager.getEventProperties(con, lUID, lEventId, lUserId, strRUMLicLevel);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnEventProperties);

				ciManager = null;
				strRUMLicLevel = null;
			} catch (Exception e) {
				LogManager.errorLog(e);

				if ( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventProperties. License expired. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventProperties.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventPropertyValues")) {
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnEventPropertyValues = null;
			//ArrayList<String> alRtnPropertyValues = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				long lEvtPropId = Long.parseLong( request.getParameter("evtPropId") );
				
				jaRtnEventPropertyValues = ciManager.getEventPropertyValues(con, lUID, lEventId, lEvtPropId);
				
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnEventPropertyValues);
				
				ciManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventPropertyValues.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventTransactions")) {
			// gets respective event's transactions of particular given columns
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnEventTransactions = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				long lEvtPropId = Long.parseLong( request.getParameter("evtPropId") );
				String strPropertyValue = request.getParameter("propertyValue");
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnEventTransactions = ciManager.getEventTransactions(con, lUID, lEventId, lEvtPropId, strPropertyValue, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnEventTransactions);
				
				ciManager = null;
				strFromStartInterval = null;
			}  catch (Exception e) {
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventTransactions. License expired. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventTransactions.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventTransactionsWithDateRange")) {
			// gets respective event's transactions of particular given columns
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnEventTransactions = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				long lEvtPropId = Long.parseLong( request.getParameter("evtPropId") );
				String strPropertyValue = request.getParameter("propertyValue");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnEventTransactions = ciManager.getEventTransactionsWithDateRange(con, lUID, lEventId, lEvtPropId, strPropertyValue, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnEventTransactions);
				
				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			}  catch (Exception e) {
				LogManager.errorLog(e);
				if ( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventTransactionsWithDateRange. License expired. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventTransactionsWithDateRange.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventTransaction")) {
			// gets particular transaction details
			Connection con = null;

			JSONObject joRtn = null, joRtnEventTransaction = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				long lEvtTransId = Long.parseLong( request.getParameter("evtTransId") );

				long lUserId = Long.parseLong(request.getAttribute("login_user_id")+"");
				String strRUMLicLevel = request.getAttribute("user_lic_rum").toString();
				
				joRtnEventTransaction = ciManager.getEventTransaction(con, lUID, lEventId, lEvtTransId, lUserId, strRUMLicLevel);

				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnEventTransaction);
				
				ciManager = null;
				strRUMLicLevel = null;
			}  catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventTransaction.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventDetailedTransactions")) {
			// gets respective event's transactions of all available columns
			Connection con = null;

			JSONObject joRtn = null, joRtnEventTransactions = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				long lEvtPropId = Long.parseLong( request.getParameter("evtPropId") );
				String strPropertyValue = request.getParameter("propertyValue");
				String strFromStartInterval = request.getParameter("fromStartInterval");
				String strLimit = request.getParameter("limit");
				String strOffset = request.getParameter("offset");
				
				long lUserId = Long.parseLong(request.getAttribute("login_user_id")+"");
				String strRUMLicLevel = request.getAttribute("user_lic_rum").toString();
				
				// 
				joRtnEventTransactions = ciManager.getEventDetailedTransactions(con, lUID, lEventId, lEvtPropId, strPropertyValue, strFromStartInterval, lUserId, strRUMLicLevel, strLimit, strOffset);

				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnEventTransactions);
				
				ciManager = null;
				strFromStartInterval = null;
				strRUMLicLevel = null;
			}  catch (Exception e) {
				LogManager.errorLog(e);

				if ( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventDetailedTransactions. License expired. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventDetailedTransactions.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventDetailedTransactionsWithDateRange")) {
			// gets respective event's transactions of all available columns
			Connection con = null;

			JSONObject joRtn = null, joRtnEventTransactions = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				long lEvtPropId = Long.parseLong( request.getParameter("evtPropId") );
				String strPropertyValue = request.getParameter("propertyValue");
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				String strLimit = request.getParameter("limit");
				String strOffset = request.getParameter("offset");
				
				long lUserId = Long.parseLong(request.getAttribute("login_user_id")+"");
				String strRUMLicLevel = request.getAttribute("user_lic_rum").toString();
				
				// 
				joRtnEventTransactions = ciManager.getEventDetailedTransactionsWithDateRange(con, lUID, lEventId, lEvtPropId, strPropertyValue, strFromStartInterval, strToInterval, lUserId, strRUMLicLevel, strLimit, strOffset);

				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnEventTransactions);
				
				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
				strRUMLicLevel = null;
			}  catch (Exception e) {
				LogManager.errorLog(e);

				if ( e.getMessage().equals("1")) {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventDetailedTransactions. License expired. ");
				} else {
					joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventDetailedTransactions.");
				}
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.equals("/ci/getCIUserLicenseDetails")) {
			// gets license details for CI, from `ci_config_param` table, 
			// (Note. start & end dates is not retrieved only config params based on user's lic_rum)
			Connection con = null;
			
			CIManager ciManager = null;
			
			CILicenseBean ciLicenseBean = null;
			
			JSONObject joRtn = null, joRtnCILicenseConfigParams = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUserId = Long.parseLong(request.getAttribute("login_user_id")+"");
				String strRUMLicLevel = request.getAttribute("user_lic_rum").toString();

				// gets license details from `userwise_lic_monthwise` and `apm_config_param` tables
				ciLicenseBean = ciManager.getCIUserLicenseDetails(con, lUserId, strRUMLicLevel);

				if (ciLicenseBean != null) {
					joRtnCILicenseConfigParams = ciLicenseBean.toJSON(); 
				}
				joRtn = UtilsFactory.getJSONSuccessReturn(UtilsFactory.replaceNull(joRtnCILicenseConfigParams, ""));
				
				strRUMLicLevel = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getCIUserLicenseConfigParams. ");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getBrowserWiseDonutData")) {
			// get getBrowserWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnBrowserShareData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnBrowserShareData = ciManager.getBrowserWiseDonutData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBrowserShareData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getBrowserWiseDonutData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getBrowserWiseDonutDataWithDateRange")) {
			// get getBrowserWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnBrowserShareData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnBrowserShareData = ciManager.getBrowserWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnBrowserShareData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getBrowserWiseDonutDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceTypeWiseDonutData")) {
			// get getDeviceTypeWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceTypeWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnDeviceTypeWiseData = ciManager.getDeviceTypeWiseDonutData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceTypeWiseData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				System.out.println("Exception in /ci/getDeviceTypeWiseData: "+e.getMessage());
				e.printStackTrace();

				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceTypeWiseData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceTypeWiseDonutDataWithDateRange")) {
			// get getDeviceTypeWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceTypeWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnDeviceTypeWiseData = ciManager.getDeviceTypeWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceTypeWiseData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				System.out.println("Exception in /ci/getDeviceTypeWiseDonutDataWithDateRange: "+e.getMessage());
				e.printStackTrace();

				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceTypeWiseDonutDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getOSWiseDonutData")) {
			// get getOSWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnOSWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnOSWiseData = ciManager.getOSWiseDonutData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnOSWiseData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getOSWiseDonutData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getOSWiseDonutDataWithDateRange")) {
			// get getOSWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnOSWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnOSWiseData = ciManager.getOSWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnOSWiseData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getOSWiseDonutDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceNameWiseDonutData")) {
			// get getDeviceNameWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceNameWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("fromStartInterval");
				
				jaRtnDeviceNameWiseData = ciManager.getDeviceNameWiseDonutData(con, lUID, lEventId, strFromStartInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceNameWiseData);

				ciManager = null;
				strFromStartInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceNameWiseData.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getDeviceNameWiseDonutDataWithDateRange")) {
			// get getDeviceNameWiseDonutData for donut chart
			Connection con = null;

			JSONObject joRtn = null;
			JSONArray jaRtnDeviceNameWiseData = null;
			
			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();
				
				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				String strFromStartInterval = request.getParameter("startDate");
				String strToInterval = request.getParameter("endDate");
				
				jaRtnDeviceNameWiseData = ciManager.getDeviceNameWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnDeviceNameWiseData);

				ciManager = null;
				strFromStartInterval = null;
				strToInterval = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getDeviceNameWiseDonutDataWithDateRange.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getModuleAgentTypes")) {
			// gets module's Agent types
			Connection con = null;

			JSONArray jaRtnModuleAgentTypes = null;
			JSONObject joRtn = null;

			CIManager ciManager = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				
				jaRtnModuleAgentTypes = ciManager.getModuleAgentTypes(con, lUID);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnModuleAgentTypes);
				
				ciManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getModuleAgentTypes.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getModuleEnvironments")) {
			// gets module's Environments
			Connection con = null;

			CIManager ciManager = null;

			JSONArray jaRtnModuleEnvironments = null;
			JSONObject joRtn = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				
				jaRtnModuleEnvironments = ciManager.getModuleEnvironments(con, lUID);

				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnModuleEnvironments);
				
				ciManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getModuleEnvironments.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getEventLastReceivedOn")) {
			// gets selected event last received on
			Connection con = null;

			CIManager ciManager = null;

			JSONObject joRtn = null;

			long lLastReceivedOn = 0L;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				long lUID = Long.parseLong( request.getParameter("uid") );
				long lEventId = Long.parseLong( request.getParameter("eventId") );
				
				lLastReceivedOn = ciManager.getEventLastReceivedOn(con, lUID, lEventId);

				joRtn = UtilsFactory.getJSONSuccessReturn(lLastReceivedOn+"");
				
				ciManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getEventLastReceivedOn.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getUserEventsVisitorsCount")) {
			// gets user RUM module's total visitors count
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			CIManager ciManager = null;
			
			JSONObject joRtn = null, joRtnUserEventsVisitorsCount = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));
				
				String strAgentType = request.getParameter("agentType");
				String strEnvironment = request.getParameter("environment");
				
				// 
				joRtnUserEventsVisitorsCount = ciManager.getUserEventsVisitorsCount(con, loginUserBean.getUserId(), strAgentType, strEnvironment);
				joRtn = UtilsFactory.getJSONSuccessReturn(joRtnUserEventsVisitorsCount);
				
				strAgentType = null;
				strEnvironment = null;
				loginUserBean = null;
				ciManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getUserEventsVisitorsCount.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		} else if(action.endsWith("/ci/getUserEventsDistinctEnvironments")) {
			// gets user's modules distinct environments
			Connection con = null;
			LoginUserBean loginUserBean = null;
			
			CIManager ciManager = null;
			
			JSONObject joRtn = null;
			JSONArray jaRtnEventsDistinctEnvironments = null;
			
			try {
				ciManager = new CIManager();

				con = DataBaseManager.giveConnection();

				loginUserBean = new LoginUserBean();
				loginUserBean.fromJSONObject( JSONObject.fromObject(request.getParameter("login_user_bean")));

				jaRtnEventsDistinctEnvironments = ciManager.getUserEventsDistinctEnvironments(con, loginUserBean.getUserId());
				joRtn = UtilsFactory.getJSONSuccessReturn(jaRtnEventsDistinctEnvironments);
				
				loginUserBean = null;
				ciManager = null;
			} catch (Exception e) {
				LogManager.errorLog(e);
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to getUserEventsDistinctEnvironments.");
			} finally {
				DataBaseManager.close(con);
				con = null;
				
				response.getWriter().write(joRtn.toString());
			}
		}
	}
}
