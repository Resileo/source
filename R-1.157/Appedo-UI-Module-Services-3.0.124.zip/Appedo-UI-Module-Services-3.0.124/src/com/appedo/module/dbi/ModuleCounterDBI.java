package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Stack;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.math.NumberUtils;

import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class ModuleCounterDBI {
	
	private static final String[] GROUP_BY_MINUTE_INTERVALS = { "15 minutes", "30 minutes", // For ServiceMap's Health DashBoard's starting sliders
																"1 hour", "2 hours", "3 hours"	// For ASD's default slider & HotSpot's all slider
															};
	
	/**
	 * Returns the UID for the given GUID.
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public long getUID(Connection con, String strGUID) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		Long lUID = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT uid FROM module_master ")
					.append("WHERE guid = '").append(strGUID).append("' ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			
			while( rst.next() ) {
				lUID = rst.getLong("uid");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lUID;
	}
	
	/**
	 * Gets chart data for the counters
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounters
	 * @param lMaxTimeStamp
	 * @param forPdf 
	 * @return
	 * @throws Exception
	 *
	public JSONObject getCountersNotInUse(Connection con, String strGUID, String strCounters, Long lMaxTimeStamp, String strFromStartInterval, boolean forPdf) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		//String strDateTimeLimitGenerateSeries = "", strDateTimeLimitTable = "";
		// strIntervalGS `GS` means generate series 
		String strDateTimeTruncBy = ""; 
		
		JSONObject joResult = new JSONObject(), joCountersException = new JSONObject(), joCounterWiseChartData = null, joData = null;
		JSONArray jaData = new JSONArray();
		
		/* DON'T delete used for break counter sets
		JSONObject joDatum = null;

		ArrayList<JSONObject> alCounterSet = null;
		ArrayList<ArrayList<JSONObject>> alCounterValues = new ArrayList<ArrayList<JSONObject>>();

		LinkedHashMap<Long, ArrayList<ArrayList<JSONObject>>> lmCountersTypeData = new LinkedHashMap<Long, ArrayList<ArrayList<JSONObject>>>();

		//String strAgentException = "";

		Double dChartValueY = null;

		Long lCounterId = -1L;

		long lTime = -1L;
		long lPrevTime = -1L, lDuration = -1L, lDiffInMinutes = -1L;
		
		long lEpochTime = -1L;
		*
		long lUId = -1L;
		
		boolean bBreakCounterSet = false;
		
		ModuleDBI moduleDBI = null;
		
		try {
			// breaks counter's data in parts, which gets plot as discountinues points (ie.. [ [{time: 12654664, value: 6233}, {time: 12654664, value: 6233}, ...], [{time: 12654664, value: 6233}, ..], ...])
			if ( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
				bBreakCounterSet = true;
			}
			
			moduleDBI = new ModuleDBI();
			
			lUId = moduleDBI.getUID(con, strGUID);
			
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			
			
			/// TODO: Add and condition for maxTS for next Time refresh, 
			// 1 hour, max TS, Note: removed `now() - interval '<> 1 minute'`
			// 
			sbQuery	.append("SELECT extract('epoch' from gs.start_from)*1000 as \"T\", "); //.append(strCounters).append(" as counter_type, ")
			if( !forPdf ){	// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
				sbQuery .append("  (CASE WHEN cnt IS NULL THEN 0 ELSE cnt END) AS \"Count\", ")
						.append("  (CASE WHEN min IS NULL THEN 0 ELSE min END) AS \"Min\", ")
						.append("  (CASE WHEN max IS NULL THEN 0 ELSE max END) AS \"Max\", ")
						.append("  (CASE WHEN avg IS NULL THEN 0 ELSE avg END) AS \"Avg\", ");
			}
			sbQuery .append("  (CASE WHEN avg IS NULL THEN 0 ELSE avg END) AS \"V\" ")
					.append("FROM ( ")
					.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', (now() - interval '").append(strFromStartInterval).append("' + interval '1 ").append(strDateTimeTruncBy).append("')), now(), '1 ").append(strDateTimeTruncBy).append("') AS start_from ")
					.append(") AS gs ")
					.append("LEFT JOIN ( ")
					.append("    SELECT date_trunc('").append(strDateTimeTruncBy).append("', appedo_received_on) as start_from, counter_type, count(counter_type) AS cnt, ")
					.append("      Round(min(counter_value), 3) as min, Round(avg(counter_value), 3) as avg, Round(max(counter_value), 3) AS max ")
					.append("    FROM collector_").append(lUId).append(" ")
					.append("    WHERE appedo_received_on >= (now() - interval '").append(strFromStartInterval).append("') ")
					.append("      AND counter_type = ").append(strCounters).append(" ")
					.append("    GROUP BY start_from, counter_type ")
					.append(") AS c ON gs.start_from = c.start_from  ")
					.append("WHERE ( date_trunc('").append(strDateTimeTruncBy).append("', now()) = gs.start_from AND c.start_from IS NULL ) = FALSE ")
					.append("ORDER BY gs.start_from ASC ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				
				joData.put("T", rst.getLong("T"));
				if( !forPdf ){	// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
					joData.put("Count", rst.getLong("Count"));
					joData.put("Min", rst.getLong("Min"));
					joData.put("Max", rst.getLong("Max"));
					joData.put("Avg", rst.getLong("Avg"));
				}
				joData.put("V", rst.getLong("V"));
				
				jaData.add(joData);
			}
			
			joCounterWiseChartData = new JSONObject();
			joCounterWiseChartData.put(strCounters, jaData);
			
			//joResult.put("max_recieved_on", lMaxTimeStamp);
			joResult.put("guid", strGUID);
			joResult.put("chartdata", joCounterWiseChartData);
			joResult.put("countersException", joCountersException);
			joResult.put("serverCurrentTime", System.currentTimeMillis());
			
			
			/*	
			 * DON'T delete, break counter's sets
			 *
			//if ( bBreakCounterSet ) {
				// for Last hour 
				sbQuery	.append("SELECT *, EXTRACT(epoch FROM appedo_received_on) AS epoch_appedo_received_on ")
						.append("FROM get_apm_monitor_counters_data(?, timestamp 'epoch' + ? * interval '1 ms', '").append(strCounters).append("', ?) ");

				// Note: maxtimestamp & chart (x-axis) time stamp differ below, TODO: both are same to avoid confusion
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setString(1, strGUID);
				if ( lMaxTimeStamp == null ) {
					// to set null
					pstmt.setNull(2, Types.TIMESTAMP);
				} else {
					// converts millseconds to seconds, since epoch returns as time in long format as seconds (with 10 digits)
					pstmt.setLong(2, lMaxTimeStamp);
				}
				pstmt.setString(3, strFromStartInterval);
			//} else {
				
			//}
			
			rst = pstmt.executeQuery();
			while(rst.next()) {
				lCounterId = rst.getLong("counter_type");

				lTime = rst.getTimestamp("appedo_received_on").getTime();
				lEpochTime = (long) (rst.getDouble("epoch_appedo_received_on") * 1000);
				
				// `T` is time (x-axis) & `V` is value (y-axis) 
				joDatum = new JSONObject();
				joDatum.put("T", lTime);
				dChartValueY = rst.getDouble("counter_value");
				joDatum.put("V", dChartValueY);
				
				// for multiple counters
				if (lmCountersTypeData.containsKey(lCounterId)) {
					alCounterValues = lmCountersTypeData.get(lCounterId);
					
					// to break counters set for last 1 hour data, 
					if ( bBreakCounterSet ) {
						lDuration = lTime - lPrevTime;
						lDiffInMinutes = TimeUnit.MILLISECONDS.toMinutes(lDuration);
						
						// If there the time difference between current & previous is more than 1 minute, then store the datum in a new Array
						if( lDiffInMinutes > Constants.COUNTER_CHART_TIME_INTERVAL ) {
							alCounterSet = new ArrayList<JSONObject>();
							
							alCounterValues.add(alCounterSet);
						} else {
							alCounterSet = alCounterValues.get(alCounterValues.size() - 1);
						}
					} else {
						// for other than interval `1 hour`
						alCounterSet = alCounterValues.get(alCounterValues.size() - 1);
					}
				} else {
					alCounterValues = new ArrayList<ArrayList<JSONObject>>();
					alCounterSet = new ArrayList<JSONObject>();
					
					alCounterValues.add(alCounterSet);
				}
				alCounterSet.add(joDatum);
				
				lmCountersTypeData.put(lCounterId, alCounterValues);

				lPrevTime = lTime;
				
				// exception to add for counter and agent
				joCountersException.put(lCounterId, rst.getString("counter_exception"));
				//strAgentException = rst.getString("agent_exception");
			}

			/*
			 * since order by asc, last value of `lTime` sets as maxTimestamp, 
			 * ( Note: since mostly in all places multiple counters data is not retrieved, 
			 *    if multiple counters are retrieve, maxTimestamp logic to revised, 
			 *   based on respective counter's maxTimestamp to get & in query also have to change for respective counter > maxts
			 * )
			 * 
			 * 
			//if ( lTime != -1 ) {
			if ( lEpochTime != -1 ) {
				//lMaxTimeStamp = lTime;
				lMaxTimeStamp = lEpochTime;
			}
			
			joResult.put("max_recieved_on", lMaxTimeStamp);
			joResult.put("guid", strGUID);
			joResult.put("chartdata", lmCountersTypeData);
			joResult.put("countersException", joCountersException);
			joResult.put("serverCurrentTime", System.currentTimeMillis());
			//joResult.put("agentException", strAgentException);
			
			//strAgentException = null;
			lCounterId = null;
			*
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			strDateTimeTruncBy = null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}
	*/
	
	public JSONObject getModuleCountersChartData(Connection con, String strGUID, String strCounters, Long lMaxTimeStamp, String strFromStartInterval, Long lStartDateTimeInMillis, Long lEndDateTimeInMillis, boolean isPdf, Boolean isAboveThreshold) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strDateTimeTruncBy = "";
		
		JSONObject joResult = new JSONObject(), joCountersException = new JSONObject(), joCounterWiseChartData = null, joData = null;
		JSONArray jaData = new JSONArray();
		
		long lUId = -1L;
		
		boolean bBreakCounterSet = false, bCustomFilter = false;
		
		Long lStartDateTimeInMins = null, lEndDateTimeInMins = null;
		
		ModuleDBI moduleDBI = null;
		
		try {
			if ( lEndDateTimeInMillis != null && lStartDateTimeInMillis != null){
				bCustomFilter = true;
				
				// breaks counter's data in parts, which gets plot as discountinues points (ie.. [ [{time: 12654664, value: 6233}, {time: 12654664, value: 6233}, ...], [{time: 12654664, value: 6233}, ..], ...])
				if( lEndDateTimeInMillis - lStartDateTimeInMillis <= 10800000 ) { // 1000 * 60 * 60 * 3 - For last 3 hours
					bBreakCounterSet = true;
				}
				
				lStartDateTimeInMins = lStartDateTimeInMillis / 1000;
				lEndDateTimeInMins = lEndDateTimeInMillis / 1000;
			} else {
				if ( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					bBreakCounterSet = true;
				}
			}
			
			moduleDBI = new ModuleDBI();
			
			lUId = moduleDBI.getUID(con, strGUID);
			
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			/* the custom filter, merged with below `sbQuery`
			if ( lEndDateTime != null && lStartDateTime != null){
				sbQuery	.append("SELECT * FROM get_module_counters_chartdata_with_date_range(?, ?, ?, ?, ?, ?)");
			} else {
			*/
			sbQuery	.append("SELECT extract('epoch' from gs.start_from)*1000 as \"T\", "); //.append(strCounters).append(" as counter_type, ")
			if( !isPdf ){	// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
				sbQuery .append("  (COALESCE(cnt,0)) AS \"Count\", ")
						.append("  (COALESCE(min,0)) AS \"Min\", ")
						.append("  (COALESCE(max,0)) AS \"Max\", ")
						.append("  (COALESCE(avg,0)) AS \"Avg\", ");
			}
			sbQuery	.append("COALESCE(CASE WHEN ").append(isAboveThreshold).append(" IS NULL THEN avg ")
					.append("WHEN ").append(isAboveThreshold).append(" IS true THEN max ELSE min END, 0) AS \"V\" ")
					.append("FROM ( ");
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lStartDateTimeInMins).append(")), date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lEndDateTimeInMins).append(")), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			} else {
				// slider filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', (now() - interval '").append(strFromStartInterval).append("' + interval '1 ").append(strDateTimeTruncBy).append("')), now(), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			}
			sbQuery	.append(") AS gs ")
					.append("LEFT JOIN ( ")
					.append("    SELECT date_trunc('").append(strDateTimeTruncBy).append("', appedo_received_on) as start_from, counter_type, count(counter_type) AS cnt, ")
					.append("      Round(min(counter_value), 3) as min, Round(avg(counter_value), 3) as avg, Round(max(counter_value), 3) AS max ")
					.append("    FROM collector_").append(lUId).append(" ")
					.append("    WHERE ");
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append(" appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMins).append(") AND to_timestamp(").append(lEndDateTimeInMins).append(") ");
			} else {
				// slider filter
				sbQuery.append(" appedo_received_on >= (now() - interval '").append(strFromStartInterval).append("') ");
			}
			sbQuery	.append("      AND counter_type = ").append(strCounters).append(" ")
					.append("    GROUP BY start_from, counter_type ")
					.append(") AS c ON gs.start_from = c.start_from  ")
					.append("WHERE ( date_trunc('").append(strDateTimeTruncBy).append("', now()) = gs.start_from AND c.start_from IS NULL ) = FALSE ")
					.append("ORDER BY gs.start_from ASC ");
			//}
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				
				joData.put("T", rst.getLong("T"));
				if( !isPdf ){	// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
					joData.put("Count", rst.getLong("Count"));
					joData.put("Min", rst.getLong("Min"));
					joData.put("Max", rst.getLong("Max"));
					joData.put("Avg", rst.getLong("Avg"));
				} else {
				joData.put("V", rst.getLong("V"));
				}
				jaData.add(joData);
			}
			
			joCounterWiseChartData = new JSONObject();
			joCounterWiseChartData.put(strCounters, jaData);
			
			//joResult.put("max_recieved_on", lMaxTimeStamp);
			joResult.put("chartdata", joCounterWiseChartData);
				
			joResult.put("guid", strGUID);
			joResult.put("countersException", joCountersException);
			joResult.put("serverCurrentTime", System.currentTimeMillis());
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			strDateTimeTruncBy = null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}
	
	public JSONObject v1_getModuleCountersChartData(Connection con, String strGUID, String strCounters, Long lMaxTimeStamp, String strFromStartInterval, Long lStartDateTimeInMillis, Long lEndDateTimeInMillis, boolean isPdf, Boolean isAboveThreshold) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strDateTimeTruncBy = "";
		
		JSONObject joResult = new JSONObject(), joCountersException = new JSONObject(), joCounterWiseChartData = null, joData = null;
		JSONArray jaData = new JSONArray();
		
		long lUId = -1L;
		
		boolean bBreakCounterSet = false, bCustomFilter = false;
		
		Long lStartDateTimeInMins = null, lEndDateTimeInMins = null;
		
		ModuleDBI moduleDBI = null;
		
		try {
			if ( lEndDateTimeInMillis != null && lStartDateTimeInMillis != null){
				bCustomFilter = true;
				
				// breaks counter's data in parts, which gets plot as discountinues points (ie.. [ [{time: 12654664, value: 6233}, {time: 12654664, value: 6233}, ...], [{time: 12654664, value: 6233}, ..], ...])
				if( lEndDateTimeInMillis - lStartDateTimeInMillis <= 10800000 ) { // 1000 * 60 * 60 * 3 - For last 3 hours
					bBreakCounterSet = true;
				}
				
				lStartDateTimeInMins = lStartDateTimeInMillis / 1000;
				lEndDateTimeInMins = lEndDateTimeInMillis / 1000;
			} else {
				if ( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					bBreakCounterSet = true;
				}
			}
			
			moduleDBI = new ModuleDBI();
			
			lUId = moduleDBI.getUID(con, strGUID);
			
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			/* the custom filter, merged with below `sbQuery`
			if ( lEndDateTime != null && lStartDateTime != null){
				sbQuery	.append("SELECT * FROM get_module_counters_chartdata_with_date_range(?, ?, ?, ?, ?, ?)");
			} else {
			*/
			sbQuery	.append("SELECT extract('epoch' from gs.start_from)*1000 as \"T\", "); //.append(strCounters).append(" as counter_type, ")
			if( !isPdf ){	// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
				sbQuery .append("  (COALESCE(cnt,0)) AS \"Count\", ")
						.append("  (COALESCE(min,0)) AS \"Min\", ")
						.append("  (COALESCE(max,0)) AS \"Max\", ")
						.append("  (COALESCE(avg,0)) AS \"Avg\", ");
			}
			sbQuery	.append("COALESCE(CASE WHEN ").append(isAboveThreshold).append(" IS NULL THEN avg ")
					.append("WHEN ").append(isAboveThreshold).append(" IS true THEN max ELSE min END, 0) AS \"V\" ")
					.append("FROM ( ");
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lStartDateTimeInMins).append(")), date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lEndDateTimeInMins).append(")), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			} else {
				// slider filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', (now() - interval '").append(strFromStartInterval).append("' + interval '1 ").append(strDateTimeTruncBy).append("')), now(), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			}
			sbQuery	.append(") AS gs ")
					.append("LEFT JOIN ( ")
					.append("    SELECT date_trunc('").append(strDateTimeTruncBy).append("', appedo_received_on) as start_from, counter_type, count(counter_type) AS cnt, ")
					.append("      Round(min(counter_value), 3) as min, Round(avg(counter_value), 3) as avg, Round(max(counter_value), 3) AS max ")
					.append("    FROM collector_").append(lUId).append(" ")
					.append("    WHERE ");
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append(" appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMins).append(") AND to_timestamp(").append(lEndDateTimeInMins).append(") ");
			} else {
				// slider filter
				sbQuery.append(" appedo_received_on >= (now() - interval '").append(strFromStartInterval).append("') ");
			}
			sbQuery	.append("      AND counter_type = ").append(strCounters).append(" ")
					.append("    GROUP BY start_from, counter_type ")
					.append(") AS c ON gs.start_from = c.start_from  ")
					.append("WHERE ( date_trunc('").append(strDateTimeTruncBy).append("', now()) = gs.start_from AND c.start_from IS NULL ) = FALSE ")
					.append("ORDER BY gs.start_from ASC ");
			//}
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				
				joData.put("T", rst.getLong("T"));
				if( !isPdf ){	// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
					joData.put("Count", rst.getLong("Count"));
					joData.put("Min", rst.getLong("Min"));
					joData.put("Max", rst.getLong("Max"));
					joData.put("Avg", rst.getLong("Avg"));
				} else {
				joData.put("V", rst.getLong("V"));
				}
				jaData.add(joData);
			}
			
			joCounterWiseChartData = new JSONObject();
			joCounterWiseChartData.put("data", jaData);
			
			//joResult.put("max_recieved_on", lMaxTimeStamp);
			joResult.put("chartdata", joCounterWiseChartData);
				
			joResult.put("guid", strGUID);
			joResult.put("countersException", joCountersException);
			joResult.put("serverCurrentTime", System.currentTimeMillis());
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			strDateTimeTruncBy = null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}
	
	public JSONObject getModuleCountersChartData_v1(Connection con, String strGUID, String strCounters, String strFromStartInterval, Long lStartDateTimeInMillis, Long lEndDateTimeInMillis, Boolean isAboveThreshold, String query, String defaultAggKey) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strDateTimeTruncBy = "";
		
		JSONObject joResult = new JSONObject(), joCountersException = new JSONObject(), joCounterWiseChartData = null, joData = null;
		JSONArray jaData = new JSONArray();
		
		long lUId = -1L;
		
		boolean bBreakCounterSet = false, bCustomFilter = false;
		
		Long lStartDateTimeInMins = null, lEndDateTimeInMins = null;
		
		ModuleDBI moduleDBI = null;
		
		try {
			if ( lEndDateTimeInMillis != null && lStartDateTimeInMillis != null){
				bCustomFilter = true;
				
				// breaks counter's data in parts, which gets plot as discountinues points (ie.. [ [{time: 12654664, value: 6233}, {time: 12654664, value: 6233}, ...], [{time: 12654664, value: 6233}, ..], ...])
				if( lEndDateTimeInMillis - lStartDateTimeInMillis <= 10800000 ) { // 1000 * 60 * 60 * 3 - For last 3 hours
					bBreakCounterSet = true;
				}
				
				lStartDateTimeInMins = lStartDateTimeInMillis / 1000;
				lEndDateTimeInMins = lEndDateTimeInMillis / 1000;
			} else {
				if ( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					bBreakCounterSet = true;
				}
			}
			
			moduleDBI = new ModuleDBI();
			
			lUId = moduleDBI.getUID(con, strGUID);
			
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lStartDateTimeInMins).append(")), date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lEndDateTimeInMins).append(")), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			} else {
				// slider filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', (now() - interval '").append(strFromStartInterval).append("' + interval '1 ").append(strDateTimeTruncBy).append("')), now(), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			}
			query = query.replace("@dateFilter_1@", sbQuery.toString());
			sbQuery.setLength(0);
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append(" appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMins).append(") AND to_timestamp(").append(lEndDateTimeInMins).append(") ");
			} else {
				// slider filter
				sbQuery.append(" appedo_received_on >= (now() - interval '").append(strFromStartInterval).append("') ");
			}
			query = query.replace("@dateFilter_2@", sbQuery.toString());

			query = query.replace("@truncData@", strDateTimeTruncBy);
			query = query.replace("@counterId@", strCounters);
			
			//StringUtils.replace(query, defaultAggKey, strDateTimeTruncBy);
			
			pstmt = con.prepareStatement(query);
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				
				joData.put("T", rst.getLong("T"));
					// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
				//joData.put(defaultAggKey.equals("Min") ? "V":"Min", rst.getLong("Min"));
				//joData.put(defaultAggKey.equals("Max") ? "V":"Max", rst.getLong("Max"));
				//joData.put(defaultAggKey.equals("Avg") ? "V":"Avg", rst.getLong("Avg"));
				joData.put("Min", rst.getLong("Min"));
				joData.put("Max", rst.getLong("Max"));
				joData.put("Avg", rst.getLong("Avg"));
				jaData.add(joData);
			}
			
			joCounterWiseChartData = new JSONObject();
			joCounterWiseChartData.put("data", jaData);
			
			//joResult.put("max_recieved_on", lMaxTimeStamp);
			joResult.put("chartdata", joCounterWiseChartData);
				
			joResult.put("guid", strGUID);
			//joResult.put("countersException", joCountersException);
			//joResult.put("serverCurrentTime", System.currentTimeMillis());
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			strDateTimeTruncBy = null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}
	
	public JSONObject getModuleCountersChartData_v2(Connection con, long lUId, String strCounters, String strFromStartInterval, Long lStartDateTimeInMillis, Long lEndDateTimeInMillis, String query, String xyLabel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strDateTimeTruncBy = "";
		
		JSONObject joResult = new JSONObject(), joCounterWiseChartData = null, joData = null;
		JSONArray jaData = new JSONArray();
		
		//long lUId = -1L;
		
		boolean bBreakCounterSet = false, bCustomFilter = false;
		
		Long lStartDateTimeInMins = null, lEndDateTimeInMins = null;
		
		
		try {
			if ( lEndDateTimeInMillis != null && lStartDateTimeInMillis != null){
				bCustomFilter = true;
				
				// breaks counter's data in parts, which gets plot as discountinues points (ie.. [ [{time: 12654664, value: 6233}, {time: 12654664, value: 6233}, ...], [{time: 12654664, value: 6233}, ..], ...])
				if( lEndDateTimeInMillis - lStartDateTimeInMillis <= 10800000 ) { // 1000 * 60 * 60 * 3 - For last 3 hours
					bBreakCounterSet = true;
				}
				
				lStartDateTimeInMins = lStartDateTimeInMillis / 1000;
				lEndDateTimeInMins = lEndDateTimeInMillis / 1000;
			} else {
				if ( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					bBreakCounterSet = true;
				}
			}
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lStartDateTimeInMins).append(")), date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lEndDateTimeInMins).append(")), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			} else {
				// slider filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', (now() - interval '").append(strFromStartInterval).append("' + interval '1 ").append(strDateTimeTruncBy).append("')), now(), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			}
			query = query.replace("@dateFilter_1@", sbQuery.toString());
			sbQuery.setLength(0);
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append(" appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMins).append(") AND to_timestamp(").append(lEndDateTimeInMins).append(") ");
			} else {
				// slider filter
				sbQuery.append(" appedo_received_on >= (now() - interval '").append(strFromStartInterval).append("') ");
			}
			query = query.replace("@dateFilter_2@", sbQuery.toString());

			query = query.replace("@truncData@", strDateTimeTruncBy);
			query = query.replace("@counterId@", strCounters);
			
			//System.out.println("query : "+ query);
			//StringUtils.replace(query, defaultAggKey, strDateTimeTruncBy);
			
			pstmt = con.prepareStatement(query);
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				
				joData.put(xyLabel , NumberUtils.isNumber(rst.getString("T"))? rst.getLong("T") : rst.getString("T"));
					// Min, Max, Avg are not shown in PDF. So in-order to reduce the JSON size, these are neglected.
				//joData.put(defaultAggKey.equals("Min") ? "V":"Min", rst.getLong("Min"));
				//joData.put(defaultAggKey.equals("Max") ? "V":"Max", rst.getLong("Max"));
				//joData.put(defaultAggKey.equals("Avg") ? "V":"Avg", rst.getLong("Avg"));
				joData.put("count", rst.getLong("count"));
				joData.put("min", rst.getLong("min"));
				joData.put("max", rst.getLong("max"));
				joData.put("avg", rst.getLong("avg"));
				joData.put("warning", rst.getLong("warning"));
				joData.put("critical", rst.getLong("critical"));
				
				jaData.add(joData);
				
			}
			
			joCounterWiseChartData = new JSONObject();
			joCounterWiseChartData.put("data", jaData);
			
			//joResult.put("max_recieved_on", lMaxTimeStamp);
			joResult.put("chartdata", joCounterWiseChartData);
				
			//joResult.put("guid", strGUID);
			//joResult.put("countersException", joCountersException);
			//joResult.put("serverCurrentTime", System.currentTimeMillis());
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			strDateTimeTruncBy = null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}
	
	public JSONObject getLOGModuleCountersChartData_v1(Connection con, Long lUID, String strFromStartInterval, Long lStartDateTimeInMillis, Long lEndDateTimeInMillis, String query) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String strDateTimeTruncBy = "";
		JSONObject joResult = new JSONObject(), joCounterWiseChartData = null, joData = null;
		JSONArray jaData = new JSONArray();
		boolean bBreakCounterSet = false, bCustomFilter = false;
		Long lStartDateTimeInMins = null, lEndDateTimeInMins = null;
		
		try {
			if ( lEndDateTimeInMillis != null && lStartDateTimeInMillis != null){
				bCustomFilter = true;
				// breaks counter's data in parts, which gets plot as discountinues points (ie.. [ [{time: 12654664, value: 6233}, {time: 12654664, value: 6233}, ...], [{time: 12654664, value: 6233}, ..], ...])
				if( lEndDateTimeInMillis - lStartDateTimeInMillis <= 10800000 ) { // 1000 * 60 * 60 * 3 - For last 3 hours
					bBreakCounterSet = true;
				}
				lStartDateTimeInMins = lStartDateTimeInMillis / 1000;
				lEndDateTimeInMins = lEndDateTimeInMillis / 1000;
			} else {
				if ( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					bBreakCounterSet = true;
				}
			}
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lStartDateTimeInMins).append(")), date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lEndDateTimeInMins).append(")), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			} else {
				// slider filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', (now() - interval '").append(strFromStartInterval).append("' + interval '1 ").append(strDateTimeTruncBy).append("')), now(), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			}
			query = query.replace("@dateFilter_1@", sbQuery.toString());
			sbQuery.setLength(0);
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append(" appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMins).append(") AND to_timestamp(").append(lEndDateTimeInMins).append(") ");
			} else {
				// slider filter
				sbQuery.append(" appedo_received_on >= (now() - interval '").append(strFromStartInterval).append("') ");
			}
			query = query.replace("@dateFilter_2@", sbQuery.toString());

			query = query.replace("@truncData@", strDateTimeTruncBy);
			
			
			//StringUtils.replace(query, defaultAggKey, strDateTimeTruncBy);
			
			pstmt = con.prepareStatement(query);
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put("T", rst.getLong("T"));
				joData.put("V", rst.getLong("count"));
				jaData.add(joData);
			}
			joCounterWiseChartData = new JSONObject();
			joCounterWiseChartData.put("data", jaData);
			joResult.put("chartdata", joCounterWiseChartData);
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strDateTimeTruncBy = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}
	
	public JSONObject getLOGModuleCountersChartData_v2(Connection con, Long lUID, String strFromStartInterval, Long lStartDateTimeInMillis, Long lEndDateTimeInMillis, String query, String xyLabel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String strDateTimeTruncBy = "";
		JSONObject joResult = new JSONObject(), joCounterWiseChartData = null, joData = null;
		JSONArray jaData = new JSONArray();
		boolean bBreakCounterSet = false, bCustomFilter = false;
		Long lStartDateTimeInMins = null, lEndDateTimeInMins = null;
		
		try {
			//long startTime = System.currentTimeMillis();
			if ( lEndDateTimeInMillis != null && lStartDateTimeInMillis != null){
				bCustomFilter = true;
				// breaks counter's data in parts, which gets plot as discountinues points (ie.. [ [{time: 12654664, value: 6233}, {time: 12654664, value: 6233}, ...], [{time: 12654664, value: 6233}, ..], ...])
				if( lEndDateTimeInMillis - lStartDateTimeInMillis <= 10800000 ) { // 1000 * 60 * 60 * 3 - For last 3 hours
					bBreakCounterSet = true;
				}
				lStartDateTimeInMins = lStartDateTimeInMillis / 1000;
				lEndDateTimeInMins = lEndDateTimeInMillis / 1000;
			} else {
				if ( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					bBreakCounterSet = true;
				}
			}
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lStartDateTimeInMins).append(")), date_trunc('").append(strDateTimeTruncBy).append("', to_timestamp(").append(lEndDateTimeInMins).append(")), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			} else {
				// slider filter
				sbQuery.append("  SELECT generate_series(date_trunc('").append(strDateTimeTruncBy).append("', (now() - interval '").append(strFromStartInterval).append("' + interval '1 ").append(strDateTimeTruncBy).append("')), now(), '1 ").append(strDateTimeTruncBy).append("') AS start_from ");
			}
			query = query.replace("@dateFilter_1@", sbQuery.toString());
			sbQuery.setLength(0);
			if ( bCustomFilter ) {
				// custom filter
				sbQuery.append(" logstash_timestamp BETWEEN to_timestamp(").append(lStartDateTimeInMins).append(") AND to_timestamp(").append(lEndDateTimeInMins).append(") ");
			} else {
				// slider filter
				sbQuery.append(" logstash_timestamp >= (now() - interval '").append(strFromStartInterval).append("') ");
			}
			query = query.replace("@dateFilter_2@", sbQuery.toString());

			query = query.replace("@truncData@", strDateTimeTruncBy);
			
			
			//StringUtils.replace(query, defaultAggKey, strDateTimeTruncBy);
			
			pstmt = con.prepareStatement(query);
			
			rst = pstmt.executeQuery();
			//System.out.println("Execute query : "+ (System.currentTimeMillis()-startTime));
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put(xyLabel, rst.getLong("T"));
				joData.put("count", rst.getLong("count"));
				joData.put("min", rst.getLong("min"));
				joData.put("avg", rst.getLong("avg"));
				joData.put("max", rst.getLong("max"));
				joData.put("warning", rst.getLong("warning"));
				joData.put("critical", rst.getLong("critical"));
				jaData.add(joData);
			}
			//System.out.println("JSON prepared : "+ (System.currentTimeMillis()-startTime));
			joCounterWiseChartData = new JSONObject();
			joCounterWiseChartData.put("data", jaData);
			joResult.put("chartdata", joCounterWiseChartData);
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strDateTimeTruncBy = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}
	
	public JSONArray getLOGTypes(Connection con, Long lUID) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaResult = new JSONArray();
		JSONObject joData = new JSONObject();
		
		try {
									
			sbQuery.append("select * from get_available_log(").append(lUID).append(") ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put("name", rst.getString("r_log_grok"));
				joData.put("value", rst.getString("r_log_grok"));
				joData.put("tableName", rst.getString("r_log_table"));
				joData.put("osName", rst.getString("r_os_name"));
				jaResult.add(joData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return jaResult;
	}
	
	public JSONArray getTomcatCatalinaLog(Connection con, Long lUID, String strSearchText, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, String logTableName, String logLevel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaResult = new JSONArray();
		JSONObject joData = new JSONObject();
		
		try {
			sbQuery.append("SELECT * from ").append(logTableName).append(lUID).append(" WHERE ");
			if (logLevel.equals(Constants.CRITICAL)){
				sbQuery.append(" loglevel = 'SEVERE' AND ");
			} else if (logLevel.equals(Constants.WARNING)) {
				sbQuery.append(" loglevel = 'WARNING' AND  ");
			} else if(logLevel.equals("INFO")) {
				sbQuery.append(" loglevel NOT IN ('WARNING', 'CRITICAL') AND ");
			} 
			if (strSearchText != null && strSearchText.length() > 0) {
				sbQuery.append(" message ILIKE '%").append(strSearchText).append("%' AND ");
			}
			if (strFromStartInterval != null){
				sbQuery.append(" logstash_timestamp BETWEEN now()- INTERVAL '").append(strFromStartInterval).append("' AND now() ");
			} else {
				sbQuery.append(" logstash_timestamp BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			}
			sbQuery.append(" ORDER BY logstash_timestamp DESC LIMIT 50");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put("date", rst.getTimestamp("logstash_timestamp").getTime());
				joData.put("host", rst.getString("host"));
				joData.put("logLevel", rst.getString("loglevel"));
				joData.put("source", rst.getString("source"));
				joData.put("class", rst.getString("classname"));
				joData.put("event", rst.getString("event"));
				joData.put("logMessage", rst.getString("logmessage"));
				
				jaResult.add(joData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return jaResult;
	}
	
	public JSONArray getTomcatAccessLog(Connection con, Long lUID, String strSearchText, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, String logTableName, String logLevel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaResult = new JSONArray();
		JSONObject joData = new JSONObject();
		
		try {
			sbQuery.append("SELECT * from ").append(logTableName).append(lUID).append(" WHERE ");
			if (logLevel.equals(Constants.CRITICAL)){
				sbQuery.append(" status::int > 499 AND ");
			} else if (logLevel.equals(Constants.WARNING)) {
				sbQuery.append(" status::int BETWEEN 400 AND 499 AND  ");
			} else if(logLevel.equals("INFO")) {
				sbQuery.append(" status::int BETWEEN 200 AND 399 AND ");
			} 
			if (strSearchText != null && strSearchText.length() > 0) {
				sbQuery.append(" message ILIKE '%").append(strSearchText).append("%' AND ");
			}
			if (strFromStartInterval != null){
				sbQuery.append(" logstash_timestamp BETWEEN now()- INTERVAL '").append(strFromStartInterval).append("' AND now() ");
			} else {
				sbQuery.append(" logstash_timestamp BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			}
			sbQuery.append(" ORDER BY logstash_timestamp DESC LIMIT 50");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put("date", rst.getTimestamp("logstash_timestamp").getTime());
				joData.put("host", rst.getString("ip_or_host"));
				joData.put("logLevel", rst.getString("status"));
				joData.put("source", rst.getString("source"));
				joData.put("method", rst.getString("method"));
				joData.put("path", rst.getString("path"));
				joData.put("protocol", rst.getString("protocol"));
				joData.put("bytes", rst.getString("bytes"));
				joData.put("responseTime", rst.getString("resptime_ms"));
				joData.put("logMessage", rst.getString("logmessage"));
				
				jaResult.add(joData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return jaResult;
	}
	
	public JSONArray getLinuxSysLog(Connection con, Long lUID, String strSearchText, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, String logTableName, String logLevel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaResult = new JSONArray();
		JSONObject joData = new JSONObject();
		
		try {
			sbQuery.append("SELECT * from ").append(logTableName).append(lUID).append(" WHERE ");
			if (strSearchText != null && strSearchText.length() > 0) {
				sbQuery.append(" message ILIKE '%").append(strSearchText).append("%' AND ");
			}
			if (strFromStartInterval != null){
				sbQuery.append(" logstash_timestamp BETWEEN now()- INTERVAL '").append(strFromStartInterval).append("' AND now() ");
			} else {
				sbQuery.append(" logstash_timestamp BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			}
			sbQuery.append(" ORDER BY logstash_timestamp DESC LIMIT 50");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put("date", rst.getTimestamp("logstash_timestamp").getTime());
				joData.put("host", rst.getString("host"));
				joData.put("logLevel", " ");
				joData.put("source", rst.getString("source"));
				joData.put("program", rst.getString("program"));
				joData.put("pid", rst.getString("pid"));
				joData.put("logMessage", rst.getString("logmessage"));
				
				jaResult.add(joData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return jaResult;
	}
	
	public JSONArray getGenericLog(Connection con, Long lUID, String strSearchText, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, String logTableName, String logLevel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaResult = new JSONArray();
		JSONObject joData = new JSONObject();
		
		try {
			sbQuery.append("SELECT * from ").append(logTableName).append(lUID).append(" WHERE ");
			if (strSearchText != null && strSearchText.length() > 0) {
				sbQuery.append(" message ILIKE '%").append(strSearchText).append("%' AND ");
			}
			if (strFromStartInterval != null){
				sbQuery.append(" logstash_timestamp BETWEEN now()- INTERVAL '").append(strFromStartInterval).append("' AND now() ");
			} else {
				sbQuery.append(" logstash_timestamp BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			}
			sbQuery.append(" ORDER BY logstash_timestamp DESC LIMIT 50");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put("date", rst.getTimestamp("logstash_timestamp").getTime());
				joData.put("host", rst.getString("host"));
				joData.put("logLevel", " ");
				joData.put("source", rst.getString("source"));
				joData.put("logMessage", rst.getString("message")); 
				jaResult.add(joData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return jaResult;
	}
	
	public JSONArray getLOG4JErrorLog(Connection con, Long lUID, String strSearchText, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, String logTableName, String logLevel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaResult = new JSONArray();
		JSONObject joData = new JSONObject();
		
		try {
			sbQuery.append("SELECT * from ").append(logTableName).append(lUID).append(" WHERE ");
			if (strSearchText != null && strSearchText.length() > 0) {
				sbQuery.append(" message ILIKE '%").append(strSearchText).append("%' AND ");
			}
			if (strFromStartInterval != null){
				sbQuery.append(" logstash_timestamp BETWEEN now()- INTERVAL '").append(strFromStartInterval).append("' AND now() ");
			} else {
				sbQuery.append(" logstash_timestamp BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			}
			sbQuery.append(" ORDER BY logstash_timestamp DESC LIMIT 50");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put("date", rst.getString("logstash_timestamp"));
				joData.put("host", rst.getString("host")); 
				joData.put("logLevel", " ");
				joData.put("source", rst.getString("source"));
				joData.put("class", rst.getString("classname"));
				joData.put("threadId", rst.getString("thread_id"));
				joData.put("exceptionClass", rst.getString("exceptionclass"));
				joData.put("logMessage", rst.getString("comments"));
				
				jaResult.add(joData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}

		return jaResult;
	}
	
	/**
	 * gets static counter(s) data,
	 *   if `bHaveCounterMasterDetails` is true gets counter data with counter master details
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounters
	 * @param bHaveCounterMasterDetails
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModuleStaticCountersData(Connection con, String strGUID, String strCounters, boolean bHaveCounterMasterDetails) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strCounterId = "";
		
		JSONObject joResult = new JSONObject(), joCountersException = new JSONObject(), joDatum = null, joCounterMasterDetails = null;
		
		HashMap<String, Object> hmCountersData = null;
		
		ArrayList<JSONObject> alData = null;
		
		long lUId = -1L;
		
		ModuleDBI moduleDBI = null;
		
		try {
			moduleDBI = new ModuleDBI();
			
			lUId = moduleDBI.getUID(con, strGUID);
			
			sbQuery	.append("SELECT DISTINCT ON (counter_type) counter_type, extract('epoch' from appedo_received_on)*1000 as \"T\", counter_value AS \"V\" ")
					.append("FROM collector_").append(lUId).append(" ")
					.append("WHERE counter_type IN (").append(strCounters).append(") ")
					//.append("  AND is_first = TRUE ")
					.append("ORDER BY counter_type, appedo_received_on DESC ");
			
			hmCountersData = new HashMap<String, Object>();
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				alData = new ArrayList<JSONObject>(1);
				strCounterId = rst.getString("counter_type");
				
				joDatum = new JSONObject();
				joDatum.put("T", rst.getLong("T"));
				joDatum.put("V", rst.getLong("V"));
				alData.add(joDatum);
				
				if ( bHaveCounterMasterDetails ) {
					// TODO conform, get counter master details, using JOIN or below is fine
					
					// gets counter master details & sets data 
					joCounterMasterDetails = getCounterDetails(con, lUId, strCounterId);
					joCounterMasterDetails.put("chartdata", alData);
					
					hmCountersData.put(strCounterId, joCounterMasterDetails);
				} else {
					hmCountersData.put(strCounterId, alData);
				}
			}
			joResult.put("chartdata", hmCountersData);
			joResult.put("guid", strGUID);
			joResult.put("countersException", joCountersException);
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	public JSONObject getModuleStaticCountersDataWithCounterDetails(Connection con, String strGUID, String strCounters) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joResult = new JSONObject(), joCountersException = new JSONObject(), joCounterCountersValue = null, joDatum = null;
		
		ArrayList<JSONObject> alData = null;
		
		long lUId = -1L;
		
		ModuleDBI moduleDBI = null;
		
		try {
			moduleDBI = new ModuleDBI();
			
			lUId = moduleDBI.getUID(con, strGUID);
			
			// TODO: for multiple counter alter query 
			
			sbQuery	.append("SELECT extract('epoch' from appedo_received_on)*1000 as \"T\", counter_value AS \"V\" ")
					.append("FROM collector_").append(lUId).append(" ")
					.append("WHERE counter_type = ").append(strCounters).append(" ")
					.append("  AND is_first = TRUE ")
					.append("ORDER BY appedo_received_on DESC ")
					.append("LIMIT 1 ");
			
			joCounterCountersValue = new JSONObject();
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				alData = new ArrayList<JSONObject>(1);
				
				joDatum = new JSONObject();
				joDatum.put("T", rst.getLong("T"));
				joDatum.put("V", rst.getLong("V"));
				alData.add(joDatum);
				
				joCounterCountersValue.put(strCounters, alData);
			}
			joResult.put("chartdata", joCounterCountersValue);
			joResult.put("guid", strGUID);
			joResult.put("countersException", joCountersException);
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	/**
	 * Gets transactions done in the application
	 * 
	 * @param con
	 * @param strGUID
	 * @param profilerTrans 
	 * @return
	 * @throws Exception
	 */
	public JSONArray getProfilerTransactionTree(Connection con, String strGUID, String strCounterTypeName, String strFromStartInterval, boolean profilerTrans) throws Exception {
		PreparedStatement psProfilerTransactionTree = null;
		ResultSet rst = null;

		JSONArray jaTransactions = new JSONArray();
		JSONObject joTransaction = null;

		int i = 0;
		float fMaxAvgDuration = 0f;
		// Percentage is calculated based on its max value returns
		float fPercentagAvgDuration = 0f;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			if(strCounterTypeName.equals("MSIIS")) {
				sbQuery.append("SELECT * FROM get_dnp_transaction_summary(?, ?, ?)");
			} else {
				sbQuery.append("SELECT * FROM get_jp_transaction_summary(?, ?, ?)");
			}
			
			psProfilerTransactionTree = con.prepareStatement(sbQuery.toString());
			psProfilerTransactionTree.setString(1, strGUID);
			psProfilerTransactionTree.setString(2, strFromStartInterval);
			psProfilerTransactionTree.setBoolean(3, profilerTrans);
			rst = psProfilerTransactionTree.executeQuery();
			while (rst.next()) {
				joTransaction = new JSONObject();
				
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				if (i == 0) {
					fMaxAvgDuration = rst.getFloat("avg_duration_ms");
					if(fMaxAvgDuration == 0) {
						fMaxAvgDuration = 1;
					}
				}
				fPercentagAvgDuration = rst.getFloat("avg_duration_ms") / fMaxAvgDuration * 100;
				
				joTransaction.put("transactionType", rst.getString("tx_type"));
				joTransaction.put("localhost_name_ip", rst.getString("localhost_name_ip"));
				joTransaction.put("transactionName", rst.getString("request_uri"));
				joTransaction.put("noOfHits", rst.getString("no_of_hits"));
				joTransaction.put("avgDuration", rst.getFloat("avg_duration_ms"));
				joTransaction.put("percentageAvgDuration", (fPercentagAvgDuration != 0 ? fPercentagAvgDuration : 1));
				joTransaction.put("keyTransactionId", rst.getInt("key_id"));
				joTransaction.put("keyTransactionName", rst.getString("key_name"));
				joTransaction.put("keyTransactionDescription", rst.getString("key_description"));
				joTransaction.put("guid", strGUID);
				
				jaTransactions.add(joTransaction);
				i = i + 1;
			}

			UtilsFactory.clearCollectionHieracy( sbQuery );
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(psProfilerTransactionTree);
			psProfilerTransactionTree = null;
		}

		return jaTransactions;
	} 
	
	public JSONArray getProfilerTransactionsWithDateRange(Connection con, String strGUID, String strCounterTypeName, String strFromStartInterval, String strToInterval, boolean profilerTrans) throws Exception {
		PreparedStatement psProfilerTransactionTree = null;
		ResultSet rst = null;

		JSONArray jaTransactions = new JSONArray();
		JSONObject joTransaction = null;

		int i = 0;
		float fMaxAvgDuration = 0f;
		// Percentage is calculated based on its max value returns
		float fPercentagAvgDuration = 0f;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			if(strCounterTypeName.equals("MSIIS")) {
				sbQuery.append("SELECT * FROM get_dnp_transaction_summary_with_date_range(?, ?, ?, ?)");
			} else {
				sbQuery.append("SELECT * FROM get_jp_transaction_summary_with_date_range(?, ?, ?, ?)");
			}
			
			psProfilerTransactionTree = con.prepareStatement(sbQuery.toString());
			psProfilerTransactionTree.setString(1, strGUID);
			psProfilerTransactionTree.setLong(2, Long.parseLong(strFromStartInterval));
			psProfilerTransactionTree.setLong(3, Long.parseLong(strToInterval));
			psProfilerTransactionTree.setBoolean(4, profilerTrans);
			rst = psProfilerTransactionTree.executeQuery();
			while (rst.next()) {
				joTransaction = new JSONObject();
				
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				if (i == 0) {
					fMaxAvgDuration = rst.getFloat("avg_duration_ms");
					if(fMaxAvgDuration == 0) {
						fMaxAvgDuration = 1;
					}
				}
				fPercentagAvgDuration = rst.getFloat("avg_duration_ms") / fMaxAvgDuration * 100;
				
				joTransaction.put("transactionType", rst.getString("tx_type"));
				joTransaction.put("localhost_name_ip", rst.getString("localhost_name_ip"));
				joTransaction.put("transactionName", rst.getString("request_uri"));
				joTransaction.put("noOfHits", rst.getString("no_of_hits"));
				joTransaction.put("avgDuration", rst.getFloat("avg_duration_ms"));
				joTransaction.put("percentageAvgDuration", (fPercentagAvgDuration != 0 ? fPercentagAvgDuration : 1));
				joTransaction.put("keyTransactionId", rst.getInt("key_id"));
				joTransaction.put("keyTransactionName", rst.getString("key_name"));
				joTransaction.put("keyTransactionDescription", rst.getString("key_description"));
				joTransaction.put("guid", strGUID);
				
				jaTransactions.add(joTransaction);
				i = i + 1;
			}

			UtilsFactory.clearCollectionHieracy( sbQuery );
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(psProfilerTransactionTree);
			psProfilerTransactionTree = null;
		}

		return jaTransactions;
	}
	
	/**
	 * Gets the selected transaction time taken
	 * 
	 * @param con
	 * @param strGUID
	 * @param strLocalhostNameIP
	 * @param strTransactionName
	 * @return
	 * @throws Exception
	 */
	public ArrayList getProfilerTransactionTimeTaken(Connection con, String strTransactionType, String strGUID, String strLocalhostNameIP, String strTransactionName, String strCounterTypeName, String strFromStartInterval) throws Exception {
		PreparedStatement psProfilerTransactionTimeTaken = null;
		ResultSet rst = null;

		/*JSONArray jaTransactionsTimeTaken = new JSONArray();
		JSONObject joTransactionTimeTaken = null;*/

		ArrayList alData = null;
		ArrayList alTransactionsTimeTaken = new ArrayList();

		StringBuilder sbQuery = new StringBuilder();

		try {
			if(strCounterTypeName.equals("MSIIS")) {
				sbQuery	.append("SELECT * FROM get_dnp_expensive_transactions_timestamp(?, ?, ?::text, ?)");
				psProfilerTransactionTimeTaken = con.prepareStatement(sbQuery.toString());
				psProfilerTransactionTimeTaken.setString(1, strGUID);
				psProfilerTransactionTimeTaken.setString(2, strLocalhostNameIP);
				psProfilerTransactionTimeTaken.setString(3, strTransactionName);
				psProfilerTransactionTimeTaken.setString(4, strFromStartInterval);
			} else {
				sbQuery	.append("SELECT * FROM get_jp_expensive_transactions_timestamp(?, ?, ?, ?::text, ?) ");
				psProfilerTransactionTimeTaken = con.prepareStatement(sbQuery.toString());
				psProfilerTransactionTimeTaken.setString(1, strGUID);
				psProfilerTransactionTimeTaken.setString(2, strLocalhostNameIP);
				psProfilerTransactionTimeTaken.setString(3, strTransactionType);
				psProfilerTransactionTimeTaken.setString(4, strTransactionName);
				psProfilerTransactionTimeTaken.setString(5, strFromStartInterval);
			}
			
			rst = psProfilerTransactionTimeTaken.executeQuery();
			while (rst.next()) {
				/*joTransactionTimeTaken = new JSONObject();
				// joTransactionTimeTaken.put("pId", rst.getString("p_id"));
				joTransactionTimeTaken.put("startTime", rst.getTimestamp("start_time").getTime());
				joTransactionTimeTaken.put("startTimeStamp", rst.getString("start_time"));
				joTransactionTimeTaken.put("durationMS", rst.getFloat("duration_ms"));

				jaTransactionsTimeTaken.add(joTransactionTimeTaken);*/

				alData = new ArrayList(2);
				alData.add(rst.getTimestamp("start_time").getTime());
				alData.add(rst.getFloat("duration_ms"));

				alTransactionsTimeTaken.add(alData);
			}

			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(psProfilerTransactionTimeTaken);
			psProfilerTransactionTimeTaken = null;
		}

		// return jaTransactionsTimeTaken;
		return alTransactionsTimeTaken;
	}

	public ArrayList getProfilerTransactionTimeTakenWithDateRange(Connection con, String strGUID, String strLocalhostNameIP, String strTransactionType, String strTransactionName, String strCounterTypeName, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement psProfilerTransactionTimeTaken = null;
		ResultSet rst = null;

		/*JSONArray jaTransactionsTimeTaken = new JSONArray();
		JSONObject joTransactionTimeTaken = null;*/

		ArrayList alData = null;
		ArrayList alTransactionsTimeTaken = new ArrayList();

		StringBuilder sbQuery = new StringBuilder();

		try {
			if(strCounterTypeName.equals("MSIIS")) {
				sbQuery	.append("SELECT * FROM get_dnp_expensive_transactions_timestamp_with_date_range(?, ?, ?::text, ?, ?)");
				psProfilerTransactionTimeTaken = con.prepareStatement(sbQuery.toString());
				psProfilerTransactionTimeTaken.setString(1, strGUID);
				psProfilerTransactionTimeTaken.setString(2, strLocalhostNameIP);
				psProfilerTransactionTimeTaken.setString(3, strTransactionName);
				psProfilerTransactionTimeTaken.setLong(4, Long.parseLong(strFromStartInterval));
				psProfilerTransactionTimeTaken.setLong(5, Long.parseLong(strToInterval));
			} else {
				sbQuery	.append("SELECT * FROM get_jp_expensive_transactions_timestamp_with_date_range(?, ?, ?, ?::text, ?, ?) ");
				psProfilerTransactionTimeTaken = con.prepareStatement(sbQuery.toString());
				psProfilerTransactionTimeTaken.setString(1, strGUID);
				psProfilerTransactionTimeTaken.setString(2, strLocalhostNameIP);
				psProfilerTransactionTimeTaken.setString(3, strTransactionType);
				psProfilerTransactionTimeTaken.setString(4, strTransactionName);
				psProfilerTransactionTimeTaken.setLong(5, Long.parseLong(strFromStartInterval));
				psProfilerTransactionTimeTaken.setLong(6, Long.parseLong(strToInterval));
			}
			
			rst = psProfilerTransactionTimeTaken.executeQuery();
			while (rst.next()) {
				/*joTransactionTimeTaken = new JSONObject();
				// joTransactionTimeTaken.put("pId", rst.getString("p_id"));
				joTransactionTimeTaken.put("startTime", rst.getTimestamp("start_time").getTime());
				joTransactionTimeTaken.put("startTimeStamp", rst.getString("start_time"));
				joTransactionTimeTaken.put("durationMS", rst.getFloat("duration_ms"));

				jaTransactionsTimeTaken.add(joTransactionTimeTaken);*/

				alData = new ArrayList(2);
				alData.add(rst.getTimestamp("start_time").getTime());
				alData.add(rst.getFloat("duration_ms"));
				
				alTransactionsTimeTaken.add(alData);
			}
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(psProfilerTransactionTimeTaken);
			psProfilerTransactionTimeTaken = null;
		}
		
		// return jaTransactionsTimeTaken;
		return alTransactionsTimeTaken;
	}
	
	/*
	 * public JSONArray getProfilerTransactionTimeTaken(Connection con, String
	 * strGUID, String strTransactionName) throws Exception { PreparedStatement
	 * psProfilerTransactionTimeTaken = null; ResultSet rst = null;
	 * 
	 * JSONArray jaTransactionsTimeTaken = new JSONArray(); JSONObject
	 * joTransactionTimeTaken = null;
	 * 
	 * ArrayList alData = null; ArrayList alTransactionsTimeTaken = new
	 * ArrayList();
	 * 
	 * 
	 * StringBuilder sbQuery = new StringBuilder();
	 * 
	 * try{
	 * sbQuery.append("SELECT * FROM gettransactionstimestamp('").append(strGUID
	 * ).append("', '").append(strTransactionName).append("'::text) ");
	 * 
	 * psProfilerTransactionTimeTaken =
	 * con.prepareStatement(sbQuery.toString()); rst =
	 * psProfilerTransactionTimeTaken.executeQuery();
	 * 
	 * while( rst.next() ){ joTransactionTimeTaken = new JSONObject();
	 * joTransactionTimeTaken.put("pId", rst.getString("p_id"));
	 * joTransactionTimeTaken.put("startTime",
	 * rst.getTimestamp("start_time").getTime());
	 * joTransactionTimeTaken.put("startTimeStamp",
	 * rst.getString("start_time")); joTransactionTimeTaken.put("durationMS",
	 * rst.getFloat("duration_ms"));
	 * 
	 * jaTransactionsTimeTaken.add(joTransactionTimeTaken);
	 * 
	 * alData = new ArrayList(2);
	 * alData.add(rst.getTimestamp("start_time").getTime());
	 * alData.add(rst.getFloat("duration_ms"));
	 * 
	 * alTransactionsTimeTaken.add(alData); }
	 * 
	 * } catch(Exception ex) {
	 * System.out.println("Exception in getProfilerTransactionTimeTaken: "
	 * +ex.getMessage()); throw ex; } finally { DataBaseManager.close(rst); rst
	 * = null; DataBaseManager.close(psProfilerTransactionTimeTaken);
	 * psProfilerTransactionTimeTaken = null; }
	 * 
	 * 
	 * return jaTransactionsTimeTaken; //return alTransactionsTimeTaken; }
	 */

	/**
	 * Gets method trace for the time taken transaction
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public ArrayList<LinkedHashMap<String, Object>> getProfilerMethodsTrace(Connection con, String strGUID, String strLocalNameIP, String strTransactionType, String strTransactionName, String strTimeStamp, String strDuration, String strCounterTypeName) throws Exception {
		PreparedStatement psProfilerMethodsTrace = null;
		ResultSet rst = null;
		/*
		 * JSONArray jaMethodsTrace = new JSONArray(), jaChildMethods = null;
		 * JSONObject joMethodTrace = null, joParentMethod = null;
		 */
		ArrayList<LinkedHashMap<String, Object>> jaChildMethods = null;
		ArrayList<LinkedHashMap<String, Object>> alRootNodes = new ArrayList<LinkedHashMap<String, Object>>();
		
		// To keep the Function's level in StackTrace. (i.e.) Child function's generation level.
		HashMap<String, Integer> hmMethodStackLevel = new HashMap<String, Integer>();
		
		LinkedHashMap<String, Object> joMethodTrace = null, joParentMethod = null;

		HashMap<String, LinkedHashMap<String, Object>> hmMethodTraces = new HashMap<String, LinkedHashMap<String, Object>>();

		StringBuilder sbQuery = new StringBuilder();
		Long lCallerMethodId = 0l, lMethodId = 0l;
		Stack<String> stackMethodIds = new Stack<String>();
		// Stack<JSONObject> stackMethods = new Stack<JSONObject>();
		String strIndent = "", strShowText = null, strParentMethodId = null, strRootMethodId = null;
		long lStartTime = 0l;
		int i = 0;
		
		try {
			if(strCounterTypeName.equals("MSIIS")) {
				/*sbQuery	.append("SELECT * FROM get_dnp_transaction_stacktrace('").append(strGUID).append("', '")
						.append(strLocalNameIP).append("', '").append(strTransactionName).append("'::text, '")
						.append(strTimeStamp).append("', ").append(strDuration).append(") ");*/
				sbQuery	.append("SELECT * FROM get_dnp_transaction_stacktrace(?, ?, ?::text, ?, ?) ");
				
				psProfilerMethodsTrace = con.prepareStatement(sbQuery.toString());
				psProfilerMethodsTrace.setString(1, strGUID);
				psProfilerMethodsTrace.setString(2, strLocalNameIP);
				psProfilerMethodsTrace.setString(3, strTransactionName);
				psProfilerMethodsTrace.setString(4, strTimeStamp);
				psProfilerMethodsTrace.setInt(5, Integer.parseInt(strDuration));
			} else {
				/*sbQuery	.append("SELECT * FROM get_jp_transaction_stacktrace('").append(strGUID).append("', '")
						.append(strLocalNameIP).append("', '").append(strTransactionName).append("'::text, '")
						.append(strTimeStamp).append("', ").append(strDuration).append(") ");*/
				sbQuery	.append("SELECT * FROM get_jp_transaction_stacktrace(?, ?, ?::text, ?::text, ?, ?)");
				
				psProfilerMethodsTrace = con.prepareStatement(sbQuery.toString());
				psProfilerMethodsTrace.setString(1, strGUID);
				psProfilerMethodsTrace.setString(2, strLocalNameIP);
				psProfilerMethodsTrace.setString(3, strTransactionType);
				psProfilerMethodsTrace.setString(4, strTransactionName);
				psProfilerMethodsTrace.setString(5, strTimeStamp);
				psProfilerMethodsTrace.setInt(6, Integer.parseInt(strDuration));
			}
			
			rst = psProfilerMethodsTrace.executeQuery();
			
			while (rst.next()) {
				strParentMethodId = null;
				joMethodTrace = new LinkedHashMap<String, Object>();
				lCallerMethodId = Long.valueOf(rst.getLong("caller_method_id"));
				lMethodId = Long.valueOf(rst.getLong("method_id"));
				
				if (stackMethodIds.size() != 0 && lCallerMethodId != -1l) {

					if ((strParentMethodId = stackMethodIds.peek()).equals(lCallerMethodId + "")) {
					} else if (stackMethodIds.contains(lCallerMethodId + "")) {
						do {
							stackMethodIds.pop();
							// strIndent = strIndent.substring( 0,
							// strIndent.length() - "---".length() );

						} while (!(strParentMethodId = stackMethodIds.peek()).equals(lCallerMethodId + ""));
					}
					// strIndent += "---";
					strShowText = strIndent + rst.getString("class_name") + "." + rst.getString("method_name");
				} else if (stackMethodIds.size() == 0) {
					strShowText = rst.getString("class_name") + "." + rst.getString("method_name");
					strRootMethodId = lMethodId + "";
				} else if (lCallerMethodId == -1l) {
					strIndent = "";
					strShowText = rst.getString("request_uri");
				}
				
				// append
				/*
				 * if( rst.getString("type").equals("SQL_METHOD") ){ strShowText
				 * += "<BR/>"+rst.getString("query"); }
				 * 
				 * if( rst.getString("exception_stacktrace").length() > 0 ){
				 * strShowText += "<BR/>"+rst.getString("exception_stacktrace");
				 * }
				 */
				
				// Calculate the relative function start time
				// initiate the first time
				if (i == 0) {
					lStartTime = rst.getDate("start_time").getTime();
				}
				
				joMethodTrace.put("\"id\"", rst.getString("id"));
				joMethodTrace.put("\"type\"", "\"" + rst.getString("type").replaceAll("\"", "\\\\\"") + "\"");
				joMethodTrace.put("\"query\"", "\"" + rst.getString("query").replaceAll("\"", "\\\\\"") + "\"");
				joMethodTrace.put("\"showText\"", "\"" + strShowText.replaceAll("\"", "\\\\\"") + "\"");
				joMethodTrace.put("\"duration\"", rst.getInt("duration_ms"));
				joMethodTrace.put("\"time_trace\"", (rst.getDate("start_time").getTime() - lStartTime));
				joMethodTrace.put("\"exception_type\"", "\"" + rst.getString("exception_type").replaceAll("\"", "\\\\\"") + "\"");
				joMethodTrace.put("\"exception_message\"", "\"" + rst.getString("exception_message").replaceAll("\"", "\\\\\"") + "\"");
				joMethodTrace.put("\"exception_stacktrace\"", "\"" + rst.getString("exception_stacktrace").replaceAll("\"", "\\\\\"") + "\"");
				joMethodTrace.put("\"items\"", new ArrayList<LinkedHashMap<String, Object>>());
				// System.out.println("joMethodTrace: "+joMethodTrace);
				
				// Put method's Stack Level
				if( hmMethodStackLevel.containsKey(strParentMethodId) ){
					hmMethodStackLevel.put(lMethodId+"", hmMethodStackLevel.get(strParentMethodId) + 1 );
				} else {
					hmMethodStackLevel.put(lMethodId+"", 1);
				}
//				System.out.println("hmMethodStackLevel: "+hmMethodStackLevel);
				
				if (strParentMethodId != null && hmMethodTraces.containsKey(strParentMethodId)) {
					joParentMethod = hmMethodTraces.get(strParentMethodId);
					jaChildMethods = (ArrayList<LinkedHashMap<String, Object>>) joParentMethod.get("\"items\"");
					
					// To avoid more recursive method calls shown in the UI, limit child length.
					// This will prevent Browser from hang or invisible, due to more depth.
					if( hmMethodStackLevel.get(lMethodId+"") <= Constants.PROFILER_STACK_METHOD_CALL_LEVEL ){
						jaChildMethods.add(joMethodTrace);
						joParentMethod.put("\"items\"", jaChildMethods);
						hmMethodTraces.put(strParentMethodId, joParentMethod);
					}
				}
				
				// if parent-method-id is not -1 then, don't add this.
				if( lCallerMethodId == -1l || hmMethodTraces.containsKey(strParentMethodId) ){
					hmMethodTraces.put(lMethodId + "", joMethodTrace);
				}
				
				stackMethodIds.push(lMethodId + "");
				
				if (lCallerMethodId == -1l) {
					// if parent-method-id is not -1 then, don't add this.
					if( lCallerMethodId == -1l || hmMethodTraces.containsKey(strParentMethodId) ){
						alRootNodes.add(joMethodTrace);
					}
				}

				i++;
			}
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		} catch (Exception ex) {
			System.out.println("ex: "+ex.getLocalizedMessage());
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(psProfilerMethodsTrace);
			psProfilerMethodsTrace = null;
		}
		
		// System.out.println("joRootMethod: "+hmMethodTraces.get(strRootMethodId));
		// return jaMethodsTrace; // for normal table; with --- as child mark.
		return alRootNodes;
	}
	
	/**
	 * gets profiler top 10 time taken methods
	 * 
	 * @param con
	 * @param strGUID
	 * @param strLocalNameIP
	 * @param strTransactionName
	 * @param strTimeStamp
	 * @param strDuration
	 * @param strCounterTypeName
	 * @return
	 * @throws Exception
	 */
	public JSONArray getProfilerTimeTakenMethods(Connection con, String strGUID, String strLocalNameIP, String strTransactionType, String strTransactionName, String strTimeStamp, String strDuration, String strCounterTypeName) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		/*
		 * JSONArray jaMethodsTrace = new JSONArray(), jaChildMethods = null;
		 * JSONObject joMethodTrace = null, joParentMethod = null;
		 */
		
		//ArrayList<LinkedHashMap<String, Object>> alTimeTakenMethods = new ArrayList<LinkedHashMap<String, Object>>();
		//LinkedHashMap<String, Object> lhmTimeTakenMethod = null;
		
		
		JSONObject joTimetakenMethod = null;
		JSONArray jaTimetakenMethods = new JSONArray();
		
		
		String strQuery = "";
		
		try {
			if(strCounterTypeName.equals("MSIIS")) {
				strQuery = "SELECT * FROM get_dnp_transaction_top_time_taken_methods(?, ?, ?::text, ?, ?) ";
				
				pstmt = con.prepareStatement(strQuery);
				pstmt.setString(1, strGUID);
				pstmt.setString(2, strLocalNameIP);
				pstmt.setString(3, strTransactionName);
				pstmt.setString(4, strTimeStamp);
				pstmt.setInt(5, Integer.parseInt(strDuration));
			} else {
				strQuery = "SELECT * FROM get_jp_transaction_top_time_taken_methods(?, ?, ?, ?::text, ?, ?) ";
				
				pstmt = con.prepareStatement(strQuery);
				pstmt.setString(1, strGUID);
				pstmt.setString(2, strLocalNameIP);
				pstmt.setString(3, strTransactionType);
				pstmt.setString(4, strTransactionName);
				pstmt.setString(5, strTimeStamp);
				pstmt.setInt(6, Integer.parseInt(strDuration));
			}
			
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joTimetakenMethod = new JSONObject();
				joTimetakenMethod.put("duration", rst.getInt("duration_ms"));
				joTimetakenMethod.put("methodName", rst.getString("class_name")+"."+rst.getString("method_name"));
				joTimetakenMethod.put("query", rst.getString("query"));
				joTimetakenMethod.put("exception_type", rst.getString("exception_type"));
				joTimetakenMethod.put("exception_message", rst.getString("exception_message"));
				joTimetakenMethod.put("exception_stacktrace", rst.getString("exception_stacktrace"));
				
				jaTimetakenMethods.add(joTimetakenMethod);
			}
			
		} catch (Exception ex) {
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( strQuery );
			strQuery = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaTimetakenMethods;
	}
	
	/**
	 * Gets expensive queries
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getExpensiveQueries(Connection con, String strGUID, String strFromStartInterval) throws Exception {
		PreparedStatement psProfilerTransactionTree = null;
		ResultSet rst = null;

		JSONArray jaExpensiveQueries = new JSONArray();
		JSONObject joExpensiveQuery = null;

		try {
			psProfilerTransactionTree = con.prepareStatement("select * from get_expensive_queries(?, ?)");
			psProfilerTransactionTree.setString(1, strGUID);
			psProfilerTransactionTree.setString(2, strFromStartInterval);
			rst = psProfilerTransactionTree.executeQuery();
			while (rst.next()) {
				joExpensiveQuery = new JSONObject();
				joExpensiveQuery.put("query", rst.getString("query"));
				joExpensiveQuery.put("count", rst.getString("cnt"));
				joExpensiveQuery.put("avg_duration", rst.getFloat("avg_duration_ms"));

				jaExpensiveQueries.add(joExpensiveQuery);
			}

		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(psProfilerTransactionTree);
			psProfilerTransactionTree = null;
		}

		return jaExpensiveQueries;
	}

	/**
	 * Gets dashboard's chart data for the application
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public JSONObject getDashboardAvgRequestAndResponse(Connection con, String strGUID) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		ArrayList<Long> alDataRequest = null;
		ArrayList<ArrayList> alRequests = new ArrayList<ArrayList>();

		ArrayList alDataResponse = null;
		ArrayList<ArrayList> alResponses = new ArrayList<ArrayList>();

		JSONObject joResult = new JSONObject();

		try {
			sbQuery.append("SELECT * FROM get_avg_reqres_timeline_for_dashboard_chart('").append(strGUID).append("') ");

			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while (rst.next()) {
				// request
				alDataRequest = new ArrayList<Long>(2);
				alDataRequest.add(rst.getTimestamp("start_time").getTime());
				alDataRequest.add(rst.getLong("no_of_hits"));

				alRequests.add(alDataRequest);

				// response
				alDataResponse = new ArrayList<Long>(2);
				alDataResponse.add(rst.getTimestamp("start_time").getTime());
				alDataResponse.add(rst.getLong("duration_ms"));

				alResponses.add(alDataResponse);
			}

			joResult.put("requests", alRequests);
			joResult.put("responses", alResponses);
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			//UtilsFactory.clearCollectionHieracy( alDataRequest );
			//UtilsFactory.clearCollectionHieracy( alRequests );
			//UtilsFactory.clearCollectionHieracy( alDataResponse );
			//UtilsFactory.clearCollectionHieracy( alResponses );
		}

		return joResult;
	}

	/**
	 * Gets dashboard's widget data
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public JSONObject getDashboardWidget(Connection con, String strGUID) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONObject joWidget = new JSONObject();

		try {
			sbQuery.append("SELECT * FROM get_reqres_avg_for_dashboard_widget('").append(strGUID).append("') ");

			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			if (rst.next()) {
				joWidget.put("noOfHits", rst.getString("no_of_hits"));
				joWidget.put("avgDuration", rst.getString("avg_duration_ms"));
			}

			UtilsFactory.clearCollectionHieracy( sbQuery );
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
		}

		return joWidget;
	}
	
	/**
	 * gets counter ids for the given template ids from counter_master_<uid>
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounterTemplateIds
	 * @return
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getCounterIds(Connection con, String strGUID, String strCounterTemplateIds) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		
		//LinkedHashMap<String, String> lhmCounters = new LinkedHashMap<String, String>(saCounterTemplateIds.length), lhmMapCounterKeys = new LinkedHashMap<String, String>(saCounterTemplateIds.length);
		LinkedHashMap<String, String> lhmCounters = new LinkedHashMap<String, String>();
		
		StringBuilder sbQuery = new StringBuilder();
		
		ModuleDBI moduleDBI = null;
		
		long lUID = -1L;
		
		try {
			moduleDBI = new ModuleDBI();
			
			// gets counter_ids from user's master table
			lUID = moduleDBI.getUID(con, strGUID);
			
			sbQuery	.append("SELECT counter_id, counter_template_id ")
					.append("FROM counter_master_").append(lUID).append(" ")
					.append("WHERE counter_template_id IN (").append(strCounterTemplateIds).append(") ")
					.append(" AND is_selected = true ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				lhmCounters.put(rst.getString("counter_template_id"), rst.getString("counter_id"));
			}
			
			moduleDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			LogManager.infoLog(sbQuery.toString());
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return lhmCounters;
	}
	
	/**
	 * gets primary counters data to show in dashboard
	 * 
	 * @param stmt
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public ResultSet getPrimaryCounters(Statement stmt, long lUID) throws Exception {
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		// TODO : need to get is above threshold here
		try {
			sbQuery	.append("SELECT counter_id, counter_template_id, category, counter_name, display_name, ")
					.append("  show_in_primary, show_in_secondary, unit, show_in_dashboard, threshold_sla_id, counter_description, is_above_threshold ")
					.append("FROM counter_master_").append(lUID).append(" ")
					.append("WHERE show_in_primary = true ")
					.append("ORDER BY category,counter_template_id ");
			// TODO: thinks ask for  is_enabled = true		
			rst = stmt.executeQuery(sbQuery.toString());
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			LogManager.infoLog(sbQuery.toString());
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return rst;
	}

	public ResultSet getPrimaryCountersForAllDetailsPage(Statement stmt, long lUID, boolean bShowPrimaryGraphs) throws Exception {
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
// TODO : is above threshold		
		try {
			sbQuery	.append("SELECT counter_id, counter_template_id, category, counter_name, display_name, show_in_primary, show_in_secondary, unit, show_in_dashboard, counter_description, is_above_threshold ")
					.append("FROM counter_master_").append(lUID).append(" ")
					.append("WHERE show_in_dashboard = true ");
			if ( bShowPrimaryGraphs ) {
				sbQuery.append(" OR show_in_primary = true ");
			}
			sbQuery	.append("ORDER BY counter_template_id ");
			// TODO: thinks ask for  is_enabled = true 
			
			rst = stmt.executeQuery(sbQuery.toString());
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			LogManager.infoLog(sbQuery.toString());
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return rst;
	}
	
	/**
	 * Get all the Counters summary for the selected counters under given GUID.
	 * 
	 * @param con
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSelectedCounterSummary(Connection con, long lUID, String strAgentVersion) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaCounterSummaries = new JSONArray();
		JSONObject joCounterSummary = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bMiniChartCounter = false;
		
		try {
			sbQuery	.append("SELECT counter_id, counter_template_id, category, display_name, unit, counter_name, ")
					.append("  show_in_primary, show_in_secondary, show_in_dashboard, counter_description, is_above_threshold, ")
					.append("  is_static_counter, max_value_counter_id ")
					.append("FROM counter_master_").append(lUID).append(" ")
					.append("WHERE is_selected = true ")
					.append("ORDER BY show_in_primary DESC, show_in_secondary DESC, category, counter_name ");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joCounterSummary = new JSONObject();
				joCounterSummary.put("counter_id", rst.getLong("counter_id"));
				//joCounterSummary.put("counter_template_id", rst.getLong("counter_template_id"));
				joCounterSummary.put("category", rst.getString("category"));
				joCounterSummary.put("counter_name", rst.getString("counter_name"));
				joCounterSummary.put("display_name", rst.getString("display_name"));
				joCounterSummary.put("counter", rst.getString("counter_name").replaceAll("[!@#$%^&*]", ""));
				joCounterSummary.put("unit", rst.getString("unit"));
				joCounterSummary.put("show_in_dashboard", rst.getBoolean("show_in_dashboard"));
				joCounterSummary.put("counter_description", rst.getString("counter_description"));
				joCounterSummary.put("is_above_threshold", rst.getBoolean("is_above_threshold"));
				joCounterSummary.put("is_static_counter", rst.getBoolean("is_static_counter"));
				joCounterSummary.put("max_value_counter_id", rst.getInt("max_value_counter_id") != 0 ? rst.getInt("max_value_counter_id") : null);
				
				bMiniChartCounter = UtilsFactory.contains(Constants.MINICHART_COUNTERS.get(strAgentVersion), rst.getString("counter_template_id"));
				joCounterSummary.put("is_mandatory", rst.getBoolean("show_in_primary") || rst.getBoolean("show_in_secondary") || bMiniChartCounter);
				//joCounterSummary.put("yaxis_category","avg");
				jaCounterSummaries.add(joCounterSummary);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaCounterSummaries;
	}

	public long updateChartStausForDashboard(Connection con, long lUID, String nCounterId, Boolean status) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lChartId = -1;
		
		try {
			
			sbQuery.append("UPDATE counter_master_").append(lUID).append(" ")
			.append("SET show_in_dashboard = ").append(status).append(" ")
			.append("WHERE counter_id = ").append(nCounterId);

			pstmt = con.prepareStatement(sbQuery.toString());
			
			lChartId = pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
		
		return lChartId;
	}
	

	
	public long createApmKeyTransaction(Connection con,String strGUID,long lUID,String uri,String keyTransactionId,String keyTransactionName,String keyTransactionDescription,long userId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lKeyId = -1;
		try {
			sbQuery.setLength(0);
			sbQuery.append("INSERT INTO profiler_key_transactions (user_id, uid, guid, uri, key_name, description ) VALUES (?,?,?,?,?,?)");
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, userId);
			pstmt.setLong(2, lUID);
			pstmt.setString(3, strGUID);
			pstmt.setString(4, uri);
			pstmt.setString(5, keyTransactionName);
			pstmt.setString(6, keyTransactionDescription);
			pstmt.executeUpdate();
			lKeyId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
		return lKeyId;
	}
	
	public long updateApmKeyTransaction(Connection con,String keyTransactionId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lKeyId = -1;
		try {
			sbQuery.setLength(0);
			sbQuery.append("DELETE FROM profiler_key_transactions WHERE id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, Integer.parseInt(keyTransactionId));
			lKeyId = pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
		
		return lKeyId;
	}
	
	public boolean checkKeyNameWithUserExists(Connection con,String keyTransactionName, long userId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		boolean status = false;
		try {
			sbQuery.setLength(0);
			sbQuery	.append("SELECT * from profiler_key_transactions where user_id =")
			.append(userId).append(" ")
			.append("AND key_name ='").append(keyTransactionName).append("'");
	
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if(rst.next()){
				status = true;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			rst = null;
			sbQuery = null;
		}
		return status;
	}
	
	public long getTotalCounterDataBetweenTime(Connection con, long lUId, String strCounterIds, long lFromTimestamp, long lToTimestamp) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lTotalCount = 0;
		
		try {
			sbQuery	.append("SELECT count(*) AS total_data_between_time ")
					.append("FROM collector_").append(lUId).append(" AS apc ")
					.append("WHERE apc.counter_type IN (").append(strCounterIds).append(") ")
					.append("AND apc.appedo_received_on >= to_timestamp(").append(lFromTimestamp/1000).append(") ")
					.append("AND apc.appedo_received_on <= to_timestamp(").append(lToTimestamp/1000).append(") ");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			if (rst.next()) {
				lTotalCount = rst.getLong("total_data_between_time");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lTotalCount;
	}
	
	public ResultSet getCounterDataBetweenTime(Statement stmt, long lUId, String strCounterIds, long lFromTimestamp, long lToTimestamp) throws Exception {
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT extract(epoch from apc.appedo_received_on) * 1000 AS T, apc.counter_value AS V ")
					.append("FROM collector_").append(lUId).append(" AS apc ")
					.append("WHERE apc.counter_type IN (").append(strCounterIds).append(") ")
					.append("AND apc.appedo_received_on >= to_timestamp(").append(lFromTimestamp/1000).append(") ")
					.append("AND apc.appedo_received_on <= to_timestamp(").append(lToTimestamp/1000).append(") ")
					.append("ORDER BY apc.appedo_received_on ASC ");
			
			rst = stmt.executeQuery(sbQuery.toString());
		} catch (Exception e) {
			throw e;
		}
		
		return rst;
	}
	
	public ArrayList<HashMap<String, String>> getPrimaryCountersWithTemplateDetails(Connection con, long lUId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		ArrayList<HashMap<String, String>> alPrimaryCounters = null;
		HashMap<String, String> hmPrimaryCounter = null;
		
		try {
			alPrimaryCounters = new ArrayList<HashMap<String, String>>();
			
			/*
			 * TODO: ct.module_name is not available in counter_master_<uid> table, ADD respective cols in counter_master_<uid> are not present in counter_template,
			 *   thinks, if cols added can avoid below JOIN with `counter_template` 
			 */
			sbQuery	.append("SELECT cm.counter_id, cm.counter_template_id, cm.category, cm.counter_name, cm.display_name, ")  
					.append("  cm.warning_threshold_value, cm.critical_threshold_value, cm.is_percentage, cm.is_above_threshold, ")
					.append("  ct.module_name ")
					.append("FROM counter_master_").append(lUId).append(" cm ")
					.append("INNER JOIN counter_template ct ON ct.counter_template_id = cm.counter_template_id ")
					.append("  AND cm.show_in_primary IS TRUE ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				hmPrimaryCounter = new HashMap<String, String>();
				hmPrimaryCounter.put("counterId", rst.getString("counter_id"));
				hmPrimaryCounter.put("counterTemplateId", rst.getString("counter_template_id"));
				hmPrimaryCounter.put("category", rst.getString("category"));
				hmPrimaryCounter.put("counterName", rst.getString("counter_name"));
				hmPrimaryCounter.put("displayName", rst.getString("display_name"));
				hmPrimaryCounter.put("warning_threshold_value", rst.getString("warning_threshold_value"));
				hmPrimaryCounter.put("critical_threshold_value", rst.getString("critical_threshold_value"));
				hmPrimaryCounter.put("isPercentage", rst.getBoolean("is_percentage")+"");
				hmPrimaryCounter.put("isAboveThreshold", rst.getBoolean("is_above_threshold")+"");
				hmPrimaryCounter.put("moduleCode", rst.getString("module_name"));
				
				alPrimaryCounters.add(hmPrimaryCounter);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return alPrimaryCounters;
	}
	
	/**
	 * update sla_id in counter_master_<uid> autogenerated counters mapped with SLAs 
	 * 
	 * @param con
	 * @param lUId
	 * @param strQryCountersWithSLAIds
	 * @throws Exception
	 */
	public void updateMappedSLAIdsWithCounters(Connection con, long lUId, String strQryCountersWithSLAIds) throws Exception {
		PreparedStatement pstmt = null;

		StringBuilder sbQuery = new StringBuilder();
		
		try {
			/* sample qry tried
			UPDATE counter_master_889 cm SET 
			  threshold_sla_id = counter_with_sla_id.sla_id
		  	FROM (
  			  SELECT 100007 AS counter_id, 1 AS sla_id
  			  UNION 
  			  SELECT 100008 AS counter_id, 2 AS sla_id
  			) AS counter_with_sla_id
  			WHERE cm.counter_id = counter_with_sla_id.counter_id
  			*/
			sbQuery	.append("UPDATE counter_master_").append(lUId).append(" cm SET ")
					.append("  threshold_sla_id = counter_with_sla_id.sla_id ")
					.append("FROM ( ").append(strQryCountersWithSLAIds).append(") AS counter_with_sla_id ")
					.append("WHERE cm.counter_id = counter_with_sla_id.counter_id ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	public JSONArray getCSVChartdata(Connection con, long lUID, long lCounterId, String strInterval) throws Exception {
		
		StringBuilder sbQuery = new StringBuilder();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jaData = new JSONArray();
		JSONObject joData = null;
		Date dateLog = LogManager.logMethodStart();
		try {
			sbQuery.append("SELECT received_on, counter_value FROM collector_").append(lUID)
					.append("  WHERE appedo_received_on >= (now() - interval '").append(strInterval).append("') AND counter_type = ").append(lCounterId)
					.append(" ORDER BY received_on DESC");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				joData = new JSONObject();
				joData.put("received_on", rs.getTimestamp("received_on").getTime());
				joData.put("counter_value", rs.getFloat("counter_value"));
				
				jaData.add(joData);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaData;
	}
	
	public JSONArray getCSVChartdataWithDateRange(Connection con, long lUID, long lCounterId, String strStartTime, String strEndTime) throws Exception {
		
		StringBuilder sbQuery = new StringBuilder();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jaData = new JSONArray();
		JSONObject joData = null;
		Date dateLog = LogManager.logMethodStart();
		try {
			sbQuery.append("SELECT received_on, counter_value FROM collector_")
					.append(lUID)
					.append("  WHERE appedo_received_on::timestamp BETWEEN to_timestamp(")
					.append(Long.parseLong(strStartTime))
					.append("/1000)::timestamp AND to_timestamp(")
					.append(Long.parseLong(strEndTime))
					.append("/1000)::timestamp AND counter_type = ")
					.append(lCounterId)
					.append(" ORDER BY received_on DESC");
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				joData = new JSONObject();
				joData.put("received_on", rs.getTimestamp("received_on").getTime());
				joData.put("counter_value", rs.getFloat("counter_value"));
				
				jaData.add(joData);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaData;
	}

	public JSONObject getCounterUnits(Connection con, long lUID, long lCounterId) throws Exception {
		
		StringBuilder sbQuery = new StringBuilder();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONObject joData = new JSONObject();
		
		Date dateLog = LogManager.logMethodStart();
		try {
			sbQuery.append("SELECT module_code, module_name, unit FROM module_master mm ")
					.append("INNER JOIN counter_master_")
					.append(lUID)
					.append("  cmd ON cmd.user_id = mm.user_id AND  counter_id = ")
					.append(lCounterId)
					.append("AND uid = ")
					.append(lUID);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				joData.put("module_code", rs.getString("module_code"));
				joData.put("module_name", rs.getString("module_name"));
				joData.put("units", rs.getString("unit"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return joData;
	}
	
	public String getTopProcess(Connection con, String strUID, String strCounterId, String strCategory,String strSliderValue,String selectedTime) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject jsonObj = null;
		JSONArray jsonArr = new JSONArray();
		
		String strQuery = "";
		boolean bBreakCounterSet = false;
		String strDateTimeTruncBy ="";
		
		try {
			if ( strSliderValue.equals("1 hour") ) {
				bBreakCounterSet = true;
			}
			
			if( bBreakCounterSet ) {
				// for Last 1 hour
				strDateTimeTruncBy = "minute"; 
			} else {
				// for other than Last 1 hour
				strDateTimeTruncBy = "hour";
			}
			
			strQuery = "Select * from get_top_process(?,?,?,?,?,?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1, Integer.parseInt(strUID));
			pstmt.setInt(2, Integer.parseInt(strCounterId));
			pstmt.setLong(3, Long.parseLong(selectedTime));
			pstmt.setString(4, strDateTimeTruncBy);
			pstmt.setInt(5, Constants.TOP_PROCESS_LIMIT);
			pstmt.setString(6, strCategory);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				jsonObj = new JSONObject();
				jsonObj.put("processName", rst.getString("process_name"));
				jsonObj.put("processValue", rst.getString("process_value"));
				
				jsonArr.add(jsonObj);
			}
			jsonObj = new JSONObject();
			jsonObj.put("topProcessDetails", jsonArr);
			jsonObj.put("topProcessLimit", Constants.TOP_PROCESS_LIMIT);
			
		} catch (Exception ex) {
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( strQuery );
			strQuery = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jsonObj.toString();
	}
	
	/**
	 * Get the Counter's details for the given array of Counter-Template-Ids
	 * 
	 * @param con
	 * @param sbCounterTemplateIds
	 * @return
	 * @throws Throwable
	 */
	public HashMap<String, HashMap<String, String> > getCounterTemplateDetails(Connection con, StringBuilder sbCounterTemplateIds) throws Throwable {
		StringBuilder sbQuery = new StringBuilder();
		
		Statement stmt = null;
		ResultSet rst = null;
		HashMap<String, HashMap<String, String> > hmCounters = new HashMap<String, HashMap<String, String> >();
		HashMap<String, String> hmCounter = null;
		
		Date dateLog = LogManager.logMethodStart();
		try {
			sbQuery	.append("SELECT counter_template_id, ct.category, ct.counter_name, ct.display_name, ct.unit ")
					.append("FROM counter_template ct ")
					.append("WHERE counter_template_id IN (").append(sbCounterTemplateIds).append(")");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while( rst.next() ) {
				hmCounter = new HashMap<String, String>();
				hmCounter.put("counter_template_id", rst.getString("counter_template_id"));
				hmCounter.put("category", rst.getString("category"));
				hmCounter.put("counter_name", rst.getString("counter_name"));
				hmCounter.put("display_name", rst.getString("display_name"));
				hmCounter.put("unit", rst.getString("unit"));
				
				hmCounters.put(hmCounter.get("counter_template_id"), hmCounter);
			}
		} catch (Throwable th) {
			LogManager.errorLog(th, sbQuery);
			throw th;
		} finally {
		    LogManager.logMethodEnd(dateLog);
		}
		
		return hmCounters;
	}
	
	/**
	 * gets counter master details 
	 * 
	 * @param con
	 * @param lUId
	 * @param strCounterId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getCounterDetails(Connection con, long lUId, String strCounterId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joCounterDetails = null;
		
		try {
			sbQuery	.append("SELECT category, display_name, unit FROM counter_master_").append(lUId).append(" WHERE counter_id = ").append(strCounterId);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				joCounterDetails = new JSONObject();
				joCounterDetails.put("category", rst.getString("category"));
				joCounterDetails.put("display_name", rst.getString("display_name"));
				joCounterDetails.put("unit", rst.getString("unit"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joCounterDetails;
	}
}
