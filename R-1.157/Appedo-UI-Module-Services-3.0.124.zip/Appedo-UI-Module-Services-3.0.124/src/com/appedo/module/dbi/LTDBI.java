package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.LTLicenseBean;
import com.appedo.module.bean.LoadTestSchedulerBean;
import com.appedo.module.bean.SummaryReportNotesBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class LTDBI {

	/**
	 * Gets SUM tests done
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param strTestType 
	 * @return
	 * @throws Exception
	 */
	public JSONArray getVUScripts(Connection con, LoginUserBean loginUserBean, String strTestType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";

		JSONArray jaScripts = new JSONArray();
		JSONObject joScript = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			strQuery = "SELECT * FROM lt_script_master WHERE user_id = ? AND script_type = ?";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, strTestType);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joScript = new JSONObject();
				
				joScript.put("scriptName", rst.getString("script_name"));
				joScript.put("created_by", loginUserBean.getFirstName());
				joScript.put("created_on", rst.getTimestamp("created_on").getTime());
				joScript.put("type", strTestType);
				joScript.put("script_id", rst.getLong("script_id"));
				
				joScript.put("status", getScriptStatus(con, rst.getLong("script_id")));
				jaScripts.add(joScript);
				
				joScript = null;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			joScript = null;
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaScripts;
	}
	
	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param strTestType
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLTScripts(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";

		JSONArray jaScripts = new JSONArray();
		JSONObject joScript = null;
		JSONObject joVariable = null;
		JSONObject joCol_Value = null;

		Date dateLog = LogManager.logMethodStart();

		try {
			strQuery = "SELECT * FROM lt_script_master WHERE user_id = ? /* AND script_type = ? */ ORDER BY script_name";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joScript = new JSONObject();
				
				joScript.put("scriptName", rst.getString("script_name"));
				joScript.put("created_by", loginUserBean.getFirstName());
				joScript.put("created_on", rst.getTimestamp("created_on").getTime());
				joScript.put("script_type", rst.getString("script_type"));
				joScript.put("script_id", rst.getLong("script_id"));
				
				joScript.put("status", getScriptStatus(con, rst.getLong("script_id")));
				jaScripts.add(joScript);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			joScript = null;
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaScripts;
	}
	
/**
 * 	
 * @param con
 * @param scriptId
 * @param userId
 * @return
 * @throws Exception
 */
	public HashMap<Integer, String> getScenarioNames(Connection con, long scriptId, long userId) throws Exception {
		HashMap<Integer, String> hmScenarioNames = null;
		String scenarioName = null;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		boolean isFirst = true;
		int mappingScenarios = 0;
		Date dateLog = LogManager.logMethodStart();

		try {
			hmScenarioNames = new HashMap<Integer, String>();
			sbQuery .append("SELECT scenario_name FROM lt_scenario_master sm LEFT JOIN lt_scenario_script_mapping ssm ON ")
					.append("sm.scenario_id = ssm.scenario_id AND sm.user_id = ssm.created_by WHERE ssm.script_id = ? AND ssm.created_by = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, scriptId);
			pstmt.setLong(2, userId);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				mappingScenarios++;
				if(isFirst){
					scenarioName = rst.getString("scenario_name");
					isFirst = false;
				} else {
					scenarioName = scenarioName + ", " + rst.getString("scenario_name");	
				}
			}
			if( scenarioName != null){
				hmScenarioNames.put(mappingScenarios, scenarioName);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			scenarioName = null;
			LogManager.logMethodEnd(dateLog);
		}
		return hmScenarioNames;
	}
	
	public String getScriptStatus(Connection con, long scriptId) throws Exception {
		String status = "";
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery .append("SELECT is_completed FROM scriptwise_status WHERE script_id = ? ORDER BY runid DESC LIMIT 1");
	
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, scriptId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				if( rst.getInt("is_completed") == 0 ){
					status = "RUNNING";
				} else {
					status = "COMPLETED";
				}
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return status;
	}
	
	public JSONArray getVUScenarios(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";

		JSONArray jaScenarios = new JSONArray();
		JSONObject joScenario = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			strQuery = "SELECT * FROM lt_scenario_master WHERE user_id = ? /* AND scenario_type = ? */ ORDER BY scenario_name";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joScenario = new JSONObject();
				joScenario.put("scenarioName", rst.getString("scenario_name"));
				joScenario.put("created_by", loginUserBean.getFirstName());
				joScenario.put("created_on", rst.getTimestamp("created_on").getTime());
				joScenario.put("scenario_type",  rst.getString("scenario_type"));
				joScenario.put("virtual_users", rst.getLong("v_users"));
				joScenario.put("scenario_id", rst.getLong("scenario_id"));
				
				jaScenarios.add(joScenario);
				
				joScenario = null;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			joScenario = null;
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaScenarios;
	}
	
	public long getMappedScripts(Connection con, long scenarioId, long userId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		long mappedScripts = 0;
		String strQuery = "";
		Date dateLog = LogManager.logMethodStart();

		try {
			strQuery = "SELECT count(*) AS mappedScenarios FROM lt_scenario_script_mapping WHERE scenario_id = ? AND created_by = ?";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, scenarioId);
			pstmt.setLong(2, userId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				mappedScripts = rst.getLong("mappedScenarios");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return mappedScripts;
	}
	
	public JSONObject getScenarioRunStatus(Connection con, long scenarioId, long userId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject hmScenarioStatus = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery .append("SELECT runid, is_active, status, grafana_report_url FROM tblreportmaster WHERE scenario_id = ? AND userid = ? ORDER BY runid DESC LIMIT 1");
	
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, scenarioId);
			pstmt.setLong(2, userId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				hmScenarioStatus = new JSONObject();
				hmScenarioStatus.put("runid", rst.getLong("runid"));
				hmScenarioStatus.put("is_active", rst.getBoolean("is_active"));
				if( rst.getString("status") != null ){
					hmScenarioStatus.put("status", rst.getString("status"));
				} else {
					hmScenarioStatus.put("status", "QUEUED");
				}
				hmScenarioStatus.put("grafana_report_url", rst.getString("grafana_report_url"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return hmScenarioStatus;
	}
	
	/**
	 * gets total_runs and total_runs_completed for the scenario
	 * 
	 * @param con
	 * @param lScenarioId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Long> getScenarioRuns(Connection con, long lScenarioId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		HashMap<String, Long> hmScenarioRuns = new HashMap<String, Long>();
		
		Date dateLog = LogManager.logMethodStart();
		
		try {
			sbQuery	.append("SELECT count(runid) AS total_runs, ")
					.append("  count(CASE WHEN status IN (").append(Constants.getLTStausStringForCompletedRuns()).append(") THEN 1 ELSE NULL END) AS total_runs_completed ")
					.append("FROM tblreportmaster ")
					.append("WHERE scenario_id = ? ")
					.append("  AND userid = ? ")
					.append("  AND is_active = FALSE ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lScenarioId);
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				hmScenarioRuns.put("total_runs", rst.getLong("total_runs"));
				hmScenarioRuns.put("total_runs_completed", rst.getLong("total_runs_completed"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
			
			LogManager.logMethodEnd(dateLog);
		}
		
		return hmScenarioRuns;
	}
	
	public JSONArray getRunningScriptData(Connection con, long runId) throws Exception{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rst = null;
		JSONArray jaRunningScripts = new JSONArray();
		JSONObject joScripts = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("select * from scriptwise_status where runid=?")
					.append(" ORDER BY script_name");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, runId);
			
			rst = pstmt.executeQuery();
			while(rst.next()){
				int err400 = 0, err500 = 0, errCnt = 0, totErr = 0;
				joScripts = new JSONObject();
				joScripts.put("scriptId", rst.getString("script_id"));
				joScripts.put("scriptName", rst.getString("script_name"));
				joScripts.put("createdUser", rst.getInt("created_users"));
				joScripts.put("completedUser", rst.getInt("completed_users"));
				joScripts.put("http200Status", rst.getInt("http_200_count"));
				joScripts.put("http300Status", rst.getInt("http_300_count"));
				err400 = rst.getInt("http_400_count");
				err500 = rst.getInt("http_500_count");
				errCnt = rst.getInt("error_count");
				totErr = errCnt - (err400 + err500);
				joScripts.put("http400Status", err400);
				joScripts.put("http500Status", err500);
				joScripts.put("httpOthStatus", totErr);
				joScripts.put("errorCount", errCnt);
				joScripts.put("iscompleted", rst.getInt("is_completed"));
				if( rst.getInt("is_completed") == 0 ){
					joScripts.put("status", "RUNNING");
				} else {
					joScripts.put("status", "COMPLETED");
				}
				
				jaRunningScripts.add(joScripts);
				joScripts = null;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jaRunningScripts;
	}
	
	/**
	 * gets user's load test type all reports OR scenario reports
	 *   lScenarioId IS NULL gets all reports OR the particular scenario reports
	 * 
	 * @param con
	 * @param lScenarioId
	 * @param strLoadTestType
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getScenarioReports(Connection con, Long lScenarioId, String strLoadTestType, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joReport = null;
		JSONArray jaReports = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
		
		Date dateLog = LogManager.logMethodStart();
		
		try {
			jaReports =  new JSONArray();
			
			sbQuery	.append("SELECT tr.reporttype, tr.runid, tr.reportname, tr.scenario_id, tr.scenarioname, tr.runstarttime, tr.runendtime, tr.status, ")
					.append("  coalesce(sum(ss.created_users), 0) AS createduser, coalesce(sum(ss.completed_users), 0) AS completeduser, tr.grafana_report_url, ")
					.append("  (CASE WHEN group_concat(lram.guid) IS NULL THEN '0' ELSE group_concat(lram.guid) END) AS guids ")
					.append("FROM tblreportmaster tr ")
					.append("LEFT JOIN scriptwise_status ss on ss.runid = tr.runid ")
					.append("LEFT JOIN lt_run_agent_mapping lram on lram.lt_run_id = tr.runid ")
					.append("WHERE tr.userid = ? AND tr.reporttype = ? ");
			if( lScenarioId != null ){
				sbQuery.append("  AND tr.scenario_id = ? ");
			}
			sbQuery	.append("  AND tr.is_deleted = FALSE AND tr.status <> '' ")
					.append("GROUP BY tr.runid, tr.reportname, tr.scenarioname, tr.runstarttime, tr.runendtime, tr.is_deleted, tr.reporttype, tr.grafana_report_url ")
					.append("ORDER BY runendtime DESC");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, strLoadTestType);
			if( lScenarioId != null ){
				pstmt.setLong(3, lScenarioId);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joReport = new JSONObject();
				joReport.put("testType", rst.getString("reporttype"));
				// TODO: ASK key `runid` AS `runid` to have
				// joReports.put("runid",rs.getString("runid"));
				joReport.put("reportId",rst.getString("runid"));
				joReport.put("reportName",rst.getString("reportname"));
				joReport.put("scenarioId",rst.getString("scenario_id"));
				joReport.put("scenarioName",rst.getString("scenarioname"));
				joReport.put("createdUser",rst.getString("createduser"));
				joReport.put("completedUser",rst.getString("completeduser"));
				joReport.put("runStartTime", rst.getTimestamp("runstarttime").getTime());
				joReport.put("runStartTimeString", sdf.format(rst.getTimestamp("runstarttime")));
				joReport.put("status", rst.getString("status"));
				joReport.put("grafanaReportURL", rst.getString("grafana_report_url"));
				joReport.put("guid", rst.getString("guids"));
				if( rst.getTimestamp("runendtime") != null ){
					joReport.put("runEndTime", rst.getTimestamp("runendtime").getTime());
					joReport.put("runEndTimeString", sdf.format(rst.getTimestamp("runendtime")));
					long runTime = rst.getTimestamp("runendtime").getTime() - rst.getTimestamp("runstarttime").getTime();
					joReport.put("runTime", runTime);
				} else {
					joReport.put("runEndTimeString", "");
					joReport.put("runEndTime", 0);
					joReport.put("runTime", 0);
				}
				
				jaReports.add(joReport);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sdf = null;
			
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return jaReports;
	}
	
	public JSONObject getRunDetails(Connection con, long runId, long userId, String strTestType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		JSONObject joRunDetail = null;
		long elapsedTime = 0;
		Date dateLog = LogManager.logMethodStart();

		try {
			strQuery = "SELECT * FROM tblreportmaster WHERE runid = ? AND userid = ? AND reporttype = ?";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, runId);
			pstmt.setLong(2, userId);
			pstmt.setString(3, strTestType);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				joRunDetail = new JSONObject();
				joRunDetail.put("scenarioName", rst.getString("scenarioname"));
				joRunDetail.put("reportName", rst.getString("reportname"));
				joRunDetail.put("runStartTime", rst.getTimestamp("runstarttime").getTime());
				
//				long lResDate = rst.getTimestamp("runstarttime").getTime();
//				long lReqDate = new Date().getTime();
//				long diff = lReqDate - lResDate;
//				long diffSeconds = (diff / 1000) % 60;
//				long diffMinutes = (diff / (60 * 1000)) % 60;
//				long diffHours = diff / (60 * 60 * 1000);
//				joRunDetail.put("elapsedtime", (diffHours<=9?"0"+diffHours:diffHours)+":"+(diffMinutes<=9?"0"+diffMinutes:diffMinutes)+":"+(diffSeconds<=9?"0"+diffSeconds:diffSeconds));
				if( rst.getTimestamp("runendtime") != null ){
					joRunDetail.put("runendtime", rst.getTimestamp("runendtime").getTime());
					elapsedTime = rst.getTimestamp("runendtime").getTime() - rst.getTimestamp("runstarttime").getTime();
					joRunDetail.put("elapsedtime", elapsedTime);
				} else {
					elapsedTime = System.currentTimeMillis() - rst.getTimestamp("runstarttime").getTime();
					joRunDetail.put("runendtime", 0);
					joRunDetail.put("elapsedtime", elapsedTime);
				}
				joRunDetail.put("grafanaReportURL", rst.getString("grafana_report_url"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joRunDetail;
	}
	
	public JSONObject getRunStatus(Connection con, long runId, JSONObject joRunDetails) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery .append("SELECT SUM(created_users) AS createdUser, SUM(completed_users) AS completedUser, ")
					.append("SUM(http_200_count) AS total_2XX, SUM(http_300_count) AS total_3XX, ")
					.append("SUM(http_400_count) AS total_4XX, SUM(http_500_count) AS total_5XX, ")
					.append("SUM(error_count) AS total_error ")
					.append("FROM scriptwise_status WHERE runid = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, runId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				joRunDetails.put("createdUser", rst.getLong("createdUser"));
				joRunDetails.put("completedUser", rst.getLong("completedUser"));
				joRunDetails.put("total_2XX", rst.getLong("total_2XX"));
				joRunDetails.put("total_3XX", rst.getLong("total_3XX"));
				joRunDetails.put("total_4XX", rst.getLong("total_4XX"));
				joRunDetails.put("total_5XX", rst.getLong("total_5XX"));
				joRunDetails.put("total_error", rst.getLong("total_error"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		return joRunDetails;
	}
	
	public String getUserRampUp(Connection con, long runId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();
		JSONObject userRampupObj = null;
		JSONArray userRampupArr = new JSONArray();
		int rampValue = 0;
		String outString = null;
		try {
			sbQuery .append("SELECT runtime, ")
					.append("SUM(CASE WHEN runtype=1 THEN 1 ELSE 0 END) as userRampUp, ")
					.append("SUM(CASE WHEN runtype=2 THEN 1 ELSE 0 END) as userRampDown, MAX(userid) as maxUsers ")
					.append("FROM lt_user_runtime_")
					.append(runId)
					.append(" GROUP BY runtime,runtype ORDER BY runtime");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				userRampupObj = new JSONObject();
				rampValue = rampValue + rst.getInt("userRampUp") - rst.getInt("userRampDown");
				userRampupObj.put("T", rst.getLong("runtime"));
				userRampupObj.put("V", rampValue <= rst.getInt("maxUsers") ? rampValue : rst.getInt("maxUsers"));
				userRampupObj.put("User Count", rampValue <= rst.getInt("maxUsers") ? rampValue : rst.getInt("maxUsers"));
				userRampupArr.add(userRampupObj);
			}
			outString = userRampupArr.toString();
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		return outString;
	}

	public String getRunChartDataForThroughputHitCounts(Connection con, long runId, String strInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();
		String outString = null;
		try {
			sbQuery .append("Select array_to_json(array_agg(row_to_json(jsoncontent))) as \"chartData\" from (")
					.append("SELECT (EXTRACT('epoch' FROM (date_trunc ('second', to_timestamp(endtime/1000) at time zone 'utc')))*1000) \"T\", ")
					.append("COUNT(reportdata_id) as  \"Total Hits\", ")
					.append("ROUND(avg(responsesize),0) \"Bps\" ")
					.append("FROM lt_reportdata_")
					.append(runId)
					.append(" WHERE date_trunc ('second', to_timestamp(endtime/1000) at time zone 'utc') >= (NOW() - interval '")
					.append(strInterval)
					.append("') GROUP BY 1 ORDER BY 1")
					.append(") jsoncontent");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if (rst.next()) {
				outString = rst.getString("chartData");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		return outString;
	}

	public JSONArray getLogReports(Connection con, long runId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joReports = null;
		JSONArray jaReports = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT * FROM lt_log_"+runId);
			
			jaReports =  new JSONArray();
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				joReports = new JSONObject();
				joReports.put("iteration_id", rs.getLong("iteration_id"));
				joReports.put("loadgen", rs.getString("loadgen"));
				joReports.put("log_id", rs.getLong("log_id"));
				joReports.put("log_name", rs.getString("log_name"));
				joReports.put("message",rs.getString("message"));
				joReports.put("log_time", rs.getLong("log_time"));
				joReports.put("user_id", rs.getLong("user_id"));
				joReports.put("scriptname", rs.getString("scriptname"));
				
				jaReports.add(joReports);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return jaReports;
	}
	
//	public JSONArray getErrorReports(Connection con, long runId) throws Exception {
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		StringBuilder sbQuery = new StringBuilder();
//		JSONObject joReports = null;
//		JSONArray jaReports = null;
//		
//		try {
//			sbQuery	.append("SELECT * FROM lt_error_"+runId);
//			
//			jaReports =  new JSONArray();
//			pstmt = con.prepareStatement(sbQuery.toString());
//			rs = pstmt.executeQuery();
//			while(rs.next())
//			{
//				joReports = new JSONObject();
//				joReports.put("iteration_id", rs.getLong("iteration_id"));
//				joReports.put("loadgen", rs.getString("loadgen"));
//				joReports.put("requestid", rs.getLong("requestid"));
//				joReports.put("errorcode", rs.getInt("errorcode"));
//				joReports.put("message",rs.getString("message"));
//				joReports.put("log_time", rs.getLong("log_time"));
//				joReports.put("user_id", rs.getLong("user_id"));
//				joReports.put("scriptname", rs.getString("scriptname"));
//				
//				jaReports.add(joReports);
//			}
//		} catch (Exception e) {
//			LogManager.errorLog(e);
//			throw e;
//		} finally {
//			DataBaseManager.close(rs);
//			rs = null;
//			DataBaseManager.close(pstmt);
//			pstmt = null;
//			UtilsFactory.clearCollectionHieracy(sbQuery);
//		}
		public JSONArray getErrorReports(Connection con, long runId) throws Exception {
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			StringBuilder sbQuery = new StringBuilder();
			JSONObject joReports = null;
			JSONArray jaReports = null;
			Date dateLog = LogManager.logMethodStart();

			try {
				sbQuery.append("select scriptid,scriptname,container_id,container_name,errorcode,message,count(lt_error_id) as \"errorCount\" from lt_error_");
				sbQuery.append(runId);
				sbQuery.append(" group by scriptid,scriptname,container_id,container_name,errorcode,message order by scriptid,scriptname,container_id,container_name,errorcode,message");
				jaReports =  new JSONArray();
				pstmt = con.prepareStatement(sbQuery.toString());
				rs = pstmt.executeQuery();
				while(rs.next())
				{
					joReports = new JSONObject();
					joReports.put("scriptid", rs.getLong("scriptid"));
					joReports.put("scriptname", rs.getString("scriptname"));
					joReports.put("container_id", rs.getLong("container_id"));
					joReports.put("container_name", rs.getString("container_name"));
					joReports.put("errorcode", rs.getInt("errorcode"));
					joReports.put("message",rs.getString("message"));
					joReports.put("errorCount", rs.getLong("errorCount"));
					jaReports.add(joReports);
				}
			} catch (Exception e) {
				LogManager.errorLog(e);
				throw e;
			} finally {
				DataBaseManager.close(rs);
				rs = null;
				DataBaseManager.close(pstmt);
				pstmt = null;
				UtilsFactory.clearCollectionHieracy(sbQuery);
				LogManager.logMethodEnd(dateLog);
			}
		
	 	return jaReports;
	}
	
	public JSONArray getRegions(Connection con, LoginUserBean loginUserBean, String strOSType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joRegion = null;
		JSONArray jaRegions = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			jaRegions =  new JSONArray();
			
			sbQuery	.append("SELECT * FROM lt_region_details ")
					.append("WHERE is_deleted = FALSE ")
					.append("  AND reservation <> total_availability ")
					.append("  AND os_type = '").append(strOSType).append("' ")
					.append("ORDER BY region ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				joRegion = new JSONObject();
				joRegion.put("lt_region_id",rs.getString("lt_region_id"));
				joRegion.put("instance_owner",rs.getString("instance_owner"));
				joRegion.put("region",rs.getString("region"));
				joRegion.put("location",rs.getBoolean("location"));
				joRegion.put("image_id",rs.getBoolean("image_id"));
				joRegion.put("is_deleted",rs.getBoolean("is_deleted"));
				if(rs.getBoolean("is_default")){
					joRegion.put("showRegion", true);
					joRegion.put("distribution", 100);
				}else{
					joRegion.put("showRegion", false);
					joRegion.put("distribution", 0);
				}
				if(loginUserBean.getLicense().equals("level0")){
					joRegion.put("license", true);
				}else{
					joRegion.put("license", false);
				}
				
				if(rs.getString("os_type").equals("FEDORA")){
					joRegion.put("showRadio", true);
				}else{
					joRegion.put("showRadio", false);
				}
				joRegion.put("userLicense", loginUserBean.getLicense());
				jaRegions.add(joRegion);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			joRegion = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	 	return jaRegions;
		
	}
	
	public JSONObject getReportDetails(Connection con, long runId) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joReportDetails = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT * FROM tblreportmaster WHERE runid = ").append(runId);
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			if ( rst.next() ) {
				joReportDetails = new JSONObject();
				joReportDetails.put("runid", rst.getString("runid"));
				joReportDetails.put("reportname", rst.getString("reportname")+" - "+rst.getString("runstarttime"));
				joReportDetails.put("reporttype", rst.getString("reporttype"));
				joReportDetails.put("scenarioname", rst.getString("scenarioname"));
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
		return joReportDetails;
	}
	
	public long insertScenarioName(Connection con, String scenarioName, String strTestType, LTLicenseBean ltLicBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmtSelect = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rst = null;
		boolean isExist = false; 
		
		long lScenarioId = -1L;
		Date dateLog = LogManager.logMethodStart();

		try {
			
			if(ltLicBean == null) {
				// License expired for user
				throw new Exception("2");
			} else {
				sbQuery.append("SELECT true FROM lt_scenario_master WHERE user_id = ? AND scenario_type = ? AND LOWER(scenario_name) = LOWER(?)");
				pstmtSelect = con.prepareStatement(sbQuery.toString());
				pstmtSelect.setLong(1, loginUserBean.getUserId());
				pstmtSelect.setString(2, strTestType);
				pstmtSelect.setString(3, scenarioName);
				rst = pstmtSelect.executeQuery();
				if( rst.next() ){
					throw new Exception("1");
				}
				
				if( !isExist ){
					sbQuery.setLength(0);
					sbQuery.append("INSERT INTO lt_scenario_master (user_id, enterprise_id, scenario_type, scenario_name, created_on) VALUES (?, ?, ?, ?, now())");
					
					pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
					
					pstmt.setLong(1, loginUserBean.getUserId());
					if( loginUserBean.getEnterpriseId() == 0 ) {
						pstmt.setNull(2, Types.BIGINT);
					} else {
						pstmt.setLong(2, loginUserBean.getEnterpriseId());	
					}
					pstmt.setString(3, strTestType);
					pstmt.setString(4, scenarioName);
					pstmt.executeUpdate();
					
					lScenarioId = DataBaseManager.returnKey(pstmt);
				}
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmtSelect);
			pstmtSelect = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
		return lScenarioId;
	}
	
	public void deleteMappingScripts(Connection con, long scenarioId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmtDelete = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			
			sbQuery	.append("DELETE FROM lt_scenario_script_mapping WHERE scenario_id = ? AND created_by = ? ");
			
			pstmtDelete = con.prepareStatement( sbQuery.toString() );
			pstmtDelete.setLong(1, scenarioId);
			pstmtDelete.setLong(2, loginUserBean.getUserId());
			pstmtDelete.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmtDelete);
			pstmtDelete = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public void insertMappingScripts(Connection con, long scenarioId, String strTestType, LoginUserBean loginUserBean, JSONArray scriptIds) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			
			sbQuery	.append("INSERT INTO lt_scenario_script_mapping (scenario_id, script_id, scenario_settings, created_by, created_on) VALUES (?, ?, ?, ?, now())");
			pstmt = con.prepareStatement(sbQuery.toString());
			for ( int i=0; i<scriptIds.size(); i++ ){
				JSONObject joObject = scriptIds.getJSONObject(i);
				pstmt.setLong(1, scenarioId);
				pstmt.setLong(2, Long.valueOf(joObject.getLong("script_id")));	
				if( strTestType.equalsIgnoreCase("APPEDO_LT") ){
					if( joObject.get("settings") != null){
						pstmt.setObject(3, UtilsFactory.getPgObject(joObject.getString("settings")));
					} else{
						pstmt.setObject(3, UtilsFactory.getPgObject("{\"browsercache\":\"false\", \"currentloadgenid\":\"1\", \"durationmode\":\"1\", \"durationtime\":\"0;0;0\", \"incrementtime\":\"0;0;0\", \"incrementuser\":\"1\", \"iterations\":\"1\", \"maxuser\":\"1\", \"startuser\":\"1\", \"startuserid\":\"0\", \"totalloadgen\":\"1\", \"type\":\"1\"}"));
					}
				} else {
					pstmt.setObject(3, UtilsFactory.getPgObject("{\"browsercache\":\"false\", \"currentloadgenid\":\"1\", \"durationtime\":\"0;1;0\", \"incrementtime\":\"0;0;1\", \"incrementuser\":\"1\", \"iterations\":\"1\", \"maxuser\":\"5\", \"startuser\":\"1\", \"startuserid\":\"0\", \"totalloadgen\":\"1\", \"type\":\"1\"}"));
				}
				pstmt.setLong(4, loginUserBean.getUserId());
				pstmt.addBatch();
			}
			
//			for ( String script:scriptIds.split(",")){
//				pstmt.setLong(1, scenarioId);
//				pstmt.setLong(2, Long.valueOf(script));	
//				if( strTestType.equalsIgnoreCase("APPEDO_LT") ){
//					pstmt.setObject(3, UtilsFactory.getPgObject("{\"browsercache\":\"false\", \"currentloadgenid\":\"1\", \"durationmode\":\"1\", \"durationtime\":\"0;0;0\", \"incrementtime\":\"0;0;0\", \"incrementuser\":\"1\", \"iterations\":\"1\", \"maxuser\":\"1\", \"startuser\":\"1\", \"startuserid\":\"0\", \"totalloadgen\":\"1\", \"type\":\"1\"}"));
//				} else {
//					pstmt.setObject(3, UtilsFactory.getPgObject("{\"browsercache\":\"false\", \"currentloadgenid\":\"1\", \"durationtime\":\"0;1;0\", \"incrementtime\":\"0;0;1\", \"incrementuser\":\"1\", \"iterations\":\"1\", \"maxuser\":\"5\", \"startuser\":\"1\", \"startuserid\":\"0\", \"totalloadgen\":\"1\", \"type\":\"1\"}"));
//				}
//				pstmt.setLong(4, loginUserBean.getUserId());
//				pstmt.addBatch();
//			}
			
			pstmt.executeBatch();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public JSONArray getScenarioDetails(Connection con, long scenarioId, String testTypeScript, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joReports = null;
		JSONArray jaReports = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT CASE WHEN ssm.scenario_id IS NULL THEN -1 ELSE ssm.scenario_id END AS scenarioId, ")
					.append("sm.script_id AS scriptId, sm.script_name AS scriptName, ssm.scenario_settings AS settings FROM lt_script_master sm ")
					.append("LEFT JOIN lt_scenario_script_mapping ssm ON sm.script_id = ssm.script_id ")
					.append("AND ssm.scenario_id = ? WHERE sm.user_id = ? AND sm.script_type = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, scenarioId);
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, testTypeScript);
			rs = pstmt.executeQuery();
			jaReports =  new JSONArray();

			while(rs.next())
			{
				joReports = new JSONObject();
				joReports.put("scenarioId", rs.getLong("scenarioId"));
				joReports.put("script_id", rs.getLong("scriptId"));
				joReports.put("scriptName",rs.getString("scriptName"));
				if( rs.getLong("scenarioId") > 0 ){
					joReports.put("isSelected", true);
					joReports.put("settings", rs.getString("settings"));
				}else {
					joReports.put("isSelected", false);
				}
				jaReports.add(joReports);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return jaReports;
	}
	
	public JSONObject getScenarioName(Connection con, long scenarioId, String testTypeScript, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joReports = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT * FROM lt_scenario_master WHERE scenario_id = ? AND user_id = ? AND scenario_type = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, scenarioId);
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, testTypeScript);
			rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				joReports = new JSONObject();
				joReports.put("scenario_id", rs.getLong("scenario_id"));
				joReports.put("user_id", rs.getLong("user_id"));
				joReports.put("enterprise_id", rs.getLong("enterprise_id"));
				joReports.put("scenario_type", rs.getString("scenario_type"));
				joReports.put("scenario_name",rs.getString("scenario_name"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return joReports;
	}
	
	public void updateScenarioName(Connection con, String scenarioName, String strTestType, long scenarioId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("UPDATE lt_scenario_master SET scenario_name = ? ")
					.append("WHERE user_id = ? AND scenario_id = ? AND scenario_type = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, scenarioName);
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setLong(3, scenarioId);
			pstmt.setString(4, strTestType);
			
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public void deleteScenarios(Connection con, long scenarioId, String strTestType, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmtDelete = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			
			sbQuery	.append("DELETE FROM lt_scenario_master WHERE scenario_id = ? AND user_id = ? AND scenario_type = ?");
			
			pstmtDelete = con.prepareStatement( sbQuery.toString() );
			pstmtDelete.setLong(1, scenarioId);
			pstmtDelete.setLong(2, loginUserBean.getUserId());
			pstmtDelete.setString(3, strTestType);
			pstmtDelete.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmtDelete);
			pstmtDelete = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public JSONArray mappingAgent(Connection con, LoginUserBean loginUserBean, String testTypeScript, String apmGroup, String scenarioId) throws Exception {
		PreparedStatement pstmt = null, stmt = null;
		ResultSet rs = null, rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joReports = null;
		JSONArray jaReports = null;
		Date dateLog = LogManager.logMethodStart();
		String status = "Inactive";

		try {
			sbQuery	.append("SELECT  mm.uid AS uid, mm.guid AS guid, mm.module_name AS module_name, mm.module_code AS module_code, ")
					.append("CASE WHEN lastrun.map_id IS NULL THEN -1 ELSE lastrun.map_id END AS map_id ")
					.append("FROM module_master mm ")
					.append("LEFT JOIN (")
					.append("SELECT map_id, guid FROM lt_run_agent_mapping ")
					.append("WHERE lt_run_id IN ( SELECT max(runid) FROM tblreportmaster WHERE scenario_id = ?) ")
					.append(")lastrun ON lastrun.guid = mm.guid ")
					.append("WHERE user_id = ? AND module_code = ? ")
					.append("ORDER BY module_code");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, Long.valueOf(scenarioId));
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, apmGroup);
			
			rs = pstmt.executeQuery();
			jaReports =  new JSONArray();

			while(rs.next())
			{
				sbQuery.setLength(0);
				sbQuery	.append("SELECT EXISTS(SELECT 1 FROM collector_")
						.append(rs.getLong("uid"))
						.append(" WHERE appedo_received_on >= now() - INTERVAL '1 min' LIMIT 1)");
				stmt = con.prepareStatement(sbQuery.toString());
				rst = stmt.executeQuery();
				if( rst.next() ){
					status = rst.getBoolean("exists") ? "Active" : "Inactive";
				}
				
				joReports = new JSONObject();
				joReports.put("guid", rs.getString("guid"));
				joReports.put("module_name", rs.getString("module_name"));
				joReports.put("module_name_status", rs.getString("module_name")+" (" +status+")");
				joReports.put("module_code",rs.getString("module_code"));
				if( rs.getLong("map_id") > 0 ){
					joReports.put("isSelected", true);
				}else {
					joReports.put("isSelected", false);
				}
				jaReports.add(joReports);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(rst);
			rs = null;
			DataBaseManager.close(stmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return jaReports;
	}

	public JSONArray getLTDashDonut(Connection con,long userid, String type,String runid) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		Date dateLog = LogManager.logMethodStart();

		try {
			String query = null;

			switch (type) {
			case "Error":
				query = "select (select count(errorcode) from lt_error_"+runid+" where errorcode > 399 and errorcode < 499) as http_400, (select count(errorcode) from lt_error_"+runid+" where errorcode > 499 and errorcode < 599) as http_500, count(errorcode) as others from lt_error_"+runid+" where errorcode > 599";
				pstmt = con.prepareStatement(query);
				rst = pstmt.executeQuery();
				while (rst.next()) {
					if (rst.getLong("http_400") > 0) {
						json = new JSONObject();
						json.put("label", "http 400");
						json.put("value", rst.getLong("http_400"));
						jsonArray.add(json);
					}
					if (rst.getLong("http_500") > 0) {
						json = new JSONObject();
						json.put("label", "http 500");
						json.put("value", rst.getLong("http_500"));
						jsonArray.add(json);
					}
					if (rst.getLong("others") > 0) {
						json = new JSONObject();
						json.put("label", "Others");
						json.put("value", rst.getLong("others"));
						jsonArray.add(json);
					}
				}
				break;
			case "Status":
				query = "select status,count(status) from tblreportmaster where userid = ? group by status";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, userid);
				rst = pstmt.executeQuery();
				Map<String,Long> labelVsValue = new HashMap<String,Long>();
				while(rst.next()) {
					if (rst.getLong("count") > 0) {
						String label = rst.getString("status").toLowerCase();
						
						if(label.equalsIgnoreCase("")){
							label = "Queued";
						}else if(label.equalsIgnoreCase("running")){
							label = "Running";
						}else if(label.equalsIgnoreCase("failed")){
							label = "Failed";
						}else{
							label = "Success";
						}
						if(labelVsValue.containsKey(label)){
							labelVsValue.put(label,labelVsValue.get(label)+ rst.getLong("count"));
						}else{
							labelVsValue.put(label,rst.getLong("count"));
						}
					}
				}
				for (Map.Entry<String,Long> childEntry : labelVsValue.entrySet()){
					json = new JSONObject();
					json.put("label", childEntry.getKey());
					json.put("value", childEntry.getValue());
					jsonArray.add(json);
				}
				break;
			case "Run":
				query = "select 'Max' as name, CASE WHEN license_level='level0' THEN u.lt_max_run_per_day ElSE (select SUM(ul.lt_max_run_per_day) from usermaster um, userwise_lic_monthwise ul where um.user_id=u.user_id and um.user_id=ul.user_id and start_date<=now() and end_date>=now() and module_type = 'LT') end AS max_runs from usermaster u inner join lt_config_parameters lcp on u.license_level = lcp.lt_license where user_id = ? union select 'Completed' as name,count(userid) from tblreportmaster where userid = ? and is_deleted = false and created_on::DATE = now()::DATE";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1,userid);
				pstmt.setLong(2,userid);
				rst = pstmt.executeQuery();
				Long total = 0l;
				Long used = 0l;
				while(rst.next()) {
					if(rst.getString("name").equalsIgnoreCase("Max")){
						total = rst.getLong("max_runs");
					}else{

						json = new JSONObject();
						used = rst.getLong("max_runs");
						json.put("label", rst.getString("name"));
						json.put("value", used);
						jsonArray.add(json);
					}
				}
				json = new JSONObject();
				json.put("label","Available");
				if((total-used)>0){
					json.put("value", total-used);
				}else{
					json.put("value", 0);
				}
				jsonArray.add(json);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			json = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonArray;

	}
	
	public JSONArray getScenarioSettings(Connection con, long userid, String type, long scenarioId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joReports = null;
		JSONArray jaReports = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT sm.script_name AS scriptName, lm.script_id AS scriptId, lm.scenario_settings AS settings FROM lt_scenario_script_mapping lm left join lt_script_master sm ")
					.append("ON sm.script_id = lm.script_id AND sm.user_id = lm.created_by AND sm.user_id = ? AND sm.script_type = ? ")
					.append("WHERE scenario_id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, userid);
			pstmt.setString(2, type);
			pstmt.setLong(3, scenarioId);
			rs = pstmt.executeQuery();
			jaReports = new JSONArray();
			while(rs.next())
			{
				joReports = new JSONObject();
				joReports.put("script_name", rs.getString("scriptName"));
				joReports.put("script_id", rs.getLong("scriptId"));
				joReports.put("scenario_settings", rs.getString("settings"));
				jaReports.add(joReports);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			joReports = null;
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return jaReports;
	}
	
	public void updateScenarioSettings(Connection con, LoginUserBean loginUserBean, String strTestType, String scenarioSettings, long scenarioId, String scriptIds) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("UPDATE lt_scenario_script_mapping SET scenario_settings = ? ")
					.append("WHERE created_by = ? AND scenario_id = ? AND script_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			for ( String script:scriptIds.split(",")){
				pstmt.setObject(1, UtilsFactory.getPgObject(scenarioSettings));
				pstmt.setLong(2, loginUserBean.getUserId());
				pstmt.setLong(3, scenarioId);	
				pstmt.setLong(4, Long.valueOf(script));
				pstmt.addBatch();
			}
			
			pstmt.executeBatch();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public void updateVuser(Connection con, LoginUserBean loginUserBean, String strTestType, long scenarioId) throws Exception {
		PreparedStatement pstmt = null, pstmtSelect = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rs = null;
		long vuserId = 0;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery .append("SELECT SUM((scenario_settings->>'maxuser')::bigint) AS vuser FROM lt_scenario_script_mapping ")
					.append("WHERE created_by = ? AND scenario_id = ?");
			pstmtSelect = con.prepareStatement(sbQuery.toString());
			pstmtSelect.setLong(1, loginUserBean.getUserId());
			pstmtSelect.setLong(2, scenarioId);
			rs = pstmtSelect.executeQuery();
			if(rs.next()){
				vuserId = rs.getInt("vuser");
			}
			
			sbQuery.setLength(0);
			sbQuery	.append("UPDATE lt_scenario_master SET v_users = ? ")
					.append("WHERE user_id = ? AND scenario_id = ? AND scenario_type = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, vuserId);
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setLong(3, scenarioId);
			pstmt.setString(4, strTestType);
			
			pstmt.execute();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmtSelect);
			pstmtSelect = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
    public JSONArray getLTLicense(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject joModule = null;
		JSONArray jaModules = new JSONArray();
		Date dateLog = LogManager.logMethodStart();

		try {
			String query = "select * from get_lt_license(?)";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(loginUserBean.getUserId()+""));
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joModule = new JSONObject();
				joModule.put("smr_label", "License");
				joModule.put("smr_value", rst.getString("lic"));
				joModule.put("lic_label", "Virtual Users");
				joModule.put("lic_value", rst.getString("vusers"));
				jaModules.add(joModule);
				joModule = new JSONObject();
				joModule.put("lic_label", "Avl.Scripts");
				joModule.put("lic_value", rst.getString("script"));
				joModule.put("smr_label", "Avl.scenarios");
				joModule.put("smr_value", rst.getLong("scenario"));
				jaModules.add(joModule);
				joModule = null;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			joModule = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaModules;

}

	public JSONArray getDashResponseArea(Connection con,LoginUserBean loginUserBean,long runid) throws Exception {
		PreparedStatement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONArray jsonChildArray = new JSONArray();
		String sbQuery = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery = "select scenariotime,avgrequestresponse from tblchartsummary inner join tblreportmaster on tblreportmaster.runid = tblchartsummary.id where userid = ? and runid =? and status IN ("+Constants.getLTStausStringForCompletedRuns()+")";
			stmt = con.prepareStatement(sbQuery);
			stmt.setLong(1, loginUserBean.getUserId());
			stmt.setLong(2, runid);
			rst = stmt.executeQuery();
			while( rst.next() ){
					jsonChildArray = new JSONArray();
					Long count = rst.getLong("avgrequestresponse");
					if(count == null){
						count = 0l;
					}
					jsonChildArray.add(rst.getTimestamp("scenariotime").getTime());
					jsonChildArray.add(count);
					jsonArray.add(jsonChildArray);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close(stmt);
			rst = null;
			stmt= null;
			sbQuery = null;
			jsonChildArray = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonArray;
	}

	public JSONArray getDashVUsersArea(Connection con,LoginUserBean loginUserBean, long runid,String scenarioName) throws Exception {
		PreparedStatement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONArray jsonChildArray = new JSONArray();
		String sbQuery = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery = "select runendtime,sum(v_users) as v_users from lt_scenario_master inner join tblreportmaster on tblreportmaster.userid = lt_scenario_master.user_id where user_id = ? and runid = ? and scenario_name = ? and status IN ("+Constants.getLTStausStringForCompletedRuns()+") group by runendtime";
			stmt = con.prepareStatement(sbQuery);
			stmt.setLong(1, loginUserBean.getUserId());
			stmt.setLong(2, runid);
			stmt.setString(3, scenarioName);
			rst = stmt.executeQuery();
			while( rst.next() ){
					jsonChildArray = new JSONArray();
					Long count = rst.getLong("v_users");
					if(count == null){
						count = 0l;
					}
					jsonChildArray.add(rst.getTimestamp("runendtime").getTime());
					jsonChildArray.add(count);
					jsonArray.add(jsonChildArray);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close(stmt);
			rst = null;
			stmt= null;
			sbQuery = null;
			jsonChildArray = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonArray;
	}
	
	public JSONObject getReportsChart(Connection con, String strReportId, String strReportType, String startTime) throws Exception
	{
		PreparedStatement pstmt = null, pstmtCount = null, pstmtPartition = null, pstmtInsert = null;
		ResultSet rs = null, rsCount = null;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joReportsChart = null;
		
		String tableName = null;
		long tableCount = 0;
		
		LinkedHashMap<Long,Double> userCountMap = new LinkedHashMap<Long,Double>();
		LinkedHashMap<Long,Double> hitCountMap = new LinkedHashMap<Long,Double>();
		LinkedHashMap<Long,Double> avgRequestResponseMap = new LinkedHashMap<Long,Double>();
		LinkedHashMap<Long,Double> avgThroughPutMap = new LinkedHashMap<Long,Double>();
		LinkedHashMap<Long,Double> errorCountMap = new LinkedHashMap<Long,Double>();
		LinkedHashMap<Long,Double> avgPageRespMap = new LinkedHashMap<Long,Double>();
		
		JSONArray chartArray = null;
		JSONObject chartObject = null;
		JSONArray childArray = null;
		
		Long scenariotime = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			joReportsChart = new JSONObject();
			tableName = "lt_chartsummary_"+strReportId;
			if( strReportType.equalsIgnoreCase("APPEDO_LT") ){	
				sbQuery.setLength(0);
				sbQuery .append("select count(*) AS count from pg_class where relname=? and relkind='r'");
				pstmtCount = con.prepareStatement(sbQuery.toString());
				pstmtCount.setString(1, tableName);
				rsCount = pstmtCount.executeQuery();
				if( rsCount.next() ){
					tableCount = rsCount.getLong("count");
				}
				
				if( tableCount == 0){
					sbQuery.setLength(0);
					sbQuery.append("SELECT lt_logs_table_partitions(?)");
					pstmtPartition = con.prepareStatement(sbQuery.toString());
					pstmtPartition.setLong(1, Long.valueOf(strReportId));
					pstmtPartition.execute();
					
					sbQuery.setLength(0);
					sbQuery .append("INSERT INTO lt_chartsummary_"+strReportId+"(loadgen_name, usercount, hitcount, avgrequestresponse, avgthroughput, errorcount, scenariotime, avgpageresponse)")
							.append("(SELECT loadgenname, usercount, hitcount, avgrequestresponse, avgthroughput, ")
							.append("errorcount, extract(epoch FROM scenariotime), avgpageresp FROM tblchartsummary WHERE id = ?)");
					pstmtInsert = con.prepareStatement(sbQuery.toString());
					pstmtInsert.setLong(1, Long.valueOf(strReportId));
					pstmtInsert.execute();
				}
			}
			sbQuery.setLength(0);
			if( strReportType.equalsIgnoreCase("APPEDO_LT") ){
				sbQuery	.append("SELECT loadgen_name as loadgenname, usercount, hitcount, avgrequestresponse, avgthroughput, ")
						.append("errorcount, scenariotime, avgpageresponse as avgpageresp FROM lt_chartsummary_")
						.append(strReportId)
						.append(" ")
						.append("WHERE loadgen_name IS NULL OR loadgen_name = '' ")
						.append("ORDER BY scenariotime ");
			}else {
				sbQuery	.append("SELECT loadgenname, usercount, hitcount, avgrequestresponse, avgthroughput, ")
						.append("errorcount, scenariotime, avgpageresp FROM tblchartsummary WHERE id = ")
						.append(strReportId)
						.append(" ")
						.append("AND loadgenname = '' ")
						.append("ORDER BY scenariotime ");
			}

			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();

			while(rs.next()) {
				scenariotime = null;
//				String hrStr = null, mnStr = null, secStr = null;
				if( strReportType.equalsIgnoreCase("APPEDO_LT") ){
//					int seconds = rs.getInt("scenariotime");
//					int hr = (int)(seconds/3600);
//					int rem = (int)(seconds%3600);
//					int mn = rem/60;
//					int sec = rem%60;
//					hrStr = (hr<10 ? "0" : "")+hr;
//					mnStr = (mn<10 ? "0" : "")+mn;
//					secStr = (sec<10 ? "0" : "")+sec; 
					
//					LogManager.infoLog("Long.parseLong(startTime) : "+Long.parseLong(startTime));
//					LogManager.infoLog("rs.getLong('scenariotime') : "+(rs.getLong("scenariotime")*1000));
					scenariotime = Long.parseLong(startTime)+ (rs.getLong("scenariotime")*1000) - ((rs.getLong("scenariotime")/Constants.LOADTESTSAMPLEDURATION)*1000);
//					LogManager.infoLog("scenariotime : "+scenariotime);
					
//					cal = new GregorianCalendar();
//					cal.setTimeInMillis(Long.parseLong(startTime));
//					LogManager.infoLog("Long.parseLong(startTime) : "+Long.parseLong(startTime));
//					LogManager.infoLog("Before cal"+cal.getTime());
//					LogManager.infoLog("Before cal"+cal.getTimeInMillis());
//					LogManager.infoLog("rs.getLong('scenariotime') : "+rs.getLong("scenariotime"));
//					cal.add(Calendar.SECOND,rs.getInt("scenariotime"));
//					LogManager.infoLog("After cal"+cal.getTime());
//					LogManager.infoLog("After cal"+cal.getTimeInMillis());
//					scenariotime = cal.getTimeInMillis();
				}else{
					//scenariotime = rs.getTime("scenariotime").getTime();
					scenariotime = Long.parseLong(startTime)+ rs.getTime("scenariotime").getTime();
				}
				
//				String scenariotime = "";
//				if( strReportType.equalsIgnoreCase("APPEDO_LT") ){
//					scenariotime = hrStr+":"+mnStr+":"+secStr;
//				} else {
//					scenariotime = rs.getString("scenariotime");
//				}
				
				userCountMap.put(scenariotime, rs.getDouble("usercount"));
				hitCountMap.put(scenariotime, rs.getDouble("hitcount"));
				avgRequestResponseMap.put(scenariotime, rs.getDouble("avgrequestresponse"));
				avgThroughPutMap.put(scenariotime, rs.getDouble("avgthroughput"));
				errorCountMap.put(scenariotime, rs.getDouble("errorcount"));
				avgPageRespMap.put(scenariotime, rs.getDouble("avgpageresp"));
				
//				hrStr = null;
//				mnStr = null;
//				secStr = null;
				scenariotime = null;
			}
			chartArray =  new JSONArray();

			chartObject = new JSONObject();
			chartObject.put("chartName","User Counts");
			childArray = new JSONArray();
			for (Map.Entry<Long,Double> childEntry : userCountMap.entrySet()){
				JSONObject childJson = new JSONObject();
				childJson.put("T",childEntry.getKey());
				childJson.put("V",childEntry.getValue());
				childJson.put("Value",childEntry.getValue());
				childArray.add(childJson);
			}
			chartObject.put("chartData",childArray);
			chartArray.add(chartObject);

			chartObject = new JSONObject();
			chartObject.put("chartName","Hit Counts");
			childArray = new JSONArray();
			for (Map.Entry<Long,Double> childEntry : hitCountMap.entrySet()){
				JSONObject childJson = new JSONObject();
				childJson.put("T",childEntry.getKey());
				childJson.put("V",childEntry.getValue());
				childJson.put("Value",childEntry.getValue());
				childArray.add(childJson);
			}
			chartObject.put("chartData",childArray);
			chartArray.add(chartObject);

			chartObject = new JSONObject();
			chartObject.put("chartName","Avg. Request Response");
			childArray = new JSONArray();
			for (Map.Entry<Long,Double> childEntry : avgRequestResponseMap.entrySet()){
				JSONObject childJson = new JSONObject();
				childJson.put("T",childEntry.getKey());
				childJson.put("V",childEntry.getValue());
				childJson.put("Value",childEntry.getValue());
				childArray.add(childJson);
			}
			chartObject.put("chartData",childArray);
			chartArray.add(chartObject);
			
			chartObject = new JSONObject();
			chartObject.put("chartName","Avg. ThroughPut");
			childArray = new JSONArray();
			for (Map.Entry<Long,Double> childEntry : avgThroughPutMap.entrySet()){
				JSONObject childJson = new JSONObject();
				childJson.put("T",childEntry.getKey());
				childJson.put("V",childEntry.getValue());
				childJson.put("Value",childEntry.getValue());
				childArray.add(childJson);
			}
			chartObject.put("chartData",childArray);
			chartArray.add(chartObject);

			chartObject = new JSONObject();
			chartObject.put("chartName","Error Counts");
			childArray = new JSONArray();
			for (Map.Entry<Long,Double> childEntry : errorCountMap.entrySet()){
				JSONObject childJson = new JSONObject();
				childJson.put("T",childEntry.getKey());
				childJson.put("V",childEntry.getValue());
				childJson.put("Value",childEntry.getValue());
				childArray.add(childJson);
			}
			chartObject.put("chartData",childArray);
			chartArray.add(chartObject);

			chartObject = new JSONObject();
			chartObject.put("chartName","Avg. Page Response");
			childArray = new JSONArray();
			for (Map.Entry<Long,Double> childEntry : avgPageRespMap.entrySet()){
				JSONObject childJson = new JSONObject();
				childJson.put("T",childEntry.getKey());
				childJson.put("V",childEntry.getValue());
				childJson.put("Value",childEntry.getValue());
				childArray.add(childJson);
			}
			chartObject.put("chartData",childArray);
			chartArray.add(chartObject);

			 
			joReportsChart.put("emptyLoadgenValue",chartArray);
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : "+ sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtCount);
			pstmtCount = null;
			DataBaseManager.close(pstmtPartition);
			pstmtPartition = null;
			DataBaseManager.close(pstmtInsert);
			pstmtInsert = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return joReportsChart;
	}

	
	public String getChartDataForAppdeoLTPageResponse(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception
	{
		StringBuilder sbQuery = new StringBuilder();
		StringBuilder sbCountQuery = new StringBuilder();
		Map<String, Object> resultMap=new HashMap<>();
		String jsonString = null;
		long totalCount = 0;
		long startDurationTime = 0;
		long endDurationTime = 0;
		Long selectedTimeInSeconds = Long.parseLong(selectedTime);
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
			if(strReportType.equalsIgnoreCase(Constants.APPEDO_LT)){
				if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_HOUR)){
					if(status.equalsIgnoreCase(Constants.LOAD_TEST_RUNNING)){
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(endtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC' between (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second'");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							sbQuery.setLength(0);
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins,script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(*) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins,script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where (to_timestamp(endtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC' between (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second' group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
						}
					}else{
						if(UtilsFactory.checkRunTimeLessThanGivenHour(Constants.LT_RUNTIME_CHECK_HOUR, runTime)){
							if(UtilsFactory.checkRunTimeLessThanGivenMinute(Constants.LT_RUNTIME_CHECK_MINUTE, runTime)){
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins, script_id, page_id, sum(diff) as diff from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where end_mins  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins, script_id, page_id, sum(diff) as diff from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
								}
							}else{
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where end_secs  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(*) as \"Second counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
								}
							}
						}else{
							sbCountQuery.setLength(0);
							sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
							sbCountQuery.append(strReportId);
							resultMap = getLTCountData(con, sbCountQuery.toString());
							Boolean countStatus = (Boolean) resultMap.get("status");
							if(countStatus){
								totalCount =  (Long) resultMap.get("totalCount");
								startDurationTime = (Long) resultMap.get("startDurationTime");
								endDurationTime = (Long) resultMap.get("endDurationTime");
							}
							if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
								long endTime = endDurationTime;
								long divisableValue = UtilsFactory.getValueForLoop(totalCount);
								long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
								sbQuery.setLength(0);
								for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
									endDurationTime = startDurationTime +dividedEpochTime;
									if(endDurationTime>endTime){
										endDurationTime = endTime;
									}
									if(iLoop != 0){
										sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
									}
									if(divisableValue>1){
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
									}else{
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									}
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_hrs as \"T\",count(end_hrs) as \"Hour counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_hrs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" where end_hrs  between ");
									sbQuery.append(startDurationTime);
									sbQuery.append(" and ");
									sbQuery.append(endDurationTime);
									sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
									startDurationTime = endDurationTime;
								}
							}else{
								sbQuery.setLength(0);
								sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_hrs as \"T\",count(end_hrs) as \"Hour counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_hrs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
							}
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_MINS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(end_time) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where end_hrs between ");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(" and (");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append("+3600000)");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins,script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins,script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where end_mins between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(" and (");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+3600000) group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(*) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins,script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins,script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_SECS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where end_mins between ");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(" and (");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append("+60000)");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_secs  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where end_secs between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(" and (");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+60000) group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_secs  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs,script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1,2,3 order by 1,2,3) as data group by 1 order by 1)  jsoncontent");
						}
					}
				}
			}
			jsonString  = getLTChartData(con, sbQuery.toString());
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : "+ sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery );
			UtilsFactory.clearCollectionHieracy( sbCountQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getChartDataForAppdeoLTThroughputHitCountsAndReqResponse(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception
	{
		StringBuilder sbQuery = new StringBuilder();
		StringBuilder sbCountQuery = new StringBuilder();
		Map<String, Object> resultMap=new HashMap<>();
		String jsonString = null;
		long totalCount = 0;
		long startDurationTime = 0;
		long endDurationTime = 0;
		Long selectedTimeInSeconds = Long.parseLong(selectedTime);
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
			if(strReportType.equalsIgnoreCase(Constants.APPEDO_LT)){
				if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_HOUR)){
					if(status.equalsIgnoreCase(Constants.LOAD_TEST_RUNNING)){
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(endtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC' between (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second'");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", count(end_mins) as \"Total Hits\",count(end_mins)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", count(end_mins) as \"Total Hits\",count(end_mins)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where to_timestamp(end_secs) at TIME ZONE 'UTC' between (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second' group by 1 order by 1) jsoncontent");
						}
					}else{
						if(UtilsFactory.checkRunTimeLessThanGivenHour(Constants.LT_RUNTIME_CHECK_HOUR, runTime)){
							if(UtilsFactory.checkRunTimeLessThanGivenMinute(Constants.LT_RUNTIME_CHECK_MINUTE, runTime)){
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", count(end_mins) as \"Total Hits\",count(end_secs)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where end_mins  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1 order by 1) jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", count(end_mins) as \"Total Hits\",count(end_mins)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1 order by 1) jsoncontent");
								}
							}else{
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", count(end_secs) as \"Total Hits\",count(end_secs)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where end_secs  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1 order by 1) jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", count(end_secs) as \"Total Hits\",count(end_secs)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1 order by 1) jsoncontent");
								}
							}
						}else{
							sbCountQuery.setLength(0);
							sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
							sbCountQuery.append(strReportId);
							resultMap = getLTCountData(con, sbCountQuery.toString());
							Boolean countStatus = (Boolean) resultMap.get("status");
							if(countStatus){
								totalCount =  (Long) resultMap.get("totalCount");
								startDurationTime = (Long) resultMap.get("startDurationTime");
								endDurationTime = (Long) resultMap.get("endDurationTime");
							}
							if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
								long endTime = endDurationTime;
								long divisableValue = UtilsFactory.getValueForLoop(totalCount);
								long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
								sbQuery.setLength(0);
								for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
									endDurationTime = startDurationTime +dividedEpochTime;
									if(endDurationTime>endTime){
										endDurationTime = endTime;
									}
									if(iLoop != 0){
										sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
									}
									if(divisableValue>1){
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
									}else{
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									}
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_hrs as \"T\",count(end_hrs) as \"Hour counts\", count(end_hrs) as \"Total Hits\",count(end_hrs)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/(60.000*60.000),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" where end_hrs  between ");
									sbQuery.append(startDurationTime);
									sbQuery.append(" and ");
									sbQuery.append(endDurationTime);
									sbQuery.append(" group by 1 order by 1) jsoncontent");
									startDurationTime = endDurationTime;
								}
							}else{
								sbQuery.setLength(0);
								sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_hrs as \"T\",count(*) as \"Hour counts\", count(*) as \"Total Hits\",count(*)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/(60.000*60.000),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
							}
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_MINS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(end_hrs) at TIME ZONE 'UTC') between (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC') and (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC')+ interval '1 hour' ");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", count(end_mins) as \"Total Hits\",count(end_mins)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", count(end_mins) as \"Total Hits\",count(end_mins)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where end_mins between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(" and (");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+3600000) group by 1 order by 1) jsoncontent");

						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(end_mins) as \"Minute counts\", count(end_mins) as \"Total Hits\",count(end_mins)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where endtime  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_mins as \"T\",count(*) as \"Minute counts\", count(*) as \"Total Hits\",count(*)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric)/60.000,3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\",round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1 order by 1) jsoncontent");
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_SECS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(endtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') between (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC') and (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC')+ interval '1 minute'");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(*) as \"Second counts\", count(*) as \"Total Hits\",count(*)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_secs  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(*) as \"Second counts\", count(*) as \"Total Hits\",count(*)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where end_secs between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(" and (");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+ 60000) group by 1 order by 1) jsoncontent");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", count(end_secs) as \"Total Hits\",count(end_secs)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where endtime  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select end_secs as \"T\",count(end_secs) as \"Second counts\", count(end_secs) as \"Total Hits\",count(end_secs)/60 as \"Hits/Sec\",round(cast(sum(responsesize) as numeric),3) as \"Bps\",CASE WHEN round(cast(sum(responsesize) as numeric),3) < 1024.000 THEN round(cast(sum(responsesize) as numeric),3)|| ' bytes' WHEN round(cast(sum(responsesize) as numeric),3) > 1024.000 AND round(cast(sum(responsesize) as numeric),3) < 1048576.000 THEN round(cast(sum(responsesize) as numeric)/1024.000,3)|| ' Kb' WHEN round(cast(sum(responsesize) as numeric),3) > 1048576.000 AND round(cast(sum(responsesize) as numeric),3) < 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000),3)|| ' Mb' WHEN round(cast(sum(responsesize) as numeric),3) > 1073741824.000 THEN round(cast(sum(responsesize) as numeric)/(1024.000*1024.000*1024.000),3)|| ' Gb' END AS \"Bytes\",round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast( max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1 order by 1) jsoncontent");
						}
					}
				}
			}
			jsonString  = getLTChartData(con, sbQuery.toString());
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : "+ sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery );
			UtilsFactory.clearCollectionHieracy( sbCountQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getChartDataForAppdeoLTErrorCounts(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception
	{
		StringBuilder sbQuery = new StringBuilder();
		StringBuilder sbCountQuery = new StringBuilder();
		Map<String, Object> resultMap=new HashMap<>();
		String jsonString = null;
		long totalCount = 0;
		long startDurationTime = 0;
		long endDurationTime = 0;
		Long selectedTimeInSeconds = UtilsFactory.convertMilliSecondsToSeconds(Long.parseLong(selectedTime));
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
			if(strReportType.equalsIgnoreCase(Constants.APPEDO_LT)){
				if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_HOUR)){
					if(status.equalsIgnoreCase(Constants.LOAD_TEST_RUNNING)){
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(log_time) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') between now() - interval '1 hour' and now()");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
								sbQuery.append(strReportId);
								sbQuery.append(" where log_time  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
							sbQuery.append(strReportId);
							sbQuery.append(" where to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC' between (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second' group by 1 order by 1) jsoncontent");
						}
					}else{
						if(UtilsFactory.checkRunTimeLessThanGivenHour(Constants.LT_RUNTIME_CHECK_HOUR, runTime)){
							if(UtilsFactory.checkRunTimeLessThanGivenMinute(Constants.LT_RUNTIME_CHECK_MINUTE, runTime)){
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(lt_error_id) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
										sbQuery.append(strReportId);
										sbQuery.append(" where log_time  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1 order by 1) jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1 order by 1) jsoncontent");
								}
							}else{
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(lt_error_id) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('second',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
										sbQuery.append(strReportId);
										sbQuery.append(" where log_time  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1 order by 1) jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('second',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1 order by 1) jsoncontent");
								}
							}
						}else{
							sbCountQuery.setLength(0);
							sbCountQuery.append("select max(lt_error_id) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
							sbCountQuery.append(strReportId);
							resultMap = getLTCountData(con, sbCountQuery.toString());
							Boolean countStatus = (Boolean) resultMap.get("status");
							if(countStatus){
								totalCount =  (Long) resultMap.get("totalCount");
								startDurationTime = (Long) resultMap.get("startDurationTime");
								endDurationTime = (Long) resultMap.get("endDurationTime");
							}
							if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
								long endTime = endDurationTime;
								long divisableValue = UtilsFactory.getValueForLoop(totalCount);
								long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
								sbQuery.setLength(0);
								for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
									endDurationTime = startDurationTime +dividedEpochTime;
									if(endDurationTime>endTime){
										endDurationTime = endTime;
									}
									if(iLoop != 0){
										sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
									}
									if(divisableValue>1){
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
									}else{
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									}
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('hour',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
									sbQuery.append(strReportId);
									sbQuery.append(" where log_time  between ");
									sbQuery.append(startDurationTime);
									sbQuery.append(" and ");
									sbQuery.append(endDurationTime);
									sbQuery.append(" group by 1 order by 1) jsoncontent");
									startDurationTime = endDurationTime;
								}
							}else{
								sbQuery.setLength(0);
								sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('hour',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
								sbQuery.append(strReportId);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
							}
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_MINS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(log_time) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') between (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC') and (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC')+ interval '1 hour'");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
								sbQuery.append(strReportId);
								sbQuery.append(" where log_time  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
							sbQuery.append(strReportId);
							sbQuery.append(" where (to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') between (to_timestamp(");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(") at TIME ZONE 'UTC') and (to_timestamp(");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(") at TIME ZONE 'UTC')+ interval '1 hour' group by 1 order by 1) jsoncontent");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(lt_error_id) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
								sbQuery.append(strReportId);
								sbQuery.append(" where log_time  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('minute',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1 order by 1) jsoncontent");
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_SECS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(log_time) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') between (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC') and (to_timestamp(");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(") at TIME ZONE 'UTC')+ interval '1 minute'");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('second',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
								sbQuery.append(strReportId);
								sbQuery.append(" where log_time  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('second',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
							sbQuery.append(strReportId);
							sbQuery.append(" where (to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') between (to_timestamp(");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(") at TIME ZONE 'UTC') and (to_timestamp(");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(") at TIME ZONE 'UTC')+ interval '1 minute' group by 1 order by 1) jsoncontent");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(lt_error_id) as total_count,max(log_time) as max_value,min(log_time) as min_value  from lt_error_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('second',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
								sbQuery.append(strReportId);
								sbQuery.append(" where log_time  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select (extract('epoch' from date_trunc('second',to_timestamp(log_time/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC'))*1000) as \"T\", count(*) as \"V\",count(*) as \"Error count\"  from lt_error_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1 order by 1) jsoncontent");
						}
					}
				}
			}
			jsonString  = getLTChartData(con, sbQuery.toString());
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : "+ sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery );
			UtilsFactory.clearCollectionHieracy( sbCountQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getChartDataForAppdeoLTUserCounts(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception
	{
		StringBuilder sbQuery = new StringBuilder(), sbFilter = new StringBuilder();
		String jsonString = null;
		Long selectedTimeInSeconds = UtilsFactory.convertMilliSecondsToSeconds(Long.parseLong(selectedTime));
		Date dateLog = LogManager.logMethodStart();
		String duration = "";
		Statement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject json = null;

		try {
			String subQuery = " where to_timestamp(runtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC' between";
			String fromToQuery = " (to_timestamp("+selectedTimeInSeconds+") at TIME ZONE 'UTC') and (to_timestamp("+selectedTimeInSeconds+") at TIME ZONE 'UTC')+ interval";
			
			if(strReportType.equalsIgnoreCase(Constants.APPEDO_LT)){
				if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_HOUR)){
					if(status.equalsIgnoreCase(Constants.LOAD_TEST_RUNNING)){
						duration =  "minute";
						sbFilter.append(subQuery).append(" (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second' ");
					}else{
						if(UtilsFactory.checkRunTimeLessThanGivenHour(Constants.LT_RUNTIME_CHECK_HOUR, runTime)){
							if(UtilsFactory.checkRunTimeLessThanGivenMinute(Constants.LT_RUNTIME_CHECK_MINUTE, runTime)){
								duration =  "second";
							}else{
								duration = "minute";
							}
						}else{
							duration = "hour";
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_MINS)){
					if(Long.parseLong(selectedTime)>0)
					{
						duration =  "minute";
						sbFilter.append(subQuery).append(fromToQuery).append(" '1 hour' ");
					}else{
						duration =  "minute";
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_SECS)){
					if(Long.parseLong(selectedTime)>0)
					{
						duration = "second";
						sbFilter.append(subQuery).append(fromToQuery).append(" '1 minute' ");
					}else{
						duration = "second";
					}
				}
			}
			
			sbQuery.setLength(0);
			sbQuery .append("SELECT date_trunc('"+duration+"',to_timestamp(runtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') as Time, ")
					.append("COUNT(CASE WHEN runtype = 1 THEN userid ELSE NULL END) AS rampUp, COUNT(CASE WHEN runtype = 2 THEN userid ELSE NULL END) AS rampDown FROM lt_user_runtime_")
					.append(strReportId)
					.append(sbFilter)
					.append(" group by 1 order by 1");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			int count = 0;
			while(rst.next()) {
				json = new JSONObject();
				json.put("T", rst.getTimestamp("Time").getTime());
				count += rst.getInt("rampUp") - rst.getInt("rampDown");
				json.put("V", count);
				json.put("VUser count", count);
				jsonArray.add(json);
			}
			
			jsonString  = UtilsFactory.convertStringtoJSON(jsonString, jsonArray.toString());
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : "+ sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}
	
	public JSONArray getLoadgensAvgReqResp(Connection con, String strReportId, String strReportType, String startTime) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		StringBuilder sbQuery = new StringBuilder();
		
		Map<String,LinkedHashMap> map = new HashMap<String,LinkedHashMap>();
		LinkedHashMap<Long,Long> childMap = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		Date dateLog = LogManager.logMethodStart();

		try {
			if( strReportType.equalsIgnoreCase("APPEDO_LT") ){
				sbQuery	.append("SELECT lc.loadgen_name as loadgen_ip_address, lm.public_ip, lm.region, lc.scenariotime, lc.avgrequestresponse, lc.avgpageresponse as avgpageresp ")
						.append("FROM lt_chartsummary_").append(strReportId).append(" lc ")
						.append("LEFT JOIN lt_dynamic_load_agent_details lm on lm.public_ip = lc.loadgen_name ")
						.append("WHERE loadgen_name != '' ")
						.append("ORDER BY scenariotime ");
			} else {
				sbQuery	.append("SELECT cs.loadgenname as loadgen_ip_address, lm.public_ip, lm.region, cs.scenariotime, cs.avgrequestresponse, cs.avgpageresp ")
						.append("FROM tblchartsummary cs ")
						.append("LEFT JOIN lt_dynamic_load_agent_details lm on lm.public_ip = cs.loadgenname ")
						.append("WHERE id = ").append(strReportId).append(" AND loadgenname != '' ")
						.append("ORDER BY scenariotime ");
			}
			

			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			Long scenariotime = null;
			while(rst.next()) {
//				String hrStr = null, mnStr = null, secStr = null;
				
//				Date dt = null;
				if( strReportType.equalsIgnoreCase("APPEDO_LT") ){
//					int seconds = rst.getInt("scenariotime");
//					int hr = (int)(seconds/3600);
//					int rem = (int)(seconds%3600);
//					int mn = rem/60;
//					int sec = rem%60;
//					hrStr = (hr<10 ? "0" : "")+hr;
//					mnStr = (mn<10 ? "0" : "")+mn;
//					secStr = (sec<10 ? "0" : "")+sec; 
//					dt = sdf.parse(hrStr+":"+mnStr+":"+secStr);
					// Math for negative to postive value  
//					scenariotime = dt.getTime();
//					scenariotime = Long.parseLong(startTime)+rst.getLong("scenariotime");
					scenariotime = Long.parseLong(startTime)+ (rst.getLong("scenariotime")*1000) - ((rst.getLong("scenariotime")/Constants.LOADTESTSAMPLEDURATION)*1000);
					
				} else {
					scenariotime = Math.abs(rst.getTimestamp("scenariotime").getTime());
				}
				
				if(!map.containsKey(rst.getString("region"))){
					childMap = new LinkedHashMap<Long,Long>();
					map.put(rst.getString("region"), childMap);
				}
				childMap.put(scenariotime, rst.getLong("avgrequestresponse"));
				
//				hrStr = null;
//				mnStr = null;
//				secStr = null;
//				dt = null;
				scenariotime = null;
			}
			
			for (Map.Entry<String, LinkedHashMap> entry : map.entrySet()){
				json = new JSONObject();
				json.put("City", entry.getKey());
				LinkedHashMap<Long,Long> cMap = entry.getValue();
				JSONArray childArray = new JSONArray();
				for (Map.Entry<Long,Long> childEntry : cMap.entrySet()){
					JSONObject childJson = new JSONObject();
					childJson.put("Date",childEntry.getKey());
					childJson.put("Value",childEntry.getValue());
					childArray.add(childJson);
				}
				json.put("Data",childArray);
				jsonArray.add(json);
			}	
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sdf = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return jsonArray;
	}
	
	public String getLoadgensAvgReqResp(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status,String runTime) throws Exception
	{
		StringBuilder sbQuery = new StringBuilder();
		StringBuilder sbCountQuery = new StringBuilder();
		Map<String, Object> resultMap=new HashMap<>();
		String jsonString = null;
		long totalCount = 0;
		long startDurationTime = 0;
		long endDurationTime = 0;
		Long selectedTimeInSeconds = Long.parseLong(selectedTime);
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
			if(strReportType.equalsIgnoreCase(Constants.APPEDO_LT)){
				if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_HOUR)){
					if(status.equalsIgnoreCase(Constants.LOAD_TEST_RUNNING)){
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(endtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC' between (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second'");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(end_mins) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where loadgen_name=dd.loadgen_name and end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(*) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where loadgen_name = dd.loadgen_name and (to_timestamp(end_secs) between now() - interval '1 hour' and now() group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
						}
					}else{
						if(UtilsFactory.checkRunTimeLessThanGivenHour(Constants.LT_RUNTIME_CHECK_HOUR, runTime)){
							if(UtilsFactory.checkRunTimeLessThanGivenMinute(Constants.LT_RUNTIME_CHECK_MINUTE, runTime)){
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_secs as \"Date\", end_secs as \"T\", count(*) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where loadgen_name=dd.loadgen_name and end_secs  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_secs as \"Date\", end_secs as \"T\", count(*) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");						
								}
							}else{
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(end_mins) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where loadgen_name=dd.loadgen_name and end_mins  between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(end_mins) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");						
								}
							}
						}else{
							sbCountQuery.setLength(0);
							sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
							sbCountQuery.append(strReportId);
							resultMap = getLTCountData(con, sbCountQuery.toString());
							Boolean countStatus = (Boolean) resultMap.get("status");
							if(countStatus){
								totalCount =  (Long) resultMap.get("totalCount");
								startDurationTime = (Long) resultMap.get("startDurationTime");
								endDurationTime = (Long) resultMap.get("endDurationTime");
							}
							if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
								long endTime = endDurationTime;
								long divisableValue = UtilsFactory.getValueForLoop(totalCount);
								long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
								sbQuery.setLength(0);
								for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
									endDurationTime = startDurationTime +dividedEpochTime;
									if(endDurationTime>endTime){
										endDurationTime = endTime;
									}
									if(iLoop != 0){
										sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
									}
									if(divisableValue>1){
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
									}else{
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									}
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_hrs as \"Date\", end_hrs as \"T\", count(end_hrs) as \"Hour count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" where loadgen_name=dd.loadgen_name and end_mins  between ");
									sbQuery.append(startDurationTime);
									sbQuery.append(" and ");
									sbQuery.append(endDurationTime);
									sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
									startDurationTime = endDurationTime;
								}
							}else{
								sbQuery.setLength(0);
								sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_hrs as \"Date\", end_hrs as \"T\", count(end_hrs) as \"Hour count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");						
							}
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_MINS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where end_mins between ");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(" and ");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append("+3600000");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(end_mins) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where loadgen_name=dd.loadgen_name and end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(end_mins) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where loadgen_name=dd.loadgen_name and end_mins between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(" and (");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+3600000) group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(end_mins) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where loadgen_name=dd.loadgen_name and end_mins  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_mins as \"Date\", end_mins as \"T\", count(end_mins) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");						
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_SECS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where end_secs between ");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(" and (");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append("+60000)");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_secs as \"Date\", end_secs as \"T\", count(end_secs) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where loadgen_name=dd.loadgen_name and end_secs  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_secs as \"Date\", end_secs as \"T\", count(end_secs) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where loadgen_name=dd.loadgen_name and end_secs between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(" and (");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+60000) group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_secs as \"Date\", end_secs as \"T\", count(end_secs) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where loadgen_name=dd.loadgen_name and end_secs  between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select end_secs as \"Date\", end_secs as \"T\", count(end_secs) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\",round(cast(avg(diff) as numeric),3) as \"Value\",round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");						
						}
					}
				}
			}
			jsonString  = getLTChartData(con, sbQuery.toString());
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : "+ sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery );
			UtilsFactory.clearCollectionHieracy( sbCountQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	/**
	 * Returns LoadGen's average page response
	 * 
	 * @param con
	 * @param strReportId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLoadgensAvgPageResp(Connection con, String strReportId, String strReportType, String startTime) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		StringBuilder sbQuery = new StringBuilder();
		
		Map<String,LinkedHashMap> map = new HashMap<String,LinkedHashMap>();
		LinkedHashMap<Long,Long> childMap = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		Long scenariotime = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			if( strReportType.equalsIgnoreCase("APPEDO_LT") ){
				sbQuery	.append("SELECT lc.loadgen_name as loadgen_ip_address, lm.public_ip, lm.region, lc.scenariotime, lc.avgrequestresponse, lc.avgpageresponse as avgpageresp ")
						.append("FROM lt_chartsummary_").append(strReportId).append(" lc ")
						.append("LEFT JOIN lt_dynamic_load_agent_details lm on lm.public_ip = lc.loadgen_name ")
						.append("WHERE loadgen_name != '' ")
						.append("ORDER BY scenariotime ");
			} else {
				sbQuery	.append("SELECT cs.loadgenname as loadgen_ip_address, lm.public_ip, lm.region, cs.scenariotime, cs.avgrequestresponse, cs.avgpageresp ")
						.append("FROM tblchartsummary cs ")
						.append("LEFT JOIN lt_dynamic_load_agent_details lm on lm.public_ip = cs.loadgenname ")
						.append("WHERE id = ").append(strReportId).append(" AND loadgenname != '' ")
						.append("ORDER BY scenariotime ");
			}

			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while(rst.next()) {
//				String hrStr = null, mnStr = null, secStr = null;
//				Date dt = null;
				scenariotime = null;
				if( strReportType.equalsIgnoreCase("APPEDO_LT") ){
//					int seconds = rst.getInt("scenariotime");
//					int hr = (int)(seconds/3600);
//					int rem = (int)(seconds%3600);
//					int mn = rem/60;
//					int sec = rem%60;
//					hrStr = (hr<10 ? "0" : "")+hr;
//					mnStr = (mn<10 ? "0" : "")+mn;
//					secStr = (sec<10 ? "0" : "")+sec; 
//					dt = sdf.parse(hrStr+":"+mnStr+":"+secStr);
					// Math for negative to postive value  
//					scenariotime = dt.getTime();
//					scenariotime = Long.parseLong(startTime)+rst.getLong("scenariotime");
					scenariotime = new Date(Long.parseLong(startTime)+ (rst.getLong("scenariotime")*1000) - ((rst.getLong("scenariotime")/Constants.LOADTESTSAMPLEDURATION)*1000)).getTime();
				} else {
					scenariotime = Math.abs(rst.getTimestamp("scenariotime").getTime());
				}
				
				if(!map.containsKey(rst.getString("region"))){
					childMap = new LinkedHashMap<Long,Long>();
					map.put(rst.getString("region"), childMap);
				}
				childMap.put(scenariotime, rst.getLong("avgpageresp"));
				
//				hrStr = null;
//				mnStr = null;
//				secStr = null;
//				dt = null;
				scenariotime = null;
			}
			
			for (Map.Entry<String, LinkedHashMap> entry : map.entrySet()){
				json = new JSONObject();
				json.put("City", entry.getKey());
				LinkedHashMap<Long,Long> cMap = entry.getValue();
				JSONArray childArray = new JSONArray();
				for (Map.Entry<Long,Long> childEntry : cMap.entrySet()){
					JSONObject childJson = new JSONObject();
					childJson.put("Date",childEntry.getKey());
					childJson.put("Value",childEntry.getValue());
					childArray.add(childJson);
				}
				json.put("Data",childArray);
				jsonArray.add(json);
			}	
			
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sdf = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return jsonArray;
	}

	/**
	 * Returns LoadGen's average page response
	 * 
	 * @param con
	 * @param strReportId
	 * @return
	 * @throws Exception
	 */
	public String getLoadgensAvgPageResp(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status,String runTime) throws Exception
	{
		StringBuilder sbQuery = new StringBuilder();
		StringBuilder sbCountQuery = new StringBuilder();
		Map<String, Object> resultMap=new HashMap<>();
		String jsonString = null;
		long totalCount = 0;
		long startDurationTime = 0;
		long endDurationTime = 0;
		Long selectedTimeInSeconds = Long.parseLong(selectedTime);
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
			if(strReportType.equalsIgnoreCase(Constants.APPEDO_LT)){
				if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_HOUR)){
					if(status.equalsIgnoreCase(Constants.LOAD_TEST_RUNNING)){
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where (to_timestamp(endtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC' between (now()- interval '10 second')- interval '1 hour' and now()- interval '10 second'");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(*) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(*) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where (to_timestamp(endtime/"+Constants.LT_BATCH_EPOCH_VALUE+") at TIME ZONE 'UTC') between (now()-interval '10 second') - interval '1 hour' and (now()-interval '10 second') group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
						}
					}else{
						if(UtilsFactory.checkRunTimeLessThanGivenHour(Constants.LT_RUNTIME_CHECK_HOUR, runTime)){
							if(UtilsFactory.checkRunTimeLessThanGivenMinute(Constants.LT_RUNTIME_CHECK_MINUTE, runTime)){
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(*) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where end_secs between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(*) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
								}
							}else{
								sbCountQuery.setLength(0);
								sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
								sbCountQuery.append(strReportId);
								resultMap = getLTCountData(con, sbCountQuery.toString());
								Boolean countStatus = (Boolean) resultMap.get("status");
								if(countStatus){
									totalCount =  (Long) resultMap.get("totalCount");
									startDurationTime = (Long) resultMap.get("startDurationTime");
									endDurationTime = (Long) resultMap.get("endDurationTime");
								}
								if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
									long endTime = endDurationTime;
									long divisableValue = UtilsFactory.getValueForLoop(totalCount);
									long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
									sbQuery.setLength(0);
									for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
										endDurationTime = startDurationTime +dividedEpochTime;
										if(endDurationTime>endTime){
											endDurationTime = endTime;
										}
										if(iLoop != 0){
											sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
										}
										if(divisableValue>1){
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
										}else{
											sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
										}
										sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(*) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" where end_mins between ");
										sbQuery.append(startDurationTime);
										sbQuery.append(" and ");
										sbQuery.append(endDurationTime);
										sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
										sbQuery.append(strReportId);
										sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
										startDurationTime = endDurationTime;
									}
								}else{
									sbQuery.setLength(0);
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
								}
							}
						}else{
							sbCountQuery.setLength(0);
							sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
							sbCountQuery.append(strReportId);
							resultMap = getLTCountData(con, sbCountQuery.toString());
							Boolean countStatus = (Boolean) resultMap.get("status");
							if(countStatus){
								totalCount =  (Long) resultMap.get("totalCount");
								startDurationTime = (Long) resultMap.get("startDurationTime");
								endDurationTime = (Long) resultMap.get("endDurationTime");
							}
							if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
								long endTime = endDurationTime;
								long divisableValue = UtilsFactory.getValueForLoop(totalCount);
								long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
								sbQuery.setLength(0);
								for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
									endDurationTime = startDurationTime +dividedEpochTime;
									if(endDurationTime>endTime){
										endDurationTime = endTime;
									}
									if(iLoop != 0){
										sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
									}
									if(divisableValue>1){
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
									}else{
										sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
									}
									sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Hour count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_hrs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" where end_mins between ");
									sbQuery.append(startDurationTime);
									sbQuery.append(" and ");
									sbQuery.append(endDurationTime);
									sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
									sbQuery.append(strReportId);
									sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
									startDurationTime = endDurationTime;
								}
							}else{
								sbQuery.setLength(0);
								sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Hour count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_hrs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
							}
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_MINS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where end_mins between ");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(" and (");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append("+3600000)");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where end_mins between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("  and ( ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+3600000) group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_mins between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Minute count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_mins as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
						}
					}
				}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_SECS)){
					if(Long.parseLong(selectedTime)>0)
					{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select count(endtime) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						sbCountQuery.append(" where end_secs between ");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append(" and (");
						sbCountQuery.append(selectedTimeInSeconds);
						sbCountQuery.append("+60000)");
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_secs between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" where end_secs between ");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append(" and (");
							sbQuery.append(selectedTimeInSeconds);
							sbQuery.append("+60000) group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
						}
					}else{
						sbCountQuery.setLength(0);
						sbCountQuery.append("select max(reportdata_id) as total_count,max(endtime) as max_value,min(endtime) as min_value  from lt_reportdata_");
						sbCountQuery.append(strReportId);
						resultMap = getLTCountData(con, sbCountQuery.toString());
						Boolean countStatus = (Boolean) resultMap.get("status");
						if(countStatus){
							totalCount =  (Long) resultMap.get("totalCount");
							startDurationTime = (Long) resultMap.get("startDurationTime");
							endDurationTime = (Long) resultMap.get("endDurationTime");
						}
						if(UtilsFactory.checkTotalCountGreaterThanLimit(totalCount)){
							long endTime = endDurationTime;
							long divisableValue = UtilsFactory.getValueForLoop(totalCount);
							long dividedEpochTime = UtilsFactory.getDividedEpochTime(divisableValue,(endDurationTime - startDurationTime));
							for(int iLoop=0 ; iLoop <= divisableValue ; iLoop++){
								endDurationTime = startDurationTime +dividedEpochTime;
								if(endDurationTime>endTime){
									endDurationTime = endTime;
								}
								if(iLoop != 0){
									sbQuery.append(Constants.QUERY_STRING_SEPARATOR);
								}
								if(divisableValue>1){
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_100_MB+";");
								}else{
									sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
								}
								sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" where end_secs between ");
								sbQuery.append(startDurationTime);
								sbQuery.append(" and ");
								sbQuery.append(endDurationTime);
								sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name  group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
								sbQuery.append(strReportId);
								sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
								startDurationTime = endDurationTime;
							}
						}else{
							sbQuery.setLength(0);
							sbQuery.append("Set work_mem = "+Constants.WORK_MEM_10_MB+";");
							sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as chartData from (select loadgen_name, (select region from lt_dynamic_load_agent_details where public_ip = dd.loadgen_name) as \"City\",(select array_to_json(array_agg(row_to_json(d))) from (select etime as \"Date\", etime as \"T\", count(etime) as \"Second count\", round(cast(min(diff) as numeric),3) as \"Min\", round(cast(avg(diff) as numeric),3) as \"Avg\", round(cast(avg(diff) as numeric),3) as \"Value\", round(cast(avg(diff) as numeric),3) as \"V\", round(cast(max(diff) as numeric),3) as \"Max\" from (select end_secs as etime,loadgen_name, script_id, page_id, sum(diff) as diff from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" group by 1,2,3,4 order by 1,2,3,4) as tmp where loadgen_name=dd.loadgen_name group by 1 order by 1) as d) as \"Data\" from lt_reportdata_");
							sbQuery.append(strReportId);
							sbQuery.append(" as dd group by 1 order by 1) as jsoncontent ");
						}
					}
				}
			}
			jsonString  = getLTChartData(con, sbQuery.toString());
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : "+ sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery );
			UtilsFactory.clearCollectionHieracy( sbCountQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	
	public JSONObject loadLoadTestLicenseDetails(Connection con, LoginUserBean userBean) {
		JSONObject LOAD_TEST_LICENSE_DETAILS = new JSONObject();
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rs = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			if (userBean.getLicense().equalsIgnoreCase("level0")) {
				sbQuery.append("SELECT * from lt_config_parameters where lt_license=?");
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setString(1, userBean.getLicense());
			} else {
				sbQuery.append("SELECT MAX(lt_max_vusers) as max_vusers, SUM(ulm.lt_max_run_per_day) as lt_max_run_per_day, ")
						.append("MAX(ulm.max_duration) as max_duration, MAX(max_iterations) as max_iterations FROM userwise_lic_monthwise ulm ")
						.append("INNER JOIN lt_config_parameters lcp ON lcp.lt_license = ulm.license_level ")
						.append("WHERE ulm.module_type = 'LT' and ulm.user_id = ? and ulm.start_date<= now() and ulm.end_date>=now()");
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setLong(1, userBean.getUserId());
			}
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				if (userBean.getLicense().equalsIgnoreCase("level0")) {
					LOAD_TEST_LICENSE_DETAILS.put("mode", "FREE");
				} else {
					LOAD_TEST_LICENSE_DETAILS.put("mode", "PAID");
				}
				LOAD_TEST_LICENSE_DETAILS.put("maxuser", rs.getInt("max_vusers"));
//				LOAD_TEST_LICENSE_DETAILS.put("maxruncount", rs.getInt("max_runs"));
				LOAD_TEST_LICENSE_DETAILS.put("maxruncountperday", rs.getInt("lt_max_run_per_day"));
				LOAD_TEST_LICENSE_DETAILS.put("maxduration", rs.getInt("max_duration"));
				LOAD_TEST_LICENSE_DETAILS.put("maxiteration", rs.getInt("max_iterations"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		
		return LOAD_TEST_LICENSE_DETAILS;
	}
	
	public long insertJmeterScenarioName(Connection con, String scenarioName, String strTestType, LTLicenseBean ltLicBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmtSelect = null, pstmtUpdate = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rst = null;
		boolean isExist = false; 
		
		long lScenarioId = -1L;
		Date dateLog = LogManager.logMethodStart();

		try {
			
//			if(ltLicBean == null) {
//				// License expired for user
//				throw new Exception("2");
//			} else {
				sbQuery.append("SELECT scenario_id FROM lt_scenario_master WHERE user_id = ? AND scenario_type = ? AND LOWER(scenario_name) = LOWER(?)");
				pstmtSelect = con.prepareStatement(sbQuery.toString());
				pstmtSelect.setLong(1, loginUserBean.getUserId());
				pstmtSelect.setString(2, strTestType);
				pstmtSelect.setString(3, scenarioName);
				rst = pstmtSelect.executeQuery();
				if( rst.next() ){
					sbQuery.setLength(0);
					sbQuery	.append("UPDATE lt_scenario_master SET scenario_name = ? ")
							.append("WHERE user_id = ? AND scenario_id = ? AND scenario_type = ?");
			
					pstmtUpdate = con.prepareStatement(sbQuery.toString());
					pstmtUpdate.setString(1, scenarioName);
					pstmtUpdate.setLong(2, loginUserBean.getUserId());
					pstmtUpdate.setLong(3, rst.getLong("scenario_id"));
					pstmtUpdate.setString(4, strTestType);
					
					pstmtUpdate.execute();
					isExist = true;
					lScenarioId = rst.getLong("scenario_id");
				}
				
				if( !isExist ){
					sbQuery.setLength(0);
					sbQuery.append("INSERT INTO lt_scenario_master (user_id, enterprise_id, scenario_type, scenario_name, created_on) VALUES (?, ?, ?, ?, now())");
					
					pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
					
					pstmt.setLong(1, loginUserBean.getUserId());
					if( loginUserBean.getEnterpriseId() == 0 ) {
						pstmt.setNull(2, Types.BIGINT);
					} else {
						pstmt.setLong(2, loginUserBean.getEnterpriseId());	
					}
					pstmt.setString(3, strTestType);
					pstmt.setString(4, scenarioName);
					pstmt.executeUpdate();
					
					lScenarioId = DataBaseManager.returnKey(pstmt);
				}

//			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmtSelect);
			pstmtSelect = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
		return lScenarioId;
	}
	
	public long insertJmeterScriptName(Connection con, String scriptName, String strTestType, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmtSelect = null, pstmtUpdate = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rst = null;
		boolean isExist = false; 
		
		long lScriptId = -1L;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT script_id FROM lt_script_master WHERE user_id = ? AND script_type = ? AND LOWER(script_name) = LOWER(?)");
			pstmtSelect = con.prepareStatement(sbQuery.toString());
			pstmtSelect.setLong(1, loginUserBean.getUserId());
			pstmtSelect.setString(2, strTestType);
			pstmtSelect.setString(3, scriptName);
			rst = pstmtSelect.executeQuery();
			if( rst.next() ){
				sbQuery.setLength(0);
				sbQuery	.append("UPDATE lt_script_master SET script_name = ? ")
						.append("WHERE user_id = ? AND script_id = ? AND script_type = ?");
		
				pstmtUpdate = con.prepareStatement(sbQuery.toString());
				pstmtUpdate.setString(1, scriptName);
				pstmtUpdate.setLong(2, loginUserBean.getUserId());
				pstmtUpdate.setLong(3, rst.getLong("script_id"));
				pstmtUpdate.setString(4, strTestType);
				
				pstmtUpdate.execute();
				isExist = true;
				lScriptId = rst.getLong("script_id");
			}
			
			if( !isExist ){
				sbQuery.setLength(0);
				sbQuery .append("INSERT INTO lt_script_master (user_id, script_name, script_type, created_by, created_on, enterprise_id) VALUES (?, ?, ?, ?, now(), ?) ");
				
				pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
				
				pstmt.setLong(1, loginUserBean.getUserId());
				pstmt.setString(2, scriptName);
				pstmt.setString(3, strTestType);
				pstmt.setLong(4, loginUserBean.getUserId());
				if( loginUserBean.getEnterpriseId() == 0 ) {
					pstmt.setNull(5, Types.BIGINT);
				} else {
					pstmt.setLong(5, loginUserBean.getEnterpriseId());	
				}
				
				pstmt.executeUpdate();
				
				lScriptId = DataBaseManager.returnKey(pstmt);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmtSelect);
			pstmtSelect = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
		return lScriptId;
	}
	
	/**
	 * gets counter data with date range,
	 * tried breakCounterSet, if diff of runStartTime & runEndTime is <= `1 hour`, instead of maxTS 
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounters
	 * @param strMaxTimeStamp
	 * @param strFromStartInterval
	 * @param strStartTime
	 * @param strEndTime
	 * @param strRunTime
	 * @param bMiniChartRequest
	 * @return
	 * @throws Exception
	 */
	public JSONObject getCountersForLoadTest(Connection con, String strGUID, String strCounters, String strMaxTimeStamp, String strFromStartInterval ,String strStartTime, String strEndTime, String strRunTime, boolean bMiniChartRequest) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");

		JSONObject joResult = new JSONObject(), joCountersException = new JSONObject();
		JSONObject joDatum = null;

		ArrayList<JSONObject> alCounterSet = null;
		ArrayList<ArrayList<JSONObject>> alCounterValues = new ArrayList<ArrayList<JSONObject>>();

		LinkedHashMap<Long, ArrayList<ArrayList<JSONObject>>> lmCountersTypeData = new LinkedHashMap<Long, ArrayList<ArrayList<JSONObject>>>();
		HashMap<String, Long> hmTimeDiff = null;
		
		//String strAgentException = "";

		Double dChartValueY = null;

		Long lCounterId = -1L;

		long lTime = -1L;
		long lPrevTime = -1L, lDuration = -1L, lDiffInMinutes = -1L;
		long lStartTime = -1L, lEndTime = -1L;
		
		//long lEpochTime = -1L;
		
		boolean bBreakCounterSet = false;
		Date dateLog = LogManager.logMethodStart();

		try {
			if(Integer.parseInt(strRunTime)==0){
				strEndTime = sdf.format(new Date());
			}
			// tried breakCounterSet, if diff of runStartTime & runEndTime is <= `1 hour`, instead of maxTS
			lStartTime = UtilsFactory.formatTimestampToLong_yyyMMMddHHmmss(strStartTime);
			lEndTime = UtilsFactory.formatTimestampToLong_yyyMMMddHHmmss(strEndTime);
			hmTimeDiff = UtilsFactory.calcDateDiffInMilliSeconds(lStartTime, lEndTime);
			// 1 refers to `1 hour`
			if ( hmTimeDiff.get("HOURS") <= Constants.COUNTER_CHART_HOUR_INTERVAL) {
				bBreakCounterSet = true;
			}

			sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_date_range('")
					.append(strGUID).append("', '").append(strMaxTimeStamp).append("', '")
					.append(strCounters).append("', '").append(strFromStartInterval).append("', '")
					.append(strStartTime).append("', '").append(strEndTime).append("') ");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				lCounterId = rst.getLong("counter_type");

				lTime = rst.getTimestamp("received_on_timestamp").getTime();
				//lEpochTime = (long) (rst.getDouble("epoch_appedo_received_on") * 1000);
				
				// `T` is time (x-axis) & `V` is value (y-axis) 
				joDatum = new JSONObject();
				joDatum.put("T", lTime);
				dChartValueY = rst.getDouble("counter_value");
				joDatum.put("V", dChartValueY.longValue());
				
				// for multiple counters
				if (lmCountersTypeData.containsKey(lCounterId)) {
					alCounterValues = lmCountersTypeData.get(lCounterId);
					
					// to break counters set for last 1 hour data, 
					if ( bBreakCounterSet ) {
						lDuration = lTime - lPrevTime;
						lDiffInMinutes = TimeUnit.MILLISECONDS.toMinutes(lDuration);
						
						// If there the time difference between current & previous is more than 1 minute, then store the datum in a new Array
						if( lDiffInMinutes > Constants.COUNTER_CHART_TIME_INTERVAL ) {
							alCounterSet = new ArrayList<JSONObject>();
							
							alCounterValues.add(alCounterSet);
						} else {
							alCounterSet = alCounterValues.get(alCounterValues.size() - 1);
						}
					} else {
						// for other than interval `1 hour`
						alCounterSet = alCounterValues.get(alCounterValues.size() - 1);
					}
				} else {
					alCounterValues = new ArrayList<ArrayList<JSONObject>>();
					alCounterSet = new ArrayList<JSONObject>();
					
					alCounterValues.add(alCounterSet);
				}
				alCounterSet.add(joDatum);
				
				lmCountersTypeData.put(lCounterId, alCounterValues);

				lPrevTime = lTime;
				
				// exception to add for counter and agent
				joCountersException.put(lCounterId, rst.getString("counter_exception"));
				//strAgentException = rst.getString("agent_exception");
			}

			/*
			 * since order by asc, last value of `lTime` sets as maxTimestamp, 
			 * ( Note: since mostly in all places multiple counters data is not retrieved, 
			 *    if multiple counters are retrieve, maxTimestamp logic to revised, 
			 *   based on respective counter's maxTimestamp to get & in query also have to change for respective counter > maxts
			 * )
			 * 
			 */
			/*//if ( lTime != -1 ) {
			if ( lEpochTime != -1 ) {
				//lMaxTimeStamp = lTime;
				lMaxTimeStamp = lEpochTime;
			}*/

			//joResult.put("max_recieved_on", lMaxTimeStamp);
			joResult.put("guid", strGUID);
			joResult.put("chartdata", lmCountersTypeData);
			joResult.put("countersException", joCountersException);
		} catch (Exception e) {
			LogManager.infoLog("sbQuery: " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}

		return joResult;
	}

	public String getCountersForLoadTest(Connection con, String strGUID, String strCounters, String startTime, String endTime, String runTime, String queryDuration, String selectedTime, String status) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		long startDurationTime = UtilsFactory.convertMilliSecondsToSeconds(Long.parseLong(startTime));
		long endDurationTime = UtilsFactory.convertMilliSecondsToSeconds(Long.parseLong(endTime));
		long selectedTimeInSeconds = UtilsFactory.convertMilliSecondsToSeconds(Long.parseLong(selectedTime));
//		Long selectedTimeInSeconds = Long.parseLong(selectedTime);
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
			if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_HOUR)){
				if(status.equalsIgnoreCase(Constants.LOAD_TEST_RUNNING)){
					sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
					.append(strGUID).append("', '").append(strCounters).append("', '").append("cast((extract('epoch' from date_trunc('hour', now() at time zone 'utc'))-(60*60)) as character)").append("', '")
					.append("cast(extract('epoch' from date_trunc('hour', now() at time zone 'utc')) as character)").append("', '").append("minute").append("') ");
				}else{
					if(UtilsFactory.checkRunTimeLessThanGivenHour(Constants.LT_RUNTIME_CHECK_HOUR, runTime)){
						if(UtilsFactory.checkRunTimeLessThanGivenMinute(Constants.LT_RUNTIME_CHECK_MINUTE, runTime)){
							sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
							.append(strGUID).append("', '").append(strCounters).append("', '").append(startDurationTime).append("', '")
							.append(endDurationTime).append("', '").append("minute").append("') ");
						}else{
							sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
							.append(strGUID).append("', '").append(strCounters).append("', '").append(startDurationTime).append("', '")
							.append(endDurationTime).append("', '").append("second").append("') ");
						}
					}else{
						sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
						.append(strGUID).append("', '").append(strCounters).append("', '").append(startDurationTime).append("', '")
						.append(endDurationTime).append("', '").append("hour").append("') ");
					}
				}
			}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_MINS)){
				if(Long.parseLong(selectedTime)>0){
					sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
					.append(strGUID).append("', '").append(strCounters).append("', '").append(selectedTimeInSeconds).append("', '")
					.append(selectedTimeInSeconds+(60*60)).append("', '").append("minute").append("') ");
				}else{
					sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
					.append(strGUID).append("', '").append(strCounters).append("', '").append(startDurationTime).append("', '")
					.append(endDurationTime).append("', '").append("minute").append("') ");
				}
			}else if(queryDuration.equalsIgnoreCase(Constants.LOAD_TEST_CHART_SECS)){
				if(Long.parseLong(selectedTime)>0){
					sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
					.append(strGUID).append("', '").append(strCounters).append("', '").append(selectedTimeInSeconds).append("', '")
					.append(selectedTimeInSeconds+60).append("', '").append("second").append("') ");
				}else{
					sbQuery	.append("SELECT * FROM get_apm_monitor_counters_data_with_epoch_range('")
					.append(strGUID).append("', '").append(strCounters).append("', '").append(startDurationTime).append("', '")
					.append(endDurationTime).append("', '").append("second").append("') ");
				}
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				jsonString = UtilsFactory.convertStringtoJSON(jsonString, rs.getString("apmChartData"));
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public LTLicenseBean getLTUserWiseLicenseMonthWise(Connection con, LoginUserBean loginUserBean) throws Exception {
		LTLicenseBean ltLicBean = null;
		PreparedStatement pstmt = null, pstmt1 = null;
		ResultSet rst = null, rst1 = null;
		
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
//			if( ! loginUserBean.getLtLicense().equals("level0") ) {
				// For PAID user
//				sbQuery	.append("SELECT user_id, start_date, end_date, lt_max_vusers ")
//						.append("FROM userwise_lic_monthwise ")
//						.append("WHERE user_id = ? AND module_type = 'LT' ")
//						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
//			} else {
				// For FREE user
//				sbQuery	.append("SELECT user_id, apm_lic_start_date AS start_date, apm_lic_end_date AS end_date, lt_max_vusers ")
//						.append("FROM usermaster ")
//						.append("WHERE user_id = ? ")
//						.append("AND apm_lic_start_date::date <= now()::date AND lt_lic_end_date::date >= now()::date ");
//			}
			
			sbQuery	.append("SELECT MIN(start_date) AS start_date, MAX(end_date) AS end_date, SUM(lt_max_vusers) AS lt_max_vusers, SUM(lt_max_run_per_day) AS lt_max_run_per_day ")
					.append("FROM userwise_lic_monthwise ")
					.append("WHERE user_id = ? AND module_type = 'LT' ")
					.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				ltLicBean = new LTLicenseBean();
				
				ltLicBean.setUserId(loginUserBean.getUserId());
				ltLicBean.setStartDate(rst.getString("start_date"));
				ltLicBean.setEndDate(rst.getString("end_date"));
				ltLicBean.setMaxVusers(rst.getInt("lt_max_vusers"));
				ltLicBean.setMaxRunsPerDay(rst.getInt("lt_max_run_per_day"));
				
				LTLicenseBean ltLicBean1 = getLTLicenseConfigParameters(con, loginUserBean.getLicense());
				
				ltLicBean.setLicInternalName(ltLicBean1.getLicInternalName());
				ltLicBean.setLicExternalName(ltLicBean1.getLicExternalName());
				ltLicBean.setMaxIterations(ltLicBean1.getMaxIterations());
				ltLicBean.setMaxRuns(ltLicBean1.getMaxRuns());
				ltLicBean.setMaxDuration(ltLicBean1.getMaxDuration());
				ltLicBean.setReportRetentionPeriod(ltLicBean1.getReportRetentionPeriod());
				
			}else{
				sbQuery.setLength(0);
				sbQuery	.append("SELECT created_on AS start_date, lt_max_vusers, lt_max_run_per_day ")
						.append("FROM usermaster ")
						.append("WHERE user_id = ? ");
				pstmt1 = con.prepareStatement(sbQuery.toString());
				pstmt1.setLong(1, loginUserBean.getUserId());
				rst1 = pstmt1.executeQuery();
				if( rst1.next() ) {
					ltLicBean = new LTLicenseBean();
					
					ltLicBean.setUserId(loginUserBean.getUserId());
					ltLicBean.setStartDate(rst1.getString("start_date"));
					ltLicBean.setMaxVusers(rst1.getInt("lt_max_vusers"));
					ltLicBean.setMaxRunsPerDay(rst1.getInt("lt_max_run_per_day"));
					
					LTLicenseBean ltLicBean1 = getLTLicenseConfigParameters(con, "level0");
					
					ltLicBean.setLicInternalName(ltLicBean1.getLicInternalName());
					ltLicBean.setLicExternalName(ltLicBean1.getLicExternalName());
					ltLicBean.setMaxIterations(ltLicBean1.getMaxIterations());
					ltLicBean.setMaxRuns(ltLicBean1.getMaxRuns());
					ltLicBean.setMaxDuration(ltLicBean1.getMaxDuration());
					ltLicBean.setReportRetentionPeriod(ltLicBean1.getReportRetentionPeriod());
				}
			}
		}catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return ltLicBean;
	}
	
	public LTLicenseBean getLTLicenseConfigParameters(Connection con, String strLtLicense) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		LTLicenseBean ltLicBean = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT * ")
					.append("FROM lt_config_parameters ")
					.append("WHERE lt_license = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strLtLicense);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				ltLicBean = new  LTLicenseBean();
				
				ltLicBean.setLicInternalName(rst.getString("lt_license"));
				ltLicBean.setLicExternalName(rst.getString("lic_external_name"));
				ltLicBean.setMaxIterations(rst.getInt("max_iterations"));
				ltLicBean.setMaxRuns(rst.getInt("max_runs"));
				ltLicBean.setMaxDuration(rst.getInt("max_duration"));
				ltLicBean.setReportRetentionPeriod(rst.getInt("report_retention_period"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return ltLicBean;
	}
	
	public JSONArray getScriptDetails(Connection con, long scenarioId) throws Throwable {
		StringBuilder sbQuery = new StringBuilder();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject joScript = null;
		JSONArray jaScriptDetails = new JSONArray();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery .append("SELECT sc.script_id AS scriptId, sc.script_name AS scriptName FROM lt_scenario_script_mapping sm ")
					.append("INNER JOIN lt_script_master sc ON sc.script_id = sm.script_id AND sm.created_by = sc.user_id ")
					.append("WHERE scenario_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, scenarioId);
			rst = pstmt.executeQuery();
			
			while(rst.next()) {
				joScript = new JSONObject();
				joScript.put("scriptId", rst.getLong("scriptId"));
				joScript.put("scriptName", rst.getString("scriptName"));
				jaScriptDetails.add(joScript);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close( rst );
			rst = null;
			DataBaseManager.close( pstmt );
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jaScriptDetails;
	}
	
	public int getUserMaxRunCount(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		int nUserTotalRuncount = 0;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT count(*) as user_total_runcount ")
					.append("FROM tblreportmaster ")
					.append("WHERE userid = ? AND created_on BETWEEN date_trunc('month', CURRENT_DATE) AND date_trunc('month', CURRENT_DATE) + interval '1month' - interval '1day' ")
					.append("GROUP BY userid ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				nUserTotalRuncount = rst.getInt("user_total_runcount");
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
		return nUserTotalRuncount;
	}
	
	public int getUserMaxRunCountPerDay(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		int nUserTotalRuncountPerDay = 0;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT count(*) as user_total_runcount_perday ")
					.append("FROM tblreportmaster ")
					.append("WHERE userid = ? AND created_on BETWEEN date_trunc('day', CURRENT_DATE) AND date_trunc('day', CURRENT_DATE) + interval '1day' - interval '1sec' ")
					.append("GROUP BY userid ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				nUserTotalRuncountPerDay = rst.getInt("user_total_runcount_perday");
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
//			rst = null;
			DataBaseManager.close(pstmt);
//			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
		return nUserTotalRuncountPerDay;
	}
	public JSONObject isUserRunningScenario(Connection con, LoginUserBean loginUserBean, String strTestType ) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joUserRunningScenario = new JSONObject();
		Date dateLog = LogManager.logMethodStart();

		try {
			
			sbQuery	.append("SELECT * FROM tblreportmaster ")
			.append("WHERE  userid = ? AND is_active = true ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				joUserRunningScenario.put("scenarioname", rst.getString("scenarioname"));
				joUserRunningScenario.put("isActive", rst.getBoolean("is_active"));
				joUserRunningScenario.put("runid", rst.getString("runid"));
				joUserRunningScenario.put("createduser", rst.getString("createduser"));
				joUserRunningScenario.put("completeduser", rst.getString("completeduser"));
				joUserRunningScenario.put("status", rst.getString("status"));
				joUserRunningScenario.put("runstarttime", rst.getString("runstarttime"));
				joUserRunningScenario.put("runendtime", rst.getString("runendtime"));
				joUserRunningScenario.put("reportName", rst.getString("reportname"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		
		return joUserRunningScenario;
	}
	
	public boolean isReportNameExist(Connection con, LoadTestSchedulerBean schedulerBean){
		boolean bExist = false;
		PreparedStatement pstmt = null;
		StringBuffer sbQuery = null;
		ResultSet rst = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery = new StringBuffer();
			
			sbQuery	.append("SELECT true from tblreportmaster  where lower(reportname)=LOWER(?) AND userid=?  AND is_deleted=false");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, schedulerBean.getReportName());
			pstmt.setLong(2, schedulerBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()){
				bExist = true;
			}else{
				bExist = false;
			}
			
		} catch(Exception e){
			LogManager.errorLog(e);
		} finally {
			LogManager.logMethodEnd(dateLog);
		}
		return bExist;
	}
	
	public long  insertIntoReportMaster(Connection con, LTLicenseBean ltLicBean, LoadTestSchedulerBean schedulerBean) throws Throwable {
		
		PreparedStatement pstmt = null, pstmtLog = null, pstmtError = null, pstmtReport = null, pstmtTrans = null;
		StringBuilder sbQuery = new StringBuilder();
		long lRunId = -1L;
		Date dateLog = LogManager.logMethodStart();

		try	{
			sbQuery .append("INSERT INTO tblreportmaster (userid,reportname,reporttype,scenarioname,created_by,created_on, is_active, runstarttime, scenario_id, runtype, start_monitor_in_mins, end_monitor_in_mins ) ")
					.append("VALUES (?, ?, ?, ?, ?, now(), true, now(), ?, ?, ?, ?) ");
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);

			pstmt.setLong(1, schedulerBean.getUserId());
			pstmt.setString(2, schedulerBean.getReportName());
			pstmt.setString(3, schedulerBean.getTestType());
			pstmt.setString(4, schedulerBean.getScenarioName());
			pstmt.setLong(5, schedulerBean.getUserId());
			pstmt.setLong(6, Long.valueOf(schedulerBean.getScenarioId()));
			pstmt.setString(7, schedulerBean.getRunType());
			pstmt.setInt(8, schedulerBean.getStartMonitor());
			pstmt.setInt(9, schedulerBean.getEndMonitor());
			
			pstmt.executeUpdate();

			lRunId = DataBaseManager.returnKey(pstmt);

			sbQuery = new StringBuilder();
			sbQuery.append("SELECT lt_logs_table_partitions(?)");
			pstmtReport = con.prepareStatement(sbQuery.toString());
			pstmtReport.setLong(1, lRunId);
			pstmtReport.execute();
		}
		catch(Throwable t) {
			LogManager.errorLog(t);
			throw t;
		}finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtLog);
			pstmtLog = null;
			DataBaseManager.close(pstmtError);
			pstmtError = null;
			DataBaseManager.close(pstmtReport);
			pstmtReport = null;
			DataBaseManager.close(pstmtTrans);
			pstmtTrans = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return lRunId;
	}

	public void updatePrivateCounters(Connection con, String columnName, long queueValue) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {

			sbQuery.append("UPDATE appedo_pvt_counters SET " + columnName + "=?, lt_exec_status = true");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, queueValue);

			pstmt.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public void insertAgentMapping(Connection con, String guids, long runId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("INSERT INTO lt_run_agent_mapping (lt_run_id, guid) VALUES (?, ?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			for ( String guid:guids.split(",")){
				pstmt.setLong(1, runId);
				pstmt.setString(2, guid);	
				pstmt.addBatch();
			}
			
			pstmt.executeBatch();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public void updateProcessServiceFailed(Connection con, String status, long runId) throws Exception{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("update tblreportmaster set is_active=false, status='FAILED', runendtime=NOW(), notes=? where runid = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, status);
			pstmt.setLong(2, runId);
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public String getLTChartData(Connection con,String query) throws Exception{
		Statement stmt = null;
		ResultSet rst = null;
		String jsonString = null;
		Date dateLog = LogManager.logMethodStart();

		try{
			String[] queries = query.split("\\"+Constants.QUERY_STRING_SEPARATOR);
			for(int jLoop=0; jLoop< queries.length; jLoop++)
			{
				String[] qu = queries[jLoop].split("\\;");
				stmt = con.createStatement();
				stmt.execute(qu[0]);
				rst = stmt.executeQuery(qu[1]);
				if(rst.next()) {
					jsonString = UtilsFactory.convertStringtoJSON(jsonString, rst.getString("chartData"));
				}			
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( query );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}
	
	public Map<String, Object> getLTCountData(Connection con,String query) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rst = null;
        Map<String, Object> resultMap=new HashMap<>();
        Date dateLog = LogManager.logMethodStart();

		try{
			pstmt = con.prepareStatement(query);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				resultMap.put("status", true);
				resultMap.put("totalCount",rst.getLong("total_count"));
				resultMap.put("startDurationTime",rst.getLong("min_value"));
				resultMap.put("endDurationTime",rst.getLong("max_value"));
			}
		} catch (Exception e) {
			resultMap.put("status", false);
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( query );
			LogManager.logMethodEnd(dateLog);
		}
		return resultMap;
	}

	public Boolean checkEndTimeFormatForExistingTest(Connection con, String strReportId) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean outputStatus = false;
		Date dateLog = LogManager.logMethodStart();

		try{
			sbQuery.append("Select end_hrs,end_mins,end_secs from lt_reportdata_");
			sbQuery.append(strReportId);
			sbQuery.append(" Limit 1");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				outputStatus = true;
			}
		} catch (Exception e) {
			outputStatus = false;
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			LogManager.logMethodEnd(dateLog);
		}
		return outputStatus;
	}
	
	public Boolean runEndTimeFormatForExistingTest(Connection con, String strReportId) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean outputStatus = false;
		Date dateLog = LogManager.logMethodStart();

		try{
			sbQuery.append("SELECT * from summary_chart_for_existing_users(");
			sbQuery.append(strReportId);
			sbQuery.append(")");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				outputStatus = rst.getBoolean("summary_chart_for_existing_users");
			}	
		} catch (Exception e) {
			outputStatus = false;
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			LogManager.logMethodEnd(dateLog);
		}
		return outputStatus;
	}
	

	public String getLTSummaryData(Connection con,String query) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String jsonString = null;
		Date dateLog = LogManager.logMethodStart();

		try{
			pstmt = con.prepareStatement(query);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("summaryReport");
			}			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( query );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}
	
	public String getMasterSummaryReport(Connection con, long runId, long userId, String strTestType) throws Exception {
		String jsonString = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT * ")
					.append("FROM summary_report_for_load_test(")
					.append(runId)
					.append(")");
			jsonString = getLTSummaryData(con,sbQuery.toString());
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	
	public String getLTScenarioReports(Connection con, String scenarioId, String strTestType, long userId) throws Exception {
		StringBuilder sbQuery = new StringBuilder();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String jsonString = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			// TODO: ASK, in while loop, corrections added indent corrections col. `scenarioname` added; thinks can reuse of `/lt/getScenarioReports`
			sbQuery	.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as \"runDropDown\" from ( ")
					.append("  SELECT runid AS \"reportId\", reportname as \"reportName\", status, '").append(strTestType).append("' AS \"testType\", ")
					.append("    scenarioname AS \"scenarioname\", start_monitor_in_mins AS \"startMonitor\", end_monitor_in_mins AS \"endMonitor\" ")
					.append("  FROM tblreportmaster ")
					.append("  WHERE scenario_id = ? AND reporttype = ? AND userid = ? ")
					.append("  ORDER BY 1 DESC ")
					.append(") as jsoncontent");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, Long.parseLong(scenarioId));
			pstmt.setString(2, strTestType);
			pstmt.setLong(3, userId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("runDropDown");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getselectedReportRunStartAndEndTime(Connection con, long runid, String strTestType, long userId) throws Exception {
		StringBuilder sbQuery = new StringBuilder();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String jsonString = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
			sbQuery.append("select array_to_json(array_agg(row_to_json(jsoncontent))) as \"runDuration\" from (Select min(runtime) as \"runStartTime\", max(runtime)as \"runEndTime\", max(runtime)-min(runtime) as \"runTime\" from lt_user_runtime_"+runid+") as jsoncontent");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("runDuration");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}
	
	public String getselectedReportGuid(Connection con, long runid, String strTestType, long userId) throws Exception {
		StringBuilder sbQuery = new StringBuilder();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String jsonString = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.setLength(0);
//			sbQuery.append("SELECT guid FROM lt_run_agent_mapping WHERE lt_run_id = ?");
			sbQuery.append("SELECT group_concat(guid) as guids FROM lt_run_agent_mapping WHERE lt_run_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, runid);
			rst = pstmt.executeQuery();
			if(rst.next()) {
//				jsonString = rst.getString("guid");
				jsonString = rst.getString("guids");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getScriptSummaryReport(Connection con, String runId, String strTestType,String scriptId) throws Exception {
		String jsonString = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("select row_to_json(t) as \"summaryReport\" from (select script_name as \"scriptName\",t1.script_id as \"scriptId\", max(hits) as \"hits\", sum(tput_mb) as \"tPutInMb\", min(min_ms) as \"minInMs\",ROUND(CAST( avg(avg_ms) as numeric),0) as  \"avgInMs\", max(max_ms) as \"maxInMs\", max(max98_ms) as \"max98InMs\", max(max95_ms) as \"max95InMs\", max(max90_ms) as \"max90InMs\",min(min_ms_tt) as \"minTTInMs\", ROUND(CAST(avg(avg_ms_tt) as numeric),3) as \"avgTTInMs\", max(max_ms_tt) as \"maxTTInMs\", max(max98_ms_tt) as \"max98TTInMs\", max(max95_ms_tt) as \"max95TTInMs\", max(max90_ms_tt) as \"max90TTInMs\", (CASE WHEN SUM(err_400) IS NULL THEN 0 ELSE SUM(err_400) END) as \"error400\", (CASE WHEN SUM(err_500) IS NULL THEN 0 ELSE SUM(err_500) END) as \"error500\", (CASE WHEN SUM(err_700) IS NULL THEN 0 ELSE SUM(err_700) END) as \"error700\"  from lt_rep_script_cont_summary_")
				.append(runId)
				.append(" as t1 join lt_script_master as t2 on t1.script_id=t2.script_id where t1.script_id IN (")
				.append(scriptId)
				.append(") group by t1.script_id,t2.script_name order by 1) t ");
			jsonString = getLTSummaryData(con,sbQuery.toString());
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}
	
	public String getSummaryDataForRequestResponse(Connection con, String runId, String strTestType,String scriptId) throws Exception {
		String jsonString = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();
		
		try {
//			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select script_name as \"scriptName\", request_id as \"requestId\", address as  \"address\", sum(hits) as \"hits\", sum(tput_mb) as \"tPutInMb\", min(min_ms) as \"minInMs\", ROUND(CAST( avg(avg_ms) as numeric),0) as \"avgInMs\", max(max_ms) as \"maxInMs\", max(max98_ms) as \"Max98InMs\", max(max95_ms) as \"Max95InMs\", max(max90_ms) as \"Max90InMs\", coalesce(err_400,'0') as \"error400\", coalesce(err_500,'0') as \"error500\", coalesce(err_700,'0') as \"error700\"  from lt_rep_script_request_summary_")
//				.append(runId)
//				.append(" as t1 join lt_script_master as t2 on t1.script_id=t2.script_id where t1.script_id=")
//				.append(scriptId)
//				.append(" group by t1.script_id,t2.script_name ,request_id, address,err_400, err_500, err_700 order by 1,2) t ");
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select container_id as \"containerId\",container_name  as \"containerName\",request_id as \"requestId\", address as  \"address\", sum(hits) as \"hits\", sum(tput_mb) as \"tPutInMb\", min(min_ms) as \"minInMs\", ROUND(CAST( avg(avg_ms) as numeric),0) as \"avgInMs\", max(max_ms) as \"maxInMs\", max(max98_ms) as \"Max98InMs\", max(max95_ms) as \"Max95InMs\", max(max90_ms) as \"Max90InMs\", SUM(coalesce(err_400,'0')) as \"error400\", SUM(coalesce(err_500,'0')) as \"error500\", SUM(coalesce(err_700,'0')) as \"error700\"  from lt_rep_script_request_summary_")
				.append(runId)
				.append(" where script_id=")
				.append(scriptId)
				.append(" group by script_id ,container_id,container_name,request_id, address order by script_id ,container_id,container_name,request_id) t ");
			jsonString = getLTSummaryData(con,sbQuery.toString());
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getSummaryDataForContainerResponse(Connection con, String runId, String strTestType,String scriptId) throws Exception {
		String jsonString = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
//			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select script_name as \"scriptName\", container_name as \"containerName\", sum(hits) as \"hits\", sum(tput_mb) as \"tPutInMb\", min(min_ms) as \"minInMs\",ROUND(CAST( avg(avg_ms) as numeric),0) as  \"avgInMs\", max(max_ms) as \"maxInMs\", max(max98_ms) as \"max98InMs\", max(max95_ms) as \"max95InMs\", max(max90_ms) as \"max90InMs\",min(min_ms_tt) as \"minTTInMs\", ROUND(CAST(avg(avg_ms_tt) as numeric),0) as \"avgTTInMs\", max(max_ms_tt) as \"maxTTInMs\", max(max98_ms_tt) as \"max98TTInMs\", max(max95_ms_tt) as \"max95TTInMs\", max(max90_ms_tt) as \"max90TTInMs\", (CASE WHEN SUM(err_400) IS NULL THEN 0 ELSE SUM(err_400) END) as \"error400\", (CASE WHEN SUM(err_500) IS NULL THEN 0 ELSE SUM(err_500) END) as \"error500\", (CASE WHEN SUM(err_700) IS NULL THEN 0 ELSE SUM(err_700) END) as \"error700\"  from lt_rep_script_cont_summary_")
//				.append(runId)
//				.append(" as t1 join lt_script_master as t2 on t1.script_id=t2.script_id where t1.script_id= ")
//				.append(scriptId)
//				.append(" group by t1.script_id,t2.script_name,container_name order by 1,2) t");
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select  min(row_id) as \"Serial\" , container_name as \"containerName\", max(hits) as \"hits\", sum(tput_mb) as \"tPutInMb\", min(min_ms) as \"minInMs\",ROUND(CAST( avg(avg_ms) as numeric),0) as  \"avgInMs\", max(max_ms) as \"maxInMs\", max(max98_ms) as \"max98InMs\", max(max95_ms) as \"max95InMs\", max(max90_ms) as \"max90InMs\",min(min_ms_tt) as \"minTTInMs\", ROUND(CAST(avg(avg_ms_tt) as numeric),0) as \"avgTTInMs\", max(max_ms_tt) as \"maxTTInMs\", max(max98_ms_tt) as \"max98TTInMs\", max(max95_ms_tt) as \"max95TTInMs\", max(max90_ms_tt) as \"max90TTInMs\", (CASE WHEN SUM(err_400) IS NULL THEN 0 ELSE SUM(err_400) END) as \"error400\", (CASE WHEN SUM(err_500) IS NULL THEN 0 ELSE SUM(err_500) END) as \"error500\", (CASE WHEN SUM(err_700) IS NULL THEN 0 ELSE SUM(err_700) END) as \"error700\"  from lt_rep_script_cont_summary_")
				.append(runId)
				.append(" where script_id= ")
				.append(scriptId)
				.append(" group by script_id,container_name order by 1) t");
			jsonString = getLTSummaryData(con,sbQuery.toString());
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getSummaryDataForTransactionResponse(Connection con, String runId, String strTestType,String scriptId) throws Exception {
		String jsonString = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
//			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select script_name as \"scriptName\", transaction_name as \"transactionName\", min(min_ms_tt) as \"minTTInMs\", ROUND(CAST(avg(avg_ms_tt) as numeric),0) as \"avgTTInMs\", max(max_ms_tt) as \"maxTTInMs\", max(max98_ms_tt) as \"max98TTInMs\", max(max95_ms_tt) as \"max95TTInMs\", max(max90_ms_tt) as \"max90TTInMs\" from lt_rep_trans_summary_")
//				.append(runId)
//				.append(" as t1 join lt_script_master as t2 on t1.script_id=t2.script_id where t1.script_id= ")
//				.append(scriptId)
//				.append(" group by 1,2 order by 1,2) t");
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select transaction_name as \"transactionName\", min(min_ms_tt) as \"minTTInMs\", ROUND(CAST(avg(avg_ms_tt) as numeric),0) as \"avgTTInMs\", max(max_ms_tt) as \"maxTTInMs\", max(max98_ms_tt) as \"max98TTInMs\", max(max95_ms_tt) as \"max95TTInMs\", max(max90_ms_tt) as \"max90TTInMs\" from lt_rep_trans_summary_")
				.append(runId)
				.append(" where script_id= ")
				.append(scriptId)
				.append(" group by 1 order by 1) t");
			jsonString = getLTSummaryData(con,sbQuery.toString());
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}
	
	public String getSummaryDataForErrorCount(Connection con, String runId, String strTestType,String scriptId) throws Exception {
		String jsonString = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
//			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select script_name as \"scriptName\", message as  \"message\", sum(msg_cnt) \"count\" from lt_rep_error_msg_summary_")
//				.append(runId)
//				.append(" as t1 join lt_script_master as t2 on t1.script_id=t2.script_id where t1.script_id= ")
//				.append(scriptId)
//				.append(" group by 1,2 order by 1,2) t");
//			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select message as  \"message\", sum(msg_cnt) \"count\" from lt_rep_error_msg_summary_")
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select container_id as \"containerId\",container_name  as \"containerName\",message as  \"message\", count(lt_error_id) as \"count\" from lt_error_")
				.append(runId)
				.append(" where scriptid= ")
				.append(scriptId)
				.append(" group by 1,2,3 order by 1,2,3) t");
			jsonString = getLTSummaryData(con,sbQuery.toString());
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}

	public String getSummaryDataForErrorDescription(Connection con, String runId, String strTestType,String scriptId) throws Exception {
		String jsonString = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"summaryReport\" from (select container_id as \"containerId\",container_name  as \"containerName\",errorcode as \"errorCode\", message as  \"message\", count(lt_error_id) as \"count\" from lt_error_")
			.append(runId)
			.append(" WHERE scriptid= ")
			.append(scriptId)
			.append(" group by 1,2,3,4 order by 1,2,3,4) t");
			jsonString = getLTSummaryData(con,sbQuery.toString());
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonString;
	}


	public void updateReportMaster(Connection con, long lRunId, String status ) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			
			sbQuery	.append("update tblreportmaster SET is_active=false, status=?")
					.append(" WHERE runid = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, status);
			pstmt.setLong(2, lRunId);
			pstmt.execute();
			UtilsFactory.clearCollectionHieracy( sbQuery );
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			LogManager.logMethodEnd(dateLog);
		}
	}

	public void updateManualReportRuntime(Connection con, long lRunId, long reportRunTime ) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			
			sbQuery	.append("update tblreportmaster SET rpt=?")
					.append(" WHERE runid = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, reportRunTime);
			pstmt.setLong(2, lRunId);
			pstmt.execute();
			UtilsFactory.clearCollectionHieracy( sbQuery );
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			LogManager.logMethodEnd(dateLog);
		}
	}

	public boolean manualSummaryReportPreparationScriptwiseContainerwiseResponse(Connection con, long lRunId) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean status = false;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT * FROM summary_report_preparation_scriptwise_containerwise_response(?) ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				status = rst.getBoolean("summary_report_preparation_scriptwise_containerwise_response");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close( pstmt );
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return status;
	}

	public boolean manualSummaryReportGenerationScriptwiseContainerwiseResponse(Connection con, long lRunId) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean status = false;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT * FROM summary_report_generation_scriptwise_containerwise_response(?) ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				status = rst.getBoolean("summary_report_generation_scriptwise_containerwise_response");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close( pstmt );
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return status;
	}

	public boolean manualSummaryReportPreparationTransactionError(Connection con, long lRunId) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean status = false;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT * FROM summary_report_preparation_transaction_error(?) ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				status = rst.getBoolean("summary_report_preparation_transaction_error");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close( pstmt );
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return status;
	}

	public boolean manualSummaryReportGenerationTransactionError(Connection con, long lRunId) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean status = false;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT * FROM summary_report_generation_transaction_error(?) ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				status = rst.getBoolean("summary_report_generation_transaction_error");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close( pstmt );
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return status;
	}

	public boolean manualSummaryReportGenerationRequestwise(Connection con, long lRunId) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean status = false;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT * FROM summary_report_generation_requestwise(?) ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				status = rst.getBoolean("summary_report_generation_requestwise");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close( pstmt );
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return status;
	}

	public boolean manualSummaryReportPreparationRequestwise(Connection con, long lRunId) throws Throwable {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Boolean status = false;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery.append("SELECT * FROM summary_report_preparation_requestwise(?) ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				status = rst.getBoolean("summary_report_preparation_requestwise");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		} finally {
			DataBaseManager.close(rst);
			DataBaseManager.close( pstmt );
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return status;
	}
	
	public Long scenarioReferenceFromReportMaster (Connection con, long scenarioId, long userId) throws Throwable {
		long completedRuns = 0;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery .append("SELECT count(runid) AS total_runs FROM tblreportmaster WHERE scenario_id = ? AND userid = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, scenarioId);
			pstmt.setLong(2, userId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				completedRuns = rst.getLong("total_runs");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return completedRuns;
	}
	
	public JSONObject getMappedScriptNames(Connection con, long scenarioId, long userId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject mappedScripts = null;
		String strQuery = "";
		Date dateLog = LogManager.logMethodStart();

		try {
			strQuery = " SELECT count(*) AS mappedScenarios, GROUP_CONCAT(s.script_name) AS scriptNames, CASE WHEN GROUP_CONCAT(DISTINCT m.scenario_settings->>'type') = '1' THEN 'ITERATION' ELSE 'DURATION' END AS runType, MAX(scenario_settings->>'maxuser') as maxusers FROM lt_scenario_script_mapping m, lt_script_master s WHERE scenario_id = ? AND m.created_by = ? AND s.script_id=m.script_id";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, scenarioId);
			pstmt.setLong(2, userId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				mappedScripts = new JSONObject();
				mappedScripts.put("mappedScenarios", rst.getLong("mappedScenarios"));
				mappedScripts.put("script_name", rst.getString("scriptNames"));
				mappedScripts.put("runType", rst.getString("runType"));
				mappedScripts.put("maxusers", rst.getString("maxusers"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return mappedScripts;
	}
	
	public JSONArray getUserAgentDetails(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joAgent = null;
		JSONArray jaUserAgents = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT browser_name, user_agent_value FROM lt_user_agent");
			
			jaUserAgents =  new JSONArray();
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				joAgent = new JSONObject();
				joAgent.put("browser_name", rs.getString("browser_name"));
				joAgent.put("user_agent_value", rs.getString("user_agent_value"));
				jaUserAgents.add(joAgent);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return jaUserAgents;
	}
	
	public JSONArray getRunSettings(Connection con, long lUserId, long lRunId, long lScriptId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joReports = null;
		JSONArray jaReports = null;
		Date dateLog = LogManager.logMethodStart();

		try {
			sbQuery	.append("SELECT script_name, browser_cache, runtype, v_users, duration, iteration, rd.browser_name, ua.browser_name AS browser_value, rd.parallel_connections ")
					.append("FROM lt_run_details rd ")
					.append("LEFT JOIN lt_user_agent ua ON ua.user_agent_value = rd.browser_name ")
					.append("WHERE run_id = ? ");
			if( lScriptId > 0 ){
				sbQuery	.append("AND script_id = ?");
			}
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			if( lScriptId > 0 ){
				pstmt.setLong(2, lScriptId);
			}
			rst = pstmt.executeQuery();
			jaReports = new JSONArray();
			while(rst.next())
			{
				joReports = new JSONObject();
				joReports.put("script_name", rst.getString("script_name"));
				joReports.put("browser_cache", rst.getBoolean("browser_cache"));
				joReports.put("runtype", rst.getString("runtype"));
				joReports.put("v_users", rst.getLong("v_users"));
				joReports.put("duration", rst.getString("duration"));
				joReports.put("iteration", rst.getLong("iteration"));
				joReports.put("browser_name", rst.getString("browser_value") == null ? rst.getString("browser_name") : rst.getString("browser_value")+" ("+rst.getString("browser_name")+")");
				joReports.put("parallel_connections", UtilsFactory.replaceNull(rst.getString("parallel_connections"), "N/A"));
				jaReports.add(joReports);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			joReports = null;
			
			LogManager.logMethodEnd(dateLog);
		}
		
	 	return jaReports;
	}
	
	/**
	 * gets notes for the runid's category OR runid's category script_id's
	 * 
	 * @param con
	 * @param lRunId
	 * @param strCategory
	 * @param lScriptId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public SummaryReportNotesBean getSummaryReportCategoryNote(Connection con, long lRunId, String strCategory, Long lScriptId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		SummaryReportNotesBean notesBean = null;
		
		try {
			sbQuery	.append("SELECT id, run_id, category, script_id, notes ")
					.append("FROM lt_report_notes ")
					.append("WHERE run_id = ? ")
					.append("  AND category = ? ")
					.append("  AND script_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRunId);
			pstmt.setString(2, strCategory);
			pstmt.setLong(3, lScriptId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				notesBean = new SummaryReportNotesBean();
				notesBean.setNoteId( rst.getLong("id") );
				notesBean.setRunId( rst.getLong("run_id") );
				notesBean.setCategory( rst.getString("category") );
				notesBean.setScriptId( rst.getLong("script_id") );
				notesBean.setNotes( rst.getString("notes") );
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return notesBean;
	}
	
	/**
	 * inserts summary report notes for the user's LT run_id,
	 * adds run's summary report notes for the category, 
	 *   if category based on script wise script_id is added else script_id = `-1`
	 * 
	 * @param con
	 * @param notesBean
	 * @param lUserId
	 * @throws Exception
	 */
	public void insertSummaryReportCategoryNote(Connection con, SummaryReportNotesBean notesBean, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "INSERT INTO lt_report_notes (user_id, run_id, category, script_id, notes, created_by, created_on) VALUES (?, ?, ?, ?, ?, ?, now()) ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, notesBean.getRunId());
			pstmt.setString(3, notesBean.getCategory());
			pstmt.setLong(4, notesBean.getScriptId());
			pstmt.setString(5, notesBean.getNotes());
			pstmt.setLong(6, lUserId);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * update notes for the id
	 * 
	 * @param con
	 * @param notesBean
	 * @param lUserId
	 * @throws Exception
	 */
	public void updateSummaryReportCategoryNote(Connection con, SummaryReportNotesBean notesBean, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE lt_report_notes SET ")
					.append("  notes = ?, ")
					.append("  modified_by = ?, ")
					.append("  modified_on = now() ")
					.append("WHERE id = ? ")
					.append("  AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, notesBean.getNotes());
			pstmt.setLong(2, lUserId);
			pstmt.setLong(3, notesBean.getNoteId());
			pstmt.setLong(4, lUserId);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * gets run_id's category wise notes,
	 * 
	 * @param con
	 * @param lRunId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> getRunSummaryReportNotes(Connection con, long lRunId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "", strCategory = "";
		
		HashMap<String, Object> hmCategoryWiseNotes = null;
		ArrayList<JSONObject> alScriptWiseCategoryNotes = null;
		
		JSONObject joScriptNote = null;
		
		long lScriptId = -1L;
		
		try {
			strQuery = "SELECT * FROM lt_report_notes WHERE run_id = ? ";
			
			hmCategoryWiseNotes = new HashMap<String, Object>();
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lRunId);
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				lScriptId = rst.getLong("script_id");
				strCategory = rst.getString("category");
				
				if ( lScriptId == -1 ) {
					hmCategoryWiseNotes.put(strCategory, rst.getString("notes"));
				} else {
					joScriptNote = new JSONObject();
					joScriptNote.put("scriptId", lScriptId);
					joScriptNote.put("notes", rst.getString("notes"));
					
					if ( hmCategoryWiseNotes.containsKey(strCategory) ) {
						alScriptWiseCategoryNotes = (ArrayList<JSONObject>) hmCategoryWiseNotes.get(strCategory);
					} else {
						alScriptWiseCategoryNotes = new ArrayList<JSONObject>();
						hmCategoryWiseNotes.put(strCategory, alScriptWiseCategoryNotes);
					}
					alScriptWiseCategoryNotes.add(joScriptNote);
				}
				
				strCategory = null;
			}
			/*
			 * the format `hmCategoryWiseNotes`, {"SUMMARY"="<notes>", "SETTINGS"="<notes>", ..., "CONTAINER_WISE": [{"scriptId": <script_id>, "notes": <notes>}, ...], ...}
			 * the category has script wise notes are return ArrayList, without script wise are added as String
			 */
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
			strCategory = null;
		}
		
		return hmCategoryWiseNotes;
	}
	
	/**
	 * check the runid is for the user,
	 *   
	 * @param con
	 * @param lRunId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isRunOwner(Connection con, long lRunId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		boolean bRunExist = false;
		
		try {
			strQuery = "SELECT EXISTS ( SELECT 1 FROM tblreportmaster WHERE runid = ? AND userid = ?) AS is_user_run ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lRunId);
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bRunExist = rst.getBoolean("is_user_run");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		
		return bRunExist;
	}
}
