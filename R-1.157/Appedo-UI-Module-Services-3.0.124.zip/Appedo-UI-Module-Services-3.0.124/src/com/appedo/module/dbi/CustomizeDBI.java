package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class CustomizeDBI {
	
	public JSONArray getCountryCodeDetails(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaCountryCodes = new JSONArray();
		JSONObject joCountryCode = null;
		
		try {
			sbQuery.append("SELECT telephone_code, country_name FROM countries_master WHERE HIDE =  false");
			 
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joCountryCode = new JSONObject();
				joCountryCode.put("telephone_code", rst.getInt("telephone_code"));
				/*joCountryCode.put("value", rst.getInt("telephone_code"));*/
				joCountryCode.put("country_name", rst.getString("country_name"));
				
				jaCountryCodes.add(joCountryCode);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaCountryCodes;
	}
}