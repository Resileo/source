package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;


public class ChartDBI {
	
	private static final String[] RUM_GROUP_BY_HOUR_INTERVALS = { "2 hours", "4 hours", "6 hours", "8 hours", "10 hours", "12 hours", "1 day"};

	public JSONArray getSUMTests(Connection con, long lServiceMapId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaSUMTests = null;
		JSONObject joSUMTest = null;
		
		try {
			jaSUMTests = new JSONArray();
			/*
			sbQuery	.append("SELECT test_id, testname, testtype, testurl, runevery ")
					.append("FROM sum_test_master ")
					.append("WHERE user_id = ? ")
					.append("order by testname ");
			*/
			
			sbQuery	.append("SELECT ")
					.append("stm.test_id, 'SUM' AS module_code, stm.testname, ");
			if ( lServiceMapId == -1 ) {
				// for add
				sbQuery	.append("FALSE AS is_selected, null AS smd_id ")
						.append("FROM sum_test_master stm ");
			} else {
				// for edit
				sbQuery	.append("(CASE WHEN smd.test_id IS NOT NULL THEN TRUE ELSE FALSE END) is_selected, smd.smd_id ")
						.append("FROM sum_test_master stm ")
						.append("LEFT JOIN ( ")
						.append("  SELECT smd_id, service_map_id, CAST(mapped_service->'module_master'->>'test_id' AS bigint) AS test_id ") 
						.append("  FROM service_map_details ")
						.append("  WHERE service_map_id = ").append(lServiceMapId).append(" ")
						.append(") AS smd ON smd.test_id = stm.test_id ");
			}
			sbQuery	.append("WHERE stm.user_id = ").append(lUserId).append(" ")
					.append("ORDER BY testname ");

			//System.out.println("sbQuery: "+sbQuery.toString());
			
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joSUMTest = new JSONObject();
				joSUMTest.put("test_id", rst.getLong("test_id"));
				joSUMTest.put("testname", rst.getString("testname"));
				joSUMTest.put("isSelected", rst.getBoolean("is_selected"));
				joSUMTest.put("module_code", "SUM");
				
				jaSUMTests.add(joSUMTest);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaSUMTests;
	}
	
	public long insertChartView(Connection con, JSONObject joChartDetails, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt  = null;
		
		long lChartViewId = -1L;
		
		int nRowInserted = 0;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("INSERT INTO chart_view (chart_view_name, description, user_id, created_by, created_on) VALUES (?, ?, ?, ?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, joChartDetails.getString("chartName"));
			pstmt.setString(2, joChartDetails.getString("chartDescription"));
			pstmt.setLong(3, loginUserBean.getUserId());
			pstmt.setLong(4, loginUserBean.getUserId());
			pstmt.setLong(5, (new Date()).getTime());
			
			nRowInserted = pstmt.executeUpdate();
			
			lChartViewId = DataBaseManager.returnKey(pstmt);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lChartViewId;
	}
	
	public long updateChartView(Connection con, JSONObject joChartDetails, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt  = null;
		
		long lChartViewId = -1L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("UPDATE chart_view SET chart_view_name = ?, description = ?, modified_by = ?, modified_on = ? WHERE chart_view_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, joChartDetails.getString("chartName"));
			pstmt.setString(2, joChartDetails.getString("chartDescription"));
			pstmt.setLong(3, loginUserBean.getUserId());
			pstmt.setLong(4, (new Date()).getTime());
			pstmt.setLong(5, joChartDetails.getLong("chartViewId"));
			pstmt.execute();
			
			lChartViewId = joChartDetails.getLong("chartViewId");
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lChartViewId;
	}
	
	public void insertChartViewDetails(Connection con, long lChartViewId, JSONObject joChartDetails) throws Exception {
		PreparedStatement pstmt = null, pstmtDel = null;
		JSONArray JaSelectedCounters =null;
		StringBuilder sbQuery = new StringBuilder();
		JaSelectedCounters = joChartDetails.getJSONArray("selectedCounters");
		try {
			sbQuery.append("DELETE FROM chart_view_details WHERE chart_view_id = ?");
			pstmtDel = con.prepareStatement(sbQuery.toString());
			pstmtDel.setLong(1, lChartViewId);
			pstmtDel.execute();
			
			sbQuery.setLength(0);
			sbQuery.append("INSERT INTO chart_view_details (chart_view_id, look_up_id, module_name, module_or_test_id, counter_id, app_name) VALUES (?, (select lookup_id from lookup_code_master_new where lookup_code= ? ), ?, ?, ?, ?) ");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			for(int i= 0;i<JaSelectedCounters.size();i++){
				JSONObject JoSelectedCounters = JaSelectedCounters.getJSONObject(i);
				
				pstmt.setLong(1, lChartViewId);
				pstmt.setString(2, JoSelectedCounters.getString("serviceType"));
				pstmt.setString(3, JoSelectedCounters.getString("serviceType"));
				pstmt.setLong(4, JoSelectedCounters.getLong("uid"));
				pstmt.setLong(5, JoSelectedCounters.getLong("counterID"));
				pstmt.setString(6, JoSelectedCounters.getString("moduleName"));
				pstmt.addBatch();
			}
			int count[] = pstmt.executeBatch();
			LogManager.infoLog(" count object"+count);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtDel);
			pstmtDel = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public boolean isChartViewExists(Connection con, String strChartName, long lChartViewId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		boolean bChartNameExists = false;
		
		try {
			strQuery = "SELECT EXISTS(SELECT 1 FROM chart_view WHERE user_id = ? AND UPPER(chart_view_name) = UPPER(?) AND chart_view_id != ?) AS chart_view_exists ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strChartName);
			pstmt.setLong(3, lChartViewId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bChartNameExists = rst.getBoolean("chart_view_exists");
			}
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		return bChartNameExists;
	}
	
	public HashMap<String, ArrayList<JSONObject>> getAgentAllCategoryWiseCounters(Connection con, long lUId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		String strPvt = "", strCategory = "";

		boolean bMiniChartCounter = false;
		
		HashMap<String, ArrayList<JSONObject>> hmCategoryWiseCouters = new HashMap<String, ArrayList<JSONObject>>();
		ArrayList<JSONObject> alCounters = null;
		
		JSONObject joCounter = null;
		
		try {
			sbQuery	.append("SELECT counter_id, counter_template_id, category, counter_name, display_name, ")
					.append("  is_selected, show_in_primary, show_in_secondary, public ")
					.append("FROM counter_master_").append(lUId).append(" ")
					.append("WHERE is_enabled = true AND is_selected = true ")
					.append("ORDER BY category, display_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joCounter = new JSONObject();
				
				strCategory = rst.getString("category");
				strPvt = rst.getBoolean("public") ? "" : "(Pvt)";
				
				joCounter.put("counter_id", rst.getInt("counter_id"));
				joCounter.put("counter_template_id", rst.getInt("counter_template_id"));
				joCounter.put("category", strCategory);
				joCounter.put("name", rst.getString("counter_name")+strPvt);
				joCounter.put("displayName", rst.getString("display_name")+strPvt);
				joCounter.put("isDefault", rst.getBoolean("is_selected"));
				joCounter.put("isSelected", rst.getBoolean("is_selected"));
				joCounter.put("showCounter", false);
				joCounter.put("isPublic", rst.getBoolean("public"));
				joCounter.put("show_in_primary", rst.getBoolean("show_in_primary"));
				joCounter.put("show_in_secondary", rst.getBoolean("show_in_secondary"));
				joCounter.put("isMandatory", rst.getBoolean("show_in_primary") || rst.getBoolean("show_in_secondary") || bMiniChartCounter);
				
				if ( hmCategoryWiseCouters.containsKey(strCategory) ) {
					alCounters = hmCategoryWiseCouters.get(strCategory);
				} else {
					alCounters = new ArrayList<JSONObject>();
					
					// obj. by ref
					hmCategoryWiseCouters.put(strCategory, alCounters);
				}
				alCounters.add(joCounter);
				
				strCategory = null;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strPvt = null;
			strCategory = null;
		}
		
		return hmCategoryWiseCouters;
	}
	
	public String getUserChartViewsWithCounterDetails(Connection con, LoginUserBean loginUserBean, long chartId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null, pstmtModules = null;
		ResultSet rst = null, rstModules = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONArray joUserChartView = null;
		String jout = null, query = null;
		
		try {
			if( chartId > 0 ){
				query = "SELECT chart_view_id, chart_view_name, description, created_on, (select array_to_json(array_agg(row_to_json(d))) from (select module_name, module_or_test_id, counter_id, app_name from chart_view_details where chart_view_id=c.chart_view_id) d) as \"counterDetails\" from chart_view as c where c.user_id = ? AND c.chart_view_id = ? order by chart_view_name";
			} else {
				query = "SELECT chart_view_id, chart_view_name, description, created_on, (select array_to_json(array_agg(row_to_json(d))) from (select module_name, module_or_test_id, counter_id, app_name from chart_view_details where chart_view_id=c.chart_view_id) d) as \"counterDetails\" from chart_view as c where c.user_id = ? order by chart_view_name";
			}
			sbQuery .append("SELECT array_to_json(array_agg(row_to_json(t))) AS value from (").append(query).append(") as t");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			if( chartId > 0 ){
				pstmt.setLong(2, chartId);
			}
			rst = pstmt.executeQuery();
			if (rst.next()) {
				jout = rst.getString("value");
			}
			if (jout != null) {
				joUserChartView = JSONArray.fromObject(jout);
				for( int k = 0; k < joUserChartView.size(); k++ ){
					JSONObject j = joUserChartView.getJSONObject(k);
					j.put("created_by", loginUserBean.getFirstName());
					JSONArray ja = JSONArray.fromObject(j.get("counterDetails"));
					for (int i = 0; i < ja.size(); i++) {
						JSONObject joCounters = ja.getJSONObject(i);
						if (joCounters.get("module_name").equals("SUM") || joCounters.get("module_name").equals("RUM")) {
							joCounters.put("category", "Response Time");
							joCounters.put("display_name", "Page Load Time");
							joCounters.put("unit", "");
						} else {
							sbQuery.setLength(0);
							sbQuery .append("SELECT category, display_name, unit from counter_master_")
									.append(joCounters.getLong("module_or_test_id"))
									.append(" WHERE counter_id = ?");
							
							pstmtModules = con.prepareStatement(sbQuery.toString());
							pstmtModules.setLong(1, joCounters.getLong("counter_id"));
							rstModules = pstmtModules.executeQuery();
							if (rstModules.next()) {
								joCounters.put("category", rstModules.getString("category"));
								joCounters.put("display_name", rstModules.getString("display_name"));
								joCounters.put("unit", rstModules.getString("unit"));
							}
						}
					}
				}
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(rstModules);
			rstModules = null;
			DataBaseManager.close(pstmtModules);
			pstmtModules = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return joUserChartView.toString();
	}
	
	//public String getChartMultiLine(Connection con, String strModuleName, long uid, long counterId, String strDisplayName, String unit, String strInterval, String appName, String moduleName, String category, String loc) throws Exception {
	public JSONObject getChartMultiLine(Connection con, JSONObject joDetails, String strInterval, String strLocation, Long lStartDateTime, Long lEndDateTime) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		//String outputStr = null;
		
		JSONObject joResult = null, joDatum = null;
		JSONArray jaChartData = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		Date dateLog = LogManager.logMethodStart();
		
		try {
			if( joDetails.getString("module_name").equalsIgnoreCase("SUM") ){
				sbQuery = getSUMQuery(con, joDetails, strInterval, strLocation, lStartDateTime, lEndDateTime);
				pstmt = con.prepareStatement(sbQuery.toString());
			} else if ( joDetails.getString("module_name").equalsIgnoreCase("RUM") ){
				sbQuery = getRUMQuery(con, joDetails, strInterval, strLocation, lStartDateTime, lEndDateTime);
				pstmt = con.prepareStatement(sbQuery.toString());
			} else {
				sbQuery = getASDQuery(con, joDetails, strInterval, strLocation, lStartDateTime, lEndDateTime);
				sbQuery.append(" AND counter_type = ? ORDER BY T ");
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setLong(1, joDetails.getLong("counter_id"));
			}
			jaChartData = new JSONArray();
			
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joDatum = new JSONObject();
				joDatum.put("T", rst.getTimestamp("T").getTime());
				joDatum.put("V", rst.getLong("V"));
				jaChartData.add(joDatum);
			}
			joResult = new JSONObject();
			
			if( strLocation != null){
				joResult.put("legendName", joDetails.getString("module_name")+" - " +joDetails.getString("app_name")+" - " + joDetails.getString("category")+" - " +joDetails.getString("display_name")+ " - " +strLocation);
			} else {
				joResult.put("legendName", joDetails.getString("module_name")+" - " +joDetails.getString("app_name")+" - " + joDetails.getString("category")+" - " +joDetails.getString("display_name"));
			}
			joResult.put("uid",joDetails.getLong("module_or_test_id"));
			joResult.put("counter_id", joDetails.getLong("counter_id"));
			joResult.put("appName", joDetails.getString("app_name"));
			if( joDetails.getString("module_name").equals("SUM") ){
				joResult.put("displayName", joDetails.getString("display_name")+" (ms)");

				joResult.put("field_1_name", "Params");
				joResult.put("field_1_value", strLocation);
			} else {
				joResult.put("displayName", joDetails.getString("display_name"));
				joResult.put("field_1_name", "");
				joResult.put("field_1_value", "");
			}
			joResult.put("unit", joDetails.getString("unit"));
			joResult.put("moduleName", joDetails.getString("module_name"));
			joResult.put("category", joDetails.getString("category"));
			joResult.put("Data", jaChartData);
			
			joResult.put("field_2_name", "");
			joResult.put("field_2_value", "");
			joResult.put("field_3_name", "");
			joResult.put("field_3_value", "");
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			/*
			map = null;
			childMap = null;
			strAppName = null;*/
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joResult;
	}
	
	public StringBuilder getSUMQuery(Connection con, JSONObject joDetails, String strInterval, String loc, Long lStartDateTime, Long lEndDateTime){
		StringBuilder queryString = new StringBuilder();
		Long uid = 0l;
		try {
			uid = joDetails.getLong("module_or_test_id");
			if( strInterval != null ){
				queryString .append("SELECT hf.received_on AS T, hf.pageloadtime AS V, hf.pageloadtime_repeatview FROM sum_har_test_results hf where hf.test_id = ")
							.append(uid).append(" AND hf.location = '").append(loc)
							.append("' AND hf.received_on > ( now() - INTERVAL '"+ strInterval + "' ) ORDER BY location_name, received_on");
			} else {
				queryString .append("SELECT hf.received_on AS T, hf.pageloadtime AS V, hf.pageloadtime_repeatview FROM sum_har_test_results hf where hf.test_id = ")
							.append(uid).append(" and hf.location = '").append(loc)
							.append("' AND hf.received_on::timestamp between to_timestamp("+ lStartDateTime + "/1000) ")
							.append("AND to_timestamp(" + lEndDateTime + "/1000) order by location_name, received_on");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
		return queryString;
	}
	
	public StringBuilder getRUMQuery(Connection con, JSONObject joDetails, String strInterval, String loc, Long lStartDateTime, Long lEndDateTime){
		StringBuilder queryString = new StringBuilder();
		Long uid = 0l;
		String strFormatAppedoReceivedOn = "";
		try {
			uid = joDetails.getLong("module_or_test_id");
			if( strInterval != null ){
				if( strInterval.equals("1 hour") ) {
					strFormatAppedoReceivedOn = "date_trunc('minute', appedo_received_on)";
				} else if( UtilsFactory.contains(RUM_GROUP_BY_HOUR_INTERVALS, strInterval) ) {
					strFormatAppedoReceivedOn = "date_trunc('hour', appedo_received_on)";
				} else {
					strFormatAppedoReceivedOn = "appedo_received_on::date";
				}
				queryString .append("SELECT ").append(strFormatAppedoReceivedOn).append(" AS T, count(*) AS V ")
							.append("FROM rum_collector_").append(uid).append(" ")
							.append("WHERE appedo_received_on > now() - interval '").append(strInterval).append("' AND (nt_domcomp <> 0 AND nt_nav_st <> 0) ")
							.append("GROUP BY T ")
							.append("ORDER BY T ");
			} else {
				if( lEndDateTime - lStartDateTime <= 3600000 ) {
					strFormatAppedoReceivedOn = "date_trunc('minute', appedo_received_on)";
				} else if( lEndDateTime - lStartDateTime <= 86400000 ) {
					strFormatAppedoReceivedOn = "date_trunc('hour', appedo_received_on)";
				} else {
					strFormatAppedoReceivedOn = "appedo_received_on::date";
				}
				queryString .append("SELECT ").append(strFormatAppedoReceivedOn).append(" AS T, count(*) AS V ")
							.append("FROM rum_collector_").append(uid).append(" ")
							.append("WHERE appedo_received_on::timestamp")
							.append(" between to_timestamp("+lStartDateTime+"/1000)")
							.append(" AND to_timestamp("+lEndDateTime+"/1000)")
							.append(" AND (nt_domcomp <> 0 AND nt_nav_st <> 0) ")
							.append("GROUP BY T ")
							.append("ORDER BY T ");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
		return queryString;
	}
	
	public StringBuilder getASDQuery(Connection con, JSONObject joDetails, String strInterval, String loc, Long lStartDateTime, Long lEndDateTime){
		StringBuilder sbQuery = new StringBuilder();
		Long uid = 0l;
		try {
			uid = joDetails.getLong("module_or_test_id");
			if( strInterval != null ){
				sbQuery .append("SELECT appedo_received_on AS T, counter_value AS V FROM collector_")
				.append(uid).append(" WHERE appedo_received_on >= date_trunc('minute', (now() - interval '").append(strInterval).append("')) ");
							/*.append(uid).append(" where date_trunc('minute', appedo_received_on) >= (now() - interval '").append(strInterval).append("') ");*/
			} else {
				sbQuery .append("SELECT appedo_received_on AS T, counter_value AS V FROM collector_")
							.append(uid).append(" WHERE appedo_received_on::timestamp BETWEEN to_timestamp("+ lStartDateTime + "/1000) ")
							.append("AND to_timestamp(" + lEndDateTime + "/1000) ");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
		return sbQuery;
	}
	
	/**
	 * gets ASD's counter's raw data without aggregation,
	 *  for agent does not send data, break counter's array data into set, to have gap/discontinuous between lines, based on time diff. > 1 min.   
	 *  chartdata in format, `[ [{T: 145678920000, V: }, {T: 145678920000, V: }, ...], ..., [..., {T: 145678920000, V: }, {T: 145678920000, V: }] ]`
	 * 
	 * @param con
	 * @param joModuleDetails
	 * @param strInterval
	 * @param lStartDateTime
	 * @param lEndDateTime
	 * @return
	 * @throws Exception
	 */
	public JSONObject getASDCounterChartData(Connection con, JSONObject joModuleDetails, String strInterval, Long lStartDateTime, Long lEndDateTime) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lTime = -1L;
		long lPrevTime = -1L, lDuration = -1L;
		
		ArrayList<JSONObject> alCounterSet = null;
		ArrayList<ArrayList<JSONObject>> alCounterSets = new ArrayList<ArrayList<JSONObject>>();
		
		JSONObject joResult = new JSONObject(), joDatum = null;
		
		try {
			sbQuery .append("SELECT appedo_received_on, counter_value ")
					.append("FROM collector_").append(joModuleDetails.getLong("module_or_test_id")).append(" ")
					.append("WHERE counter_type = ? ");
			if( strInterval != null ){
				sbQuery.append("  AND appedo_received_on >= (now() - interval '").append(strInterval).append("') ");
			} else {
				sbQuery.append("  AND appedo_received_on BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			}
			sbQuery	.append("ORDER BY appedo_received_on ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, joModuleDetails.getLong("counter_id"));
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				lTime = rst.getTimestamp("appedo_received_on").getTime();
				
				// `T` is time (x-axis) & `V` is value (y-axis) 
				joDatum = new JSONObject();
				joDatum.put("T", lTime);
				joDatum.put("V", rst.getDouble("counter_value"));
				
				lDuration = lTime - lPrevTime;
				
				// If there the time difference between current & previous is more than 1 minute, then store the datum in a new Array
				if( lDuration > Constants.COUNTER_CHART_TIME_INTERVAL ) {
					alCounterSet = new ArrayList<JSONObject>();
					alCounterSets.add(alCounterSet);
				}
				alCounterSet.add(joDatum);
				
				lPrevTime = lTime;
			}
			joResult.put("legendName", joModuleDetails.getString("module_name")+" - " +joModuleDetails.getString("app_name")+" - " + joModuleDetails.getString("category")+" - " +joModuleDetails.getString("display_name"));
			joResult.put("uid",joModuleDetails.getLong("module_or_test_id"));
			joResult.put("moduleName", joModuleDetails.getString("module_name"));	// moduleCode
			joResult.put("appName", joModuleDetails.getString("app_name"));
			joResult.put("counter_id", joModuleDetails.getLong("counter_id"));
			joResult.put("category", joModuleDetails.getString("category"));
			joResult.put("displayName", joModuleDetails.getString("display_name"));
			joResult.put("unit", joModuleDetails.getString("unit"));
			joResult.put("Data", alCounterSets);
			joResult.put("serverCurrentTime", System.currentTimeMillis());
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	public String getSUMLocations(Connection con, long testId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		String strQuery = "";
		String locations = null;
		
		try {
			strQuery = "SELECT GROUP_CONCAT(DISTINCT hf.location) AS locations FROM sum_har_test_results hf, sum_test_cluster_mapping sc WHERE sc.location = hf.location_name AND hf.test_id = sc.test_id AND sc.test_id = ?";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, testId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				locations = rst.getString("locations");
			}
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		return locations;
	}
	
	public void deleteChartView(Connection con, long lChartViewId, long lUserId) throws Exception {
		PreparedStatement pstmt  = null;
		
		String strQuery = "";
		
		try {
			strQuery = "DELETE FROM chart_view WHERE chart_view_id = ? AND user_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lChartViewId);
			pstmt.setLong(2, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
	}
	
	public long updateChartVisualOnCounterRemove(Connection con, Long lCounterId, Long lUid, Long lUserId) throws Exception {
		PreparedStatement pstmt  = null;
		
		long lChartViewId = -1L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("UPDATE chart_visualization_").append(lUserId)
				.append(" SET is_active = false, modified_by = ?, modified_on = now() WHERE ref_table_name = ")
				.append(UtilsFactory.makeValidVarchar("counter_master_"+lUid)).append(" AND ref_table_pkey_id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lCounterId);
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lChartViewId;
	}
	
	public long updateChartVisualOnCounterConfig(Connection con, String strCounterId, Long lUid, Long lUserId) throws Exception {
		PreparedStatement pstmt  = null;
		
		long lChartViewId = -1L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("UPDATE chart_visualization_").append(lUserId)
				.append(" SET is_active = (CASE WHEN ref_table_pkey_id IN (").append(strCounterId).append(") THEN TRUE  ELSE FALSE END), ")
				.append("modified_by = ?, modified_on = now() WHERE ref_table_name = ")
				.append(UtilsFactory.makeValidVarchar("counter_master_"+lUid));
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lChartViewId;
	}
	
	public String getChartDataQuery(Connection con, long lUserId, long metricId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		String chartQuery = null;
		
		try {
			sbQuery.append("SELECT query from chart_visualization_").append(lUserId).append(" WHERE chart_id = ").append(metricId);
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			if(rst.next()) {
				chartQuery = rst.getString("query");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return chartQuery;
	}
	
	
	public JSONArray getChartVisualizerOADData_v1(Connection con, long lUserId, long uid, String strCounterId, String moduleType, Long counterTemplateId, String strInterval, long lStartDate, long lEndDate) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joChartRawData = null;
		JSONObject joChartData = null;
		JSONObject joRtnData = null;
		JSONArray jaRtnArrayData = null;
		
		try {
			jaRtnArrayData = new JSONArray();
			sbQuery.append("SELECT chart_id, chart_title, legend_text, module_type, category, unit, chart_type, ")
					.append(" xaxis_timescale, enable_yaxis, h_display_label, enable_critical, enable_warning,")
					.append(" axis_label, sel_graph_value, xy_axis_label, enable_mma, clickable, ref_table_pkey_id, ")
					.append(" ref_table_name, query, is_active FROM chart_visualization_").append(lUserId)
					.append(" WHERE ref_table_name = 'counter_master_"+uid+"' AND module_type LIKE '").append(moduleType).append("' ");
			
			if (counterTemplateId != null) {
				sbQuery.append(" AND counter_template_id = "+counterTemplateId+" AND ref_table_pkey_id = ").append(strCounterId);
			} else {
				sbQuery.append(" AND ref_table_pkey_id IN (SELECT counter_type FROM collector_").append(uid).append(" WHERE ");
				if (strInterval != null) {
					sbQuery.append(" appedo_received_on >= (now() - interval '").append(strInterval).append("') ");
				} else {
					sbQuery.append(" appedo_received_on BETWEEN to_timestamp(").append(lStartDate/1000).append(") AND to_timestamp(")
					.append(lEndDate/1000).append(") ");
				}
				sbQuery.append(" GROUP BY counter_type HAVING count(id) > 0) ");
			}
					
			//System.out.println("query :"+ sbQuery.toString());
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				joChartRawData = new JSONObject();
				joChartData =  new JSONObject();
				joRtnData =  new JSONObject();
				
				joChartRawData.put("chartType", rst.getString("chart_type"));
				joChartRawData.put("legendText",rst.getString("legend_text"));
				joChartRawData.put("metricId",rst.getLong("chart_id"));
				//joChartRawData.put("id", rst.getLong("chart_id"));
				joChartRawData.put("selGraphValue",rst.getString("sel_graph_value"));
				joChartRawData.put("unit", rst.getString("unit"));
				//joChartRawData.put("lineWidth", Constants.CHART_LINE_WIDTH);
				//joChartRawData.put("circleWidth", Constants.CHART_CIRCLE_WIDTH);
				//joChartRawData.put("enableMinAvgMax", rst.getBoolean("mma_enabled"));
				//joChartRawData.put("query",rst.getString("query"));
				
				//joChartData.put("module",Constants.CHART_MODULE_APM);
				joChartData.put("type", moduleType);
				joChartData.put("category", rst.getString("category"));
				joChartData.put("chartName", rst.getString("chart_title"));
				joChartData.put("axisLabel", rst.getString("axis_label"));
				joChartData.put("enableMinAvgMax", rst.getBoolean("enable_mma"));
				joChartData.put("xAxisTimeScale", rst.getBoolean("xaxis_timescale"));
				joChartData.put("enableYaxis", rst.getBoolean("enable_yaxis"));
				joChartData.put("xyAxisLabel", rst.getString("xy_axis_label"));
				joChartData.put("chartId",rst.getLong("chart_id"));
				joChartData.put("counterId", rst.getString("ref_table_pkey_id"));
				joChartData.put("refId", rst.getString("ref_table_name"));
				joChartData.put("isActive", rst.getBoolean("is_active"));
				joChartData.put("isAlertEnabled", true);
				
				joRtnData.put("isChartVisulizerAvailable", true);
				joRtnData.put("chartRawData", joChartRawData);
				joRtnData.put("chart", joChartData);
				joRtnData.put("isQueryExist", rst.getString("query").length() > 0 ? true : false);
				jaRtnArrayData.add(joRtnData);
			}
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			joChartRawData = null;
			joChartData =  null;
			joRtnData =  null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return jaRtnArrayData;
	}
	public JSONArray getChartVisualizerLOGData_v1(Connection con, long lUserId, long uid, String moduleType, Long secRefId, String secRefName) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joChartRawData = null;
		JSONObject joChartData = null;
		JSONObject joRtnData = null;
		JSONArray jaRtnArrayData = null;
		
		try {
			jaRtnArrayData = new JSONArray();
			sbQuery.append("SELECT chart_id, chart_title, legend_text, module_type, category, unit, chart_type, ")
					.append(" xaxis_timescale, enable_yaxis, h_display_label, enable_critical, enable_warning,")
					.append(" axis_label, sel_graph_value, xy_axis_label, enable_mma, clickable, ref_table_pkey_id, query")
					.append(" FROM chart_visualization_").append(lUserId)
					.append(" WHERE ref_table_pkey_id = ").append(uid).append(" AND module_type = '").append(moduleType).append("' ");
					if (secRefId > 0) {
						sbQuery.append(" AND ref_table_name = '").append(secRefName).append("' AND ref_sec_pkey_id = ").append(secRefId);
					}
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				joChartRawData = new JSONObject();
				joChartData =  new JSONObject();
				joRtnData =  new JSONObject();
				
				joChartRawData.put("chartType", rst.getString("chart_type"));
				joChartRawData.put("legendText",rst.getString("legend_text"));
				joChartRawData.put("metricId",rst.getLong("chart_id"));
				//joChartRawData.put("id", rst.getLong("chart_id"));
				joChartRawData.put("selGraphValue",rst.getString("sel_graph_value"));
				joChartRawData.put("unit", rst.getString("unit"));
				//joChartRawData.put("query",rst.getString("query"));
				
				joChartData.put("type", moduleType);
				joChartData.put("category", rst.getString("category"));
				joChartData.put("chartName", rst.getString("chart_title"));
				joChartData.put("axisLabel", rst.getString("axis_label"));
				joChartData.put("enableMinAvgMax", rst.getBoolean("enable_mma"));
				joChartData.put("xAxisTimeScale", rst.getBoolean("xaxis_timescale"));
				joChartData.put("enableYaxis", rst.getBoolean("enable_yaxis"));
				joChartData.put("xyAxisLabel", rst.getString("xy_axis_label"));
				joChartData.put("chartId",rst.getLong("chart_id"));
				joChartData.put("refId",uid);
				joChartData.put("isAlertEnabled", false);
				
				joRtnData.put("isChartVisulizerAvailable", true);
				joRtnData.put("chartRawData", joChartRawData);
				joRtnData.put("chart", joChartData);
				joRtnData.put("isQueryExist", rst.getString("query").length() > 0 ? true : false);
				jaRtnArrayData.add(joRtnData);
			}
					
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			joChartRawData = null;
			joChartData =  null;
			joRtnData =  null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return jaRtnArrayData;
	}
	
	
	//con, lUserId, uid, moduleType, strModuleName
	public JSONArray getChartVisualizerRUMData_v1(Connection con, long lUserId, long uid, String moduleType) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joChartRawData = null;
		JSONObject joChartData = null;
		JSONObject joRtnData = null;
		JSONArray jaRtnArrayData = null;
		
		try {
			jaRtnArrayData = new JSONArray();
			sbQuery.append("SELECT chart_id, chart_title, legend_text, module_type, category, unit, chart_type, ")
					.append(" xaxis_timescale, enable_yaxis, h_display_label, enable_critical, enable_warning,")
					.append(" axis_label, sel_graph_value, xy_axis_label, enable_mma, clickable, ref_table_pkey_id, ref_sec_table_name, query")
					.append(" FROM chart_visualization_").append(lUserId)
					.append(" WHERE ref_table_name LIKE 'rum_collector_")
					.append(uid).append("' AND ref_table_pkey_id = ").append(uid)
					.append(" AND module_type LIKE '").append(moduleType).append("'");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				joChartRawData = new JSONObject();
				joChartData =  new JSONObject();
				joRtnData =  new JSONObject();
				
				joChartRawData.put("chartType", rst.getString("chart_type"));
				joChartRawData.put("legendText",rst.getString("legend_text"));
				joChartRawData.put("metricId",rst.getLong("chart_id"));
				//joChartRawData.put("id", rst.getLong("chart_id"));
				joChartRawData.put("selGraphValue",rst.getString("sel_graph_value"));
				joChartRawData.put("unit", rst.getString("unit"));
				//joChartRawData.put("query", rst.getString("query"));
				
				joChartData.put("type", moduleType);
				joChartData.put("category", rst.getString("category"));
				joChartData.put("chartName", rst.getString("chart_title"));
				joChartData.put("axisLabel", rst.getString("axis_label"));
				joChartData.put("enableMinAvgMax", rst.getBoolean("enable_mma"));
				joChartData.put("xAxisTimeScale", rst.getBoolean("xaxis_timescale"));
				joChartData.put("enableYaxis", rst.getBoolean("enable_yaxis"));
				joChartData.put("xyAxisLabel", rst.getString("xy_axis_label"));
				joChartData.put("rumType", rst.getString("ref_sec_table_name"));
				joChartData.put("chartId",rst.getLong("chart_id"));
				joChartData.put("refId",uid);
				joChartData.put("isAlertEnabled", false);
								
				joRtnData.put("isChartVisulizerAvailable", true);
				joRtnData.put("chartRawData", joChartRawData);
				joRtnData.put("chart", joChartData);
				joRtnData.put("isQueryExist", rst.getString("query").length() > 0 ? true : false);
				jaRtnArrayData.add(joRtnData);
			}
					
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			joChartRawData = null;
			joChartData =  null;
			joRtnData =  null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return jaRtnArrayData;
	}
	
	public JSONArray getAllMyChart(Connection con, long lUserId, long lEID) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joRtnData = null;
		JSONArray jaRtnArrayData = null;
		
		try {
			
			sbQuery.append("SELECT * FROM get_all_my_chart(?, ?)");
			jaRtnArrayData = new JSONArray();
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lEID);
			rst = pstmt.executeQuery();
			
			while (rst.next()) {
				joRtnData = new JSONObject();
				joRtnData.put("name", rst.getString("mc_name"));
				jaRtnArrayData.add(joRtnData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			joRtnData =  null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return jaRtnArrayData;
	}
	
	public JSONArray getMyChartIds(Connection con, long lUserId, String strMyChartName, long lEID) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joRtnData = null;
		JSONArray jaRtnArrayData = null;
		
		try {
			
			sbQuery.append("SELECT chart_id FROM my_chart_").append(lUserId).append(" WHERE LOWER(mc_name) = LOWER('").append(strMyChartName)
					.append("') AND user_id = ").append(lUserId).append(" AND CASE WHEN ").append(lEID).append(" = 0 THEN e_id IS NULL ELSE ")
					.append(" e_id = ").append(lEID).append(" END");
			
			jaRtnArrayData = new JSONArray();
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				joRtnData = new JSONObject();
				joRtnData.put("chartId", rst.getLong("chart_id"));
				jaRtnArrayData.add(joRtnData);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			joRtnData =  null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return jaRtnArrayData;
	}
	
	public void addToMyChart(Connection con, long lUserId, Long lChartId, Long lRefId, String strMyChartName, String strModuleType, long lEID) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			
			sbQuery.append("SELECT add_update_my_chart(?, ?, ?, ?, ?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			if (lEID > 0) {
				pstmt.setLong(2, lEID);
			} else {
				pstmt.setNull(2, Types.BIGINT);
			}
			pstmt.setLong(3, lChartId);
			pstmt.setLong(4, lRefId);
			pstmt.setString(5, strMyChartName);
			pstmt.setString(6, strModuleType);
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
	}
	
	public void removeFromMyChart(Connection con, long lUserId, Long lChartId, String strMyChartName, long lEID) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			
			sbQuery.append("DELETE FROM my_chart_").append(lUserId).append(" WHERE LOWER(mc_name) = LOWER('")
			.append(strMyChartName).append("') AND user_id = ? AND chart_id = ? AND CASE WHEN ? = 0 THEN e_id IS NULL ELSE e_id = ? END ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lChartId);
			pstmt.setLong(3, lEID);
			pstmt.setLong(4, lEID);
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
	}
	
	public boolean isMyChartExists(Connection con, long lUserId, String strMyChartName, long lEID) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		boolean isChartExist = false;
		
		try {
			
			sbQuery.append("SELECT * FROM my_chart_").append(lUserId).append(" WHERE LOWER(mc_name) = LOWER('")
					.append(strMyChartName).append("') AND CASE WHEN ").append(lEID).append(" = 0 THEN e_id IS NULL ELSE ")
					.append(" e_id = ").append(lEID).append(" END ");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			if (rst.next()) {
				isChartExist = true;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		return isChartExist;
	}
	
	public JSONArray getChartVisualizerSUMData_v1(Connection con, long lUserId, long test_id, String moduleType, String url, String category) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joChartRawData = null;
		JSONObject joChartData = null;
		JSONObject joRtnData = null;
		JSONArray jaRtnArrayData = null;
		
		try {
			jaRtnArrayData = new JSONArray();
			sbQuery.append("SELECT chart_id, chart_title, legend_text, module_type, category, location, os, browser, connection_name, ")
					.append(" unit, chart_type, xaxis_timescale, enable_yaxis, h_display_label, enable_critical, enable_warning,")
					.append(" axis_label, sel_graph_value, xy_axis_label, enable_mma, clickable, ref_table_pkey_id, query")
					.append(" FROM chart_visualization_").append(lUserId)
					.append(" WHERE ref_table_name LIKE 'sum_test_master'")
					.append(" AND ref_table_pkey_id = ").append(test_id).append(" AND module_type = '").append(moduleType).append("' ")
					.append(" AND ref_sec_table_name LIKE '").append(url).append("' AND category = '").append(category).append("' ");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				joChartRawData = new JSONObject();
				joChartData =  new JSONObject();
				joRtnData =  new JSONObject();
				
				joChartRawData.put("chartType", rst.getString("chart_type"));
				joChartRawData.put("legendText",rst.getString("legend_text"));
				joChartRawData.put("metricId",rst.getLong("chart_id"));
				//joChartRawData.put("id", rst.getLong("chart_id"));
				joChartRawData.put("selGraphValue",rst.getString("sel_graph_value"));
				joChartRawData.put("unit", rst.getString("unit"));
				joChartRawData.put("location", rst.getString("location"));
				joChartRawData.put("os", rst.getString("os"));
				joChartRawData.put("browser", rst.getString("browser"));
				joChartRawData.put("connectionName", rst.getString("connection_name"));
				//joChartRawData.put("query", rst.getString("query"));
				
				joChartData.put("type", moduleType);
				joChartData.put("category", rst.getString("category"));
				joChartData.put("chartName", rst.getString("chart_title"));
				joChartData.put("axisLabel", rst.getString("axis_label"));
				joChartData.put("enableMinAvgMax", rst.getBoolean("enable_mma"));
				joChartData.put("xAxisTimeScale", rst.getBoolean("xaxis_timescale"));
				joChartData.put("enableYaxis", rst.getBoolean("enable_yaxis"));
				joChartData.put("xyAxisLabel", rst.getString("xy_axis_label"));
				joChartData.put("chartId",rst.getLong("chart_id"));
				joChartData.put("refId",test_id);
				joChartData.put("isAlertEnabled", false);
				
				joRtnData.put("isChartVisulizerAvailable", true);
				joRtnData.put("chartRawData", joChartRawData);
				joRtnData.put("chart", joChartData);
				joRtnData.put("isQueryExist", rst.getString("query").length() > 0 ? true : false);
				jaRtnArrayData.add(joRtnData);
			}
					
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			joChartRawData = null;
			joChartData =  null;
			joRtnData =  null;
			
		    LogManager.logMethodEnd(dateLog);
		}

		return jaRtnArrayData;
	}
	
	public JSONObject getChartVisualizerDataWithChartId(Connection con, long lUserId, long lChartId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joChartRawData = null;
		JSONObject joChartData = null;
		JSONObject joRtnData = null;
		String strModuleType = null;
		
		try {
			sbQuery.append("SELECT chart_id, chart_title, legend_text, module_type, category, unit, chart_type, ")
					.append(" location, os, browser, connection_name, ")
					.append(" xaxis_timescale, enable_yaxis, h_display_label, enable_critical, enable_warning,")
					.append(" axis_label, sel_graph_value, xy_axis_label, enable_mma, clickable, ref_table_pkey_id, ")
					.append(" ref_table_name, ref_sec_table_name, query, is_active FROM chart_visualization_").append(lUserId)
					.append(" WHERE chart_id = ").append(lChartId);
			
			//System.out.println("query :"+ sbQuery.toString());
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while (rst.next()) {
				joChartRawData = new JSONObject();
				joChartData =  new JSONObject();
				joRtnData =  new JSONObject();
				
				strModuleType = rst.getString("module_type");
				
				joChartRawData.put("chartType", rst.getString("chart_type"));
				joChartRawData.put("legendText",rst.getString("legend_text"));
				joChartRawData.put("metricId",rst.getLong("chart_id"));
				joChartRawData.put("selGraphValue",rst.getString("sel_graph_value"));
				joChartRawData.put("unit", rst.getString("unit"));
				joChartRawData.put("location", rst.getString("location"));
				joChartRawData.put("os", rst.getString("os"));
				joChartRawData.put("browser", rst.getString("browser"));
				joChartRawData.put("connectionName", rst.getString("connection_name"));
				
				joChartData.put("type", strModuleType);
				joChartData.put("category", rst.getString("category"));
				joChartData.put("chartName", rst.getString("chart_title"));
				joChartData.put("axisLabel", rst.getString("axis_label"));
				joChartData.put("enableMinAvgMax", rst.getBoolean("enable_mma"));
				joChartData.put("xAxisTimeScale", rst.getBoolean("xaxis_timescale"));
				joChartData.put("enableYaxis", rst.getBoolean("enable_yaxis"));
				joChartData.put("xyAxisLabel", rst.getString("xy_axis_label"));
				joChartData.put("rumType", rst.getString("ref_sec_table_name"));
				joChartData.put("chartId",rst.getLong("chart_id"));
				if (strModuleType.equals(Constants.RUM_MODULE) || strModuleType.equals(Constants.SUM_MODULE) || strModuleType.equals(Constants.LOG_MODULE)) {
					joChartData.put("refId", rst.getString("ref_table_pkey_id"));
					joChartData.put("isActive", false);
					joChartData.put("isAlertEnabled", false);
				} else {
					joChartData.put("counterId", rst.getString("ref_table_pkey_id"));
					joChartData.put("refId", rst.getString("ref_table_name"));
					joChartData.put("isActive", rst.getBoolean("is_active"));
					joChartData.put("isAlertEnabled", true);
				}
				joRtnData.put("isChartVisulizerAvailable", true);
				joRtnData.put("chartRawData", joChartRawData);
				joRtnData.put("chart", joChartData);
				joRtnData.put("isQueryExist", rst.getString("query").length() > 0 ? true : false);
				
				//jaRtnArrayData.add(joRtnData);
			}
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			joChartRawData = null;
			joChartData =  null;
			strModuleType = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		return joRtnData;
	}
}
