package com.appedo.module.dbi;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.APMLicenseBean;
import com.appedo.module.bean.DDLicenseBean;
import com.appedo.module.bean.ModuleBean;
import com.appedo.module.bean.RUMLicenseBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class ModuleDBI {
	
	public JSONObject getAPMModules(Connection con, LoginUserBean loginBean, String strModuleType, String strLimit, String strOffset) throws Exception {
		PreparedStatement pstmt = null, pstmtCnt = null;
		ResultSet rst = null, rstCnt = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joModule = null, joResult = new JSONObject();
		JSONArray jaModules = new JSONArray();
		
		long lTotalResults = -1L;
		
		try {
			sbQuery	.append("SELECT count(*) AS total_results ")
					.append("FROM module_master mm ")
					.append("INNER JOIN counter_type_version ctv on ctv.counter_type_version_id = mm.counter_type_version_id AND mm.module_code = ? ")
					.append("INNER JOIN counter_type ct on ctv.counter_type_id = ct.counter_type_id ")
					.append("AND mm.user_id = ? ");
			pstmtCnt = con.prepareStatement(sbQuery.toString());
			pstmtCnt.setString(1, strModuleType);
			pstmtCnt.setLong(2, loginBean.getUserId());
			rstCnt = pstmtCnt.executeQuery();
			if (rstCnt.next()) {
				lTotalResults = rstCnt.getLong("total_results");
			}
			
			sbQuery .setLength(0);
			sbQuery .append("SELECT * FROM get_modules_summary(?, ?)");			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, (int)loginBean.getUserId());
			pstmt.setString(2, strModuleType);
			rst = pstmt.executeQuery();
			while(rst.next())
			{
				joModule = new JSONObject();
				joModule.put("uid",rst.getString("uid"));
				joModule.put("moduleName",rst.getString("module_name"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("description", rst.getString("description"));
				joModule.put("created_by",rst.getString("created_by"));
				joModule.put("created_on",rst.getTimestamp("created_on").getTime());
				joModule.put("type",rst.getString("counter_type_name"));
				joModule.put("version",rst.getString("type_version"));
				joModule.put("label_1",rst.getString("label_1"));
				joModule.put("counter_id_1",rst.getLong("counter_id_1"));
				joModule.put("label_2",rst.getString("label_2"));
				joModule.put("counter_id_2",rst.getLong("counter_id_2"));
				joModule.put("unit_1",rst.getString("unit_1"));
				joModule.put("unit_2",rst.getString("unit_2"));
				// joModule.put("monitor_active", rst.getBoolean("monitor_active"));
				// joModule.put("profiler_active", rst.getBoolean("profiler_active"));

/* commented, used for profiler validation
				// defaults enable profiler is disable, in js based on license its enabled
				if ( strModuleType.equals("APPLICATION") ) {
					joModule.put("enableProfiler", false);
				}
*/				
				if( rst.getString("counter_type_name").equals("MSIIS") ) {
					joModule.put("clrVersion", rst.getString("clr_version"));
				}
				
				joModule.put("slow_query_duration_unit", rst.getString("slow_query_duration_unit"));
				
				jaModules.add(joModule);
				
				UtilsFactory.clearCollectionHieracy(joModule);
			}
			
			joResult.put("totalResults", lTotalResults);
			joResult.put("moduleData", jaModules);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rstCnt);
			rstCnt = null;
			DataBaseManager.close(pstmtCnt);
			pstmtCnt = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
	 	return joResult;
	}

	
	public JSONArray getAPMModules01(Connection con, LoginUserBean loginBean, String strModuleType, String strLimit, String strOffset, JSONObject joEnt) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joModule = null, joResult = new JSONObject();
		JSONArray jaModules = new JSONArray();
		
		long lTotalResults = -1L;

		try {
			JSONObject jovariable = new JSONObject();
			JSONObject joCol_Value = new JSONObject();
			//sbQuery	.append("select * from module_master where user_id = ? AND module_code IN ('?','?','?')");
			//sbQuery	.append("select * from module_master where user_id = ? AND module_code IN ('APPLICATION','SERVER','DATABASE')");
			/*sbQuery	.append("SELECT uid, guid, module_code, module_name, description, created_by, created_on, last_appedo_received_on, ")
					.append("CASE WHEN (now()- interval '3 minutes') <= last_appedo_received_on THEN 'true' ELSE 'false' END AS active ")
					.append("from module_master where user_id = ? ")
					.append("AND module_code IN ("+strModuleType+")");*/

/*			sbQuery	.append("SELECT mm.uid, mm.guid, mm.module_code, mm.module_name, mm.description, mm.created_by, mm.created_on, mm.last_appedo_received_on, ct.counter_type_name, ")
					.append("ctv.version, CASE WHEN (now()- interval '3 minutes') <= mm.last_appedo_received_on THEN 'true' ELSE 'false' END AS active ")
					.append("from module_master mm INNER JOIN counter_type_version ctv  on ctv.counter_type_version_id = mm.counter_type_version_id AND mm.user_id = ? ")
					.append("INNER JOIN counter_type ct on ctv.counter_type_id = ct.counter_type_id AND mm.module_code IN ("+strModuleType+")")
					.append("INNER JOIN usermaster um  on um.user_id = mm.user_id");
*/
			sbQuery	.append("SELECT mm.uid, mm.guid, mm.module_code, mm.module_name, mm.description, mm.created_by, um.first_name, mm.created_on, mm.last_appedo_received_on, mm.clr_version, ct.counter_type_name, ")
							.append("ctv.version, CASE WHEN (now()- interval '3 minutes') <= mm.last_appedo_received_on THEN 'true' ELSE 'false' END AS active ")
							.append("from module_master mm LEFT JOIN counter_type_version ctv  on ctv.counter_type_version_id = mm.counter_type_version_id ")
							.append("LEFT JOIN counter_type ct on ctv.counter_type_id = ct.counter_type_id LEFT JOIN usermaster um  on um.user_id = mm.user_id ");
							if(joEnt.getInt("e_id") != 0){
								sbQuery.append("WHERE mm.e_id = ? AND mm.module_code IN ("+strModuleType+") ORDER BY mm.module_name");
							}else{
								sbQuery.append("WHERE mm.user_id = ? AND mm.module_code IN ("+strModuleType+") ORDER BY mm.module_name");
							}

			pstmt = con.prepareStatement(sbQuery.toString());
			if(joEnt.getInt("e_id") != 0){
				pstmt.setLong(1, joEnt.getInt("e_id"));
			}else{
				pstmt.setLong(1, loginBean.getUserId());
			}
			
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joModule = new JSONObject();
				//System.out.println(i++);
				if(rst.getString("module_code").equalsIgnoreCase("APPLICATION") || rst.getString("module_code").equalsIgnoreCase("SERVER") || rst.getString("module_code").equalsIgnoreCase("DATABASE")) {
					jovariable.put("var1", "is_delete");
					jovariable.put("var2", "is_edit");
					jovariable.put("var3", "is_config");
					jovariable.put("var4", rst.getString("module_code"));
				}else if(rst.getString("module_code").equalsIgnoreCase("RUM") || rst.getString("module_code").equalsIgnoreCase("LOG")) {
					jovariable.put("var1", "is_delete");
					jovariable.put("var2", "is_edit");
					jovariable.put("var3", "");
					jovariable.put("var4", rst.getString("module_code"));
				}
				
				joCol_Value.put("col_1", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				

				jovariable.put("var1", rst.getString("module_name"));
				/*jovariable.put("var2", "Added By "+rst.getString("first_name")+" on "+rst.getString("created_on"));*/
				jovariable.put("var2", "Added By "+rst.getString("first_name")+" on ");
				jovariable.put("var21", rst.getTimestamp("created_on").getTime());
				joCol_Value.put("col_2", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);

				if(rst.getString("module_code").equalsIgnoreCase("RUM")) {
					jovariable.put("var1", "");
				}else {
					if(rst.getString("description").length() > 47) {
						jovariable.put("var1", ((rst.getString("description")).substring(0, 43)).concat(" ..."));
					}else {
						jovariable.put("var1", rst.getString("description"));
					}
				}
				jovariable.put("var2", rst.getString("guid"));
				joCol_Value.put("col_3", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				if(rst.getString("module_code").equalsIgnoreCase("RUM")) {
					jovariable.put("var1", "Page Views");
				}else if(rst.getString("module_code").equalsIgnoreCase("LOG")) {
					jovariable.put("var1", "Log Recevied");
				}else{
					jovariable.put("var1", "Available");
				}
				jovariable.put("var2", "");
				jovariable.put("var3", rst.getInt("uid"));
				joCol_Value.put("col_4", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				if(rst.getString("module_code").equalsIgnoreCase("RUM")) {
					jovariable.put("var1", "");
				}else if(rst.getString("module_code").equalsIgnoreCase("LOG")) {
					jovariable.put("var1", "Log Pattern");
				}else {
					jovariable.put("var1", "Configured");
				}
				jovariable.put("var2", "");
				joCol_Value.put("col_5", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "STATUS");
				jovariable.put("var2", "");
				jovariable.put("var3", "");
				jovariable.put("var4", "");
				joCol_Value.put("col_6", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				if(rst.getString("module_code").equalsIgnoreCase("RUM")) {
					jovariable.put("var1", "Mon_RumDown");
				} else {
					jovariable.put("var1", "Mon_stat_down");
				}
				joCol_Value.put("col_7", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				if(rst.getString("module_code").equals("APPLICATION")) {
					jovariable.put("var1", "Pro_stat_down");
					
				}else if(rst.getString("module_code").equals("RUM")) {
					jovariable.put("var1", "chart_icon");
					/*joCol_Value.put("col_8", jovariable);
					UtilsFactory.clearCollectionHieracy(jovariable);*/
				}
				
				joCol_Value.put("col_8", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				joCol_Value.put("uid", rst.getInt("uid"));
				joCol_Value.put("active_status", rst.getBoolean("active"));
				joCol_Value.put("last_appedo_received_on", rst.getString("last_appedo_received_on")); 
				joCol_Value.put("type",rst.getString("counter_type_name"));
				joCol_Value.put("version",rst.getString("version"));
				joCol_Value.put("guid",rst.getString("guid"));
				joCol_Value.put("clrVersion", rst.getString("clr_version"));
				/*if( rst.getString("counter_type_name").equals("MSIIS") ) {
					//joCol_Value.put("clrVersion", rst.getString("clr_version"));
				}*/
				//joModule.put(rst.getString("module_code"), joCol_Value);
				//jaModules.add(joModule);
				
				jaModules.add(joCol_Value);
				
				UtilsFactory.clearCollectionHieracy(joModule);				
				UtilsFactory.clearCollectionHieracy(joCol_Value);
			}
			joResult.put("moduleData", jaModules);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
	 	//return joResult;'
		return jaModules;
	}

	public JSONObject getEditSUMModules(Connection con, Long testid) throws Exception{
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		String strStartDate = "", strEndDate = "";

		Timestamp tsStartDate = null, tsEndDate = null;

		boolean bTestStatus, availabilityTestStatus, smsAlert, emailAlert, repeatView = false;

		JSONArray jaSUMTests = new JSONArray();
		JSONObject joSUMTest = null;

		String browserDetails = null;
		try {
			strQuery = "SELECT * FROM get_edit_sum_test_v1(?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, testid);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joSUMTest = new JSONObject();

				bTestStatus = rst.getBoolean("status");
				availabilityTestStatus = rst.getBoolean("enable_availability_monitor");
				smsAlert = rst.getBoolean("smsalert");
				emailAlert = rst.getBoolean("emailalert");
				repeatView = rst.getBoolean("repeatView");

				joSUMTest.put("testid", rst.getString("test_id"));
				joSUMTest.put("testname", rst.getString("testname"));
				joSUMTest.put("testtype", rst.getString("testtype"));
				joSUMTest.put("testurl", rst.getString("testurl"));
				joSUMTest.put("testtransaction", rst.getString("testtransaction"));
				joSUMTest.put("trasnactionImports", rst.getString("trasnaction_imports"));
				joSUMTest.put("runevery", rst.getString("runevery"));
				joSUMTest.put("cities", rst.getString("cities"));
				joSUMTest.put("clusters", rst.getString("cluster_ids"));
				joSUMTest.put("originalstatus", bTestStatus);

				joSUMTest.put("connectionid", rst.getInt("connection_id"));
				joSUMTest.put("connectionname", rst.getString("connectionname"));
				joSUMTest.put("downloadlimit", rst.getInt("download"));
				joSUMTest.put("uploadlimit", rst.getInt("upload"));
				joSUMTest.put("latencylimit", rst.getInt("latency"));
				joSUMTest.put("packetloss", rst.getInt("packet_loss"));

				joSUMTest.put("smsalert", smsAlert);
				joSUMTest.put("emailalert", emailAlert);
				joSUMTest.put("warning", rst.getInt("warning"));
				joSUMTest.put("error", rst.getInt("error"));
				joSUMTest.put("rm_minbreachcount", rst.getInt("rm_minbreachcount"));
				joSUMTest.put("am_minbreachcount", rst.getInt("am_minbreachcount"));
				joSUMTest.put("repeatView", repeatView);
				joSUMTest.put("downtimeAlert", rst.getBoolean("downtimeAlert"));
				joSUMTest.put("rmSlaId", rst.getLong("rm_sla_id"));
				joSUMTest.put("amSlaId", rst.getLong("am_sla_id"));

				//joSUMTest.put("modifiedOn", ((Timestamp) UtilsFactory.replaceNull(rst.getTimestamp("modified_on"), rst.getTimestamp("created_on"))).getTime());
				joSUMTest.put("createdOn", ((Timestamp) rst.getTimestamp("created_on")).getTime());
				//joSUMTest.put("status", "Disabled");
				tsStartDate = rst.getTimestamp("start_date");
				strStartDate = tsStartDate.toString();
				strStartDate = strStartDate.replace(" ", "T");
				strStartDate = strStartDate + "00Z";
				joSUMTest.put("startdate", strStartDate);

				tsEndDate = rst.getTimestamp("end_date");
				strEndDate = tsEndDate.toString();
				strEndDate = strEndDate.replace(" ", "T");
				strEndDate = strEndDate + "00Z";
				joSUMTest.put("enddate", strEndDate);

				if ( ! bTestStatus ) {
					// for Test status Disabled, to show as `Disabled`					
					joSUMTest.put("status", "Disabled");
				} else {
					joSUMTest.put("status", rst.getString("teststatus"));
				}

				if( joSUMTest.getString("testtype").equals("TRANSACTION") ) {
					joSUMTest.put("availabilityTestStatus", "N/A");
				} else if ( ! availabilityTestStatus ) {
					joSUMTest.put("availabilityTestStatus", "Disabled");
				} else {
					joSUMTest.put("availabilityTestStatus", rst.getString("teststatus"));
				}

				browserDetails = getSUMBrowserDetailsBySUMTestId_01(con, joSUMTest.getInt("testid"));
				
				
				if(browserDetails!=null){
					joSUMTest.put("browserDetails", browserDetails);
				}
				//System.out.println("Length of browser details json : "+ joSUMTest.getString(browserDetails).length());

				joSUMTest.put("enableAvailabilityMonitor", rst.getBoolean("enable_availability_monitor"));
				joSUMTest.put("availabilityMonitorFrequency", rst.getInt("availability_monitor_frequency"));

				jaSUMTests.add(joSUMTest);

				//joSUMTest = null;
				strStartDate = null;
				strEndDate = null;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			strQuery = null;
		}
		
		//return jaSUMTests;
		return joSUMTest;
	}
	
	public JSONArray getEnterpriseModules(Connection con, LoginUserBean loginBean) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaEnterprise = new JSONArray();
		JSONObject joSUMData = null, joCol_Value = null;
		//StringBuffer browserDetails = null;
		String browserDetails = null;
		
		try {
			joSUMData = new JSONObject();
			joCol_Value = new JSONObject();
			JSONObject jovariable = new JSONObject();
			
			// Enterprise License implemented
			sbQuery	.append("select em.e_id , em.e_name, em.description, em.created_on, um.first_name , count(uem.e_id) AS mapped_user ")
					.append("from enterprise_master em INNER JOIN user_enterprise_mapping uem ON em.e_id =uem.e_id ")
					.append("LEFT JOIN usermaster um ON um.user_id = em.user_id WHERE em.user_id = ? GROUP BY 1,2,3,4,5");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginBean.getUserId());

			rst = pstmt.executeQuery();
			
			while (rst.next()) {
				
				//col_1 Values
				jovariable.put("var1", "is_delete");
				jovariable.put("var2", "is_edit");
				jovariable.put("var3", "is_config");
				jovariable.put("var4", "Enterprise");
				joCol_Value.put("col_1", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_2 Values
				jovariable.put("var1", rst.getString("e_name"));
				jovariable.put("var2", "Added By "+rst.getString("first_name")+" on ");
				jovariable.put("var21", rst.getTimestamp("created_on").getTime());
				joCol_Value.put("col_2", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_3 Values
				jovariable.put("var1", rst.getString("description"));
				jovariable.put("var2", "");
				joCol_Value.put("col_3", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_4 Values
				jovariable.put("var1", "Config User");
				jovariable.put("var2", rst.getInt("mapped_user"));
				joCol_Value.put("col_4", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
/*				//col_5 Values
				jovariable.put("var1", "");
				jovariable.put("var2", "");
				joCol_Value.put("col_5", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_6 Values
				jovariable.put("var1", "STATUS_Live");
				jovariable.put("var2", rst.getString("teststatus"));
				joCol_Value.put("col_6", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_7 Values
				jovariable.put("var1", "SUM_Details");
	
				jovariable.put("var2", rst.getString("browser_name"));
				jovariable.put("var3", rst.getString("connectionname"));
				jovariable.put("var4", rst.getBoolean("repeatView"));
				joCol_Value.put("col_7", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
*/				
				//Parameter Values
				joCol_Value.put("e_id", rst.getString("e_id"));
				jaEnterprise.add(joCol_Value);
				UtilsFactory.clearCollectionHieracy(joCol_Value);

			}
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( strQuery );
		}
		return jaEnterprise;
	}
	
	public JSONArray getSUMModules(Connection con, LoginUserBean loginBean, JSONObject joEnterprise) throws Exception{
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaSUMTests = new JSONArray();
		JSONObject joSUMData = null, joCol_Value = null;
		//StringBuffer browserDetails = null;
		String browserDetails = null;
		
		try {
			joSUMData = new JSONObject();
			joCol_Value = new JSONObject();
			JSONObject jovariable = new JSONObject();
			
			//strQuery = "SELECT * FROM v1_get_new_sum_test(?)";
			/*sbQuery	.append("select stm.test_id, stm.testname, stm.start_date, stm.end_date, stm.testtype, stm.testurl, stm.runevery, stm.repeat_view as repeatView, ")
					.append("replace(group_concat( replace(stcm.location, '--', ' - ') ), '\"', '')as cities, count(stcm.location) as selected_location, ")
					.append("sc.display_name as connectionname, browser.browser_name, CASE WHEN stm.status = true AND stm.start_date < now() AND stm.end_date > now() THEN 'Running' ")
					.append("WHEN stm.status = true AND stm.start_date > now() AND stm.end_date > now() THEN 'Scheduled' ")
					.append("WHEN stm.status = true AND stm.start_date < now() AND stm.end_date < now() THEN 'Completed' ")
					.append("WHEN stm.status = false THEN 'Disabled' ELSE 'N/A' END AS teststatus ")
					.append("from sum_test_master stm LEFT JOIN sum_test_cluster_mapping stcm ON stcm.test_id = stm.test_id ")
					.append("LEFT JOIN sum_connectivity sc ON sc.connection_id = stm.connection_id ")
					.append("LEFT JOIN (select stdob.sum_test_id, group_concat(sdob.browser_name) as browser_name from sum_device_os_browser as sdob , sum_test_device_os_browser as ")
					.append("stdob, sum_test_master as stm1 where sdob.dob_id = stdob.device_os_browser_id and stm1.test_id = stdob.sum_test_id and stm1.user_id = ? ")
					.append("group by stdob.sum_test_id) as browser ON browser.sum_test_id = stm.test_id ")
					.append("WHERE stm.user_id = ? AND stm.is_delete = FALSE GROUP BY stm.test_id, stcm.test_id, browser.browser_name, connectionname ORDER BY stm.testname");*/
			
			// Enterprise License implemented
			
			sbQuery	.append("select stm.test_id, stm.testname, stm.start_date, stm.end_date, stm.testtype, stm.testurl, stm.runevery, stm.repeat_view as repeatView, ")
					.append("replace(group_concat( replace(stcm.location, '--', ' - ') ), '\"', '')as cities, count(stcm.location) as selected_location, ")
					.append("sc.display_name as connectionname, browser.browser_name, CASE WHEN stm.status = true AND stm.start_date < now() AND stm.end_date > now() THEN 'Running' ")
					.append("WHEN stm.status = true AND stm.start_date > now() AND stm.end_date > now() THEN 'Scheduled' ")
					.append("WHEN stm.status = true AND stm.start_date < now() AND stm.end_date < now() THEN 'Completed' ")
					.append("WHEN stm.status = false THEN 'Disabled' ELSE 'N/A' END AS teststatus ")
					.append("from sum_test_master stm LEFT JOIN sum_test_cluster_mapping stcm ON stcm.test_id = stm.test_id ")
					.append("LEFT JOIN sum_connectivity sc ON sc.connection_id = stm.connection_id ")
					.append("LEFT JOIN (select stdob.sum_test_id, group_concat(sdob.browser_name) as browser_name from sum_device_os_browser as sdob , sum_test_device_os_browser as ")
					.append("stdob, sum_test_master as stm1 where sdob.dob_id = stdob.device_os_browser_id and stm1.test_id = stdob.sum_test_id and stm1.user_id = ? ");
					if(joEnterprise.getInt("e_id")!=0){
						sbQuery	.append("and e_id = ").append(joEnterprise.getInt("e_id")+" ");
					}
			sbQuery	.append("group by stdob.sum_test_id) as browser ON browser.sum_test_id = stm.test_id WHERE stm.user_id = ? ");
					if(joEnterprise.getInt("e_id")!=0){
						sbQuery	.append("and e_id = ").append(joEnterprise.getInt("e_id")+" ");
					}
			sbQuery	.append("AND stm.is_delete = FALSE GROUP BY stm.test_id, stcm.test_id, browser.browser_name, connectionname ORDER BY stm.testname");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
				pstmt.setLong(2, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, loginBean.getUserId());
				pstmt.setLong(2, loginBean.getUserId());
			}
			rst = pstmt.executeQuery();
			
			while (rst.next()) {
				
				//col_1 Values
				jovariable.put("var1", "is_delete");
				jovariable.put("var2", "is_edit");
				jovariable.put("var3", "");
				jovariable.put("var4", "SUM");
				joCol_Value.put("col_1", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_2 Values
				jovariable.put("var1", rst.getString("testname"));
				jovariable.put("var2", "Run Duration: "+ rst.getDate("start_date") + " to " + rst.getDate("end_date"));
				joCol_Value.put("col_2", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_3 Values
				if(rst.getString("testtype").equalsIgnoreCase("URL")) {
					jovariable.put("var1", rst.getString("testtype")+" : "+ rst.getString("testurl"));
				} else {
					jovariable.put("var1", rst.getString("testtype"));
				}
				jovariable.put("var2", rst.getString("cities"));
				joCol_Value.put("col_3", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_4 Values
				jovariable.put("var1", "Run Every");
				jovariable.put("var2", rst.getString("runevery"));
				joCol_Value.put("col_4", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_5 Values
				jovariable.put("var1", "Location");
				jovariable.put("var2", rst.getInt("selected_location"));
				joCol_Value.put("col_5", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_6 Values
				jovariable.put("var1", "STATUS_Live");
				jovariable.put("var2", rst.getString("teststatus"));
				joCol_Value.put("col_6", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//col_7 Values
				jovariable.put("var1", "SUM_Details");
				//browserDetails = getSUMBrowserDetailsBySUMTestId(con, rst.getInt("test_id"));
				//jovariable.put("var2", browserDetails);
				//System.out.println("BrowserDetails: "+ browserDetails);
				//jovariable.put("var2", "Browser(s):CHROME");
				jovariable.put("var2", rst.getString("browser_name"));
				//jovariable.put("var2", browserDetails.toString()); 
				//jovariable.put("var3", "connection:Cable(5/1 Mbps 28ms RRT)");
				jovariable.put("var3", rst.getString("connectionname"));
				jovariable.put("var4", rst.getBoolean("repeatView"));
				joCol_Value.put("col_7", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//Parameter Values
				joCol_Value.put("testid", rst.getString("test_id"));
				joCol_Value.put("testtype", rst.getString("testtype"));
				jaSUMTests.add(joCol_Value);
				UtilsFactory.clearCollectionHieracy(joCol_Value);

			}
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( strQuery );
		}
		return jaSUMTests;
	}
	
	public String getSUMBrowserDetailsBySUMTestId(Connection con,int sumTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		StringBuffer sb = new StringBuffer();
		
		try {
			//sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserDetails\" from (select sdob.dob_id as \"dobId\",sdob.device_type as \"deviceType\",sdob.os_name as \"osName\",sdob.browser_name as \"browserName\" FROM sum_device_os_browser  as sdob ,sum_test_device_os_browser  as stdob  where sdob.dob_id = stdob.device_os_browser_id and stdob.sum_test_id = ? order by sdob.is_default) t");
			//sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserDetails\" from (select sdob.dob_id as \"dobId\",sdob.device_type as \"deviceType\",sdob.os_name as \"osName\",sdob.browser_name as \"browserName\",true as \"isSelected\" FROM sum_device_os_browser  as sdob ,sum_test_device_os_browser  as stdob  where sdob.dob_id = stdob.device_os_browser_id and stdob.sum_test_id = ? order by sdob.is_default) t");
			sbQuery.append("select  group_concat(sdob.browser_name) as browser_name from sum_device_os_browser as sdob , sum_test_device_os_browser as stdob where sdob.dob_id = stdob.device_os_browser_id and stdob.sum_test_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, sumTestId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				//jsonString = rst.getString("browserDetails");
				jsonString = rst.getString("browser_name");
				//sb.append(rst.getString("browser_name")+",");
				
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
		//return sb;
	}
	
	public String getSUMBrowserDetailsBySUMTestId_01(Connection con,int sumTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
//			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserDetails\" from (select sdob.dob_id as \"dobId\",sdob.device_type as \"deviceType\",sdob.os_name as \"osName\",sdob.browser_name as \"browserName\" FROM sum_device_os_browser  as sdob ,sum_test_device_os_browser  as stdob  where sdob.dob_id = stdob.device_os_browser_id and stdob.sum_test_id = ? order by sdob.is_default) t");
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserDetails\" from (select sdob.dob_id as \"dobId\",sdob.device_type as \"deviceType\",sdob.os_name as \"osName\",sdob.browser_name as \"browserName\",true as \"isSelected\" FROM sum_device_os_browser  as sdob ,sum_test_device_os_browser  as stdob  where sdob.dob_id = stdob.device_os_browser_id and stdob.sum_test_id = ? order by sdob.is_default) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, sumTestId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("browserDetails");	
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	
	public JSONObject getAPMModules2(Connection con, LoginUserBean loginBean, String strUid) throws Exception {
		PreparedStatement pstmt = null, pstmtCnt = null;
		ResultSet rst = null, rstCnt = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joModule = null, joResult = new JSONObject();
		JSONArray jaModules = new JSONArray();
		//JSONObject joValues = new JSONObject(); 

		try {
			sbQuery .append("select count(CASE WHEN is_selected = true THEN 1 ELSE NULL END) AS configured, count(counter_id) AS available from counter_master_").append(strUid);
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next())
			{
				/*joModule = new JSONObject();
				joModule.put("configured",rst.getString("configured"));
				joModule.put("available",rst.getString("available"));*/
				//jaModules.add(joModule);
				
				//joResult.put("moduleData", joModule);
				
				joResult.put("configured",rst.getInt("configured"));
				joResult.put("available",rst.getInt("available"));
				joResult.put("uid",strUid);
				UtilsFactory.clearCollectionHieracy(joModule);
			}
			
			//joResult.put("moduleData", jaModules);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rstCnt);
			rstCnt = null;
			DataBaseManager.close(pstmtCnt);
			pstmtCnt = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
	 	return joResult;
	}	
	
	public void setAsDefaultInCard(Connection con, LoginUserBean loginBean, String strModuleType) throws Exception {
		PreparedStatement pstmt  = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery.append("UPDATE default_page_settings SET module_type = ? , modified_on = now(), modified_by = ? WHERE user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strModuleType);
			pstmt.setLong(2, loginBean.getUserId());
			pstmt.setLong(3, loginBean.getUserId());
			pstmt.executeUpdate();
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
	}
	
	public void setAsDefaultDashboard(Connection con, LoginUserBean loginBean, String strHealthCode, Long lServiceMapId) throws Exception {
		PreparedStatement pstmt  = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			
			sbQuery.append("UPDATE default_page_settings set ");
			if (lServiceMapId != null) {
				sbQuery.append(" service_map_id = ").append(lServiceMapId);
			} else {
				sbQuery.append(" crit_warn_name = '").append(strHealthCode).append("'");
			}
			sbQuery.append(", modified_on = now(), modified_by = ? WHERE user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginBean.getUserId());
			pstmt.setLong(2, loginBean.getUserId());
			pstmt.executeUpdate();
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
	}
	
	public JSONObject getLogRunningStatus(Connection con, LoginUserBean loginBean, String strUid) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joResult = null, joLogResult = null;
		
		try {
			joResult = new JSONObject();
			joLogResult = new JSONObject();
			sbQuery .append("select * from getLogStatus(?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, Integer.parseInt(strUid));
			rst = pstmt.executeQuery();
			int inf = 0;
			int war = 0;
			int cri = 0;
			String log_name = "";
			int count = 0;
			while(rst.next())
			{
				log_name = log_name + rst.getString("log_name")+",";
				inf = inf + rst.getInt("info");
				war = war + rst.getInt("warning");
				cri = cri + rst.getInt("critical");
				count++;
			}
			
			joResult.put("log_name",log_name);
			joResult.put("info",inf);
			joResult.put("warning",war);
			joResult.put("critical",cri);
			joResult.put("Log_Recived",inf+war+cri);
			joResult.put("Log_pattern",count);
			joResult.put("uid",strUid);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	 	return joResult;
	}
	
	public JSONArray getAPMCardStatus(Connection con, LoginUserBean loginBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmtCnt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joModule = null,joResult = new JSONObject();
		JSONArray jaModules = new JSONArray();
		try {
			sbQuery	.append("select uid, breached_severity, count(counter_id) AS status_count ")
					.append("from (select b.uid, b.counter_id, b.breached_severity ");
			if(joEnterprise.getInt("e_id") != 0){
				sbQuery.append("from so_threshold_breach_").append(joEnterprise.getInt("e_user_id")).append(" ");
			}else{
				sbQuery.append("from so_threshold_breach_").append(loginBean.getUserId()).append(" ");
			}
			sbQuery .append("b inner join (select counter_id, MAX(so_tb_id) so_tb_id,uid ");
			if(joEnterprise.getInt("e_id") != 0){
				sbQuery.append("from so_threshold_breach_").append(joEnterprise.getInt("e_user_id")).append(" ");
			}else{
				sbQuery.append("from so_threshold_breach_").append(loginBean.getUserId()).append(" ");
			}
			sbQuery .append("where (now()- interval '1 days') <= received_on ");
			if(joEnterprise.getInt("e_id") != 0){
				sbQuery.append("AND uid IN (select uid from module_master where e_id = ").append(joEnterprise.getInt("e_id")).append(") ");
			}
			sbQuery .append("group by counter_id,uid ) as a on a.so_tb_id =b.so_tb_id) b group by uid, breached_severity order by uid");
			
			pstmtCnt = con.prepareStatement(sbQuery.toString());
			rst = pstmtCnt.executeQuery();
			while(rst.next()) {
				joModule = new JSONObject();
				joModule.put("uid", rst.getString("uid"));
				joModule.put("status_severity", rst.getString("breached_severity"));
				joModule.put("status_count", rst.getInt("status_count"));
				
				jaModules.add(joModule);
			}
			joResult.put("statusReport", jaModules);
			
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(pstmtCnt);
			pstmtCnt = null;
			DataBaseManager.close(rst);
			rst = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return jaModules;
	}
	
	public JSONArray getRUMCardStatus(Connection con, LoginUserBean loginBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmtCnt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joModule = null,joResult = new JSONObject();
		JSONArray jaModules = new JSONArray();
		try {
			/*sbQuery	.append("select uid, breached_severity, count(rum_id) AS status_count ")
					.append("from (select b.uid, b.rum_id, b.breached_severity ")
					.append("from so_rum_threshold_breach_").append(loginBean.getUserId()).append(" ")
					.append("b inner join (select rum_id, MAX(so_rum_tb_id) so_rum_tb_id,uid ")
					.append("from so_rum_threshold_breach_").append(loginBean.getUserId()).append(" ")
					.append("where (now()- interval '1 hour') <= received_on group by rum_id,uid ) as a ")
					.append("on a.so_rum_tb_id =b.so_rum_tb_id) b group by uid, breached_severity order by uid");*/
					
			/*sbQuery	.append("select uid, breached_severity, count(so_rum_tb_id) AS status_count ")
					.append("from so_rum_threshold_breach_").append(loginBean.getUserId()).append(" ")
					.append("where received_on >= (now()- interval '1 hour') group by breached_severity , uid");*/
			
			sbQuery	.append("select uid, breached_severity, count(so_rum_tb_id) AS status_count ");
				if(joEnterprise.getInt("e_id") != 0){
					sbQuery.append("from so_rum_threshold_breach_").append(joEnterprise.getInt("e_user_id")).append(" ");
				}else{
					sbQuery.append("from so_rum_threshold_breach_").append(loginBean.getUserId()).append(" ");
				}
				sbQuery .append("where received_on >= (now()- interval '1 hour') ");
				if(joEnterprise.getInt("e_id") != 0){
					sbQuery.append("AND uid IN (select uid from module_master where e_id = ").append(joEnterprise.getInt("e_id")).append(") ");
				}
				sbQuery.append("group by breached_severity , uid");
				
			pstmtCnt = con.prepareStatement(sbQuery.toString());
			rst = pstmtCnt.executeQuery();
			while(rst.next()) {
				joModule = new JSONObject();
				joModule.put("uid", rst.getString("uid"));
				joModule.put("status_severity", rst.getString("breached_severity"));
				joModule.put("status_count", rst.getInt("status_count"));
				jaModules.add(joModule);
			}
			joResult.put("statusReport", jaModules);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(pstmtCnt);
			pstmtCnt = null;
			DataBaseManager.close(rst);
			rst = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return jaModules;
	}

	/**
	 * Add new module which can be Application, Server or Database or others
	 * 
	 * @param con
	 * @param applicationBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public long insertModule(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception	{
		PreparedStatement pstmt = null;
		String strQuery = null;
		
		long lModuleId = -1L;
		
		try {
			strQuery = "INSERT INTO module_master (user_id, guid, module_code, counter_type_version_id, module_name, description, clr_version, created_by, created_on, e_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, now(), ?) ";
			
			pstmt = con.prepareStatement(strQuery, PreparedStatement.RETURN_GENERATED_KEYS);
			
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, moduleBean.getGuid());
			pstmt.setString(3, moduleBean.getModuleType());
			pstmt.setInt(4, moduleBean.getAgentVersionId());
			pstmt.setString(5, moduleBean.getModuleName());
			pstmt.setString(6, moduleBean.getDescription());
			pstmt.setString(7, moduleBean.getCLRVersion());
			pstmt.setLong(8, loginUserBean.getUserId());
			if(joEnterprise.getBoolean("is_owner") && joEnterprise.getInt("e_id") != 0){
				pstmt.setInt(9, joEnterprise.getInt("e_id"));
			}else{
				/*pstmt.setInt(9, Integer.parseInt(null));*/
				pstmt.setNull(9, java.sql.Types.INTEGER);
			}
			pstmt.executeUpdate();
			
			lModuleId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		
		return lModuleId;
	}
	
	public long addEnterprise(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception	{
		PreparedStatement pstmt = null;
		String strQuery = null;
		
		long lEnterpriseId = -1L;
		
		try {
			strQuery = "INSERT INTO enterprise_master (e_name, user_id, description, created_by, created_on) VALUES (?, ?, ?, ?, now()) ";
			
			pstmt = con.prepareStatement(strQuery, PreparedStatement.RETURN_GENERATED_KEYS);
			
			pstmt.setString(1, moduleBean.getModuleName());
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, moduleBean.getDescription());
			pstmt.setLong(4, loginUserBean.getUserId());
			pstmt.executeUpdate();
			
			lEnterpriseId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		
		return lEnterpriseId;
	}
		
	public JSONArray getMapUsers(Connection con, long e_Id, long lUser_id) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONArray jaMapUsers = new JSONArray();
		JSONObject joMapUser = null;

		try {
			// ASK below query
			sbQuery	.append("select email_id, e_id from user_enterprise_mapping where e_id = ? AND user_id != ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, e_Id);
			pstmt.setLong(2, lUser_id);
			rst = pstmt.executeQuery();
			while(rst.next()){
				joMapUser = new JSONObject();
				joMapUser.put("userName", rst.getString("email_id"));
				joMapUser.put("e_id", rst.getString("e_id"));
				jaMapUsers.add(joMapUser);

				joMapUser = null;
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jaMapUsers;
	}
	
	public void deleteMapUser(Connection con, Integer e_Id, String strUserName) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from user_enterprise_mapping ")
					.append("WHERE email_id = ? AND e_id = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setString(1, strUserName);
			pstmt.setLong(2, e_Id);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	public void deleteEnterprise(Connection con, Integer e_Id) throws Exception {
		
		PreparedStatement pstmt = null, pstmt1 = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from user_enterprise_mapping WHERE e_id = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, e_Id);
			pstmt.execute();
			
			sbQuery = new StringBuilder();
			sbQuery.append("DELETE FROM enterprise_master WHERE e_id = ?");
			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.setLong(1, e_Id);
			pstmt1.executeUpdate();
			
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			pstmt1 = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	public void userEnterpriseMapping(Connection con, long lEnterpriseId, long lUser_id, String strEmail_id) throws Exception	{
		PreparedStatement pstmt = null;
		String strQuery = null;

		try {
			strQuery = "INSERT INTO user_enterprise_mapping (e_id, user_id, email_id, created_on) VALUES (?, ?, ?, now()) ";
			
			pstmt = con.prepareStatement(strQuery);
			
			pstmt.setLong(1, lEnterpriseId);
			pstmt.setLong(2, lUser_id);
			pstmt.setString(3, strEmail_id);
			pstmt.executeUpdate();
			
			lEnterpriseId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
	
	}
	
	public long insertEmailVerificationHistory(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQurey = "";
		
		long lVerificationHistoryId;
		
		try {
			strQurey = "INSERT INTO login_verification_history (user_id, activity, created_on) VALUES (?, 'EMAIL_ID_VERIFICATION', now()) ";
			
			pstmt = con.prepareStatement(strQurey, PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, lUserId);
			pstmt.executeUpdate();
			
			lVerificationHistoryId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQurey = null;
		}
		
		return lVerificationHistoryId;
	}
	
	public void insertChartVisualData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, String query) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("INSERT INTO chart_visual_").append(loginUserBean.getUserId())
					.append(" (chart_title, legend_text, module_type, metric_category, counter_template_id, metric_name, unit,")
					.append(" ref_table_name, ref_table_pkey_id, query, created_by, created_on)")
					.append(" SELECT '").append(moduleBean.getModuleName()).append("', cm.display_name, '").append(moduleBean.getModuleType())
					.append("', cm.category, cm.counter_template_id, cm.counter_name, cm.unit, 'counter_master_").append(moduleBean.getModuleId())
					.append("', cm.counter_id,").append(UtilsFactory.makeValidVarchar(query)).append(", cm.user_id, now()")
					.append(" FROM counter_master_").append(moduleBean.getModuleId()).append(" cm WHERE")
					.append(" cm.is_selected = true");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	public void insertChartVisualizationData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, String query) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("INSERT INTO chart_visualization_").append(loginUserBean.getUserId())
					.append(" (chart_title, legend_text, module_type, category, counter_template_id, unit, ")
					.append(" axis_label, xy_axis_label, ref_table_name, ref_table_pkey_id, query, created_by, created_on) ")
					.append(" SELECT '").append(moduleBean.getModuleType()).append("-").append(moduleBean.getModuleName().replace("'", "''")).append("-")
					.append("'||cm.category, cm.display_name, '").append(moduleBean.getModuleType()).append("', cm.category, cm.counter_template_id, ")
					.append(" cm.unit, cm.unit, 'Date Time', 'counter_master_").append(moduleBean.getModuleId()).append("', cm.counter_id, ")
					.append(UtilsFactory.makeValidVarchar(query)).append(", cm.user_id, now() ")
					.append(" FROM counter_master_").append(moduleBean.getModuleId()).append(" cm WHERE ")
					.append(" cm.is_selected = true");
					
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	public void insertChartVisualDataRUM(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, String query) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("INSERT INTO chart_visual_").append(loginUserBean.getUserId())
					.append(" (chart_title, legend_text, module_type, metric_category, metric_name, chart_type, mma_enabled, ")
					.append(" aggregation, clickable, mouse_move_tooltip, ref_table_name, ref_table_pkey_id, query, created_by, created_on)")
					.append(" SELECT module_name, 'Page View(s)', module_code, module_code, 'View(s)', 'bar', FALSE, '', TRUE, FALSE, ")
					.append(" 'rum_collector_").append(moduleBean.getModuleId()).append("', '").append(moduleBean.getModuleId())
					.append("',").append(UtilsFactory.makeValidVarchar(query)).append(" , user_id, now()")
					.append(" FROM module_master WHERE user_id=").append(loginUserBean.getUserId()).append(" AND uid =").append(moduleBean.getModuleId());
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	/*public void insertChartVisualizationDataRUM(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, String query) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("INSERT INTO chart_visualization_").append(loginUserBean.getUserId())
					.append(" (chart_title, legend_text, module_type, category, unit, chart_type, enable_mma, axis_label, sel_graph_value, ")
					.append(" xy_axis_label, ref_table_name, ref_table_pkey_id, query, created_by, created_on ) ")
					.append(" SELECT module_name||'::'||module_code, 'Page View(s)', module_code, 'Views' , '', 'vbar' , FALSE, 'Page Views', ")
					.append(" 'count', 'Date Time', 'rum_collector_").append(moduleBean.getModuleId()).append("', '").append(moduleBean.getModuleId())
					.append("',").append(UtilsFactory.makeValidVarchar(query)).append(" , user_id, now()")
					.append(" FROM module_master WHERE user_id=").append(loginUserBean.getUserId()).append(" AND uid =").append(moduleBean.getModuleId());
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}*/
	
	public void insertChartVisualizationDataRUM(Connection con, Long lModuleId, LoginUserBean loginUserBean) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("SELECT * from insert_chart_visualization_data_RUM(?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.setLong(2, loginUserBean.getUserId());
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	/**
	 * Update given module which can be Application, Server or Database or others
	 * 
	 * @param con
	 * @param applicationBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateModule(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception
	{
		PreparedStatement pstmt = null;
		String strQuery = null;
		
		try {
			strQuery = "UPDATE module_master SET module_name = ?, description = ?, modified_by = ?, modified_on = now() WHERE uid = ? AND module_code = ?";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, moduleBean.getModuleName());
			pstmt.setString(2, moduleBean.getDescription());
			pstmt.setLong(3, loginUserBean.getUserId());
			pstmt.setLong(4, moduleBean.getModuleId());
			pstmt.setString(5, moduleBean.getModuleType());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
	}
	
	public void updateEnterpriseModule(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception
	{
		PreparedStatement pstmt = null;
		String strQuery = null;
		
		try {
			strQuery = "UPDATE enterprise_master SET e_name = ?, description = ?, modified_by = ?, modified_on = now() WHERE e_id = ? AND user_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, moduleBean.getModuleName());
			pstmt.setString(2, moduleBean.getDescription());
			pstmt.setLong(3, loginUserBean.getUserId());
			pstmt.setLong(4, moduleBean.getModuleId());
			pstmt.setLong(5, loginUserBean.getUserId());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
	}
	
	public String getOldModuleName(Connection con, long lUID) throws Exception
	{
		PreparedStatement pstmt = null;
		String strQuery = null;
		ResultSet rst = null;
		String oldModuleName = null;
		
		try {
			strQuery = "SELECT module_name from module_master where uid = ?";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUID);
			
			rst = pstmt.executeQuery();
			
			if (rst.next()) {
				oldModuleName = rst.getString("module_name");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		return oldModuleName;
	}
	
	public void updateChartVisualModuleData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception
	{
		PreparedStatement pstmt = null;
		String strQuery = null;
		
		try {
			if (moduleBean.getModuleType().equals(Constants.RUM_MODULE))
			{
				strQuery = "UPDATE chart_visual_"+loginUserBean.getUserId()+" SET chart_title = ?, modified_by = ?, modified_on = now() WHERE ref_table_name LIKE 'rum_collector_"+moduleBean.getModuleId()+"' AND module_type = ?";
			} else {
				strQuery = "UPDATE chart_visual_"+loginUserBean.getUserId()+" SET chart_title = ?, modified_by = ?, modified_on = now() WHERE ref_table_name LIKE 'counter_master_"+moduleBean.getModuleId()+"' AND module_type = ?";
			}
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, moduleBean.getModuleName());
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, moduleBean.getModuleType());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
	}
	
	public void updateChartVisualizationData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception
	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			if (moduleBean.getModuleType().equals(Constants.RUM_MODULE))
			{
				sbQuery.append("UPDATE chart_visualization_").append(loginUserBean.getUserId()).append(" SET chart_title = '")
						.append(moduleBean.getModuleType()).append("-Views-").append(moduleBean.getModuleName().replace("'", "''"))
						.append("', modified_by = ?, modified_on = now() WHERE ref_table_name LIKE 'rum_collector_").append(moduleBean.getModuleId()).append("' AND module_type = ?");
			} else if (moduleBean.getModuleType().equals(Constants.LOG_MODULE)){
				sbQuery.append("UPDATE chart_visualization_").append(loginUserBean.getUserId()).append(" SET chart_title = '")
						.append(moduleBean.getModuleType()).append("-").append(moduleBean.getModuleName().replace("'", "''")).append("', category = ").append(UtilsFactory.makeValidVarchar(moduleBean.getDescription()))
						.append(", modified_by = ?, modified_on = now() WHERE ref_table_pkey_id =").append(moduleBean.getModuleId()).append(" AND module_type = ?");
			}
			pstmt = con.prepareStatement(sbQuery.toString());
		//	pstmt.setString(1, moduleBean.getModuleType()+"-"+moduleBean.getModuleName());
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, moduleBean.getModuleType());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	public void updateChartVisualizationOADData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception
	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			
			sbQuery.append("SELECT update_chart_visualization_data (?, ?, ?, ?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
		
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setLong(2, moduleBean.getModuleId());
			pstmt.setString(3, moduleBean.getOldModuleName());
			pstmt.setString(4, moduleBean.getModuleName());
			pstmt.setString(5, moduleBean.getModuleType());
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	/**
	 * Delete given module which can be Application, Server or Database or others
	 * 
	 * @param con
	 * @param applicationBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteModule(Connection con, long lModuleId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("DELETE FROM module_master WHERE uid = ? AND user_id = ?");
			
			pstmt = con.prepareStatement( sbQuery.toString() );
			
			pstmt.setLong(1, lModuleId);
			pstmt.setLong(2, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
	}
	
	/**
	 * Drop log related Table's
	 * 
	 * @param con
	 * @param uid
	 * 
	 */
	public void dropLogsTables(Connection con, long lModuleId) throws Exception{
		PreparedStatement pstmt = null;
		//Statement stmt = null, stmt1 = null, stmt2 = null, stmt3 = null, stmt4 = null;
		StringBuilder sbQuery = new StringBuilder();
		
		
		try{
			sbQuery.append( "select * from delete_log_details(?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.execute();
			
			/*sbQuery.append("DROP TABLE  IF EXISTS log_syslog_").append(lModuleId);
			stmt = con.createStatement();
			stmt.execute(sbQuery.toString());
			sbQuery.setLength(0);
			
			sbQuery.append("DROP TABLE  IF EXISTS log_tomcat_catalina_").append(lModuleId);
			stmt1 = con.createStatement();
			stmt.execute(sbQuery.toString());
			sbQuery.setLength(0);

			sbQuery.append("DROP TABLE  IF EXISTS log_tomcat_access_").append(lModuleId);
			stmt2 = con.createStatement();
			stmt.execute(sbQuery.toString());
			sbQuery.setLength(0);

			sbQuery.append("DROP TABLE  IF EXISTS log_log4j_error_").append(lModuleId);
			stmt3 = con.createStatement();
			stmt.execute(sbQuery.toString());
			sbQuery.setLength(0);

			sbQuery.append("DROP TABLE  IF EXISTS log_general_").append(lModuleId);
			stmt4 = con.createStatement();
			stmt.execute(sbQuery.toString());
			sbQuery.setLength(0);
*/			
		}catch(Exception e) {
			throw e;
		}finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	//remove_my_chart
	public void removeMyChart(Connection con, long lUserId, long lEID, long lModuleId, String strModuleType) throws Exception{
		PreparedStatement pstmt = null;
		//Statement stmt = null, stmt1 = null, stmt2 = null, stmt3 = null, stmt4 = null;
		StringBuilder sbQuery = new StringBuilder();
		
		
		try{
			sbQuery.append( "select remove_user_ent_my_chart(?, ?, ?, ?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lEID);
			pstmt.setLong(2, lUserId);
			pstmt.setLong(3, lModuleId);
			pstmt.setString(4, strModuleType);
			pstmt.execute();
						
		}catch(Exception e) {
			throw e;
		}finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	/**
	 *  Checking module name is already exist or not
	 *  
	 * @param con
	 * @param moduleBean
	 * @param loginUserBean
	 * @param bExcludeThis
	 * @return
	 * @throws Exception
	 */
	public boolean isModuleExist(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, Boolean bExcludeThis) throws Exception
	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rst = null;
		boolean flag ;
		try {
			sbQuery	.append("SELECT uid, true from module_master where lower(module_name)=LOWER(?) ")
					.append("AND user_id=? AND module_code=?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, moduleBean.getModuleName());
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, moduleBean.getModuleType());
			
			rst = pstmt.executeQuery();
			
			if(rst.next()){
				if( bExcludeThis !=null && bExcludeThis == true && 
						rst.getInt("uid")==moduleBean.getModuleId())
				{
					flag = false;
				}else{
					flag = true;
				}
			}else{
				flag = false;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return flag;
	}
	/**
	 *  Checking module name is already exist or not
	 *  
	 * @param con
	 * @param moduleBean
	 * @param loginUserBean
	 * @param bExcludeThis
	 * @return
	 * @throws Exception
	 */
	public boolean isModuleExist(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception
	{
		
		boolean flag = isModuleExist(con, moduleBean, loginUserBean, false);
		
		return flag;
	}
	public JSONObject getModules(Connection con, String strModuleType, String strLimit, String strOffset, LoginUserBean loginUserBean) throws Exception
	{
		PreparedStatement pstmt = null, pstmtCnt = null;
		ResultSet rst = null, rstCnt = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joModule = null, joResult = new JSONObject();
		JSONArray jaModules = new JSONArray();
		
		long lTotalResults = -1L;
		
		try {
			sbQuery .append("SELECT count(*) AS total_results ")
					.append("FROM module_master mm ")
					.append("INNER JOIN counter_type_version ctv on ctv.counter_type_version_id = mm.agent_version_id AND mm.module_code = ? ")
					.append("INNER JOIN counter_type ct on ctv.counter_type_id = ct.counter_type_id ")
					.append("AND mm.user_id = ? ");
			pstmtCnt = con.prepareStatement(sbQuery.toString());
			pstmtCnt.setString(1, strModuleType);
			pstmtCnt.setLong(2, loginUserBean.getUserId());
			rstCnt = pstmtCnt.executeQuery();
			if (rstCnt.next()) {
				lTotalResults = rstCnt.getLong("total_results");
			}
			
			sbQuery	.setLength(0);
			sbQuery .append("SELECT mm.*, ct.counter_type_name, ct.counter_type_id, ctv.version ")
					.append("FROM module_master mm ")
					.append("INNER JOIN counter_type_version ctv on ctv.counter_type_version_id = mm.agent_version_id AND mm.module_code = ? ")
					.append("INNER JOIN counter_type ct on ctv.counter_type_id = ct.counter_type_id ")
					.append("AND mm.user_id = ? ")
					.append("ORDER BY mm.module_name ");
			if( strLimit != null && strLimit.length() > 0 ) {
				sbQuery.append("LIMIT ? ");
				if( strOffset != null && strOffset.length() > 0 ) {
					sbQuery.append("OFFSET ? ");
				}
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strModuleType);
			pstmt.setLong(2, loginUserBean.getUserId());
			if( strLimit != null && strLimit.length() > 0 ) {
				pstmt.setInt(3, Integer.parseInt(strLimit));
				if( strOffset != null && strOffset.length() > 0 ) {
					pstmt.setInt(4, Integer.parseInt(strOffset));
				}
			}
			rst = pstmt.executeQuery();
			while(rst.next())
			{
				joModule = new JSONObject();
				joModule.put("uid",rst.getString("uid"));
				joModule.put("moduleName",rst.getString("module_name"));
				joModule.put("description",rst.getString("description"));
				joModule.put("guid",rst.getString("guid"));
				joModule.put("typeName",rst.getString("counter_type_name"));
				joModule.put("agentVersionId",rst.getString("version"));
				joModule.put("agentName",rst.getString("counter_type_name").toUpperCase()+" "+rst.getString("version"));
				joModule.put("familyName", rst.getString("counter_type_name").toUpperCase());
				joModule.put("counterTypeId", rst.getLong("counter_type_id"));
				// defaults enable profiler is disable, in js based on license its enabled
				if (rst.getString("module_code").equals("APPLICATION")) {
					joModule.put("enableProfiler", false);
				}
				
				jaModules.add(joModule);
				
				UtilsFactory.clearCollectionHieracy( joModule );
			}
			joResult.put("totalResults", lTotalResults);
			joResult.put("moduleData", jaModules);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rstCnt);
			rstCnt = null;
			DataBaseManager.close(pstmtCnt);
			pstmtCnt = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	 	return joResult;
	}
	
	/**
	 * Creates counter_master and collector table partitions for `APPLICATION/SERVER/DATABASE`,
	 *  counters also inserted into countermaster table for the uid's counter_type_version
	 * 
	 * @param con
	 * @param lApplicationId
	 * @throws Exception
	 */
	public void createModuleCounterTablePartitions(Connection con, long lModuleId, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT create_counter_table_partitions(?, ?, ?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.setInt(2, moduleBean.getAgentVersionId());
			pstmt.setLong(3, loginUserBean.getUserId());
			pstmt.setString(4, moduleBean.getGuid());
			
			pstmt.execute();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * Gets agent status whether running or not
	 * 
	 * @param con
	 * @param strguid
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModuleAgentStatus(Connection con, String[] strGUIDs, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joAgentsStatus = new JSONObject();
		
		try {
			for(String strGUID : strGUIDs) {
				strGUID = strGUID.trim();
				
				sbQuery	.setLength(0);
				sbQuery	.append("SELECT guid, CASE WHEN (now()- interval '3 minutes') < last_received_on THEN 'active' ELSE 'inactive' END AS status ")
						.append("FROM module_master am ")
						.append("LEFT JOIN ( ")
						.append("    SELECT uid, MAX(appedo_received_on) AS last_received_on ")
						.append("    FROM collector_").append(getUID(con, strGUID)).append(" ")
						.append("    GROUP BY uid ")
						.append(")lr ON lr.uid = am.uid ")
						.append("WHERE am.user_id = ? AND am.guid = '").append(strGUID).append("' ");
				
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setLong(1, loginUserBean.getUserId());
				rst = pstmt.executeQuery();
				
				if( rst.next() ) {
					joAgentsStatus.put(rst.getString("guid"),rst.getString("status"));
				}
				strGUID = null;
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery: " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return joAgentsStatus;
	}
	
	/**
	 * Get the UID (primary key) for the given GUID.
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public long getUID(Connection con, String strGUID) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		// to ignore exception for guid not found
		long lUID = 0;
		
		try {
			sbQuery	.append("SELECT uid FROM module_master WHERE guid = '").append(strGUID).append("' ");
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			if( rst.next() ){
				lUID = rst.getLong("uid");
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return lUID;
	}
	
	public String getGUID(Connection con, Long lUID) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		// to ignore exception for guid not found
		String strGUID = null;
		
		try {
			sbQuery	.append("SELECT guid FROM module_master WHERE uid = ").append(lUID);
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			if( rst.next() ){
				strGUID = rst.getString("guid");
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return strGUID;
	}
	
	public String getModuleName(Connection con, String strGUID) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		// to ignore exception for guid not found
		String  moduleName = null;
		
		try {
			sbQuery	.append("SELECT module_name FROM module_master WHERE guid = '").append(strGUID).append("' ");
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			if( rst.next() ){
				moduleName = rst.getString("module_name");
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return moduleName;
	}
	
	/**
	 * Delete agent tables for the individual application
	 * 
	 * @param con
	 * @param lApplicationId
	 * @throws Exception
	 */
	public void deleteModuleCounterTablePartitions(Connection con, long lModuleId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("SELECT drop_counter_table_partitions(?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.setLong(2, lUserId);
			
			pstmt.executeQuery();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public void deleteChartVisualData(Connection con, long lModuleId, long lUserId, String moduleType) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		//String strModuleId = lModuleId;
		try {
			if (moduleType.equals(Constants.RUM_MODULE)  || moduleType.equals(Constants.LOG_MODULE)) {
				sbQuery.append("DELETE FROM chart_visual_").append(lUserId).append(" WHERE ref_table_pkey_id = ").append(lModuleId);
			} else {
				sbQuery.append("DELETE FROM chart_visual_").append(lUserId).append(" WHERE ref_table_name LIKE 'counter_master_").append(lModuleId).append("'");
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setLong(1, lModuleId);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public void deleteChartVisualizationData(Connection con, long lModuleId, long lUserId, String moduleType) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		//String strModuleId = lModuleId;
		try {
			if (moduleType.equals(Constants.RUM_MODULE)  || moduleType.equals(Constants.LOG_MODULE)) {
				sbQuery.append("DELETE FROM chart_visualization_").append(lUserId).append(" WHERE ref_table_pkey_id = ").append(lModuleId);
			} else {
				sbQuery.append("DELETE FROM chart_visualization_").append(lUserId).append(" WHERE ref_table_name LIKE 'counter_master_").append(lModuleId).append("'");
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setLong(1, lModuleId);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public void deleteMyChartDetails(Connection con, long lModuleId, long lUserId) throws Exception {
		PreparedStatement pstmtDetails = null, pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("DELETE FROM chart_view_details WHERE module_or_test_id = ?");
			pstmtDetails = con.prepareStatement(sbQuery.toString());
			pstmtDetails.setLong(1, lModuleId);
			pstmtDetails.executeUpdate();
			
			sbQuery.setLength(0);
			sbQuery.append("DELETE FROM chart_view WHERE chart_view_id NOT IN(SELECT chart_view_id FROM chart_view_details) AND user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmtDetails);
			pstmtDetails = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * Gets dashboard chart for the particular module type's guid 
	 * 
	 * @param con
	 * @param strGUID
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleTypeDashboardCharts(Connection con, String strGUID, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaModuleCharts = new JSONArray();
		JSONObject joModuleChart = null;
		
		try {
			sbQuery	.append("SELECT udc.id, udc.module_name, reference_uid, udc.counter_id, ")
					.append("am.module_name, am.guid, am.agent_version_id ")
					.append("FROM user_dashboard_charts udc ")
					.append("INNER JOIN module_master am ON am.uid = udc.reference_uid AND am.guid = ? ")
					.append("INNER JOIN counter_type_version avm on avm.counter_type_version_id  = am.agent_version_id ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strGUID);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joModuleChart = new JSONObject();
				joModuleChart.put("id", rst.getString("id"));
				joModuleChart.put("moduleName", rst.getString("module_name"));
				joModuleChart.put("guid", rst.getString("guid"));
				joModuleChart.put("counterCode", rst.getString("counter_id"));
				joModuleChart.put("moduleName", rst.getString("module_name"));
				joModuleChart.put("agentVersionId", rst.getString("agent_version_id"));
				
				jaModuleCharts.add(joModuleChart);
				UtilsFactory.clearCollectionHieracy(joModuleChart);
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return jaModuleCharts;
	}
	
	/**
	 * gets all available agents from different modules Application/Server/Database
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAllAgents(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaAgents = new JSONArray();
		JSONObject joAgent = null;
		
		try {
			sbQuery .append("SELECT ctv.counter_type_version_id, ct.counter_type_id, ct.module_name, ct.counter_type_name, ")
					.append(" ctv.version, concat(ct.counter_type_name, ' ', ctv.version) AS agent_name ")
					.append("FROM counter_type ct ")
					.append("INNER JOIN counter_type_version ctv ON ctv.counter_type_id = ct.counter_type_id ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joAgent = new JSONObject();
				joAgent.put("counterTypeVersionId", rst.getString("counter_type_version_id"));
				joAgent.put("counterTypeId", rst.getString("counter_type_id"));
				joAgent.put("moduleName", rst.getString("module_name"));
				joAgent.put("counterTypeName", rst.getString("counter_type_name"));
				joAgent.put("version", rst.getString("version"));
				joAgent.put("agentName", rst.getString("agent_name"));
				
				jaAgents.add(joAgent);
			}

		} catch (Exception e) {
			
			
			
			LogManager.infoLog("sbQuery: "+sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return jaAgents;
	}
	
	
	/**
	 * Gets module details for the given moduleCode(Application/Server/Database) 
	 * 
	 * @param con
	 * @param strModuleCode
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserModuleDetails(Connection con, String strModuleCode, int nCounterTypeVersionId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		//StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaModuleDetails = new JSONArray();
		JSONObject joModuleDetail = null;
		
		try {
			// TODO: based on module code, agent type and user id should come
			strQuery = "SELECT * FROM module_master WHERE module_code = ? AND agent_version_id = ? AND user_id = ?  ORDER BY module_name ";
			/*sbQuery	.append("SELECT mm.* ")
					.append("FROM module_master mm ")
					.append("INNER JOIN counter_type_version ctv on ctv.counter_type_version_id = mm.agent_version_id ")
					.append(" AND mm.module_code = ? AND mm.agent_version_id = ? AND user_id = ? ")
					.append("ORDER BY module_name ");
			*/
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strModuleCode);
			pstmt.setInt(2, nCounterTypeVersionId);
			pstmt.setLong(3, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joModuleDetail = new JSONObject();
				joModuleDetail.put("uid", rst.getString("uid"));
				joModuleDetail.put("guid", rst.getString("guid"));
				joModuleDetail.put("moduleCode", rst.getString("module_code"));
				joModuleDetail.put("agentVersionId", rst.getString("agent_version_id"));
				joModuleDetail.put("moduleName", rst.getString("module_name"));
				joModuleDetail.put("description", rst.getString("description"));
				joModuleDetail.put("clrVersion", rst.getString("clr_version"));
				
				jaModuleDetails.add(joModuleDetail);
			}
			
		} catch (Exception e) {
			
			
			
			LogManager.infoLog("strQuery : " + strQuery);
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			//UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return jaModuleDetails;
	}
	
	/**
	 * Gets 
	 * @param con
	 * @param strUId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getUserUIDCategoryWiseCounters(Connection con, String strUId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joModuleCounter = null, joCategoryWiseCounters = new JSONObject();
		JSONArray jaModuleCounters = null;
		
		try {
			// TODO: HARD coding table for testing purpose 
			//sbQuery.append("select * from counter_master_191");
			sbQuery	.append("SELECT * FROM counter_master_").append(strUId).append(" ")
					.append("WHERE is_selected = true ")
					.append("ORDER BY category, counter_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joModuleCounter = new JSONObject();
				joModuleCounter.put("counterId", rst.getString("counter_id"));
				joModuleCounter.put("counterTemplateId", rst.getString("counter_template_id"));
				joModuleCounter.put("counterName", rst.getString("counter_name"));
				joModuleCounter.put("queryString", rst.getString("query_string"));
				joModuleCounter.put("executionType", rst.getString("execution_type"));
				joModuleCounter.put("instanceName", rst.getString("instance_name"));
				
				if( joCategoryWiseCounters.containsKey(rst.getString("category")) ) {
					jaModuleCounters = joCategoryWiseCounters.getJSONArray(rst.getString("category"));
				} else {
					jaModuleCounters = new JSONArray();
				}
				jaModuleCounters.add(joModuleCounter);
				joCategoryWiseCounters.put(rst.getString("category"), jaModuleCounters);
			}
			
		} catch (Exception e) {
			

			LogManager.infoLog("sbQuery: "+sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return joCategoryWiseCounters;
	}
	

	public JSONArray getModuleCounterTypes(Connection con, String strModuleName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		
		JSONObject joModuleCounterType = null;
		JSONArray jaModuleCounterTypes = new JSONArray();

		try {
			//strQuery = "SELECT * FROM counter_type WHERE module_name = ? ";
			strQuery = "SELECT * FROM counter_type WHERE module_name = ? ORDER BY counter_type_name ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strModuleName);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joModuleCounterType = new JSONObject();
				joModuleCounterType.put("counterTypeId", rst.getString("counter_type_id"));
				joModuleCounterType.put("moduleName", rst.getString("module_name"));
				joModuleCounterType.put("counterTypeName", rst.getString("counter_type_name"));
				
				jaModuleCounterTypes.add(joModuleCounterType);
			}
			
			strQuery = null;
		} catch(Exception e) {
			
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		
		return jaModuleCounterTypes;
	}

	public JSONArray getModuleCounterTypeVersions(Connection con, int nCounterTypeId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		
		JSONObject joCounterTypeVersion = null;
		JSONArray jaCounterVersions = new JSONArray();

		try {
			strQuery = "SELECT * FROM counter_type_version WHERE counter_type_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1, nCounterTypeId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joCounterTypeVersion = new JSONObject();
				joCounterTypeVersion.put("counterTypeVersionId", rst.getString("counter_type_version_id"));
				joCounterTypeVersion.put("counterTypeId", rst.getString("counter_type_id"));
				joCounterTypeVersion.put("version", rst.getString("version"));
				
				jaCounterVersions.add(joCounterTypeVersion);
			}
			
			strQuery = null;
		} catch(Exception e) {
			System.out.println("Exception in getModuleCounterTypeVersions: "+e.getMessage());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		
		return jaCounterVersions;
	}
	
	/**
	 * gets execution types for SLA action from lookups
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getExecutionTypes(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";

		JSONObject joExecutionType = null;
		JSONArray jaExecutionTypes = new JSONArray();

		try {
			strQuery = "SELECT * FROM lookup_code_master WHERE lookup_group = 'EXECUTION_TYPE' and lookup_code NOT IN ('Batch file', 'Command line', 'JS') ORDER BY lookup_code ";
			
			pstmt = con.prepareStatement(strQuery);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joExecutionType = new JSONObject();
				joExecutionType.put("lookupId", rst.getString("lookup_id"));
				joExecutionType.put("lookupGroup", rst.getString("lookup_group"));
				joExecutionType.put("lookupCode", rst.getString("lookup_code"));
				
				jaExecutionTypes.add(joExecutionType);
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		
		return jaExecutionTypes;
	}
	
	
	/**
	 * gets chart template for the counter type, say Tomcat,
	 * 
	 * @param con
	 * @param lUID
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public ResultSet getTemplateCounterTypeCharts(Connection con, long lUID, LoginUserBean loginUserBean) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT cm.*, ")
					.append("ct.counter_type_id AS counter_type_id, ct.counter_type_name, ct.counter_type_name AS family_name ") 
					.append("FROM counter_master_").append(lUID).append(" cm ")
					.append("INNER JOIN counter_template ct ON ct.counter_template_id = cm.counter_template_id AND is_selected = TRUE ")
					.append("ORDER BY cm.category, cm.counter_name ");

			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return rst;
	}
	
	/**
	 * gets agent download files for a agent, say Tomcat, etc.,
	 * 
	 * @param con
	 * @param strCounterTypeName
	 * @return
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getAgentDownloadFilePath(Connection con, String strCounterTypeName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		LinkedHashMap<String, String> lhmAgentFiles = new LinkedHashMap<String, String>();
		
		try {
			strQuery = "SELECT * FROM counter_type WHERE counter_type_name = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strCounterTypeName);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				lhmAgentFiles.put("monitor_build_module_name", rst.getString("monitor_build_module_name"));
				lhmAgentFiles.put("profiler_build_module_name", rst.getString("profiler_build_module_name"));
				lhmAgentFiles.put("monitor_agent_full_path", rst.getString("monitor_agent_full_path"));
				lhmAgentFiles.put("monitor_guid_files", rst.getString("monitor_guid_files"));
				lhmAgentFiles.put("profiler_agent_full_path", rst.getString("profiler_agent_full_path"));
				lhmAgentFiles.put("profiler_guid_files", rst.getString("profiler_guid_files"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return lhmAgentFiles;
	}


	/**
	 * loads agents(counter_types) download file paths 
	 * 
	 * @param con
	 * @throws Exception
	 */
	/*public static void loadAgentsDownloadFilePath(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		LinkedHashMap<String, String> lhmAgentDownloadFilePath = null;
		
		try {
			strQuery = "SELECT * FROM counter_type ";
			
			pstmt = con.prepareStatement(strQuery);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				lhmAgentDownloadFilePath = new LinkedHashMap<String, String>();
				lhmAgentDownloadFilePath.put("monitor_build_module_name", rst.getString("monitor_build_module_name"));
				lhmAgentDownloadFilePath.put("profiler_build_module_name", rst.getString("profiler_build_module_name"));
				lhmAgentDownloadFilePath.put("monitor_agent_full_path", rst.getString("monitor_agent_full_path"));
				lhmAgentDownloadFilePath.put("monitor_guid_files", rst.getString("monitor_guid_files"));
				lhmAgentDownloadFilePath.put("profiler_agent_full_path", rst.getString("profiler_agent_full_path"));
				lhmAgentDownloadFilePath.put("profiler_guid_files", rst.getString("profiler_guid_files"));
				
				Constants.COUNTER_TYPES_DOWNLOAD_FILE_PATH.put(rst.getString("counter_type_name"), lhmAgentDownloadFilePath);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}*/
	
	/**
	 * Loads agent's latest build version   
	 * 
	 * @param con
	 * @throws Exception
	 */
	public static void loadAgentsLatestVersion(Connection con) throws Exception  {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT bum.module_name, bum.version_number FROM build_upgrade_master bum ")
					.append("INNER JOIN ( ") 
					.append(" SELECT module_name, max(upgraded_on) AS last_upgraded_on ")
					.append(" FROM build_upgrade_master ")
					.append(" GROUP BY module_name ")
					.append(") AS l_bum ON l_bum.module_name = bum.module_name AND l_bum.last_upgraded_on = bum.upgraded_on ")
					.append("ORDER BY bum.module_name ");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while(rst.next()) {
				Constants.AGENT_LATEST_BUILD_VERSION.put(rst.getString("module_name"), rst.getString("version_number"));
			}
			
		} catch (Exception e) {
        	LogManager.errorLog(e);
        	throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}

	/**
	 * loads minichart counters template ids
	 * 
	 * @param con
	 * @throws Exception
	 */
	public static void loadMiniChartCounters(Connection con) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		try {
			strQuery = "SELECT agent_version, minichart_counter_template_ids FROM v_counter_type_version ";
			stmt = con.createStatement();
			rst = stmt.executeQuery(strQuery);
			while(rst.next()) {
				Constants.MINICHART_COUNTERS.put(rst.getString("agent_version"), UtilsFactory.replaceNullBlank(rst.getString("minichart_counter_template_ids"), "").split(","));
			}
		} catch(Exception e) {
        	throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * Gets available agents for the module (APPLICATION/SERVER/DATABASES) 
	 * 
	 * @param con
	 * @param strModuleName
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleAgents(Connection con, String strModuleName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaAgents = new JSONArray();
		JSONObject joAgent = null;
		
		try {
			//sbQuery.append("SELECT * from agentversionmaster WHERE module_code = ? ORDER BY agent_name");
			sbQuery.append("SELECT * from counter_type WHERE module_name = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strModuleName);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joAgent = new JSONObject();
				joAgent.put("counterTypeId", rst.getString("counter_type_id"));
				joAgent.put("moduleName", rst.getString("module_name"));
				joAgent.put("agentName", rst.getString("counter_type_name"));
				
				jaAgents.add(joAgent);
				UtilsFactory.clearCollectionHieracy( joAgent );
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return jaAgents;
	}

	/**
	 * loads agents(counter_types) download file paths 
	 * 
	 * @param con
	 * @throws Exception
	 */
	public static void loadAgentsDownloadFilePath(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		LinkedHashMap<String, String> lhmAgentDownloadFilePath = null;
		
		try {
			strQuery = "SELECT * FROM counter_type ";
			
			pstmt = con.prepareStatement(strQuery);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				lhmAgentDownloadFilePath = new LinkedHashMap<String, String>();
				lhmAgentDownloadFilePath.put("monitor_build_module_name", rst.getString("monitor_build_module_name"));
				lhmAgentDownloadFilePath.put("profiler_build_module_name", rst.getString("profiler_build_module_name"));
				lhmAgentDownloadFilePath.put("monitor_agent_full_path", rst.getString("monitor_agent_full_path"));
				lhmAgentDownloadFilePath.put("monitor_guid_files", rst.getString("monitor_guid_files"));
				lhmAgentDownloadFilePath.put("profiler_agent_full_path", rst.getString("profiler_agent_full_path"));
				lhmAgentDownloadFilePath.put("profiler_guid_files", rst.getString("profiler_guid_files"));
				
				Constants.COUNTER_TYPES_DOWNLOAD_FILE_PATH.put(rst.getString("counter_type_name"), lhmAgentDownloadFilePath);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * get particular module details 
	 * 
	 * @param con
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModule(Connection con, long lUID) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		JSONObject joModule = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT mm.*, ct.counter_type_name, ctv.version ")
					.append("FROM module_master mm ")
					.append("INNER JOIN counter_type_version ctv ON ctv.counter_type_version_id = mm.agent_version_id AND mm.uid = ? ")
					.append("INNER JOIN counter_type ct ON ct.counter_type_id = ctv.counter_type_id ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUID);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				joModule = new JSONObject();
				joModule.put("uid", rst.getString("uid"));
				joModule.put("moduleCode", rst.getString("module_code"));
				joModule.put("moduleName", rst.getString("module_name"));
				joModule.put("counterTypeVersionId", rst.getString("agent_version_id"));
				joModule.put("description", rst.getString("description"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("clrVersion", rst.getString("clr_version"));
				joModule.put("counterTypeName", rst.getString("counter_type_name"));
				joModule.put("version", rst.getString("version"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return joModule;
	}

	/**
	 * Creates RUM collector table for the individual module
	 * 
	 * @param con
	 * @param lApplicationId
	 * @throws Exception
	 */
	public void createRUMCollectorTablePartitions(Connection con, long lModuleId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("SELECT create_rum_collector_table_partitions(?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * Drops RUM collector table partitions 
	 * 
	 * @param con
	 * @param lModuleId
	 * @throws Exception
	 */
	public void dropRUMCollectorTablePartitions(Connection con, long lModuleId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("SELECT drop_rum_collector_table_partitions(?, ?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.setLong(2, lUserId);
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * gets module details for dashboard
	 * 
	 * @param con
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getDashboardModuleData(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		JSONObject joModule = null;
		JSONArray jaModules = new JSONArray();
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT module_code, count(*) as total ")
					.append("FROM module_master ")
					.append("WHERE user_id = ? AND module_code <> 'RUM' ")
					.append("GROUP BY module_code ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joModule = new JSONObject();
				joModule.put("moduleCode", rst.getString("module_code"));
				joModule.put("total", rst.getInt("total"));
				
				jaModules.add(joModule);
				joModule = null;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return jaModules;
	}
	
	public boolean isSLAConfigured(Connection con, String strGUID, long lCounterId) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		boolean bExist = false;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT true from so_sla_counter where guid=? AND counter_id=? limit 1");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strGUID);
			pstmt.setLong(2, lCounterId);
			rst = pstmt.executeQuery();
			
			if(rst.next()){
				bExist = true;
			}else{
				bExist = false;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return bExist;
	}

	public void createCICollectorTablePartitions(Connection con, long lModuleId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("SELECT create_ci_events_table_partitions(?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * drops CI event, property and respective events transaction table partitions 
	 * @param con
	 * @param lModuleId
	 * @throws Exception
	 */
	public void dropCICollectorTablePartitions(Connection con, long lModuleId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("SELECT drop_ci_collector_table_partitions(?, ?)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lModuleId);
			pstmt.setLong(2, lUserId);
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}

	/**
	 * 
	 * get total number of Enterprise from enterprise master. 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long getTotalEnterpriseMapping(Connection con, long e_id) throws Exception {
		long lTotalEnterpriseMapping = 0;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery	.append("SELECT count(*) AS total_enterprise_mapping ")
					.append("FROM user_enterprise_mapping ")
					.append("WHERE e_id = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, e_id);
			rst = pstmt.executeQuery();
			
			if( rst.next() ) {
				lTotalEnterpriseMapping = rst.getInt("total_enterprise_mapping");
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return lTotalEnterpriseMapping;
	}
	
	/**
	 * 
	 * get total number of Enterprise from enterprise master. 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long getTotalEnterprise(Connection con, LoginUserBean loginUserBean) throws Exception {
		long lTotalEnterprise = 0;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery	.append("SELECT count(*) AS total_enterprise ")
					.append("FROM enterprise_master ")
					.append("WHERE user_id = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			
			if( rst.next() ) {
				lTotalEnterprise = rst.getInt("total_enterprise");
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return lTotalEnterprise;
	}
		
	/**
	 * 
	 * get Enterprise user wise Month wise License details 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long getMaxEnterprise(Connection con, LoginUserBean loginUserBean) throws Exception {
		long lMaxEnterprise = 0;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery	.append("SELECT user_id, start_date, end_date, max_enterprises ")
					.append("FROM userwise_lic_monthwise ")
					.append("WHERE user_id = ? AND module_type = 'COMMON' ")
					.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			
			if( rst.next() ) {
				lMaxEnterprise = rst.getInt("max_enterprises");
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return lMaxEnterprise;
	}
	
	/**
	 * 
	 * get Enterprise user wise Month wise License details 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long getMaxUserEnterpriseMapping(Connection con, LoginUserBean loginUserBean) throws Exception {
		long lMaxEnterprise = 0;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery	.append("SELECT ent_max_allowed_users ")
					.append("FROM userwise_lic_monthwise ")
					.append("WHERE user_id = ? AND module_type = 'COMMON' ")
					.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			
			if( rst.next() ) {
				lMaxEnterprise = rst.getInt("ent_max_allowed_users");
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return lMaxEnterprise;
	}
	
	/**
	 * Gets APM license details for the user from `userwise_lic_monthwise` table
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public APMLicenseBean getAPMUserWiseLicenseMonthWise(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		APMLicenseBean apmLicenseBean = null;
		
		try {
			if( ! loginUserBean.getLicense().equals("level0") ) {
				// For PAID user
				sbQuery	.append("SELECT user_id, start_date, end_date, apm_max_agents, apm_max_counters ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type = 'APM' ")
						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			} else {
				// For FREE user
				sbQuery	.append("SELECT user_id, created_on AS start_date, apm_max_agents, apm_max_counters ")
						.append("FROM usermaster ")
						.append("WHERE user_id = ? ");
			}
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				apmLicenseBean = new APMLicenseBean();
				
				apmLicenseBean.setUserId(rst.getLong("user_id"));
				apmLicenseBean.setStartDate(rst.getString("start_date"));
				if( ! loginUserBean.getLicense().equals("level0") )
					apmLicenseBean.setEndDate(rst.getString("end_date"));
				apmLicenseBean.setMaxAgents(rst.getInt("apm_max_agents"));
				apmLicenseBean.setMaxCounters(rst.getInt("apm_max_counters"));
			}

		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return apmLicenseBean;
	}
	
	/**
	 * Gets APM license details for the user from `apm_config_parameters` table
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public APMLicenseBean getAPMLicenseConfigParameters(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		APMLicenseBean apmLicenseBean = null;
		
		try {
			sbQuery	.append("SELECT * ")
					.append("FROM apm_config_parameters ")
					.append("WHERE lic_internal_name = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, loginUserBean.getLicense());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				apmLicenseBean = new  APMLicenseBean();
				
				apmLicenseBean.setLicInternalName(rst.getString("lic_internal_name"));
				apmLicenseBean.setLicExternalName(rst.getString("lic_external_name"));
				apmLicenseBean.setAllowPrivateCounters(rst.getBoolean("is_allow_private_counters"));
				apmLicenseBean.setEnableSlider(rst.getBoolean("is_allow_private_counters"));
				apmLicenseBean.setReportRetentionInDays(rst.getInt("report_retention_in_days"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return apmLicenseBean;
	}

	/**
	 * gets user added total no. of modules 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long getUserAddedModulesCount(Connection con, String strModuleName, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		// total modules default `0`, since `-1` means user can add with no limits 
		long lTotalUserModulesCount = 0;
		
		try {
			sbQuery	.append("SELECT count(*) AS total_user_modules ")
					.append("FROM module_master ")
					.append("WHERE user_id = ? AND module_code IN (").append(strModuleName).append(") ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				lTotalUserModulesCount = rst.getLong("total_user_modules");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery= null;
		}
		
		return lTotalUserModulesCount;
	}
	
	/**
	 * gets user added counters for the particular counter type/agent 
	 * 
	 * @param con
	 * @param lUID
	 * @param nCounterTypeId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long getUserAddedCounterTypeCountersCount(Connection con, long lUID, int nCounterTypeId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lTotalUserCounterTypeCounters = -1;
		
		try {
			sbQuery	.append("SELECT count(*) AS total_user_counter_type_counters ")
					.append("FROM counter_master_").append(lUID).append(" ")
					.append("WHERE is_selected = TRUE ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				lTotalUserCounterTypeCounters = rst.getLong("total_user_counter_type_counters");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery= null;
		}
		
		return lTotalUserCounterTypeCounters;
	}
	

	public RUMLicenseBean getRUMUserWiseLicenseMonthWise(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		RUMLicenseBean rumLicenseBean = null;
		
		try {
			if( ! loginUserBean.getLicense().equals("level0") ) {
				// For PAID user
				sbQuery	.append("SELECT user_id, start_date, end_date, rum_max_test ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type = 'RUM' ")
						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			} else {
				// For FREE user
				sbQuery	.append("SELECT user_id, created_on AS start_date, rum_max_test ")
						.append("FROM usermaster ")
						.append("WHERE user_id = ? ");
			}

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				rumLicenseBean = new RUMLicenseBean();
				
				rumLicenseBean.setUserId(rst.getLong("user_id"));
				rumLicenseBean.setStartDate(rst.getString("start_date"));
				if( ! loginUserBean.getLicense().equals("level0") )
					rumLicenseBean.setEndDate(rst.getString("end_date"));
				rumLicenseBean.setMaxRUMTests(rst.getInt("rum_max_test"));
			}

		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return rumLicenseBean;
	}
	
	

	public RUMLicenseBean getRUMLicenseConfigParameters(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		RUMLicenseBean rumLicenseBean = null;
		
		try {
			sbQuery	.append("SELECT * ")
					.append("FROM rum_config_parameters ")
					.append("WHERE lic_internal_name = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, loginUserBean.getLicense());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				rumLicenseBean = new  RUMLicenseBean();
				
				rumLicenseBean.setLicInternalName(rst.getString("lic_internal_name"));
				rumLicenseBean.setLicExternalName(rst.getString("lic_external_name"));
				rumLicenseBean.setMaxRUMTests(rst.getInt("rum_max_test"));
				rumLicenseBean.setReportRetentionInDays(rst.getInt("report_retention_in_days"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return rumLicenseBean;
	}
	
	/**
	 * Updates selected counters to true and other counters to false
	 * 
	 * @param con
	 * @param strCounterIds
	 * @param lUId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateCounters(Connection con, String strCounterIds, long lUId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			if ( strCounterIds.length() == 0 ) {
				strCounterIds = "-1";
			}
			sbQuery	.append("UPDATE counter_master_").append(lUId).append(" SET ")
					.append("is_selected = (CASE  WHEN counter_id IN (").append(strCounterIds).append(") THEN TRUE  ELSE FALSE END), ")
					.append("is_agent_updated = (CASE  WHEN counter_id IN (").append(strCounterIds).append(") THEN TRUE  ELSE FALSE END), ")
					.append("modified_on = now(), ")
					.append("modified_by = ? "); 
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			
			pstmt.executeUpdate();
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public void updateChartData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, String strCounterIds) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = null;
		
		try {
			
			//strQuery = "select * from delete_insert_chart_visualization_data(?,?)";
			
			strQuery = "SELECT * FROM update_counter_in_chart_visualization(?,?,?,?,?)";
			
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setLong(2, moduleBean.getModuleId());
			pstmt.setString(3, strCounterIds);
			pstmt.setString(4, moduleBean.getModuleName());
			pstmt.setString(5, moduleBean.getModuleType());
			
			pstmt.execute();
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(strQuery);
			strQuery = null;
		}
	}

	public JSONArray validateMaxCounterIdMapping(Connection con, String strCounterIds, long lUId, LoginUserBean loginUserBean) throws Exception {
		Date dateLog = LogManager.logMethodStart();

		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONArray jaMaxCounterIds = null;

		StringBuilder sbQuery = new StringBuilder();

		try {

			if (strCounterIds.length() == 0) {
				strCounterIds = "-1";
			}

			sbQuery.append("WITH selected_max_counter_ids AS ( ")
			.append("SELECT counter_id, display_name FROM counter_master_").append(lUId).append(" WHERE counter_id IN (SELECT max_value_counter_id ")
			.append("FROM counter_master_").append(lUId).append(" WHERE counter_id IN (").append(strCounterIds).append(") AND max_value_counter_id IS NOT NULL) ")
			.append(") , sla_mapped_ids AS ( ")
			.append("SELECT DISTINCT smcid.counter_id, smcid.display_name ")
			.append("FROM selected_max_counter_ids smcid ")
			.append("INNER JOIN so_sla_counter ssc ON smcid.counter_id = ssc.denominator_counter_id AND ssc.uid = ? ")
			.append("INNER JOIN so_sla on ssc.sla_id = so_sla.sla_id AND so_sla.is_deleted = false) ")
			.append("SELECT counter_id, display_name FROM sla_mapped_ids WHERE counter_id NOT IN (").append(strCounterIds).append(")");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				jaMaxCounterIds = new JSONArray();
				jaMaxCounterIds.add(rst.getString("display_name"));
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;

			LogManager.logMethodEnd(dateLog);
		}
		return jaMaxCounterIds;
	}

	public DDLicenseBean getDDUserWiseLicenseMonthWise(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		DDLicenseBean ddLicenseBean = null;
		
		try {
			if( ! loginUserBean.getLicense().equals("level0") ) {
				// For PAID user
				sbQuery	.append("SELECT user_id, start_date, end_date, dd_max_profilers ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type = 'PROFILER' ")
						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			} else {
				// For FREE user
				sbQuery	.append("SELECT user_id, dd_lic_start_date AS start_date, dd_lic_end_date AS end_date, dd_max_profilers ")
						.append("FROM usermaster ")
						.append("WHERE user_id = ? ")
						.append("AND dd_lic_start_date::date <= now()::date AND dd_lic_end_date::date >= now()::date ");
			}
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				ddLicenseBean = new DDLicenseBean();
				
				ddLicenseBean.setUserId(rst.getLong("user_id"));
				ddLicenseBean.setStartDate(rst.getString("start_date"));
				ddLicenseBean.setEndDate(rst.getString("end_date"));
				ddLicenseBean.setMaxProfilers(rst.getInt("dd_max_profilers"));
				// TODO: max profilers for enterprise
			}

		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return ddLicenseBean;
	}

	public DDLicenseBean getDDLicenseConfigParameters(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		DDLicenseBean ddLicenseBean = null;
		
		try {
			sbQuery	.append("SELECT * ")
					.append("FROM dd_config_parameters ")
					.append("WHERE lic_internal_name = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, loginUserBean.getLicense());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				ddLicenseBean = new DDLicenseBean();
				
				ddLicenseBean.setLicInternalName(rst.getString("lic_internal_name"));
				ddLicenseBean.setLicExternalName(rst.getString("lic_external_name"));
				ddLicenseBean.setEnableApplicationResponseTime(rst.getBoolean("is_enable_application_response_time"));
				ddLicenseBean.setEnableDotNetProfiling(rst.getBoolean("is_enable_dot_net_profiling"));
				ddLicenseBean.setEnableJavaProfiling(rst.getBoolean("is_enable_java_profiling"));
				ddLicenseBean.setEnableMostTimeConsumingTrans(rst.getBoolean("is_enable_most_time_consuming_trans"));
				ddLicenseBean.setEnablePerformanceOfExtServices(rst.getBoolean("is_enable_performance_of_ext_services"));
				ddLicenseBean.setEnableSlowQuery(rst.getBoolean("is_enable_slow_query"));
				ddLicenseBean.setEnableStackTrace(rst.getBoolean("is_enable_stack_trace"));
				ddLicenseBean.setEnableTraceTransaction(rst.getBoolean("is_enable_trace_transaction"));
				ddLicenseBean.setEnableTransBreakdown(rst.getBoolean("is_enable_trans_breakdown"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return ddLicenseBean;
	}
	
	/**
	 * Need to verify, tried backed validation for user selected profiler is enabled OR not, 
	 * (Note, nowhere configured particular module to profiler handled user defined logic, as from first to till maxProfiler is enabled for user, 
	 *  handled based on ORDER BY module name.) 
	 * 
	 * @param con
	 * @param strGUID
	 * @param nMaxProfiler
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isProfilerEnabled(Connection con, String strGUID, int nMaxProfiler, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bProfilerEnabled = false;

		try {
			/*
			sbQuery	.append("SELECT CASE WHEN count(*) > 0 THEN TRUE ELSE FALSE END AS is_enable_profiler FROM ( ")
					.append("  SELECT guid ")
					.append("  FROM module_master ")
					.append("  WHERE user_id = ? AND module_code = 'APPLICATION' ")
					.append("  ORDER BY module_name ")
					.append("  LIMIT ? ")
					.append(") AS app_prof WHERE guid = ? ");
			*/			
			sbQuery	.append("SELECT EXISTS ( ")
					.append("  SELECT 1 FROM ( ")
					.append("    SELECT guid ")
					.append("    FROM module_master ")
					.append("    WHERE user_id = ? AND module_code = 'APPLICATION' ")
					.append("    ORDER BY module_name ")
					.append("    LIMIT ? ")
					.append("  ) AS app_prof WHERE guid = ? ")
					.append(") AS is_enable_profiler ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setInt(2, nMaxProfiler);
			pstmt.setString(3, strGUID);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				bProfilerEnabled = rst.getBoolean("is_enable_profiler");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return bProfilerEnabled;
	}

	/**
	 * Getting 
	 * @param con
	 * @param strModuleType versions
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleTypeVersions(Connection con, String strModuleType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joType = null, joVersion = null;
		JSONArray jaVersions = null;
		JSONArray jaTypeNVersions = new JSONArray();
		try{
			sbQuery .append("SELECT counter_type_name, display_name, version, counter_type_version_id ")
					.append("FROM counter_type  ct ")
					.append("INNER JOIN counter_type_version ctv on ct.counter_type_id=ctv.counter_type_id AND ct.module_name=? ")
					.append("GROUP BY counter_type_name, display_name, version, counter_type_version_id ORDER BY counter_type_name");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strModuleType);
			
			rs = pstmt.executeQuery();
			String strType = "";
			while(rs.next()){
				if(strType.equals(rs.getString("counter_type_name"))){
					joVersion.put("version", rs.getString("version"));
					joVersion.put("ctv_id",rs.getLong("counter_type_version_id"));
					jaVersions.add(joVersion);
					jaTypeNVersions.remove(jaTypeNVersions.size()-1);
				}else{
					joType = new JSONObject();
					jaVersions = new JSONArray();
					joVersion = new JSONObject();
					strType = rs.getString("counter_type_name");
					joType.put("display_name", rs.getString("display_name"));
					joType.put("module_type", rs.getString("counter_type_name"));
					joVersion.put("version", rs.getString("version"));
					joVersion.put("ctv_id",rs.getLong("counter_type_version_id"));
					jaVersions.add(joVersion);
				}
				if(joType != null){
					joType.put("versions", jaVersions);
					jaTypeNVersions.add(joType);
				}
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
		return jaTypeNVersions;
	}
	
	public JSONArray getAppDropDown(Connection con, long lUserId, String strModuleName) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null, pstmtStatus = null;
		ResultSet rst = null, rstStatus= null;
		JSONObject joModule = null;
		JSONArray jaModules = new JSONArray();
		
		StringBuilder sbQuery = new StringBuilder();

		try {
//			sbQuery	.append("SELECT module_name, guid, uid FROM module_master ")
//					.append("WHERE module_code = ? AND user_id = ? ");

			sbQuery	.append("SELECT mm.module_name, mm.guid, mm.uid,ct.counter_type_name, ctv.version ")
					.append("FROM module_master mm ")
					.append("INNER JOIN counter_type_version ctv on ctv.counter_type_version_id = mm.counter_type_version_id AND mm.module_code = ? ")
					.append("INNER JOIN counter_type ct on ctv.counter_type_id = ct.counter_type_id AND mm.user_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strModuleName);
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				sbQuery.setLength(0);
				sbQuery	.append("SELECT EXISTS( select 1  from collector_")
						.append(rst.getLong("uid"))
						.append(" where appedo_received_on>=now() - interval '1 min' LIMIT 1)");
				pstmtStatus = con.prepareStatement(sbQuery.toString());
				rstStatus = pstmtStatus.executeQuery();
				if(rstStatus.next()){
					if(rstStatus.getBoolean("exists")){
						joModule = new JSONObject();
						joModule.put("moduleName", rst.getString("module_name"));
						joModule.put("guid", rst.getString("guid"));
						joModule.put("uid", rst.getLong("uid"));
						joModule.put("type", rst.getString("counter_type_name"));
						joModule.put("version", rst.getString("version"));
						// joModule.put("counters", getUserUIDCategoryWiseCounters(con, String.valueOf(rst.getLong("uid")), null));
						jaModules.add(joModule);
						joModule = null;
					}
				}
				DataBaseManager.close(rstStatus);
				rstStatus = null;
				DataBaseManager.close(pstmtStatus);
				pstmtStatus = null;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(rstStatus);
			rstStatus = null;
			DataBaseManager.close(pstmtStatus);
			pstmtStatus = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return jaModules;
	}
	
	/**
	 * gets all ASD modules active agents
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getAllASDModulesActiveAgents(Connection con, long lUserId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONObject joModule = null, joModuleTypesActiveAgents = new JSONObject();
		JSONArray jaModuleTypeModules = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strModuleCode = "";
		
		try {
			sbQuery	.append("SELECT vmmv.module_code, vmmv.module_name, vmmv.guid, vmmv.uid, vmmv.counter_type_name ")
					.append("FROM v_user_last_counter_").append(lUserId).append(" vulc ")
					.append("INNER JOIN v_module_master_version vmmv ON vmmv.uid = vulc.uid ")
					.append("  AND vulc.appedo_received_on > now() - interval '1 minute' ")
					.append("ORDER BY vmmv.module_code, vmmv.module_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				strModuleCode = rst.getString("module_code");
				
				joModule = new JSONObject();
				joModule.put("moduleCode", strModuleCode);
				joModule.put("moduleName", rst.getString("module_name"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("uid", rst.getLong("uid"));
				joModule.put("type", rst.getString("counter_type_name"));
				
				if ( joModuleTypesActiveAgents.containsKey(strModuleCode) ) {
					jaModuleTypeModules = joModuleTypesActiveAgents.getJSONArray(strModuleCode);
				} else {
					jaModuleTypeModules = new JSONArray();
					
					// obj. by ref is not working 
					//joModuleTypesActiveAgents.put(strModuleCode, jaModuleTypeModules);
				}
				jaModuleTypeModules.add(joModule);
				joModuleTypesActiveAgents.put(strModuleCode, jaModuleTypeModules);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery= null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return joModuleTypesActiveAgents;
	}
	
	 public JSONArray getAppSummary(Connection con, long lUserId, String strModuleName) throws Exception {
         PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONArray jaModules = new JSONArray();
		try {
			String query = "SELECT status, COALESCE(count, 0) FROM (SELECT 'Active' AS status, true AS status_boolean UNION ALL SELECT 'Inactive' AS status, false AS status_boolean )base LEFT JOIN ( select * from get_app_summary(?,?))summary ON status_boolean = is_active ORDER BY status";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(lUserId + ""));
			pstmt.setString(2, strModuleName);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				JSONObject joModule = new JSONObject();
				joModule.put("label", rst.getString("status"));
				joModule.put("value",rst.getInt("COALESCE"));
				jaModules.add(joModule);
			}
         } catch (Exception e) {
                 LogManager.errorLog(e);
                 throw e;
         } finally {
                 DataBaseManager.close(rst);
                 rst = null;
                 DataBaseManager.close(pstmt);
                 pstmt = null;
         }
		return jaModules;
	 }


	 public JSONArray getAppLicense(Connection con, long lUserId) throws Exception {
         PreparedStatement pstmt = null;
         ResultSet rst = null;
         JSONObject joModule = null;
         JSONArray jaModules = new JSONArray();
         try {
         		 //String query = "SELECT 'APM License' AS NAME,apm_max_agents As count,'Free' AS LIC FROM usermaster where user_id =? and lic_apm='level0' union select 'DD License' AS NAME,dd_max_profilers As count,'Free' AS LIC FROM usermaster where user_id =? and lic_dd='level0' union SELECT 'APM License' AS NAME,apm_max_agents As count,'Paid' AS LIC FROM userwise_lic_monthwise where user_id =? AND module_type = 'APM' AND start_date <= now() AND end_date >= now() union select 'DD License' AS NAME,dd_max_profilers As count,'Paid' AS LIC FROM userwise_lic_monthwise where user_id =? AND module_type = 'PROFILER' AND start_date <= now() AND nd_date >= now()";
        	 	 String query = "select * from get_license(?)";
                 pstmt = con.prepareStatement(query);
                 pstmt.setInt(1, Integer.parseInt(lUserId + ""));  
                 rst = pstmt.executeQuery();
                 while(rst.next()) {
                         joModule = new JSONObject();	
                         joModule.put("lic_label",rst.getString("NAME"));
                         joModule.put("lic_value",rst.getString("LIC"));
                         joModule.put("smr_label","Max Profilers");
						 if(rst.getString("NAME").equalsIgnoreCase("APM License")){
		                     joModule.put("smr_label","Max Monitors");
						 }
						 joModule.put("smr_value",rst.getLong("count"));
						 if(rst.getLong("count") == -1){
							 joModule.put("smr_value","Unlimited");
						 }
                         jaModules.add(joModule);
                         joModule = null;
                 }	
         } catch (Exception e) {
                 LogManager.errorLog(e);
                 throw e;
         } finally {
                 DataBaseManager.close(rst);
                 rst = null;
                 DataBaseManager.close(pstmt);
                 pstmt = null;
                 joModule = null;
         }
         return jaModules;
	 }
	 
	 public JSONArray getCategories(Connection con, long uid) throws Exception {
			
			PreparedStatement pstmt = null, pstmtMiniChart = null;
			ResultSet rs = null, rsMiniChart = null;
			
			StringBuilder sbQuery = new StringBuilder();
			
			JSONArray jaAPCounters = new JSONArray();
			JSONObject joAPCounter = null;
			String miniChartId = "0";
			
			try {
				sbQuery .append("SELECT minichart_counter_template_ids FROM module_master m ")
						.append("INNER JOIN counter_type_version ct ON m.counter_type_version_id=ct.counter_type_version_id WHERE uid=")
						.append(uid);
				
				pstmtMiniChart = con.prepareStatement(sbQuery.toString());
				
				rsMiniChart = pstmtMiniChart.executeQuery();
				if(rsMiniChart.next()){
					miniChartId = rsMiniChart.getString("minichart_counter_template_ids");
				}
				
				sbQuery.setLength(0);
				sbQuery .append("select distinct(category) from counter_master_")
						.append(uid)
						.append(" ORDER BY category");
				
				pstmt = con.prepareStatement(sbQuery.toString());
				
				rs = pstmt.executeQuery();
				while(rs.next()){
					joAPCounter = new JSONObject();
					joAPCounter.put("category", rs.getString("category"));
					joAPCounter.put("counters", getCounters(con, uid, rs.getString("category"), miniChartId));
					jaAPCounters.add(joAPCounter);
					joAPCounter = null;
				}
			}catch(Exception e){
				LogManager.errorLog(e);
				throw e;
			}finally {
				DataBaseManager.close(rsMiniChart);
				rsMiniChart = null;
				DataBaseManager.close(pstmtMiniChart);
				pstmtMiniChart = null;
				DataBaseManager.close(rs);
				rs = null;
				DataBaseManager.close(pstmt);
				pstmt = null;
				sbQuery = null;
				joAPCounter = null;
				miniChartId = null;
			}
			return jaAPCounters;
		}
	 
	 
	 /**
		 * Getting application counters
		 * @param con
		 * @param nApplicationID
		 * @param strCategory
		 * @return
		 * @throws Exception
		 */
		public JSONArray getCounters(Connection con, long lUID, String category, String miniChartId) throws Exception {
			
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			StringBuilder sbQuery = new StringBuilder();
			
			JSONArray jaAPPCounters = new JSONArray();
			JSONObject joAPPCounter = null;
			
			try {
				sbQuery .append("select *, CASE WHEN counter_template_id IN (")
						.append(miniChartId)
						.append(")THEN true ELSE false END AS minichart from counter_master_")
						.append(lUID)
						.append(" WHERE is_enabled = true AND category = ?")
						.append(" ORDER BY category, counter_name");
			
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setString(1, category);
				
				rs = pstmt.executeQuery();
				while(rs.next()){
					joAPPCounter = new JSONObject();
					joAPPCounter.put("counter_id", rs.getInt("counter_id"));
					String strPvt = (rs.getBoolean("public"))?"":"(Pvt)";
					joAPPCounter.put("name", rs.getString("counter_name")+strPvt);
					joAPPCounter.put("isDefault", rs.getBoolean("is_selected"));
					joAPPCounter.put("isSelected", rs.getBoolean("is_selected"));
					joAPPCounter.put("showCounter", false);
					joAPPCounter.put("isPublic", rs.getBoolean("public"));
					joAPPCounter.put("show_in_primary", rs.getBoolean("show_in_primary"));
					joAPPCounter.put("show_in_secondary", rs.getBoolean("show_in_secondary"));
					joAPPCounter.put("minichart", rs.getBoolean("minichart"));
					jaAPPCounters.add(joAPPCounter);
					joAPPCounter = null;
					strPvt = null;
				}
			}catch(Exception e){
				LogManager.errorLog(e);
				throw e;
			}finally {
				DataBaseManager.close(rs);
				rs = null;
				DataBaseManager.close(pstmt);
				pstmt = null;
				sbQuery = null;
				joAPPCounter = null;
			}
		return jaAPPCounters;
	}
	
	public LinkedHashMap<String, ArrayList<JSONObject>> getAgentAllCategoryWiseCounters(Connection con, long lUId, String strAgentVersion) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		String strPvt = "", strCategory = "";
		
		boolean bMiniChartCounter = false;
		
		LinkedHashMap<String, ArrayList<JSONObject>> hmCategoryWiseCouters = new LinkedHashMap<String, ArrayList<JSONObject>>();
		
		ArrayList<JSONObject> alCounters = null;
		
		JSONObject joCounter = null;
		
		try {
			sbQuery	.append("SELECT counter_id, counter_template_id, category, counter_name, display_name, ")
					.append("  is_selected, show_in_primary, show_in_secondary, public ")
					.append("FROM counter_master_").append(lUId).append(" ")
					.append("WHERE is_enabled = true ")
					.append("ORDER BY category, display_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joCounter = new JSONObject();
				
				strCategory = rst.getString("category");
				strPvt = rst.getBoolean("public") ? "" : "(Pvt)";
				bMiniChartCounter = UtilsFactory.contains(Constants.MINICHART_COUNTERS.get(strAgentVersion), rst.getString("counter_template_id"));
				
				joCounter.put("counter_id", rst.getInt("counter_id"));
				joCounter.put("counter_template_id", rst.getInt("counter_template_id"));
				joCounter.put("category", strCategory);
				joCounter.put("name", rst.getString("counter_name")+strPvt);
				joCounter.put("displayName", rst.getString("display_name")+strPvt);
				joCounter.put("isDefault", rst.getBoolean("is_selected"));
				joCounter.put("isSelected", rst.getBoolean("is_selected"));
				joCounter.put("showCounter", false);
				joCounter.put("isPublic", rst.getBoolean("public"));
				joCounter.put("show_in_primary", rst.getBoolean("show_in_primary"));
				joCounter.put("show_in_secondary", rst.getBoolean("show_in_secondary"));
				joCounter.put("minichart", bMiniChartCounter);
				joCounter.put("isMandatory", rst.getBoolean("show_in_primary") || rst.getBoolean("show_in_secondary") || bMiniChartCounter);
				
				if ( hmCategoryWiseCouters.containsKey(strCategory) ) {
					alCounters = hmCategoryWiseCouters.get(strCategory);
				} else {
					alCounters = new ArrayList<JSONObject>();
					
					// obj. by ref
					hmCategoryWiseCouters.put(strCategory, alCounters);
				}
				alCounters.add(joCounter);
				
				strCategory = null;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strPvt = null;
			strCategory = null;
		}
		
		return hmCategoryWiseCouters;
	}
	
	public JSONArray getSlowQuery(Connection con, String strFromStartInterval, String strGUID) throws Exception {
	
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaSlowQueries = new JSONArray();
		JSONObject joSlowQuery = null;
		
		try {
			
			pstmt = con.prepareStatement("SELECT * FROM get_expensive_queries(?, ?)");
			pstmt.setString(1, strGUID);
			pstmt.setString(2, strFromStartInterval);
			
			rst = pstmt.executeQuery();
			while(rst.next()){
				joSlowQuery = new JSONObject();
				joSlowQuery.put("query", rst.getString("query"));
				joSlowQuery.put("count", rst.getString("cnt"));
				joSlowQuery.put("min_duration", rst.getFloat("min_duration_ms"));
				joSlowQuery.put("max_duration", rst.getFloat("max_duration_ms"));
				joSlowQuery.put("avg_duration", rst.getFloat("avg_duration_ms"));
				
				jaSlowQueries.add(joSlowQuery);
				joSlowQuery = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
	return jaSlowQueries;
	}
	
	public JSONArray getSlowQueryWithDateRange(Connection con, String strFromStartInterval, String strToInterval, String strGUID) throws Exception {

		PreparedStatement pstmt = null;
		ResultSet rst = null;

		JSONArray jaSlowQueries = new JSONArray();
		JSONObject joSlowQuery = null;

		try {

			pstmt = con.prepareStatement("SELECT * FROM get_expensive_queries_with_date_range(?, ?, ?)");
			pstmt.setString(1, strGUID);
			pstmt.setLong(2, Long.parseLong(strFromStartInterval));
			pstmt.setLong(3, Long.parseLong(strToInterval));

			rst = pstmt.executeQuery();
			while (rst.next()) {
				joSlowQuery = new JSONObject();
				joSlowQuery.put("query", rst.getString("query"));
				joSlowQuery.put("count", rst.getString("cnt"));
				joSlowQuery.put("min_duration", rst.getFloat("min_duration_ms"));
				joSlowQuery.put("max_duration", rst.getFloat("max_duration_ms"));
				joSlowQuery.put("avg_duration", rst.getFloat("avg_duration_ms"));

				jaSlowQueries.add(joSlowQuery);
				joSlowQuery = null;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return jaSlowQueries;
	}
	
	public JSONArray getSecCounter(Connection con, long lUserId,String strModuleCode, String guid) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONArray jaModules = new JSONArray();
		JSONObject joModule = null;
		try {
			String query = "select * from get_sec_counter(?,?,?)";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(lUserId + ""));
			pstmt.setString(2, strModuleCode);
			pstmt.setString(3, guid);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joModule = new JSONObject();
				joModule.put("counter_id", rst.getLong("counter_id"));
				joModule.put("label", rst.getString("display_name"));
				joModule.put("value", rst.getBigDecimal("count").abs());
				joModule.put("unit", rst.getString("unit"));
				jaModules.add(joModule);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return jaModules;
	}
	
	/**
	 * gets guid's minichart counter(s) sent in param's data, 
	 *  with guid/agent is_active
	 *  
	 * @param con
	 * @param loginBean
	 * @param jaModulesCounters
	 * @return
	 * @throws Exception
	 */
	public JSONObject getAPMModuleCounters(Connection con, LoginUserBean loginBean, JSONArray jaModulesCounters) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joModuleData = null, joGUIDWiseData = null, joModuleCounter = null;
		
		String strGUID = null, strCounterIds = null;
		
		try {
			joGUIDWiseData = new JSONObject();
			
			sbQuery .append("SELECT * FROM get_modules_card_values(?, ?)");			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			for( int i = 0; i < jaModulesCounters.size(); i++ ){
				joModuleCounter = jaModulesCounters.getJSONObject(i);
				strGUID = joModuleCounter.getString("guid");
				strCounterIds = joModuleCounter.getString("counter_id");
				
				pstmt.setString(1, strGUID);
				pstmt.setString(2, strCounterIds);
				rst = pstmt.executeQuery();
				if(rst.next()) {
					joModuleData = new JSONObject();
					joModuleData.put("label_1",rst.getString("counter_id_1"));
					joModuleData.put("value_1",rst.getDouble("counter_value_1"));
					joModuleData.put("label_2",rst.getString("counter_id_2"));
					joModuleData.put("value_2",rst.getDouble("counter_value_2"));
					joModuleData.put("monitor_active", rst.getBoolean("monitor_active"));
					joModuleData.put("profiler_active", rst.getBoolean("profiler_active"));
					
					joGUIDWiseData.put(strGUID, joModuleData);
					
					UtilsFactory.clearCollectionHieracy(joModuleData);
				}
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		
	 	return joGUIDWiseData;
	}


	public JSONArray getSecCounterValues(Connection con, long lUserId, String strModuleCode, String strGUID, String strCounterId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONArray jaModules = new JSONArray();
		JSONObject joModule = null;
		
		String strQuery = "";
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			strQuery = "select uid from module_master where user_id = ? and module_code = ? and guid = ?";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1, Integer.parseInt(lUserId + ""));
			pstmt.setString(2,strModuleCode);
			pstmt.setString(3,strGUID);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				Long lUid = rst.getLong("uid");
				String[] saCounterIds = strCounterId.split(",");
				for(int i = 0;i<saCounterIds.length;i++){
					sbQuery	.append("SELECT CASE WHEN counter_value IS NULL THEN 0 ELSE counter_value END ")
					 		.append("FROM collector_").append(lUid).append(" ")
					 		.append("WHERE counter_type = ? ")
					 		.append("AND appedo_received_on > now() - interval '1 minute' ");
					
					pstmt = con.prepareStatement(sbQuery.toString());
					pstmt.setLong(1,Long.parseLong(saCounterIds[i]));
					rst = pstmt.executeQuery();
					joModule = new JSONObject();
					joModule.put("value","0");
					 if(rst.next()) {
						 joModule.put("value",rst.getBigDecimal("counter_value").abs());
					 }
					 jaModules.add(joModule);
					 
					 // clears 
					 sbQuery.setLength(0);
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strQuery = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		return jaModules;
	}


	public void updateExecutionServiceFailedStatus(Connection con) throws Exception {
		PreparedStatement pstmt = null, pstmtSelect = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rs = null;
		long lastUpdatedTime = 0;
		
		try {
			sbQuery .append("SELECT lt_controller_status_last_updated FROM appedo_pvt_counters ");
			pstmtSelect = con.prepareStatement(sbQuery.toString());
			rs = pstmtSelect.executeQuery();
			if(rs.next()){
				lastUpdatedTime = rs.getTimestamp("lt_controller_status_last_updated").getTime();
			}
			
			if( (System.currentTimeMillis() - lastUpdatedTime) > 60000 ){
				sbQuery.setLength(0);
				sbQuery	.append("UPDATE appedo_pvt_counters SET lt_controller_status_last_updated = now(), lt_exec_status = false ");
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.execute();
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmtSelect);
			pstmtSelect = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	public LinkedHashMap<String, ArrayList<JSONObject>> getUserAllModules(Connection con, long lServiceMapId, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		LinkedHashMap<String, ArrayList<JSONObject>> lhmModulesDetails = new LinkedHashMap<String, ArrayList<JSONObject>>();
		ArrayList<JSONObject> alModules = null;
		
		JSONObject joModule = null;
		
		String strModuleCode = "";
		
		try {
			/*
			sbQuery	.append("SELECT uid, module_code, module_name, description, guid ")
					.append("FROM module_master ")
					.append("WHERE user_id = ? ")
					.append("ORDER BY module_code, module_name ");
			*/
			
			sbQuery	.append("SELECT ")
					.append("mm.uid, mm.module_code, mm.module_name, mm.guid, "); 
					
			if ( lServiceMapId == -1 ) {
				// for add
				sbQuery	.append("FALSE AS is_selected, null AS smd_id ")
						.append("FROM module_master mm ");
			} else {
				// for edit
				sbQuery	.append("(CASE WHEN smd.uid IS NOT NULL THEN TRUE ELSE FALSE END) is_selected, smd.smd_id ")
						.append("FROM module_master mm ")
						.append("LEFT JOIN ( ")
						.append("  SELECT smd_id, service_map_id, CAST(mapped_service->'module_master'->>'uid' AS bigint) AS uid ") 
						.append("  FROM service_map_details ")
						.append("  WHERE service_map_id =  ").append(lServiceMapId).append(" ")
						.append(") as smd on smd.uid = mm.uid  ");
			}
			sbQuery	.append("WHERE mm.user_id = ").append(lUserId).append(" ");
			if(joEnterprise.getInt("e_id")!=0){
				sbQuery	.append("AND mm.e_id = ").append(joEnterprise.getInt("e_id")).append(" ");
			}
			sbQuery	.append("ORDER BY module_code, module_name ");
			
			
			
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				strModuleCode = rst.getString("module_code");
				
				joModule = new JSONObject();
				joModule.put("uid", rst.getLong("uid"));
				joModule.put("module_code", strModuleCode);
				joModule.put("module_name", rst.getString("module_name"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("isSelected", rst.getBoolean("is_selected"));
				
				
				if ( lhmModulesDetails.containsKey(strModuleCode) ) {
					alModules = lhmModulesDetails.get(strModuleCode);
				} else {
					alModules = new ArrayList<JSONObject>();
					
					// thinks obj by ref
					lhmModulesDetails.put(strModuleCode, alModules);
				}
				
				alModules.add(joModule);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		
		return lhmModulesDetails;
	}
	
	public boolean isEntNameExist(Connection con, String strEnterpriseName, Long e_id) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bRuleExists = false;
		String strQuery = "";
		try {
			strQuery = "SELECT EXISTS(SELECT e_name FROM enterprise_master WHERE lower(e_name)=LOWER(?) AND e_id != ?) as EnterpriseName_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strEnterpriseName);
			pstmt.setLong(2, e_id);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				bRuleExists = rst.getBoolean("EnterpriseName_exists");
			}
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return bRuleExists;
	}
	
	public boolean isEnterpriseNameExist(Connection con, String strEnterpriseName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bRuleExists = false;
		String strQuery = "";
		try {
			strQuery = "SELECT EXISTS(SELECT e_name FROM enterprise_master WHERE lower(e_name)=LOWER(?)) as EnterpriseName_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strEnterpriseName);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				bRuleExists = rst.getBoolean("EnterpriseName_exists");
			}
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return bRuleExists;
	}
	
	public Integer isExistUser(Connection con, JSONObject joEntUserDetails) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bRuleExists = false;
		String strQuery = "";
		int lUser_id = -1;
		try {
			/*strQuery = "SELECT EXISTS(SELECT email_id FROM usermaster WHERE lower(email_id)=LOWER(?)) as user_exists";*/
			strQuery = "SELECT user_id FROM usermaster WHERE lower(email_id)=LOWER(?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, joEntUserDetails.getString("emailId"));
			rst = pstmt.executeQuery();
			if(rst.next()) {
				//bRuleExists = rst.getBoolean("user_exists");
				lUser_id = rst.getInt("user_id");
			}
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		//return bRuleExists;
		return lUser_id;
	}
	
	public JSONArray getDatabaseSlowQuery(Connection con, String strFromStartInterval, String strGUID, int SLOW_QRY_LIMIT, String strDatabaseType) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jaSlowQueries = new JSONArray();
		JSONObject joSlowQuery = null;
		
		try {
			pstmt = con.prepareStatement("select * from get_expensive_database_queries(?, ?, ?, ?)");
			pstmt.setString(1, strGUID);
			pstmt.setString(2, strFromStartInterval);
			pstmt.setInt(3, SLOW_QRY_LIMIT);
			pstmt.setString(4, strDatabaseType);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joSlowQuery = new JSONObject();
				joSlowQuery.put("query", rs.getString("query"));
				joSlowQuery.put("count", rs.getString("cnt"));
				joSlowQuery.put("avg_duration", rs.getFloat("avg_duration_ms"));
				joSlowQuery.put("appedo_received_on", rs.getTimestamp("appedo_received_on").getTime());
				
				jaSlowQueries.add(joSlowQuery);
			}
		} catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaSlowQueries;
	}
	
	public JSONArray getDatabaseSlowQueryWithDateRange(Connection con, String strFromStartInterval, String strToInterval, String strGUID, int SLOW_QRY_LIMIT, String strDatabaseType) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jaSlowQueries = new JSONArray();
		JSONObject joSlowQuery = null;
		
		try {
			pstmt = con.prepareStatement("select * from get_expensive_database_queries_with_date_range(?, ?, ?, ?, ?)");
			pstmt.setString(1, strGUID);
			pstmt.setLong(2, Long.parseLong(strFromStartInterval));
			pstmt.setLong(3, Long.parseLong(strToInterval));
			pstmt.setInt(4, SLOW_QRY_LIMIT);
			pstmt.setString(5, strDatabaseType);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joSlowQuery = new JSONObject();
				joSlowQuery.put("query", rs.getString("query"));
				joSlowQuery.put("count", rs.getString("cnt"));
				joSlowQuery.put("avg_duration", rs.getFloat("avg_duration_ms"));
				joSlowQuery.put("appedo_received_on", rs.getTimestamp("appedo_received_on").getTime());
				
				jaSlowQueries.add(joSlowQuery);
			}
		} catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaSlowQueries;
	}

	public JSONArray getDatabaseSlowProcedure(Connection con, String strFromStartInterval, String strGUID, int SLOW_QRY_LIMIT, String strDatabaseType) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jaSlowQueries = new JSONArray();
		JSONObject joSlowQuery = null;
		
		try {
			pstmt = con.prepareStatement("select * from get_expensive_database_procedures(?, ?, ?, ?)");
			pstmt.setString(1, strGUID);
			pstmt.setString(2, strFromStartInterval);
			pstmt.setInt(3, SLOW_QRY_LIMIT);
			pstmt.setString(4, strDatabaseType);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joSlowQuery = new JSONObject();
				joSlowQuery.put("procedure", rs.getString("procedure"));
				joSlowQuery.put("count", rs.getString("cnt"));
				joSlowQuery.put("avg_duration", rs.getFloat("avg_duration_ms"));
				joSlowQuery.put("appedo_received_on", rs.getTimestamp("appedo_received_on").getTime());

				jaSlowQueries.add(joSlowQuery);
			}
		} catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaSlowQueries;
	}
	
	public JSONArray getDatabaseSlowProcedureWithDateRange(Connection con, String strFromStartInterval, String strToInterval, String strGUID, int SLOW_QRY_LIMIT, String strDatabaseType) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONArray jaSlowQueries = new JSONArray();
		JSONObject joSlowQuery = null;
		
		try {
			pstmt = con.prepareStatement("select * from get_expensive_database_procedures_with_date_range(?, ?, ?, ?, ?)");
			pstmt.setString(1, strGUID);
			pstmt.setLong(2, Long.parseLong(strFromStartInterval));
			pstmt.setLong(3, Long.parseLong(strToInterval));
			pstmt.setInt(4, SLOW_QRY_LIMIT);
			pstmt.setString(5, strDatabaseType);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joSlowQuery = new JSONObject();
				joSlowQuery.put("procedure", rs.getString("procedure"));
				joSlowQuery.put("count", rs.getString("cnt"));
				joSlowQuery.put("avg_duration", rs.getFloat("avg_duration_ms"));
				joSlowQuery.put("appedo_received_on", rs.getTimestamp("appedo_received_on").getTime());

				jaSlowQueries.add(joSlowQuery);
			}
		} catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaSlowQueries;
	}

	public JSONArray getPostgresSlowQuery(Connection con, String strFromStartInterval, String strGUID, int SLOW_QRY_LIMIT) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JSONArray jaSlowQueries = new JSONArray();
		JSONObject joSlowQuery = null;
		
		try {
			
			pstmt = con.prepareStatement("select * from get_expensive_postgres_queries(?, ?, ?)");
			pstmt.setString(1, strGUID);
			pstmt.setString(2, strFromStartInterval);
			pstmt.setInt(3, SLOW_QRY_LIMIT);
			rs = pstmt.executeQuery();
			while(rs.next()){
				joSlowQuery = new JSONObject();
				joSlowQuery.put("query", rs.getString("query"));
				joSlowQuery.put("count", rs.getString("cnt"));
				joSlowQuery.put("avg_duration", rs.getFloat("avg_duration_ms"));

				jaSlowQueries.add(joSlowQuery);
				joSlowQuery = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return jaSlowQueries;
	}

	public String isSlaReferenceExist(Connection con, long lUId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strPolicy = "";
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("SELECT sla_name FROM so_sla_counter  ssc ")
					.append("INNER JOIN so_sla ss ON ssc.sla_id = ss.sla_id ")
					.append("  AND uid = ? AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUId);
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			while(rst.next()){
				strPolicy = strPolicy + rst.getString("sla_name");
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return strPolicy;
	}
	

	/**
	 * Create the view "v_user_last_counter_<userId>, which is last counter received for all the Modules of the user.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void createAllModuleLastCounterView(Connection con, long lUserId) throws Exception {
		Statement stmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("SELECT recreate_user_last_counter_view(").append(lUserId).append(")");
			
			stmt = con.createStatement();
			stmt.execute(sbQuery.toString());
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	/**
	 * Drop the view "v_user_last_counter_<userId>, which is last counter received for all the Modules of the user.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void dropAllModuleLastCounterView(Connection con, long lUserId) throws Exception {
		Statement stmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DROP VIEW IF EXISTS v_user_last_counter_").append(lUserId);
			
			stmt = con.createStatement();
			stmt.execute(sbQuery.toString());
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	/**
	 * update the counter to FALSE for particular guid/uid, 
	 *   to remove counter from monitor
	 *   
	 * @param con
	 * @param strGUID
	 * @param lUId
	 * @param lCounterId
	 * @param lUserId
	 * @throws Exception
	 */
	public void unSelectCounter(Connection con, String strGUID, Long lUId, Long lCounterId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE counter_master_").append(lUId).append(" SET ")
					.append("  is_selected = FALSE, ")
					.append("  is_agent_updated = FALSE, ")
					.append("  modified_on = now(), ")
					.append("  modified_by = ? ")
					.append("WHERE counter_id = ? AND guid = ? AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lCounterId);
			pstmt.setString(3, strGUID);
			pstmt.setLong(4, lUserId);
			
			pstmt.executeUpdate();
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * deletes SLAs mapped for the guid, which has only system generated SLA(s)
	 *  (i.e. guid's has user generated SLAs, SLA(s) are not deleted)
	 * 
	 * @param con
	 * @param strGUID
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public long deleteASDSLAs(Connection con, String strGUID, long lUserId) throws Exception {
		CallableStatement cstmt = null;
		
		String strQuery = "";
		
		long lGUIDTotalUserGenSLAs = -1;
		
		try {
			// note: using PreparedSTMT, ResultSet also worked, using qry SELECT * FROM delete_asd_slas(?, ?);
			strQuery = "{call delete_asd_slas(?, ?, ?)}";
			cstmt = con.prepareCall(strQuery);
			cstmt.setString(1, strGUID);
			cstmt.setLong(2, lUserId);
			cstmt.registerOutParameter(3, Types.BIGINT);
			
			cstmt.executeUpdate();
			
			lGUIDTotalUserGenSLAs = cstmt.getLong(3);
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(cstmt);
			cstmt = null;
			
			strQuery = null;
		}
		
		return lGUIDTotalUserGenSLAs;
	}
	
	/**
	 * Get the module details for the given array of UIDs
	 * 
	 * @param con
	 * @param strUIDs
	 * @return
	 * @throws Throwable
	 */
	public HashMap<String, HashMap<String, String> > getModuleDetails(Connection con, StringBuilder sbUIDs) throws Throwable {
		StringBuilder sbQuery = new StringBuilder();
		
		Statement stmt = null;
		ResultSet rst = null;
		HashMap<String, HashMap<String, String> > hmModules = new HashMap<String, HashMap<String, String> >();
		HashMap<String, String> hmModule = null;
		
		Date dateLog = LogManager.logMethodStart();
		try {
			sbQuery	.append("SELECT mm.guid, mm.uid, mm.module_name, mm.module_code ")
					.append("FROM module_master mm ")
					.append("WHERE uid IN (").append(sbUIDs).append(")");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while( rst.next() ) {
				hmModule = new HashMap<String, String>();
				hmModule.put("guid", rst.getString("guid"));
				hmModule.put("uid", rst.getString("uid"));
				hmModule.put("module_name", rst.getString("module_name"));
				hmModule.put("module_code", rst.getString("module_code"));
				
				hmModules.put(hmModule.get("uid"), hmModule);
			}
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		
		return hmModules;
	}
	
	/**
	 * gets particular RUM uid's details, with configured threshold 
	 * 
	 * @param con
	 * @param lUId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getRUMModuleDetails(Connection con, long lUId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joModule = null;
		
		try {
			sbQuery	.append("SELECT mm.uid, mm.guid, mm.module_name, mm.description, ")
					.append("  ssr.warning_threshold_value, ssr.critical_threshold_value, ssr.min_breach_count, ")
					.append("  ss.is_active ")
					.append("FROM module_master mm ")
					.append("LEFT JOIN so_sla_rum ssr ON ssr.uid = mm.uid ")
					.append("LEFT JOIN so_sla ss ON ss.sla_id = ssr.sla_id ")
					.append("WHERE mm.uid = ? ");
			/*.append("WHERE mm.uid = ? AND mm.user_id = ? ");*/
			 
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUId);
			/*pstmt.setLong(2, lUserId);*/
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				joModule = new JSONObject();
				joModule.put("uid", rst.getLong("uid"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("moduleName", rst.getString("module_name"));
				joModule.put("description", rst.getString("description"));
				// converts into seconds
				joModule.put("warningThresholdValue", rst.getInt("warning_threshold_value") / 1000);
				joModule.put("criticalThresholdValue", rst.getInt("critical_threshold_value") / 1000);
				joModule.put("minBreachCount", rst.getInt("min_breach_count"));
				joModule.put("isActive", rst.getBoolean("is_active"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joModule;
	}
}