package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.manager.LogManager;
import com.appedo.module.bean.CILicenseBean;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class CIDBI {

	public JSONArray getEventsSummary(Connection con, long lUID, String strFromStartInterval, int nMaxEvents, String strAgentType, String strEnvironmnet) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaEventsSummary = null;
		JSONObject joEventSummary = null;

		int i = 0;
		//long lMaxAvgEventDurtion = -1L, lPercentageAvgDuration = 0;
		long lMaxEventVisitorCount = -1L, lPercentageEventVisitorCount = 0;
		
		try {
			// gets events load time data from tem table
			jaEventsSummary = new JSONArray();
			
			// events load time data would be inserted into temp table after executing below qry
			strQuery = "SELECT * FROM get_events_summary(?, ?, ?::smallint, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUID);
			pstmt.setString(2, strFromStartInterval);
			pstmt.setInt(3, nMaxEvents);
			pstmt.setString(4, strAgentType);
			if ( strEnvironmnet == null ) {
				pstmt.setNull(5, Types.VARCHAR);
			} else {
				pstmt.setString(5, strEnvironmnet);
			}
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventSummary = new JSONObject();
				joEventSummary.put("eventId", rst.getLong("event_id"));
				joEventSummary.put("eventName", rst.getString("event_name"));
				joEventSummary.put("eventMethod", rst.getString("event_method"));
				joEventSummary.put("eventVisitorCount", rst.getString("event_visitor_count"));
				joEventSummary.put("avgEventDuration", rst.getString("avg_event_duration"));

				// tried for percentage calculation based on event visitor count
				if (i == 0) {
					lMaxEventVisitorCount = rst.getLong("event_visitor_count");
					if(lMaxEventVisitorCount == 0) {
						lMaxEventVisitorCount = 1;
					}
				}
				lPercentageEventVisitorCount = (rst.getLong("event_visitor_count") * 100) / lMaxEventVisitorCount ;
				joEventSummary.put("percentageEventVisitorCount", lPercentageEventVisitorCount);
				
				jaEventsSummary.add(joEventSummary);
				i = i + 1;
			}
			
			// drop temp table if exists
			dropEventSummaryTempTable(con);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaEventsSummary;
	}
	
	public JSONArray getEventsSummaryWithDateRange(Connection con, long lUID, String strFromStartInterval, String strToInterval, int nMaxEvents, String strAgentType, String strEnvironmnet) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaEventsSummary = null;
		JSONObject joEventSummary = null;

		int i = 0;
		//long lMaxAvgEventDurtion = -1L, lPercentageAvgDuration = 0;
		long lMaxEventVisitorCount = -1L, lPercentageEventVisitorCount = 0;
		
		try {
			// gets events load time data from tem table
			jaEventsSummary = new JSONArray();
			
			// events load time data would be inserted into temp table after executing below qry
			strQuery = "SELECT * FROM get_events_summary_with_date_range(?, ?, ?, ?::smallint, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUID);
			pstmt.setLong(2, Long.parseLong(strFromStartInterval));
			pstmt.setLong(3,Long.parseLong(strToInterval));
			pstmt.setInt(4, nMaxEvents);
			pstmt.setString(5, strAgentType);
			if ( strEnvironmnet == null ) {
				pstmt.setNull(6, Types.VARCHAR);
			} else {
				pstmt.setString(6, strEnvironmnet);
			}
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventSummary = new JSONObject();
				joEventSummary.put("eventId", rst.getLong("event_id"));
				joEventSummary.put("eventName", rst.getString("event_name"));
				joEventSummary.put("eventMethod", rst.getString("event_method"));
				joEventSummary.put("eventVisitorCount", rst.getString("event_visitor_count"));
				joEventSummary.put("avgEventDuration", rst.getString("avg_event_duration"));

				// tried for percentage calculation based on event visitor count
				if (i == 0) {
					lMaxEventVisitorCount = rst.getLong("event_visitor_count");
					if(lMaxEventVisitorCount == 0) {
						lMaxEventVisitorCount = 1;
					}
				}
				lPercentageEventVisitorCount = (rst.getLong("event_visitor_count") * 100) / lMaxEventVisitorCount ;
				joEventSummary.put("percentageEventVisitorCount", lPercentageEventVisitorCount);
				
				jaEventsSummary.add(joEventSummary);
				i = i + 1;
			}
			
			// drop temp table if exists
			dropEventSummaryTempTable(con);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaEventsSummary;
	}
	
	public void dropEventSummaryTempTable(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "DROP TABLE IF EXISTS event_summary_temp ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.execute();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	public JSONObject getEventLoadTime(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();

		JSONObject joResult = new JSONObject(), joData = null;
		
		try {
			/*
			sbQuery	.append("SELECT * FROM ( ")
					.append("  SELECT appedo_received_on, evt_duration ")
					.append("  FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("  WHERE appedo_received_on > (now() - interval '24 hours') ")
					.append("  ORDER BY appedo_received_on DESC ")
					.append(") AS tem ")
					.append("ORDER BY appedo_received_on ");
			*/
			
			sbQuery	.append("SELECT * FROM get_ci_event_load_time(?, ?, ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUID);
			pstmt.setLong(2, lEventId);
			pstmt.setString(3, strFromStartInterval);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on").getTime());
				joData.put("V", rst.getLong("evt_duration"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("eventLoadTimeData", alDailyVisitorsCount);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	public JSONObject getEventLoadTimeWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();

		JSONObject joResult = new JSONObject(), joData = null;
		
		try {
			/*
			sbQuery	.append("SELECT * FROM ( ")
					.append("  SELECT appedo_received_on, evt_duration ")
					.append("  FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("  WHERE appedo_received_on > (now() - interval '24 hours') ")
					.append("  ORDER BY appedo_received_on DESC ")
					.append(") AS tem ")
					.append("ORDER BY appedo_received_on ");
			*/
			
			sbQuery	.append("SELECT * FROM get_ci_event_load_time_with_date_range(?, ?, ?, ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUID);
			pstmt.setLong(2, lEventId);
			pstmt.setLong(3, Long.parseLong(strFromStartInterval));
			pstmt.setLong(4, Long.parseLong(strToInterval));
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on").getTime());
				joData.put("V", rst.getLong("evt_duration"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("eventLoadTimeData", alDailyVisitorsCount);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	public JSONArray getBrowserWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joBrowserShareDataum = null;
		JSONArray jaBrowserShareData = null;

		//long lMaxEventVisitCount = -1L, lPercentageEventVisitCount = 0;
		long lTotalVisitCount = 0;
		
		try {
			jaBrowserShareData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(browser, 'Others') AS browser, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now() - interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY browser ")
					.append("ORDER BY visit_count DESC, browser ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joBrowserShareDataum = new JSONObject();
				joBrowserShareDataum.put("browser", rst.getString("browser"));
				joBrowserShareDataum.put("visitCount", rst.getLong("visit_count"));
				
				/*
				// tried for percentage calculation based on event visitor count
				if (i == 0) {
					lMaxEventVisitCount = rst.getLong("visit_count");
					if(lMaxEventVisitCount == 0) {
						lMaxEventVisitCount = 1;
					}
				}
				lPercentageEventVisitCount = (rst.getLong("visit_count") * 100) / lMaxEventVisitCount ;
				joBrowserShareDataum.put("percentageBrowserVisitCount", lPercentageEventVisitCount);*/
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaBrowserShareData.add(joBrowserShareDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaBrowserShareData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaBrowserShareData;
	}
	
	public JSONArray getBrowserWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joBrowserShareDataum = null;
		JSONArray jaBrowserShareData = null;

		//long lMaxEventVisitCount = -1L, lPercentageEventVisitCount = 0;
		long lTotalVisitCount = 0;
		
		try {
			jaBrowserShareData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(browser, 'Others') AS browser, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) GROUP BY browser ")
					.append("ORDER BY visit_count DESC, browser ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joBrowserShareDataum = new JSONObject();
				joBrowserShareDataum.put("browser", rst.getString("browser"));
				joBrowserShareDataum.put("visitCount", rst.getLong("visit_count"));
				
				/*
				// tried for percentage calculation based on event visitor count
				if (i == 0) {
					lMaxEventVisitCount = rst.getLong("visit_count");
					if(lMaxEventVisitCount == 0) {
						lMaxEventVisitCount = 1;
					}
				}
				lPercentageEventVisitCount = (rst.getLong("visit_count") * 100) / lMaxEventVisitCount ;
				joBrowserShareDataum.put("percentageBrowserVisitCount", lPercentageEventVisitCount);*/
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaBrowserShareData.add(joBrowserShareDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaBrowserShareData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaBrowserShareData;
	}

	public JSONArray getDeviceTypeWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceTypeDataum = null;
		JSONArray jaDeviceTypeData = null;

		long lTotalVisitCount = 0;
		
		try {
			jaDeviceTypeData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(device_type, 'Others') AS device_type, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now()- interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY device_type ")
					.append("ORDER BY visit_count DESC, device_type ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceTypeDataum = new JSONObject();
				joDeviceTypeDataum.put("deviceType", rst.getString("device_type"));
				joDeviceTypeDataum.put("visitCount", rst.getLong("visit_count"));
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaDeviceTypeData.add(joDeviceTypeDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaDeviceTypeData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceTypeData;
	}
	
	public JSONArray getDeviceTypeWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceTypeDataum = null;
		JSONArray jaDeviceTypeData = null;

		long lTotalVisitCount = 0;
		
		try {
			jaDeviceTypeData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(device_type, 'Others') AS device_type, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) GROUP BY device_type ")
					.append("ORDER BY visit_count DESC, device_type ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceTypeDataum = new JSONObject();
				joDeviceTypeDataum.put("deviceType", rst.getString("device_type"));
				joDeviceTypeDataum.put("visitCount", rst.getLong("visit_count"));
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaDeviceTypeData.add(joDeviceTypeDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaDeviceTypeData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceTypeData;
	}
	
	public JSONArray getOSWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joOSWiseDataum = null;
		JSONArray jaOSWiseData = null;

		long lTotalVisitCount = 0;
		
		try {
			jaOSWiseData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(os, 'Others') AS os, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now()- interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY os ")
					.append("ORDER BY visit_count DESC, os ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joOSWiseDataum = new JSONObject();
				joOSWiseDataum.put("os", rst.getString("os"));
				joOSWiseDataum.put("visitCount", rst.getLong("visit_count"));
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaOSWiseData.add(joOSWiseDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaOSWiseData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaOSWiseData;
	}
	
	public JSONArray getOSWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joOSWiseDataum = null;
		JSONArray jaOSWiseData = null;

		long lTotalVisitCount = 0;
		
		try {
			jaOSWiseData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(os, 'Others') AS os, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) GROUP BY os ")
					.append("ORDER BY visit_count DESC, os ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joOSWiseDataum = new JSONObject();
				joOSWiseDataum.put("os", rst.getString("os"));
				joOSWiseDataum.put("visitCount", rst.getLong("visit_count"));
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaOSWiseData.add(joOSWiseDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaOSWiseData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaOSWiseData;
	}

	public JSONArray getDeviceNameWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceNameWiseDataum = null;
		JSONArray jaDeviceNameWiseData = null;

		long lTotalVisitCount = 0;
		
		try {
			jaDeviceNameWiseData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(device_name, 'Others') AS device_name, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now()- interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY device_name ")
					.append("ORDER BY visit_count DESC, device_name ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceNameWiseDataum = new JSONObject();
				joDeviceNameWiseDataum.put("deviceName", rst.getString("device_name"));
				joDeviceNameWiseDataum.put("visitCount", rst.getLong("visit_count"));
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaDeviceNameWiseData.add(joDeviceNameWiseDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaDeviceNameWiseData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceNameWiseData;
	}
	
	public JSONArray getDeviceNameWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceNameWiseDataum = null;
		JSONArray jaDeviceNameWiseData = null;

		long lTotalVisitCount = 0;
		
		try {
			jaDeviceNameWiseData = new JSONArray();

			sbQuery	.append("SELECT COALESCE(device_name, 'Others') AS device_name, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) GROUP BY device_name ")
					.append("ORDER BY visit_count DESC, device_name ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceNameWiseDataum = new JSONObject();
				joDeviceNameWiseDataum.put("deviceName", rst.getString("device_name"));
				joDeviceNameWiseDataum.put("visitCount", rst.getLong("visit_count"));
				
				lTotalVisitCount = lTotalVisitCount + rst.getLong("visit_count");
				
				jaDeviceNameWiseData.add(joDeviceNameWiseDataum);
			}
			
			// 
			calcPercentageCIChartData(lTotalVisitCount, jaDeviceNameWiseData);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceNameWiseData;
	}

	public JSONObject getDailyVisitorsCount(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";

		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();
		
		JSONObject joResult = new JSONObject(), joData = null;
		
		try {
			
			if( strFromStartInterval.equals("1 hour") ) {
				// for last 1 hour, grouped minute wise
				strFormatAppedoReceivedOn = "date_trunc('minute', appedo_received_on)";
			} else if( strFromStartInterval.equals("24 hours") || strFromStartInterval.equals("1 day") ) {
				// for Last 24 hours interval, grouped hour wise 
				strFormatAppedoReceivedOn = "date_trunc('hour', appedo_received_on)";
			} else {
				// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
				strFormatAppedoReceivedOn = "appedo_received_on::date";
			}
			sbQuery	.append("SELECT ").append(strFormatAppedoReceivedOn).append(" AS appedo_received_on_formatted, count(*) AS daily_visitor_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on >  now() - interval '").append(strFromStartInterval).append("' ")
					.append("GROUP BY appedo_received_on_formatted ")
					.append("ORDER BY appedo_received_on_formatted ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on_formatted").getTime());
				joData.put("V", rst.getLong("daily_visitor_count"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("dailyVisitorsCount", alDailyVisitorsCount);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return joResult;
	}
	
	public JSONObject getDailyVisitorsCountWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";

		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();
		
		JSONObject joResult = new JSONObject(), joData = null;
		
		try {
			if( Long.parseLong(strToInterval) - Long.parseLong(strFromStartInterval) <= 3600000 ) {
				// for last 1 hour, grouped minute wise
				strFormatAppedoReceivedOn = "date_trunc('minute', appedo_received_on)";
			} else if( Long.parseLong(strToInterval) - Long.parseLong(strFromStartInterval) <= 86400000 ) {
				// for Last 24 hours interval, grouped hour wise 
				strFormatAppedoReceivedOn = "date_trunc('hour', appedo_received_on)";
			} else {
				// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
				strFormatAppedoReceivedOn = "appedo_received_on::date";
			}
			sbQuery	.append("SELECT ").append(strFormatAppedoReceivedOn).append(" AS appedo_received_on_formatted, count(*) AS daily_visitor_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) GROUP BY appedo_received_on_formatted ")
					.append("ORDER BY appedo_received_on_formatted ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on_formatted").getTime());
				joData.put("V", rst.getLong("daily_visitor_count"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("dailyVisitorsCount", alDailyVisitorsCount);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return joResult;
	}

	public JSONArray getEventProperties(Connection con, long lUID, long lEventId, int nMaxProperties) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joEventProperty = null;
		JSONArray jaEventProperties = null;
	 	
		try {
			jaEventProperties = new JSONArray();
			
			sbQuery	.append("SELECT * FROM ( ")
					.append("  SELECT ci_evt_prop_id, property_name ")
					.append("  FROM ci_evt_prop_").append(lUID).append(" ")
					.append("  WHERE ci_event_id = ? ")
					.append("  ORDER BY ci_evt_prop_id ");
			if( nMaxProperties != -1 ) {
				sbQuery.append("  LIMIT ").append(nMaxProperties);
			}
			sbQuery	.append(") all_records ") 
					.append("ORDER BY property_name ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lEventId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventProperty = new JSONObject();
				joEventProperty.put("evtPropId", rst.getString("ci_evt_prop_id"));
				joEventProperty.put("propertyName", rst.getString("property_name"));
				
				jaEventProperties.add(joEventProperty);
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaEventProperties;
	}
	
	public String getEventPropertyColumnName(Connection con, long lUID, long lEvtPropId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		String strPropertyColumnName = "";
		
		try {
			sbQuery	.append("SELECT * ")
					.append("FROM ci_evt_prop_").append(lUID).append(" ")
					.append("WHERE ci_evt_prop_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lEvtPropId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				strPropertyColumnName = rst.getString("column_name");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return strPropertyColumnName;
	}

	/**
	 * gets event property values from the input columnName
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strPropertyColumnName
	 * @return
	 * @throws Exception
	 */
	public JSONArray getEventPropertyValues(Connection con, long lUID, long lEventId, String strPropertyColumnName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joEventProperty = null;
		JSONArray jaEventProperties = null;
		
		//ArrayList<String> alPropertyValues = new ArrayList<String>();
	 	
		try {
			jaEventProperties = new JSONArray();
			
			sbQuery	.append("SELECT DISTINCT ").append(strPropertyColumnName).append(" ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("ORDER BY ").append(strPropertyColumnName);

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventProperty = new JSONObject();
				joEventProperty.put("propertyValue", rst.getString(1));
				
				jaEventProperties.add(joEventProperty);
				
				//alPropertyValues.add(rst.getString(1));
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaEventProperties;
	}
	
	/**
	 * gets respective event's transactions of particular given columns
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param lEvtPropId
	 * @param strPropertyColumnName
	 * @param strPropertyValue
	 * @return
	 * @throws Exception
	 */
	public JSONArray getEventTransactionsSelectedColumns(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyColumnName, String strPropertyValue, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joEventTransaction = null;
		JSONArray jaEventTransactions = null;

		try {
			jaEventTransactions = new JSONArray();

			sbQuery	.append("SELECT first_name, last_name, email_id, mobile, age, referrer_url ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > now() - INTERVAL '").append(strFromStartInterval).append("' ");
					
			// for `ALL` values to show avoided where condition 
			if( lEvtPropId != -1 ) {
				sbQuery	.append("AND ").append(strPropertyColumnName).append(" = '").append(strPropertyValue).append("' ");
			}
			sbQuery	.append("GROUP BY first_name, last_name, email_id, mobile, age, referrer_url ")
					.append("ORDER BY email_id ");

			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setString(1, strPropertyValue);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventTransaction = new JSONObject();
				//joEventTransaction.put("evtTransId", rst.getString("ci_evt_trans_id"));
				joEventTransaction.put("firstName", UtilsFactory.replaceNull(rst.getString("first_name"), "Guest"));
				joEventTransaction.put("lastName", UtilsFactory.replaceNull(rst.getString("last_name"), "Guest"));
				joEventTransaction.put("emailId", rst.getString("email_id"));
				joEventTransaction.put("mobile", rst.getString("mobile"));
				joEventTransaction.put("age", rst.getString("age"));
				joEventTransaction.put("referrerUrl", rst.getString("referrer_url"));
				//joEventTransaction.put("evtStartTime", rst.getString("evt_start_time"));
				//joEventTransaction.put("evtEndTime", rst.getString("evt_end_time"));
				
				jaEventTransactions.add(joEventTransaction);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaEventTransactions;
	}
	
	public JSONArray getEventTransactionsSelectedColumnsWithDateRange(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyColumnName, String strPropertyValue, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joEventTransaction = null;
		JSONArray jaEventTransactions = null;

		try {
			jaEventTransactions = new JSONArray();

			sbQuery	.append("SELECT first_name, last_name, email_id, mobile, age, referrer_url ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) ");
					
			// for `ALL` values to show avoided where condition 
			if( lEvtPropId != -1 ) {
				sbQuery	.append("AND ").append(strPropertyColumnName).append(" = '").append(strPropertyValue).append("' ");
			}
			sbQuery	.append("GROUP BY first_name, last_name, email_id, mobile, age, referrer_url ")
					.append("ORDER BY email_id ");

			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setString(1, strPropertyValue);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventTransaction = new JSONObject();
				//joEventTransaction.put("evtTransId", rst.getString("ci_evt_trans_id"));
				joEventTransaction.put("firstName", UtilsFactory.replaceNull(rst.getString("first_name"), "Guest"));
				joEventTransaction.put("lastName", UtilsFactory.replaceNull(rst.getString("last_name"), "Guest"));
				joEventTransaction.put("emailId", rst.getString("email_id"));
				joEventTransaction.put("mobile", rst.getString("mobile"));
				joEventTransaction.put("age", rst.getString("age"));
				joEventTransaction.put("referrerUrl", rst.getString("referrer_url"));
				//joEventTransaction.put("evtStartTime", rst.getString("evt_start_time"));
				//joEventTransaction.put("evtEndTime", rst.getString("evt_end_time"));
				
				jaEventTransactions.add(joEventTransaction);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaEventTransactions;
	}
	
	/**
	 * gets event's dynamic column name mapped with respective property
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @return
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getEventColumnNameMappedWithProperty(Connection con, long lUID, long lEventId, int nMaxProperties) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		LinkedHashMap<String, String> lhmEventColumnWisePropertyName = new LinkedHashMap<String, String>();
		
		try {
			
			sbQuery	.append("SELECT ci_evt_prop_id, property_name, column_name ")
					.append("FROM ci_evt_prop_").append(lUID).append(" ")
					.append("WHERE ci_event_id = ? ")
					.append("ORDER BY ci_evt_prop_id ");
			// limit 
			if ( nMaxProperties != -1 ) {
				sbQuery.append("LIMIT ").append(nMaxProperties);
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lEventId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				lhmEventColumnWisePropertyName.put(rst.getString("column_name"), rst.getString("property_name"));
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lhmEventColumnWisePropertyName;
	}
	


	public JSONObject getEventTransaction(Connection con, long lUID, long lEventId, long lEvtTransId, LinkedHashMap<String, String> lhmEventColumnWisePropertyName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strColumnName = "", strProperty = "", strPropertyValue = "";
		
		JSONObject joEventTransaction = null, joProperties = null;

		Iterator itEventColumnWiseProperty = null;
		
		try {
			sbQuery	.append("SELECT * ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE ci_evt_trans_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lEvtTransId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				joEventTransaction = new JSONObject();
				joProperties = new JSONObject();
				/*joEventTransaction.put("ci_evt_trans_id", rst.getString("ci_evt_trans_id"));
				joEventTransaction.put("ci_event_id", rst.getString("ci_event_id"));
				joEventTransaction.put("guid", rst.getString("guid"));
				joEventTransaction.put("uid", rst.getString("uid"));*/
				joEventTransaction.put("eventName", rst.getString("event_name"));
				joEventTransaction.put("uri", rst.getString("uri"));
				joEventTransaction.put("baseUrl", rst.getString("base_url"));
				joEventTransaction.put("ipAddress", rst.getString("ip_address"));
				joEventTransaction.put("browser", rst.getString("browser"));
				joEventTransaction.put("browserVersion", rst.getString("browser_version"));
				joEventTransaction.put("os", rst.getString("os"));
				joEventTransaction.put("osVersion", rst.getString("os_version"));
				joEventTransaction.put("deviceName", rst.getString("device_name"));
				joEventTransaction.put("deviceType", rst.getString("device_type"));
				joEventTransaction.put("merchantName", rst.getString("merchant_name"));
				joEventTransaction.put("firstName", rst.getString("first_name"));
				joEventTransaction.put("lastName", rst.getString("last_name"));
				joEventTransaction.put("emailId", rst.getString("email_id"));
				joEventTransaction.put("mobile", rst.getString("mobile"));
				joEventTransaction.put("age", rst.getString("age"));
				joEventTransaction.put("referrerUrl", rst.getString("referrer_url"));
				joEventTransaction.put("evtStartTime", rst.getTimestamp("evt_start_time").getTime());
				joEventTransaction.put("evtEndTime", rst.getTimestamp("evt_end_time").getTime());
				joEventTransaction.put("evtDuration", rst.getString("evt_duration"));
				joEventTransaction.put("receivedOn", rst.getString("received_on"));
				joEventTransaction.put("appedoReceivedOn", rst.getString("appedo_received_on"));
				
				// to get respective property values from dynamic column name
				itEventColumnWiseProperty = lhmEventColumnWisePropertyName.entrySet().iterator();
				while (itEventColumnWiseProperty.hasNext()) {
					Map.Entry<String, String> pairs = (Map.Entry<String, String>) itEventColumnWiseProperty.next();
					strColumnName = pairs.getKey();
					strProperty = pairs.getValue();
					strPropertyValue = rst.getString(strColumnName);
					
					joProperties.put(strProperty, strPropertyValue);
					//it.remove(); // avoids a ConcurrentModificationException
				}
				joEventTransaction.put("properties", joProperties);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strColumnName = null;
			strProperty = null;
			strPropertyValue = null;
			
			itEventColumnWiseProperty = null;
		}
		
		return joEventTransaction;
	}
	
	/**
	 * gets respective event's transactions of all available columns
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param lEvtPropId
	 * @param strPropertyColumnName
	 * @param strPropertyValue
	 * @param lhmEventColumnWisePropertyName
	 * @return
	 * @throws Exception
	 */
	public JSONObject getEventDetailedTransactions(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyColumnName, String strPropertyValue, LinkedHashMap<String, String> lhmEventColumnWisePropertyName, String strFromStartInterval, String strLimit, String strOffset) throws Exception {
		PreparedStatement pstmt = null, pstmtCnt = null;
		ResultSet rst = null, rstCnt = null;

		StringBuilder sbQuery = new StringBuilder();
		String strColumnName = "", strProperty = "", strColumnPropertyValue = "";
		
		JSONObject joEventTransaction = null, joProperties = null, joResult = new JSONObject();
		JSONArray jaEventTransactions = null;

		Iterator itEventColumnWiseProperty = null;
		
		long lTotalResults = -1l;
		
		try {
			jaEventTransactions = new JSONArray();
			
			sbQuery	.append("SELECT count(*) as total_results ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > now() - INTERVAL '").append(strFromStartInterval).append("' ");
			// for `ALL` values to show avoided where condition 
			if( lEvtPropId != -1 ) {
				sbQuery	.append("AND ").append(strPropertyColumnName).append(" = '").append(strPropertyValue).append("' ");
			}

			pstmtCnt = con.prepareStatement(sbQuery.toString());
			rstCnt = pstmtCnt.executeQuery();
			if( rstCnt.next() ) {
				lTotalResults = rstCnt.getLong("total_results");
			}
			
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			
			sbQuery	.append("SELECT * ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > now() - INTERVAL '").append(strFromStartInterval).append("' ");
			// for `ALL` values to show avoided where condition 
			if( lEvtPropId != -1 ) {
				sbQuery	.append("AND ").append(strPropertyColumnName).append(" = '").append(strPropertyValue).append("' ");
			}
			sbQuery.append("ORDER BY email_id ");
			if ( strLimit != null && strLimit.length() > 0 ) {
				sbQuery	.append("LIMIT ").append(strLimit).append(" ");
				
				if ( strOffset != null && strOffset.length() > 0 ) {
					sbQuery	.append("OFFSET ").append(strOffset).append(" ");
				}
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventTransaction = new JSONObject();
				joProperties = new JSONObject();
				joEventTransaction.put("evtTransId", rst.getString("ci_evt_trans_id"));
				joEventTransaction.put("eventName", rst.getString("event_name"));
				joEventTransaction.put("uri", rst.getString("uri"));
				joEventTransaction.put("baseUrl", rst.getString("base_url"));
				joEventTransaction.put("ipAddress", rst.getString("ip_address"));
				joEventTransaction.put("browser", rst.getString("browser"));
				joEventTransaction.put("browserVersion", rst.getString("browser_version"));
				joEventTransaction.put("os", rst.getString("os"));
				joEventTransaction.put("osVersion", rst.getString("os_version"));
				joEventTransaction.put("deviceName", rst.getString("device_name"));
				joEventTransaction.put("deviceType", rst.getString("device_type"));
				joEventTransaction.put("merchantName", rst.getString("merchant_name"));
				joEventTransaction.put("firstName", UtilsFactory.replaceNull(rst.getString("first_name"), "Guest"));
				joEventTransaction.put("lastName", UtilsFactory.replaceNull(rst.getString("last_name"), "Guest"));
				joEventTransaction.put("emailId", rst.getString("email_id"));
				joEventTransaction.put("mobile", rst.getString("mobile"));
				joEventTransaction.put("age", rst.getString("age"));
				joEventTransaction.put("referrerUrl", rst.getString("referrer_url"));
				joEventTransaction.put("evtStartTime", rst.getTimestamp("evt_start_time").getTime());
				joEventTransaction.put("evtEndTime", rst.getTimestamp("evt_end_time").getTime());
				joEventTransaction.put("evtDuration", rst.getString("evt_duration"));
				joEventTransaction.put("receivedOn", rst.getString("received_on"));
				joEventTransaction.put("appedoReceivedOn", rst.getString("appedo_received_on"));

				// TODO: Think, need optimize the below logic, since when second time above while loop runs, respective column's property would be same
				// to get respective property values from dynamic column name
				itEventColumnWiseProperty = lhmEventColumnWisePropertyName.entrySet().iterator();
				while (itEventColumnWiseProperty.hasNext()) {
					Map.Entry<String, String> pairs = (Map.Entry<String, String>) itEventColumnWiseProperty.next();
					strColumnName = pairs.getKey();
					strProperty = pairs.getValue();
					strColumnPropertyValue = UtilsFactory.replaceNull(rst.getString(strColumnName), "");
					
					joProperties.put(strProperty, strColumnPropertyValue);
					//it.remove(); // avoids a ConcurrentModificationException
				}
				joEventTransaction.put("properties", joProperties);
				
				jaEventTransactions.add(joEventTransaction);
			}
			joResult.put("totalResults", lTotalResults);
			joResult.put("transactions", jaEventTransactions);
			
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rstCnt);
			rst = null;
			DataBaseManager.close(pstmtCnt);
			pstmt = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	public JSONObject getEventDetailedTransactionsWithDateRange(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyColumnName, String strPropertyValue, LinkedHashMap<String, String> lhmEventColumnWisePropertyName, String strFromStartInterval, String strToInterval, String strLimit, String strOffset) throws Exception {
		PreparedStatement pstmt = null, pstmtCnt = null;
		ResultSet rst = null, rstCnt = null;

		StringBuilder sbQuery = new StringBuilder();
		String strColumnName = "", strProperty = "", strColumnPropertyValue = "";
		
		JSONObject joEventTransaction = null, joProperties = null, joResult = new JSONObject();
		JSONArray jaEventTransactions = null;

		Iterator itEventColumnWiseProperty = null;
		
		long lTotalResults = -1l;
		
		try {
			jaEventTransactions = new JSONArray();
			
			sbQuery	.append("SELECT count(*) as total_results ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) ");
			// for `ALL` values to show avoided where condition 
			if( lEvtPropId != -1 ) {
				sbQuery	.append("AND ").append(strPropertyColumnName).append(" = '").append(strPropertyValue).append("' ");
			}

			pstmtCnt = con.prepareStatement(sbQuery.toString());
			rstCnt = pstmtCnt.executeQuery();
			if( rstCnt.next() ) {
				lTotalResults = rstCnt.getLong("total_results");
			}
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			
			sbQuery	.append("SELECT * ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) ");
			// for `ALL` values to show avoided where condition 
			if( lEvtPropId != -1 ) {
				sbQuery	.append("AND ").append(strPropertyColumnName).append(" = '").append(strPropertyValue).append("' ");
			}
			sbQuery.append("ORDER BY email_id ");
			if ( strLimit != null && strLimit.length() > 0 ) {
				sbQuery	.append("LIMIT ").append(strLimit).append(" ");
				
				if ( strOffset != null && strOffset.length() > 0 ) {
					sbQuery	.append("OFFSET ").append(strOffset).append(" ");
				}
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joEventTransaction = new JSONObject();
				joProperties = new JSONObject();
				joEventTransaction.put("evtTransId", rst.getString("ci_evt_trans_id"));
				joEventTransaction.put("eventName", rst.getString("event_name"));
				joEventTransaction.put("uri", rst.getString("uri"));
				joEventTransaction.put("baseUrl", rst.getString("base_url"));
				joEventTransaction.put("ipAddress", rst.getString("ip_address"));
				joEventTransaction.put("browser", rst.getString("browser"));
				joEventTransaction.put("browserVersion", rst.getString("browser_version"));
				joEventTransaction.put("os", rst.getString("os"));
				joEventTransaction.put("osVersion", rst.getString("os_version"));
				joEventTransaction.put("deviceName", rst.getString("device_name"));
				joEventTransaction.put("deviceType", rst.getString("device_type"));
				joEventTransaction.put("merchantName", rst.getString("merchant_name"));
				joEventTransaction.put("firstName", UtilsFactory.replaceNull(rst.getString("first_name"), "Guest"));
				joEventTransaction.put("lastName", UtilsFactory.replaceNull(rst.getString("last_name"), "Guest"));
				joEventTransaction.put("emailId", rst.getString("email_id"));
				joEventTransaction.put("mobile", rst.getString("mobile"));
				joEventTransaction.put("age", rst.getString("age"));
				joEventTransaction.put("referrerUrl", rst.getString("referrer_url"));
				joEventTransaction.put("evtStartTime", rst.getTimestamp("evt_start_time").getTime());
				joEventTransaction.put("evtEndTime", rst.getTimestamp("evt_end_time").getTime());
				joEventTransaction.put("evtDuration", rst.getString("evt_duration"));
				joEventTransaction.put("receivedOn", rst.getString("received_on"));
				joEventTransaction.put("appedoReceivedOn", rst.getString("appedo_received_on"));

				// TODO: Think, need optimize the below logic, since when second time above while loop runs, respective column's property would be same
				// to get respective property values from dynamic column name
				itEventColumnWiseProperty = lhmEventColumnWisePropertyName.entrySet().iterator();
				while (itEventColumnWiseProperty.hasNext()) {
					Map.Entry<String, String> pairs = (Map.Entry<String, String>) itEventColumnWiseProperty.next();
					strColumnName = pairs.getKey();
					strProperty = pairs.getValue();
					strColumnPropertyValue = UtilsFactory.replaceNull(rst.getString(strColumnName), "");
					
					joProperties.put(strProperty, strColumnPropertyValue);
					//it.remove(); // avoids a ConcurrentModificationException
				}
				joEventTransaction.put("properties", joProperties);
				
				jaEventTransactions.add(joEventTransaction);
			}
			joResult.put("totalResults", lTotalResults);
			joResult.put("transactions", jaEventTransactions);
			
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rstCnt);
			rst = null;
			DataBaseManager.close(pstmtCnt);
			pstmt = null;
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	/**
	 * calculate percentage
	 *   
	 * @param lTotalVisitCount
	 * @param jaCIChartData
	 */
	private void calcPercentageCIChartData(long lTotalVisitCount, JSONArray jaCIChartData) {
		long lPercentageVisitCount = 0;
		for(int i = 0; i < jaCIChartData.size(); i = i + 1) {
			JSONObject joDataum = jaCIChartData.getJSONObject(i);
			lPercentageVisitCount = (joDataum.getLong("visitCount") * 100) / lTotalVisitCount;
			
			joDataum.put("percentageVisitCount", lPercentageVisitCount);
		}
	}
	
	/**
	 * CI license used rum lic code
	 * 
	 * @param con
	 * @param lUserId
	 * @param strRUMLicLevel
	 * @return
	 * @throws Exception
	 */
	public CILicenseBean getCIUserWiseLicenseMonthWise(Connection con, long lUserId, String strRUMLicLevel) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		CILicenseBean ciLicenseBean = null;
		
		try {
			if( ! strRUMLicLevel.equals("level0") ) {
				// For PAID user
				sbQuery	.append("SELECT user_id, start_date, end_date, ci_max_events, ci_max_properties ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type = 'RUM' ")
						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			} else {
				// For FREE user
				sbQuery	.append("SELECT user_id, created_on AS start_date, ci_max_events, ci_max_properties ")
						.append("FROM usermaster ")
						.append("WHERE user_id = ? ");
			}

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				ciLicenseBean = new CILicenseBean();
				
				ciLicenseBean.setUserId(rst.getLong("user_id"));
				ciLicenseBean.setStartDate(rst.getString("start_date"));
				if( ! strRUMLicLevel.equals("level0") )
					ciLicenseBean.setEndDate(rst.getString("end_date"));
				ciLicenseBean.setMaxEvents(rst.getInt("ci_max_events"));
				ciLicenseBean.setMaxProperties(rst.getInt("ci_max_properties"));
			}

		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return ciLicenseBean;
	}
	
	/**
	 * gets ci license config params for a particular level 
	 * since RUM/CI used rum license level 
	 * 
	 * @param con
	 * @param strRUMLicLevel
	 * @return
	 * @throws Exception
	 */
	public CILicenseBean getCILicenseConfigParameters(Connection con, String strRUMLicLevel) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		CILicenseBean ciLicenseBean = null;
		
		try {
			sbQuery	.append("SELECT * ")
					.append("FROM ci_config_parameters ")
					.append("WHERE lic_internal_name = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strRUMLicLevel);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				ciLicenseBean = new  CILicenseBean();
				
				ciLicenseBean.setLicInternalName(rst.getString("lic_internal_name"));
				ciLicenseBean.setLicExternalName(rst.getString("lic_external_name"));
				
				ciLicenseBean.setReportRetentionInDays(rst.getInt("report_retention_in_days"));
				
				ciLicenseBean.setEnableProfiles(rst.getBoolean("is_enable_profiles"));
				ciLicenseBean.setEnableFilters(rst.getBoolean("is_enable_filters"));
				ciLicenseBean.setEnableNotificationEmail(rst.getBoolean("is_enable_notification_email"));
				ciLicenseBean.setEnableNotificationSMS(rst.getBoolean("is_enable_notification_sms"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery= null;
		}
		
		return ciLicenseBean;
	}
	

	
	/**
	 * gets browser wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getBrowserWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joBrowserShareDataum = null;
		JSONArray jaBrowserShareData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaBrowserShareData = new JSONArray();

			sbQuery	.append("SELECT browser, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now() - interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY browser ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joBrowserShareDataum = new JSONObject();
				joBrowserShareDataum.put("label", rst.getString("browser"));
				
				if( i < 3 ) {
					joBrowserShareDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joBrowserShareDataum.put("value", lOthersVisitCount);
				}
				
				jaBrowserShareData.add(joBrowserShareDataum);
				
				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaBrowserShareData;
	}

	public JSONArray getBrowserWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joBrowserShareDataum = null;
		JSONArray jaBrowserShareData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaBrowserShareData = new JSONArray();

			sbQuery	.append("SELECT browser, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) GROUP BY browser ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joBrowserShareDataum = new JSONObject();
				joBrowserShareDataum.put("label", rst.getString("browser"));
				
				if( i < 3 ) {
					joBrowserShareDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joBrowserShareDataum.put("value", lOthersVisitCount);
				}
				
				jaBrowserShareData.add(joBrowserShareDataum);
				
				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaBrowserShareData;
	}
	
	/**
	 * gets DeviceType wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getDeviceTypeWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceTypeDataum = null;
		JSONArray jaDeviceTypeData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaDeviceTypeData = new JSONArray();

			sbQuery	.append("SELECT device_type, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now() - interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY device_type ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceTypeDataum = new JSONObject();
				joDeviceTypeDataum.put("label", rst.getString("device_type"));
				
				if( i < 3 ) {
					joDeviceTypeDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joDeviceTypeDataum.put("value", lOthersVisitCount);
				}
				
				jaDeviceTypeData.add(joDeviceTypeDataum);
				
				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceTypeData;
	}

	public JSONArray getDeviceTypeWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceTypeDataum = null;
		JSONArray jaDeviceTypeData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaDeviceTypeData = new JSONArray();

			sbQuery	.append("SELECT device_type, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) ")
					.append("GROUP BY device_type ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceTypeDataum = new JSONObject();
				joDeviceTypeDataum.put("label", rst.getString("device_type"));
				
				if( i < 3 ) {
					joDeviceTypeDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joDeviceTypeDataum.put("value", lOthersVisitCount);
				}
				
				jaDeviceTypeData.add(joDeviceTypeDataum);
				
				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceTypeData;
	}
	
	/**
	 * gets OSWise wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getOSWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joOSWiseDataum = null;
		JSONArray jaOSWiseData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaOSWiseData = new JSONArray();

			sbQuery	.append("SELECT os, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now() - interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY os ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joOSWiseDataum = new JSONObject();
				joOSWiseDataum.put("label", rst.getString("os"));

				if( i < 3 ) {
					joOSWiseDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joOSWiseDataum.put("value", lOthersVisitCount);
				}
				
				jaOSWiseData.add(joOSWiseDataum);
				
				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaOSWiseData;
	}
	
	public JSONArray getOSWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joOSWiseDataum = null;
		JSONArray jaOSWiseData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaOSWiseData = new JSONArray();

			sbQuery	.append("SELECT os, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) ")
					.append("GROUP BY os ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joOSWiseDataum = new JSONObject();
				joOSWiseDataum.put("label", rst.getString("os"));

				if( i < 3 ) {
					joOSWiseDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joOSWiseDataum.put("value", lOthersVisitCount);
				}
				
				jaOSWiseData.add(joOSWiseDataum);
				
				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaOSWiseData;
	}
	
	/**
	 * gets DeviceName wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getDeviceNameWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceNameWiseDataum = null;
		JSONArray jaDeviceNameWiseData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaDeviceNameWiseData = new JSONArray();

			sbQuery	.append("SELECT device_name, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on > (now()- interval '").append(strFromStartInterval).append("') ")
					.append("GROUP BY device_name ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceNameWiseDataum = new JSONObject();
				joDeviceNameWiseDataum.put("label", rst.getString("device_name"));

				if( i < 3 ) {
					joDeviceNameWiseDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joDeviceNameWiseDataum.put("value", lOthersVisitCount);
				}
				
				jaDeviceNameWiseData.add(joDeviceNameWiseDataum);

				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceNameWiseData;
	}
	
	public JSONArray getDeviceNameWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDeviceNameWiseDataum = null;
		JSONArray jaDeviceNameWiseData = null;

		int i = 0;
		
		long lOthersVisitCount = 0;
		
		try {
			jaDeviceNameWiseData = new JSONArray();

			sbQuery	.append("SELECT device_name, count(*) AS visit_count ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId).append(" ")
					.append("WHERE appedo_received_on::timestamp between to_timestamp("+ Long.parseLong(strFromStartInterval) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strToInterval) + "/1000) ")
					.append("GROUP BY device_name ")
					.append("ORDER BY visit_count DESC ");

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joDeviceNameWiseDataum = new JSONObject();
				joDeviceNameWiseDataum.put("label", rst.getString("device_name"));

				if( i < 3 ) {
					joDeviceNameWiseDataum.put("value", rst.getLong("visit_count"));
				} else {
					lOthersVisitCount = lOthersVisitCount + rst.getLong("visit_count");
					joDeviceNameWiseDataum.put("value", lOthersVisitCount);
				}
				
				jaDeviceNameWiseData.add(joDeviceNameWiseDataum);

				i = i + 1;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaDeviceNameWiseData;
	}
	
	/**
	 * gets particular modules agent types
	 * 
	 * @param con
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleAgentTypes(Connection con, long lUID) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaAgentTypes = null;
		JSONObject joAgentType = null;
		
		try {
			jaAgentTypes = new JSONArray();
			sbQuery	.append("SELECT DISTINCT agent_type ")
					.append("FROM ci_events_").append(lUID);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joAgentType =  new JSONObject();
				joAgentType.put("agentTypeName", rst.getString("agent_type"));
				joAgentType.put("agentTypeValue", rst.getString("agent_type"));
				
				jaAgentTypes.add(joAgentType);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaAgentTypes;
	}
	

	public JSONArray getModuleEnvironments(Connection con, long lUID) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();

		JSONArray jaEnvironments = null;
		JSONObject joEnvironment = null;
		
		try {
			jaEnvironments = new JSONArray();

			sbQuery	.append("SELECT DISTINCT env ")
					.append("FROM ci_events_").append(lUID);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joEnvironment =  new JSONObject();
				// to replace blank as "None"
				joEnvironment.put("envName", UtilsFactory.replaceNullBlank(rst.getString("env"), "None"));
				joEnvironment.put("envValue", rst.getString("env"));
				
				jaEnvironments.add(joEnvironment);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaEnvironments;
	}
	

	public long getEventLastReceivedOn(Connection con, long lUID, long lEventId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		long lLastReceivedOn = 0L;
		
		try {
			sbQuery	.append("SELECT max(appedo_received_on) AS last_appedo_received_on ")
					.append("FROM ci_trans_").append(lUID).append("_").append(lEventId);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				lLastReceivedOn = rst.getTimestamp("last_appedo_received_on").getTime();
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lLastReceivedOn;
	}
	

	public JSONObject getUserEventsVisitorsCount(Connection con, long lUserId, String strAgentType, String strEnvironment) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joUserEventsVisitorsCount = null;
		
		try {
			sbQuery.append("SELECT * FROM get_user_events_visitors_count(?, ?, ?)");
			
			joUserEventsVisitorsCount = new JSONObject();
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			if( strAgentType == null ) {
				pstmt.setNull(2, Types.VARCHAR);
			} else {
				pstmt.setString(2, strAgentType);
			}
			if( strEnvironment == null ) {
				pstmt.setNull(3, Types.VARCHAR);
			} else {
				pstmt.setString(3, strEnvironment);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joUserEventsVisitorsCount.put(rst.getLong("uid"), rst.getLong("events_visitors_count"));
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joUserEventsVisitorsCount;
	}
	

	public JSONArray getUserEventsDistinctEnvironments(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joEventsDistinctEnvironment = null;
		JSONArray jaEventsDistinctEnvironments = null;
		
		try {
			jaEventsDistinctEnvironments = new JSONArray();
			
			sbQuery.append("SELECT * FROM get_user_events_distinct_environments(?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joEventsDistinctEnvironment = new JSONObject();
				joEventsDistinctEnvironment.put("env", rst.getString("env"));
				
				jaEventsDistinctEnvironments.add(joEventsDistinctEnvironment);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaEventsDistinctEnvironments;
	}
}
