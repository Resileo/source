package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.ServiceMapBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class ServiceDBI {

	
	public long insertServiceMap(Connection con, ServiceMapBean serviceMapBean, long lUserId, long lCreatedBy, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt  = null;
		
		long lServiceMapId = -1L;
		
		int nRowInserted = 0;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("INSERT INTO service_map (name, description, user_id, e_id, created_by, created_on, is_system) VALUES (?, ?, ?, ?, ?, ?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, serviceMapBean.getName());
			pstmt.setString(2, serviceMapBean.getDescription());
			pstmt.setLong(3, lUserId);
			//pstmt.setLong(4, loginUserBean.getEnterpriseId());
			if(joEnterprise != null && joEnterprise.getBoolean("is_owner") && joEnterprise.getInt("e_id") != 0){
				pstmt.setInt(4, joEnterprise.getInt("e_id"));
			}else{
				pstmt.setNull(4, java.sql.Types.INTEGER);
			}
			//pstmt.setLong(4, -1);
			pstmt.setLong(5, lCreatedBy);
			pstmt.setLong(6, (new Date()).getTime());
			pstmt.setBoolean(7, serviceMapBean.isSystemGenerated());
			
			nRowInserted = pstmt.executeUpdate();
			
			// inserted auto generate primary key
			lServiceMapId = DataBaseManager.returnKey(pstmt);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lServiceMapId;
	}
	
	public void insertSetAsDefault(Connection con, long lUserId, long lServiceMapId) throws Exception {
		PreparedStatement pstmt  = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery.append("INSERT INTO default_page_settings(user_id, enterprise_id, crit_warn_name, service_map_id, module_type, created_on, created_by) VALUES (?, null, 'CRITICAL', ?, 'OAD', now(), ?)");     
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lServiceMapId);
			pstmt.setLong(3, lUserId);
			
			pstmt.executeUpdate();
		}catch(Exception e){
			throw e;
		}
	}
	
	public void insertServiceMapDetails(Connection con, long lServiceMapId, JSONObject joMappedModule) throws Exception {
		PreparedStatement pstmt  = null;

		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("INSERT INTO service_map_details (service_map_id, mapped_service) VALUES (?, ?::json) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lServiceMapId);
			pstmt.setString(2, joMappedModule.toString());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public JSONArray getSUMTests(Connection con, long lServiceMapId, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaSUMTests = null;
		JSONObject joSUMTest = null;
		
		try {
			jaSUMTests = new JSONArray();
			/*
			sbQuery	.append("SELECT test_id, testname, testtype, testurl, runevery ")
					.append("FROM sum_test_master ")
					.append("WHERE user_id = ? ")
					.append("order by testname ");
			*/
			
			sbQuery	.append("SELECT ")
					.append("stm.test_id, 'SUM' AS module_code, stm.testname, ");
			if ( lServiceMapId == -1 ) {
				// for add
				sbQuery	.append("FALSE AS is_selected, null AS smd_id ")
						.append("FROM sum_test_master stm ");
			} else {
				// for edit
				sbQuery	.append("(CASE WHEN smd.test_id IS NOT NULL THEN TRUE ELSE FALSE END) is_selected, smd.smd_id ")
						.append("FROM sum_test_master stm ")
						.append("LEFT JOIN ( ")
						.append("  SELECT smd_id, service_map_id, CAST(mapped_service->'module_master'->>'test_id' AS bigint) AS test_id ") 
						.append("  FROM service_map_details ")
						.append("  WHERE service_map_id = ").append(lServiceMapId).append(" ")
						.append(") AS smd ON smd.test_id = stm.test_id ");
			}
			sbQuery	.append("WHERE stm.user_id = ").append(lUserId).append(" ");
			if(joEnterprise.getInt("e_id")!=0){
				sbQuery	.append("AND stm.e_id = ").append(joEnterprise.getInt("e_id")).append(" ");
			}
			sbQuery	.append("ORDER BY testname ");

			//System.out.println("sbQuery: "+sbQuery.toString());
			
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joSUMTest = new JSONObject();
				joSUMTest.put("test_id", rst.getLong("test_id"));
				joSUMTest.put("testname", rst.getString("testname"));
				joSUMTest.put("isSelected", rst.getBoolean("is_selected"));
				joSUMTest.put("module_code", "SUM");
				
				jaSUMTests.add(joSUMTest);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaSUMTests;
	}
	
	public boolean isServiceNameExists(Connection con, String strServiceName, long lServiceMapId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		
		boolean bServiceNameExists = false;
		
		try {
			strQuery = "SELECT EXISTS(SELECT name FROM service_map WHERE user_id = ? AND name = ? AND service_map_id != ?) AS service_map_exists ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strServiceName);
			pstmt.setLong(3, lServiceMapId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bServiceNameExists = rst.getBoolean("service_map_exists");
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			strQuery = null;
		}
		
		return bServiceNameExists;
	}
	
	/**
	 * gets user service maps with total modules mapped for a ServiceMap
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserServiceMapsWithMapCountDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String[] saModulesCount = null, saModuleCount = null;
		String strModuleCode = "", strModulesCount = "";
		
		long lModuleCount = 0L;
		
		JSONArray jaUserServiceMaps = null;
		JSONObject joUserServiceMap = null, joModulesCount = null;
		
		try {
			jaUserServiceMaps = new JSONArray();
			
			// TODO: DONT commit, need to verify
			
			
			// TODO: thinks, LEFT JOIN to use instead of INNER JOIN, if no module is mapped for a ServiceMap that is not shown in cardlayout/grid
			/*
			sbQuery	.append("SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ")
					.append("  string_agg(CONCAT(module_code, ':', module_count), ',') AS modules_count ")
					.append("FROM ( ")
					.append("  SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ") 
					.append("    mapped_service->'module_master'->>'module_code' AS module_code, count(*) AS module_count ")
					.append("  FROM service_map sm ")
					.append("  INNER JOIN service_map_details smd ON sm.service_map_id = smd.service_map_id AND sm.user_id = ? ")
					.append("  GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, module_code ")
					.append(") AS sm ")
					.append("GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on ")
					.append("ORDER BY sm.name ");
			*/
			
			sbQuery	.append("SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ")
					.append("  string_agg((CASE WHEN module_code NOTNULL THEN CONCAT(module_code, ':', module_count) ELSE NULL END), ',') AS modules_count ") 
					.append("FROM ( ")
					.append("  SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ")  
					.append("    mapped_service->'module_master'->>'module_code' AS module_code, count(mapped_service->'module_master'->>'module_code') AS module_count ") 
					.append("  FROM service_map sm  ")
					.append("  LEFT JOIN service_map_details smd ON sm.service_map_id = smd.service_map_id ") 
					.append("  WHERE sm.user_id = ? ")
					.append("  GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, module_code ") 
					.append(") AS sm  ")
					.append("GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on ") 
					.append("ORDER BY sm.name ");
			
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joUserServiceMap = new JSONObject();
				joUserServiceMap.put("serviceMapId", rst.getLong("service_map_id"));
				joUserServiceMap.put("name", rst.getString("name"));
				joUserServiceMap.put("description", rst.getString("description"));
				joUserServiceMap.put("updatedOn", Long.parseLong( (UtilsFactory.replaceNull(rst.getString("modified_on"), rst.getString("created_on")) ) ));
				joUserServiceMap.put("addedOn", Long.parseLong(rst.getString("created_on")));
				joUserServiceMap.put("createdBy", loginUserBean.getFirstName());

				// gets module count
				joModulesCount = new JSONObject();
				
				strModulesCount = rst.getString("modules_count");
				if ( strModulesCount != null) {
					saModulesCount = strModulesCount.split(",");
					for(int i = 0; i < saModulesCount.length; i = i + 1) {
						saModuleCount = saModulesCount[i].split(":");
						strModuleCode = saModuleCount[0];
						lModuleCount = Long.parseLong( saModuleCount[1] );

						joModulesCount.put(strModuleCode, lModuleCount);
					}
				}
				joUserServiceMap.put("modules_count", joModulesCount);

				jaUserServiceMaps.add(joUserServiceMap);
			}

		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			saModulesCount = null;
			saModuleCount = null;
			strModuleCode = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return jaUserServiceMaps;
	}
	
	/**
	 * gets user service maps with total modules mapped for a ServiceMap
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserServiceMapsWithMapCountDetails_v1(Connection con, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String[] saModulesCount = null, saModuleCount = null;
		String strModuleCode = "", strModulesCount = "";
		
		long lModuleCount = 0L;
		
		JSONArray jaUserServiceMaps = null;
		JSONObject joUserServiceMap = null, joModulesCount = null;
		JSONObject joCol_Value = null, jovariable = null;
		
		try {
			jaUserServiceMaps = new JSONArray();
					
			// TODO: thinks, LEFT JOIN to use instead of INNER JOIN, if no module is mapped for a ServiceMap that is not shown in cardlayout/grid
			
		/*	sbQuery	.append("SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ")
					.append("  string_agg((CASE WHEN module_code NOTNULL THEN CONCAT(module_code, ':', module_count) ELSE NULL END), ',') AS modules_count ") 
					.append("FROM ( ")
					.append("  SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ")  
					.append("    mapped_service->'module_master'->>'module_code' AS module_code, count(mapped_service->'module_master'->>'module_code') AS module_count ") 
					.append("  FROM service_map sm  ")
					.append("  LEFT JOIN service_map_details smd ON sm.service_map_id = smd.service_map_id ") 
					.append("  WHERE sm.user_id = ? AND is_system = false ")
					.append("  GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, module_code ") 
					.append(") AS sm  ")
					.append("GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on ") 
					.append("ORDER BY sm.name ");*/
			
			//Enterprise License implemented
			sbQuery	.append("SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ")
					.append("string_agg((CASE WHEN module_code NOTNULL THEN CONCAT(module_code, ':', module_count) ELSE NULL END), ',') AS modules_count ") 
					.append("FROM (SELECT sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, ")
					.append("mapped_service->'module_master'->>'module_code' AS module_code, ")  
					.append("count(mapped_service->'module_master'->>'module_code') AS module_count ") 
					.append("FROM service_map sm LEFT JOIN service_map_details smd ON sm.service_map_id = smd.service_map_id ")
					.append("WHERE sm.user_id = ? AND is_system = false ");
					if(joEnterprise.getInt("e_id") != 0){
						sbQuery	.append("AND sm.e_id = ").append(joEnterprise.getInt("e_id")+" ");
					}		
			sbQuery	.append("GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on, module_code ") 
					.append(") AS sm  ")
					.append("GROUP BY sm.service_map_id, sm.name, sm.description, sm.created_on, sm.modified_on ") 
					.append("ORDER BY sm.name ");
			
			
			pstmt = con.prepareStatement(sbQuery.toString());
			if(joEnterprise.getInt("e_id")!= 0) {
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, loginUserBean.getUserId());
			}
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joCol_Value = new JSONObject();
				jovariable = new JSONObject();
				
				jovariable.put("var1", "is_delete");
				jovariable.put("var2", "is_edit");
				jovariable.put("var3", "is_config");
				jovariable.put("var4", "Service Map");
				joCol_Value.put("col_1", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				

				jovariable.put("var1", rst.getString("name"));
				jovariable.put("var2", "Added By "+loginUserBean.getFirstName()+" on ");
				jovariable.put("var21", Long.parseLong(rst.getString("created_on")));
				joCol_Value.put("col_2", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);

				
				jovariable.put("var1", rst.getString("description"));
				joCol_Value.put("col_3", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				// gets module count
				joModulesCount = new JSONObject();
				
				strModulesCount = rst.getString("modules_count");
				int j = 1;
				if ( strModulesCount != null) {
					saModulesCount = strModulesCount.split(",");
					for(int i = 0; i < saModulesCount.length; i = i + 1) {
						saModuleCount = saModulesCount[i].split(":");
						if(saModuleCount[0].equals("SERVER")){
							strModuleCode = "OS";
						}else if(saModuleCount[0].equals("APPLICATION")) {
							strModuleCode = "Apl";
						}else if(saModuleCount[0].equals("DATABASE")) {
							strModuleCode = "DB";
						}else {
							strModuleCode = saModuleCount[0];
						}
						lModuleCount = Long.parseLong( saModuleCount[1] );

						joModulesCount.put("var"+(j++), strModuleCode);
						joModulesCount.put("var"+(j++), lModuleCount);
						//joModulesCount.put(strModuleCode, lModuleCount);
					}
				}
				joCol_Value.put("col_4567", joModulesCount);

				jovariable.put("var1", "chart_icon");
				joCol_Value.put("col_8", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				joCol_Value.put("serviceMapId", rst.getLong("service_map_id"));
				joCol_Value.put("updatedOn", Long.parseLong( (UtilsFactory.replaceNull(rst.getString("modified_on"), rst.getString("created_on")) ) ));
				
				jaUserServiceMaps.add(joCol_Value);
			}

		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			saModulesCount = null;
			saModuleCount = null;
			strModuleCode = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return jaUserServiceMaps;
	}
	
	/*
	public JSONObject getServiceMapModulesCount(Connection con, long lServiceMapId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joModulesCount = null;
		
		try {
			joModulesCount = new JSONObject();
			
			sbQuery	.append("SELECT mapped_service->'module_master'->>'module_code' AS module_code, count(*) AS module_count ")
					.append("FROM service_map_details ")
					.append("WHERE service_map_id = ? ")
					.append("GROUP BY module_code ")
					.append("ORDER BY module_code ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lServiceMapId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joModulesCount.put(rst.getString("module_code"), rst.getString("module_count"));
			}
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joModulesCount;
	}
	*/
	
	public void updateServiceMap(Connection con, ServiceMapBean serviceMapBean, /*LoginUserBean loginUserBean*/ long lUser_id) throws Exception {
		PreparedStatement pstmt  = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE service_map SET ")
					.append("  name = ?, ")
					.append("  description = ?, ")
					.append("  modified_by = ?, ")
					.append("  modified_on = ? ")
					.append("WHERE service_map_id = ? "); 
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, serviceMapBean.getName());
			pstmt.setString(2, serviceMapBean.getDescription());
			pstmt.setLong(3, lUser_id);
			pstmt.setLong(4, (new Date()).getTime());
			pstmt.setLong(5, serviceMapBean.getServiceMapId());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	public void deleteServiceMap(Connection con, long lServiceMapId, long lUserId) throws Exception {
		PreparedStatement pstmt  = null;
		
		String strQuery = "";
		
		try {
			strQuery = "DELETE FROM service_map WHERE service_map_id = ? AND user_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lServiceMapId);
			pstmt.setLong(2, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	public void deleteServiceMapDetails(Connection con, long lServiceMapId, long lUserId) throws Exception {
		PreparedStatement pstmt  = null;
		
		//String strQuery = "";
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			//strQuery = "DELETE FROM service_map_details WHERE service_map_id = ? ";
			
			sbQuery	.append("DELETE FROM service_map_details smd ")
					.append("USING service_map sm ")
					.append("WHERE sm.service_map_id = smd.service_map_id ")
					.append("  AND smd.service_map_id = ? ")
					.append("  AND sm.user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lServiceMapId);
			pstmt.setLong(2, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			//strQuery = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * Get all the service map json for given userId.
	 * 
	 * @param con
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapData(Connection con, long userId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject joObj = null;
		JSONArray joArr = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			joArr = new JSONArray();
			//sbQuery	.append("SELECT * FROM service_map WHERE user_id = ? ");
			/*
			sbQuery	.append("SELECT service_map_id, name, description, '{'||string_agg(CONCAT('\"', module_code, '\":', module_mapped_service), ',')||'}' AS modules_service ")
					.append("FROM ( ")
					.append("  SELECT ")
					.append("    sm.service_map_id, sm.name, sm.description, ") 
					.append("    smd.mapped_service->'module_master'->>'module_code' AS module_code, ")  
					.append("    json_agg(smd.mapped_service->'module_master') AS module_mapped_service ")
					.append("  FROM service_map sm ")
					.append("  INNER JOIN service_map_details smd ON sm.service_map_id = smd.service_map_id AND sm.user_id = ? ")
					.append("  GROUP BY sm.service_map_id, sm.name, sm.description, module_code ")
					.append(") AS u_service_maps ")
					.append("GROUP BY service_map_id, name, description ");
			*/
					
			sbQuery	.append("SELECT ")
					.append("  sm_map_modules.service_map_id, sm_map_modules.name, ")
					.append("  '{'||string_agg(CONCAT('\"', sm_map_modules.module_code, '\":', sm_map_modules.mapped_modules), ',')||'}' AS mapped_service ")
					.append("FROM ( ")
					.append("  SELECT ")
					.append("    sm_modules.service_map_id, sm_modules.name, sm_modules.module_code, ")
					.append("    json_agg( row_to_json(( ")
					.append("      SELECT t FROM (SELECT uid, module_name, guid, test_id, testname, testtype, testurl) AS t(uid, module_name, guid, test_id, testname, testtype, testurl) ") 
					.append("      ) )) AS mapped_modules ")
					.append("  FROM ( ")
					.append("    SELECT sm.*, sum.testname, sum.testtype, sum.testurl, mm.module_name, mm.guid/*, COALESCE(mm.module_name, sum.testname)*/ ")
					.append("    FROM ( ")
					.append("      SELECT ")
					.append("        sm.service_map_id, sm.name, sm.description, ") 
					.append("        smd.mapped_service->'module_master'->>'module_code' AS module_code, ")
					.append("        CAST(smd.mapped_service->'module_master'->> (CASE smd.mapped_service->'module_master'->>'module_code' WHEN 'SUM' THEN 'test_id' ELSE 'uid' END) AS bigint) AS reference_id, ")
					.append("        smd.mapped_service->'module_master'->>'uid' AS uid, ")
					.append("        smd.mapped_service->'module_master'->>'test_id' AS test_id ")
					.append("      FROM service_map sm ")
					.append("      INNER JOIN service_map_details smd ON sm.service_map_id = smd.service_map_id AND sm.user_id = ? ")
					.append("    ) AS sm ")
					.append("    LEFT JOIN sum_test_master sum ON sum.test_id = sm.reference_id AND 1 = (CASE sm.module_code WHEN 'SUM' THEN 1 ELSE 0 END) ")
					.append("    LEFT JOIN module_master mm ON mm.uid = sm.reference_id AND 1 = (CASE WHEN (sm.module_code = 'APPLICATION' OR sm.module_code = 'SERVER' OR sm.module_code = 'DATABASE' OR sm.module_code = 'RUM') THEN 1 ELSE 0 END) ")
					.append("  ) AS sm_modules ")
					.append("  GROUP BY sm_modules.service_map_id, sm_modules.name, sm_modules.module_code ")
					.append(") AS sm_map_modules ")
					.append("GROUP BY service_map_id, name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, userId);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joObj = new JSONObject();
				joObj.put("service_map_id", rst.getString("service_map_id"));
				joObj.put("name", rst.getString("name"));
				//joObj.put("description", rst.getString("description"));
				//joObj.put("mapped_service", rst.getString("mapped_service"));
				joObj.put("mapped_service", JSONObject.fromObject( rst.getString("mapped_service") ));

				joArr.add(joObj);
			}
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joArr;
	}

	
	/**
	 * deletes all mapped module, say APPLICATION's <uid>, from service map(s)
	 * 
	 * @param con
	 * @param strModuleCode
	 * @param lReferenceId
	 * @throws Exception
	 */
	public void deleteMappedModuleReferences(Connection con, String strModuleCode, long lReferenceId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			/*
			// Note: In module_services "SUM"'s refs is not deleted, since to same methods, below condition is added for all modules to have as common
			if( ! strModuleCode.equals("SUM") ) {
				// for APM
				strModuleRefKey = "uid";
			} else {
				// for SUM
				strModuleRefKey = "test_id";
			}*/
			
			
			// Ask the query with JOIN, review
			// Note: for APM reference id as `uid`
			sbQuery	.append("DELETE FROM service_map_details smd ")
					.append("USING service_map sm ")
					.append("WHERE sm.service_map_id = smd.service_map_id ")
					.append("  AND sm.user_id = ? ")
					.append("  AND smd.mapped_service->'module_master'->>'module_code' = ? ");
			if (strModuleCode.equals(Constants.SUM_MODULE)) {
				sbQuery	.append("  AND CAST(smd.mapped_service->'module_master'->>'test_id' AS bigint) = ? ");
			} else {
				sbQuery	.append("  AND CAST(smd.mapped_service->'module_master'->>'uid' AS bigint) = ? ");
			}
			
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strModuleCode);
			pstmt.setLong(3, lReferenceId);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	
	public JSONArray getUserServiceMaps(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaUserServiceMaps = null;
		JSONObject joUserServiceMap = null;
		
		try {
			jaUserServiceMaps = new JSONArray();
			
			strQuery = "SELECT * FROM service_map WHERE user_id = ? ORDER BY name ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joUserServiceMap = new JSONObject();
				joUserServiceMap.put("serviceMapId", rst.getString("service_map_id"));
				joUserServiceMap.put("name", rst.getString("name"));
				joUserServiceMap.put("description", rst.getString("description"));
				
				jaUserServiceMaps.add(joUserServiceMap);
			}
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaUserServiceMaps;
	}
	
	/**
	 * gets mapped_modules/mapped_services for a particular ServiceMap's 
	 * 
	 * @param con
	 * @param lServiceMapId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getServiceMapMappedModules(Connection con, long lServiceMapId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strModuleCode = "";
		
		LinkedHashMap<String, ArrayList<JSONObject>> lhmServiceMapMappedModules = new LinkedHashMap<String, ArrayList<JSONObject>>();
		
		ArrayList<JSONObject> alModules = null;
		
		JSONObject joModule = null, joResult = new JSONObject();
		
		try {
			// TODO: need to verify qry
			
			sbQuery .append("SELECT smd.smd_id, ")
					.append("  smd.mapped_service->'module_master'->>'module_code' AS module_code, ") 
					.append("  CAST(smd.mapped_service->'module_master'->> (CASE smd.mapped_service->'module_master'->>'module_code' WHEN 'SUM' THEN 'test_id' ELSE 'uid' END) AS bigint) AS reference_id, ") 
					.append("  CAST(smd.mapped_service->'module_master'->>'uid' AS bigint) AS uid, ")
					.append("  CAST(smd.mapped_service->'module_master'->>'test_id' AS bigint) AS test_id, ")
					.append("  sum.testname, sum.testtype, sum.testurl, ")
					.append("  vmmv.module_name, vmmv.guid, vmmv.counter_type_name, vmmv.version ")
					.append("FROM service_map_details smd ")
					.append("LEFT JOIN sum_test_master sum ON sum.test_id = CAST(smd.mapped_service->'module_master'->>'test_id' AS bigint) ")
					.append("    AND smd.mapped_service->'module_master'->>'module_code' = 'SUM' ")
					.append("LEFT JOIN v_module_master_version vmmv ON vmmv.uid = CAST(smd.mapped_service->'module_master'->>'uid' AS bigint) ")
					.append("    AND smd.mapped_service->'module_master'->>'module_code' IN ('APPLICATION', 'SERVER', 'DATABASE', 'RUM') ") 
					.append("WHERE smd.service_map_id = ?  ")
					.append("ORDER BY module_code, COALESCE(module_name, testname) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lServiceMapId);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joModule = new JSONObject();
				
				strModuleCode = rst.getString("module_code");
				
				joModule.put("referenceId", rst.getLong("reference_id"));
				joModule.put("uid", rst.getLong("uid"));
				joModule.put("test_id", rst.getLong("test_id"));
				joModule.put("testname", rst.getString("testname"));
				joModule.put("testtype", rst.getString("testtype"));
				joModule.put("testurl", rst.getString("testurl"));
				joModule.put("module_name", rst.getString("module_name"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("type", rst.getString("counter_type_name"));
				joModule.put("version", rst.getString("version"));
				
				if ( lhmServiceMapMappedModules.containsKey(strModuleCode) ) {
					alModules = lhmServiceMapMappedModules.get(strModuleCode);
				} else {
					alModules = new ArrayList<JSONObject>();
				}
				alModules.add(joModule);
				lhmServiceMapMappedModules.put(strModuleCode, alModules);
				
				strModuleCode = null;
			}
			
			joResult.put("mapped_service", lhmServiceMapMappedModules);
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	/**
	 * gets service map's mapped module's, 
	 *   say APPLICATION's OR SERVER's OR ..., module's mapped `uid/test_id`s summaries
	 * 
	 * @param con
	 * @param lServiceMapId
	 * @param strModuleCode
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapMappedModuleSummaries(Connection con, long lServiceMapId, String strModuleCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaMappedModuleSummaries = null;
		JSONObject joMappedModuleSummary = null;
		
		try {
			jaMappedModuleSummaries = new JSONArray();
			
			strQuery = "SELECT * FROM get_service_map_mapped_module_summaries(?, ?, ?) ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lServiceMapId);
			pstmt.setString(3, strModuleCode);
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joMappedModuleSummary = new JSONObject();
				joMappedModuleSummary.put("referenceId", rst.getLong("reference_id"));
				joMappedModuleSummary.put("moduleName", rst.getString("module_name"));
				joMappedModuleSummary.put("totalSelectedCounters", rst.getLong("total_selected_counters"));
				
				jaMappedModuleSummaries.add(joMappedModuleSummary);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaMappedModuleSummaries;
	}
	
	/**
	 * gets Service Maps overall health
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapsHealth(Connection con, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "", strHealth = "";
		
		JSONArray jaServiceMapsHealth = null;
		JSONObject joServiceMapHealth = null;
		
		int i = 0;
		
		try {
			jaServiceMapsHealth = new JSONArray();
			
			strQuery = "SELECT * FROM get_service_maps_health(?, ?, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			if ( strInterval != null ) {
				pstmt.setString(2, strInterval);
				pstmt.setNull(3, Types.BIGINT);
				pstmt.setNull(4, Types.BIGINT);
			} else {
				pstmt.setNull(2, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(3, lStartDateTimeInMills / 1000);
				pstmt.setLong(4, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joServiceMapHealth = new JSONObject();
				
				// TODO: ASK, in add qry for health
				
				if ( rst.getLong("critical_cnt") > 0 ) {
					strHealth = "CRITICAL";
				} else if ( rst.getLong("warning_cnt") > 0 ) {
					strHealth = "WARNING";
				} else if ( rst.getLong("ok_cnt") > 0 ) {
					strHealth = "OK";
				} else if ( rst.getLong("inactive_cnt") > 0 ) {// else
					strHealth = "INACTIVE";
				}
				joServiceMapHealth.put("serviceMapId", rst.getLong("service_map_id"));
				joServiceMapHealth.put("serviceMapName", rst.getString("service_map_name"));
				joServiceMapHealth.put("health", strHealth);
				
				jaServiceMapsHealth.add(joServiceMapHealth);
				
				i = i + 1;
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaServiceMapsHealth;
	}
	
	public JSONArray getServiceMaps_v1(Connection con, long lEID, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaServiceMapsHealth = null;
		JSONObject joServiceMapHealth = null;
		try {
			jaServiceMapsHealth = new JSONArray();
			
			strQuery = "SELECT service_map_id, name FROM service_map where user_id = ? AND CASE WHEN ? = 0 THEN 1=1 OR is_system=true ELSE e_id = ? OR is_system=true END ORDER BY created_by, name";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lEID);
			pstmt.setLong(3, lEID);
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joServiceMapHealth = new JSONObject();
				joServiceMapHealth.put("serviceMapId", rst.getLong("service_map_id"));
				joServiceMapHealth.put("serviceMapName", rst.getString("name"));
				jaServiceMapsHealth.add(joServiceMapHealth);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
		}
		return jaServiceMapsHealth;
	}
	
	/**
	 * gets Service Map's mapped modules, module code wise health
	 * 
	 * @param con
	 * @param lServiceMapId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModuleCodeWiseHealth(Connection con, long lServiceMapId, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "", strModuleCode = "";
		
		//HashMap<String, JSONObject> hmMappedModuleCodesHealth = null;
		
		JSONObject joModuleCodesHealth = null, joModuleCodeHealth = null;
		
		try {
			//hmMappedModuleCodesHealth = new HashMap<String, JSONObject>();
			joModuleCodesHealth = new JSONObject();
			
			strQuery = "SELECT * FROM get_modules_wise_health(?, ?, ?, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lServiceMapId);
			if ( strInterval != null ) {
				pstmt.setString(3, strInterval);
				pstmt.setNull(4, Types.BIGINT);
				pstmt.setNull(5, Types.BIGINT);
			} else {
				pstmt.setNull(3, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(4, lStartDateTimeInMills / 1000);
				pstmt.setLong(5, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joModuleCodeHealth = new JSONObject();
				strModuleCode = rst.getString("module_code");
				
				joModuleCodeHealth.put("moduleCode", strModuleCode);
				joModuleCodeHealth.put("okCnt", rst.getLong("ok_cnt"));
				joModuleCodeHealth.put("warningCnt", rst.getString("warning_cnt"));
				joModuleCodeHealth.put("criticalCnt", rst.getString("critical_cnt"));
				joModuleCodeHealth.put("inactiveCnt", rst.getString("inactive_cnt"));
				joModuleCodeHealth.put("totalModuleMapped", rst.getString("total_module_mapped"));
				
				//hmMappedModuleCodesHealth.put(strModuleCode, joModuleCodeHealth);
				joModuleCodesHealth.put(strModuleCode, joModuleCodeHealth);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return joModuleCodesHealth;
	}
	
	/**
	 * gets Service Map's mapped modules, each module's selected counters statuses,
	 * with filter based on,
	 *   either given moduleCode (`APPLICATION`/`SERVER`/`DATABASE`) OR
	 *          given healCode (`WARNING`/`CRITICAL`) OR
	 *   with both moduleCode & healCode given, 
	 *   moduleCode & healCode given as `''` to get all mapped modules counters status
	 *   
	 * @param con
	 * @param lServiceMapId
	 * @param strModuleCode
	 * @param strHealthCode
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModulesCountersWiseHealth(Connection con, long lServiceMapId, String strModuleCode, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = ""; 
		
		JSONArray jaModulesCountersStatuses = null;
		JSONObject joModuleCountersStatus = null;
		
		try {
			jaModulesCountersStatuses = new JSONArray();
			
			strQuery = "SELECT * FROM get_counters_and_sum_health(?, ?, ?, ?, ?, ?, ?);";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lServiceMapId);
			pstmt.setString(3, strModuleCode);
			pstmt.setString(4, strHealthCode);
			if ( strInterval != null ) {
				pstmt.setString(5, strInterval);
				pstmt.setNull(6, Types.BIGINT);
				pstmt.setNull(7, Types.BIGINT);
			} else {
				pstmt.setNull(5, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(6, lStartDateTimeInMills / 1000);
				pstmt.setLong(7, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joModuleCountersStatus = new JSONObject();
				joModuleCountersStatus.put("referenceId", rst.getLong("reference_id"));
				joModuleCountersStatus.put("moduleCode", rst.getString("module_code"));
				joModuleCountersStatus.put("guid", rst.getString("guid"));
				joModuleCountersStatus.put("moduleName", rst.getString("module_name"));
				joModuleCountersStatus.put("okCnt", rst.getLong("ok_cnt"));
				joModuleCountersStatus.put("warningCnt", rst.getLong("warning_cnt"));
				joModuleCountersStatus.put("criticalCnt", rst.getLong("critical_cnt"));
				joModuleCountersStatus.put("inactiveCnt", rst.getLong("inactive_cnt"));
				joModuleCountersStatus.put("totalSelectedCounters", rst.getLong("total_selected_counters"));
				joModuleCountersStatus.put("status", rst.getString("status"));
				
				jaModulesCountersStatuses.add(joModuleCountersStatus);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaModulesCountersStatuses;
	}
	
	/**
	 * gets user's system generated Service Map 
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public long getUserSystemServiceMapId(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		long lServiceMapId = -1L;
		
		try {
			strQuery = "SELECT service_map_id FROM service_map WHERE user_id = ? AND is_system = TRUE ";
			
			pstmt = con.prepareStatement(strQuery, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				// Validation added, if query returns more than one row, (i.e. user can have only one system generated ServiceMap) 
				if ( rst.next() ) {
					// Exception to throw for Invalid system Service Map, when query returns more than one row
					throw new Exception("1");
				}
				rst.previous();
				
				lServiceMapId = rst.getLong("service_map_id");
			}
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return lServiceMapId;
	}
	
	/**
	 * gets module's selected counters OR module's breached counters based given healthCode (`WARNING/CRITICAL`)
	 * 
	 * @param con
	 * @param lUId
	 * @param strHealthCode
	 * @param strInterval
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleCounters(Connection con, long lEID, long lUserId, long lServiceMapId, long lUId, String strModuleCode, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaCounters = null;
		JSONObject joCounter = null;
		
		try {
			jaCounters = new JSONArray();
			
			strQuery = "SELECT * FROM get_module_counters(?,?, ?, ?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lEID);
			pstmt.setLong(2, lUserId);
			pstmt.setLong(3, lServiceMapId);
			pstmt.setLong(4, lUId);
			pstmt.setString(5, strModuleCode);
			pstmt.setString(6, strHealthCode);
			if ( strInterval != null ) {
				pstmt.setString(7, strInterval);
				pstmt.setNull(8, Types.BIGINT);
				pstmt.setNull(9, Types.BIGINT);
			} else {
				pstmt.setNull(7, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(8, lStartDateTimeInMills / 1000);
				pstmt.setLong(9, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joCounter = new JSONObject();
				joCounter.put("uid", rst.getLong("uid"));
				joCounter.put("moduleCode", rst.getString("module_code"));
				joCounter.put("guid", rst.getString("guid"));
				joCounter.put("moduleName", rst.getString("module_name"));
				joCounter.put("counterId", rst.getLong("counter_id"));
				joCounter.put("counterTemplateId", rst.getLong("counter_template_id"));
				joCounter.put("guid", rst.getString("guid"));
				joCounter.put("category", rst.getString("category"));
				joCounter.put("displayName", rst.getString("display_name"));
				joCounter.put("isAboveThreshold", rst.getBoolean("is_above_threshold"));
				joCounter.put("unit", rst.getString("unit"));
				joCounter.put("counterDescription", rst.getString("counter_description"));
				
				//joCounter.put("breachedSeverity", rst.getString("breached_severity"));
				jaCounters.add(joCounter);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaCounters;
	}
	
	// to get the counter ids of active counters (with value, without value)
	public JSONArray getActiveCounters_v1(Connection con, long lServiceMapId, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaCounters = null;
		JSONObject joCounter = null;
		
		try {
			jaCounters = new JSONArray();
			
			strQuery = "SELECT * FROM get_active_counters_v1(?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lServiceMapId);
			if ( strInterval != null ) {
				pstmt.setString(3, strInterval);
				pstmt.setNull(4, Types.BIGINT);
				pstmt.setNull(5, Types.BIGINT);
			} else {
				pstmt.setString(3, "");
				// converts into minutes
				pstmt.setLong(4, lStartDateTimeInMills / 1000);
				pstmt.setLong(5, lEndDateTimeInMills / 1000);
			}
			pstmt.setString(6, strHealthCode);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joCounter = new JSONObject();
				joCounter.put("uid", rst.getLong("uid"));
				joCounter.put("counterId", rst.getLong("counter_id"));
				joCounter.put("guid", rst.getString("guid"));
				joCounter.put("moduleCode", rst.getString("module_code"));
				joCounter.put("counterTemplateId", rst.getLong("counter_template_id"));
				joCounter.put("category", rst.getString("category"));
				joCounter.put("displayName", rst.getString("display_name"));
				joCounter.put("unit", rst.getString("unit"));
				
				//joCounter.put("breachedSeverity", rst.getString("breached_severity"));
				jaCounters.add(joCounter);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaCounters;
	}
	
	/**
	 * gets service map's mapped SUM tests
	 *   
	 * @param con
	 * @param lServiceMapId
	 * @param lTestId
	 * @param strHealthCode
	 * @param strInterval
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapSUMTests(Connection con, long lEID, long lUserId, long lServiceMapId, long lTestId, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";

		JSONArray jaTests = null;
		JSONObject joTest = null;
		
		try {
			jaTests = new JSONArray();
			
			// TODO get SUM test, based on breached severity 
			
			strQuery = "SELECT * FROM get_mapped_sum_tests(?, ?, ?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lEID);
			pstmt.setLong(2, lUserId);
			pstmt.setLong(3, lServiceMapId);
			pstmt.setLong(4, lTestId);
			pstmt.setString(5, strHealthCode);
			if ( strInterval != null ) {
				pstmt.setString(6, strInterval);
				pstmt.setNull(7, Types.BIGINT);
				pstmt.setNull(8, Types.BIGINT);
			} else {
				pstmt.setNull(6, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(7, lStartDateTimeInMills / 1000);
				pstmt.setLong(8, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joTest = new JSONObject();
				joTest.put("test_id", rst.getLong("test_id"));
				joTest.put("testname", rst.getString("testname"));
				joTest.put("testtype", rst.getString("testtype"));
				joTest.put("testurl", rst.getString("testurl"));
				joTest.put("status", rst.getBoolean("status"));
				
				jaTests.add(joTest);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaTests;
	}
	
	public JSONArray getServiceMapAllSUMTest(Connection con, long lUserId, Long lServiceMapId, String strInterval, Long lStartTime, Long lEndTime) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaTests = null;
		JSONObject joTest = null;
		
		
		try {
			jaTests = new JSONArray();
			
			sbQuery.append(" SELECT stm.test_id, stm.testname, stm.testtype, stm.testurl, stm.status FROM service_map_details smd ")
					.append(" INNER JOIN sum_test_master stm ON stm.test_id = CAST(smd.mapped_service->'module_master'->>'test_id' AS bigint) ")
					.append(" INNER JOIN sum_har_test_results sht ON sht.test_id = stm.test_id ")
					.append(" WHERE stm.user_id =").append(lUserId).append(" AND smd.service_map_id = ").append(lServiceMapId)
					.append(" AND smd.mapped_service->'module_master'->>'module_code' IN ('SUM') AND ");
			if (strInterval != null) {
				sbQuery.append(" sht.received_on BETWEEN now() - INTERVAL '").append(strInterval).append("' AND now() ");
			} else {
				sbQuery.append(" sht.received_on >= to_timestamp(").append(lStartTime/1000).append(") AND")
				.append(" sht.received_on < to_timestamp(").append(lEndTime/1000).append(") ");
			}
			sbQuery.append(" GROUP BY stm.test_id, stm.testname ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			
			while(rst.next()) {
				
				joTest = new JSONObject();
				joTest.put("test_id", rst.getLong("test_id"));
				joTest.put("testname", rst.getString("testname"));
				joTest.put("testtype", rst.getString("testtype"));
				joTest.put("testurl", rst.getString("testurl"));
				joTest.put("status", rst.getBoolean("status"));
				
				jaTests.add(joTest);
			}
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			sbQuery = null;
		}
		
		return jaTests;
	}
	
	/**
	 * gets service map's mapped, RUM module(s) OR all RUM (`WARNING`/`CRITICAL`) modules 
	 * 
	 * @param con
	 * @param lServiceMapId
	 * @param lUId
	 * @param strHealthCode
	 * @param strInterval
	 * @param lStartDateTimeInMills
	 * @param lEndDateTimeInMills
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapAllRUMSites(Connection con, long lServiceMapId, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";

		JSONArray jaModules = null;
		JSONObject joModule = null;
		
		try {
			jaModules = new JSONArray();
			
			strQuery = "SELECT * FROM get_service_map_all_RUM_details(?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lServiceMapId);
			if ( strInterval != null ) {
				pstmt.setString(3, strInterval);
				pstmt.setNull(4, Types.BIGINT);
				pstmt.setNull(5, Types.BIGINT);
			} else {
				pstmt.setString(3, "");
				// converts into minutes
				pstmt.setLong(4, lStartDateTimeInMills / 1000);
				pstmt.setLong(5, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joModule = new JSONObject();
				joModule.put("uid", rst.getLong("uid"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("moduleName", rst.getString("module_name"));
				
				jaModules.add(joModule);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaModules;
	}
	
	public JSONArray getServiceMapRUMSites(Connection con, long lEID, long lUserId,  long lServiceMapId, long lUId, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";

		JSONArray jaModules = null;
		JSONObject joModule = null;
		
		try {
			jaModules = new JSONArray();
			
			strQuery = "SELECT * FROM get_mapped_rum_sites(?, ?, ?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lEID);
			pstmt.setLong(2, lUserId);
			pstmt.setLong(3, lServiceMapId);
			pstmt.setLong(4, lUId);
			pstmt.setString(5, strHealthCode);
			if ( strInterval != null ) {
				pstmt.setString(6, strInterval);
				pstmt.setNull(7, Types.BIGINT);
				pstmt.setNull(8, Types.BIGINT);
			} else {
				pstmt.setNull(6, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(7, lStartDateTimeInMills / 1000);
				pstmt.setLong(8, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joModule = new JSONObject();
				joModule.put("uid", rst.getLong("uid"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("moduleName", rst.getString("module_name"));
				
				jaModules.add(joModule);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaModules;
	}
	
	public JSONArray getLogCounters(Connection con, long lServiceMapId, long lUserId, String strInterval, Long lStartTime, Long lEndTime, String strHealthCode) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";

		JSONArray jaModules = null;
		JSONObject joModule = null;
		
		try {
			jaModules = new JSONArray();
			
			strQuery = "SELECT * FROM get_active_log_count(?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lServiceMapId);
			if (strInterval != null) {
				pstmt.setString(3, strInterval);
				pstmt.setNull(4, Types.BIGINT);
				pstmt.setNull(5, Types.BIGINT);
			} else {
				pstmt.setString(3, "");
				pstmt.setLong(4, lStartTime/1000);
				pstmt.setLong(5, lEndTime/1000);
			}
			pstmt.setString(6, strHealthCode);
			
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joModule = new JSONObject();
				joModule.put("uid", rst.getLong("uid"));
				joModule.put("guid", rst.getString("guid"));
				joModule.put("moduleName", rst.getString("module_code"));
				joModule.put("logType", rst.getString("type"));
				joModule.put("logTableId", rst.getString("log_table_id"));
				joModule.put("logTableName", rst.getString("log_table_name"));
				
				jaModules.add(joModule);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaModules;
	}
}
