package com.appedo.module.dbi;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/*import com.appedo.avm.bean.AVMAgentAlertAddressBean;
import com.appedo.avm.bean.AVMAgentBean;
import com.appedo.avm.bean.AVMTestBean;
import com.appedo.avm.common.Constants.SUM_TYPE;
import com.appedo.avm.connect.DataBaseManager;
import com.appedo.avm.utils.UtilsFactory;*/
import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.AVMAgentAlertAddressBean;
import com.appedo.module.bean.AVMAgentBean;
import com.appedo.module.bean.AVMTestBean;
import com.appedo.module.common.Constants.SUM_TYPE;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;


public class AVMDBI {
	
	/**
	 *  Retrieves the AVM test for card layout for a particular user
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getAVMTests(Connection con, LoginUserBean loginUserBean, AVMTestBean testBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strStartDate = "", strEndDate = "";
		
		Timestamp tsStartDate = null, tsEndDate = null;
		
		boolean bTestStatus = false;
		
		JSONArray jaAVMTests = new JSONArray();
		JSONObject joAVMTest = null;
		
		try {
			/*sbQuery	.append("SELECT atm.avm_test_id, atm.testname, atm.testurl, atm.request_method, atm.test_head_method_first, atm.request_headers, atm.request_parameters, ")
					.append("atm.frequency, atm.is_active, atm.min_breach_count, atm.sla_id, ")
					.append("atm.modified_on, atm.created_on, to_timestamp(start_date/1000) as start_date, to_timestamp(end_date/1000) as end_date, ")
					.append("CASE WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date < get_now_epoch_ms()) THEN 'Completed' ")
					.append("WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date > get_now_epoch_ms()) THEN 'Running' ")
					.append("ELSE 'Scheduled' ")
					//.append("END AS teststatus, start_time, end_time, timezone_offset, count(*) as mapped_locations ")
					.append("END AS teststatus, COALESCE(extract('epoch' FROM start_time)*1000, -1) as start_time, COALESCE(extract('epoch' FROM end_time)*1000, -1) as end_time, count(*) as mapped_locations ")
					.append("FROM avm_test_master atm ")
					.append("INNER JOIN avm_test_agent_mapping atam on atm.avm_test_id = atam.avm_test_id AND user_id = ? GROUP BY atm.avm_test_id");
*/
			sbQuery	.append("SELECT atm.avm_test_id, atm.testname, atm.testurl, atm.request_method, atm.test_head_method_first, atm.request_headers, atm.request_parameters, ")
					.append("atm.frequency, atm.is_active, atm.min_breach_count, atm.sla_id, ")
					.append("atm.modified_on, atm.created_on, to_timestamp(start_date/1000) as start_date, to_timestamp(end_date/1000) as end_date, ")
					.append("CASE WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date < get_now_epoch_ms()) THEN 'Completed' ")
					.append("WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date > get_now_epoch_ms()) THEN 'Running' ")
					.append("ELSE 'Scheduled' ")
					//.append("END AS teststatus, start_time, end_time, timezone_offset, count(*) as mapped_locations ")
					.append("END AS teststatus, COALESCE(extract('epoch' FROM start_time)*1000, -1) as start_time, COALESCE(extract('epoch' FROM end_time)*1000, -1) as end_time ")
					.append("FROM avm_test_master atm WHERE atm.avm_test_id = ?");
					
			
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setLong(1, testBean.getTestId());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joAVMTest = new JSONObject();
				
				bTestStatus = rst.getBoolean("is_active");
				
				joAVMTest.put("testid", rst.getString("avm_test_id"));
				joAVMTest.put("testname", rst.getString("testname"));
				joAVMTest.put("testurl", rst.getString("testurl"));
				joAVMTest.put("requestMethod", rst.getString("request_method"));
				joAVMTest.put("testHeadMethodFirst", rst.getBoolean("test_head_method_first"));
				joAVMTest.put("requestHeaders", rst.getString("request_headers"));
				joAVMTest.put("requestParameters", rst.getString("request_parameters"));
				joAVMTest.put("frequency", rst.getString("frequency"));
				joAVMTest.put("originalstatus", bTestStatus);
				joAVMTest.put("am_minbreachcount", rst.getInt("min_breach_count"));
				joAVMTest.put("amSlaId", rst.getLong("sla_id"));
				joAVMTest.put("modifiedOn", ((Timestamp) UtilsFactory.replaceNull(rst.getTimestamp("modified_on"), rst.getTimestamp("created_on"))).getTime());
				joAVMTest.put("createdOn", ((Timestamp) rst.getTimestamp("created_on")).getTime());
				
				tsStartDate = rst.getTimestamp("start_date");
				strStartDate = tsStartDate.toString();
				strStartDate = strStartDate.replace(" ", "T");
				strStartDate = strStartDate + "00Z";
				joAVMTest.put("startdate", strStartDate);

				tsEndDate = rst.getTimestamp("end_date");
				strEndDate = tsEndDate.toString();
				strEndDate = strEndDate.replace(" ", "T");
				strEndDate = strEndDate + "00Z";
				joAVMTest.put("enddate", strEndDate);
				
				if ( ! bTestStatus ) {
					// For Test status Disabled, to show as `Disabled`
					joAVMTest.put("status", "Disabled");
				} else {
					joAVMTest.put("status", rst.getString("teststatus"));
				}

//				joAVMTest.put("startTimeInMinutes", UtilsFactory.parseTimeToMinutes(rst.getString("start_time")));
//				joAVMTest.put("endTimeInMinutes", UtilsFactory.parseTimeToMinutes(rst.getString("end_time")));
				joAVMTest.put("startTimeInMinutes", rst.getInt("start_time"));
				joAVMTest.put("endTimeInMinutes", rst.getInt("end_time"));

				//joAVMTest.put("mapped_locations", rst.getInt("mapped_locations"));
				jaAVMTests.add(joAVMTest);

				//joAVMTest = null;
				//strStartDate = null;
				//strEndDate = null;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

		}
		
		//return jaAVMTests;
		return joAVMTest;
	}
	
	/**
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	
	public JSONArray getAVMTests_v1(Connection con, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strStartDate = "", strEndDate = "";
		
		Timestamp tsStartDate = null, tsEndDate = null;
		
		boolean bTestStatus = false;
		
		JSONArray jaAVMTests = new JSONArray();
		JSONObject joAVMTest = null;
		
		JSONObject joVariable = null;
		JSONObject joCol_Value = null;
		
		try {
			/*sbQuery	.append("SELECT atm.avm_test_id, atm.testname, atm.testurl, atm.request_method, atm.test_head_method_first, ")
					.append("atm.request_headers, atm.request_parameters, atm.frequency, atm.is_active, atm.min_breach_count, atm.sla_id, ")
					.append("atm.modified_on, atm.created_on, to_timestamp(start_date/1000) as start_date, to_timestamp(end_date/1000) as end_date, ")
					.append("CASE WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date < get_now_epoch_ms()) THEN 'Completed' ")
					.append("WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date > get_now_epoch_ms()) THEN 'Running' ")
					.append("ELSE 'Scheduled' END AS teststatus, COALESCE(extract('epoch' FROM start_time)*1000, -1) as start_time, ")
					//.append("END AS teststatus, start_time, end_time, timezone_offset, count(*) as mapped_locations ")
					.append("COALESCE(extract('epoch' FROM end_time)*1000, -1) as end_time, count(*) as mapped_locations ")
					.append("FROM avm_test_master atm INNER JOIN avm_test_agent_mapping atam on atm.avm_test_id = atam.avm_test_id ")
					.append("AND user_id = ? GROUP BY atm.avm_test_id ORDER BY atm.testname");*/
			
			//Enterprise License implemented
			sbQuery	.append("SELECT atm.avm_test_id, atm.testname, atm.testurl, atm.request_method, atm.test_head_method_first, ")
					.append("atm.request_headers, atm.request_parameters, atm.frequency, atm.is_active, atm.min_breach_count, atm.sla_id, ")
					.append("atm.modified_on, atm.created_on, to_timestamp(start_date/1000) as start_date, to_timestamp(end_date/1000) as end_date, ")
					.append("CASE WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date < get_now_epoch_ms()) THEN 'Completed' ")
					.append("WHEN (atm.start_date < get_now_epoch_ms() AND atm.end_date > get_now_epoch_ms()) THEN 'Running' ELSE 'Scheduled' ")
					.append("END AS teststatus, COALESCE(extract('epoch' FROM start_time)*1000, -1) as start_time, ")
					.append("COALESCE(extract('epoch' FROM end_time)*1000, -1) as end_time, count(*) as mapped_locations ")
					.append("FROM avm_test_master atm INNER JOIN avm_test_agent_mapping atam on atm.avm_test_id = atam.avm_test_id AND user_id = ? ");
					if(joEnterprise.getInt("e_id")!=0){
						sbQuery	.append("AND e_id = ").append(joEnterprise.getInt("e_id")+" ");
					}
			sbQuery	.append("GROUP BY atm.avm_test_id ORDER BY atm.testname");
			
			
			pstmt = con.prepareStatement(sbQuery.toString());
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, loginUserBean.getUserId());
			}
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joAVMTest = new JSONObject();
				
				bTestStatus = rst.getBoolean("is_active");

				
				//new UI Data's
				joVariable = new JSONObject();
				joCol_Value = new JSONObject();
				
				joVariable.put("var1", "is_delete");
				joVariable.put("var2", "is_edit");
				joVariable.put("var3", "");
				joVariable.put("var4", "AVAILABILITY");
				joCol_Value.put("col_1", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", rst.getString("testname"));
				joVariable.put("var2", "Added On : "); 
				joVariable.put("var21", rst.getTimestamp("created_on").getTime());
				joCol_Value.put("col_2", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "URL: "+ rst.getString("testurl"));
				joVariable.put("var2", "Run Duration: " + rst.getDate("start_date") + " to " + rst.getDate("end_date"));
				joCol_Value.put("col_3", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Run Every");
				joVariable.put("var2", rst.getString("frequency"));
				joCol_Value.put("col_4", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Location");
				joVariable.put("var2", rst.getInt("mapped_locations"));
				joCol_Value.put("col_5", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);

				joVariable.put("var1", "STATUS_Live");
				if ( ! bTestStatus ) {
					joVariable.put("var2", "Disabled");
				}else {
					joVariable.put("var2", rst.getString("teststatus"));
				}
				joCol_Value.put("col_6", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Mon_Availablity");
				joVariable.put("var2", "Down In");
				/*joVariable.put("var3", "");
				joVariable.put("var4", "");*/
				joCol_Value.put("col_7", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "chart_icon");
				joCol_Value.put("col_8", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				tsStartDate = rst.getTimestamp("start_date");
				strStartDate = tsStartDate.toString();
				strStartDate = strStartDate.replace(" ", "T");
				strStartDate = strStartDate + "00Z";
				joCol_Value.put("startdate", strStartDate);

				tsEndDate = rst.getTimestamp("end_date");
				strEndDate = tsEndDate.toString();
				strEndDate = strEndDate.replace(" ", "T");
				strEndDate = strEndDate + "00Z";
				joCol_Value.put("enddate", strEndDate);
				
				joCol_Value.put("testid", rst.getString("avm_test_id"));

				jaAVMTests.add(joCol_Value);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

		}
		
		return jaAVMTests;
	}
	
	/**
	 * 
	 * @param con
	 * @param lTestId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAVMAgents(Connection con, long lTestId, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		LinkedHashMap<String, ArrayList<JSONObject>> lhmNodes = new LinkedHashMap<String, ArrayList<JSONObject>>();
		ArrayList<JSONObject> alCities = null;

		JSONArray jaNodes = new JSONArray();
		JSONObject joNode = null, joCity = null;

		String strCountry = "", strState = "", strCity = "", strRegion = "", strZone = "";
		
		try {
			// To get cities for availability
			
			sbQuery.append("SELECT * FROM get_avm_nodes_with_location_status_sample(?, ?) ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lTestId);
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(2, joEnterprise.getLong("e_user_id"));
			}else{
				pstmt.setLong(2, lUserId);
			}
			rst = pstmt.executeQuery();
			while(rst.next()) {
				strCountry = rst.getString("country");
				strState = rst.getString("state");
				strCity = rst.getString("city");
				strRegion = rst.getString("region");
				strZone = rst.getString("zone");

				joCity = new JSONObject();
				joCity.put("state", strState);
				joCity.put("city", strCity);
				joCity.put("region", strRegion);
				joCity.put("zone", strZone);
				joCity.put("zone", strZone);
				joCity.put("location", rst.getString("location"));
				joCity.put("isSelected", rst.getBoolean("is_selected"));
				joCity.put("canAgentAcceptTest", rst.getBoolean("can_agent_accept_test"));
				joCity.put("totalAgents", rst.getLong("total_agents"));
				
				if ( lhmNodes.containsKey(strCountry) ) {
					alCities = lhmNodes.get(strCountry);
				} else {
					alCities = new ArrayList<JSONObject>();
					lhmNodes.put(strCountry, alCities);
				}
				
				alCities.add(joCity);
			}
			
			Iterator<Map.Entry<String,ArrayList<JSONObject>>> itNodes = lhmNodes.entrySet().iterator();
			while (itNodes.hasNext()) {
				Map.Entry<String, ArrayList<JSONObject>> pair = itNodes.next();
				strCountry = pair.getKey();
				alCities = pair.getValue();
				
				joNode = new JSONObject();
				joNode.put("country", strCountry);
				joNode.put("cities", alCities);
				jaNodes.add(joNode);
				
				itNodes.remove();
			}
			
			strCountry = null;
			strState = null;
			strCity = null;
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return jaNodes;
	}
	
	/**
	 * 
	 * @param con
	 * @param strAVMTestName
	 * @param lTestId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isAVMTestExist(Connection con, String strAVMTestName, long lTestId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bExists = false;
		String strQuery = "";
		try {
			strQuery = "SELECT EXISTS(SELECT 1 FROM avm_test_master WHERE lower(testname) = lower(?) AND avm_test_id != ? AND user_id = ? LIMIT 1) as test_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strAVMTestName);
			pstmt.setLong(2, lTestId);
			pstmt.setLong(3, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if (rst.next()) {
				bExists = rst.getBoolean("test_exists");
			}
			strQuery = null;
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return bExists;
	}
	
	/**
	 *  Adds the Availability test
	 *  
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long addAVMTest(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		long lTestId = -1l;
		
		try {
			sbQuery.append("INSERT INTO avm_test_master (user_id, testname, testurl, request_method, test_head_method_first, request_headers, request_parameters, start_date, end_date,")
					.append(" is_active, frequency, min_breach_count, created_by, created_on, selected_days, start_time, end_time, e_id)")
					.append(" VALUES (?, ?, ?, ?, ?, ?::JSON, ?::JSON, ?, ?, ?, ?, ?, ?, now(), ?::JSON, ?::TIME + ?::INTERVAL, ?::TIME + ?::INTERVAL, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, testBean.getTestName());
			pstmt.setString(3, testBean.getURL());
			pstmt.setString(4, testBean.getRequestMethod());
			pstmt.setBoolean(5, testBean.isTestHeadMethodFirst());
			pstmt.setString(6, testBean.getRequestHeaders().toString());
			pstmt.setString(7, testBean.getRequestParameters().toString());
			pstmt.setLong(8, UtilsFactory.toDate(testBean.getStartDate(), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").getTime());
			pstmt.setLong(9, UtilsFactory.toDate(testBean.getEndDate(), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").getTime());
			
			pstmt.setBoolean(10, testBean.isStatus());
			pstmt.setInt(11, testBean.getRunEveryMinute());
			pstmt.setInt(12, testBean.getAvmMinBreachCount());
			pstmt.setLong(13, loginUserBean.getUserId());
			pstmt.setString(14, testBean.getJoDays().toString());
			if (testBean.getStartTime() != null) {
				pstmt.setString(15, testBean.getStartTime());
				pstmt.setString(16, testBean.getTimezone_offset() + " minutes"); // offset in minutes
			} else {
				pstmt.setNull(15, Types.TIME);
				pstmt.setNull(16, Types.TIME);
			}
			
			if (testBean.getEndTime() != null) {
				pstmt.setString(17, testBean.getEndTime());
				pstmt.setString(18, testBean.getTimezone_offset() + " minutes"); // offset in minutes
			} else {
				pstmt.setNull(17, Types.TIME);
				pstmt.setNull(18, Types.TIME);
			}
			if(joEnterprise.getBoolean("is_owner") && joEnterprise.getInt("e_id") != 0){
				pstmt.setInt(19, joEnterprise.getInt("e_id"));
			}else{
				pstmt.setNull(19, java.sql.Types.INTEGER);
			}
			
			pstmt.executeUpdate();
			
			lTestId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lTestId;
	}
	
	/**
	 *  Updates the availability test's details
	 *  
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public void updateAVMTest(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();

		try {
			
			sbQuery	.append("update avm_test_master set testname = ?, testurl = ?, request_method = ?, test_head_method_first = ?, request_headers = ?::json, request_parameters = ?::json, ")
					.append("start_date = ?, end_date = ?, start_time = ?::TIME + ?::INTERVAL, end_time = ?::TIME + ?::INTERVAL, ")
					.append("is_active = ?, frequency = ?, min_breach_count = ?, modified_by = ?, modified_on = now() ")
					.append("WHERE avm_test_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, testBean.getTestName());
			pstmt.setString(2, testBean.getURL());
			pstmt.setString(3, testBean.getRequestMethod());
			pstmt.setBoolean(4, testBean.isTestHeadMethodFirst());
			pstmt.setString(5, testBean.getRequestHeaders().toString());
			pstmt.setString(6, testBean.getRequestParameters().toString());
			pstmt.setLong(7, UtilsFactory.toDate(testBean.getStartDate(), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").getTime());
			pstmt.setLong(8, UtilsFactory.toDate(testBean.getEndDate(), "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").getTime());
			
			if (testBean.getStartTime() != null) {
				pstmt.setString(9, testBean.getStartTime());
				pstmt.setString(10, testBean.getTimezone_offset() + " minutes"); // offset in minutes
			} else {
				pstmt.setNull(9, Types.TIME);
				pstmt.setNull(10, Types.TIME);
			}
			
			if (testBean.getEndTime() != null) {
				pstmt.setString(11, testBean.getEndTime());
				pstmt.setString(12, testBean.getTimezone_offset() + " minutes"); // offset in minutes
			} else {
				pstmt.setNull(11, Types.TIME);
				pstmt.setNull(12, Types.TIME);
			}
			pstmt.setBoolean(13, testBean.isStatus());
			pstmt.setInt(14, testBean.getRunEveryMinute());
			pstmt.setInt(15, testBean.getAvmMinBreachCount());
			pstmt.setLong(16, loginUserBean.getUserId());
			pstmt.setLong(17, testBean.getTestId());
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * 
	 * @param con
	 * @param lTestId
	 * @param hsClusters
	 * @throws Exception
	 */
	public void addAvmAgentMapping(Connection con, long lTestId, HashSet<JSONObject> hsClusters) throws Exception {
		PreparedStatement pstmt = null;
		JSONObject joLocation = null;
		StringBuilder sbQuery = new StringBuilder();

		try {

			sbQuery.append("INSERT INTO avm_test_agent_mapping(avm_test_id, country, state, city, region, zone) values(?, ? ,?, ?, ?, ?)");
			pstmt = con.prepareStatement(sbQuery.toString());

			Iterator<JSONObject> iter = hsClusters.iterator();
			while (iter.hasNext()) {
				joLocation = iter.next();

				pstmt.setInt(1, (int) lTestId);
				pstmt.setString(2, joLocation.getString("country"));
				pstmt.setString(3, joLocation.getString("state"));
				pstmt.setString(4, joLocation.getString("city"));
				pstmt.setString(5, joLocation.getString("region"));
				pstmt.setString(6, joLocation.getString("zone"));

				pstmt.addBatch();
				joLocation = null;
			}

			int res[] = pstmt.executeBatch();
			LogManager.infoLog(Arrays.toString(res));
		} catch (Exception e) {
			e.printStackTrace();
			LogManager.errorLog(e);

			if (e instanceof SQLException) {
				SQLException sqlExcpNext = null;
				while ((sqlExcpNext = ((SQLException) e).getNextException()) != null) {
					LogManager.errorLog(sqlExcpNext);
				}
				sqlExcpNext = null;
			}

			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

	}
	
	/**
	 * Updates the AVM test's AgentMapping
	 * 
	 * @param con
	 * @param lTestId
	 * @param hsClusters
	 * @throws Exception
	 */
	public void deleteAvmAgentMapping(Connection con, long lTestId) throws Exception {
		PreparedStatement pstmt = null, pstmtMapping = null;
		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery.append("DELETE FROM avm_test_agent_mapping WHERE avm_test_id = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lTestId);
			pstmt.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
			LogManager.errorLog(e);

			if (e instanceof SQLException) {
				SQLException sqlExcpNext = null;
				while ((sqlExcpNext = ((SQLException) e).getNextException()) != null) {
					LogManager.errorLog(sqlExcpNext);
				}
				sqlExcpNext = null;
			}

			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtMapping);
			pstmtMapping = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @param sumType
	 * @throws Exception
	 */
	public void updateSlaIdInAVMTestMaster(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean, SUM_TYPE sumType) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try {

			sbQuery.append("UPDATE avm_test_master SET sla_id = ? WHERE avm_test_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, testBean.getAmSLAId());
			pstmt.setLong(2, testBean.getTestId());
			pstmt.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * Delete the test details from `avm_test_master` and `sum_heartbeat_log_<UserID>`
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteAVMTest(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmtLog = null; 

		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery.append("DELETE FROM avm_test_master WHERE avm_test_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, testBean.getTestId());
			pstmt.executeUpdate();

			sbQuery.setLength(0);
			sbQuery.append("DELETE FROM sum_heartbeat_log_")
					.append(loginUserBean.getUserId())
					.append(" WHERE sum_test_id = ?");
			pstmtLog = con.prepareStatement(sbQuery.toString());
			pstmtLog.setLong(1, testBean.getTestId());
			pstmtLog.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtLog);
			pstmtLog = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}

	/**
	 * gets user's availability monitor summary
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getAVMUserDashboardSummary(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONObject joAVMUserSummary = null;
		
		try {
			strQuery = "SELECT * FROM get_avm_user_summary(?) ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				joAVMUserSummary = new JSONObject();
				joAVMUserSummary.put("totalPvtMonitoringLocations", rst.getLong("total_pvt_monitoring_locations"));
				joAVMUserSummary.put("totalActiveLocations", rst.getLong("total_active_locations"));
				joAVMUserSummary.put("totalInactiveLocations", rst.getLong("total_inactive_locations"));
				joAVMUserSummary.put("totalMonitoringApps", rst.getLong("total_monitoring_apps"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return joAVMUserSummary;
	}
	
	/**
	 * gets user's down locations status,
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserDownLocationsStatus(Connection con, long lUserId, long lLimit, long lOffSet) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONObject joDownLocation = null;
		JSONArray jaDownLocationsStatus = null;
		
		try {
			jaDownLocationsStatus = new JSONArray();
			
			strQuery = "SELECT * FROM get_avm_locations_status(?, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lLimit);
			pstmt.setLong(3, lOffSet);
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joDownLocation = new JSONObject();
				joDownLocation.put("country", rst.getString("country"));
				joDownLocation.put("state", rst.getString("state"));
				joDownLocation.put("city", rst.getString("city"));
				joDownLocation.put("region", rst.getString("region"));
				joDownLocation.put("zone", rst.getString("zone"));
				joDownLocation.put("locationText", rst.getString("location_text"));
				joDownLocation.put("last_responded_on", rst.getLong("last_responded_on"));
				joDownLocation.put("last_seen_since", rst.getLong("last_seen_since"));
				joDownLocation.put("status", rst.getString("status"));
				joDownLocation.put("statusText", rst.getString("status_text"));
				joDownLocation.put("urlStatus", rst.getString("url_status"));
				
				jaDownLocationsStatus.add(joDownLocation);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaDownLocationsStatus;
	}
	
	/**
	 * gets user's down locations status,
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUrlDownLocationsStatus(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joDownLocation = null;
		JSONArray jaDownLocationsStatus = null;
		
		try {
			jaDownLocationsStatus = new JSONArray();
			
			sbQuery	.append("select agent_id , count(sum_test_id) as down_url from ")
					.append("(SELECT agent_id, sum_test_id FROM sum_heartbeat_log_").append(lUserId).append(" ")
					.append("WHERE availability = false AND appedo_received_on > (get_now_epoch_ms() - 3600000 /*1 hour*/) ")
					.append("group by agent_id , sum_test_id) AS au group by au.agent_id ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joDownLocation = new JSONObject();
				joDownLocation.put("agent_id", rst.getString("agent_id"));
				joDownLocation.put("url_Down", rst.getString("down_url"));
				jaDownLocationsStatus.add(joDownLocation);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			sbQuery = null;
		}
		
		return jaDownLocationsStatus;
	}
	
	/**
	 * gets user's applications status 
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserApplicationsStatus(Connection con, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONObject joApplicationStatus = null;
		JSONArray jaApplicationsStatus = new JSONArray();
		
		try {
			//strQuery = "SELECT * FROM get_avm_applications_status(?)";
			strQuery = "SELECT * FROM get_avm_applications_status_v1(?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, lUserId);
			}
			pstmt.setLong(2, joEnterprise.getInt("e_id"));
			//pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joApplicationStatus = new JSONObject();
				
				joApplicationStatus.put("avmTestId", rst.getLong("avm_test_id"));
				joApplicationStatus.put("testName", rst.getString("testname"));
				joApplicationStatus.put("testURL", rst.getString("testurl"));
				joApplicationStatus.put("mappedLocationCnt", rst.getLong("mapped_location_cnt"));
				joApplicationStatus.put("mappedAgentCnt", rst.getLong("mapped_agent_cnt"));
				joApplicationStatus.put("downLocationCnt", rst.getLong("inactive_location_cnt"));
				joApplicationStatus.put("downAgentCnt", rst.getLong("inactive_agent_cnt"));
				joApplicationStatus.put("downLocations", rst.getString("inactive_locations"));
				joApplicationStatus.put("status", rst.getString("status"));
				joApplicationStatus.put("severity", rst.getString("severity"));
				
				jaApplicationsStatus.add(joApplicationStatus);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaApplicationsStatus;
	}
	
	/**
	 * inserts user's AVM agent location 
	 * 
	 * @param con
	 * @param avmAgentBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long insertAVMAgent(Connection con, AVMAgentBean avmAgentBean, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lAgentId = -1L;
		
		try {
			sbQuery	.append("INSERT INTO avm_agent_master (e_id, user_id, is_private, mac_address, ip_address, country, state, city, region, zone, ")
					.append("  latitude, longitude, os_type, operating_system, os_version, remarks, agent_version, status,")
					/*last_requested_on, last_received_url_cnt, last_responded_on, last_error_on,*/
					.append("  created_by, created_on, guid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now(), ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			/*pstmt.setLong(1, -1L);*/	//loginUserBean.getEnterpriseId()
			if( joEnterprise != null && joEnterprise.containsKey("is_owner") && joEnterprise.getBoolean("is_owner") && joEnterprise.getInt("e_id") != 0){
				pstmt.setInt(1, joEnterprise.getInt("e_id"));
			}else{
				pstmt.setNull(1, java.sql.Types.INTEGER);
			}
			pstmt.setLong(2, lUserId);
			pstmt.setBoolean(3, avmAgentBean.isPrivate());
			pstmt.setString(4, avmAgentBean.getMACAddress());
			pstmt.setString(5, avmAgentBean.getIPAddress());
			pstmt.setString(6, avmAgentBean.getCountry());
			pstmt.setString(7, avmAgentBean.getState());
			pstmt.setString(8, avmAgentBean.getCity());
			pstmt.setString(9, avmAgentBean.getRegion());
			pstmt.setString(10, avmAgentBean.getZone());
			if ( avmAgentBean.getLatitude() == null ) {
				pstmt.setNull(11, Types.INTEGER);
			} else {
				pstmt.setInt(11, avmAgentBean.getLatitude());
			}
			if ( avmAgentBean.getLongitude() == null ) {
				pstmt.setNull(12, Types.INTEGER);
			} else {
				pstmt.setInt(12, avmAgentBean.getLongitude());
			}
			pstmt.setString(13, avmAgentBean.getOSType());
			pstmt.setString(14, avmAgentBean.getOperatingSystem());
			pstmt.setString(15, avmAgentBean.getOSVersion());
			pstmt.setString(16, avmAgentBean.getRemarks());
			pstmt.setString(17, avmAgentBean.getAgentVersion());
			pstmt.setString(18, avmAgentBean.getStatus());
			pstmt.setLong(19, lUserId);
			pstmt.setString(20, avmAgentBean.getGUID());
			
			pstmt.executeUpdate();
			
			lAgentId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lAgentId;
	}
	
	/**
	 * update's user's AVM agent location 
	 * 
	 * @param con
	 * @param avmAgentBean
	 * @param lUserId
	 * @throws Exception
	 */
	public void updateAgentLocation(Connection con, AVMAgentBean avmAgentBean, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE avm_agent_master SET ")
					.append("  country = ?, state = ?, city = ?, region = ?, zone = ?, ")
					.append("  modified_by = ?, modified_on = now() ")
					.append("WHERE agent_id = ? AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, avmAgentBean.getCountry());
			pstmt.setString(2, avmAgentBean.getState());
			pstmt.setString(3, avmAgentBean.getCity());
			pstmt.setString(4, avmAgentBean.getRegion());
			pstmt.setString(5, avmAgentBean.getZone());
			pstmt.setLong(6, lUserId);
			pstmt.setLong(7, avmAgentBean.getAgentId());
			pstmt.setLong(8, lUserId);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * gets user's locations
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserLocations(Connection con, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaLocations = null;
		JSONObject joLocation = null;
		JSONObject joVariable = null;
		JSONObject joCol_Value = null;
		
		try {
			jaLocations = new JSONArray();
			
			//new UI Data's
			joVariable = new JSONObject();
			joCol_Value = new JSONObject();
			
			/*strQuery = "SELECT * FROM get_avm_user_locations(?) ORDER BY location_text";*/
			
			strQuery = "SELECT * FROM get_avm_user_locations_test(?, ?) ORDER BY location_text";
			
			pstmt = con.prepareStatement(strQuery);
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, lUserId);
			}
			pstmt.setLong(2, joEnterprise.getInt("e_id"));
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				/* joLocation = new JSONObject();
				joLocation.put("agentId", rst.getLong("agent_id"));
				joLocation.put("isPrivate", rst.getBoolean("is_private"));
				joLocation.put("macAddress", rst.getString("mac_address"));
				joLocation.put("ipAddress", rst.getString("ip_address"));
				joLocation.put("country", rst.getString("country"));
				joLocation.put("state", rst.getString("state"));
				joLocation.put("city", rst.getString("city"));
				joLocation.put("region", rst.getString("region"));
				joLocation.put("zone", rst.getString("zone"));
				joLocation.put("locationText", rst.getString("location_text"));
				joLocation.put("latitude", rst.getInt("latitude"));
				joLocation.put("longitude", rst.getInt("longitude"));
				joLocation.put("osType", rst.getString("os_type"));
				joLocation.put("operatingSystem", rst.getString("operating_system"));
				joLocation.put("osVersion", rst.getString("os_version"));
				joLocation.put("status", rst.getString("status"));
				joLocation.put("statusText", rst.getString("status_text"));
				joLocation.put("lastRequestedOn", rst.getString("last_requested_on"));
				joLocation.put("lastReceivedUrlCnt", rst.getString("last_received_url_cnt"));
				joLocation.put("lastRespondedOn", rst.getString("last_responded_on"));
				joLocation.put("lastErrorOn", rst.getString("last_error_on"));
				joLocation.put("guid", rst.getString("guid"));
				joLocation.put("lastSeenSince", rst.getString("last_seen_since"));
				joLocation.put("createdOn", rst.getTimestamp("created_on").getTime());
				joLocation.put("modifiedOn", (rst.getTimestamp("modified_on") != null ? rst.getTimestamp("modified_on").getTime() : null));
				joLocation.put("lastSeenSince", rst.getString("last_seen_since"));
				joLocation.put("totalMappedTests", rst.getLong("total_mapped_tests"));
				
				jaLocations.add(joLocation); */

				joVariable.put("var1", "is_delete");
				joVariable.put("var2", "is_alert");
				joVariable.put("var3", "");
				joVariable.put("var4", "Avl Location");
				joCol_Value.put("col_1", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", rst.getString("location_text"));
				joVariable.put("var2", "Added On : ");
				joVariable.put("var21", rst.getTimestamp("created_on").getTime());
				joCol_Value.put("col_2", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Runs In: "+ rst.getString("ip_address"));
				joVariable.put("var2", "Last seen since 211 Days on " + rst.getString("last_responded_on"));
				joCol_Value.put("col_3", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Mapped App");
				joVariable.put("var2", rst.getLong("total_mapped_tests"));
				joCol_Value.put("col_4", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "");
				joVariable.put("var2", "");
				joCol_Value.put("col_5", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);

				joVariable.put("var1", "STATUS_Live");
				joVariable.put("var2", rst.getString("status_text"));
				joCol_Value.put("col_6", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Mon_Availablity");
				joVariable.put("var2", "Url Down");
				/*joVariable.put("var3", "0");*/
				joCol_Value.put("col_7", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joCol_Value.put("agentId", rst.getLong("agent_id"));
				joCol_Value.put("country", rst.getString("country"));
				joCol_Value.put("state", rst.getString("state"));
				joCol_Value.put("city", rst.getString("city"));
				joCol_Value.put("region", rst.getString("region"));
				joCol_Value.put("zone", rst.getString("zone"));

				jaLocations.add(joCol_Value);
				UtilsFactory.clearCollectionHieracy(joCol_Value);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		return jaLocations;
	}
	
	/**
	 * 
	 */
	public String deleteAVMUserLocations(Connection con, LoginUserBean loginUserBean, AVMAgentBean avmAgentBean) throws Exception {
		String strResult = null;
		CallableStatement cstmt = null;
		
		String strQuery = "";
		
		try {
			// note: using PreparedSTMT, ResultSet also worked, using qry SELECT * FROM delete_asd_slas(?, ?);
			strQuery = "{call delete_AVMLocation(?, ?, ?, ?, ?, ?, ?, ?)}";
			cstmt = con.prepareCall(strQuery);
			cstmt.setLong(1, loginUserBean.getUserId());
			cstmt.setLong(2, avmAgentBean.getAgentId());
			cstmt.setString(3, avmAgentBean.getCountry());
			cstmt.setString(4, avmAgentBean.getState());
			cstmt.setString(5, avmAgentBean.getCity());
			cstmt.setString(6, avmAgentBean.getRegion());
			cstmt.setString(7, avmAgentBean.getZone());
			cstmt.registerOutParameter(8, Types.VARCHAR);
			cstmt.executeUpdate();
			
			strResult = cstmt.getString(8);
		}catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(cstmt);
			cstmt = null;
			
			strQuery = null;
		}
		return strResult;
	}
	
	/**
	 * checks user's location already exists 
	 * 
	 * @param con
	 * @param strCountry
	 * @param strState
	 * @param strCity
	 * @param strRegion
	 * @param strZone
	 * @param lAgentId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isUserAgentLocationExists(Connection con, String strCountry, String strState, String strCity, String strRegion, String strZone, long lAgentId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bUserAgentLocationExists = false;
		
		try {
			sbQuery	.append("SELECT EXISTS ( ")
					.append("  SELECT agent_id FROM avm_agent_master WHERE user_id = ? AND country = ? AND state = ? AND city = ? AND region = ? AND zone = ? AND agent_id != ? ")
					.append(") AS user_agent_exists ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strCountry);
			pstmt.setString(3, strState);
			pstmt.setString(4, strCity);
			pstmt.setString(5, strRegion);
			pstmt.setString(6, strZone);
			pstmt.setLong(7, lAgentId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bUserAgentLocationExists = rst.getBoolean("user_agent_exists");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return bUserAgentLocationExists;
	}
	
	/**
	 * gets particular agent's details
	 * 
	 * @param con
	 * @param lAgentId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public AVMAgentBean getAgentLocation(Connection con, long lAgentId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		AVMAgentBean avmAgentBean = null;
		
		try {
			sbQuery	//.append("SELECT agent_id, status, country, state, city, region, zone ")
					.append("SELECT *, concat_avm_location(country, state, city, region, zone) AS location_text ")
					.append("FROM avm_agent_master ")
					.append("WHERE agent_id = ? AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lAgentId);
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				avmAgentBean = new AVMAgentBean();
				avmAgentBean.setAgentId(rst.getLong("agent_id"));
				avmAgentBean.setPrivate(rst.getBoolean("is_private"));
				avmAgentBean.setMACAddress(rst.getString("mac_address"));
				avmAgentBean.setIPAddress(rst.getString("ip_address"));
				avmAgentBean.setStatus(rst.getString("status"));
				avmAgentBean.setCountry(rst.getString("country"));
				avmAgentBean.setState(rst.getString("state"));
				avmAgentBean.setCity(rst.getString("city"));
				avmAgentBean.setRegion(rst.getString("region"));
				avmAgentBean.setZone(rst.getString("zone"));
				avmAgentBean.setGUID(rst.getString("guid"));
				avmAgentBean.setLocationText(rst.getString("location_text"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return avmAgentBean;
	}
	
	/**
	 * adds AVM agent's alert address
	 * 
	 * @param con
	 * @param agentAlertAddressBean
	 * @param lUserId
	 * @param bAddressVerified
	 * @return
	 * @throws Exception
	 */
	public long insertLocationAlertAddress(Connection con, AVMAgentAlertAddressBean agentAlertAddressBean, long lUserId, boolean bAddressVerified) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lAgentAlertId = -1L;
		
		try {
			sbQuery	.append("INSERT INTO avm_agent_alert_mapping (user_id, agent_id, guid, alert_type, email_mobile, created_by, created_on, verified_on) VALUES (?, ?, ?, ?, ?, ?, now(), ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, agentAlertAddressBean.getAgentId());
			pstmt.setString(3, agentAlertAddressBean.getGUID());
			pstmt.setString(4, agentAlertAddressBean.getAlertType());
			pstmt.setString(5, agentAlertAddressBean.getEmailMobile());
			pstmt.setLong(6, lUserId);
			if ( ! bAddressVerified ) {	// address not verified 
				pstmt.setNull(7, Types.TIMESTAMP);
			} else {	// email_mobile address already verified 
				pstmt.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
			}
			pstmt.executeUpdate();
			
			lAgentAlertId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lAgentAlertId;
	}
	
	/**
	 * checks AVM agent's alert address already exists 
	 * 
	 * @param con
	 * @param lAgentId
	 * @param strEmailOrMobileNumber
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isLocAlertAddressAlreadyExists(Connection con, long lAgentId, String strEmailOrMobileNumber, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bLocAlertAddressAlreadyExists = false;
		
		try {
			sbQuery	.append("SELECT EXISTS ( ")
					.append("  SELECT 1 ")
					.append("  FROM avm_agent_alert_mapping ")
					.append("  WHERE user_id = ? AND agent_id = ? AND email_mobile = ? ")
					.append(") AS loc_alert_address_exists ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lAgentId);
			pstmt.setString(3, strEmailOrMobileNumber);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bLocAlertAddressAlreadyExists = rst.getBoolean("loc_alert_address_exists");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return bLocAlertAddressAlreadyExists;
	}
	
	/**
	 * check user's alert address email is already verified, 
	 *   either in `SLA`(`so_alert`) or `AVM`(`avm_agent_alert_mapping`)
	 * 
	 * @param con
	 * @param strEmailOrMobileNumber
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isEmailAlreadyVerified(Connection con, String strEmailOrMobileNumber, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		boolean bEmailAlreadyVerified = false;
		
		try {
			strQuery = "SELECT is_email_already_verified(?, ?) AS is_email_already_verified";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strEmailOrMobileNumber);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bEmailAlreadyVerified = rst.getBoolean("is_email_already_verified");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return bEmailAlreadyVerified;
	}
	
	/**
	 * gets location's added alert addresses
	 * 
	 * @param con
	 * @param lAgentId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLocationAlertAddresses(Connection con, long lAgentId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaAlertAddresses = null;
		JSONObject joAlertAddress = null;
		
		boolean bAddressVerified = false;
		
		try {
			jaAlertAddresses = new JSONArray();
			
			strQuery = "SELECT * FROM avm_agent_alert_mapping WHERE agent_id = ? AND user_id = ?";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lAgentId);
			pstmt.setLong(2, lUserId);
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joAlertAddress = new JSONObject();
				bAddressVerified = (rst.getTimestamp("verified_on") != null);
				
				joAlertAddress.put("alertId", rst.getLong("a_a_m_id"));
				joAlertAddress.put("alertType", rst.getString("alert_type"));
				joAlertAddress.put("emailOrMobile", rst.getString("email_mobile"));
				joAlertAddress.put("status", bAddressVerified ? "Verified" : "Not Verified" );
				joAlertAddress.put("isVerified", bAddressVerified);
				
				jaAlertAddresses.add(joAlertAddress);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaAlertAddresses;
	}
	
	/**
	 * deletes AVM agent's alert address 
	 * 
	 * @param con
	 * @param lAgentAlertId
	 * @param lAgentId
	 * @param lUserId
	 * @throws Exception
	 */
	public void deleteLocationAlertAddress(Connection con, long lAgentAlertId, long lAgentId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "DELETE FROM avm_agent_alert_mapping WHERE a_a_m_id = ? AND agent_id = ? AND user_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lAgentAlertId);
			pstmt.setLong(2, lAgentId);
			pstmt.setLong(3, lUserId);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * updates email address verification, 
	 *  in `SLA`, `AVM` for address is not verified in `so_alert`, `avm_agent_alert_mapping`
	 * 
	 * @param con
	 * @param lAgentAlertId
	 * @throws Exception
	 */
	public void updateAlertVerificationAddress(Connection con, long lAgentAlertId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			// tried, user added same email for different agents/locations, to all email_id(s) added by user
			/*
			sbQuery	.append("WITH avm_user_alert_address AS ( ")
					.append("  SELECT user_id, email_mobile ")
					.append("  FROM avm_agent_alert_mapping ")
					.append("  WHERE a_a_m_id = ? ")
					.append(") UPDATE avm_agent_alert_mapping SET ")
					.append("  verified_on = now(), ")
					.append("  modified_by = avm_user_alert_address.user_id, ")
					.append("  modified_on = now() ")
					.append("WHERE user_id = avm_user_alert_address.user_id ")
					.append("  AND email_mobile = avm_user_alert_address.email_mobile ");
			*/

			/*
			// working
			sbQuery	.append("UPDATE avm_agent_alert_mapping aam SET ") 
					.append("  verified_on = now(), ")
					.append("  modified_by = avm_user_alert_address.user_id, ")
					.append("  modified_on = now() ")
					.append("FROM ( ")
					.append("  SELECT user_id, email_mobile ")
					.append("  FROM avm_agent_alert_mapping ")
					.append("  WHERE a_a_m_id = ? ")
					.append(") AS avm_user_alert_address ")
					.append("WHERE aam.user_id = avm_user_alert_address.user_id ")
					.append("  AND aam.email_mobile = avm_user_alert_address.email_mobile ");
			*/
			
			strQuery = "SELECT * FROM verify_alert_address('AVM', ?) ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lAgentAlertId);
			
			pstmt.execute();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * gets test's locations status 
	 * 
	 * @param con
	 * @param lTestId
	 * @param lLimit
	 * @param lOffSet
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getTestLocationsStatus(Connection con, long lTestId, long lLimit, long lOffSet, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONArray jaLocationsStatus = null;
		JSONObject joLocation = null;
		
		try {
			jaLocationsStatus = new JSONArray();
			
			strQuery = "SELECT * FROM get_avm_test_locations_status(?, ?, ?, ?) ";
			
			pstmt = con.prepareStatement(strQuery);
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getLong("e_user_id"));
			}else{
				pstmt.setLong(1, lUserId);
			}
			
			pstmt.setLong(2, lTestId);
			pstmt.setLong(3, lLimit);
			pstmt.setLong(4, lOffSet);
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				joLocation = new JSONObject();
				joLocation.put("agentId", rst.getLong("agent_id"));
				joLocation.put("country", rst.getString("country"));
				joLocation.put("state", rst.getString("state"));
				joLocation.put("city", rst.getString("city"));
				joLocation.put("region", rst.getString("region"));
				joLocation.put("zone", rst.getString("zone"));
				joLocation.put("locationText", rst.getString("location_text"));
				joLocation.put("last_responded_on", rst.getLong("last_responded_on"));
				joLocation.put("last_seen_since", rst.getLong("last_seen_since"));
				joLocation.put("status", rst.getString("status"));
				joLocation.put("statusText", rst.getString("status_text"));
				joLocation.put("urlStatus", rst.getString("url_status"));
				
				jaLocationsStatus.add(joLocation);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaLocationsStatus;
	}
	
	/**
	 * get user's test summary 
	 * 
	 * @param con
	 * @param lTestId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getUserTestSummary(Connection con, long lTestId, long lUserId, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		JSONObject joUserTestSummary = null;
		
		try {
			strQuery = "SELECT * FROM get_avm_user_test_summary(?, ?) ";
			
			pstmt = con.prepareStatement(strQuery);
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getLong("e_user_id"));
			}else{
				pstmt.setLong(1, lUserId);
			}
			
			pstmt.setLong(2, lTestId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				joUserTestSummary = new JSONObject();
				joUserTestSummary.put("totalMonitoringLocations", rst.getLong("total_monitoring_locations"));
				joUserTestSummary.put("totalActiveLocations", rst.getLong("total_active_locations"));
				joUserTestSummary.put("totalInactiveLocations", rst.getLong("total_inactive_locations"));
				joUserTestSummary.put("activeLocations", rst.getString("active_locations"));
				joUserTestSummary.put("inactiveLocations", rst.getString("inactive_locations"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return joUserTestSummary;
	}
}
