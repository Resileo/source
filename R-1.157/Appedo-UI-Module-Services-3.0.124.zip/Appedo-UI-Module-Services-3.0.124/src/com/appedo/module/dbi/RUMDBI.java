package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class RUMDBI {
	
	private static final String[] GROUP_BY_MINUTE_INTERVALS = {"15 minutes", "30 minutes", "1 hour"};
	private static final String[] GROUP_BY_HOUR_INTERVALS = {"2 hours", "3 hours", "6 hours", "12 hours", "24 hours", "1 day"};
	
	
	/*
	public JSONArray getRUMTests(Connection con, long lUID) throws Exception {
		
		Statement stmt = null;
		ResultSet rs = null;
		
		JSONArray jaRUMTests = null;
		JSONObject joRUMTest = null;
		
		StringBuilder sbQuery = null;
		
		try{
			sbQuery = new StringBuilder();
			
			sbQuery	.append("SELECT * FROM rum_").append(lUID);
			stmt = con.createStatement();
			rs = stmt.executeQuery(sbQuery.toString());
			
			while(rs.next()){
				joRUMTest = new JSONObject();
				
				jaRUMTests.add(joRUMTest);
			}
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return jaRUMTests;
	}
	*/
	
	/**
	 * Get the UID (primary key) for the given GUID.
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public long getUID(Connection con, String strGUID) throws Exception {
		
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		long lUID = -1l;
		
		try {
			
			sbQuery	.append("SELECT uid FROM module_master WHERE guid = '").append(strGUID).append("' ");
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while( rst.next() ){
				lUID = rst.getLong("uid");
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return lUID;
	}
	
	/**
	 * gets pages load time details for particular lUID
	 * 
	 * @param con
	 * @param lUId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getPagesLoadTime(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
	    Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaPagesLoadTime = null;
		JSONObject joPageLoadTime = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		int i = 0, nMaxAvgLoadTime = 0;
		float fPercentagAvgLoadTime = 0f;
		
		try {
			jaPagesLoadTime = new JSONArray();
			
			sbQuery	.append("SELECT rc.url_without_query_string AS page, count(*) AS visitcount, avg(rc.nt_domcomp - rc.nt_nav_st) AS loadtime ")
					.append("FROM rum_collector_").append(lUId).append(" rc ");
			if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
				sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
						.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
						.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
			}
			sbQuery	.append("WHERE (nt_domcomp <> 0 AND nt_nav_st <> 0) ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("GROUP BY rc.url_without_query_string ")
					.append("ORDER BY loadtime DESC ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				if (i == 0) {
					nMaxAvgLoadTime = rst.getInt("loadtime");
					if(nMaxAvgLoadTime == 0) {
						nMaxAvgLoadTime = 1;
					}
				}

				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				fPercentagAvgLoadTime = (rst.getInt("loadtime") * 100) / nMaxAvgLoadTime ;
				
				joPageLoadTime = new JSONObject();
				joPageLoadTime.put("loadtime", rst.getInt("loadtime"));
				joPageLoadTime.put("visitCount", rst.getInt("visitcount"));
				joPageLoadTime.put("page", rst.getString("page"));
				joPageLoadTime.put("percentagePageLoadTime", fPercentagAvgLoadTime != 0 ? fPercentagAvgLoadTime : 1);
				
				jaPagesLoadTime.add(joPageLoadTime);
				
				i = i + 1;
				joPageLoadTime = null;
			}
		} catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaPagesLoadTime;
	}
	
	public JSONArray getPagesLoadTimeWithDateRange(Connection con, long lUId, String strFromStartInterval, String strToInterval) throws Exception {
	    Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaPagesLoadTime = null;
		JSONObject joPageLoadTime = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		int i = 0, nMaxAvgLoadTime = 0;
		float fPercentagAvgLoadTime = 0f;
		try {
			jaPagesLoadTime = new JSONArray();
			
			sbQuery	.append("SELECT url AS page, count(*) AS visitcount, avg(nt_domcomp - nt_nav_st) AS loadtime ") 
					.append("FROM rum_collector_").append(lUId).append(" ")
					.append("WHERE appedo_received_on::timestamp ")
					.append("between to_timestamp("+Long.parseLong(strFromStartInterval)+"/1000)")
					.append(" and to_timestamp("+Long.parseLong(strToInterval)+"/1000)")
					.append(" AND (nt_domcomp <> 0 AND nt_nav_st <> 0) ")
					.append("GROUP BY url ")
					.append("ORDER BY loadtime DESC ");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				if (i == 0) {
					nMaxAvgLoadTime = rst.getInt("loadtime");
					if(nMaxAvgLoadTime == 0) {
						nMaxAvgLoadTime = 1;
					}
				}

				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				fPercentagAvgLoadTime = (rst.getInt("loadtime") * 100) / nMaxAvgLoadTime ;
				
				joPageLoadTime = new JSONObject();
				joPageLoadTime.put("loadtime", rst.getInt("loadtime"));
				joPageLoadTime.put("visitCount", rst.getInt("visitcount"));
				joPageLoadTime.put("page", rst.getString("page"));
				joPageLoadTime.put("percentagePageLoadTime", fPercentagAvgLoadTime != 0 ? fPercentagAvgLoadTime : 1);
				
				jaPagesLoadTime.add(joPageLoadTime);
				
				i = i + 1;
				joPageLoadTime = null;
			}
		} catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaPagesLoadTime;
	}
	
	/**
	 * gets page loaded times
	 *  
	 * @param con
	 * @param lUid
	 * @param strFromStartInterval
	 * @param strURL
	 * @return
	 * @throws Exception
	 */
	public JSONArray getPageLoadTimeChartData(Connection con, long lUid, String strFromStartInterval, String strURL, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaPageLoadTimes = null;
		JSONObject joPageLoadTime = null; // joResult = new JSONObject();//, joRumIdMapping = new JSONObject();
		
		//ArrayList<Long> alData = null;
		//ArrayList<ArrayList<Long>> alChartData = null;
		
		StringBuilder sbQuery = null;
		
		long lTime = 0L;
				
		try {
			sbQuery = new StringBuilder();
			//alChartData = new ArrayList<ArrayList<Long>>();
			jaPageLoadTimes = new JSONArray();
			/*sbQuery	.append("select rum_id, appedo_received_on as time, nt_load_end-nt_nav_st as resp ")
					.append("from rum_collector_").append(lUid).append(" ")
					.append("where appedo_received_on > now() - interval '").append(strFromStartInterval).append("' ")
					.append("and appedo_received_on<=now() and nt_load_end <> 0  and nt_nav_st <> 0  and url=? ")
					.append("order by time desc limit 50 ");*/
			sbQuery	.append("SELECT * FROM get_rum_url_page_load_time(?, ?, ?, ?, ?, ?, ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUid);
			pstmt.setString(2, strURL);
			if ( strFromStartInterval != null ) {
				pstmt.setString(3, strFromStartInterval);
				pstmt.setNull(4, Types.BIGINT);
				pstmt.setNull(5, Types.BIGINT);
			} else {
				pstmt.setNull(3, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(4, lStartDateTimeInMills / 1000);
				pstmt.setLong(5, lEndDateTimeInMills / 1000);
			}
			if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
				pstmt.setString(6, strHealthCode);
			} else {
				pstmt.setNull(6, Types.VARCHAR);
			}
			pstmt.setLong(7, lUserId);
			
			rst = pstmt.executeQuery();
			while(rst.next()){
				lTime = rst.getTimestamp("appedo_received_on").getTime();
/*				
				alData = new ArrayList<Long>();
				alData.add(lTime);
				alData.add(rst.getLong("resp"));
				alChartData.add(alData);
				
				joRumIdMapping.put(lTime+"_"+rst.getLong("resp"), rst.getInt("rum_id"));
*/
				
				// used new chart format for ploting
				joPageLoadTime = new JSONObject();
				joPageLoadTime.put("T", lTime);
				joPageLoadTime.put("V", rst.getLong("resp"));
				joPageLoadTime.put("rumId", rst.getLong("rum_id"));
				jaPageLoadTimes.add(joPageLoadTime);
				
				//alData = null;
				//joPageLoadTime = null;
			}
			
			//joResult.put("message", alChartData);
			//joResult.put("ids", joRumIdMapping);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		
		return jaPageLoadTimes;
	}
	
	public JSONArray getPageLoadTimeChartDataWithDateRange(Connection con, long lUid, String strFromStartInterval, String strToInterval, String strURL) throws Exception {
	    Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaPageLoadTimes = null;
		JSONObject joPageLoadTime = null; 
		
		StringBuilder sbQuery = null;
		
		long lTime = 0L;
		try {
			sbQuery = new StringBuilder();
			jaPageLoadTimes = new JSONArray();
			sbQuery	.append("SELECT * from get_rum_url_page_load_time_range(?, ?, ?, ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUid);
			pstmt.setString(2, strURL);
			pstmt.setLong(3, Long.parseLong(strFromStartInterval));
			pstmt.setLong(4, Long.parseLong(strToInterval));
			rst = pstmt.executeQuery();
			while(rst.next()){
				lTime = rst.getTimestamp("appedo_received_on").getTime();
				
				// used new chart format for ploting
				joPageLoadTime = new JSONObject();
				joPageLoadTime.put("T", lTime);
				joPageLoadTime.put("V", rst.getLong("resp"));
				joPageLoadTime.put("rumId", rst.getLong("rum_id"));
				jaPageLoadTimes.add(joPageLoadTime);
				
			}
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaPageLoadTimes;
	}
	
	public JSONObject getPageBreakDownDetails(Connection con, long lUid, long lRUMId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null, joResult = new JSONObject();
		
		String strFullURL = "";
		StringBuilder sbQuery = null;
		
		long lMax = 0l;
		
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			
			sbQuery	.append("SELECT url, (nt_dns_end - nt_dns_st) AS dns, (nt_con_end - nt_con_st) AS connection, ")
					.append("  (nt_res_st - nt_req_st) AS request, (nt_res_end - nt_res_st) AS response, ")
					.append("  (nt_domcomp - nt_domloading) AS dom_loading, (nt_red_end - nt_red_st) AS redirect ")
					.append("FROM rum_collector_").append(lUid).append(" ")
					.append("WHERE rum_id = ? ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND received_on > now() - interval '").append(strFromStartInterval).append("' ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRUMId);
			rst = pstmt.executeQuery();
			if(rst.next()){
				strFullURL = rst.getString("url");
				
				lMax = rst.getLong("dns") + rst.getLong("connection") + rst.getLong("request") + rst.getLong("response") + rst.getLong("dom_loading") + rst.getLong("redirect");
				joChart = new JSONObject();
				joChart.put("name", "DNS");
				joChart.put("time", rst.getLong("dns"));
				joChart.put("percentage",(rst.getLong("dns")*100)/lMax != 0 ? rst.getLong("dns")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Connection");
				joChart.put("time", rst.getLong("connection"));
				joChart.put("percentage",(rst.getLong("connection")*100)/lMax != 0 ? rst.getLong("connection")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Redirect");
				joChart.put("time", rst.getLong("redirect"));
				joChart.put("percentage",(rst.getLong("redirect")*100)/lMax != 0 ? rst.getLong("redirect")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Request");
				joChart.put("time", rst.getLong("request"));
				joChart.put("percentage",(rst.getLong("request")*100)/lMax != 0 ? rst.getLong("request")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Response");
				joChart.put("time", rst.getLong("response"));
				joChart.put("percentage",(rst.getLong("response")*100)/lMax != 0 ? rst.getLong("response")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Dom Loading");
				joChart.put("time", rst.getLong("dom_loading"));
				joChart.put("percentage",(rst.getLong("dom_loading")*100)/lMax != 0 ? rst.getLong("dom_loading")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
			}
			joResult.put("fullURL", strFullURL);
			joResult.put("pageBreakDownDetails", jaChartData);
			
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
			
			strFullURL = null;
		}
		
		return joResult;
	}

	public JSONArray getPageBreakDownDetailsWithDateRange(Connection con, long lUid, long lRUMId, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		long lMax = 0l;
	    Date dateLog = LogManager.logMethodStart();

		try{
			
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			sbQuery	.append("SELECT (nt_dns_end-nt_dns_st) AS dns, (nt_con_end-nt_con_st) AS connection, (nt_res_st - nt_req_st) AS request,(nt_res_end -nt_res_st) AS response,(nt_domcomp-nt_domloading) AS dom_loading,(nt_red_end - nt_red_st) AS redirect ")
					.append("FROM rum_collector_").append(lUid).append(" ")
					.append("WHERE rum_id=? ")
					.append("AND appedo_received_on::timestamp")
					.append(" between to_timestamp("+Long.parseLong(strFromStartInterval)+"/1000)")
					.append(" and to_timestamp("+Long.parseLong(strToInterval)+"/1000)");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRUMId);
			rst = pstmt.executeQuery();
			
			if(rst.next()){
				lMax = rst.getLong("dns") + rst.getLong("connection") + rst.getLong("request") + rst.getLong("response") + rst.getLong("dom_loading") + rst.getLong("redirect");
				joChart = new JSONObject();
				joChart.put("name", "DNS");
				joChart.put("time", rst.getLong("dns"));
				joChart.put("percentage",(rst.getLong("dns")*100)/lMax != 0 ? rst.getLong("dns")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Connection");
				joChart.put("time", rst.getLong("connection"));
				joChart.put("percentage",(rst.getLong("connection")*100)/lMax != 0 ? rst.getLong("connection")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Redirect");
				joChart.put("time", rst.getLong("redirect"));
				joChart.put("percentage",(rst.getLong("redirect")*100)/lMax != 0 ? rst.getLong("redirect")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Request");
				joChart.put("time", rst.getLong("request"));
				joChart.put("percentage",(rst.getLong("request")*100)/lMax != 0 ? rst.getLong("request")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Response");
				joChart.put("time", rst.getLong("response"));
				joChart.put("percentage",(rst.getLong("response")*100)/lMax != 0 ? rst.getLong("response")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
				joChart = new JSONObject();
				joChart.put("name", "Dom Loading");
				joChart.put("time", rst.getLong("dom_loading"));
				joChart.put("percentage",(rst.getLong("dom_loading")*100)/lMax != 0 ? rst.getLong("dom_loading")*100/lMax : 1 );
				jaChartData.add(joChart);
				joChart = null;
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return jaChartData;
	}

	public JSONArray getBrowserChartdata(Connection con, long lUid, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		
		//boolean bFilterWithHealthCode = false;
		
	    Date dateLog = LogManager.logMethodStart();
	    
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			
			//bFilterWithHealthCode = (strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")));
			
			// TODO: for percentage calc, get total count by adding `visitcount` in while(rst) and add another loop calc %
			
			/*
			 * TODO: conform, add `LEFT JOIN so_rum_threshold_breach_<user_id>` based on `strHealthCode != null`,
			 *   instead of `rc.uid = rtb.uid` hard code `srtb = <uid>` 
			 */
			sbQuery	.append("select translate(COALESCE(rc.browser_name, 'Others'), '0123456789', '') AS browser, count(*) as visitcount, ")
					.append("  round(max(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("  round(avg(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("  round(min(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("from rum_collector_").append(lUid).append(" rc ");
			if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
				sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
						.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
						.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
			}
			sbQuery	.append("where (rc.nt_domcomp - rc.nt_nav_st) > 0 AND (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("group by browser ")
					.append("order by visitcount desc, browser ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joChart = new JSONObject();
				joChart.put("visitCount", rst.getInt("visitcount"));
				joChart.put("browser", rst.getString("browser"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				jaChartData.add(joChart);
				
				joChart = null;
			}
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return jaChartData;
	}
	
	
	public JSONObject getRumAllCharts_v1(Connection con, long lUserId, long lUid, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strQuery, String xyLabel) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joData = null, joResult = null, joRtn = null;
		
		StringBuilder sbQuery = null;
		
		//boolean bFilterWithHealthCode = false;
		
	    Date dateLog = LogManager.logMethodStart();
	    
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			joResult = new JSONObject();
			joRtn = new JSONObject();
			
			if (strFromStartInterval != null) {
				sbQuery.append(" srt.received_on BETWEEN now() - interval '").append(strFromStartInterval).append("' AND now() ");
			} else {
				sbQuery.append(" srt.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND  to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			
			strQuery = strQuery.replace("@dateFilter_1@", sbQuery.toString());
			sbQuery.setLength(0);
			
			if (strFromStartInterval != null) {
				sbQuery.append(" graph.appedo_received_on BETWEEN now() - interval '").append(strFromStartInterval).append("' AND now() ");
			} else {
				sbQuery.append(" graph.appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND  to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			strQuery = strQuery.replace("@dateFilter_2@", sbQuery.toString());
			
			pstmt = con.prepareStatement(strQuery);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joData = new JSONObject();
				joData.put(xyLabel, rst.getString("name"));
				joData.put("count", rst.getLong("count"));
				joData.put("min", rst.getString("min"));
				joData.put("avg", rst.getString("avg"));
				joData.put("max", rst.getString("max"));
				joData.put("warning", rst.getLong("warning"));
				joData.put("critical", rst.getLong("critical"));
				
				jaChartData.add(joData);
			}
			//System.out.println("return array "+ jaChartData.toString());
			joResult.put("data", jaChartData);
			joRtn.put("chartdata", joResult);
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			joData = null;
			joResult = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return joRtn;
	}
	
	public JSONArray getBrowserChartdataWithDateRange(Connection con, long lUid, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		
	    Date dateLog = LogManager.logMethodStart();
		try{
			
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			
			// TODO: for percentage calc, get total count by adding `visitcount` in while(rst) and add another loop calc %
			sbQuery	.append("select translate(COALESCE(browser_name, 'Others'), '0123456789', '') as browser, count(*) as visitcount, round(max(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("round(avg(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("round(min(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("from rum_collector_").append(lUid).append(" ")
					.append("where appedo_received_on::timestamp")
					.append(" between to_timestamp("+Long.parseLong(strFromStartInterval)+"/1000)")
					.append(" and to_timestamp("+Long.parseLong(strToInterval)+"/1000)")
					.append(" AND (nt_domcomp - nt_nav_st)>0 AND (nt_domcomp <> 0 AND nt_nav_st <> 0) group by browser order by visitcount desc, browser");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				
				joChart = new JSONObject();
				
				joChart.put("visitCount", rst.getInt("visitcount"));
				joChart.put("browser", rst.getString("browser"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				jaChartData.add(joChart);
				
				joChart = null;
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return jaChartData;
	}
	
	public JSONArray getOSChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			sbQuery	.append("select COALESCE(rc.os, 'Others') AS os, count(*) as visitcount, ")
					.append("  round(max(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("  round(avg(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("  round(min(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("from rum_collector_").append(lUId).append(" rc ");
			if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
				sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
						.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
						.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
			}
			sbQuery	.append("where (rc.nt_domcomp - rc.nt_nav_st) > 0 AND (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			} else {
				sbQuery	.append("  AND rc.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("group by os ")  
					.append("order by visitcount desc, os ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				joChart = new JSONObject();

				joChart.put("visitCount", rst.getInt("visitcount"));
				joChart.put("os", rst.getString("os"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				
				jaChartData.add(joChart);
				
				joChart = null;
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaChartData;
	}
	
	public JSONArray getOSChartdataWithDateRange(Connection con, long lUid, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			sbQuery	.append("select COALESCE(os, 'Others') AS os, count(*) as visitcount, round(max(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("round(avg(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("round(min(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("from rum_collector_").append(lUid).append(" ")
					.append("where appedo_received_on::timestamp")
					.append(" between to_timestamp("+Long.parseLong(strFromStartInterval)+"/1000)")
					.append(" and to_timestamp("+Long.parseLong(strToInterval)+"/1000)")
					.append(" and (nt_domcomp - nt_nav_st)>0 AND (nt_domcomp <> 0 AND nt_nav_st <> 0) group by os order by visitcount desc, os");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				joChart = new JSONObject();

				joChart.put("visitCount", rst.getInt("visitcount"));
				joChart.put("os", rst.getString("os"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				
				jaChartData.add(joChart);
				
				joChart = null;
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaChartData;
	}
	
	public JSONArray getDeviceTypeChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		
		Date dateLog = LogManager.logMethodStart();
		
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			
			sbQuery	.append("SELECT COALESCE(rc.device_type, 'Others') as device, count(*) as visitcount, ")
					.append("  round(max(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("  round(avg(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("  round(min(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("from rum_collector_").append(lUId).append(" rc ");
			if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
				sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
						.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
						.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
			}
			sbQuery	.append("WHERE (rc.nt_domcomp - rc.nt_nav_st) > 0 AND (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("group by device ")
					.append("order by visitcount desc, device ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				joChart = new JSONObject();
				
				joChart.put("visitCount", rst.getInt("visitcount"));
				joChart.put("device", rst.getString("device"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				jaChartData.add(joChart);
				
				joChart = null;
			}
		} catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaChartData;
	}
	
	public JSONArray getDeviceTypeChartdataWithDateRange(Connection con, long lUid, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		
		Date dateLog = LogManager.logMethodStart();
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			sbQuery	.append("SELECT COALESCE(device_type, 'Others') as device, count(*) as visitcount, round(max(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("round(avg(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("round(min(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append(" from rum_collector_").append(lUid).append(" ")
					.append("where appedo_received_on::timestamp")
					.append(" between to_timestamp("+Long.parseLong(strFromStartInterval)+"/1000)")
					.append(" and to_timestamp("+Long.parseLong(strToInterval)+"/1000)")
					.append(" AND (nt_domcomp - nt_nav_st)>0 AND (nt_domcomp <> 0 AND nt_nav_st <> 0) group by device order by visitcount desc, device ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				joChart = new JSONObject();
				
				joChart.put("visitCount", rst.getInt("visitcount"));
				joChart.put("device", rst.getString("device"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				jaChartData.add(joChart);
				
				joChart = null;
			}
		} catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaChartData;
	}
	
	public JSONArray getDeviceNamesChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		
		Date dateLog = LogManager.logMethodStart();
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			sbQuery	.append("select rc.merchant_name as merchant, count(*) as visitcount, ")
					.append("  round(max(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("  round(avg(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("  round(min(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("from rum_collector_").append(lUId).append(" rc ");
			if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
				sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
						.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
						.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
			}
			sbQuery	.append("where (rc.nt_domcomp - rc.nt_nav_st) > 0 AND (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("group by merchant ")
					.append("order by visitcount desc ");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				
				// The query returns first row will be max duration, since it is ordered in procedure
				// so the time taken bar can be shown.
				joChart = new JSONObject();
				
				joChart.put("visitCount", rst.getInt("visitcount"));
				joChart.put("merchant", rst.getString("merchant"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				
				jaChartData.add(joChart);
				
				joChart = null;
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return jaChartData;
	}
		
	public JSONArray getLocationChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		
		Date dateLog = LogManager.logMethodStart();
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			sbQuery	.append("SELECT count(*) AS count, CASE WHEN ipm.city_name = '-' OR ipm.city_name IS NULL THEN 'Others' ELSE ipm.city_name END AS city, ")
					.append("  round(max(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("  round(avg(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("  round(min(rc.nt_domcomp - rc.nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("FROM rum_collector_").append(lUId).append(" rc ");
			if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
				sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
						.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
						.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
			}
			sbQuery	.append("LEFT JOIN ip_location_master ipm ON rc.ip_address = ipm.ipaddress ")
					.append("where (rc.nt_domcomp - rc.nt_nav_st) > 0 AND (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("GROUP BY city ")
					.append("ORDER BY count DESC, city ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				joChart = new JSONObject();
				
				joChart.put("count", rst.getInt("count"));
				joChart.put("city", rst.getString("city"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				
				jaChartData.add(joChart);
				
				joChart = null;
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return jaChartData;
	}
	
	public String getLocationChartdataForWorldMap(Connection con, long lUid, String strFromStartInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null,jaoutputData=null;
		int loccount=0,otherscount=0;
		
		StringBuilder sbQuery = null;
		
		Date dateLog = LogManager.logMethodStart();
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			jaoutputData = new JSONObject();
			sbQuery	.append("SELECT count(*) AS count, CASE WHEN city_name = '-' OR city_name IS NULL THEN 'Others' ELSE city_name END AS city, latitude, longitude, ")
					.append("round(max(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("round(avg(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("round(min(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("FROM rum_collector_").append(lUid)
					.append(" LEFT JOIN ip_location_master ON ip_address = ipaddress ")
					.append(" where appedo_received_on>now()- interval '").append(strFromStartInterval)
					.append("' AND (nt_domcomp - nt_nav_st)>0 AND (nt_domcomp <> 0 AND nt_nav_st <> 0) GROUP BY city, latitude, longitude ORDER BY 1 DESC");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				if(!rst.getString("city").equalsIgnoreCase("Others")){
					loccount++;
					joChart = new JSONObject();
					joChart.put("id", loccount);
					joChart.put("name", rst.getString("city"));
					joChart.put("latitude", rst.getDouble("latitude"));
					joChart.put("longitude", rst.getDouble("longitude"));
					joChart.put("completed", rst.getInt("count"));
					joChart.put("running", 0);
					jaChartData.add(joChart);
					joChart = null;
				}else{
					otherscount = otherscount+rst.getInt("count");
				}
			}
			jaoutputData.put("mapData", jaChartData);
			jaoutputData.put("othersCount", otherscount);
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return jaoutputData.toString();
	}
	
	public JSONArray getRUMLocationChartDataWithDateRange(Connection con, long lUid, String strFromStartInterval, String strToInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaChartData = null;
		JSONObject joChart = null;
		
		StringBuilder sbQuery = null;
		
		Date dateLog = LogManager.logMethodStart();
		try{
			sbQuery = new StringBuilder();
			jaChartData = new JSONArray();
			sbQuery	.append("SELECT count(*) AS count, CASE WHEN city_name = '-' OR city_name IS NULL THEN 'Others' ELSE city_name END AS city, ")
					.append("round(max(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS max_resp, ")
					.append("round(avg(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS avg_resp, ")
					.append("round(min(nt_domcomp - nt_nav_st)/1000::numeric, 2) AS min_resp ")
					.append("FROM rum_collector_").append(lUid)
					.append(" LEFT JOIN ip_location_master ON ip_address = ipaddress ")
					.append("where appedo_received_on::timestamp")
					.append(" between to_timestamp("+Long.parseLong(strFromStartInterval)+"/1000)")
					.append(" and to_timestamp("+Long.parseLong(strToInterval)+"/1000)")
					.append(" AND (nt_domcomp - nt_nav_st)>0 AND (nt_domcomp <> 0 AND nt_nav_st <> 0) GROUP BY city ORDER BY 1 DESC");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				joChart = new JSONObject();
				
				joChart.put("count", rst.getInt("count"));
				joChart.put("city", rst.getString("city"));
				joChart.put("max_resp", rst.getString("max_resp"));
				joChart.put("avg_resp", rst.getString("avg_resp"));
				joChart.put("min_resp", rst.getString("min_resp"));
				
				jaChartData.add(joChart);
				
				joChart = null;
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		    LogManager.logMethodEnd(dateLog);
		}
		return jaChartData;
	}
	
	/**
	 * Gets Total Visitors count for the particular User's UID,
	 * for the given time interval.
	 * 
	 * @param con
	 * @param lUID
	 * @throws Exception
	 */
	public JSONObject getVisitorsCount(Connection con, long lUID, String strFromStartInterval) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joResult = new JSONObject();
		
		try {
			sbQuery	.append("SELECT count(*) AS visitor_count ")
					.append("FROM rum_collector_").append(lUID).append(" ")
					.append("WHERE appedo_received_on > now() - interval '").append(strFromStartInterval).append("' AND (nt_domcomp <> 0 AND nt_nav_st <> 0) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			
			if( rst.next() ) {
				joResult.put("visitorsCount", rst.getLong("visitor_count"));
			}
			
		} catch (Exception e) {
			LogManager.errorLog("Exception in getVisitorsCount: "+e.getMessage());
			LogManager.errorLog(e.getMessage());
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			LogManager.logMethodEnd(dateLog);
		}
		
		return joResult;
	}
	
	/**
	 * gets daily visitors count chart data for the particular user's uid 
	 * 
	 * @param con
	 * @param lUID
	 * @throws Exception
	 */
	public JSONObject getDailyVisitorsCount(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";
		String[] saAppedoReceivedOnFormats = {"date_trunc('minute', rc.appedo_received_on)", "date_trunc('hour', rc.appedo_received_on)", "rc.appedo_received_on::date"};
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();
		
		JSONObject joResult = new JSONObject(), joData = null;
		
		try {
			if ( strFromStartInterval != null ) {
				// slider
				
				if( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( UtilsFactory.contains(GROUP_BY_HOUR_INTERVALS, strFromStartInterval) ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			} else {
				// custom date time interval 
				
				if( lEndDateTimeInMills - lStartDateTimeInMills <= 3600000 ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( lEndDateTimeInMills - lStartDateTimeInMills <= 86400000 ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			}
			
			sbQuery	.append("SELECT ").append(strFormatAppedoReceivedOn).append(" AS appedo_received_on_formatted, count(*) AS daily_visitor_count, ")
					.append("count(CASE WHEN rtb.rum_id IS NULL THEN 1 ELSE NULL END) AS ok_cnt, ")
					.append("count(CASE WHEN rtb.breached_severity = 'WARNING' THEN 1 ELSE NULL END) AS warning_cnt, ")
					.append("count(CASE WHEN rtb.breached_severity = 'CRITICAL' THEN 1 ELSE NULL END) AS critical_cnt ")
					.append("FROM rum_collector_").append(lUID).append(" rc ")
					.append("LEFT JOIN so_rum_threshold_breach_").append(lUserId).append(" rtb ON rc.uid = rtb.uid AND rc.rum_id = rtb.rum_id ")
					.append("WHERE (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ")
					.append("AND ( '").append(strHealthCode).append("' = '' OR rtb.breached_severity = '").append(strHealthCode).append("' ) ");
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.appedo_received_on > now() - interval '").append(strFromStartInterval).append("'  ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("GROUP BY appedo_received_on_formatted ")
					.append("ORDER BY appedo_received_on_formatted ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on_formatted").getTime());
				joData.put("V", rst.getLong("daily_visitor_count"));
				joData.put("ok_cnt", rst.getLong("ok_cnt"));
				joData.put("warning_cnt", rst.getLong("warning_cnt"));
				joData.put("critical_cnt", rst.getLong("critical_cnt"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("dailyVisitorsCount", alDailyVisitorsCount);
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strFormatAppedoReceivedOn = null;
			alDailyVisitorsCount = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joResult;
	}
	
	/**
	 * gets daily visitors count chart data for the particular user's uid 
	 * 
	 * @param con
	 * @param lUID
	 * @throws Exception
	 */
	public JSONObject getDailyVisitorsCount_v1(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";
		String[] saAppedoReceivedOnFormats = {"date_trunc('minute', rc.appedo_received_on)", "date_trunc('hour', rc.appedo_received_on)", "rc.appedo_received_on::date"};
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();
		
		JSONObject joResult = new JSONObject(), joData = null;
		
		try {
			if ( strFromStartInterval != null ) {
				// slider
				
				if( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( UtilsFactory.contains(GROUP_BY_HOUR_INTERVALS, strFromStartInterval) ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			} else {
				// custom date time interval 
				
				if( lEndDateTimeInMills - lStartDateTimeInMills <= 3600000 ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( lEndDateTimeInMills - lStartDateTimeInMills <= 86400000 ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			}
			   
			sbQuery	.append("SELECT ").append(strFormatAppedoReceivedOn).append(" AS appedo_received_on_formatted, count(*) AS daily_visitor_count, ")
					.append("count(CASE WHEN rtb.rum_id IS NULL THEN 1 ELSE NULL END) AS ok_cnt, ")
					.append("count(CASE WHEN rtb.breached_severity = 'WARNING' THEN 1 ELSE NULL END) AS warning_cnt, ")
					.append("count(CASE WHEN rtb.breached_severity = 'CRITICAL' THEN 1 ELSE NULL END) AS critical_cnt ")
					.append("FROM rum_collector_").append(lUID).append(" rc ")
					.append("LEFT JOIN so_rum_threshold_breach_").append(lUserId).append(" rtb ON rc.uid = rtb.uid AND rc.rum_id = rtb.rum_id ")
					.append("WHERE (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
			if (strHealthCode.equals(Constants.CRITWARN)) {
				sbQuery.append("AND rtb.breached_severity IN ('").append(Constants.CRITICAL).append("','").append(Constants.WARNING).append("') ");
			} else {
				sbQuery.append("AND ( '").append(strHealthCode).append("' = '' OR rtb.breached_severity = '").append(strHealthCode).append("' ) ");
			}
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.appedo_received_on > now() - interval '").append(strFromStartInterval).append("'  ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			sbQuery	.append("GROUP BY appedo_received_on_formatted ")
					.append("ORDER BY appedo_received_on_formatted ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on_formatted").getTime());
				joData.put("V", rst.getLong("daily_visitor_count"));
				joData.put("ok_cnt", rst.getLong("ok_cnt"));
				joData.put("warning_cnt", rst.getLong("warning_cnt"));
				joData.put("critical_cnt", rst.getLong("critical_cnt"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("data", alDailyVisitorsCount);
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strFormatAppedoReceivedOn = null;
			alDailyVisitorsCount = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joResult;
	}
	
	public JSONObject getDailyVisitorsCount_v2(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, String query) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";
		String[] saAppedoReceivedOnFormats = {"date_trunc('minute', rc.appedo_received_on)", "date_trunc('hour', rc.appedo_received_on)", "rc.appedo_received_on::date"};
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();
		
		JSONObject joResult = new JSONObject(), joData = null;
		JSONObject joRtn = new JSONObject();
		try {
			if ( strFromStartInterval != null ) {
				// slider
				
				if( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( UtilsFactory.contains(GROUP_BY_HOUR_INTERVALS, strFromStartInterval) ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			} else {
				// custom date time interval 
				
				if( lEndDateTimeInMills - lStartDateTimeInMills <= 3600000 ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( lEndDateTimeInMills - lStartDateTimeInMills <= 86400000 ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			}
			
			query = query.replace("@appedoReceivedOn@",strFormatAppedoReceivedOn);
						
			if (strHealthCode.equals(Constants.CRITWARN)) {
				sbQuery.append("AND rtb.breached_severity IN ('").append(Constants.CRITICAL).append("','").append(Constants.WARNING).append("') ");
			} else {
				sbQuery.append("AND ( '").append(strHealthCode).append("' = '' OR rtb.breached_severity = '").append(strHealthCode).append("' ) ");
			}
			query = query.replace("@healthCode@",sbQuery.toString());
			sbQuery.setLength(0);
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.appedo_received_on > now() - interval '").append(strFromStartInterval).append("'  ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			query = query.replace("@dateFilter@",sbQuery.toString());
			
			pstmt = con.prepareStatement(query);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on_formatted").getTime());
				joData.put("V", rst.getLong("daily_visitor_count"));
				joData.put("ok_cnt", rst.getLong("ok_cnt"));
				joData.put("warning_cnt", rst.getLong("warning_cnt"));
				joData.put("critical_cnt", rst.getLong("critical_cnt"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("data", alDailyVisitorsCount);
			joRtn.put("chartdata", joResult);
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strFormatAppedoReceivedOn = null;
			alDailyVisitorsCount = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joRtn;
	}
	
	public JSONObject getDailyVisitorsCount_v3(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, String query, String xyLabel) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";
		String[] saAppedoReceivedOnFormats = {"date_trunc('minute', rc.appedo_received_on)", "date_trunc('hour', rc.appedo_received_on)", "rc.appedo_received_on::date"};
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();
		
		JSONObject joResult = new JSONObject(), joData = null;
		JSONObject joRtn = new JSONObject();
		try {
			if ( strFromStartInterval != null ) {
				// slider
				
				if( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( UtilsFactory.contains(GROUP_BY_HOUR_INTERVALS, strFromStartInterval) ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			} else {
				// custom date time interval 
				
				if( lEndDateTimeInMills - lStartDateTimeInMills <= 3600000 ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( lEndDateTimeInMills - lStartDateTimeInMills <= 86400000 ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			}
			
			query = query.replace("@appedoReceivedOn@",strFormatAppedoReceivedOn);
						
			if (strHealthCode.equals(Constants.CRITWARN)) {
				sbQuery.append("AND rtb.breached_severity IN ('").append(Constants.CRITICAL).append("','").append(Constants.WARNING).append("') ");
			} else {
				sbQuery.append("AND ( '").append(strHealthCode).append("' = '' OR rtb.breached_severity = '").append(strHealthCode).append("' ) ");
			}
			query = query.replace("@healthCode@",sbQuery.toString());
			sbQuery.setLength(0);
			if ( strFromStartInterval != null ) {
				sbQuery	.append("  AND rc.appedo_received_on > now() - interval '").append(strFromStartInterval).append("'  ");
			} else {
				// converts into minutes
				sbQuery	.append("  AND rc.appedo_received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
			}
			query = query.replace("@dateFilter@",sbQuery.toString());
			
			pstmt = con.prepareStatement(query);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put(xyLabel, rst.getTimestamp("appedo_received_on_formatted").getTime());
				joData.put("count", rst.getLong("count"));
				joData.put("avg", 0);
				joData.put("warning", rst.getLong("warning"));
				joData.put("critical", rst.getLong("critical"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("data", alDailyVisitorsCount);
			joRtn.put("chartdata", joResult);
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strFormatAppedoReceivedOn = null;
			alDailyVisitorsCount = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joRtn;
	}
	
	public JSONObject getDailyVisitorsCount_v4(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String query, String xyLabel) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";
		String[] saAppedoReceivedOnFormats = {"minute", "hour", "day"};
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();
		
		JSONObject joResult = new JSONObject(), joData = null;
		JSONObject joRtn = new JSONObject();
		try {
			if ( strFromStartInterval != null ) {
				// slider
				
				if( UtilsFactory.contains(GROUP_BY_MINUTE_INTERVALS, strFromStartInterval) ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( UtilsFactory.contains(GROUP_BY_HOUR_INTERVALS, strFromStartInterval) ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			} else {
				// custom date time interval 
				
				if( lEndDateTimeInMills - lStartDateTimeInMills <= 3600000 ) {
					// for last 1 hour, grouped minute wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[0];
				} else if( lEndDateTimeInMills - lStartDateTimeInMills <= 86400000 ) {
					// for Last 24 hours interval, grouped hour wise 
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[1];
				} else {
					// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
					strFormatAppedoReceivedOn = saAppedoReceivedOnFormats[2];
				}
			}
			
			if ( strFromStartInterval != null) {
				sbQuery.append(" (SELECT generate_series(date_trunc('").append(strFormatAppedoReceivedOn).append("', now() - interval '").append(strFromStartInterval)
				.append("'), date_trunc('").append(strFormatAppedoReceivedOn).append("', now()), '1 ").append(strFormatAppedoReceivedOn).append("') as start_from) as gs ");
			} else {
				sbQuery.append(" (SELECT generate_series(date_trunc('").append(strFormatAppedoReceivedOn).append("', to_timestamp(").append(lStartDateTimeInMills/1000)
				.append(")), date_trunc('").append(strFormatAppedoReceivedOn).append("',to_timestamp(").append(lEndDateTimeInMills/1000).append(")), '1 ")
				.append(strFormatAppedoReceivedOn).append("') as start_from) as gs ");
			}
			
			query = query.replace("@dateFilter@",sbQuery.toString());
			query = query.replace("@dateTrunc@",strFormatAppedoReceivedOn);
			
			//System.out.println("query : "+ query);
			pstmt = con.prepareStatement(query);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put(xyLabel, rst.getLong("datetime"));
				joData.put("count", rst.getLong("count"));
				joData.put("min", rst.getString("min"));
				joData.put("avg", rst.getString("avg"));
				joData.put("max", rst.getString("max"));
				joData.put("warning", rst.getLong("warning"));
				joData.put("critical", rst.getLong("critical"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("data", alDailyVisitorsCount);
			joRtn.put("chartdata", joResult);
			
		} catch (Exception ex) {
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strFormatAppedoReceivedOn = null;
			alDailyVisitorsCount = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joRtn;
	}
	
	public JSONArray getRUMCards(Connection con, long lUserId, JSONObject joEnterprise) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaRUMCards = new JSONArray();
		
		JSONObject joData = null;
		try {
			sbQuery.append("SELECT uid, module_name FROM module_master WHERE user_id = ? AND module_code = 'RUM' ");
			if(joEnterprise.getInt("e_id")!=0){
				sbQuery.append("AND e_id = ").append(joEnterprise.getLong("e_id"));
			}
			sbQuery.append(" ORDER BY module_name ");
			
			//System.out.println("query : "+ query);
			pstmt = con.prepareStatement(sbQuery.toString());
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getLong("e_user_id"));
			}else{
				pstmt.setLong(1, lUserId);
			}
			
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("name", rst.getString("module_name"));
				joData.put("value", rst.getLong("uid"));
				
				jaRUMCards.add(joData);
			}
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaRUMCards;
	}
	
	public JSONArray getRUMFilterValues(Connection con, long lUID, String filterType, String sliderInterval, long lStartDate, long lEndDate) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		StringBuilder sbDateFilter = new StringBuilder();
		
		JSONArray jaRUMFilters = new JSONArray();
		
		JSONObject joData = null;
		try {
			
			if (!filterType.equals("city_name")) {
				sbQuery.append(" SELECT ").append(filterType).append(" FROM rum_collector_").append(lUID).append(" WHERE @dateFilter@ GROUP BY ").append(filterType)
				.append(" ORDER BY ").append(filterType);
			} else {
				sbQuery.append(" SELECT ipm.").append(filterType).append(" FROM ip_location_master ipm INNER JOIN rum_collector_").append(lUID)
						.append(" rm ON rm.ip_address = ipm.ipaddress AND rm.@dateFilter@ GROUP BY ipm.").append(filterType).append(" ORDER BY ipm.").append(filterType);
			}
			
			if (sliderInterval != null) {
				sbDateFilter.append("appedo_received_on BETWEEN now() - INTERVAL '").append(sliderInterval).append("' AND now() ");
			} else {
				sbDateFilter.append("appedo_received_on BETWEEN to_timestamp(").append(lStartDate/1000).append(") AND to_timestamp(").append(lEndDate/1000).append(") ");
			}
			
			//System.out.println("query : "+ query);
			pstmt = con.prepareStatement(sbQuery.toString().replace("@dateFilter@", sbDateFilter.toString()));
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("name", rst.getString(filterType));
				joData.put("value", rst.getString(filterType));
				
				jaRUMFilters.add(joData);
			}
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst); 
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			UtilsFactory.clearCollectionHieracy(sbDateFilter);
			sbDateFilter = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaRUMFilters;
	}
	
	public JSONArray getRUMDatas(Connection con, long lUID, String strSearchText, String filterType, String filterValue, String sliderInterval, long lStartDate, long lEndDate) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaRUMDatas = new JSONArray();
		
		JSONObject joData = null;
		try {
			
			sbQuery.append(" SELECT rm.appedo_received_on AS date, rm.ip_address AS ip_address, rm.url_without_query_string AS url, (rm.nt_dns_end - rm.nt_dns_st) AS dns, ")
					.append(" (rm.nt_con_end - rm.nt_con_st) AS connection, (rm.nt_res_st - rm.nt_req_st) AS ttfb, (rm.nt_res_end - rm.nt_res_st) AS response, ")
					.append(" (rm.nt_domcomp - nt_domloading) AS dom, (rm.nt_load_end - rm.nt_load_st) AS load_time, (rm.nt_domcomp - rm.nt_fet_st) AS total_time from rum_collector_")
					.append(lUID).append(" rm WHERE ");
			if (!filterType.equals("city_name")) {
				sbQuery.append(" rm.").append(filterType).append(" = ").append(UtilsFactory.makeValidVarchar(filterValue));
			} else {
				sbQuery.append(" rm.ip_address IN (SELECT ipaddress FROM ip_location_master WHERE city_name = ").append(UtilsFactory.makeValidVarchar(filterValue)).append(") ");
			}
			if (strSearchText != null && strSearchText.length() > 0) {
				sbQuery.append(" AND rm.url_without_query_string ILIKE '%").append(strSearchText).append("%' ");
			}
			if (sliderInterval != null) {
				sbQuery.append(" AND rm.appedo_received_on BETWEEN now() - INTERVAL '").append(sliderInterval).append("' AND now() ");
			} else {
				sbQuery.append(" AND rm.appedo_received_on BETWEEN to_timestamp(").append(lStartDate/1000).append(") AND to_timestamp(").append(lEndDate/1000).append(") ");
			}
			sbQuery.append(" ORDER BY rm.appedo_received_on DESC LIMIT 50 ");
			//System.out.println("query : "+ query);
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("date", rst.getTimestamp("date").getTime());
				joData.put("ipaddress", rst.getString("ip_address"));
				joData.put("url", rst.getString("url"));
				joData.put("dns", rst.getLong("dns"));
				joData.put("connection", rst.getString("connection"));
				joData.put("ttfb", rst.getLong("ttfb"));
				joData.put("response", rst.getLong("response"));
				joData.put("dom", rst.getLong("dom"));
				joData.put("loadTime", rst.getLong("load_time"));
				joData.put("totalTime", rst.getLong("total_time"));
				jaRUMDatas.add(joData);
			}
			
		} catch (Throwable th) {
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jaRUMDatas;
	}
	
	public JSONObject getDailyVisitorsCountWithDateRange(Connection con, long lUID, String strFromStartInterval, String strToInterval) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		String strFormatAppedoReceivedOn = "";
		
		ArrayList<JSONObject> alDailyVisitorsCount = new ArrayList<JSONObject>();

		JSONObject joResult = new JSONObject(), joData = null;
		
		try {
			if( Long.parseLong(strToInterval) - Long.parseLong(strFromStartInterval) <= 3600000 ) {
				// for last 1 hour, grouped minute wise
				strFormatAppedoReceivedOn = "date_trunc('minute', appedo_received_on)";
			} else if( Long.parseLong(strToInterval) - Long.parseLong(strFromStartInterval) <= 86400000 ) {
				// for Last 24 hours interval, grouped hour wise 
				strFormatAppedoReceivedOn = "date_trunc('hour', appedo_received_on)";
			} else {
				// for other(greater) than Last 1 hour & 24 hours interval, grouped date wise
				strFormatAppedoReceivedOn = "appedo_received_on::date";
			}
			sbQuery	.append("SELECT ").append(strFormatAppedoReceivedOn).append(" AS appedo_received_on_formatted, count(*) AS daily_visitor_count ")
					.append("FROM rum_collector_").append(lUID).append(" ")
					.append("where appedo_received_on::timestamp")
					.append(" between to_timestamp("+Long.parseLong(strFromStartInterval)+"/1000)")
					.append(" and to_timestamp("+Long.parseLong(strToInterval)+"/1000)")
					.append(" AND (nt_domcomp <> 0 AND nt_nav_st <> 0) ")
					.append("GROUP BY appedo_received_on_formatted ")
					.append("ORDER BY appedo_received_on_formatted ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joData = new JSONObject();
				joData.put("T", rst.getTimestamp("appedo_received_on_formatted").getTime());
				joData.put("V", rst.getLong("daily_visitor_count"));
				
				alDailyVisitorsCount.add(joData);
			}
			joResult.put("dailyVisitorsCount", alDailyVisitorsCount);
			
		} catch (Exception e) {
			System.out.println("Exception in getDailyVisitorsCountWithDateRange: "+e.getMessage());
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strFormatAppedoReceivedOn = null;
			alDailyVisitorsCount = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joResult;
	}

	public JSONArray getRUMSiteDetails(Connection con, LoginUserBean loginBean) throws Exception {
		PreparedStatement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject json = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery	.append("select uid, module_name, guid,description, created_on, modified_on from module_master where user_id = ?  and module_code = 'RUM' ORDER BY created_on desc");
			stmt = con.prepareStatement(sbQuery.toString());
			stmt.setLong(1, loginBean.getUserId());
			rst = stmt.executeQuery();
			while( rst.next() ){
				json = new JSONObject();
				json.put("uid",rst.getLong("uid"));
				json.put("moduleName",rst.getString("module_name"));
				json.put("guid", rst.getString("guid"));
				json.put("description", rst.getString("description"));
				json.put("created_on", rst.getTimestamp("created_on").getTime());
				json.put("created_by", loginBean.getFirstName());
				json.put("modified_on", rst.getTimestamp("modified_on") != null ? rst.getTimestamp("modified_on").getTime() : null);
				jsonArray.add(json);
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			json = null;
			sbQuery = null;
		}
		return jsonArray;
	}

	public JSONArray getRUMSiteTransDetails(Connection con, long lUID,String type, JSONObject joEnterprise) throws Exception{
		PreparedStatement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject json = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery.append("select * from get_rum_cardlayout_v2(");
				if(joEnterprise.getInt("e_id") != 0){
					sbQuery.append(joEnterprise.getInt("e_user_id")).append(", '");
				}else{
					sbQuery.append(lUID).append(", '");
				}
			sbQuery .append(type).append("', ")
					.append(joEnterprise.getInt("e_id")).append(")");
				
			stmt = con.prepareStatement(sbQuery.toString());
			rst = stmt.executeQuery();
			while( rst.next() ){
				json = new JSONObject();
				json.put("uid",rst.getLong("uid"));
				json.put("visitor_count",rst.getLong("visitor_count"));
				json.put("max_page_load", rst.getLong("max_page_load"));
				jsonArray.add(json);
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			json = null;
			sbQuery = null;
		}
		return jsonArray;
	
	}

	public JSONArray getRUMAgentStatus(Connection con, long lUID) throws Exception{
		PreparedStatement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject json = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery.append("select * from get_ci_cardlayout(")
					.append(lUID).append(")");
			stmt = con.prepareStatement(sbQuery.toString());
			rst = stmt.executeQuery();
			while( rst.next() ){
				json = new JSONObject();
				json.put("uid",rst.getLong("uid"));
				json.put("rum_status",rst.getBoolean("active"));
				jsonArray.add(json);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			json = null;
			sbQuery = null;
		}
		return jsonArray;
	
	}
	
	public JSONArray getRUMDashDonut(Connection con,String interval,String moduleType, String uid) throws Exception {
		PreparedStatement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject json = null;
		StringBuilder sbQuery = new StringBuilder();
		String type = null;
		try {
			switch(moduleType){
				case "Browser" :
					sbQuery.setLength(0);
					sbQuery.append("select browser_name, count(*) as cnt from rum_collector_")
						.append(uid).append(" where appedo_received_on > now() - interval")
						.append(" '"+interval+"' group by browser_name order by cnt desc");
					type = "browser_name";
				break;
				case "DeviceType" :
					sbQuery.setLength(0);
					sbQuery.append("select device_type, count(*) as cnt from rum_collector_")
						.append(uid).append(" where appedo_received_on > now() - interval")
						.append(" '"+interval+"' group by device_type order by cnt desc");
					type = "device_type";
				break;
				case "OS" :
					sbQuery.setLength(0);
					sbQuery.append("select os, count(*) as cnt from rum_collector_")
						.append(uid).append(" where appedo_received_on > now() - interval")
						.append(" '"+interval+"' group by os order by cnt desc");
					type = "os";
				break;
				case "DEVICE_NAME" :
					sbQuery.setLength(0);
					sbQuery	.append("SELECT merchant_name as merchant, count(*) as cnt ")
							.append("FROM rum_collector_").append(uid).append(" ")
							.append("WHERE appedo_received_on >= now() - INTERVAL '").append(interval).append("' ")
							.append("GROUP BY merchant ")
							.append("ORDER BY cnt DESC ");
					type = "merchant";
				break;
				//default :
				//	throw new IllegalArgumentException("Invalid Module Type "+moduleType);
			}
			stmt = con.prepareStatement(sbQuery.toString());
			rst = stmt.executeQuery();
			int i =0 ;
			Long othersCnt = 0l;
			while( rst.next() ){
				if(i < 3){
					json = new JSONObject();
					Long count = rst.getLong("cnt");
					if(count == null){
						count = 0l;
					}
					json.put("label",rst.getString(type));
					json.put("value",count);
					jsonArray.add(json);
					i++;
				}
				else{
					othersCnt = othersCnt + rst.getLong("cnt");
				}
			}
			if(othersCnt > 0){
				json = new JSONObject();
				json.put("label","others");
				json.put("value",othersCnt);
				jsonArray.add(json);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst=null;
			DataBaseManager.close(stmt);
			stmt=null;
			json = null;
			sbQuery = null;
			type = null;
		}
		return jsonArray;
	
	}
	
	public JSONArray getRUMDashArea(Connection con, String interval, String uid) throws Exception{
		PreparedStatement stmt = null;
		ResultSet rst = null;
		JSONArray jsonArray = new JSONArray();
		JSONArray jsonChildArray = new JSONArray();
		StringBuilder sbQuery = new StringBuilder();
		try {
			
			sbQuery.append("select appedo_received_on,count(*) as cnt from rum_collector_")
				   .append(uid).append(" where appedo_received_on > now() - interval")
				   .append(" '"+interval+"' group by appedo_received_on order by appedo_received_on");
			stmt = con.prepareStatement(sbQuery.toString());
			rst = stmt.executeQuery();
			while( rst.next() ){
					jsonChildArray = new JSONArray();
					Long count = rst.getLong("cnt");
					if(count == null){
						count = 0l;
					}
					jsonChildArray.add(rst.getTimestamp("appedo_received_on").getTime());
					jsonChildArray.add(count);
					jsonArray.add(jsonChildArray);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt=null;
			jsonChildArray = null;
			sbQuery = null;
		}
		
		return jsonArray;
	}
	
	/**
	 * gets lastReceivedOn for particular RUM moduleName
	 * 
	 * @param con
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public long getRUMLastReceivedOn(Connection con, long lUID) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		long lLastReceivedOn = 0L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT max(appedo_received_on) AS last_appedo_received_on ")
					.append("FROM rum_collector_").append(lUID);
			/*
			-- 
			SELECT appedo_received_on 
			FROM rum_collector_265 
			ORDER BY appedo_received_on DESC 
			LIMIT 1;
			*/

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				lLastReceivedOn = rst.getTimestamp("last_appedo_received_on").getTime();
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lLastReceivedOn;
	}
	
	public String getRumAvgPageLoadTimeDonutCount(Connection con, LoginUserBean loginUserBean,String interval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		String donutCount = null;
		Date dateLog = LogManager.logMethodStart();
		try {
			strQuery = "SELECT * FROM get_rum_avg_page_load_time_donut_count(?,?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, interval);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				donutCount = rst.getString("get_rum_avg_page_load_time_donut_count");
			}
			
		} catch (Exception e) {
			donutCount =null;
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return donutCount;
	}
	
	public String getRumUrlWisePageView(Connection con, LoginUserBean loginUserBean,String interval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		String barChart = null;
		Date dateLog = LogManager.logMethodStart();
		try {
			strQuery = "SELECT * FROM get_rum_url_view_count(?,?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, interval);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				barChart = rst.getString("get_rum_url_view_count");
			}
			
		} catch (Exception e) {
			barChart =null;
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return barChart;
	}
	
	/**
	 * gets RUM's most time taken responses, based on Browser, City, Device or Os 
	 * 
	 * @param con
	 * @param lUId
	 * @param strType
	 * @param strTypeValue
	 * @param strInterval
	 * @param lStartDateTimeInMills
	 * @param lEndDateTimeInMills
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getTopRUMResponses(Connection con, long lUId, String strType, String strTypeValue, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder(), sbTypeWiseCondition = null;
		
		JSONArray jaTopRUMResponses = null;
		JSONObject joTopRUMResponse = null;
		
		try {
			jaTopRUMResponses = new JSONArray();
			
			if ( ! strType.equals("CITY") ) {
				// for BROWSER, DEVICE, OS
				sbTypeWiseCondition = new StringBuilder();
				switch(strType) {
					case "BROWSER": 
						sbTypeWiseCondition.append("translate(browser_name, '0123456789', '') = '").append(strTypeValue).append("' ");
					break;
					case "DEVICE": 
						sbTypeWiseCondition.append("device_type = '").append(strTypeValue).append("' ");
					break;
					case "OS": 
						sbTypeWiseCondition.append("os = '").append(strTypeValue).append("' ");
					break;
					case "PAGE_VIEWS_GRAPH": 
						sbTypeWiseCondition.append("1 = 1 ");
					break;
				}
				
				sbQuery	.append("SELECT rc.rum_id, rc.ip_address, rc.received_on, ")
						.append("  (rc.nt_dns_end - rc.nt_dns_st) AS dns, (rc.nt_con_end - rc.nt_con_st) AS connection, (rc.nt_res_st - rc.nt_req_st) AS ttfb, ")
						.append("  (rc.nt_res_end - rc.nt_res_st) AS receive_time, (rc.nt_domcomp - rc.nt_domloading) AS dom_loading, ")
						.append("  (rc.nt_load_end - rc.nt_load_st) AS rendering, (rc.nt_red_end - rc.nt_red_st) AS redirect ")
						.append("FROM rum_collector_").append(lUId).append(" rc ");
				if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
					sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
							.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
							.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
				}
				sbQuery	.append("WHERE ").append(sbTypeWiseCondition).append(" ")
						.append("  AND (rc.nt_domcomp - rc.nt_nav_st) > 0 AND (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
				if ( strInterval != null ) {
					sbQuery	.append("  AND rc.received_on > now() - interval '").append(strInterval).append("' ");
				} else {
					// converts into minutes
					sbQuery	.append("  AND rc.received_on >= to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND rc.received_on < to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
				}
				sbQuery	.append("ORDER BY (rc.nt_domcomp - rc.nt_nav_st) DESC ")
						.append("LIMIT 10 ");
			} else {
				// for Location
				sbQuery	.append("SELECT rc.rum_id, rc.ip_address, rc.received_on, ")
						.append("  (rc.nt_dns_end - rc.nt_dns_st) AS dns, (rc.nt_con_end - rc.nt_con_st) AS connection, (rc.nt_res_st - rc.nt_req_st) AS ttfb, ")
						.append("  (rc.nt_res_end - rc.nt_res_st) AS receive_time,(rc.nt_domcomp - rc.nt_domloading) AS dom_loading, ")
						.append("  (rc.nt_load_end - rc.nt_load_st) AS rendering, (rc.nt_red_end - rc.nt_red_st) AS redirect, ")
						.append("  ilc.city_name ")
						.append("FROM rum_collector_").append(lUId).append(" rc ")
						.append("INNER JOIN ip_location_master ilc ON ilc.ipaddress = rc.ip_address ");
				if ( strHealthCode != null && (strHealthCode.equals("WARNING") || strHealthCode.equals("CRITICAL")) ) {
					sbQuery	.append("INNER JOIN so_rum_threshold_breach_").append(lUserId).append(" srtb ON rc.uid = srtb.uid ")
							.append("  AND rc.received_on = srtb.received_on AND rc.rum_id = srtb.rum_id ")
							.append("  AND srtb.breached_severity = '").append(strHealthCode).append("' ");
				}
				sbQuery	.append("WHERE (ilc.city_name = '").append(strTypeValue).append("' OR ('Others' = '").append(strTypeValue).append("' AND (ilc.city_name = '-' OR ilc.city_name IS NULL))) ")
						.append("  AND (rc.nt_domcomp - rc.nt_nav_st) > 0 AND (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0) ");
				if ( strInterval != null ) {
					sbQuery	.append("  AND rc.received_on > now() - interval '").append(strInterval).append("' ");
				} else {
					// converts into minutes
					sbQuery	.append("  AND rc.received_on >= to_timestamp(").append(lStartDateTimeInMills/1000).append(") AND rc.received_on < to_timestamp(").append(lEndDateTimeInMills/1000).append(") ");
				}
				sbQuery	.append("ORDER BY (rc.nt_domcomp - rc.nt_nav_st) DESC ")
						.append("LIMIT 10 ");
			}
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joTopRUMResponse = new JSONObject();
				joTopRUMResponse.put("ipAddress", rst.getString("ip_address"));
				joTopRUMResponse.put("receivedOn", rst.getTimestamp("received_on").getTime());
				joTopRUMResponse.put("dns", rst.getLong("dns"));
				joTopRUMResponse.put("connection", rst.getLong("connection"));
				joTopRUMResponse.put("ttfb", rst.getLong("ttfb"));
				joTopRUMResponse.put("receiveTime", rst.getLong("receive_time"));
				joTopRUMResponse.put("domLoading", rst.getLong("dom_loading"));
				joTopRUMResponse.put("rendering", rst.getLong("rendering"));
				
				jaTopRUMResponses.add(joTopRUMResponse);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			UtilsFactory.clearCollectionHieracy(sbTypeWiseCondition);
			sbTypeWiseCondition = null;
		}
		
		return jaTopRUMResponses;
	}
}
