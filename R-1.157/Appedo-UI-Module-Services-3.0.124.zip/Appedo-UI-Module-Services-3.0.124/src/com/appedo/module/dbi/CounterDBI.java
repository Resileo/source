package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.manager.LogManager;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class CounterDBI {

	/**
	 * Creating dynamic application counter table
	 * 
	 * @param con
	 * @param lApplicationId
	 * @throws Exception
	 */
	/*public void createCounterMasterTable(Connection con, long lId) throws Exception {
		
		PreparedStatement pstmt = null;
		Statement stmt1 = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery .append("create table counter_master_")
					.append(lId)
					.append(" (counter_id serial NOT NULL,")
					.append("counter_template_id bigint NOT NULL references counter_template(counter_template_id),")
					.append("user_id bigint NOT NULL,")
					.append("guid character varying(100) NOT NULL,")
					//.append("query_string character varying(100),")
					.append("query_string character varying(500),")
					.append("execution_type character varying(50) NOT NULL,")
					.append("counter_name character varying(100),")
					.append("category character varying(100),")
					.append("instance_name character varying(100),")
					.append(" is_selected boolean NOT NULL DEFAULT false,")
					.append("is_agent_updated boolean NOT NULL DEFAULT false,")
					.append("is_enabled boolean NOT NULL DEFAULT false,")
					.append("has_instance boolean NOT NULL DEFAULT false,")
					.append(" modified_on timestamp without time zone,")
					.append(" modified_by bigint,")
					.append("last_date_sent_to_agent timestamp without time zone,")
					.append("show_in_graph boolean NOT NULL DEFAULT false,")
					.append("created_on timestamp without time zone NOT NULL,")
					.append(" created_by bigint NOT NULL,")
					.append(" CONSTRAINT counter_master_")
					.append(lId)
					.append("_pkey PRIMARY KEY (counter_id)")
					.append(");");
			
			
			/**.append("_pkey PRIMARY KEY (counter_id),")
			.append("CONSTRAINT uqe_counter_master_")
			.append(lId)
			.append("_counter_id UNIQUE (counter_template_id)")
			.append(")");** /
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.execute();
			
			stmt1 = con.createStatement();
			stmt1.executeUpdate("ALTER SEQUENCE counter_master_"+lId+"_counter_id_seq RESTART WITH 100001");
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}*/
	
	/**
	 * Getting application master counters
	 * 
	 * @param con
	 * @param nVersionId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCounterTemplateValues(Connection con, int nVersionId) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaApplicationCounters = new JSONArray();
		JSONObject joApplicationCounter = null;
		
		try {
			
			//sbQuery	.append("select * from counter_template ct left join agentversionmaster avm on ct.module_type_id=avm.agent_version_id where ct.module_type_id = ?");
					
//			sbQuery	.append("SELECT countertemplate.* from counter_template countertemplate ")
//					.append("LEFT JOIN counter_type_version ctv on countertemplate.counter_type_id = ctv.counter_type_version_id ")
//					.append("LEFT JOIN counter_type ct on ct.counter_type_id = ctv.counter_type_id ")
//					.append("WHERE ctv.counter_type_version_id = ?");
					
			sbQuery .append("select * from counter_template ct ")
					.append("INNER JOIN counter_template_version ctv on ctv.counter_template_id = ct.counter_template_id ")
					.append("where ctv.counter_type_version_id = ? AND is_enabled=true");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, nVersionId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joApplicationCounter = new JSONObject();
				joApplicationCounter.put("counterId", rst.getInt("counter_template_id"));
				joApplicationCounter.put("queryString", rst.getString("query_string"));
				joApplicationCounter.put("executionType", rst.getString("execution_type"));
				joApplicationCounter.put("category", rst.getString("category"));
				joApplicationCounter.put("counterName", rst.getString("counter_name"));
				joApplicationCounter.put("isDefault", rst.getBoolean("is_default"));
				joApplicationCounter.put("is_enabled", rst.getBoolean("is_enabled"));
				joApplicationCounter.put("has_instance", rst.getBoolean("has_instance"));
				
				jaApplicationCounters.add(joApplicationCounter);
				joApplicationCounter = null;
			}
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
		
		return jaApplicationCounters;
	}
	/**
	 * Inserting into application dynamic counter table
	 * @param con
	 * @param joMasterCounter
	 * @param lApplicatonID
	 * @param loginUserBean
	 * @throws Exception
	 */
	/*public void insertCounterMasterTable(Connection con, JSONObject joMasterCounter, long lID, LoginUserBean loginUserBean) throws Exception {
		
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery .append("insert into counter_master_")
					.append(lID)
					.append("( counter_template_id, ")
					.append("user_id , ")
					.append("guid , ")
					.append("query_string , ")
					.append("execution_type , ")
					.append("counter_name, ")
					.append("category , ")
					.append("is_selected, ")
					.append("last_date_sent_to_agent, ")
					.append("created_on, ")
					.append("created_by, ")
					.append("has_instance, ")
					.append("is_enabled) ")
					.append("values(?, ?, ?, ?, ?, ?, ?, ?, now(), now(), ?, ?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, Integer.parseInt(joMasterCounter.getString("counterId")));
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, joMasterCounter.getString("guid"));
			pstmt.setString(4, joMasterCounter.getString("queryString"));
			pstmt.setString(5, joMasterCounter.getString("executionType"));
			pstmt.setString(6, joMasterCounter.getString("counterName"));
			pstmt.setString(7, joMasterCounter.getString("category"));
			pstmt.setBoolean(8, joMasterCounter.getBoolean("isDefault"));
			pstmt.setLong(9, loginUserBean.getUserId());
			pstmt.setBoolean(10, joMasterCounter.getBoolean("has_instance"));
			pstmt.setBoolean(11, joMasterCounter.getBoolean("is_enabled"));
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}*/
	
	/**
	 * Getting application categories
	 * 
	 * @param con
	 * @param nApplicationId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCategory(Connection con, int nId) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaAPCounters = new JSONArray();
		JSONObject joAPCounter = null;
		
		try {
			sbQuery .append("select distinct(category) from counter_master_")
					.append(nId)
					.append(" ORDER BY category");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joAPCounter = new JSONObject();
				joAPCounter.put("category", rs.getString("category"));
				
				jaAPCounters.add(joAPCounter);
				joAPCounter = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
			joAPCounter = null;
			
		}
		return jaAPCounters;
	}
	
	/**
	 * Getting application counters
	 * @param con
	 * @param nApplicationID
	 * @param strCategory
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCounters(Connection con, long nID) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaAPPCounters = new JSONArray();
		JSONObject joAPPCounter = null;
		
		try {
				sbQuery .append("select * from counter_master_")
				.append(nID)
				.append(" WHERE is_enabled = true")
				.append(" ORDER BY category, counter_name");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joAPPCounter = new JSONObject();
				joAPPCounter.put("counter_id", rs.getInt("counter_id"));
				String strPvt = (rs.getBoolean("public"))?"":"(Pvt)";
				joAPPCounter.put("name", rs.getString("counter_name")+strPvt);
				joAPPCounter.put("isDefault", rs.getBoolean("is_selected"));
				joAPPCounter.put("isSelected", rs.getBoolean("is_selected"));
				joAPPCounter.put("category", rs.getString("category"));
				joAPPCounter.put("showCounter", false);
				joAPPCounter.put("isPublic", rs.getBoolean("public"));
				jaAPPCounters.add(joAPPCounter);
				joAPPCounter = null;
				strPvt = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
			joAPPCounter = null;
		}
		return jaAPPCounters;
	}
	
	/**
	 * Updating application counters
	 * 
	 * @param con
	 * @param nApplicationId
	 * @param joCounter
	 * @throws Exception
	 */
	/*public void updateCounters(Connection con, String strCounterIds, long lUId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			/*if(joCounter.getBoolean("isSelected")){
				sbQuery .append("UPDATE counter_master_")
				.append(lUId)
				.append(" set is_selected=?, ")
				.append("is_agent_updated = true, ")
				.append("modified_on = now(), ")
				.append(" modified_by = created_by")
				.append(" where counter_id=? AND ")
				.append("counter_name = ? ");
			}else{
				sbQuery .append("UPDATE counter_master_")
				.append(lUId)
				.append(" set is_selected=?, ")
				.append("modified_on = now(), ")
				.append(" modified_by = created_by")
				.append(" where counter_id=? AND ")
				.append("counter_name = ? ");
			}
					
			
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setBoolean(1, joCounter.getBoolean("isDefault"));
			pstmt.setBoolean(1, joCounter.getBoolean("isSelected"));
			pstmt.setInt(2, joCounter.getInt("counter_id"));
			pstmt.setString(3, joCounter.getString("name"));* /
			
			sbQuery	.append("UPDATE counter_master_").append(lUId).append(" SET ")
					.append("is_selected = (CASE  WHEN counter_id IN (").append(strCounterIds).append(") THEN TRUE  ELSE FALSE END), ")
					.append("is_agent_updated = (CASE  WHEN counter_id IN (").append(strCounterIds).append(") THEN TRUE  ELSE FALSE END), ")
					.append("modified_on = now(), ")
					.append("modified_by = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}*/
	
	public JSONArray getCounterVersions(Connection con, String strModuleType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joVersion = null;
		JSONArray jaVersions = new JSONArray();
		
		try{
			sbQuery .append("select * from counter_type ct left join counter_type_version ctv on  ctv.counter_type_id = ct.counter_type_id where ct.counter_type_name = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strModuleType);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joVersion = new JSONObject();
				joVersion.put("versionName", rs.getString("version"));
				joVersion.put("versionId", rs.getString("counter_type_version_id"));
				jaVersions.add(joVersion);
				joVersion = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(rs);
			rs = null;
			sbQuery = null;
		}
		return jaVersions;
	}
	
	/*public void deleteCounterMasterTable(Connection con, long lId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery .append("drop table counter_master_")
					.append(lId);
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.execute();
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}*/
	
	public JSONArray getSelectedCounters(Connection con, long lUId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONObject joCounter = null;
		JSONArray jaCounters = new JSONArray();
		
		try{
			sbQuery .append("SELECT * FROM counter_master_").append(lUId).append(" ")
					.append("WHERE is_selected = true ")
					.append("ORDER BY counter_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while(rst.next()){
				joCounter = new JSONObject();
				joCounter.put("counter_id", rst.getInt("counter_id"));
				joCounter.put("query", rst.getString("query_string"));
				joCounter.put("executiontype", rst.getString("execution_type"));
				joCounter.put("isdelta", rst.getBoolean("is_delta"));
				joCounter.put("isTopProcess", rst.getBoolean("is_top_process"));
				
				jaCounters.add(joCounter);
				joCounter = null;
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jaCounters;
	}
}
