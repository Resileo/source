package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TimeZone;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.SUMLicenseBean;
import com.appedo.module.bean.SUMTestBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;
import com.appedo.utils.CryptManager;

public class SUMDBI {

	private static final SimpleDateFormat monthDayYearformatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

	/**
	 * Gets SUM tests done
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMTests(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		String strToday = "", strStartDate = "", strEndDate = "";
		
		Timestamp tsStartDate = null, tsEndDate = null;
		
		boolean bTestStatus = false;
		
		DateFormat df =  new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date date = new Date(), dateToday = null;

		JSONArray jaSUMTests = new JSONArray();
		JSONObject joSUMTest = null;
		
		try {
			strQuery = "SELECT * FROM get_sum_tests(?)";

			monthDayYearformatter.setTimeZone(TimeZone.getTimeZone("UTC"));
			strToday = monthDayYearformatter.format(new Timestamp(date.getTime()));
			dateToday = df.parse(strToday);
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joSUMTest = new JSONObject();

				bTestStatus = rst.getBoolean("status");
				
				joSUMTest.put("testid", rst.getString("test_id"));
				joSUMTest.put("testname", rst.getString("testname"));
				joSUMTest.put("testtype", rst.getString("testtype"));
				joSUMTest.put("testurl", rst.getString("testurl"));
				joSUMTest.put("testtransaction", rst.getString("testtransaction"));
				joSUMTest.put("trasnactionImports", rst.getString("trasnaction_imports"));
				joSUMTest.put("runevery", rst.getString("runevery"));
				joSUMTest.put("cities", rst.getString("cities"));
				joSUMTest.put("clusters", rst.getString("cluster_ids"));
				joSUMTest.put("originalstatus", bTestStatus);
				joSUMTest.put("modifiedOn", ((Timestamp) UtilsFactory.replaceNull(rst.getTimestamp("modified_on"), rst.getTimestamp("created_on"))).getTime());
				joSUMTest.put("createdOn", ((Timestamp) rst.getTimestamp("created_on")).getTime());

				tsStartDate = rst.getTimestamp("start_date");
				strStartDate = tsStartDate.toString();
				strStartDate = strStartDate.replace(" ", "T");
				strStartDate = strStartDate + "00Z";
				joSUMTest.put("startdate", strStartDate);

				tsEndDate = rst.getTimestamp("end_date");
				strEndDate = tsEndDate.toString();
				strEndDate = strEndDate.replace(" ", "T");
				strEndDate = strEndDate + "00Z";
				joSUMTest.put("enddate", strEndDate);
				
				if ( ! bTestStatus ) {
					// for Test status Disabled, to show as `Disabled`					
					joSUMTest.put("status", "Disabled");
				} else {
					if (tsStartDate.before(dateToday) && dateToday.before(tsEndDate)) {
						joSUMTest.put("status", "Running");
					} else if (tsStartDate.equals(dateToday) || tsEndDate.equals(dateToday)) {
						joSUMTest.put("status", "Running");
					} else if (tsStartDate.after(dateToday)) {
						joSUMTest.put("status", "Scheduled");
					} else if (dateToday.after(tsEndDate)) {
						joSUMTest.put("status", "Completed");
					}
				}
				
				jaSUMTests.add(joSUMTest);
				
				joSUMTest = null;
				strStartDate = null;
				strEndDate = null;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			strQuery = null;
		}
		
		return jaSUMTests;
	}
	
	public JSONArray getNewSUMTests(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = "";
		String strStartDate = "", strEndDate = "";

		Timestamp tsStartDate = null, tsEndDate = null;

		boolean bTestStatus, availabilityTestStatus, smsAlert, emailAlert, repeatView = false;

		JSONArray jaSUMTests = new JSONArray();
		JSONObject joSUMTest = null;

		String browserDetails = null;
		try {
			strQuery = "SELECT * FROM get_new_sum_tests(?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joSUMTest = new JSONObject();

				bTestStatus = rst.getBoolean("status");
				availabilityTestStatus = rst.getBoolean("enable_availability_monitor");
				smsAlert = rst.getBoolean("smsalert");
				emailAlert = rst.getBoolean("emailalert");
				repeatView = rst.getBoolean("repeatView");

				joSUMTest.put("testid", rst.getString("test_id"));
				joSUMTest.put("testname", rst.getString("testname"));
				joSUMTest.put("testtype", rst.getString("testtype"));
				joSUMTest.put("testurl", rst.getString("testurl"));
				joSUMTest.put("testtransaction", rst.getString("testtransaction"));
				joSUMTest.put("trasnactionImports", rst.getString("trasnaction_imports"));
				joSUMTest.put("runevery", rst.getString("runevery"));
				joSUMTest.put("cities", rst.getString("cities"));
				joSUMTest.put("clusters", rst.getString("cluster_ids"));
				joSUMTest.put("originalstatus", bTestStatus);

				joSUMTest.put("connectionid", rst.getInt("connection_id"));
				joSUMTest.put("connectionname", rst.getString("connectionname"));
				joSUMTest.put("downloadlimit", rst.getInt("download"));
				joSUMTest.put("uploadlimit", rst.getInt("upload"));
				joSUMTest.put("latencylimit", rst.getInt("latency"));
				joSUMTest.put("packetloss", rst.getInt("packet_loss"));

				joSUMTest.put("smsalert", smsAlert);
				joSUMTest.put("emailalert", emailAlert);
				joSUMTest.put("warning", rst.getInt("warning"));
				joSUMTest.put("error", rst.getInt("error"));
				joSUMTest.put("rm_minbreachcount", rst.getInt("rm_minbreachcount"));
				joSUMTest.put("am_minbreachcount", rst.getInt("am_minbreachcount"));
				joSUMTest.put("repeatView", repeatView);
				joSUMTest.put("downtimeAlert", rst.getBoolean("downtimeAlert"));
				joSUMTest.put("rmSlaId", rst.getLong("rm_sla_id"));
				joSUMTest.put("amSlaId", rst.getLong("am_sla_id"));

				joSUMTest.put("modifiedOn", ((Timestamp) UtilsFactory.replaceNull(rst.getTimestamp("modified_on"), rst.getTimestamp("created_on"))).getTime());
				joSUMTest.put("createdOn", ((Timestamp) rst.getTimestamp("created_on")).getTime());
				//joSUMTest.put("status", "Disabled");
				tsStartDate = rst.getTimestamp("start_date");
				strStartDate = tsStartDate.toString();
				strStartDate = strStartDate.replace(" ", "T");
				strStartDate = strStartDate + "00Z";
				joSUMTest.put("startdate", strStartDate);

				tsEndDate = rst.getTimestamp("end_date");
				strEndDate = tsEndDate.toString();
				strEndDate = strEndDate.replace(" ", "T");
				strEndDate = strEndDate + "00Z";
				joSUMTest.put("enddate", strEndDate);

				if ( ! bTestStatus ) {
					// for Test status Disabled, to show as `Disabled`					
					joSUMTest.put("status", "Disabled");
				} else {
					joSUMTest.put("status", rst.getString("teststatus"));
				}

				if( joSUMTest.getString("testtype").equals("TRANSACTION") ) {
					joSUMTest.put("availabilityTestStatus", "N/A");
				} else if ( ! availabilityTestStatus ) {
					joSUMTest.put("availabilityTestStatus", "Disabled");
				} else {
					joSUMTest.put("availabilityTestStatus", rst.getString("teststatus"));
				}

				browserDetails = getSUMBrowserDetailsBySUMTestId(con, joSUMTest.getInt("testid"));
				if(browserDetails!=null){
					joSUMTest.put("browserDetails", browserDetails);
				}

				joSUMTest.put("enableAvailabilityMonitor", rst.getBoolean("enable_availability_monitor"));
				joSUMTest.put("availabilityMonitorFrequency", rst.getInt("availability_monitor_frequency"));

				jaSUMTests.add(joSUMTest);

				joSUMTest = null;
				strStartDate = null;
				strEndDate = null;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			strQuery = null;
		}
		
		return jaSUMTests;
	}

	/**
	 * Getting available cities along with cluster_id in eum_cluster_master
	 * 
	 * @param con
	 * @param strCountry
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserCities(Connection con, String strCountry) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		JSONObject joCountries = null;
		JSONArray jaReturn = new JSONArray();
		try {
			sbQuery.append("SELECT  city FROM sum_node_details where country='").append(strCountry).append("' group by city ORDER BY sum_node_details.city ASC");
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while (rst.next()) {
				joCountries = new JSONObject();
				joCountries.put("city", rst.getString("city"));
				jaReturn.add(joCountries);
				joCountries = null;
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return jaReturn;
	}

	/**
	 * Getting available cities along with cluster_id in eum_cluster_master
	 * 
	 * @param con
	 * @param strCountry
	 * @return
	 * @throws Exception
	 */
	public JSONArray getNodeCities(Connection con, String strCountry, ArrayList<String> alConfigCities) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		JSONObject joCountries = null;
		JSONArray jaReturn = new JSONArray();
		try {
			sbQuery.append("SELECT  city FROM sum_node_details where country='").append(strCountry).append("' group by city ORDER BY sum_node_details.city ASC");
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while (rst.next()) {
				joCountries = new JSONObject();
				if (alConfigCities.contains(rst.getString("city"))) {
					joCountries.put("isSelected", true);
				} else {
					joCountries.put("isSelected", false);
				}
				joCountries.put("city", rst.getString("city"));
				jaReturn.add(joCountries);
				joCountries = null;
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return jaReturn;
	}

	/**
	 * to get configured locations for given test id
	 * 
	 * @param con
	 * @param lTestid
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> getConfigTestCities(Connection con, long lTestid)
			throws Exception {

		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		ArrayList<String> alReturn = new ArrayList<String>();
		try {
			sbQuery.append(
					"select stm.test_id,split_part(stcm.location,'--', 2) as location from sum_test_master stm inner join sum_test_cluster_mapping stcm on stm.test_id=stcm.test_id where stm.test_id=")
					.append(lTestid);
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while (rst.next()) {
				alReturn.add(rst.getString("location"));
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return alReturn;

	}

	/**
	 * Changes the status of test to false for the mentioned test_id
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmtMapping = null, pstmtHarfiles = null,pstmtDob = null;

		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery.append("DELETE FROM sum_test_master WHERE test_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, testBean.getTestId());
			pstmt.executeUpdate();

			sbQuery = new StringBuilder();
			sbQuery.append("DELETE FROM sum_test_cluster_mapping WHERE test_id = ?");
			pstmtMapping = con.prepareStatement(sbQuery.toString());
			pstmtMapping.setLong(1, testBean.getTestId());
			pstmtMapping.executeUpdate();

			sbQuery = new StringBuilder();
			sbQuery.append("DELETE FROM sum_har_test_results WHERE test_id = ?");
			pstmtHarfiles = con.prepareStatement(sbQuery.toString());
			pstmtHarfiles.setLong(1, testBean.getTestId());
			pstmtHarfiles.executeUpdate();
			
			sbQuery = new StringBuilder();
			sbQuery.append("DELETE FROM sum_test_device_os_browser WHERE sum_test_id = ?");
			pstmtDob = con.prepareStatement(sbQuery.toString());
			pstmtDob.setLong(1, testBean.getTestId());
			pstmtDob.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtMapping);
			pstmtMapping = null;
			DataBaseManager.close(pstmtHarfiles);
			pstmtHarfiles = null;
			DataBaseManager.close(pstmtDob);
			pstmtDob = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	public void deleteMyChartDetails(Connection con, long lTestId, long lUserId) throws Exception {
		PreparedStatement pstmtDetails = null, pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.append("DELETE FROM chart_view_details WHERE module_or_test_id = ?");
			pstmtDetails = con.prepareStatement(sbQuery.toString());
			pstmtDetails.setLong(1, lTestId);
			pstmtDetails.executeUpdate();
			
			sbQuery.setLength(0);
			sbQuery.append("DELETE FROM chart_view WHERE chart_view_id NOT IN(SELECT chart_view_id FROM chart_view_details) AND user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmtDetails);
			pstmtDetails = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	/**
	 * Getting available countries in eum_cluster_master
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getNodes(Connection con, long lTestId) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		JSONObject joCountries = null;
		JSONArray jaCities = null;
		JSONArray jaReturn = new JSONArray();
		ArrayList<String> alReturn = new ArrayList<String>();
		try {

			alReturn = getConfigTestCities(con, lTestId);

			sbQuery.append("SELECT country FROM sum_node_details group by country ORDER BY sum_node_details.country ASC");

			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while (rst.next()) {
				joCountries = new JSONObject();
				jaCities = new JSONArray();
				joCountries.put("country", rst.getString("country"));

				jaCities = getNodeCities(con, rst.getString("country"),
						alReturn);
				joCountries.put("cities", jaCities.toString());
				jaReturn.add(joCountries);
				joCountries = null;
				jaCities = null;
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);

		}
		return jaReturn;
	}

	/**
	 * Getting available countries in eum_cluster_master
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserCountries(Connection con) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		JSONObject joCountries = null;
		JSONArray jaCities = null;
		JSONArray jaReturn = new JSONArray();
		try {
			sbQuery.append("SELECT country FROM sum_node_details group by country ORDER BY sum_node_details.country ASC");

			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while (rst.next()) {
				joCountries = new JSONObject();
				jaCities = new JSONArray();
				joCountries.put("country", rst.getString("country"));

				jaCities = getUserCities(con, rst.getString("country"));
				joCountries.put("cities", jaCities.toString());
				jaReturn.add(joCountries);
				joCountries = null;
				jaCities = null;
			}
		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return jaReturn;
	}

	public JSONObject getLicenseSUMDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONObject joLicenseDetails = new JSONObject();

		try {
			if( loginUserBean.getLicense().equalsIgnoreCase("level0")){
				sbQuery	.append("SELECT u.created_on AS start_date, sum_desktop_max_measurements as max_measurement_per_day, sum_max_cities_per_test AS max_location, s.max_retention_in_days as max_retention ")
						.append("FROM usermaster u INNER JOIN sum_config_parameters s ON s.lic_internal_name = u.license_level WHERE user_id = ? ");
			} else {
				sbQuery	.append("SELECT MIN(start_date) AS start_date, MAX(end_date) AS end_date, SUM(sum_desktop_max_measurements) AS max_measurement_per_day, ")
						.append("SUM(sum_max_cities_per_test) AS max_location, s.max_retention_in_days AS max_retention ")
						.append("FROM userwise_lic_monthwise u INNER JOIN sum_config_parameters s ON s.lic_internal_name = u.license_level WHERE user_id = ? AND ")
						.append("module_type = 'SUM' AND start_date::date <= now()::date AND end_date::date >= now()::date GROUP BY max_retention");
			}

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();

			if (rst.next()) {
				if( rst.getString("start_date")!= null ){
					joLicenseDetails.put("max_location", rst.getInt("max_location"));
					joLicenseDetails.put("max_measurement_per_day", rst.getLong("max_measurement_per_day"));
					joLicenseDetails.put("lic_internal_name", loginUserBean.getLicense());
					joLicenseDetails.put("max_retention_in_days", rst.getInt("max_retention"));
				}
			}
		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return joLicenseDetails;
	}

	public int getMaxTestCount(Connection con, LoginUserBean loginUserBean)
			throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		Timestamp startTime = null;
		int nUserTotalRuncount = 0;

		try {
			if (!loginUserBean.getLicense().equals("level0")) {
				startTime = getUserLicenseDetails(con, loginUserBean);
				if (startTime != null) {
					sbQuery .append("SELECT count(*) as user_total_runcount ")
							.append("FROM sum_test_master ")
							.append("WHERE user_id = ? AND created_on ")
							.append("BETWEEN ?::timestamp AND ?::timestamp + interval '1 month' ")
							.append("GROUP BY user_id ");

					pstmt = con.prepareStatement(sbQuery.toString());
					pstmt.setLong(1, loginUserBean.getUserId());
					pstmt.setTimestamp(2, startTime);
					pstmt.setTimestamp(3, startTime);
				} 
			} else {
				sbQuery .append("SELECT count(*) as user_total_runcount ")
						.append("FROM sum_test_master ")
						.append("WHERE user_id = ? AND created_on ")
						.append("BETWEEN date_trunc('month', CURRENT_DATE) AND date_trunc('month', CURRENT_DATE) + interval '1month' - interval '1day'")
						.append("GROUP BY user_id ");

				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setLong(1, loginUserBean.getUserId());
			}
			rst = pstmt.executeQuery();
			if (rst.next()) {
				nUserTotalRuncount = rst.getInt("user_total_runcount");
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			startTime = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}

		return nUserTotalRuncount;
	}

	private Timestamp getUserLicenseDetails(Connection con,
			LoginUserBean loginUserBean) {
		ResultSet rst = null;
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		Timestamp startTime = null;
		try {
			if (!loginUserBean.getLicense().equals("level0")) {
				// For Paid User
				sbQuery.append(
						"SELECT start_date, end_date FROM userwise_lic_monthwise WHERE user_id = ? AND ")
						.append("module_type = 'SUM' AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			} else {
				// For Free User
				sbQuery.append(
						"SELECT created_on AS start_date FROM usermaster WHERE user_id = ? ");
			}
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if (rst.next()) {
				startTime = rst.getTimestamp("start_date");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return startTime;
	}

	public int getMaxNodeCount(Connection con, LoginUserBean loginUserBean)
			throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		String testIds = null;
		boolean isFirst = true;
		int nUserTotalRuncount = 0;
		Timestamp startTime = null;

		try {
			sbQuery.append("SELECT test_id ").append("FROM sum_test_master ")
					.append("WHERE user_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				if (isFirst) {
					testIds = String.valueOf("'" + rst.getInt("test_id") + "'");
					isFirst = false;
				} else {
					testIds = testIds + ","
							+ String.valueOf("'" + rst.getInt("test_id") + "'");
				}
			}

			startTime = getUserLicenseDetails(con, loginUserBean);

			if (startTime != null) {
				nUserTotalRuncount = getMaxNodeCountForUser(con, startTime,
						testIds, loginUserBean);
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			startTime = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}

		return nUserTotalRuncount;
	}

	private int getMaxNodeCountForUser(Connection con, Timestamp startTime,
		String testIds, LoginUserBean loginUserBean) {
		ResultSet rstCount = null;
		Statement pstmtCount = null;
		StringBuilder sbQuery = new StringBuilder();
		int nUserTotalRuncount = 0;
		try {
			if(!loginUserBean.getLicense().equals("level0")){
				sbQuery .append("SELECT count(*) as node_total_runcount ")
						.append("FROM sum_har_test_results ")
						.append("WHERE test_id IN (" + testIds + ") AND received_on ")
						.append("BETWEEN '" + startTime + "'::timestamp AND '" + startTime + "'::timestamp + interval '1 month' ");
			} else {
				sbQuery .append("SELECT count(*) as node_total_runcount ")
						.append("FROM sum_har_test_results ")
						.append("WHERE test_id IN (" + testIds + ") AND received_on ")
						.append("BETWEEN date_trunc('month', CURRENT_DATE) AND date_trunc('month', CURRENT_DATE) + interval '1month' - interval '1day'");
			}

			pstmtCount = con.createStatement();
			rstCount = pstmtCount.executeQuery(sbQuery.toString());
			if (rstCount.next()) {
				nUserTotalRuncount = rstCount.getInt("node_total_runcount");
			}

		} catch (Exception e) {
			LogManager.errorLog(e);

		} finally {
			DataBaseManager.close(rstCount);
			rstCount = null;
			DataBaseManager.close(pstmtCount);
			pstmtCount = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}

		return nUserTotalRuncount;
	}
	
	public int getMaxMeasuermentCountForUser(Connection con, LoginUserBean loginUserBean) {
		ResultSet rstCount = null;
		PreparedStatement pstmtCount = null;
		StringBuilder sbQuery = new StringBuilder();
		int nUserTotalRuncount = 0;
		try {
			sbQuery	.append("SELECT sum_measurements_used_today as node_total_runcount ")
					.append("FROM usermaster WHERE user_id = ? ");
			pstmtCount = con.prepareStatement(sbQuery.toString());
			pstmtCount.setLong(1, loginUserBean.getUserId());
			rstCount = pstmtCount.executeQuery();
			if (rstCount.next()) {
				nUserTotalRuncount = rstCount.getInt("node_total_runcount");
			}

		} catch (Exception e) {
			LogManager.errorLog(e);

		} finally {
			DataBaseManager.close(rstCount);
			rstCount = null;
			DataBaseManager.close(pstmtCount);
			pstmtCount = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}

		return nUserTotalRuncount;
	}

	/**
	 * SUM Test existence checking for add
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isSUMTestExist(Connection con, SUMTestBean testBean,
			LoginUserBean loginUserBean) throws Exception {

		boolean flag = isSUMTestExist(con, testBean, loginUserBean, false);

		return flag;
	}

	/**
	 * SUM Test existence checking for update
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @param bExcludeThis
	 * @return
	 * @throws Exception
	 */
	public boolean isSUMTestExist(Connection con, SUMTestBean testBean,
			LoginUserBean loginUserBean, Boolean bExcludeThis) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		ResultSet rst = null;
		boolean flag;
		try {
			sbQuery.append(
					"SELECT test_id, true from sum_test_master where lower(testname)=LOWER(?) ")
					.append("AND user_id=? and is_delete=false ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, testBean.getTestName());
			pstmt.setLong(2, loginUserBean.getUserId());

			rst = pstmt.executeQuery();

			if (rst.next()) {
				if (bExcludeThis != null && bExcludeThis == true
						&& rst.getInt("test_id") == testBean.getTestId()) {
					flag = false;
				} else {
					flag = true;
				}
			} else {
				flag = false;
			}

		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return flag;
	}

	public SUMLicenseBean getSUMUserWiseLicenseMonthWise(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null;
		ResultSet rst = null, rst1 = null;

		StringBuilder sbQuery = new StringBuilder();

		SUMLicenseBean sumLicenseBean = null;

		try {
			
			sbQuery .append("SELECT EXISTS(SELECT 1 FROM userwise_lic_monthwise  WHERE user_id = ? AND start_date::date <= now()::date AND end_date::date >= now()::date LIMIT 1) as record_exists");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			sbQuery.setLength(0);
			if(rst.next() && rst.getBoolean("record_exists")){
				// For PAID user
				sbQuery .append("SELECT user_id, start_date, end_date, sum_desktop_max_measurements, sum_mobile_max_measurements ")
						.append("FROM userwise_lic_monthwise ")
						.append("WHERE user_id = ? AND module_type = 'SUM' ")
						.append("AND start_date::date <= now()::date AND end_date::date >= now()::date ");
			}else{
				// For FREE user
				sbQuery	.append("SELECT user_id, created_on AS start_date, sum_desktop_max_measurements, sum_mobile_max_measurements ")
						.append("FROM usermaster ")
						.append("WHERE user_id = ? ");
			}
			

			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.setLong(1, loginUserBean.getUserId());
			rst1 = pstmt1.executeQuery();
			if (rst1.next()) {
				sumLicenseBean = new SUMLicenseBean();

				sumLicenseBean.setUserId(rst1.getLong("user_id"));
				sumLicenseBean.setStartDate(rst1.getString("start_date"));
				if(rst.next() && rst.getBoolean("record_exists"))
					sumLicenseBean.setEndDate(rst1.getString("end_date"));
				sumLicenseBean.setMaxDesktopMeasurements(rst1.getInt("sum_desktop_max_measurements"));
				sumLicenseBean.setMaxMobileMeasurements(rst1.getInt("sum_mobile_max_measurements"));
			}

		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return sumLicenseBean;
	}

	/**
	 * Adds clusters into sum_test_cluster_mapping
	 * 
	 * @param con
	 * @param lTestId
	 * @param alClusters
	 * @throws Exception
	 */
	public void addClusters(Connection con, long lTestId,
			HashSet<String> hsClusters) throws Exception {
		Statement stmt = null;
		String strLocation = null;

		try {
			stmt = con.createStatement();
			Iterator<String> iter = hsClusters.iterator();
			while (iter.hasNext()) {
				strLocation = iter.next();
				stmt.addBatch("insert into sum_test_cluster_mapping(test_id,location) values("
						+ lTestId + ", '" + strLocation + "');");
				strLocation = null;
			}
			int res[] = stmt.executeBatch();
			LogManager.infoLog(Arrays.toString(res));
		} catch (Exception e) {
			LogManager.errorLog(e);

			if (e instanceof SQLException) {
				SQLException sqlExcpNext = null;
				while ((sqlExcpNext = ((SQLException) e).getNextException()) != null) {
					LogManager.errorLog(sqlExcpNext);
				}
				sqlExcpNext = null;
			}

			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
		}

	}

	/**
	 * Updates the SUM URL's testing status
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSUMTestFileName(Connection con, SUMTestBean testBean,
			LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery.append("UPDATE sum_test_master SET ")
					.append("testfilename = ? ").append("WHERE test_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());

			pstmt.setString(1, testBean.getTestClassName());
			pstmt.setLong(2, testBean.getTestId());
			pstmt.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}

	/**
	 * Adds SUM URL to be tested
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long addSUMTest(Connection con, SUMTestBean testBean,
			LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();

		long lTestId = -1l;

		try {
			/*
			 * sbQuery .append(
			 * "INSERT INTO sum_test_master (user_id, testname, testtype, testurl, testtransaction, runevery, status, created_by, created_on, start_date, end_date) "
			 * )
			 * .append("VALUES (").append(loginUserBean.getUserId()).append(", "
			 * )
			 * .append(UtilsFactory.makeValidVarchar(testBean.getTestName())).append
			 * (", ")
			 * .append(UtilsFactory.makeValidVarchar(testBean.getTestType(
			 * ))).append(", ")
			 * .append(UtilsFactory.makeValidVarchar(testBean.getURL
			 * ())).append(", ")
			 * .append(UtilsFactory.makeValidVarchar(testBean.getTransaction
			 * ())).append(", ")
			 * .append(testBean.getRunEveryMinute()).append(", ")
			 * .append(testBean.isStatus()).append(", ")
			 * .append(loginUserBean.getUserId())
			 * .append(", now()").append(", ")
			 * .append(UtilsFactory.makeValidVarchar
			 * (testBean.getStartDate())).append(", ")
			 * .append(UtilsFactory.makeValidVarchar
			 * (testBean.getEndDate())).append(")"); lTestId =
			 * DataBaseManager.insertAndReturnKey(con,sbQuery.toString());
			 */

			sbQuery .append("INSERT INTO sum_test_master (user_id, testname, testtype, testurl, testtransaction, runevery, status, created_by, created_on, start_date, end_date, trasnaction_imports, last_run_detail) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, now(), ?::timestamp, ?::timestamp, ?, (?::timestamp - CAST(?||' minute' AS Interval)))");
			pstmt = con.prepareStatement(sbQuery.toString(),
					PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, testBean.getTestName());
			pstmt.setString(3, testBean.getTestType());
			pstmt.setString(4, testBean.getURL());
			pstmt.setString(5, testBean.getTransaction());
			pstmt.setInt(6, testBean.getRunEveryMinute());
			pstmt.setBoolean(7, testBean.isStatus());
			pstmt.setLong(8, loginUserBean.getUserId());
			pstmt.setString(9, testBean.getStartDate());
			pstmt.setString(10, testBean.getEndDate());
			pstmt.setString(11, testBean.getSeleniumScriptPackages());
			pstmt.setString(12, testBean.getStartDate());
			pstmt.setInt(13, testBean.getRunEveryMinute());
			pstmt.executeUpdate();

			lTestId = DataBaseManager.returnKey(pstmt);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return lTestId;
	}

	public long addNewSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();

		long lTestId = -1l;

		try {
			sbQuery.append("INSERT INTO sum_test_master (user_id, testname, testtype, testurl, testtransaction, ")
					.append("runevery, status, created_by, created_on, start_date, end_date, trasnaction_imports, ")
					.append("connection_id, download, upload, latency, packet_loss, sms_alert, email_alert, warning, ")
					.append("error, rm_min_breach_count, am_min_breach_count, last_run_detail, repeat_view, downtime_alert, e_id) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, now(), ?::timestamp, ?::timestamp, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, (?::timestamp - CAST(?||' minute' AS Interval)), ?, ?, ?)");

			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, testBean.getTestName());
			pstmt.setString(3, testBean.getTestType());
			pstmt.setString(4, testBean.getURL());
			pstmt.setString(5, testBean.getTransaction());
			pstmt.setInt(6, testBean.getRunEveryMinute());
			pstmt.setBoolean(7, testBean.isStatus());
			pstmt.setLong(8, loginUserBean.getUserId());
			pstmt.setString(9, testBean.getStartDate());
			pstmt.setString(10, testBean.getEndDate());
			pstmt.setString(11, testBean.getSeleniumScriptPackages());
			pstmt.setInt(12, testBean.getConnectionId());
			pstmt.setInt(13, testBean.getDownloadLimit());
			pstmt.setInt(14, testBean.getUploadLimit());
			pstmt.setInt(15, testBean.getLatencyLimit());
			pstmt.setInt(16, testBean.getPacketLoss());
			if (testBean.isResponseAlert()) {
				if (testBean.isSmsAlert()) {
					pstmt.setBoolean(17, true);
				} else {
					pstmt.setBoolean(17, false);
				}

				if (testBean.isEmailAlert()) {
					pstmt.setBoolean(18, true);
				} else {
					pstmt.setBoolean(18, false);
				}

				pstmt.setInt(19, testBean.getWarningLimit());
				pstmt.setInt(20, testBean.getErrorLimit());
				pstmt.setInt(21, testBean.getRmMinBreachCount());
				pstmt.setNull(22, Types.INTEGER);

			} else {
				pstmt.setBoolean(17, false);
				pstmt.setBoolean(18, false);
				pstmt.setNull(19, Types.INTEGER);
				pstmt.setNull(20, Types.INTEGER);
				pstmt.setNull(21, Types.INTEGER);
				pstmt.setNull(22, Types.INTEGER);
			}

			pstmt.setString(23, testBean.getStartDate());
			pstmt.setInt(24, testBean.getRunEveryMinute());
			if(testBean.isRepeatView()){
				pstmt.setBoolean(25, testBean.isRepeatView());
			} else{
				pstmt.setBoolean(25, false);
			}
			pstmt.setBoolean(26, testBean.isDownTimeAlert());
			if(joEnterprise.getBoolean("is_owner") && joEnterprise.getInt("e_id") != 0){
				pstmt.setInt(27, joEnterprise.getInt("e_id"));
			}else{
				pstmt.setNull(27, java.sql.Types.INTEGER);
			}

			pstmt.executeUpdate();

			lTestId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return lTestId;
	}
	
	//To insert SUM chart data
	public void insertChartVisualizationDataSUM(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean, String query) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("INSERT INTO chart_visualization_").append(loginUserBean.getUserId())
					.append(" (chart_title, legend_text, module_type, category, location, os, browser, connection_name,  ")
					.append(" unit, chart_type, enable_mma, axis_label, sel_graph_value, xy_axis_label, ref_table_name, ref_table_pkey_id, ref_sec_table_name, query, created_by, created_on) ")
					.append(" SELECT t.testname||'::'||t.testurl, location||'-'||browser_name||'.'||sc.connection_name, 'SUM', t.testtype, location, os_name, browser_name, ")
					.append(" sc.connection_name, 'ms', 'line' , FALSE, 'ms', 'avg', 'Date Time', 'sum_test_master', ").append(testBean.getTestId())
					.append(" , t.testurl, ").append(UtilsFactory.makeValidVarchar(query)).append(" , t.user_id, now() FROM sum_test_master t ")
					.append(" INNER JOIN sum_test_cluster_mapping sm ON sm.test_id = t.test_id INNER JOIN sum_connectivity sc ON sc.connection_id = t.connection_id ")
					.append(" INNER JOIN (SELECT sum_test_id, device_os_browser_id FROM sum_test_device_os_browser GROUP BY sum_test_id, device_os_browser_id ) st ON st.sum_test_id = sm.test_id ")
					.append(" INNER JOIN sum_device_os_browser os ON st.device_os_browser_id = os.dob_id WHERE t.test_id = ").append(testBean.getTestId())
					.append(" AND t.user_id = ").append(loginUserBean.getUserId());
								
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	public void updateChartVisualizationDataSUM(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("SELECT * from update_chart_visualization_data_SUM_URL(?,?,?)");
					
			pstmt = con.prepareStatement(sbQuery.toString());					
			pstmt.setLong(1, testBean.getTestId());
			pstmt.setLong(2, loginUserBean.getUserId());
			pstmt.setString(3, testBean.getURL());
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	public void updateChartVisualizationDataSUMTestName(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean, String oldTestName) throws Exception	{
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		//long lModuleId = -1L;
		
		try {
			sbQuery.append("SELECT update_chart_visualization_SUM_test_name(?,?,?,?)");
					
			pstmt = con.prepareStatement(sbQuery.toString());					
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setLong(2, testBean.getTestId());
			pstmt.setString(3, oldTestName);
			pstmt.setString(4, testBean.getTestName());
			
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
		}
	}
	
	public void addBrowserToSUMTest(Connection con, long lTestId,String dobIds) throws Exception {
		Statement stmt = null;

		try {
			stmt = con.createStatement();
			String[] dob_Ids = dobIds.split(",");
			for (String id: dob_Ids) {           
				stmt.addBatch("insert into sum_test_device_os_browser(sum_test_id,device_os_browser_id) values("
						+ lTestId + ", '" + id + "');");
			}
			int res[] = stmt.executeBatch();
			LogManager.infoLog(Arrays.toString(res));
		} catch (Exception e) {
			LogManager.errorLog(e);

			if (e instanceof SQLException) {
				SQLException sqlExcpNext = null;
				while ((sqlExcpNext = ((SQLException) e).getNextException()) != null) {
					LogManager.errorLog(sqlExcpNext);
				}
				sqlExcpNext = null;
			}

			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
		}
	}

	public void updateSlaIdInSumTestMaster(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try {

			sbQuery.append("UPDATE sum_test_master SET response_monitor_sla_id = ? WHERE test_id = ? ");
			pstmt = con.prepareStatement(sbQuery.toString());

			pstmt.setLong(1, testBean.getRmSLAId());
			pstmt.setLong(2, testBean.getTestId());
			pstmt.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	public void updateBrowserToSUMTest(Connection con, long lTestId,String dobIds) throws Exception {
		Statement stmt = null;

		try {
			stmt = con.createStatement();
			stmt.execute("delete from sum_test_device_os_browser where sum_test_id="+ lTestId);
			String[] dob_Ids = dobIds.split(",");
			for (String id: dob_Ids) {
				stmt.addBatch("insert into sum_test_device_os_browser(sum_test_id,device_os_browser_id) values("
						+ lTestId + ", '" + id + "');");
			}
			int res[] = stmt.executeBatch();
			LogManager.infoLog(Arrays.toString(res));
		} catch (Exception e) {
			LogManager.errorLog(e);

			if (e instanceof SQLException) {
				SQLException sqlExcpNext = null;
				while ((sqlExcpNext = ((SQLException) e).getNextException()) != null) {
					LogManager.errorLog(sqlExcpNext);
				}
				sqlExcpNext = null;
			}

			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
		}
	}

	public SUMLicenseBean getSUMLicenseConfigParameters(Connection con,
			LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		SUMLicenseBean sumLicenseBean = null;

		try {
			sbQuery.append("SELECT * ").append("FROM sum_config_parameters ")
					.append("WHERE lic_internal_name = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, loginUserBean.getLicense());
			rst = pstmt.executeQuery();
			if (rst.next()) {
				sumLicenseBean = new SUMLicenseBean();

				sumLicenseBean.setLicInternalName(rst
						.getString("lic_internal_name"));
				sumLicenseBean.setLicExternalName(rst
						.getString("lic_external_name"));
				sumLicenseBean.setMaxTest(rst.getInt("max_test"));
				sumLicenseBean.setAllowTransaction(rst
						.getBoolean("allow_transaction"));
				sumLicenseBean.setAllowURL(rst.getBoolean("allow_url"));
				sumLicenseBean.setMaxLocation(rst.getInt("max_location"));

			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return sumLicenseBean;
	}

	/**
	 * Updates the SUM URL's testing status
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSUMTest(Connection con, SUMTestBean testBean,
			LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery.append("UPDATE sum_test_master SET ")
					.append("testname = ?, status = ?, testtype = ?, ")
					.append("testurl = ?, testtransaction = ?, ")
					.append("runevery = ?, ")
					.append("start_date = "
							+ UtilsFactory.makeValidVarchar(testBean
									.getStartDate()) + ", ")
					.append("end_date = "
							+ UtilsFactory.makeValidVarchar(testBean
									.getEndDate()) + ", ")
					.append("modified_by = ?, modified_on = now(), ")
					.append("trasnaction_imports = ? ")
					.append("WHERE test_id = ? ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, testBean.getTestName());
			pstmt.setBoolean(2, testBean.isStatus());
			pstmt.setString(3, testBean.getTestType());
			pstmt.setString(4, testBean.getURL());
			pstmt.setString(5, testBean.getTransaction());
			pstmt.setInt(6, testBean.getRunEveryMinute());
			pstmt.setLong(7, loginUserBean.getUserId());
			pstmt.setString(8, testBean.getSeleniumScriptPackages());
			pstmt.setLong(9, testBean.getTestId());
			pstmt.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	public void updateNewSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery	.append("UPDATE sum_test_master SET ")
					.append("testname = ?, status = ?, testtype = ?, ")
					.append("testurl = ?, testtransaction = ?, ")
					.append("runevery = ?, ")
					.append("start_date = ").append(UtilsFactory.makeValidVarchar(testBean.getStartDate())).append(", ")
					.append("end_date = ").append(UtilsFactory.makeValidVarchar(testBean.getEndDate())).append(", ")
					.append("modified_by = ?, modified_on = now(), ")
					.append("trasnaction_imports = ?, ")
					.append("connection_id = ?,download = ?,upload = ?, latency = ?, packet_loss= ?, ")
					.append("sms_alert = ?, email_alert = ?, warning= ?, error= ?, rm_min_breach_count = ?, repeat_view = ?, downtime_alert = ? ");
			
			if(testBean.isChangedStDate()){
				sbQuery.append(",last_run_detail = ").append(UtilsFactory.makeValidVarchar(testBean.getStartDate())).append("::timestamp - CAST(").append(testBean.getRunEveryMinute()).append("||' minute' AS Interval) ");
			}
			sbQuery.append("WHERE test_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, testBean.getTestName());
			pstmt.setBoolean(2, testBean.isStatus());
			pstmt.setString(3, testBean.getTestType());
			pstmt.setString(4, testBean.getURL());
			pstmt.setString(5, testBean.getTransaction());
			pstmt.setInt(6, testBean.getRunEveryMinute());
			pstmt.setLong(7, loginUserBean.getUserId());
			pstmt.setString(8, testBean.getSeleniumScriptPackages());
			
			pstmt.setInt(9, testBean.getConnectionId());
			pstmt.setInt(10, testBean.getDownloadLimit());
			pstmt.setInt(11, testBean.getUploadLimit());
			pstmt.setInt(12, testBean.getLatencyLimit());
			pstmt.setInt(13, testBean.getPacketLoss());
			if(testBean.isResponseAlert()){
				if (testBean.isSmsAlert()) {
					pstmt.setBoolean(14, true);
				} else {
					pstmt.setBoolean(14, false);
				}
				if (testBean.isEmailAlert()) {
					pstmt.setBoolean(15, true);
				} else {
					pstmt.setBoolean(15, false);

				}
				pstmt.setInt(16, testBean.getWarningLimit());
				pstmt.setInt(17, testBean.getErrorLimit());
				pstmt.setInt(18, testBean.getRmMinBreachCount());

			}else{
				pstmt.setBoolean(14, false);
				pstmt.setBoolean(15, false);
				pstmt.setInt(16, 0);
				pstmt.setInt(17, 0);
				pstmt.setInt(18, 0);
			}
			
			if(testBean.isRepeatView()){
				pstmt.setBoolean(19, testBean.isRepeatView());
			}else{
				pstmt.setBoolean(19, false);
			}
			
			pstmt.setBoolean(20, testBean.isDownTimeAlert());
			pstmt.setLong(21, testBean.getTestId());

			pstmt.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	/**
	 * Updates clusters in sum_test_cluster_mapping
	 * 
	 * @param con
	 * @param lTestId
	 * @param alClusters
	 * @throws Exception
	 */
	public void updateClusters(Connection con, long lTestId,
			HashSet<String> hsClusters) throws Exception {

		Statement stmt = null;
		String strLocation = null;
		try {
			stmt = con.createStatement();
			stmt.execute("delete from sum_test_cluster_mapping where test_id = "+lTestId);
			Iterator<String> iter = hsClusters.iterator();
			while (iter.hasNext()) {
				strLocation = iter.next();
				stmt.addBatch("insert into sum_test_cluster_mapping(test_id,location) values("+lTestId+", '"+strLocation+"')");
				strLocation = null;
			}
			int res[] = stmt.executeBatch();
			LogManager.infoLog(Arrays.toString(res));
		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
		}

	}
	
	public String getPreviousTestName(Connection con, long lTestId) throws Exception {

		Statement stmt = null;
		ResultSet rst = null;
		String strTestName = null;
		try {
			stmt = con.createStatement();
			rst = stmt.executeQuery("SELECT testname from sum_test_master where test_id ="+lTestId);
			
			if (rst.next()) {
				strTestName = rst.getString("testname");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
		}
		return strTestName;
	}

	public JSONArray getSUMMultiDropDown(Connection con, long userId)throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		try {
			String query = "select test_id,testname,testurl from sum_test_master where user_id = ? and testtype = 'URL'";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(userId + ""));
			rst = pstmt.executeQuery();
			while (rst.next()) {
				json = new JSONObject();
				json.put("testName", rst.getString("testname"));
				json.put("testid", rst.getLong("test_id"));
				json.put("testurl", rst.getString("testurl"));
				jsonArray.add(json);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			json = null;
		}
		return jsonArray;
	}

	public JSONArray getSUMMultiLine(Connection con, String strTestId, String strPageId, String strPageName, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		Map<String, LinkedHashMap<Long, String> > map = new HashMap<String, LinkedHashMap<Long, String> >();
		LinkedHashMap<Long, String> childMap = null;
		String filename = "" , key = "";
		StringBuilder queryString = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			queryString	.append("SELECT hf.received_on,hf.pageloadtime,hf.pageloadtime_repeatview,hf.location,harfilename ")
						.append("FROM sum_har_test_results hf where hf.test_id = ").append(strTestId);
			if (strPageId != "") {
				queryString.append(" and hf.page_id = '").append(strPageId).append("' AND hf.page_name = '").append(strPageName).append("' ");
			}
			if ( strInterval != null ) {
				queryString.append(" and hf.received_on > ( now() - INTERVAL '").append(strInterval).append("' ) ");
			} else {
				queryString.append("  AND hf.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills / 1000).append(") AND to_timestamp(").append(lEndDateTimeInMills / 1000).append(") ");
			}
			queryString.append("order by location,received_on ");
			

			/*
			 * String query =
			 * "SELECT hf.received_on,hf.pageLoadTime,nm.country,nm.city,harfilename FROM sum_har_test_results hf INNER JOIN sum_node_details nm ON nm.mac_address = hf.mac_address where test_id = "
			 * +testId+" and hf.received_on > ( now() - INTERVAL '"+interval+
			 * "' ) order by city,received_on"; String query =
			 * "SELECT hf.received_on,hf.pageLoadTime,nm.country,nm.city,harfilename FROM sum_har_test_results hf INNER JOIN sum_node_details nm ON nm.mac_address = hf.mac_address where test_id = "
			 * +testId+" and hf.page_id = '"+pageId+
			 * "' and hf.received_on > ( now() - INTERVAL '"
			 * +interval+"' ) order by city,received_on";
			 */
			pstmt = con.prepareStatement(queryString.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				key = rst.getString("location");
				if (!map.containsKey(key)) {
					childMap = new LinkedHashMap<Long, String>();
					map.put(key, childMap);
				}
				filename = "";
				if (rst.getString("harfilename") != null) {
					filename = Constants.APPEDO_HARFILES + "/" + strTestId + "/"
							+ rst.getString("harfilename");
				}
				/*if(rst.getString("pageloadtime_repeatview")!=null){
					childMap.put(rst.getTimestamp("received_on").getTime(),
							rst.getLong("pageloadtime_repeatview") + "," + filename);
				}else{
					childMap.put(rst.getTimestamp("received_on").getTime(),
							rst.getLong("pageloadtime") + "," + filename);
				}*/
				childMap.put(rst.getTimestamp("received_on").getTime(),
						rst.getLong("pageloadtime") + "," + filename);
			}

			for (Map.Entry<String, LinkedHashMap<Long, String> > entry : map.entrySet()) {
				json = new JSONObject();
				json.put("City", entry.getKey());
				LinkedHashMap<Long, String> cMap = entry.getValue();
				JSONArray childArray = new JSONArray();
				for (Map.Entry<Long, String> childEntry : cMap.entrySet()) {
					JSONObject childJson = new JSONObject();
					childJson.put("Date", childEntry.getKey());
					String[] values = childEntry.getValue().split(",");
					childJson.put("Value", Long.parseLong(values[0]));
					childJson.put("filename", values[1]);
					childArray.add(childJson);
				}
				json.put("Data", childArray);
				jsonArray.add(json);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			json = null;
			map = null;
			childMap = null;
			filename = null;
			queryString = null;
			key = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonArray;
	}
	
	public JSONObject getSUMChartData_v1(Connection con, Long lTestId, String strPageId, String strPageName, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String query, String location) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject joRtnData = new JSONObject();
		JSONArray jaSUMData = new JSONArray();
		StringBuilder queryString = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();

		try {
			
			if ( strInterval != null ) {
				queryString.append(" hf.received_on > ( now() - INTERVAL '").append(strInterval).append("' ) ");
			} else {
				queryString.append("  hf.received_on BETWEEN to_timestamp(").append(lStartDateTimeInMills / 1000).append(") AND to_timestamp(").append(lEndDateTimeInMills / 1000).append(") ");
			}
			
			query = query.replace("@dateFilter@", queryString.toString());
			query = query.replace("@location@", location);

			pstmt = con.prepareStatement(query);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				//joSUMData = JSONArray.fromObject(rst.getString(1));
				//rst.getString(1)
			JSONObject joData = new JSONObject();
			joData.put("Date Time" ,  rst.getLong("datetime"));
			joData.put("count", 0);
			joData.put("min", rst.getLong("min"));
			joData.put("max", rst.getLong("max"));
			joData.put("avg", rst.getLong("avg"));
			joData.put("warning", rst.getLong("warning"));
			joData.put("critical", rst.getLong("critical"));
			
			jaSUMData.add(joData);
			}
			joRtnData.put("data", jaSUMData);
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			//joRtnData = null;
			queryString = null;
			LogManager.logMethodEnd(dateLog);
		}
		return joRtnData;
	}

	public JSONObject getSUMMultiLineWithLocationBrowserConnection(Connection con, String strTestId, String strPageId, String strPageName, String strInterval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonRtn = new JSONObject();
		Map<String, LinkedHashMap<Long, String> > map = new HashMap<String, LinkedHashMap<Long, String> >();
		LinkedHashMap<Long, String> childMap = null;
		String filename = "" , key = "";
		StringBuilder queryString = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();
		try {
			queryString
					.append("SELECT id, received_on,pageloadtime,pageloadtime_repeatview,location,harfilename,location_name, browser_name,connection_name FROM sum_har_test_results where test_id = "
							+ strTestId);
			if (strPageId != "") {
				queryString.append(" and page_id = '" + strPageId +"' AND page_name = '").append(strPageName).append("' ");
			}
			queryString.append(" and received_on > ( now() - INTERVAL '"+ strInterval + "' ) order by location_name, browser_name, connection_name, received_on");

			pstmt = con.prepareStatement(queryString.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				key = rst.getString("location")+"," +rst.getString("location_name")+"," +rst.getString("browser_name")+"," +rst.getString("connection_name");
				if (!map.containsKey(key)) {
					childMap = new LinkedHashMap<Long, String>();
					map.put(key, childMap);
				}
				filename = "";
				if (rst.getString("harfilename") != null) {
					filename = Constants.APPEDO_HARFILES + "/" + strTestId + "/"
							+ rst.getString("harfilename");
				}
				
				/*if(rst.getString("pageloadtime_repeatview")!=null){
					childMap.put(rst.getTimestamp("received_on").getTime(),
							rst.getLong("pageloadtime_repeatview") + "," + filename + "," +rst.getLong("id"));
				}else{
					childMap.put(rst.getTimestamp("received_on").getTime(),
							rst.getLong("pageloadtime") + "," + filename + "," +rst.getLong("id"));
				}*/
				childMap.put(rst.getTimestamp("received_on").getTime(),
						rst.getLong("pageloadtime") + "," + filename + "," +rst.getLong("id"));
			}
			
			JSONObject jsLoc = new JSONObject(), jsBrow = new JSONObject(), jsConn = new JSONObject();
			JSONArray jaLoc = new JSONArray(), jaBrow = new JSONArray(), jaConn = new JSONArray();
			for (Map.Entry<String, LinkedHashMap<Long, String> > entry : map.entrySet()) {
				json = new JSONObject();
				String keys[] = entry.getKey().split(",");
				json.put("City", keys[0]);
				if(!jaLoc.toString().contains("\"label\":\""+keys[1]+"\"")){
					jsLoc.put("label", keys[1]);
					jaLoc.add(jsLoc);
				}
				if(!jaBrow.toString().contains("\"label\":\""+keys[2]+"\"")){
					jsBrow.put("label", keys[2]);
					jaBrow.add(jsBrow);
				}
				if(!jaConn.toString().contains("\"label\":\""+keys[3]+"\"")){
					jsConn.put("label", keys[3]);
					jaConn.add(jsConn);
				}
				json.put("locationName", keys[1]);
				json.put("browserName", keys[2]);
				json.put("connectionName", keys[3]);
				LinkedHashMap<Long, String> cMap = entry.getValue();
				JSONArray childArray = new JSONArray();
				for (Map.Entry<Long, String> childEntry : cMap.entrySet()) {
					JSONObject childJson = new JSONObject();
					childJson.put("Date", childEntry.getKey());
					String[] values = childEntry.getValue().split(",");
					childJson.put("Value", Long.parseLong(values[0]));
					childJson.put("filename", values[1]);
					childJson.put("id", Long.parseLong(values[2]));
					childArray.add(childJson);
				}
				json.put("Data", childArray);
				jsonArray.add(json);
			}
			
			jsonRtn.put("MainDetail", jsonArray);
			jsonRtn.put("LocationDetail", jaLoc);
			jsonRtn.put("BrowserDetail", jaBrow);
			jsonRtn.put("ConnectionDetail", jaConn);
			
			if(jsonArray.size()==0){
				boolean bFlag;
				bFlag = isRunning(con, Long.valueOf(strTestId));
					jsonRtn.put("isTestRunning", bFlag);
				}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			json = null;
			map = null;
			childMap = null;
			filename = null;
			queryString = null;
			key = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonRtn;
	}
	
	public JSONObject getSUMMultiLineWithDateRange(Connection con, String strTestId, String strPageId, String strPageName, String strStartDate, String strEndDate) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonRtn = new JSONObject();
		Map<String, LinkedHashMap<Long, String> > map = new HashMap<String, LinkedHashMap<Long, String> >();
		LinkedHashMap<Long, String> childMap = null;
		String filename = "" , key = "";
		StringBuilder queryString = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();
		try {
			queryString.append("SELECT id, received_on,pageloadtime,pageloadtime_repeatview,location,harfilename,location_name, browser_name,connection_name FROM sum_har_test_results where test_id = " + strTestId);
			if (strPageId != "") {
				queryString.append(" and page_id = '" + strPageId + "' AND page_name = '").append(strPageName).append("' ");
			}
			queryString	.append(" and received_on::timestamp between to_timestamp("+ Long.parseLong(strStartDate) + "/1000) ")
					.append("and to_timestamp(" + Long.parseLong(strEndDate) + "/1000) order by location,received_on");
			
			pstmt = con.prepareStatement(queryString.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				key = rst.getString("location")+"," +rst.getString("location_name")+"," +rst.getString("browser_name")+"," +rst.getString("connection_name");
				if (!map.containsKey(key)) {
					childMap = new LinkedHashMap<Long, String>();
					map.put(key, childMap);
				}
				filename = "";
				if (rst.getString("harfilename") != null) {
					filename = Constants.APPEDO_HARFILES + "/" + strTestId + "/"
							+ rst.getString("harfilename");
				}
				
				/*if(rst.getString("pageloadtime_repeatview")!=null){
					childMap.put(rst.getTimestamp("received_on").getTime(),
							rst.getLong("pageloadtime_repeatview") + "," + filename + "," +rst.getLong("id"));
				}else{
					childMap.put(rst.getTimestamp("received_on").getTime(),
							rst.getLong("pageloadtime") + "," + filename + "," +rst.getLong("id"));
				}*/
				childMap.put(rst.getTimestamp("received_on").getTime(),
						rst.getLong("pageloadtime") + "," + filename + "," +rst.getLong("id"));
			}
			
			JSONObject jsLoc = new JSONObject(), jsBrow = new JSONObject(), jsConn = new JSONObject();
			JSONArray jaLoc = new JSONArray(), jaBrow = new JSONArray(), jaConn = new JSONArray();
			for (Map.Entry<String, LinkedHashMap<Long, String> > entry : map.entrySet()) {
				json = new JSONObject();
				String keys[] = entry.getKey().split(",");
				json.put("City", keys[0]);
				if(!jaLoc.toString().contains("\"label\":\""+keys[1]+"\"")){
					jsLoc.put("label", keys[1]);
					jaLoc.add(jsLoc);
				}
				if(!jaBrow.toString().contains("\"label\":\""+keys[2]+"\"")){
					jsBrow.put("label", keys[2]);
					jaBrow.add(jsBrow);
				}
				if(!jaConn.toString().contains("\"label\":\""+keys[3]+"\"")){
					jsConn.put("label", keys[3]);
					jaConn.add(jsConn);
				}
				json.put("locationName", keys[1]);
				json.put("browserName", keys[2]);
				json.put("connectionName", keys[3]);
				LinkedHashMap<Long, String> cMap = entry.getValue();
				JSONArray childArray = new JSONArray();
				for (Map.Entry<Long, String> childEntry : cMap.entrySet()) {
					JSONObject childJson = new JSONObject();
					childJson.put("Date", childEntry.getKey());
					String[] values = childEntry.getValue().split(",");
					childJson.put("Value", Long.parseLong(values[0]));
					childJson.put("filename", values[1]);
					childJson.put("id", Long.parseLong(values[2]));
					childArray.add(childJson);
				}
				json.put("Data", childArray);
				jsonArray.add(json);
			}
			
			jsonRtn.put("MainDetail", jsonArray);
			jsonRtn.put("LocationDetail", jaLoc);
			jsonRtn.put("BrowserDetail", jaBrow);
			jsonRtn.put("ConnectionDetail", jaConn);
			
			if(jsonArray.size()==0){
				boolean bFlag;
				bFlag = isRunning(con, Long.valueOf(strTestId));
					jsonRtn.put("isTestRunning", bFlag);
				}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			json = null;
			map = null;
			childMap = null;
			filename = null;
			queryString = null;
			key = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonRtn;
	}

	private boolean isRunning(Connection con, long lTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder strQuery = new StringBuilder();
		boolean isRunning = false;
		try {
			
			strQuery.append("SELECT start_date > last_run_detail FROM sum_test_master WHERE test_id = ? ");
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setLong(1, lTestId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				isRunning = rst.getBoolean(1);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return isRunning;
	}
	
	public boolean isResultAvailable(Connection con, long lTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder strQuery = new StringBuilder();
		boolean is_exists = false;
		try {
			
			strQuery.append("SELECT EXISTS(SELECT 1 FROM sum_har_test_results hf INNER JOIN sum_node_details nm ON nm.mac_address = hf.mac_address where test_id = ? LIMIT 1) as is_exists");
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setLong(1, lTestId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				is_exists = rst.getBoolean("is_exists");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return is_exists;
	}

	public JSONArray getSumLicense(Connection con, long userId)	throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject joModule = null;
		JSONArray jaModules = new JSONArray();
		try {
			String query = "select * from get_sum_license(?)";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, Integer.parseInt(userId + ""));
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joModule = new JSONObject();
				joModule.put("lic_label", rst.getString("NAME"));
				joModule.put("lic_value", rst.getString("LIC"));

				joModule.put("smr_label", "Max Measurements");
				joModule.put("smr_value", rst.getLong("count"));
				if (rst.getLong("count") == -1) {
					joModule.put("smr_value", "Unlimited");
				}
				jaModules.add(joModule);
				/*joModule = new JSONObject();
				joModule.put("lic_label", "License Valid Till");
				joModule.put("lic_value", rst.getString("validtill"));
				jaModules.add(joModule);
				*/
				joModule = null;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			joModule = null;
		}
		return jaModules;
	}

	public JSONArray getSUMSummaryBasedOnType(Connection con, long lUserId, String strModuleCode) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = null, strLabel = null;

		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		
		try {
			strQuery = "SELECT testtype, count(*) FROM sum_test_master WHERE user_id = ? AND is_delete = false GROUP BY testtype";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1, Integer.parseInt(lUserId + ""));
			rst = pstmt.executeQuery();
			while (rst.next()) {
				json = new JSONObject();
				Long count = rst.getLong("count");
				if (count != null && count > 0) {
					// if (count == null) {
					// count = 0l;
					// }
					strLabel = rst.getString("testtype");
					if(strLabel.equalsIgnoreCase("TRANSACTION")){
						strLabel = "TRAN";
					}
					json.put("label",strLabel);
					json.put("value", count);
					jsonArray.add(json);
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			//json = null;
			
			strQuery = null;
			strLabel = null;
		}
		
		return jsonArray;
	}
	
	public JSONArray getSUMSummaryBasedOnStatus(Connection con, long lUserId, String strModuleCode) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder(); 
		
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		
		try {
			sbQuery	.append("SELECT count(CASE WHEN start_date < now() AND end_date > now() AND status = true THEN 1 ELSE NULL END) as running, ")
					.append("  count(CASE WHEN end_date < now() AND status = true THEN 1 ELSE NULL END) as completed, ")
					.append("  count(CASE WHEN start_date > now() AND status = true THEN 1 ELSE NULL END) as scheduled, ")
					.append("  count(CASE WHEN status = false THEN 1 ELSE NULL END) as Disabled ")
					.append("FROM sum_test_master ")
					.append("where user_id = ? and is_delete = false ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, Integer.parseInt(lUserId + ""));
			rst = pstmt.executeQuery();
			if (rst.next()) {
				if (rst.getLong("running") > 0) {
					json = new JSONObject();
					json.put("label", "Running");
					json.put("value", rst.getLong("running"));
					jsonArray.add(json);
				}
				if (rst.getLong("completed") > 0) {
					json = new JSONObject();
					json.put("label", "Completed");
					json.put("value", rst.getLong("completed"));
					jsonArray.add(json);
				}
				if (rst.getLong("scheduled") > 0) {
					json = new JSONObject();
					json.put("label", "Scheduled");
					json.put("value", rst.getLong("scheduled"));
					jsonArray.add(json);
				}
				if (rst.getLong("Disabled") > 0) {
					json = new JSONObject();
					json.put("label", "Disabled");
					json.put("value", rst.getLong("Disabled"));
					jsonArray.add(json);
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			//json = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jsonArray;
	}
	
	public JSONArray getSUMSummaryBasedOnMeasurement(Connection con, long lUserId, String strModuleCode) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		String strQuery = null;

		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		
		try {
			strQuery = "select * from get_sum_Donut_Mst(?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setInt(1, Integer.parseInt(lUserId + ""));
			rst = pstmt.executeQuery();
			if (rst.next()) {
				if (rst.getLong("used") >= 0) {
					json = new JSONObject();
					json.put("label", "Used");
					json.put("value", rst.getLong("used"));
					jsonArray.add(json);
				}
				if(rst.getLong("total") < 0){
					json = new JSONObject();
					json.put("label", "Total");
					json.put("value",rst.getLong("total"));
				} else {
					json = new JSONObject();
					json.put("label", "Free");
					json.put("value",rst.getLong("total") - rst.getLong("used"));
				}
				jsonArray.add(json);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			//json = null;
			
			strQuery = null;
		}
		
		return jsonArray;
	}

	public JSONArray getSUMDetailsDropDown(Connection con, long lUserId, JSONObject joEnterprise) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		PreparedStatement pstmt1 = null;
		ResultSet rst1 = null;
		
		JSONObject json = null, jsonChild = null;
		JSONArray jsonArray = new JSONArray(), jsonChildArray = new JSONArray();

		DateFormat df =  new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date date = new Date(), dateToday = null;
		
		Timestamp tsStartdate = null, tsEnddate = null;
		
		String strToday = null;
		String strQuery1 = "";
		
		StringBuilder sbQuery = new StringBuilder();
		
		boolean bTestStatus = false, bAvailabilityTestStatus = false;
		
		try {
			monthDayYearformatter.setTimeZone(TimeZone.getTimeZone("UTC"));
			strToday = monthDayYearformatter.format(new Timestamp(date.getTime()));
			dateToday = df.parse(strToday);
			
			strQuery1 = "select distinct page_id,page_name from sum_har_test_results where test_id = ? ORDER BY page_id, page_name ";
			pstmt1 = con.prepareStatement(strQuery1);
			// String query = "select test_id,testname,testtype,testurl,CASE WHEN start_date < now() AND end_date > now() THEN 'Running' WHEN end_date < now() THEN 'Completed' ELSE 'Scheduled' END as Status from sum_test_master where user_id = ?";
			// below qry, last In use
			//strQuery = "select test_id,testname,testtype,testurl,start_date,end_date,status, runevery from sum_test_master where user_id = ? ORDER BY testname ";
			
			// tried, for new SUM the selected SUM test data, in UI to have device_type & os_name above harfile
			sbQuery	.append("SELECT DISTINCT stm.test_id, stm.testname, stm.testtype, stm.testurl, stm.start_date, stm.end_date, stm.status, ")
					.append("  stm.runevery, stm.enable_availability_monitor, stm.availability_monitor_frequency, ")
					.append("  sdob.device_type, sdob.os_name ")
					.append("FROM sum_test_master stm ")
					.append("LEFT JOIN sum_test_device_os_browser stdob ON stdob.sum_test_id = stm.test_id ")
					.append("LEFT JOIN sum_device_os_browser sdob ON sdob.dob_id = stdob.device_os_browser_id WHERE stm.user_id = ? ");
					if(joEnterprise.getInt("e_id")!=0){
						sbQuery	.append("AND e_id = ").append(joEnterprise.getLong("e_id"));
					}
			sbQuery	.append(" ORDER BY testname ");
			
			System.out.println(sbQuery.toString());
			pstmt = con.prepareStatement(sbQuery.toString());
			if(joEnterprise.getInt("e_id")!=0){
				pstmt.setLong(1, joEnterprise.getLong("e_user_id"));
			}else{
				pstmt.setLong(1, lUserId);
			}
			
			rst = pstmt.executeQuery();
			while (rst.next()) {
				json = new JSONObject();
				jsonChildArray = new JSONArray();
				
				bTestStatus = rst.getBoolean("status");
				bAvailabilityTestStatus = rst.getBoolean("enable_availability_monitor");
				
				json.put("testName", rst.getString("testname"));
				json.put("testid", rst.getLong("test_id"));
				json.put("testurl", rst.getString("testurl"));
				json.put("testtype", rst.getString("testtype"));
				json.put("runEvery", rst.getLong("runevery"));
				json.put("deviceType", rst.getString("device_type"));
				json.put("osName", rst.getString("os_name"));
				json.put("enableAvailabilityMonitor", bAvailabilityTestStatus);
				json.put("availabilityMonitorFrequency", rst.getLong("availability_monitor_frequency"));
//				json.put("browserName", rst.getString("browser_name"));
//				json.put("browserVersion", rst.getString("browser_version"));
				
				tsStartdate = rst.getTimestamp("start_date");
				tsEnddate = rst.getTimestamp("end_date");
				
				if ( ! bTestStatus ) {
					json.put("status", "Disabled");
				} else {
					if (tsStartdate.before(dateToday) && dateToday.before(tsEnddate)) {
						json.put("status", "Running");
					} else if (tsStartdate.equals(dateToday) || tsEnddate.equals(dateToday)) {
						json.put("status", "Running");
					} else if (tsStartdate.after(dateToday)) {
						json.put("status", "Scheduled");
					} else if (dateToday.after(tsEnddate)) {
						json.put("status", "Completed");
					}
				}
				
				if (rst.getString("testtype").equalsIgnoreCase("TRANSACTION")) {
					jsonChildArray = new JSONArray();
					pstmt1.setLong(1, rst.getLong("test_id"));
					rst1 = pstmt1.executeQuery();
					while (rst1.next()) {
						jsonChild = new JSONObject();
						jsonChild.put("page_id", rst1.getString("page_id"));
						jsonChild.put("page_name", rst1.getString("page_name"));
						jsonChildArray.add(jsonChild);
					}
					
					json.put("availabilityTestStatus", "N/A");
				} else  if ( ! bAvailabilityTestStatus ) {
					json.put("availabilityTestStatus", "Disabled");
				} else {
					if (tsStartdate.before(dateToday) && dateToday.before(tsEnddate)) {
						json.put("availabilityTestStatus", "Running");
					} else if (tsStartdate.equals(dateToday) || tsEnddate.equals(dateToday)) {
						json.put("availabilityTestStatus", "Running");
					} else if (tsStartdate.after(dateToday)) {
						json.put("availabilityTestStatus", "Scheduled");
					} else if (dateToday.after(tsEnddate)) {
						json.put("availabilityTestStatus", "Completed");
					}
				}
				
				json.put("pageDetails", jsonChildArray);
				jsonArray.add(json);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(rst1);
			rst1 = null;
			DataBaseManager.close(pstmt1);
			pstmt1 = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strQuery1 = null;
			
			json = null;
			jsonChild = null;
			LogManager.logMethodEnd(dateLog);
		}
		return jsonArray;
	}

	public String getLocationDetailsBySUMTestId(Connection con,int sumTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"locationDetails\" from (select distinct location_name as \"locationName\" from sum_har_test_results_testing where test_id =? ORDER BY location_name ) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, sumTestId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("locationDetails");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public String getBrowserDetailsBySUMTestId(Connection con,int sumTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserDetails\" from (select distinct browser_name as \"browserName\" from sum_har_test_results_testing where test_id =? ORDER BY browser_name ) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, sumTestId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("browserDetails");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public String getConnectionDetailsBySUMTestId(Connection con,int sumTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"connectionDetails\" from (select distinct connection_name as \"connectionName\" from sum_har_test_results_testing where test_id =? ORDER BY connection_name ) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, sumTestId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("connectionDetails");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public boolean validateSUMTestName(Connection con, String strSUMTestName, long lTestId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bExists = false;
		String strQuery = "";
		try {
			strQuery = "SELECT EXISTS(SELECT 1 FROM sum_test_master WHERE lower(testname) = lower(?) AND test_id != ? AND user_id = ? LIMIT 1) as test_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strSUMTestName);
			pstmt.setLong(2, lTestId);
			pstmt.setLong(3, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				bExists = rst.getBoolean("test_exists");
			}
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
		return bExists;
	}

	public JSONArray getSUMWorldMap(Connection con, long userId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		JSONObject json = null;
		JSONArray jsonArray = new JSONArray();
		int loccount=0;
		StringBuilder sbQuery = new StringBuilder();
		try {
			sbQuery.append("SELECT sl.location_name,sl.latitude,sl.longitude,count(CASE WHEN st.start_date < now() AND st.end_date > now() AND status=true THEN 1 ELSE NULL END) as running,count(CASE WHEN st.end_date < now() OR status = false THEN 1 ELSE NULL END) as completed ");
			sbQuery.append("FROM sum_test_master st ");
			sbQuery.append("INNER JOIN sum_test_cluster_mapping stc ON st.test_id = stc.test_id ");
			sbQuery.append("INNER JOIN sum_location sl ON stc.location = ((sl.country_name || '-' || sl.state_name || '-' || sl.location_name)) ");
			sbQuery.append("WHERE st.user_id = ? AND st.is_delete = false ");
			sbQuery.append("GROUP BY stc.location,sl.location_name,sl.state_name,sl.country_name,sl.latitude,sl.longitude ");
			sbQuery.append("ORDER BY stc.location");
			
//			sbQuery.append("SELECT sl.location_name,sl.latitude,sl.longitude,count(CASE WHEN st.start_date < now() ");
//			sbQuery.append("AND st.end_date > now() AND status=true THEN 1 ELSE NULL END) as running, ");
//			sbQuery.append("count(CASE WHEN st.end_date < now() OR status = false THEN 1 ELSE NULL END) as completed ");
//			sbQuery.append("FROM sum_test_master st ");
//			sbQuery.append("INNER join sum_har_test_results stc on st.test_id = stc.test_id ");
//			sbQuery.append("INNER join sum_location sl on split_part(stc.location, ':', 1) = ((sl.country_name || '-' || sl.state_name || '-' || sl.location_name)) ");
//			sbQuery.append("WHERE st.user_id = ? and st.is_delete = false ");
//			sbQuery.append("GROUP BY split_part(stc.location, ':', 1), sl.location_name,sl.state_name,sl.country_name,sl.latitude,sl.longitude ");
//			sbQuery.append("ORDER BY  split_part(stc.location, ':', 1) ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, userId);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				loccount++;
				json = new JSONObject();
				json.put("id", loccount);
				json.put("name", rst.getString("location_name"));
				json.put("latitude", rst.getDouble("latitude"));
				json.put("longitude", rst.getDouble("longitude"));
				json.put("completed", rst.getInt("completed"));
				json.put("running", rst.getInt("running"));
				jsonArray.add(json);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			e.printStackTrace();
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			json = null;
		}
		return jsonArray;
	}

	/**
	 * thinks, gets SUM tests which has HAR results
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMTestsResults(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		String strToday = "", strStartDate = "", strEndDate = "";
		
		Timestamp tsStartDate = null, tsEndDate = null;
		
		boolean bTestStatus = false;
		
		DateFormat df =  new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		Date date = new Date(), dateToday = null;
		
		JSONArray jaSUMTests = new JSONArray();
		JSONObject joSUMTest = null;
		
		try {
			strQuery = "SELECT * FROM getsumtestsresults(?)";
			
			monthDayYearformatter.setTimeZone(TimeZone.getTimeZone("UTC"));
			strToday = monthDayYearformatter.format(new Timestamp(date.getTime()));
			dateToday = df.parse(strToday);
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joSUMTest = new JSONObject();
				
				bTestStatus = rst.getBoolean("status");
				
				joSUMTest.put("test_id", rst.getString("test_id"));
				joSUMTest.put("testname", rst.getString("testname"));
				joSUMTest.put("testtype", rst.getString("testtype"));
				joSUMTest.put("testurl", rst.getString("testurl"));
				joSUMTest.put("testtransaction", rst.getString("testtransaction"));
				joSUMTest.put("runevery", rst.getString("runevery"));
				joSUMTest.put("cities", rst.getString("cities"));
				joSUMTest.put("clusters", rst.getString("cluster_ids"));
				joSUMTest.put("originalstatus", bTestStatus);
				
				tsStartDate = rst.getTimestamp("start_date");
				strStartDate = tsStartDate.toString();
				strStartDate = strStartDate.replace(" ", "T");
				strStartDate = strStartDate+"00Z";
				joSUMTest.put("startdate", strStartDate);
				
				tsEndDate = rst.getTimestamp("end_date");
				strEndDate = tsEndDate.toString();
				strEndDate = strEndDate.replace(" ", "T");
				strEndDate = strEndDate+"00Z";
				joSUMTest.put("enddate", strEndDate);
				
				if ( ! bTestStatus ) {
					// for Test status Disabled, to show as `Disabled`
					joSUMTest.put("status", "Disabled");
				} else {
					if (tsStartDate.before(dateToday) && dateToday.before(tsEndDate)) {
						joSUMTest.put("status", "Running");
					} else if (tsStartDate.equals(dateToday) || tsEndDate.equals(dateToday)) {
						joSUMTest.put("status", "Running");
					} else if (tsStartDate.after(dateToday)) {
						joSUMTest.put("status", "Scheduled");
					} else if (dateToday.after(tsEndDate)) {
						joSUMTest.put("status", "Completed");
					}
				}
				
				/*
				if( joSUMTest.getString("testtype").equals("TRANSACTION") ) {
					joSUMTest.put("availabilityTestStatus", "N/A");
				} else  if ( ! bAvailabilityTestStatus ) {
					joSUMTest.put("availabilityTestStatus", "Disabled");
				} else {
					if (tsStartDate.before(dateToday) && dateToday.before(tsEndDate)) {
						joSUMTest.put("availabilityTestStatus", "Running");
					} else if (tsStartDate.equals(dateToday) || tsEndDate.equals(dateToday)) {
						joSUMTest.put("availabilityTestStatus", "Running");
					} else if (tsStartDate.after(dateToday)) {
						joSUMTest.put("availabilityTestStatus", "Scheduled");
					} else if (dateToday.after(tsEndDate)) {
						joSUMTest.put("availabilityTestStatus", "Completed");
					}
				}
				*/
				
				jaSUMTests.add(joSUMTest);
				
				joSUMTest = null;
				strStartDate = null;
				strEndDate = null;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaSUMTests;
	}
	
	/**
	 * gets SUM test's transaction's pages
	 * 
	 * @param con
	 * @param lTestId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMTestPages(Connection con, Long lTestId) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONArray jaSUMTests = new JSONArray();
		JSONObject joSUMTest = null;

		//SUM_CHART_START_INTERVAL sum_chart_start_interval = SUM_CHART_START_INTERVAL.valueOf("_"+strFromStartInterval);
		
		try {
			sbQuery	.append("SELECT * FROM getsumtestpages(").append(lTestId).append(")");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while (rst.next()) {
				joSUMTest = new JSONObject();
				joSUMTest.put("testId", rst.getString("test_id"));
				joSUMTest.put("pageId", rst.getString("page_id"));
				joSUMTest.put("pageName", rst.getString("page_name"));

				jaSUMTests.add(joSUMTest);
				joSUMTest = null;
			}

		} catch (Exception e) {
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}

		return jaSUMTests;
	}
	
	/**
	 * gets available SUM nodes, private nodes configured by a user also retrieved 
	 * 
	 * @param con
	 * @param lTestId
	 * @param lUserId
	 * @param dobId 
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMNodes(Connection con, long lTestId, long lUserId, String dobId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		LinkedHashMap<String, ArrayList<JSONObject>> lhmNodes = new LinkedHashMap<String, ArrayList<JSONObject>>();
		ArrayList<JSONObject> alCities = null;
		
		JSONArray jaNodes = new JSONArray();
		JSONObject joNode = null, joCity = null;
		
		String strCountry = "", strState = "", strCity = "";
		
		try {
			sbQuery.append("SELECT * FROM get_sum_nodes_with_location_status_sample(?, ?, ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lTestId);
			pstmt.setLong(2, lUserId);
			pstmt.setString(3, dobId);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				strCountry = rst.getString("country");
				strState = rst.getString("state");
				strCity = rst.getString("city");

				joCity = new JSONObject();
				joCity.put("city", strCity);
				joCity.put("isSelected", rst.getBoolean("is_selected"));
				joCity.put("canAgentAcceptTest", rst.getBoolean("can_agent_accept_test"));
				
				if ( lhmNodes.containsKey(strCountry) ) {
					alCities = lhmNodes.get(strCountry);
				} else {
					alCities = new ArrayList<JSONObject>();
					lhmNodes.put(strCountry, alCities);
				}
				// thinks, obj by ref
				alCities.add(joCity);
			}
			
			Iterator itNodes = lhmNodes.entrySet().iterator();
			while (itNodes.hasNext()) {
				Map.Entry<String, ArrayList<JSONObject>> pair = (Map.Entry<String, ArrayList<JSONObject>>)itNodes.next();
				strCountry = pair.getKey();
				alCities = pair.getValue();
				
				joNode = new JSONObject();
				joNode.put("country", strCountry);
				joNode.put("cities", alCities);
				jaNodes.add(joNode);
				
				itNodes.remove();
			}
			
			strCountry = null;
			strState = null;
			strCity = null;
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		
		return jaNodes;
	}
	
	public void saveQuickSUMDetails(Connection con, HashMap<String, String> joQuickSUMDetails) throws Exception {
		
		StringBuilder sbQuery = new StringBuilder();
		PreparedStatement pstmt = null;
		try {

			sbQuery .append("INSERT INTO demo_sum_test_master (url, email_id, company_name, phone_number, sum_test_id, created_on) ")
					.append("VALUES (?, ?, ?, ?, ?, now())");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, joQuickSUMDetails.get("url"));
			pstmt.setString(2, joQuickSUMDetails.get("email_id"));
			pstmt.setString(3, joQuickSUMDetails.get("company_name"));
			pstmt.setString(4, joQuickSUMDetails.get("phone_number"));
			pstmt.setLong(5, Long.valueOf(joQuickSUMDetails.get("sum_test_id")));
			pstmt.executeUpdate();

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public JSONArray getQuickSUMNodes(Connection con, String strDeviceType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONArray jaNodes = new JSONArray();
		JSONObject joCity = null;

		try {
			if (strDeviceType.equalsIgnoreCase("Desktop")) {
				sbQuery.append("SELECT country, state, city FROM sum_node_details WHERE is_default_desktop = true");
			} else {
				sbQuery.append("SELECT country, state, city FROM sum_node_details WHERE is_default_mobile = true");
			}

			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joCity = new JSONObject();
				joCity.put("city", rst.getString("country") + " - " + rst.getString("city"));
				joCity.put("location", rst.getString("country") + "--" + rst.getString("city"));
				jaNodes.add(joCity);
				joCity = null;
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}

		return jaNodes;
	}
	
	public String getSUMDeviceTypes(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"deviceTypes\" from (select distinct(device_type) as \"deviceType\",is_default as \"isDefault\" FROM sum_device_os_browser order by is_default) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("deviceTypes");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public String getSUMOsNames(Connection con,String deviceType) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"osNames\" from (select distinct(os_name) as \"osName\",is_default as \"isDefault\" FROM sum_device_os_browser where device_type = ? order by is_default) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, deviceType);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("osNames");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public String getSUMBrowserNames(Connection con,String deviceType,String osName) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserNames\" from (select dob_id as \"dobId\",device_type as \"deviceType\",os_name as \"osName\",browser_name as \"browserName\" FROM sum_device_os_browser where device_type = ? and os_name = ? order by is_default) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, deviceType);
			pstmt.setString(2, osName);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("browserNames");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public String getSUMBrowserDetailsBySUMTestId(Connection con,int sumTestId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
//			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserDetails\" from (select sdob.dob_id as \"dobId\",sdob.device_type as \"deviceType\",sdob.os_name as \"osName\",sdob.browser_name as \"browserName\" FROM sum_device_os_browser  as sdob ,sum_test_device_os_browser  as stdob  where sdob.dob_id = stdob.device_os_browser_id and stdob.sum_test_id = ? order by sdob.is_default) t");
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"browserDetails\" from (select sdob.dob_id as \"dobId\",sdob.device_type as \"deviceType\",sdob.os_name as \"osName\",sdob.browser_name as \"browserName\",true as \"isSelected\" FROM sum_device_os_browser  as sdob ,sum_test_device_os_browser  as stdob  where sdob.dob_id = stdob.device_os_browser_id and stdob.sum_test_id = ? order by sdob.is_default) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, sumTestId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("browserDetails");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public String getSUMConnectivity(Connection con) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		String jsonString = null;
		try {
			sbQuery.append("select array_to_json(array_agg(row_to_json(t))) as \"connectivity\" from (select connection_id as \"connectionId\", display_name as \"displayName\", connection_name as \"connectionName\",download as \"downloadLimit\",upload as \"uploadLimit\",latency as \"latencyLimit\",packet_loss as \"packetLoss\",is_default as \"isDefault\",is_active as \"isActive\" FROM sum_connectivity where is_active = true order by is_default) t");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				jsonString = rst.getString("connectivity");
			}	
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jsonString;
	}

	public JSONObject ishavingSUMURLTest(Connection con, String strUrl, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joSUMURLTest = null;
		
		try {
			joSUMURLTest = new JSONObject();
			
			sbQuery .append("SELECT true as isExist, stm.test_id FROM demo_sum_test_master  dstm ")
					.append("INNER JOIN sum_test_master stm ON dstm.sum_test_id = stm.test_id AND stm.user_id = ? AND lower(dstm.url) similar to '%(")
					.append(strUrl.substring(strUrl.indexOf("//")))
					.append("%)'");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				joSUMURLTest.put("ishavingurl", rst.getBoolean("isExist"));
				joSUMURLTest.put("sum_test_id", CryptManager.encryptEncodeURL(rst.getLong("test_id")+""));
			} else {
				joSUMURLTest.put("ishavingurl", false);
			}
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joSUMURLTest;
	}
	

	public JSONObject getSUMTestDetails(Connection con, long lSUMTestId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joSUMTestDetails = null;
		
		try {
			sbQuery.append("SELECT * FROM sum_test_master WHERE test_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lSUMTestId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				joSUMTestDetails = new JSONObject();

				joSUMTestDetails.put("testid", rst.getString("test_id"));
				joSUMTestDetails.put("testname", rst.getString("testname"));
				joSUMTestDetails.put("testtype", rst.getString("testtype"));
				joSUMTestDetails.put("testurl", rst.getString("testurl"));
				joSUMTestDetails.put("testtransaction", rst.getString("testtransaction"));
				joSUMTestDetails.put("trasnactionImports", rst.getString("trasnaction_imports"));
				joSUMTestDetails.put("runevery", rst.getString("runevery"));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joSUMTestDetails;
	}
	
	public String getSumAvgPageLoadTimeDonutCount(Connection con, LoginUserBean loginUserBean,String interval) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		String donutCount = null;
		Date dateLog = LogManager.logMethodStart();
		try {
			strQuery = "SELECT * FROM get_sum_avg_page_load_time_donut_count(?,?)";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, loginUserBean.getUserId());
			pstmt.setString(2, interval);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				donutCount = rst.getString("get_sum_avg_page_load_time_donut_count");
			}
			
		} catch (Exception e) {
			donutCount =null;
			LogManager.errorLog("Problem in getSumAvgPageLoadTimeDonutCount : "+e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			strQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return donutCount;
	}
	
	public JSONArray getFirstByte(Connection con, long lharId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		Date dateLog = LogManager.logMethodStart();
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joHarResults = null;
		JSONObject joHarResultsRview = null;
		JSONArray jaModules = new JSONArray();
		try {
			sbQuery	.append("select trunc((json_result->'run'->'firstView'->'results'->>'loadTime')::numeric/1000,3) AS loadTime, ")
					.append("trunc((json_result->'run'->'firstView'->'results'->>'TTFB')::numeric/1000,3) AS TTFB, ")
					.append("trunc((json_result->'run'->'firstView'->'results'->>'render')::numeric/1000,3) AS render, ")
					.append("json_result->'run'->'firstView'->'results'->>'domElements' AS domElements, ")
					.append("trunc((json_result->'run'->'firstView'->'results'->>'docTime')::numeric/1000,3) AS docTime, ")
					.append("json_result->'run'->'firstView'->'results'->>'requestsDoc' AS requestsDoc, ")
					.append("round(((json_result->'run'->'firstView'->'results'->>'bytesInDoc')::numeric/1024)::numeric) AS bytesInDoc, ")
					.append("trunc((json_result->'run'->'firstView'->'results'->>'fullyLoaded')::numeric/1000,3) AS fullyLoaded, ")
					.append("json_result->'run'->'firstView'->'results'->>'requests' AS requests, ")
					.append("round(((json_result->'run'->'firstView'->'results'->>'bytesIn')::numeric/1024)::numeric) AS bytesIn, ")
					
					.append("trunc((json_result->'run'->'repeatView'->'results'->>'loadTime')::numeric/1000,3) AS rloadTime, ")
					.append("trunc((json_result->'run'->'repeatView'->'results'->>'TTFB')::numeric/1000,3) AS rTTFB, ")
					.append("trunc((json_result->'run'->'repeatView'->'results'->>'render')::numeric/1000,3) AS rrender, ")
					.append("json_result->'run'->'repeatView'->'results'->>'domElements' AS rdomElements, ")
					.append("trunc((json_result->'run'->'repeatView'->'results'->>'docTime')::numeric/1000,3) AS rdocTime, ")
					.append("json_result->'run'->'repeatView'->'results'->>'requestsDoc' AS rrequestsDoc, ")
					.append("round(((json_result->'run'->'repeatView'->'results'->>'bytesInDoc')::numeric/1024)::numeric) AS rbytesInDoc, ")
					.append("trunc((json_result->'run'->'repeatView'->'results'->>'fullyLoaded')::numeric/1000,3) AS rfullyLoaded, ")
					.append("json_result->'run'->'repeatView'->'results'->>'requests' AS rrequests, ")
					.append("round(((json_result->'run'->'repeatView'->'results'->>'bytesIn')::numeric/1024)::numeric) AS rbytesIn ")
					
					.append("from sum_har_test_results where id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lharId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				joHarResults = new JSONObject();
				joHarResults.put("category", "FirstView");
				joHarResults.put("loadTime", rst.getString("loadTime"));
				joHarResults.put("TTFB", rst.getString("TTFB"));
				joHarResults.put("render", rst.getString("render"));
				joHarResults.put("domElements", rst.getString("domElements"));
				joHarResults.put("docTime", rst.getString("docTime"));
				joHarResults.put("requestsDoc", rst.getString("requestsDoc"));
				joHarResults.put("bytesInDoc", rst.getString("bytesInDoc"));
				joHarResults.put("fullyLoaded", rst.getString("fullyLoaded"));
				joHarResults.put("requests", rst.getString("requests"));
				joHarResults.put("bytesIn", rst.getString("bytesIn"));
				jaModules.add(joHarResults);
				
				if (!(rst.getString("rloadTime") == null)) {
					joHarResultsRview = new JSONObject();
					joHarResultsRview.put("category", "RepeatView");
					joHarResultsRview.put("loadTime", rst.getString("rloadTime"));
					joHarResultsRview.put("TTFB", rst.getString("rTTFB"));
					joHarResultsRview.put("render", rst.getString("rrender"));
					joHarResultsRview.put("domElements", rst.getString("rdomElements"));
					joHarResultsRview.put("docTime", rst.getString("rdocTime"));
					joHarResultsRview.put("requestsDoc", rst.getString("rrequestsDoc"));
					joHarResultsRview.put("bytesInDoc", rst.getString("rbytesInDoc"));
					joHarResultsRview.put("fullyLoaded", rst.getString("rfullyLoaded"));
					joHarResultsRview.put("requests", rst.getString("rrequests"));
					joHarResultsRview.put("bytesIn", rst.getString("rbytesIn"));
					jaModules.add(joHarResultsRview);
				}
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		
		return jaModules;
	}
	
	/**
	 * To fetch WPT urls for `Content Breakdown` and `domain Breakdown`
	 * 
	 * @param con
	 * @param lharId
	 * @return
	 * @throws Exception
	 */
	public ResultSet fetchScreenRst(Connection con, long lharId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		Date dateLog = LogManager.logMethodStart();
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT json_result->'run'->'firstView'->'images'->>'screenShot' AS fView_Screen, ")
					.append("json_result->'run'->'repeatView'->'images'->>'screenShot' AS rView_Screen, ")
					.append("json_result->'run'->'firstView'->'pages'->>'breakdown' AS breakdown, ")
					.append("json_result->'run'->'firstView'->'pages'->>'domains' AS domains ")
					.append("FROM sum_har_test_results WHERE id = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lharId);
			rst = pstmt.executeQuery();
			
		} catch (Exception e) {
			throw e;
		} finally {
/*			DataBaseManager.close(pstmt);
			pstmt = null;*/
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
		return rst;
	}
	
	/**
	 * Get the Failure records of the given SUM Test.
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param strTestId
	 * @param strLocation
	 * @param strInterval
	 * @param strStartDate
	 * @param strEndDate
	 * @return
	 * @throws Throwable
	 */
	public JSONArray[] getSUMTestUnavailability(Connection con, LoginUserBean loginUserBean, String strTestId, String strInterval, String strStartDate, String strEndDate) throws Throwable {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaSUMSuccessResults = new JSONArray(), jaSUMFailureResults = new JSONArray();
		JSONObject joSUMSuccessResult = null, joSUMFailureResult = null;
		boolean bAvailability;
		
		try {
			sbQuery	.append("SELECT testurl, location, response_status, availability, appedo_received_on ")
					.append("FROM sum_heartbeat_log_").append(loginUserBean.getUserId()).append(" ")
					.append("WHERE sum_test_id = ").append(strTestId).append(" ");
//			if( strLocation != null && strLocation.length() > 0 ) {
//				sbQuery.append("AND location = '").append(strLocation).append("' ");
//			}
			if( strInterval != null ) {
				sbQuery.append("AND to_timestamp(appedo_received_on/1000) > now() - INTERVAL '").append(strInterval).append("' ");
			} else if( strStartDate != null & strEndDate != null ) {
				sbQuery.append("AND appedo_received_on BETWEEN ").append(strStartDate).append(" AND ").append(strEndDate).append(" ");
			}
			sbQuery.append("ORDER BY appedo_received_on");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while( rst.next() ) {
				bAvailability = rst.getBoolean("availability");
				if( bAvailability ) {
					joSUMSuccessResult = new JSONObject();
					joSUMSuccessResult.put("testurl", rst.getString("testurl"));
					joSUMSuccessResult.put("location", rst.getString("location"));
					joSUMSuccessResult.put("response_status", rst.getString("response_status"));
					joSUMSuccessResult.put("availability", rst.getBoolean("availability"));
					joSUMSuccessResult.put("appedo_received_on", rst.getLong("appedo_received_on"));
					
					jaSUMSuccessResults.add(joSUMSuccessResult);
				} else {
					joSUMFailureResult = new JSONObject();
					joSUMFailureResult.put("testurl", rst.getString("testurl"));
					joSUMFailureResult.put("location", rst.getString("location"));
					joSUMFailureResult.put("response_status", rst.getString("response_status"));
					joSUMFailureResult.put("availability", rst.getBoolean("availability"));
					joSUMFailureResult.put("appedo_received_on", rst.getLong("appedo_received_on"));
					
					jaSUMFailureResults.add(joSUMFailureResult);
				}
			}
			
		} catch (Throwable th) {
			System.out.println(sbQuery);
			LogManager.errorLog(th, sbQuery);
			throw th;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return new JSONArray[]{jaSUMSuccessResults, jaSUMFailureResults};
	}
	
	/**
	 * Get the last Warning & Critical Threshold limits of the given `test_id`.
	 * 
	 * @param con
	 * @param luserId
	 * @param lUID
	 * @param lCounterId
	 * @param strSliderValue
	 * @return
	 * @throws Exception
	 */
	public JSONObject getTestBreachedThresholdLimits(Connection con, long lTestId, String strSliderValue, Long lStartDateTimeInMills, Long lEndDateTimeInMills, long lUserId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joBreachedThresholdLimit = null;
		
		try {
			pstmt = con.prepareStatement("SELECT * FROM get_test_breached_threshold_limits(?, ?, ?, ?, ?)");
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, lTestId);
			pstmt.setString(3, strSliderValue);
			if ( strSliderValue != null ) {
				pstmt.setString(3, strSliderValue);
				pstmt.setNull(4, Types.BIGINT);
				pstmt.setNull(5, Types.BIGINT);
			} else {
				pstmt.setNull(3, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(1, lStartDateTimeInMills / 1000);
				pstmt.setLong(5, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joBreachedThresholdLimit = new JSONObject();
				
				joBreachedThresholdLimit.put("testId", rst.getLong("test_id"));
				joBreachedThresholdLimit.put("critical_threshold_value", rst.getLong("critical_threshold_value"));
				joBreachedThresholdLimit.put("warning_threshold_value", rst.getLong("warning_threshold_value"));
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			DataBaseManager.close(rst);
			rst = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		
		return joBreachedThresholdLimit;
	}
}
