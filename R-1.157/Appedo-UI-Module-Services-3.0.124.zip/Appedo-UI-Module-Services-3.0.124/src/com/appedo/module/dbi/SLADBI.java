package com.appedo.module.dbi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.MapCounterBean;
import com.appedo.module.bean.RUMSLABean;
import com.appedo.module.bean.SLAActionBean;
import com.appedo.module.bean.SLABean;
import com.appedo.module.bean.SLARuleBean;
import com.appedo.module.bean.SLASUMBean;
import com.appedo.module.common.Constants;
import com.appedo.module.common.Constants.SUM_TYPE;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;

public class SLADBI {
	
	public static void loadSLABreachTypes(Connection con) throws Exception {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT * from breach_type ")
					.append("ORDER BY breach_type ");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while(rst.next()) {
				Constants.SLA_BREACH_TYPES.put(rst.getString("breach_type"), rst.getInt("breach_type_id"));
			}
			
		} catch(Exception e) {
        	throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public JSONArray getBreachedCountersList(Connection con, String strSliderValue, Long lStartDateTime, Long lEndDateTime, Long lUserId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaBreachedCounters = new JSONArray();
		JSONObject joBreachedCounter = null;
		
		try {
			sbQuery	.append("SELECT ssc.sla_id, ssc.uid, ssc.counter_template_id, ssc.counter_id, ssc.is_above_threshold, group_concat( DISTINCT (extract('epoch' from sal.received_on)*1000)::bigint ) AS breached_timestamps ")
					.append("FROM sla_alert_log_").append(lUserId).append(" sal ")
					.append("INNER JOIN so_sla_counter ssc ON ssc.sla_id = sal.sla_id ");
			if( lStartDateTime != null && lEndDateTime != null ) {
				sbQuery.append("AND sal.received_on::timestamp BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			} else {
				sbQuery.append("AND sal.received_on > now() - interval '").append(strSliderValue).append("' ");
			}
			sbQuery.append("GROUP BY ssc.sla_id, ssc.uid, ssc.counter_template_id, ssc.counter_id, ssc.is_above_threshold ");
			
			/*
			sbQuery	.append("SELECT distinct(stb.counter_id), stb.sla_id, stb.guid,ssc.counter_template_id,mm.uid, mm.module_name, mm.module_code, ct.category, ct.counter_name, ct.display_name, ct.unit ")
					.append("FROM so_threshold_breach_").append(lUserId).append(" stb ")
					.append("INNER JOIN sla_alert_log sal ON sal.sla_id = stb.sla_id ")
					.append("  AND stb.received_on BETWEEN (sal.received_on - interval '5 second') AND sal.received_on ")
					.append("  AND sal.user_id = ").append(lUserId).append(" ")
					.append("INNER JOIN so_sla_counter ssc ON ssc.sla_id = stb.sla_id  AND ssc.counter_id = stb.counter_id ");
			if( lStartDateTime != null && lEndDateTime != null ) {
				sbQuery.append("AND stb.received_on::timestamp BETWEEN to_timestamp(").append(lStartDateTime/1000).append(") AND to_timestamp(").append(lEndDateTime/1000).append(") ");
			} else {
				sbQuery.append("AND stb.received_on > now() - interval '").append(strSliderValue).append("' ");
			}
			sbQuery	.append("INNER JOIN counter_template ct ON ct.counter_template_id = ssc.counter_template_id ")
					.append("INNER JOIN module_master mm ON mm.guid = stb.guid ")
					.append("ORDER BY mm.module_name");
			*/
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			while( rst.next() ) {
				joBreachedCounter = new JSONObject();
				
				joBreachedCounter.put("sla_id", rst.getString("sla_id"));
				joBreachedCounter.put("uid", rst.getString("uid"));
				joBreachedCounter.put("counter_template_id", rst.getString("counter_template_id"));
				joBreachedCounter.put("counter_id", rst.getString("counter_id"));
				joBreachedCounter.put("breached_timestamps", rst.getString("breached_timestamps"));
				joBreachedCounter.put("sla_is_above_threshold", rst.getBoolean("is_above_threshold"));
				
				jaBreachedCounters.add(joBreachedCounter);
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
			
			DataBaseManager.close(rst);
			rst = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		return jaBreachedCounters;
	}

	/**
	 * Get the last Warning & Critical Threshold limits of the given UID's Counter-Id.
	 * 
	 * @param con
	 * @param luserId
	 * @param lUID
	 * @param lCounterId
	 * @param strSliderValue
	 * @return
	 * @throws Exception
	 */
	public JSONObject getCounterBreachedThresholdLimits(Connection con, long lUserId, String strGUID, String strCounterId, String strSliderValue, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joBreachedThresholdLimit = null;
		
		try {
			pstmt = con.prepareStatement("SELECT * FROM get_counter_breached_threshold_limits(?, ?, ?, ?, ?, ?)");
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strGUID);
			pstmt.setString(3, strCounterId);
			pstmt.setString(4, strSliderValue);

			if ( strSliderValue != null ) {
				pstmt.setString(4, strSliderValue);
				pstmt.setNull(5, Types.BIGINT);
				pstmt.setNull(6, Types.BIGINT);
			} else {
				pstmt.setNull(4, Types.VARCHAR);
				// converts into minutes
				pstmt.setLong(5, lStartDateTimeInMills / 1000);
				pstmt.setLong(6, lEndDateTimeInMills / 1000);
			}
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joBreachedThresholdLimit = new JSONObject();
				
				joBreachedThresholdLimit.put("guid", rst.getString("guid"));
				joBreachedThresholdLimit.put("counter_id", rst.getLong("counter_id"));
				joBreachedThresholdLimit.put("critical_threshold_value", rst.getLong("critical_threshold_value"));
				joBreachedThresholdLimit.put("warning_threshold_value", rst.getLong("warning_threshold_value"));
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			DataBaseManager.close(rst);
			rst = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery.toString() );
			sbQuery = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		
		return joBreachedThresholdLimit;
	}
	
	/**
	 * gets breaches data for the given module's/guid's slaId, counterId
	 * 
	 * @param con
	 * @param strGUID
	 * @param strSLAIds
	 * @param strCounters
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getCountersBreaches(Connection con, String strGUID, String strSLAIds, String strCounters, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONObject joResult = new JSONObject();
		
		StringBuilder sbQuery = new StringBuilder();
		String strLabel = "", strBreachSeverity = "";
		
		ArrayList<JSONObject> alBreachedOn = null;
		
		LinkedHashMap<Long, HashMap<String, HashMap<String, Object>>> lmCountersTypeData = new LinkedHashMap<Long, HashMap<String, HashMap<String, Object>>>();
		HashMap<String, HashMap<String, Object>> hmBreacheTypeWiseCounterBreaches = null;
		HashMap<String, Object> hmCounterBreaches = null;
		
		JSONObject joDatum = null;
		JSONObject joCountersTypeData = new JSONObject();
		JSONArray jaCountersTypeBreaches = null;
		
		Long lCounterId = -1L;
		long lTimeBreachedOn = -1L;
		
		try {
			sbQuery	.append("SELECT stb.sla_id, stb.counter_id, stb.breached_severity, stb.is_above, ")
					.append("  max(critical_threshold_value) AS critical_threshold_value, max(warning_threshold_value) AS warning_threshold_value, ")
					.append("  date_trunc('minute', stb.received_on) AS breached_on, ")// date_trunc('minute', min(stb.received_on)) AS format_breached_on, 
					.append("  count(stb.received_value) AS \"Count\", round(avg(stb.received_value), 3) AS \"Avg\" ")
					.append("FROM so_threshold_breach_").append(lUserId).append(" stb ")
					.append("WHERE stb.guid = ? ")
					.append("  AND stb.counter_id IN (").append(strCounters).append(") ")
					.append("  AND stb.sla_id IN (").append(strSLAIds).append(") ");
			if ( lStartDateTime != null && lEndDateTime != null ) {
				sbQuery	.append("  AND stb.received_on::timestamp BETWEEN to_timestamp(").append( lStartDateTime / 1000 ).append(") AND to_timestamp(").append( lEndDateTime / 1000 ).append(") ");
			} else {
				sbQuery	.append("  AND stb.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			}
			sbQuery	.append("GROUP BY stb.sla_id, stb.counter_id, stb.breached_severity, stb.is_above, breached_on ")
					.append("ORDER BY breached_on");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strGUID);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				lCounterId = rst.getLong("counter_id");
				lTimeBreachedOn = rst.getTimestamp("breached_on").getTime();
				
				// commented since only having breachType `Threshold Breach`
				//strBreachType = rst.getString("breach_type");
				strBreachSeverity = rst.getString("breached_severity");
						
				//strLabel = "SLA Breach - "+strBreachType+" - "+lCounterId;
				strLabel = "SLA Breach - "+strBreachSeverity;
				
				joDatum = new JSONObject();
				joDatum.put("T", lTimeBreachedOn);
				
				joDatum.put("V", rst.getLong("Avg"));
				joDatum.put("Count", rst.getLong("Count"));
				joDatum.put("Avg", rst.getLong("Avg"));
				joDatum.put("isThresholdAbove", rst.getBoolean("is_above"));
				joDatum.put("thresholdLimit", strBreachSeverity.equals("CRITICAL") ? rst.getLong("critical_threshold_value") : rst.getLong("warning_threshold_value") );
				
				if ( lmCountersTypeData.containsKey(lCounterId) ) {
					hmBreacheTypeWiseCounterBreaches = lmCountersTypeData.get(lCounterId);
				} else {
					hmBreacheTypeWiseCounterBreaches = new HashMap<String, HashMap<String, Object>>();
					
					lmCountersTypeData.put(lCounterId, hmBreacheTypeWiseCounterBreaches);
				}
				
				if ( hmBreacheTypeWiseCounterBreaches.containsKey(strBreachSeverity) ) {
					hmCounterBreaches = hmBreacheTypeWiseCounterBreaches.get(strBreachSeverity);
					alBreachedOn = (ArrayList<JSONObject>) hmCounterBreaches.get("data");
				} else {
					hmCounterBreaches = new HashMap<String, Object>();
					alBreachedOn = new ArrayList<JSONObject>();
					
					hmCounterBreaches.put("data", alBreachedOn);
					hmCounterBreaches.put("label", strLabel);
					hmCounterBreaches.put("counterId", lCounterId);
					hmCounterBreaches.put("breachType", strBreachSeverity);
					hmBreacheTypeWiseCounterBreaches.put(strBreachSeverity, hmCounterBreaches);
				}
				alBreachedOn.add(joDatum);
			}
			// sample format of `lmCountersTypeData` {100028="Error"={data=[], label="", type="Error"...}, 100028="Exception"={data=[], label="", type="Exception"...}}
			
			// adds counter's breachTypes data adds into array, formats {100028:[{data=[], label="", type="Error"...}, {data=[], label="", type="Exception"...}], 100007:[{data=[], label="", type="Error"...}, {data=[], label="", type="Exception"...}]} 
			Iterator<Map.Entry<Long, HashMap<String, HashMap<String, Object>>>> itlmCountersTypeData = lmCountersTypeData.entrySet().iterator();
			while( itlmCountersTypeData.hasNext() ) {
				Map.Entry<Long, HashMap<String, HashMap<String, Object>>> pair = (Map.Entry<Long, HashMap<String, HashMap<String, Object>>>) itlmCountersTypeData.next();
				lCounterId = pair.getKey();
				hmBreacheTypeWiseCounterBreaches = pair.getValue();
				
				jaCountersTypeBreaches = new JSONArray();

				Iterator< Map.Entry<String, HashMap<String, Object>> > ithmBreacheTypeWiseCounterBreaches = hmBreacheTypeWiseCounterBreaches.entrySet().iterator();
				while( ithmBreacheTypeWiseCounterBreaches.hasNext() ) {
					Map.Entry<String, HashMap<String, Object>> pairBreacheTypeWise = ithmBreacheTypeWiseCounterBreaches.next();
					strBreachSeverity = pairBreacheTypeWise.getKey();
					hmCounterBreaches = pairBreacheTypeWise.getValue();
					
					// adds counter's breacheTypes into array
					jaCountersTypeBreaches.add(hmCounterBreaches);
					
					ithmBreacheTypeWiseCounterBreaches.remove();
					UtilsFactory.clearCollectionHieracy(hmCounterBreaches);
					hmCounterBreaches = null;
				}
				
				joCountersTypeData.put(lCounterId, jaCountersTypeBreaches);
				
				itlmCountersTypeData.remove(); // avoids a ConcurrentModificationException
				UtilsFactory.clearCollectionHieracy(hmBreacheTypeWiseCounterBreaches);
				hmBreacheTypeWiseCounterBreaches = null;
			}
			joResult.put("guid", strGUID);
			joResult.put("countersBreaches", joCountersTypeData);
			
		} catch (Exception e) {
        	throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(lmCountersTypeData);
			lmCountersTypeData = null;/*
			UtilsFactory.clearCollectionHieracy(hmBreacheTypeWiseCounterBreaches);
			hmBreacheTypeWiseCounterBreaches = null;
			UtilsFactory.clearCollectionHieracy(hmCounterBreaches);
			hmCounterBreaches = null;*/
			
			strLabel = null;
			strBreachSeverity = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	/**
	 * gets breaches data for the given module's/guid's slaId, counterId
	 * 
	 * @param con
	 * @param strGUID
	 * @param strSLAIds
	 * @param strCounters
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getCounterBreaches(Connection con, String strGUID, String strSLAIds, String strCounters, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONObject joResult = new JSONObject();
		
		StringBuilder sbQuery = new StringBuilder();
		String strLabel = "", strBreachSeverity = "";
		
		ArrayList<JSONObject> alBreachedOn = null;
		
		LinkedHashMap<Long, HashMap<String, HashMap<String, Object>>> lmCountersTypeData = new LinkedHashMap<Long, HashMap<String, HashMap<String, Object>>>();
		HashMap<String, HashMap<String, Object>> hmBreacheTypeWiseCounterBreaches = null;
		HashMap<String, Object> hmCounterBreaches = null;
		
		JSONObject joDatum = null;
		JSONObject joCountersTypeData = new JSONObject();
		JSONArray jaCountersTypeBreaches = null;
		
		Long lCounterId = -1L;
		long lTimeBreachedOn = -1L;
		
		try {
			sbQuery	.append("SELECT stb.sla_id, stb.counter_id, stb.breached_severity, stb.is_above, ")
					.append("critical_threshold_value, warning_threshold_value, stb.received_on, stb.received_value ")
					.append("FROM so_threshold_breach_").append(lUserId).append(" stb ")
					.append("WHERE stb.guid = ? ")
					.append("  AND stb.counter_id IN (").append(strCounters).append(") ")
					.append("  AND stb.sla_id IN (").append(strSLAIds).append(") ");
			if ( lStartDateTime != null && lEndDateTime != null ) {
				sbQuery	.append("  AND stb.received_on::timestamp BETWEEN to_timestamp(").append( lStartDateTime / 1000 ).append(") AND to_timestamp(").append( lEndDateTime / 1000 ).append(") ");
			} else {
				sbQuery	.append("  AND stb.received_on > now() - interval '").append(strFromStartInterval).append("' ");
			}
			sbQuery	.append("ORDER BY received_on");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strGUID);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				lCounterId = rst.getLong("counter_id");
				lTimeBreachedOn = rst.getTimestamp("received_on").getTime();
				
				// commented since only having breachType `Threshold Breach`
				//strBreachType = rst.getString("breach_type");
				strBreachSeverity = rst.getString("breached_severity");
						
				//strLabel = "SLA Breach - "+strBreachType+" - "+lCounterId;
				strLabel = "SLA Breach - "+strBreachSeverity;
				
				joDatum = new JSONObject();
				joDatum.put("T", lTimeBreachedOn);
				joDatum.put("received_value", rst.getDouble("received_value"));
				
				joDatum.put("isThresholdAbove", rst.getBoolean("is_above"));
				joDatum.put("thresholdLimit", strBreachSeverity.equals("CRITICAL") ? rst.getLong("critical_threshold_value") : rst.getLong("warning_threshold_value") );
				
				if ( lmCountersTypeData.containsKey(lCounterId) ) {
					hmBreacheTypeWiseCounterBreaches = lmCountersTypeData.get(lCounterId);
				} else {
					hmBreacheTypeWiseCounterBreaches = new HashMap<String, HashMap<String, Object>>();
					
					lmCountersTypeData.put(lCounterId, hmBreacheTypeWiseCounterBreaches);
				}
				
				if ( hmBreacheTypeWiseCounterBreaches.containsKey(strBreachSeverity) ) {
					hmCounterBreaches = hmBreacheTypeWiseCounterBreaches.get(strBreachSeverity);
					alBreachedOn = (ArrayList<JSONObject>) hmCounterBreaches.get("data");
				} else {
					hmCounterBreaches = new HashMap<String, Object>();
					alBreachedOn = new ArrayList<JSONObject>();
					
					hmCounterBreaches.put("data", alBreachedOn);
					hmCounterBreaches.put("label", strLabel);
					hmCounterBreaches.put("counterId", lCounterId);
					hmCounterBreaches.put("breachType", strBreachSeverity);
					hmBreacheTypeWiseCounterBreaches.put(strBreachSeverity, hmCounterBreaches);
				}
				alBreachedOn.add(joDatum);
			}
			// sample format of `lmCountersTypeData` {100028="Error"={data=[], label="", type="Error"...}, 100028="Exception"={data=[], label="", type="Exception"...}}
			
			// adds counter's breachTypes data adds into array, formats {100028:[{data=[], label="", type="Error"...}, {data=[], label="", type="Exception"...}], 100007:[{data=[], label="", type="Error"...}, {data=[], label="", type="Exception"...}]} 
			Iterator<Map.Entry<Long, HashMap<String, HashMap<String, Object>>>> itlmCountersTypeData = lmCountersTypeData.entrySet().iterator();
			while( itlmCountersTypeData.hasNext() ) {
				Map.Entry<Long, HashMap<String, HashMap<String, Object>>> pair = (Map.Entry<Long, HashMap<String, HashMap<String, Object>>>) itlmCountersTypeData.next();
				lCounterId = pair.getKey();
				hmBreacheTypeWiseCounterBreaches = pair.getValue();
				
				jaCountersTypeBreaches = new JSONArray();

				Iterator< Map.Entry<String, HashMap<String, Object>> > ithmBreacheTypeWiseCounterBreaches = hmBreacheTypeWiseCounterBreaches.entrySet().iterator();
				while( ithmBreacheTypeWiseCounterBreaches.hasNext() ) {
					Map.Entry<String, HashMap<String, Object>> pairBreacheTypeWise = ithmBreacheTypeWiseCounterBreaches.next();
					strBreachSeverity = pairBreacheTypeWise.getKey();
					hmCounterBreaches = pairBreacheTypeWise.getValue();
					
					// adds counter's breacheTypes into array
					jaCountersTypeBreaches.add(hmCounterBreaches);
					
					ithmBreacheTypeWiseCounterBreaches.remove();
					UtilsFactory.clearCollectionHieracy(hmCounterBreaches);
					hmCounterBreaches = null;
				}
				
				joCountersTypeData.put(lCounterId, jaCountersTypeBreaches);
				
				itlmCountersTypeData.remove(); // avoids a ConcurrentModificationException
				UtilsFactory.clearCollectionHieracy(hmBreacheTypeWiseCounterBreaches);
				hmBreacheTypeWiseCounterBreaches = null;
			}
			joResult.put("guid", strGUID);
			joResult.put("countersBreaches", joCountersTypeData);
			
		} catch (Exception e) {
        	throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(lmCountersTypeData);
			lmCountersTypeData = null;/*
			UtilsFactory.clearCollectionHieracy(hmBreacheTypeWiseCounterBreaches);
			hmBreacheTypeWiseCounterBreaches = null;
			UtilsFactory.clearCollectionHieracy(hmCounterBreaches);
			hmCounterBreaches = null;*/
			
			strLabel = null;
			strBreachSeverity = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return joResult;
	}
	
	//SLA DBI in SLA Services

	
	public JSONArray getSLAActions(Connection con, LoginUserBean loginBean) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JSONArray jaActions = null;
		JSONObject joAction = null;
		
		ArrayList<String> alMappedRules = null;
		ArrayList<Long> alMappedSla = null;
		StringBuilder sbQuery = null;
		try{
			
			sbQuery = new StringBuilder();
			jaActions = new JSONArray();
			
			sbQuery	.append("SELECT action_id, action_name, execution_type, created_on, is_public, action_description, parameter_format, parameter_values, script ")
					.append("FROM so_sla_action  WHERE user_id=? AND is_delete = false ")
					.append("ORDER BY created_on desc");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginBean.getUserId());
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joAction = new JSONObject();
				String strRule = "";
				joAction.put("action_id", rs.getLong("action_id"));
				joAction.put("action_name", rs.getString("action_name"));
				joAction.put("created_by", loginBean.getFirstName());
				joAction.put("created_on", rs.getTimestamp("created_on").getTime());
				joAction.put("type", rs.getString("execution_type"));
				joAction.put("is_public", rs.getBoolean("is_public"));
				joAction.put("action_description", rs.getString("action_description"));
				joAction.put("parameter_format", rs.getString("parameter_format"));
				joAction.put("parameter_values", rs.getString("parameter_values"));
				joAction.put("script", rs.getString("script"));
				alMappedRules = getMappedRules(con, rs.getLong("action_id"),loginBean.getUserId());
				joAction.put("mapped_rules", alMappedRules.size());
				alMappedSla = getMappedSLA(con, rs.getLong("action_id"));
				joAction.put("mapped_sla", alMappedSla.size());
				joAction.put("isRefered", isActionMappedToRule(con, rs.getLong("action_id"), loginBean));
				for(int i=0; i<alMappedRules.size(); i++){
					if(i==alMappedRules.size()-1){
						strRule = strRule + alMappedRules.get(i);
					}else{
						strRule = strRule + alMappedRules.get(i)+", ";
					}
				}
				joAction.put("rule_name", strRule);
				jaActions.add(joAction);
				
				strRule = null;
				joAction = null;
				alMappedSla = null;
				alMappedRules = null;
			}
			
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return jaActions;
	}
	
	public ArrayList<String> getMappedRules(Connection con, long lActionId, long lUserID) throws Exception {

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuilder sbQuery = null;
		ArrayList<String> al = null;
		try{

			sbQuery = new StringBuilder();
			al = new ArrayList<String>();

			sbQuery.append("SELECT rule_name FROM so_rule where rule_id in (SELECT rule_id FROM so_rule_action WHERE action_id=? AND user_id=? )");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lActionId);
			pstmt.setLong(2, lUserID);
			rs = pstmt.executeQuery();

			while(rs.next()){
				al.add(rs.getString("rule_name"));
			}

		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);

			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return al;
	}
	
	public ArrayList<Long> getMappedSLA(Connection con, long lActionId) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = null;
		ArrayList<Long> al = null;
		try{
			
			sbQuery = new StringBuilder();
			al = new ArrayList<Long>();
			
			sbQuery	.append("SELECT ssr.sla_id FROM so_sla_action ssa ")
					.append(" INNER JOIN so_rule_action  sra ON ssa.action_id=sra.action_id  and ssa.action_id=?  AND ssa.is_delete=false AND ssa.user_id=sra.created_by")
					.append(" INNER JOIN so_sla_rule ssr on ssr.rule_id=sra.rule_id");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lActionId);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				al.add(rs.getLong("sla_id"));
			}
			
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return al;
	}

	public JSONArray getSLARules(Connection con, LoginUserBean loginBean) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JSONArray jaRules = null;
		JSONObject joRule = null;
		
		ArrayList<Long> alMappedActions = null;
		ArrayList<String> alMappedSlas = null;
		StringBuilder sbQuery = null;
		try{
			
			sbQuery = new StringBuilder();
			jaRules = new JSONArray();
			
			sbQuery	.append("SELECT rule_id,rule_name,created_on, rule_description FROM so_rule WHERE user_id=? ")
					.append("ORDER BY created_on desc");
	
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginBean.getUserId());
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joRule = new JSONObject();
				String strSLA = "";
				joRule.put("rule_id", rs.getLong("rule_id"));
				joRule.put("rule_name", rs.getString("rule_name"));
				joRule.put("created_by", loginBean.getFirstName());
				joRule.put("created_on", rs.getTimestamp("created_on").getTime());
				joRule.put("ruleDescription", rs.getString("rule_description"));
				alMappedActions = getMappedActions(con, rs.getLong("rule_id"));
				joRule.put("mapped_actions", alMappedActions.size());
				alMappedSlas = getMappedSLAs(con, rs.getLong("rule_id"));
				joRule.put("mapped_sla", alMappedSlas.size());
				joRule.put("isRefered", isRuleMappedToPolicy(con, rs.getLong("rule_id"), loginBean));
				for(int i=0; i<alMappedSlas.size(); i++){
					if(i==alMappedSlas.size()-1){
						strSLA = strSLA + alMappedSlas.get(i);
					}else{
						strSLA = strSLA + alMappedSlas.get(i)+", ";
					}
				}
				joRule.put("sla_name", strSLA);
				jaRules.add(joRule);
				
				strSLA = null;
				joRule = null;
				alMappedSlas = null;
				alMappedActions = null;
			}
			
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return jaRules;
	}
	
	public ArrayList<Long> getMappedActions(Connection con, long lRuleId) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = null;
		ArrayList<Long> al = null;
		try{
			
			sbQuery = new StringBuilder();
			al = new ArrayList<Long>();
			
			sbQuery	.append("SELECT action_id FROM so_rule sr INNER JOIN so_rule_action sra ON sra.rule_id = sr.rule_id where sr.rule_id=?");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRuleId);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				al.add(rs.getLong("action_id"));
			}
			
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return al;
	}
	public ArrayList<String> getMappedSLAs(Connection con, long lRuleId) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = null;
		ArrayList<String> al = null;
		try{
			
			sbQuery = new StringBuilder();
			al = new ArrayList<String>();
			
			sbQuery	.append("SELECT  sla_name FROM so_sla ss INNER JOIN so_sla_rule ssr on ss.sla_id=ssr.sla_id and ssr.rule_id=?");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRuleId);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				al.add(rs.getString("sla_name"));
			}
			
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return al;
	}
	/**
	 * To get the slave status 
	 * @param con
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSlaSlaveStatusCardLayout(Connection con, LoginUserBean loginBean) throws Exception {
		
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JSONArray jaSlaSlaveStatusCardLayouts = null;
		JSONObject joSlaSlaveStatusCardLayout = null;
		
		StringBuilder sbQuery = null;
		try{
			
			sbQuery = new StringBuilder();
			jaSlaSlaveStatusCardLayouts = new JSONArray();
			
			sbQuery	.append("SELECT * FROM get_sla_slave_status_card_layout(")
					.append(loginBean.getUserId())
					.append(")");
	
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joSlaSlaveStatusCardLayout = new JSONObject();
				joSlaSlaveStatusCardLayout.put("mac_address", rs.getString("macAddress"));
				joSlaSlaveStatusCardLayout.put("ip_address", rs.getString("ip"));
				joSlaSlaveStatusCardLayout.put("slave_version", rs.getString("slaveVersion"));
				joSlaSlaveStatusCardLayout.put("last_received_on", rs.getTimestamp("lastReceivedon").getTime());
				joSlaSlaveStatusCardLayout.put("os_type", rs.getString("osType"));
				joSlaSlaveStatusCardLayout.put("os_version", rs.getString("osVersion"));
				joSlaSlaveStatusCardLayout.put("slave_status", rs.getBoolean("slaveStatus"));
				jaSlaSlaveStatusCardLayouts.add(joSlaSlaveStatusCardLayout);
				//joSlaSlaveStatusCardLayout = null;
			}
			
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return jaSlaSlaveStatusCardLayouts;
		
	}
	
	/**
	 * To get the sla alert log
	 * @param con
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getSlaAlertCardLayout(Connection con, /*LoginUserBean loginBean*/ long lUser_id , long lSlaId, long lLimt, long lOffSet) throws Exception {
		PreparedStatement pstmt = null, pscount = null;
		ResultSet rst = null, rscount = null;
		
		JSONArray jaSlaSlaveStatusCardLayouts = null;
		JSONObject joSlaSlaveStatusCardLayout = null, joRtn = null;
		
		StringBuilder sbQuery = null;
		String strToAddress = "", strAlertContent = "";
		
		long lTotalCount = 0;
		
		try{
			sbQuery = new StringBuilder();
			jaSlaSlaveStatusCardLayouts = new JSONArray();
			joRtn = new JSONObject();
			sbQuery .append("SELECT COUNT(*) as total FROM sla_alert_log_").append(lUser_id).append(" ")
					.append("WHERE sla_id = ").append(lSlaId);
			
			pscount = con.prepareStatement(sbQuery.toString());
			rscount = pscount.executeQuery();
			if(rscount.next()){
				lTotalCount = rscount.getLong("total");
			}
			
			joRtn.put("total_count", lTotalCount);
			sbQuery.setLength(0);
			
			sbQuery	.append("SELECT * FROM get_sla_alert_card_layout(")
					.append(/*loginBean.getUserId()*/lUser_id)
					.append(" , ")
					.append(lSlaId)
					.append(" , ")
					.append(lLimt)
					.append(" , ")
					.append(lOffSet)
					.append(")");
	
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			
			while(rst.next()){
				joSlaSlaveStatusCardLayout = new JSONObject();
				
				if ( rst.getString("EmailId").length() > 0 ) {
					strToAddress = rst.getString("EmailId");
				} else if ( rst.getString("Mobile").length() > 0 ) {
					strToAddress = rst.getString("Mobile");
				} else {
					strToAddress = "";
				}
				
				if ( rst.getString("AlertContentSms").length() > 0 ) {
					strAlertContent = rst.getString("AlertContentSms");
				} else {
					strAlertContent = rst.getString("AlertContentEmail");
				}
				
				joSlaSlaveStatusCardLayout.put("toAddress", strToAddress);
				joSlaSlaveStatusCardLayout.put("email_id", rst.getString("EmailId"));
				joSlaSlaveStatusCardLayout.put("Mobile", rst.getString("Mobile"));
				joSlaSlaveStatusCardLayout.put("is_sent", rst.getBoolean("IsSent"));				
				joSlaSlaveStatusCardLayout.put("is_success", rst.getBoolean("IsSuccess"));
				joSlaSlaveStatusCardLayout.put("alert_content", strAlertContent);
				joSlaSlaveStatusCardLayout.put("alert_content_email", rst.getString("AlertContentEmail"));
				joSlaSlaveStatusCardLayout.put("alert_content_sms", rst.getString("AlertContentSms"));
				joSlaSlaveStatusCardLayout.put("received_on", rst.getTimestamp("ReceivedOn").getTime());
				jaSlaSlaveStatusCardLayouts.add(joSlaSlaveStatusCardLayout);
				joSlaSlaveStatusCardLayout = null;
			}
			
			joRtn.put("log_records", jaSlaSlaveStatusCardLayouts);
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rscount);
			rscount = null;
			DataBaseManager.close(pscount);
			pscount = null;
			
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return joRtn;
		
	}
	
	/**
	 * To get the Sla Heal log
	 * @param con
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSlaHealCardLayout(Connection con, LoginUserBean loginBean, long lSlaId) throws Exception {
		
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JSONArray jaSlaHealCardLayouts = null;
		JSONObject joSlHealCardLayout = null;
		
		StringBuilder sbQuery = null;
		try{
			
			sbQuery = new StringBuilder();
			jaSlaHealCardLayouts = new JSONArray();
			
			sbQuery	.append("SELECT * FROM get_sla_Heal_card_layout(")
					.append(loginBean.getUserId())
					.append(" , ")
					.append(lSlaId)
					.append(")");
	
			pstmt = con.prepareStatement(sbQuery.toString());
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				joSlHealCardLayout = new JSONObject();
				//actionname character varying,execscript character varying,serverip character varying,os character varying,reason character varying,actiontakenon timestamp without time zone,success boolean, Execlog character varying
				joSlHealCardLayout.put("action_name", rs.getString("actionname"));
				joSlHealCardLayout.put("exec_script", rs.getString("execscript"));
				joSlHealCardLayout.put("server_ip", rs.getString("serverip"));				
				joSlHealCardLayout.put("os", rs.getString("os"));
				joSlHealCardLayout.put("reason", rs.getString("reason"));
				joSlHealCardLayout.put("success", rs.getBoolean("success"));
				joSlHealCardLayout.put("action_taken_on", rs.getTimestamp("actiontakenon").getTime());
				joSlHealCardLayout.put("Exec_log", rs.getString("Execlog"));
				jaSlaHealCardLayouts.add(joSlHealCardLayout);
				joSlHealCardLayout = null;
			}
			
			
		}catch(Exception e){
			LogManager.infoLog("sbQuery : " + sbQuery.toString());
			LogManager.errorLog(e);
			
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return jaSlaHealCardLayouts;
		
	}
	
	/**
	 * gets ASD SLAs either User added OR System generated, based on boolean
	 * 
	 * @param con
	 * @param bSystemGenerated
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getASDSLAs(Connection con, boolean bSystemGenerated, LoginUserBean loginBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaSLAs = null;
		JSONObject joSLA = null;
		
		String strQuery = "";
		
		//New UI FormatData
		JSONObject jovariable = null, joCol_Value = null;
		
		try{
			jaSLAs = new JSONArray();
			jovariable = new JSONObject();
			joCol_Value = new JSONObject();
			
			/*strQuery = "SELECT * FROM get_asd_slas(?, ?)";*/
			//Enterprise License implemeted.
			strQuery = "SELECT * FROM get_asd_slas_test(?, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			if(joEnterprise.getInt("e_id") != 0){
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, loginBean.getUserId());
			}
			pstmt.setBoolean(2, bSystemGenerated);
			pstmt.setLong(3, joEnterprise.getInt("e_id"));
			rst = pstmt.executeQuery();
			while(rst.next()){
/*				joSLA = new JSONObject();
				joSLA.put("sla_id", rst.getLong("sla_id"));
				joSLA.put("sla_name", rst.getString("sla_name"));
				joSLA.put("description", rst.getString("sla_description"));
				joSLA.put("type", rst.getString("sla_type"));
				joSLA.put("policySvr", rst.getString("server_details"));
				joSLA.put("policySvrType", rst.getString("server_details_type"));
				joSLA.put("isActive", rst.getBoolean("is_active"));
				joSLA.put("created_by", loginBean.getFirstName());
				joSLA.put("created_on", rst.getTimestamp("created_on").getTime());
				joSLA.put("ruleId", rst.getLong("rule_id"));
				
				joSLA.put("mapped_counters", rst.getLong("total_mapped_counters"));
				joSLA.put("alerted", rst.getLong("total_alerted"));
				joSLA.put("healed", rst.getLong("total_healed"));
				
				jaSLAs.add(joSLA);
				joSLA = null;*/
				
				//New UI FormatJSON
				
				jovariable.put("var2", "is_edit");
				jovariable.put("var3", "is_config");
				if(bSystemGenerated){
					jovariable.put("var4", "Alert-System");
				}else{
					jovariable.put("var1", "is_delete");
					jovariable.put("var4", "Alert-User");
				}
				joCol_Value.put("col_1", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", rst.getString("sla_name"));
				jovariable.put("var2", "Added By "+loginBean.getFirstName()+" on ");
				jovariable.put("var21", rst.getTimestamp("created_on").getTime());
				joCol_Value.put("col_2", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);

				jovariable.put("var1", rst.getString("sla_description"));
				joCol_Value.put("col_3", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Mapped Metrics");
				jovariable.put("var2", rst.getLong("total_mapped_counters"));
				joCol_Value.put("col_4", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//jovariable.put("var1", "Alerted (Last 24 Hrs)");
				jovariable.put("var1", "Alerted");
				jovariable.put("var2", rst.getLong("total_alerted"));
				joCol_Value.put("col_5", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Alert_Settings");
				jovariable.put("var2", "");
				jovariable.put("var3", "");
				jovariable.put("var4", "");
				joCol_Value.put("col_6", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Alert_Mon_stat");
				joCol_Value.put("col_7", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Pro_doc");
				joCol_Value.put("col_8", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				joCol_Value.put("sla_id", rst.getLong("sla_id"));
				joCol_Value.put("ruleId", rst.getLong("rule_id"));
				joCol_Value.put("isActive", rst.getBoolean("is_active"));
				joCol_Value.put("type", rst.getString("sla_type"));
				
				joCol_Value.put("sla_name", rst.getString("sla_name"));
				joCol_Value.put("description", rst.getString("sla_description"));
				
				joCol_Value.put("policySvr", rst.getString("server_details"));
				joCol_Value.put("policySvrType", rst.getString("server_details_type"));
				
				jaSLAs.add(joCol_Value);
				UtilsFactory.clearCollectionHieracy(joCol_Value);
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaSLAs;
	}
	
	/**
	 * gets SUM's SLAs
	 * 
	 * @param con
	 * @param bSystemGenerated
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMSLAs(Connection con, boolean bSystemGenerated, LoginUserBean loginBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaSLAs = null;
		JSONObject joSLA = null;
		
		String strQuery = "";
		
		//New UI
		JSONObject jovariable = null, joCol_Value = null;
		
		try{
			jaSLAs = new JSONArray();
			jovariable = new JSONObject();
			joCol_Value = new JSONObject();
			
			/*strQuery = "SELECT * FROM get_sum_slas(?, ?)";*/
			//Enterprise License implemeted.
			strQuery = "SELECT * FROM get_sum_slas_test(?, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			if(joEnterprise.getInt("e_id") != 0){
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, loginBean.getUserId());
			}
			pstmt.setBoolean(2, bSystemGenerated);
			pstmt.setLong(3, joEnterprise.getInt("e_id"));
			rst = pstmt.executeQuery();
			while(rst.next()){
				
				/*joSLA = new JSONObject();
				joSLA.put("sla_id", rst.getLong("sla_id"));
				joSLA.put("sla_name", rst.getString("sla_name"));
				joSLA.put("description", rst.getString("sla_description"));
				joSLA.put("type", rst.getString("sla_type"));
				joSLA.put("policySvr", rst.getString("server_details"));
				joSLA.put("policySvrType", rst.getString("server_details_type"));
				joSLA.put("isActive", rst.getBoolean("is_active"));
				joSLA.put("created_by", loginBean.getFirstName());
				joSLA.put("created_on", rst.getTimestamp("created_on").getTime());
				//joSLA.put("ruleId", rst.getLong("rule_id"));
				
				//joSLA.put("mapped_counters", rst.getLong("total_mapped_counters"));
				joSLA.put("alerted", rst.getLong("total_alerted"));
				//joSLA.put("healed", rst.getLong("total_healed"));
				
				jaSLAs.add(joSLA);
				joSLA = null;*/
				//jovariable.put("var1", "is_delete");
				//jovariable.put("var2", "is_edit");
				//jovariable.put("var3", "is_config");
				jovariable.put("var4", "Alert-SUM");
				joCol_Value.put("col_1", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", rst.getString("sla_name"));
				jovariable.put("var2", "Added By "+loginBean.getFirstName()+" on ");
				jovariable.put("var21", rst.getTimestamp("created_on").getTime());
				joCol_Value.put("col_2", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);

				jovariable.put("var1", rst.getString("sla_description"));
				joCol_Value.put("col_3", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//jovariable.put("var1", "Mapped Metrics");
				//jovariable.put("var2", rst.getLong("total_mapped_counters"));
				joCol_Value.put("col_4", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//jovariable.put("var1", "Alerted (Last 24 Hrs)");
				jovariable.put("var1", "Alerted");
				jovariable.put("var2", rst.getLong("total_alerted"));
				joCol_Value.put("col_5", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "STATUS_Live");
				jovariable.put("var2", rst.getBoolean("is_active") ? "Enabled" : "Disabled");
				joCol_Value.put("col_6", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Mon_stat");
				joCol_Value.put("col_7", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Pro_doc");
				joCol_Value.put("col_8", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				joCol_Value.put("sla_id", rst.getLong("sla_id"));
				//joCol_Value.put("ruleId", rst.getLong("rule_id"));
				joCol_Value.put("isActive", rst.getBoolean("is_active"));
				joCol_Value.put("type", rst.getString("sla_type"));
				
				jaSLAs.add(joCol_Value);
				UtilsFactory.clearCollectionHieracy(joCol_Value);
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaSLAs;
	}
	
	/**
	 * gets RUM SLAs
	 * 
	 * @param con
	 * @param bSystemGenerated
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getRUMSLAs(Connection con, boolean bSystemGenerated, LoginUserBean loginBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaSLAs = null;
		JSONObject joSLA = null;
		
		String strQuery = "";
		
		//New UI
		JSONObject jovariable = null, joCol_Value = null;
		
		try{
			jaSLAs = new JSONArray();
			jovariable = new JSONObject();
			joCol_Value = new JSONObject();
			
			/*strQuery = "SELECT * FROM get_rum_slas(?, ?)";*/
			//Enterprise License implemented.
			strQuery = "SELECT * FROM get_rum_slas_test(?, ?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			if(joEnterprise.getInt("e_id") != 0){
				pstmt.setLong(1, joEnterprise.getInt("e_user_id"));
			}else{
				pstmt.setLong(1, loginBean.getUserId());
			}
			pstmt.setBoolean(2, bSystemGenerated);
			pstmt.setLong(3, joEnterprise.getInt("e_id"));
			
			rst = pstmt.executeQuery();
			while(rst.next()){
/*				joSLA = new JSONObject();
				joSLA.put("sla_id", rst.getLong("sla_id"));
				joSLA.put("sla_name", rst.getString("sla_name"));
				joSLA.put("description", rst.getString("sla_description"));
				joSLA.put("type", rst.getString("sla_type"));
				joSLA.put("policySvr", rst.getString("server_details"));
				joSLA.put("policySvrType", rst.getString("server_details_type"));
				joSLA.put("isActive", rst.getBoolean("is_active"));
				joSLA.put("created_by", loginBean.getFirstName());
				joSLA.put("created_on", rst.getTimestamp("created_on").getTime());
				//joSLA.put("ruleId", rst.getLong("rule_id"));
				
				//joSLA.put("mapped_counters", rst.getLong("total_mapped_counters"));
				joSLA.put("alerted", rst.getLong("total_alerted"));
				//joSLA.put("healed", rst.getLong("total_healed"));
				
				jaSLAs.add(joSLA);
				joSLA = null;*/
				
				//New UI JSONFormat
				//jovariable.put("var1", "is_delete");
				//jovariable.put("var2", "is_edit");
				//jovariable.put("var3", "is_config");
				jovariable.put("var4", "Alert-RUM");
				joCol_Value.put("col_1", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", rst.getString("sla_name"));
				jovariable.put("var2", "Added By "+loginBean.getFirstName()+" on ");
				jovariable.put("var21", rst.getTimestamp("created_on").getTime());
				joCol_Value.put("col_2", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);

				jovariable.put("var1", rst.getString("sla_description"));
				joCol_Value.put("col_3", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//jovariable.put("var1", "Alert Status");
				//jovariable.put("var2", rst.getBoolean("is_active") ? "Enabled" : "Disabled");
				joCol_Value.put("col_4", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				//jovariable.put("var1", "Alerted (Last 24 Hrs)");
				jovariable.put("var1", "Alerted");
				jovariable.put("var2", rst.getLong("total_alerted"));
				joCol_Value.put("col_5", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "STATUS_Live");
				jovariable.put("var2", rst.getBoolean("is_active") ? "Enabled" : "Disabled");
				joCol_Value.put("col_6", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Mon_stat");
				joCol_Value.put("col_7", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				jovariable.put("var1", "Pro_doc");
				joCol_Value.put("col_8", jovariable);
				UtilsFactory.clearCollectionHieracy(jovariable);
				
				joCol_Value.put("sla_id", rst.getLong("sla_id"));
				//joCol_Value.put("ruleId", rst.getLong("rule_id"));
				joCol_Value.put("isActive", rst.getBoolean("is_active"));
				joCol_Value.put("type", rst.getString("sla_type"));
				
				jaSLAs.add(joCol_Value);
				UtilsFactory.clearCollectionHieracy(joCol_Value);
			}
		}catch(Exception e){
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return jaSLAs;
	}
	
	/**
	 * checks action already exists
	 *  
	 * @param con
	 * @param strActionName
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isActionExists(Connection con, String strActionName, long lActionId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		boolean bActionExists = false;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT EXISTS(SELECT 1 FROM so_sla_action WHERE lower(action_name)=LOWER(?) AND action_id != ? AND user_id = ? LIMIT 1) as action_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strActionName);
			pstmt.setLong(2, lActionId);
			pstmt.setLong(3, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				bActionExists = rst.getBoolean("action_exists");
			}

			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		
		return bActionExists;
	}
	
	/**
	 * Saves sla action details
	 * 
	 * @param con
	 * @param actionBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addAction(Connection con, SLAActionBean actionBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("INSERT INTO so_sla_action (action_name, action_description, user_id, enterprise_id, ")
					.append("is_public, ")
					.append("execution_type, script, parameter_format, parameter_values, ")
					.append("created_by,created_on) ") 
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW()) ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, actionBean.getActionName());
			pstmt.setString(2, actionBean.getActionDescription());
			pstmt.setLong(3, loginUserBean.getUserId());
			pstmt.setLong(4, loginUserBean.getEnterpriseId());
			pstmt.setBoolean(5, actionBean.isPublic());
			pstmt.setString(6, actionBean.getExecutionType());
			pstmt.setString(7, actionBean.getScript());
			pstmt.setString(8, actionBean.getParameterFormat());
			pstmt.setString(9, actionBean.getParameterValues());
			pstmt.setLong(10, loginUserBean.getUserId());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * to check whether an action is mapped to rule  
	 * 
	 * @param con
	 * @param lActionId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isActionMappedToRule(Connection con, long lActionId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		boolean bActionRuleExists = false;
		
		try {
			sbQuery	.append("SELECT EXISTS( ")
					.append("  SELECT 1 ")
					.append("  FROM so_rule sr ")
					.append("  INNER JOIN so_rule_action sra ON sra.rule_id = sr.rule_id AND sra.action_id = ? AND sr.user_id = ? ")
					.append("  LIMIT 1 ")
					.append(") AS action_rule_exists ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lActionId);
			pstmt.setLong(2, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				bActionRuleExists = rst.getBoolean("action_rule_exists");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return bActionRuleExists;
	}
	
	public boolean isRuleMappedToPolicy(Connection con, long lRuleId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		boolean bRulePolicyExists = false;
		
		try {
			sbQuery	.append("SELECT EXISTS( ")
					.append("  SELECT 1 ")
					.append("  FROM so_sla_rule ssr ")
					.append("  INNER JOIN so_sla ss ON ss.sla_id = ssr.sla_id AND ssr.rule_id = ? AND ss.user_id = ? ")
					.append("  LIMIT 1 ")
					.append(") AS rule_policy_exists ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRuleId);
			pstmt.setLong(2, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				bRulePolicyExists = rst.getBoolean("rule_policy_exists");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return bRulePolicyExists;
	}
	
	/**
	 * gets an action is referred to other action(s)
	 * 
	 * @param con
	 * @param lActionId
	 * @return
	 * @throws Exception
	 */
	public boolean isActionReferred(Connection con, long lActionId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();
		
		boolean bActionReferredExists = false;
		
		try {
			sbQuery	.append("SELECT EXISTS( ")
					.append("  SELECT 1 ")
					.append("  FROM so_sla_action sa WHERE reference_action_id = ? ")
					.append("  LIMIT 1 ")
					.append(") AS action_referred_exists ");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lActionId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				bActionReferredExists = rst.getBoolean("action_referred_exists");
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return bActionReferredExists;
	}
	
	/**
	 * updates particular action
	 * 
	 * @param con
	 * @param actionBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateAction(Connection con, SLAActionBean actionBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE so_sla_action SET ")
					.append("  action_name = ?, action_description = ?, ")
					.append("  is_public = ?, execution_type = ?, script = ?, ")
					.append("  parameter_format = ?, parameter_values = ?, ")
					.append("  modified_by = ?,  ")
					.append("  modified_on = NOW() ")
					.append("WHERE action_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, actionBean.getActionName());
			pstmt.setString(2, actionBean.getActionDescription());
			pstmt.setBoolean(3, actionBean.isPublic());
			pstmt.setString(4, actionBean.getExecutionType());
			pstmt.setString(5, actionBean.getScript());
			pstmt.setString(6, actionBean.getParameterFormat());
			pstmt.setString(7, actionBean.getParameterValues());
			pstmt.setLong(8, loginUserBean.getUserId());
			pstmt.setLong(9, actionBean.getActionId());
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * performs logical delete operation
	 * 
	 * @param con
	 * @param lActionId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteAction(Connection con, long lActionId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			//strQuery = "UPDATE so_sla_action SET is_delete = true WHERE action_id = ? AND user_id = ? ";
			strQuery = "DELETE FROM so_sla_action WHERE action_id = ? AND user_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lActionId);
			pstmt.setLong(2, loginUserBean.getUserId());;
			pstmt.executeUpdate();
			
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
	}
	
	/**
	 * get user added  actions 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */ 
	public JSONArray getActions(Connection con, LoginUserBean loginBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONObject joUserAction = null;
		JSONArray jaUserActions = new JSONArray();
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
				sbQuery	.append("SELECT action_id, action_name ")
				.append("FROM so_sla_action  ")
				.append("WHERE user_id=?  AND is_delete=false ")
				.append("ORDER BY action_name ");
				
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginBean.getUserId());
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joUserAction = new JSONObject();
				joUserAction.put("actionId", rst.getLong("action_id"));
				joUserAction.put("actionName", rst.getString("action_name"));
				joUserAction.put("isSelected", false);				
				jaUserActions.add(joUserAction);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return jaUserActions;
	}
	
	
	/**
	 * get user added  rules 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */ 
	public JSONArray getRules(Connection con, /*LoginUserBean loginBean*/ long lUser_id ) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONObject joUserAction = null;
		JSONArray jaUserActions = new JSONArray();
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
				sbQuery	.append("SELECT rule_id, rule_name ")
				.append("FROM so_rule  ")
				.append("WHERE user_id=?  ")
				.append("ORDER BY rule_name ");
				
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUser_id);
			rst = pstmt.executeQuery();
			while(rst.next()) {
				joUserAction = new JSONObject();
				joUserAction.put("ruleId", rst.getLong("rule_id"));
				joUserAction.put("ruleName", rst.getString("rule_name"));
								
				jaUserActions.add(joUserAction);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		
		return jaUserActions;
	}
	
	public boolean checkForRuleExists(Connection con, SLARuleBean ruleBean, LoginUserBean loginUserBean) throws Exception {
		
		boolean isExists = false;
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("SELECT rule_name, rule_id ")
					.append("FROM so_rule where lower(rule_name) = lower(?) AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, ruleBean.getRuleName());
			pstmt.setLong(2, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			
			if(rst.next()) {
				isExists = true;
			} else {
				isExists = false;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return isExists;
	}
	
	
	/**
	 * Saves SLA Rule details
	 * @param con
	 * @param ruleBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public long addSLARule(Connection con, SLARuleBean ruleBean, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		long lSLARuleId = -1L;
		try {
			
			sbQuery	.append("INSERT INTO so_rule (rule_name, rule_description, public, user_id, ")
			.append("enterprise_id, created_by, created_on)")
			.append("VALUES (?, ?, ?, ?, ?, ?,  NOW()) ");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, ruleBean.getRuleName());
			pstmt.setString(2, ruleBean.getRuleDescription());
			pstmt.setBoolean(3, ruleBean.isPublic());
			pstmt.setLong(4,  loginUserBean.getUserId());
			pstmt.setLong(5, loginUserBean.getEnterpriseId());
			pstmt.setLong(6, loginUserBean.getUserId());
		
			pstmt.executeUpdate();
			
			lSLARuleId = DataBaseManager.returnKey(pstmt);
		} catch (Exception e) {
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return lSLARuleId;
	}
	
	/**
	 * Saves SLA Rule Action details
	 * @param con
	 * @param ruleBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addSLARuleAction(Connection con, SLARuleBean ruleBean, Long lSLARuleId, LoginUserBean loginUserBean, Long actionId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		//long lSLARuleId = -1L;
		try {
			
			sbQuery	.append("INSERT INTO so_rule_action (rule_id, action_id, sequence_id, ")
			.append("created_by, modified_by, created_on, modified_on)")
			.append("VALUES (?, ?, ?, ?, ?, NOW(), NOW())");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, lSLARuleId);
			pstmt.setLong(2, actionId);
			pstmt.setLong(3, 1);
			pstmt.setLong(4, loginUserBean.getUserId());
			pstmt.setLong(5, loginUserBean.getUserId());
		
			pstmt.executeUpdate();
			
			//lSLARuleId = DataBaseManager.returnKey(pstmt);
			//System.out.println("SLA Rule Action Id:1111:::" +lSLARuleId);
		} catch (Exception e) {
			
			LogManager.infoLog(sbQuery.toString());
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		//return lSLARuleId;
	}
	
	/**
	 * check SlaRule exists already
	 * 
	 * @param con
	 * @param ruleName
	 * @param ruleId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isRuleExists(Connection con, String ruleName, long ruleId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bRuleExists = false;
		String strQuery = "";
		try {
			strQuery = "SELECT EXISTS(SELECT 1 FROM so_rule WHERE lower(rule_name)=LOWER(?) AND rule_id != ? AND user_id = ? LIMIT 1) as rule_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, ruleName);
			pstmt.setLong(2, ruleId);
			pstmt.setLong(3, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				bRuleExists = rst.getBoolean("rule_exists");
			}
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return bRuleExists;
	}
	
	
	/**
	 * delete deleteRuleAssociatedAction
	 * 
	 * @param con
	 * @param ruleId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteRuleActions(Connection con, long ruleId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder strQuery = new StringBuilder();
		
		try {
			strQuery.append("DELETE FROM so_rule_action WHERE rule_id = ?");
			
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setLong(1, ruleId);
			pstmt.executeUpdate();
			strQuery = new StringBuilder();
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(strQuery);
		}
	}
	
	
	
	/**
	 * Saves SLA Rule Action details
	 * @param con
	 * @param ruleBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addRuleAction(Connection con, Long lSLARuleId, long lSeqNo, long lActionId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		//long lSLARuleId = -1L;
		try {
			
			sbQuery	.append("INSERT INTO so_rule_action (rule_id, action_id, sequence_id, ")
			.append("created_by, created_on )")
			.append("VALUES (?, ?, ?, ?, NOW())");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, lSLARuleId);
			pstmt.setLong(2, lActionId);
			pstmt.setLong(3, lSeqNo);
			pstmt.setLong(4, loginUserBean.getUserId());
		
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * update SlaRule by rule_id
	 * 
	 * @param con
	 * @param ruleBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public void updateSlaRule(Connection con, SLARuleBean ruleBean, LoginUserBean loginUserBean) throws Exception {
		
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();

		try {
			
			sbQuery	.append("UPDATE so_rule SET ")
			.append("rule_name = ?, rule_description = ?, public = ?, ")
			.append(" modified_by = ?, modified_on = NOW() ")
			.append("WHERE rule_id = ? AND user_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, ruleBean.getRuleName());
			pstmt.setString(2, ruleBean.getRuleDescription());
			pstmt.setBoolean(3, ruleBean.isPublic());
			pstmt.setLong(4, loginUserBean.getUserId());
			pstmt.setLong(5, ruleBean.getRuleId());
			pstmt.setLong(6, loginUserBean.getUserId()); 
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * delete rule
	 * 
	 * @param con
	 * @param ruleId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteRule(Connection con, long ruleId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null, pstmtAssociation = null;
		
		StringBuilder strQuery = new StringBuilder();
		
		try {
			strQuery.append("DELETE FROM so_rule_action WHERE rule_id = ? ");
			
			pstmt = con.prepareStatement(strQuery.toString());
			pstmt.setLong(1, ruleId);
			//pstmt.setLong(2, loginUserBean.getUserId());;
			pstmt.executeUpdate();
			
			strQuery = new StringBuilder();
			
			strQuery.append("DELETE FROM so_rule WHERE rule_id = ? AND user_id = ? ");
			pstmtAssociation = con.prepareStatement(strQuery.toString());
			pstmtAssociation.setLong(1, ruleId);
			pstmtAssociation.setLong(2, loginUserBean.getUserId());;
			pstmtAssociation.executeUpdate();
			
			//strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmtAssociation);
			pstmtAssociation = null;
			UtilsFactory.clearCollectionHieracy(strQuery);
		}
	}
	
	
	/**
	 * To save sla 
	 * @param con
	 * @param ruleBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public long addSla(Connection con, SLABean slaBean, LoginUserBean loginBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		
		long lSLAId = -1L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("INSERT INTO so_sla(sla_name, sla_description, user_id, created_by, created_on, sla_type, email_body, sms_text, server_details, server_details_type, is_active, is_system, e_id) ")
					.append("VALUES(?, ?, ?, ?, NOW(), ?, 'Following Metrics are Breached ', 'Following Metrics are Breached ', ?, ?, ?, ?, ?)");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(1, slaBean.getSLAName());
			pstmt.setString(2, slaBean.getSLADescription());
			pstmt.setLong(3, loginBean.getUserId());
			pstmt.setLong(4, loginBean.getUserId());
			pstmt.setString(5, slaBean.getSLAType());
			pstmt.setString(6, slaBean.getSLAType().equalsIgnoreCase("Alert&Heal")?slaBean.getJoSlaConfigServFormat().toString():"");
			pstmt.setString(7, slaBean.getSLAType().equalsIgnoreCase("Alert&Heal")?slaBean.getPolicySvrType():"");
			pstmt.setBoolean(8, slaBean.isActivePolicy());
			pstmt.setBoolean(9, slaBean.isSystemGeneratedSLA());
			if(joEnterprise.getBoolean("is_owner") && joEnterprise.getInt("e_id") != 0){
				pstmt.setInt(10, joEnterprise.getInt("e_id"));
			}else{
				pstmt.setNull(10, java.sql.Types.INTEGER);
			}
			pstmt.executeUpdate();
			
			lSLAId = DataBaseManager.returnKey(pstmt);
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		
		return lSLAId;
	}
	
	/**
	 * gets SLA mapped for SUM test, 
	 * Note: only one SLA can configured for a SUM test, in other sense we can't have a SUM test for multiple SLAs 
	 *   (i.e. sum_test_id is unique in `so_sla_sum`)
	 *   
	 * @param con
	 * @param lSUMTestId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public Long getSLAMappedForSUMTest(Connection con, SLASUMBean slasumBean, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		Long lSLAId = null;

		String strQuery = "";

		try {
			strQuery = "SELECT sla_id FROM so_sla_sum WHERE sum_test_id = ? AND sum_type = ?";

			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, slasumBean.getSumTestId());
			// Included sum type , since a sum_test_id may have two sla's (response_monitor/availability)
			pstmt.setString(2, slasumBean.getSumType());
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				lSLAId = rst.getLong("sla_id");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;

			strQuery = null;
		}

		return lSLAId;
	}
	
	public Long getRUMModuleSLAId(Connection con, long lUId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		Long lSLAId = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT sla_id FROM so_sla_rum WHERE uid = ?";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUId);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				lSLAId = rst.getLong("sla_id");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return lSLAId;
	}
	
	public long addSlaSum(Connection con, SLASUMBean slaSumBean, LoginUserBean loginBean) throws Exception {
		PreparedStatement pstmt = null;
		
		long lSLASumId = -1L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery.setLength(0);
			sbQuery	.append("INSERT INTO so_sla_sum(sla_id, sum_test_id, sum_type, sum_counter_name, warning_limit, error_limit, min_breach_count, breach_type_id, created_by, created_on) ")
					.append("VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, now())");

			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);

			pstmt.setLong(1, slaSumBean.getSlaId());
			pstmt.setLong(2, slaSumBean.getSumTestId());
			pstmt.setString(3, slaSumBean.getSumType());
			pstmt.setString(4, slaSumBean.getSumCounterName());

			if (slaSumBean.getSumType().equals(SUM_TYPE.RESPONSE_MONITORING.toString())) {
				pstmt.setInt(5, slaSumBean.getWarningLimit());
				pstmt.setInt(6, slaSumBean.getErrorLimit());
			} else if (slaSumBean.getSumType().equals(SUM_TYPE.AVAILABILITY_MONITORING.toString())) {
				pstmt.setNull(5, Types.INTEGER);
				pstmt.setNull(6, Types.INTEGER);
			}

			pstmt.setInt(7, slaSumBean.getMinBreachCount());
			pstmt.setInt(8, slaSumBean.getBreachTypeId());
			pstmt.setLong(9, loginBean.getUserId());
			pstmt.executeUpdate();

			lSLASumId = DataBaseManager.returnKey(pstmt);
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return lSLASumId;
	}
	
	public long updateSlaSum(Connection con, SLASUMBean slaSumBean, LoginUserBean loginBean) throws Exception {
		PreparedStatement pstmt = null;
		long lSLASumId = -1L;
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery	.append("UPDATE so_sla_sum SET sum_counter_name = ?, warning_limit = ?, error_limit = ?, min_breach_count = ?, breach_type_id = ?, modified_by = ?, modified_on = now() ")
					.append(" WHERE sum_test_id = ? AND sla_id = ? AND sum_type = ?");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, slaSumBean.getSumCounterName());

			if (slaSumBean.getSumType().equals(SUM_TYPE.RESPONSE_MONITORING.toString())) {
				pstmt.setInt(2, slaSumBean.getWarningLimit());
				pstmt.setInt(3, slaSumBean.getErrorLimit());
			} else if (slaSumBean.getSumType().equals(SUM_TYPE.AVAILABILITY_MONITORING.toString())) {
				pstmt.setNull(2, Types.INTEGER);
				pstmt.setNull(3, Types.INTEGER);
			}

			pstmt.setInt(4, slaSumBean.getMinBreachCount());
			pstmt.setInt(5, slaSumBean.getBreachTypeId());
			pstmt.setLong(6, loginBean.getUserId());
			pstmt.setLong(7, slaSumBean.getSumTestId());
			pstmt.setLong(8, slaSumBean.getSlaId());
			pstmt.setString(9, slaSumBean.getSumType());
			
			pstmt.executeUpdate();
			
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		return lSLASumId;
	}
	
	/**
	 * inserts RUM module/uid's threshold limits
	 * 
	 * @param con
	 * @param rumslaBean
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public long addSLARUMThreshold(Connection con, RUMSLABean rumslaBean, LoginUserBean loginBean) throws Exception {
		PreparedStatement pstmt = null;
		
		long lSLARUMId = -1L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery.setLength(0);
			sbQuery	.append("INSERT INTO so_sla_rum (user_id, sla_id, uid, module_name, guid, is_above_threshold, breach_type_id, warning_threshold_value, critical_threshold_value, min_breach_count, created_by, created_on) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now())");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			
			pstmt.setLong(1, rumslaBean.getUserId());
			pstmt.setLong(2, rumslaBean.getSlaId());
			pstmt.setLong(3, rumslaBean.getUId());
			pstmt.setString(4, rumslaBean.getModuleName());
			pstmt.setString(5, rumslaBean.getGUID());
			pstmt.setBoolean(6, rumslaBean.isAboveThreshold());
			pstmt.setInt(7, rumslaBean.getBreachTypeId());
			pstmt.setInt(8, rumslaBean.getWarningThresholdValue());
			pstmt.setInt(9, rumslaBean.getCriticalThresholdValue());
			pstmt.setInt(10, rumslaBean.getMinBreachCount());
			pstmt.setLong(11, loginBean.getUserId());
			pstmt.executeUpdate();
			
			lSLARUMId = DataBaseManager.returnKey(pstmt);
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
		
		return lSLARUMId;
	}
	
	/**
	 * updates RUM module/uid's threshold limits 
	 * 
	 * @param con
	 * @param rumslaBean
	 * @param loginBean
	 * @throws Exception
	 */
	public void updateSLARUMModule(Connection con, RUMSLABean rumslaBean, LoginUserBean loginBean) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE so_sla_rum SET ")
					.append("  module_name = ?, is_above_threshold = ?, ")
					.append("  warning_threshold_value = ?, critical_threshold_value = ?, min_breach_count = ?, ")
					.append("  modified_by = ?, modified_on = now() ")
					.append("WHERE uid = ? AND sla_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, rumslaBean.getModuleName());
			pstmt.setBoolean(2, rumslaBean.isAboveThreshold());
			pstmt.setInt(3, rumslaBean.getWarningThresholdValue());
			pstmt.setInt(4, rumslaBean.getCriticalThresholdValue());
			pstmt.setInt(5, rumslaBean.getMinBreachCount());
			pstmt.setLong(6, loginBean.getUserId());
			pstmt.setLong(7, rumslaBean.getUId());
			pstmt.setLong(8, rumslaBean.getSlaId());
			
			pstmt.executeUpdate();
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
	}
	
	public void saveRule(Connection con, long lSLAId, int nRuleId, /*LoginUserBean loginBean*/ long lUser_id) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE FROM so_sla_rule WHERE sla_id = ").append(lSLAId);
			pstmt1 = con.prepareStatement(sbQuery.toString());
			pstmt1.execute();
			
			if(nRuleId != -1){
				sbQuery.setLength(0);
				sbQuery .append("INSERT INTO so_sla_rule(sla_id, rule_id, sequence_id, created_by, created_on) ")
						.append("VALUES(?, ?, ?, ?, NOW())");
				pstmt = con.prepareStatement(sbQuery.toString());
				pstmt.setLong(1, lSLAId);
				pstmt.setInt(2, nRuleId);
				pstmt.setInt(3, 1);
				pstmt.setLong(4, lUser_id);
				
				pstmt.executeUpdate();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	public boolean isSLANameExist(Connection con, String strPolicyName, long lpolicyId, /*LoginUserBean loginUserBean*/ long lUser_id) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bRuleExists = false;
		String strQuery = "";
		try {
			strQuery = "SELECT EXISTS(SELECT 1 FROM so_sla WHERE lower(sla_name)=LOWER(?) AND sla_id != ? AND user_id = ? LIMIT 1) as policy_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strPolicyName);
			pstmt.setLong(2, lpolicyId);
			pstmt.setLong(3, lUser_id);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				bRuleExists = rst.getBoolean("policy_exists");
			}
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return bRuleExists;
	}
	
	public long isSLASUMNameExist(Connection con, String strPolicyName, long lpolicyId, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		long slaId = -1L;
		String strQuery = "";
		try {
			strQuery = "SELECT sla_id FROM so_sla WHERE lower(sla_name)=LOWER(?) AND sla_id != ? AND user_id = ? LIMIT 1";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, strPolicyName);
			pstmt.setLong(2, lpolicyId);
			pstmt.setLong(3, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			if(rst.next()) {
				slaId = rst.getLong("sla_id");
			}
			strQuery = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
		}
		return slaId;
	}
	
	/**
	 * Getting Types of modules
	 * 
	 * @param con
	 * @param strType
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleTypeValues(Connection con, String strType, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaModules = new JSONArray();
		JSONObject joModule = null;
		try{
			sbQuery .append("SELECT mm.uid, mm.guid, mm.module_name, ctv.counter_type_version_id, ct.counter_type_name|| ' ' || ctv.version  as counter ")
					.append("FROM module_master mm ")
					.append("INNER JOIN counter_type_version ctv on ctv.counter_type_version_id = mm.counter_type_version_id AND mm.module_code = ? ")
					.append("INNER JOIN counter_type ct on ctv.counter_type_id = ct.counter_type_id ")
					.append("AND mm.user_id = ? ");
					if(joEnterprise.getInt("e_id")!= 0){
						sbQuery .append("AND mm.e_id = ").append(joEnterprise.getLong("e_id"));
					}
			sbQuery .append("ORDER BY mm.module_name");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strType);
			if(joEnterprise.getInt("e_id")!= 0){
				pstmt.setLong(2, joEnterprise.getLong("e_user_id"));
			}else{
				pstmt.setLong(2, loginUserBean.getUserId());
			}
			
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joModule = new JSONObject();
				joModule.put("moduleName", rs.getString("module_name"));
				joModule.put("uid", rs.getInt("uid"));
				joModule.put("counterType", rs.getString("counter"));
				joModule.put("guid", rs.getString("guid"));
				joModule.put("ctvId", rs.getInt("counter_type_version_id"));
				jaModules.add(joModule);
				joModule = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return jaModules;
	}
	
	/**
	 * Getting available categories
	 * 
	 * @param con
	 * @param nApplicationId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCategory(Connection con, int nId) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaAPCounters = new JSONArray();
		JSONObject joAPCounter = null;
		
		try {
			sbQuery .append("select distinct(category) from counter_master_")
					.append(nId)
					.append(" WHERE is_selected = true ")
					.append(" ORDER BY category");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joAPCounter = new JSONObject();
				joAPCounter.put("category", rs.getString("category"));
				
				jaAPCounters.add(joAPCounter);
				joAPCounter = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
			joAPCounter = null;
			
		}
		return jaAPCounters;
	}
	
	/**
	 * Getting application counters
	 * @param con
	 * @param nApplicationID
	 * @param strCategory
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCounters(Connection con, long lUID) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaCounters = new JSONArray();
		JSONObject joCounter = null;
		
		try {
			sbQuery	.append("SELECT cm.counter_id, cm.counter_template_id, cm.category, cm.counter_name, cm.display_name, cm.unit, ")
					.append("cm.is_percentage, cm.is_above_threshold, cm.warning_threshold_value, cm.critical_threshold_value, max_value_counter_id ")
					.append("FROM counter_master_").append(lUID).append(" cm ")
					.append("WHERE cm.is_selected = true ")
					.append("ORDER BY cm.category, cm.counter_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			//pstmt.setString(1, strCategory);
			rst = pstmt.executeQuery();
			while(rst.next()){
				joCounter = new JSONObject();
				joCounter.put("counterId", rst.getInt("counter_id"));
				joCounter.put("counter_id", rst.getInt("counter_id"));
				joCounter.put("ctId", rst.getInt("counter_template_id"));
				joCounter.put("category", rst.getString("category"));
				joCounter.put("name", rst.getString("counter_name"));
				joCounter.put("displayName", rst.getString("display_name"));
				joCounter.put("unit", rst.getString("unit"));
				joCounter.put("isThreshold", rst.getBoolean("is_above_threshold"));
				joCounter.put("isPercentage", rst.getBoolean("is_percentage"));
				joCounter.put("warning_threshold_value", rst.getLong("warning_threshold_value"));
				joCounter.put("critical_threshold_value", rst.getLong("critical_threshold_value"));
				joCounter.put("max_value_counter_id", rst.getInt("max_value_counter_id"));
				jaCounters.add(joCounter);
				joCounter = null;
			}
		} catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			
			joCounter = null;
		}
		return jaCounters;
	}
	
	/**
	 * Adding a counter
	 * 
	 * @param con
	 * @param bean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addMapCounter(Connection con, MapCounterBean bean, LoginUserBean loginUserBean) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery	.append("INSERT INTO so_sla_counter(sla_id, module_name, module_detail_name, uid, guid, counter_type_version_id, counter_type_name, counter_template_id, ")
					.append("counter_id, breach_type_id, is_percentage, is_above_threshold, warning_threshold_value, critical_threshold_value, min_breach_count, created_by, created_on, category_name, percentage_calculation, denominator_counter_id) ")
					.append("VALUES(?, ?, ?, ?, ?, ?, ?, ?, ")
					.append("?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?)");

			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);

			pstmt.setLong(1, bean.getSLAId());
			pstmt.setString(2, bean.getModuleName());
			pstmt.setString(3, bean.getModuleDetailedValue());
			pstmt.setInt(4, bean.getUId());
			pstmt.setString(5, bean.getGuid());
			pstmt.setInt(6, bean.getCounterTypeVersionId());
			pstmt.setString(7, bean.getCounterName());
			pstmt.setInt(8, bean.getCounterTemplateId());
			pstmt.setInt(9, bean.getCounterId());
			pstmt.setInt(10, bean.getBreachId());
			pstmt.setBoolean(11, bean.isInPercentage());
			pstmt.setBoolean(12, bean.isIsThresholdAbove());
			pstmt.setLong(13, bean.getWarningThresholdValue());
			pstmt.setLong(14, bean.getCriticalThresholdValue());
			pstmt.setInt(15, bean.getMinBreachCount());
			pstmt.setLong(16, loginUserBean.getUserId());
			pstmt.setString(17, bean.getCategory());
			pstmt.setBoolean(18, bean.isPercentageCalculation());
			if(bean.getDenominatorCounteId() > 0){
				pstmt.setLong(19, bean.getDenominatorCounteId());	
			}else{
				pstmt.setNull(19, Types.INTEGER);
			}

			pstmt.executeUpdate();

		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public void mapToAlert(Connection con, MapCounterBean bean, LoginUserBean loginUserBean) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery	.append("INSERT INTO so_sla_counter (sla_id, module_name, module_detail_name, uid, guid, counter_type_version_id, counter_type_name, counter_template_id, counter_id, category_name, ")
					.append(" breach_type_id, is_percentage, is_above_threshold,  critical_threshold_value, min_breach_count, created_by, created_on, warning_threshold_value) ")
					.append(" SELECT ?, mm.module_code, mm.module_name, mm.uid, mm.guid, mm.counter_type_version_id, cm.counter_name, cm.counter_template_id, cm.counter_id, cm.category, ?, ")
					.append(" cm.is_percentage, ?, ?, ?, ?, now(), ? ")
					.append(" FROM module_master mm LEFT JOIN counter_master_").append(bean.getUId()).append(" cm ON mm.user_id=cm.user_id AND mm.guid=cm.guid WHERE ")
					.append(" mm.user_id = ? AND mm.uid=? AND cm.counter_id=?");

			pstmt = con.prepareStatement(sbQuery.toString());

			pstmt.setLong(1, bean.getSLAId());
			pstmt.setInt(2, bean.getBreachId());
			pstmt.setBoolean(3, bean.isIsThresholdAbove());
			pstmt.setLong(4, bean.getCriticalThresholdValue());
			pstmt.setInt(5, bean.getMinBreachCount());
			pstmt.setLong(6, loginUserBean.getUserId());
			pstmt.setLong(7, bean.getWarningThresholdValue());
			pstmt.setLong(8, loginUserBean.getUserId());
			pstmt.setLong(9, bean.getUId());
			pstmt.setLong(10, bean.getCounterId());
			
			pstmt.executeUpdate();

		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	/**
	 * get available map counters.
	 * 
	 * @param con
	 * @param lSLAId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getMapCounters(Connection con, long lSLAId, /*LoginUserBean loginUserBean*/ long lUser_id) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONArray jaMapCounters = new JSONArray();
		JSONObject joMapCounter = null;

		try {
			// ASK below query
			sbQuery	.append("SELECT ssc.sla_counter_id, ssc.is_percentage, ssc.is_above_threshold, ssc.warning_threshold_value, ssc.critical_threshold_value, ssc.min_breach_count, ")
					.append("  ssc.module_name, ssc.module_detail_name, ssc.breach_type_id, ssc.counter_id, ssc.counter_type_version_id, ssc.guid, ssc.uid, bt.breach_type, ")
					.append("  ssc.counter_template_id, ct.category, ct.counter_name, ct.display_name, CASE WHEN ssc.percentage_calculation THEN '%' else ct.unit END as unit ")
					.append("FROM so_sla_counter ssc ")
					.append("INNER JOIN breach_type bt ON bt.breach_type_id = ssc.breach_type_id ")
					.append("INNER JOIN counter_template ct ON ct.counter_template_id = ssc.counter_template_id AND ssc.sla_id = ? /*AND ssc.created_by = 8 */ ")
					/*-- ask below required*/	
					.append("INNER JOIN so_sla ss ON ss.sla_id = ssc.sla_id AND ss.user_id = ? ")
					.append("ORDER BY ct.category, ct.display_name ");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lSLAId);
			pstmt.setLong(2, lUser_id);
			rst = pstmt.executeQuery();
			while(rst.next()){
				joMapCounter = new JSONObject();
				joMapCounter.put("mapCounterId", rst.getInt("sla_counter_id"));
				joMapCounter.put("category", rst.getString("category"));
				//joMapCounter.put("countername", rs.getString("counter_type_name"));
				joMapCounter.put("countername", rst.getString("display_name"));
				joMapCounter.put("counter_name", rst.getString("counter_name"));
				joMapCounter.put("display_name", rst.getString("display_name"));
				joMapCounter.put("inPercentage", rst.getBoolean("is_percentage"));
				joMapCounter.put("isThresholdAbove", rst.getBoolean("is_above_threshold"));
				joMapCounter.put("warning_threshold_value", rst.getLong("warning_threshold_value"));
				joMapCounter.put("critical_threshold_value", rst.getLong("critical_threshold_value"));
				joMapCounter.put("minBreachCount", rst.getInt("min_breach_count"));
				joMapCounter.put("moduleName", rst.getString("module_name"));
				joMapCounter.put("moduleValue", rst.getString("module_detail_name"));
				joMapCounter.put("breachTypeId", rst.getInt("breach_type_id"));
				joMapCounter.put("breachType", rst.getString("breach_type"));
				joMapCounter.put("counterId", rst.getInt("counter_id"));
				joMapCounter.put("ctId", rst.getInt("counter_template_id"));
				joMapCounter.put("ctvId", rst.getInt("counter_type_version_id"));
				joMapCounter.put("guid", rst.getString("guid"));
				joMapCounter.put("uid", rst.getInt("uid"));
				joMapCounter.put("unit", rst.getString("unit"));

				jaMapCounters.add(joMapCounter);

				joMapCounter = null;
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jaMapCounters;
	}
	
	public JSONArray getCounterMappedAlerts(Connection con, long lUID, long lCounterId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONArray jaMapCounters = new JSONArray();
		JSONObject joMapCounter = null;

		try {
			sbQuery	.append("SELECT ss.sla_id, ssc.sla_counter_id, ss.sla_name, ssc.guid, ssc.critical_threshold_value, ssc.warning_threshold_value, ssc.is_above_threshold,")
					.append(" ssc.min_breach_count, CASE WHEN ssc.percentage_calculation THEN '%' else ct.unit END as unit FROM so_sla ss ")
					.append(" LEFT JOIN so_sla_counter ssc ON ssc.sla_id = ss.sla_id")
					.append(" INNER JOIN counter_template ct ON ct.counter_template_id = ssc.counter_template_id")
					.append(" WHERE  ssc.uid = ? AND ssc.counter_id = ?");

			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUID);
			pstmt.setLong(2, lCounterId);
			rst = pstmt.executeQuery();
			while(rst.next()){
				joMapCounter = new JSONObject();
				joMapCounter.put("slaCounterId", rst.getString("sla_counter_id"));
				joMapCounter.put("uid", lUID);
				joMapCounter.put("guid", rst.getString("guid"));
				joMapCounter.put("slaId", rst.getLong("sla_id"));
				joMapCounter.put("counterId", lCounterId);
				joMapCounter.put("slaName", rst.getString("sla_name"));
				joMapCounter.put("criticalValue", rst.getLong("critical_threshold_value"));
				joMapCounter.put("warningValue", rst.getLong("warning_threshold_value"));
				joMapCounter.put("isAboveThreshold", rst.getBoolean("is_above_threshold"));
				joMapCounter.put("minBreachCount", rst.getInt("min_breach_count"));
				joMapCounter.put("unit", rst.getString("unit"));

				jaMapCounters.add(joMapCounter);

				joMapCounter = null;
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jaMapCounters;
	}
	
	/**
	 * gets active SLAs counter(s)
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> getActiveSLAsCounters(String strGUIDs) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		Connection con = DataBaseManager.giveConnection();
		
		StringBuilder sbQuery = new StringBuilder();
		String strGUID = "";
		
		HashMap<String, Object> hmGUIDsMappedToSLAs = new HashMap<String, Object>();
		ArrayList<JSONObject> alSLAs = null;

		JSONObject joSLACounter = null;
		
		try{
			sbQuery .append("SELECT ssc.sla_id, ss.user_id, ssc.counter_id, ssc.counter_template_id, ssc.guid, ")
					.append("  ssc.is_above_threshold, ssc.warning_threshold_value, ssc.critical_threshold_value, ssc.percentage_calculation, ssc.denominator_counter_id ")
					.append("FROM so_sla_counter ssc ")
					.append("INNER JOIN so_sla ss ON ss.sla_id = ssc.sla_id ")
					.append("  AND ssc.guid IN (").append(strGUIDs).append(") ")
					.append("  AND ss.is_active = TRUE ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while( rst.next() ){
				joSLACounter = new JSONObject();
				strGUID = rst.getString("guid");
				
				joSLACounter.put("slaid", rst.getLong("sla_id"));
				joSLACounter.put("userid", rst.getLong("user_id"));
				joSLACounter.put("counterid", rst.getLong("counter_id"));
				joSLACounter.put("countertempid", rst.getLong("counter_template_id"));
				joSLACounter.put("isabovethreshold", rst.getBoolean("is_above_threshold"));
				joSLACounter.put("warning_threshold_value", rst.getLong("warning_threshold_value"));
				joSLACounter.put("critical_threshold_value", rst.getLong("critical_threshold_value"));
				joSLACounter.put("percentage_calculation", rst.getBoolean("percentage_calculation"));
				if( rst.getString("denominator_counter_id")!= null ){
					joSLACounter.put("denominator_counter_id", rst.getInt("denominator_counter_id"));
				}
				
				if ( hmGUIDsMappedToSLAs.containsKey(strGUID) ) {
					alSLAs = (ArrayList<JSONObject>) hmGUIDsMappedToSLAs.get(strGUID);
				} else {
					alSLAs = new ArrayList<JSONObject>();
					
					// obj by ref
					hmGUIDsMappedToSLAs.put(strGUID, alSLAs);
				}
				alSLAs.add(joSLACounter);
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(con);
			con = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			strGUID = null;
		}
		
		return hmGUIDsMappedToSLAs;
	}
	
	public boolean isCounterExist(Connection con, MapCounterBean bean, LoginUserBean loginBean) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		boolean bCounterExist = false;

		StringBuilder sbQuery = new StringBuilder();

		try {
			sbQuery .append("SELECT EXISTS(SELECT 1 FROM so_sla_counter WHERE sla_id=? AND counter_id=? AND guid=? LIMIT 1) as counter_exists");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, bean.getSLAId());
			pstmt.setLong(2, bean.getCounterId());
			pstmt.setString(3, bean.getGuid());
			rst = pstmt.executeQuery();
	
			if(rst.next()){
				bCounterExist = rst.getBoolean("counter_exists");
			}

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		return bCounterExist;
	}
	
	
	/**
	 * Check whether a counters's max_value_counter_id is selected
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getMaxValueCounterIdDetail(Connection con , long lUID, long lCounterId) throws Exception {

		PreparedStatement pstmt = null;
		ResultSet rst = null;

		StringBuilder sbQuery = new StringBuilder();

		JSONObject joMaxValueCounterIdDetail = null;
		try{
			sbQuery	.append("SELECT is_selected, display_name FROM counter_master_").append(lUID)
					.append(" WHERE counter_id = ?");

			pstmt = con.prepareStatement(sbQuery.toString());

			pstmt.setLong(1, lCounterId);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				joMaxValueCounterIdDetail = new JSONObject();
				joMaxValueCounterIdDetail.put("isSelected", rst.getBoolean("is_selected"));
				joMaxValueCounterIdDetail.put("displayName", rst.getString("display_name"));

			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return joMaxValueCounterIdDetail;
	}

	/**
	 * Deleting map counter
	 * 
	 * @param con
	 * @param nMapCounterId
	 * @throws Exception
	 */
	public void deleteMapCounter(Connection con, int nMapCounterId) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from so_sla_counter ")
					.append("WHERE sla_counter_id=?");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, nMapCounterId);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * updating SLA Settings
	 * 
	 * @param con
	 * @param nMaxTryCount
	 * @param nTryCountDuration
	 * @param nTriggerAlertDuration
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void slaSettings(Connection con, int nMaxTryCount, int nTryCountDuration, int nTriggerAlertDuration, LoginUserBean loginUserBean) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery .append("UPDATE sa_sla_setting SET max_try_count=?, try_count_duration_in_min=?, trigger_alert_every_in_min=? ")
					.append("WHERE user_id = ?");
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setInt(1, nMaxTryCount);
			pstmt.setInt(2, nTryCountDuration);
			pstmt.setInt(3, nTriggerAlertDuration);
			pstmt.setLong(4, loginUserBean.getUserId());
			
			pstmt.execute();
			
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	/**
	 * insert's SLA Settings for the user
	 * 
	 * @param con
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void insertSLASettings(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null, pstmt1 = null;
		ResultSet rst = null;
		
		boolean bSettingsExists = false;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT EXISTS(SELECT 1 FROM sa_sla_setting WHERE user_id =? LIMIT 1) as settings_exists";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			if(rst.next()) {
				bSettingsExists = rst.getBoolean("settings_exists");
			}
			if ( ! bSettingsExists ) {
				strQuery = null;
				strQuery = "INSERT INTO sa_sla_setting(user_id, max_try_count, try_count_duration_in_min, trigger_alert_every_in_min, created_by, created_on) VALUES(?, ?, ?, ?, ?, now())";
				pstmt1 = con.prepareStatement(strQuery);
				pstmt1.setLong(1, lUserId);
				pstmt1.setInt(2, Constants.SLA_SETTING_MAX_TRY_COUNT);
				pstmt1.setInt(3, Constants.SLA_SETTING_TRY_COUNT_DURATION_IN_MIN);
				pstmt1.setInt(4, Constants.SLA_SETTING_TRIGGER_ALERT_EVERY_IN_MIN);
				pstmt1.setLong(5, 1);	// Indication to know that this is added automatically. So used Sysadmin's user-id.
				pstmt1.execute();
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(pstmt1);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * Getting SLA Settings
	 * 
	 * @param con
	 * @param bean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getSLASettings(Connection con, LoginUserBean bean) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		JSONObject joSetting = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			joSetting = new JSONObject();
			sbQuery .append("select * from sa_sla_setting where user_id=?");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, bean.getUserId());
			rs = pstmt.executeQuery();
			if(rs.next()){
				joSetting.put("maxtrycount", rs.getInt("max_try_count"));
				joSetting.put("trycountduration", rs.getInt("try_count_duration_in_min"));
				joSetting.put("triggeralert", rs.getInt("trigger_alert_every_in_min"));
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
		
		return joSetting;
	}
	
	
	/**
	 * inserting SLA Alert
	 * 
	 * @param con
	 * @param jaSLAAlerts
	 * @param loginUserBean
	 * @throws Exception
	 */
	public long insertSLAAlertAddress(Connection con, String strSlaAlertType, String strSlaMobileOrEmail, int nTelephoneCode, long lUserId, boolean bAddressAlreadyVerified) throws Exception {
		PreparedStatement pstmt = null;
		
		long lSLASettingId = -1L;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery .append("INSERT INTO so_alert(user_id, enterprise_id, alert_type, email_mobile, telephone_code, created_by, created_on, is_valid, validated_on) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, now(), ?, ?) ");
			
			pstmt = con.prepareStatement(sbQuery.toString(), Statement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, lUserId);
			pstmt.setLong(2, -1L);
			pstmt.setString(3, strSlaAlertType);
			pstmt.setString(4, strSlaMobileOrEmail);
			if (strSlaAlertType.equals("SMS")) {
				pstmt.setInt(5, nTelephoneCode);
			} else {
				pstmt.setNull(5, Types.INTEGER);
			}
			pstmt.setLong(6, lUserId);
			if ( ! bAddressAlreadyVerified ) {	// new email, not verified
				pstmt.setBoolean(7, false);
				pstmt.setNull(8, Types.TIMESTAMP);
			} else {	// email already verified, might verified in AVM 
				pstmt.setBoolean(7, true);
				pstmt.setTimestamp(8, new Timestamp(System.currentTimeMillis()));
			}
			
			pstmt.execute();
			
			lSLASettingId = DataBaseManager.returnKey(pstmt);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return lSLASettingId;
	}
	
	public boolean isEmailExist(Connection con, String strSlaAlertType, String strSlaMobileOrEmail, long lUserID) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		boolean bIsExist = false;
		StringBuilder sbQuery = new StringBuilder();
		Date dateLog = LogManager.logMethodStart();
		try{
//			sbQuery .append("select case when email_mobile=? then true else false end as isexist   from so_alert where user_id=? ");
			sbQuery .append("SELECT EXISTS(SELECT 1 FROM so_alert WHERE email_mobile = ? AND user_id = ? LIMIT 1) as isexist");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setString(1, strSlaMobileOrEmail);
			pstmt.setLong(2, lUserID);
			rs = pstmt.executeQuery();
			while(rs.next()){
				
				bIsExist = rs.getBoolean(1);
				
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			DataBaseManager.close(rs);
			rs = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
			LogManager.logMethodEnd(dateLog);
		}
		return bIsExist;
	}
	public JSONArray getAlertsSettings(Connection con, LoginUserBean loginUserBean) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaSLARecords = new JSONArray();
		JSONObject joSLARecord = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("SELECT sla_setting_id, alert_type, email_mobile, is_valid, ")
					.append("  CASE WHEN is_valid is false THEN 'Not Verified' ELSE 'Verified' END as status ")
					.append("FROM so_alert ")
					.append("WHERE user_id = ? ")
					.append("ORDER BY alert_type, email_mobile ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, loginUserBean.getUserId());
			rst = pstmt.executeQuery();
			while(rst.next()){
				joSLARecord = new JSONObject();
				joSLARecord.put("alertId", rst.getString("sla_setting_id"));
				joSLARecord.put("alertType", rst.getString("alert_type"));
				joSLARecord.put("emailOrMobile", rst.getString("email_mobile"));
				joSLARecord.put("status", rst.getString("status"));
				joSLARecord.put("isVerified", rst.getBoolean("is_valid"));
				
				jaSLARecords.add(joSLARecord);
				joSLARecord = null;
			}
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		return jaSLARecords;
	}
	
	/**
	 * checks the email is already verified in `SLA`(`so_alert`) or `AVM`(`avm_agent_alert_mapping`)
	 * 
	 * @param con
	 * @param strEmailOrMobileNumber
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isEmailAlreadyVerified(Connection con, String strEmailOrMobileNumber, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "";
		
		boolean bEmailAlreadyVerified = false;
		
		try {
			strQuery = "SELECT is_email_already_verified(?, ?) AS is_email_already_verified";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strEmailOrMobileNumber);
			rst = pstmt.executeQuery();
			if ( rst.next() ) {
				bEmailAlreadyVerified = rst.getBoolean("is_email_already_verified");
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return bEmailAlreadyVerified;
	}
	
	/**
	 * Deleting map counter
	 * 
	 * @param con
	 * @param lMapCounterId
	 * @throws Exception
	 */
	public void deleteMapCounter(Connection con, long lSlaId, long lMapCounterId) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from so_sla_counter ")
					.append("WHERE sla_counter_id=? AND sla_id=? ");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, lMapCounterId);
			pstmt.setLong(2, lSlaId);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * Get available Breach types
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getBrechTypes(Connection con, LoginUserBean loginUserBean) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaBrechTypes = new JSONArray();
		JSONObject joBreachType = null;
		try{
			sbQuery .append("SELECT * from breach_type ")
					.append("ORDER BY breach_type");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joBreachType = new JSONObject();
				joBreachType.put("breachType", rs.getString("breach_type"));
				joBreachType.put("breachId", rs.getInt("breach_type_id"));
				jaBrechTypes.add(joBreachType);
				joBreachType = null;
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return jaBrechTypes;
	}
	
	/**
	 * get available Sla Menu Badge
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getSlaMenuBadge(Connection con, LoginUserBean loginBean) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONObject joSlaMenuBadge = null;
		try{
			sbQuery	.append("SELECT * FROM get_sla_menu_badge(")
			.append(loginBean.getUserId())
			.append(")");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				joSlaMenuBadge = new JSONObject();
				joSlaMenuBadge.put("action_count", rs.getInt("action_count"));
				joSlaMenuBadge.put("rule_count", rs.getInt("rule_count"));
				joSlaMenuBadge.put("sla_count", rs.getInt("sla_count"));
				
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(rs);
			rs = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return joSlaMenuBadge;
	}
	
	/**
	 * Deleting SLA Alert Record
	 * 
	 * @param con
	 * @param nSLASettingId
	 * @throws Exception
	 */
	public void deleteSLARecord(Connection con, int nSLASettingId) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery .append("DELETE FROM so_alert ")
					.append("WHERE sla_setting_id=?");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setInt(1, nSLASettingId);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	public JSONArray getMappedRuleActions(Connection con, long lRuleId, LoginUserBean loginUserBean) throws Exception {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaRuleActions = new JSONArray();
		JSONObject joTemp = null;
		//JSONObject joRuleAction = null, joTemp = null;
		try {
			
//			sbQuery	.append("SELECT ssa.action_id, action_name, counter_id, ct.counter_template_id, counter_name, category, mm.uid, ")
//					.append("module_code, agent_version_id, mm.module_name, concat(ct.counter_type_name, ' ', ctv.version) AS agent_name, sequence_id ")
//					.append("FROM so_sla_action ssa ")
//					.append("INNER JOIN so_rule_action sra on sra.action_id = ssa.action_id and sra.rule_id=? ")
//					.append("INNER JOIN counter_template ct on ct.counter_template_id = ssa.counter_template_id ")
//					.append("INNER JOIN module_master mm on mm.uid = ssa.uid ")
//					.append("INNER JOIN counter_type_version ctv on ctv.counter_type_version_id = mm.counter_type_version_id ")
//					.append("INNER JOIN counter_type cot on cot.counter_type_id = ctv.counter_type_id ");
			

			sbQuery	.append("SELECT ssa.action_id, action_name FROM so_sla_action ssa INNER JOIN  so_rule_action sra on sra.action_id = ssa.action_id and sra.rule_id=?  AND ssa.is_delete=false ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lRuleId);
		
			rs = pstmt.executeQuery();
			while(rs.next()){
				//joRuleAction = new JSONObject();
				
//				joRuleAction.put("seqNo", rs.getLong("sequence_id"));
//				
//				joTemp = new JSONObject();
//				joTemp.put("agentName", rs.getString("agent_name"));
//				joTemp.put("moduleName", rs.getString("module_code"));
//				joTemp.put("counterTypeVersionId", rs.getLong("agent_version_id"));
//				joRuleAction.put("type", joTemp);
//				joTemp = null;
//				
//				joTemp = new JSONObject();
//				joTemp.put("uid", rs.getLong("uid"));
//				joTemp.put("moduleName", rs.getString("module_name"));
//				joRuleAction.put("typeValue", joTemp);
//				joTemp = null;
//				
//				joRuleAction.put("category", rs.getString("category"));
//				
//				joTemp = new JSONObject();
//				joTemp.put("counterId", rs.getLong("counter_id"));
//				joTemp.put("counterTemplateId", rs.getLong("counter_template_id"));
//				joTemp.put("counterName", rs.getString("counter_name"));
//				joRuleAction.put("counter", joTemp);
//				joTemp = null;
				
				joTemp = new JSONObject();
				joTemp.put("actionId", rs.getLong("action_id"));
				joTemp.put("actionName", rs.getString("action_name"));
				joTemp.put("isSelected", true);
				//joTemp.put("counterId", rs.getLong("counter_id"));
				//joRuleAction.put("actionName", joTemp);
				//joTemp = null;
				
				jaRuleActions.add(joTemp);
				//joRuleAction = null;
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
		return jaRuleActions;
	}
	
	/**
	 * updates email verification, 
	 *  in `SLA`, `AVM`, of address not verified in `so_alert`, `avm_agent_alert_mapping`
	 * 
	 * @param con
	 * @param lSLASettingId
	 * @throws Exception
	 */
	public void verifySLAEmailAddress(Connection con, long lSLASettingId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT * FROM verify_alert_address('SLA', ?) ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lSLASettingId);
			
			pstmt.execute();
			
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * verify SLA email address based on user_id and email_id
	 * 
	 * @param con
	 * @param lUserId
	 * @param strEmailId
	 * @throws Exception
	 */
	public void verifySLAEmailAddress(Connection con, long lUserId, String strEmailId) throws Exception {
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery .append("UPDATE so_alert SET ")
					.append(" is_valid = true, ")
					.append(" validated_on = now() ")
					.append("WHERE user_id = ? AND email_mobile = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strEmailId);
			pstmt.execute();
		}catch(Exception e){
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy(sbQuery);
		}
	}
	
	
	/**
	 * Update SLA
	 * @param con
	 * @param slaBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSLA(Connection con, SLABean slaBean, /*LoginUserBean loginBean*/ long lUser_id) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			//sla_name=?, sla_description=?, user_id=?, created_by=?, created_on=?, sla_type=?, email_body=?, sms_text=?, server_details=?, server_details_type=?
			sbQuery	.append("UPDATE so_sla SET ")
					.append("  sla_name = ?, sla_description = ?, modified_by = ?, modified_on = NOW(), ")
					.append("  sla_type = ?, server_details = ?, server_details_type = ?, is_active = ? ")
					.append("WHERE sla_id = ? ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setString(1, slaBean.getSLAName());
			pstmt.setString(2, slaBean.getSLADescription());
			pstmt.setLong(3, lUser_id);
			pstmt.setString(4, slaBean.getSLAType());
			pstmt.setString(5, slaBean.getSLAType().equalsIgnoreCase("Alert&Heal")?slaBean.getJoSlaConfigServFormat().toString():"");
			pstmt.setString(6, slaBean.getSLAType().equalsIgnoreCase("Alert&Heal")?slaBean.getPolicySvrType():"");
			pstmt.setBoolean(7, slaBean.isActivePolicy());
			pstmt.setLong(8, slaBean.getSLAId());
			pstmt.executeUpdate();
			
		}catch(Exception e){
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			sbQuery = null;
		}
	}
	
	/**
	 * deleting sla Record
	 * 
	 * @param con
	 * @param lSLAId
	 * @throws Exception
	 */
	public void removeSLARecord(Connection con, long lSLAId) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from so_sla ")
					.append("WHERE sla_id=?");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, lSLAId);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * Deleting mapped to rule
	 * @param con
	 * @param lSLAId
	 * @throws Exception
	 */
	public void removeAssociatedRule(Connection con, long lSLAId) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from so_sla_rule ")
					.append("WHERE sla_id=?");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, lSLAId);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	public void deleteSlaSumBySlaId(Connection con, long nSLAId) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from so_sla_sum ")
					.append("WHERE sla_id=?");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, nSLAId);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * delete SUM test's SLA 
	 *  
	 * @param con
	 * @param lSUMTestId
	 * @throws Exception
	 */
	public void deleteSUMSLA(Connection con, long lSUMTestId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT delete_sum_slas(?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lSUMTestId);
			pstmt.setLong(2, lUserId);
			pstmt.execute();
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 *  To delete the AVM test's sla policy.
	 * @param con
	 * @param lAVMTestId
	 * @param lUserId
	 * @throws Exception
	 */
	public void deleteAVMSLA(Connection con, long lAVMTestId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT delete_avm_slas(?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lAVMTestId);
			pstmt.setLong(2, lUserId);
			pstmt.execute();
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * delete particular RUM uid's SLA references 
	 * 
	 * @param con
	 * @param lUId
	 * @param lUserId
	 * @throws Exception
	 */
	public void deleteRUMSLA(Connection con, long lUId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT delete_rum_slas(?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUId);
			pstmt.setLong(2, lUserId);
			pstmt.execute();
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * Deleting map counters 
	 * @param con
	 * @param lSLAId
	 * @throws Exception
	 */
	public void removeMapCounters(Connection con, long lSLAId) throws Exception {
		
		PreparedStatement pstmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try{
			sbQuery .append("DELETE from so_sla_counter ")
					.append("WHERE sla_id=?");
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, lSLAId);
			pstmt.execute();
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
		}
	}
	
	/**
	 * Update Map Counter
	 * 
	 * @param con
	 * @param bean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateMapCounter(Connection con, MapCounterBean bean, LoginUserBean loginUserBean) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		try{
			sbQuery	.append("UPDATE so_sla_counter SET is_above_threshold=?, warning_threshold_value=?, critical_threshold_value=?, min_breach_count=? ")
					.append("WHERE sla_counter_id=?");
			
			pstmt = con.prepareStatement(sbQuery.toString(), PreparedStatement.RETURN_GENERATED_KEYS);
			
			
			pstmt.setBoolean(1, bean.isIsThresholdAbove());
			pstmt.setLong(2, bean.getWarningThresholdValue());
			pstmt.setLong(3, bean.getCriticalThresholdValue());
			pstmt.setInt(4, bean.getMinBreachCount());
			pstmt.setInt(5, bean.getMapCounterId());
			pstmt.executeUpdate();
			
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	public JSONArray getAllSLAAlert(Connection con, long lUserId, long lEID, String strModuleType, long lUID, long lCounterId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		JSONArray jaRtnData = null;
		JSONObject joAlertData = null;
		try{
			
			jaRtnData = new JSONArray();
			
			sbQuery	.append("SELECT ss.sla_id, ss.sla_name FROM so_sla ss INNER JOIN so_sla_counter ssc ON ss.sla_id = ssc.sla_id WHERE ss.user_id = ? ")
					.append(" AND ssc.module_name =  ? AND CASE WHEN ").append(lEID).append("=0 THEN ss.e_id IS NULL ELSE ss.e_id = ").append(lEID).append(" END ")
					.append(" AND ss.sla_id NOT IN (SELECT sla_id FROM so_sla_counter WHERE counter_id = ? AND uid = ?) ")
					.append(" GROUP BY ss.sla_id ORDER BY ss.sla_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			
			pstmt.setLong(1, lUserId);
			pstmt.setString(2, strModuleType);
			pstmt.setLong(3, lCounterId);
			pstmt.setLong(4, lUID);
			rst = pstmt.executeQuery();
			
			while (rst.next()) {
				joAlertData = new JSONObject();
				joAlertData.put("slaId", rst.getLong("sla_id"));
				joAlertData.put("slaName", rst.getString("sla_name"));
				jaRtnData.add(joAlertData);
			}
			
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
			DataBaseManager.close(pstmt);
			pstmt = null;
			UtilsFactory.clearCollectionHieracy( sbQuery );
			LogManager.logMethodEnd(dateLog);
		}
		return jaRtnData;
	}
	
	/**
	 * gets guid(s) mapped to the SLA
	 * 
	 * @param con
	 * @param lSLAId
	 * @return
	 * @throws Exception
	 */
	public String getSLAMappedActiveGUIDs(Connection con, long lSLAId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		String strQuery = "", strGUIDs = "";
		
		try {
			//strQuery = "SELECT group_concat(DISTINCT ''''||guid||'''') AS mapped_guids FROM so_sla_counter WHERE sla_id = ? ";
			strQuery = "SELECT group_concat(DISTINCT guid) AS mapped_guids FROM so_sla_counter WHERE sla_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lSLAId);
			rst = pstmt.executeQuery();
			if( rst.next() ) {
				strGUIDs = rst.getString("mapped_guids");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
		
		return strGUIDs;
	}
	
	/**
	 * update in counter_master_<uid> table, 
	 *  for the created counter's which added with SLA policy & map counter of Error Type
	 * 
	 * @param con
	 * @param lUId
	 * @param lSLAId
	 * @param lCounterId
	 * @throws Exception
	 */
	public void updateMappedSLAIdWithCounterForThresholdBreach(Connection con, long lUId, long lSLAId, long lCounterId) throws Exception {
		PreparedStatement pstmt = null;

		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE counter_master_").append(lUId).append(" SET ")
					.append("  threshold_sla_id = ").append(lSLAId).append(" ")
					.append("WHERE counter_id = ").append(lCounterId);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * update in counter_master_<uid> table, 
	 *  for the created counter's which added with SLA policy & map counter of Warning Type
	 *  
	 *   future USE, added for uid's counter's to map with Warning breach type
	 *  
	 * @param con
	 * @param lUId
	 * @param lSLAId
	 * @param lCounterId
	 * @throws Exception
	 */
	public void updateMappedSLAIdWithCounterForWarningType(Connection con, long lUId, long lSLAId, long lCounterId) throws Exception {
		PreparedStatement pstmt = null;

		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE counter_master_").append(lUId).append(" SET ")
					.append("  warning_sla_id = ").append(lSLAId).append(" ")
					.append("WHERE counter_id = ").append(lCounterId);
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	public JSONArray getAllModuleSLABreachStatus(Connection con, long lUserId) throws Throwable {
		Statement stmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		JSONArray jaAllModuleSLABreachStatus = new JSONArray(); 
		JSONObject joModuleSLABreachStatus = null;
		
		try {
			sbQuery	.append("SELECT * FROM get_sla_summary(").append(lUserId).append(")");
			
			stmt = con.createStatement();
			rst = stmt.executeQuery(sbQuery.toString());
			
			while( rst.next() ) {
				joModuleSLABreachStatus = new JSONObject();
				joModuleSLABreachStatus.put("module_code", rst.getString("module_code"));
				joModuleSLABreachStatus.put("good_cnt", rst.getInt("good_cnt"));
				joModuleSLABreachStatus.put("warning_cnt", rst.getInt("warning_cnt"));
				joModuleSLABreachStatus.put("critical_cnt", rst.getInt("critical_cnt"));
				joModuleSLABreachStatus.put("inactive_cnt", rst.getInt("inactive_cnt"));
				
				jaAllModuleSLABreachStatus.add(joModuleSLABreachStatus);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(stmt);
			stmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaAllModuleSLABreachStatus;
	}
	
	/**
	 * Create the ASD module's SLA breach partition tables for the given User_Id.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void createSLABreachPartitionTable(Connection con, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery .append("SELECT * FROM create_sla_breach_table_partition(").append(lUserId).append(")");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.execute();
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}
	
	/**
	 * Create the SUM module's SLA breach partition tables for the given User_Id.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void createSUMThresholdBreahTable(Connection con, long lUserId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery .append("SELECT * FROM create_sum_sla_breach_table_partition(").append(lUserId).append(")");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.execute();
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	/**
	 * Create the RUM module's SLA breach partition tables for the given User_Id.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void createRUMThresholdBreahTable(Connection con, long lUserId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		PreparedStatement pstmt = null;
		String strQuery = "";
		
		try {
			strQuery = "SELECT * FROM create_rum_sla_breach_table_partition(?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lUserId);
			pstmt.execute();
		} catch(Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
			
			LogManager.logMethodEnd(dateLog);
		}
	}
	
	/**
	 * gets particular module's/uid's SLA policy details,
	 * (ie.. SLAs which are added after ASD add)
	 * 
	 * @param con
	 * @param lUId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleAutogeneratedSLAs(Connection con, long lUId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		JSONArray jaModuleAutogeneratedSLAs = null;
		JSONObject joModuleAutogeneratedSLA = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			jaModuleAutogeneratedSLAs = new JSONArray();
			
			sbQuery	.append("SELECT cm.counter_id, cm.counter_template_id, cm.category, cm.counter_name, cm.display_name, cm.warning_threshold_value, cm.critical_threshold_value, ")
					.append("  ss.sla_id, ss.sla_name ")
					.append("FROM counter_master_").append(lUId).append(" cm ")
					.append("INNER JOIN so_sla ss ON cm.threshold_sla_id = ss.sla_id ")
					.append("  AND cm.threshold_sla_id IS NOT NULL ")
					.append("  AND ss.user_id = ? ")
					.append("ORDER BY cm.category, cm.counter_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setLong(1, lUserId);
			rst = pstmt.executeQuery();
			while( rst.next() ) {
				joModuleAutogeneratedSLA = new JSONObject();
				joModuleAutogeneratedSLA.put("counterId", rst.getString("counter_id"));
				joModuleAutogeneratedSLA.put("counterTemplateId", rst.getString("counter_template_id"));
				joModuleAutogeneratedSLA.put("category", rst.getString("category"));
				joModuleAutogeneratedSLA.put("counterName", rst.getString("counter_name"));
				joModuleAutogeneratedSLA.put("displayName", rst.getString("display_name"));
				joModuleAutogeneratedSLA.put("warningThresholdValue", rst.getString("warning_threshold_value"));
				joModuleAutogeneratedSLA.put("criticalThresholdValue", rst.getString("critical_threshold_value"));
				joModuleAutogeneratedSLA.put("slaId", rst.getString("sla_id"));
				joModuleAutogeneratedSLA.put("slaName", rst.getString("sla_name"));
				
				jaModuleAutogeneratedSLAs.add(joModuleAutogeneratedSLA);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return jaModuleAutogeneratedSLAs;
	}
	
	/**
	 * logical delete from so_sla for alerts configured by self (by user)
	 * 
	 * @param con
	 * @param lSLAId
	 * @param lUserId
	 * @throws Exception
	 */
	public void logicallyDeleteSLAs(Connection con, long lSLAId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;

		String strQuery = "";

		try {

			strQuery = "UPDATE so_sla SET is_active = false, is_deleted = true WHERE sla_id = ? AND user_id = ? ";

			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lSLAId);
			pstmt.setLong(2, lUserId);
			pstmt.execute();

		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;

			strQuery = null;
		}
	}

	/**
	 * deletes SLA's & mapped references,
	 *  deletes SLA's from the tables, 
	 *    ASD SLA's `sla_alert_log`, `so_threshold_breach_<user_id>`, `so_sla_counter`, `sla_log`, `so_sla_rule`,
	 *    SUM SLA's `so_sum_threshold_breach_<user_id>`, `so_sla_sum`, `so_sla` 
	 * 
	 * @param con
	 * @param lSLAId
	 * @param lUserId
	 * @throws Exception
	 */
	public void deleteSLAs(Connection con, long lSLAId, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "SELECT delete_slas(?, ?)";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setLong(1, lSLAId);
			pstmt.setLong(2, lUserId);
			pstmt.execute();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * enable or disable SLA policy
	 * 
	 * @param con
	 * @param lSLAId
	 * @param bActivePolicy
	 * @param lUserId
	 * @throws Exception
	 */
	public void enableOrDisableSLA(Connection con, long lSLAId, boolean bActivePolicy, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		
		String strQuery = "";
		
		try {
			strQuery = "UPDATE so_sla SET is_active = ? WHERE sla_id = ? AND user_id = ? ";
			
			pstmt = con.prepareStatement(strQuery);
			pstmt.setBoolean(1, bActivePolicy);
			pstmt.setLong(2, lSLAId);
			pstmt.setLong(3, lUserId);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			strQuery = null;
		}
	}
	
	/**
	 * gets SLA(s) which are mapped with GUID of delete from UI 
	 *  and gets SLA(s) which has the delete of and another GUID(s) mapped
	 *  
	 * @param con
	 * @param strGUID
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, ArrayList<HashMap<String, Object>>> getGUIDMappedSLAs(Connection con, String strGUID, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		HashMap<String, ArrayList<HashMap<String, Object>>> hmDeleteSLAs = new HashMap<String, ArrayList<HashMap<String, Object>>>(); 
		HashMap<String, Object> hmSLA = null;
		
		ArrayList<HashMap<String, Object>> alSLAs = null;
		
		// has SLAs mapped with multiple GUIDs
		boolean bHasDifferentGUIDsMapped = false;
		
		try {
			// init
			alSLAs = new ArrayList<HashMap<String, Object>>();
			hmDeleteSLAs.put("single_guid_mapped_with_slas", alSLAs);
			alSLAs = null;
			
			alSLAs = new ArrayList<HashMap<String, Object>>();
			hmDeleteSLAs.put("different_guid_mapped_with_slas", alSLAs);
			alSLAs = null;
			
			sbQuery	.append("SELECT ssc_slas.sla_id, count(DISTINCT ssc_slas.guid) AS total_unique_guids_mapped, ")
					//.append("  (CASE WHEN count(DISTINCT ssc_slas.guid) > 1 THEN TRUE ELSE FALSE END) AS has_different_guid_mapped, ")
					.append("  group_concat(DISTINCT ssc_slas.guid) AS mapped_guids, ")
					.append("  ss.sla_name ")
					.append("FROM ( ")
					.append("  SELECT sla_id, guid, count(sla_id) ")
					.append("  FROM so_sla_counter ")
					.append("  WHERE sla_id IN ( ")
					.append("    SELECT sla_id FROM so_sla_counter WHERE guid = ? ")
					.append("  ) ")
					.append("  GROUP BY sla_id, guid ")
					.append(") ssc_slas ")
					.append("INNER JOIN so_sla ss ON ss.sla_id = ssc_slas.sla_id AND ss.user_id = ? ")
					.append("GROUP BY ssc_slas.sla_id, ss.sla_name ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strGUID);
			pstmt.setLong(2, lUserId); 
			rst = pstmt.executeQuery();
			while ( rst.next() ) {
				hmSLA = new HashMap<String, Object>();
				hmSLA.put("sla_id", rst.getLong("sla_id"));
				hmSLA.put("sla_name", rst.getString("sla_name"));
				hmSLA.put("mapped_guids", rst.getString("mapped_guids"));
				
				bHasDifferentGUIDsMapped = rst.getInt("total_unique_guids_mapped") > 1 ? true : false;
				if ( bHasDifferentGUIDsMapped  ) {
					// SLA(s) mapped with multiple GUIDs; to delete only from `so_sla_counter`
					alSLAs = hmDeleteSLAs.get("different_guid_mapped_with_slas");
				} else {
					// SLA(s) has only the respective GUID mapped; delete the sla_id from all refs., say `so_sla`, `so_sla_counter`, `so_threshold_breach_<user_id>`, `sla_alert_log`, `sla_log`, `so_sla_rule` 
					alSLAs = hmDeleteSLAs.get("single_guid_mapped_with_slas");
				}
				alSLAs.add(hmSLA);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
		
		return hmDeleteSLAs;
	}
	
	/**
	 * disabe SLA(s) has another GUID mapped
	 * 
	 * @param con
	 * @param strGUID
	 * @param strSLAIds
	 * @param lUserId
	 * @throws Exception
	 */
	public void disableSLAHasDifferentGUIDMapped(Connection con, String strGUID, String strSLAIds, long lUserId) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("WITH del_ssc AS ( ")
					.append("  DELETE FROM so_sla_counter ") // TODO: DELETE FROM so_sla_counter
					.append("  WHERE guid = ? AND sla_id IN (").append(strSLAIds).append(") ")
					.append(") ")
					.append("UPDATE so_sla SET is_active = false ") // TODO: UPDATE so_sla SET is_active = false
					.append("WHERE user_id = ? AND sla_id IN (").append(strSLAIds).append(") ");
			
			pstmt = con.prepareStatement(sbQuery.toString());
			pstmt.setString(1, strGUID);
			pstmt.setLong(2, lUserId);
			//pstmt.executeUpdate();
			pstmt.execute();
			
		} catch (Exception e) {
			LogManager.errorLog(e, sbQuery);
			throw e;
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			
			UtilsFactory.clearCollectionHieracy(sbQuery);
			sbQuery = null;
		}
	}

	
}
