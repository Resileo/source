package com.appedo.module.compiler;
import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Locale;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.StandardLocation;
import javax.tools.ToolProvider;

import net.sf.json.JSONObject;

import org.openqa.selenium.firefox.FirefoxProfile;

import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.utils.UtilsFactory;

/**
 * to create, compile & invoke the methods  of java file at the run time 
 * @author Training
 *
 */
public class DynamicCompilation {

	/**
	 * to create & compile the java file
	 * @param strContent
	 * @throws Exception
	 */
	public JSONObject makeFile(String strSeleniumScriptPackages, String strContent, String strClassName) throws Exception {
    // create the source

		StringBuilder sbString = new StringBuilder();
		JSONObject joReturn = new JSONObject(), joErrors = null;
		
		try{
			LogManager.infoLog("path = "+Constants.SELENIUM_SCRIPT_CLASS_FILE_PATH);
		    File sourceFile   = new File(Constants.SELENIUM_SCRIPT_CLASS_FILE_PATH+strClassName+".java");    
		    FileWriter writer = new FileWriter(sourceFile);
		    LogManager.infoLog("Writer is ready");
		    writer.write(
		    		//Constants.SELENIUM_SCRIPT_PACKAGES +
		    		strSeleniumScriptPackages +
		            "public class "+strClassName+"{ \n"
		            + "private WebDriver driver;\nprivate static final String WEBDRIVER_SERVER_URL = \"http://127.0.0.1:4444/wd/hub\";\n" 
		            + "public WebDriver doit() {\n try {\n"
		            + "DesiredCapabilities caps = DesiredCapabilities.chrome();\n"
		            + "ChromeOptions chromeOptions = new ChromeOptions();\n"
		            + "LoggingPreferences logPrefs = new LoggingPreferences();\n"
		            + "logPrefs.enable(LogType.BROWSER, Level.ALL);\n"
		            + "logPrefs.enable(LogType.PERFORMANCE, Level.INFO);\n"
		            + "caps.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);\n"
		            + "driver = new Augmenter().augment(new RemoteWebDriver(new URL(WEBDRIVER_SERVER_URL), caps));\n"
		            + "\n " +strContent
		            +"}catch(Exception e){e.printStackTrace();}"
		            + " return driver;}\n" +
		            "}"
		    );
		    writer.close();
			LogManager.infoLog("SUM Class file created: "+strClassName);
			DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<JavaFileObject>();
		    JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		    StandardJavaFileManager fileManager = compiler.getStandardFileManager(null, null, null);
		    
		    fileManager.setLocation(StandardLocation.SOURCE_PATH,Arrays.asList(new File(Constants.SELENIUM_SCRIPT_CLASS_FILE_PATH)));
		    
		    // Compile the file
		    JavaCompiler.CompilationTask task = compiler.getTask(null,
		               fileManager,
		               diagnostics,
		               null,
		               null,
		               fileManager.getJavaFileObjectsFromFiles(Arrays.asList(sourceFile)));
		            
		    if (!task.call()) {
		    	sbString.append("Compile time error(s)<br/><br/>");
		    	for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics()) {
		    		sbString.append(diagnostic.getMessage(Locale.ENGLISH)+"<br/>");
                }
		    	joErrors = new JSONObject();
		    	joErrors.put("errorMessage", sbString.toString());
		    	joErrors.put("errorType", "Compilation error(s). Unable to proceed.");
		    	joErrors.put("focus_to", "txtTransaction");
		    	
		    	joReturn = UtilsFactory.getJSONFailureReturn(joErrors);
		    }else{
		    	joReturn = UtilsFactory.getJSONSuccessReturn("");
		    }
		    fileManager.close();
		    LogManager.infoLog("file compiled"+joReturn.toString());
		    sourceFile = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return joReturn;
  }

	/** 
	 * to invoke the method 
	 * @param profile
	 */
  @SuppressWarnings("unchecked")
  public static void runIt(FirefoxProfile profile) {
    try {
      Class params[] = {FirefoxProfile.class};
      Object paramsObj[] = {profile};
      Class thisClass = Class.forName("com.appedo.sum.Hello");
      Object iClass = thisClass.newInstance();
          
      Method thisMethod = thisClass.getDeclaredMethod("doit", params);      
      thisMethod.invoke(iClass, paramsObj);
      }
    catch (Exception e) {
    	LogManager.errorLog(e);
    }
  }
}
