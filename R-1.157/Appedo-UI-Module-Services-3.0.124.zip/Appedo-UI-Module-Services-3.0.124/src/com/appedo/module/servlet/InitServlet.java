package com.appedo.module.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appedo.commons.manager.AppedoMailer;
import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.dbi.ModuleDBI;
import com.appedo.module.dbi.SLADBI;

/**
 * Servlet to handle one operation for the whole application
 * 
 * @author navin
 * 
 */
public class InitServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public static String realPath = null;
	public static TimerTask timerTaskLoadTest = null, timerTaskProcessingQueue = null, timerTaskCount = null, timerTaskPaid = null;
	public static Timer timerLT = new Timer(), timerProcessing = new Timer(), timerCount = new Timer(), timerPaid = new Timer();
	public static TimerTask timerTaskELKInstaller = null;
	public static Timer timerELKInstaller = new Timer();
	
	public void init() {
		// super();
		
		// declare servlet context
		ServletContext context = getServletContext();
		
		realPath = context.getRealPath("//");
		
		Connection con = null;
		
		String strConstantsFilePath = null, strLog4jFilePath = null;
		
		try {
			strConstantsFilePath = context.getInitParameter("CONSTANTS_PROPERTIES_FILE_PATH");
			strLog4jFilePath = context.getInitParameter("LOG4J_PROPERTIES_FILE_PATH");
			
			Constants.CONSTANTS_FILE_PATH = InitServlet.realPath + strConstantsFilePath;
			Constants.LOG4J_PROPERTIES_FILE = InitServlet.realPath + strLog4jFilePath;
			
			// Loads log4j configuration properties
			LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
			// Loads Constant properties
			Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);
			
			// Loads Appedo config properties from the system path
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Loads mail config
			AppedoMailer.loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
			
			// Loads db config
			DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
			
			con = DataBaseManager.giveConnection();
			
			// loads agents(counter_types) download file paths 
			ModuleDBI.loadAgentsDownloadFilePath(con);
			
			// loads agent's latest build version
			ModuleDBI.loadAgentsLatestVersion(con);
			
			// loads default SLA breach types
			SLADBI.loadSLABreachTypes(con);
			
			// loads minichart counters for the respective agent's
			ModuleDBI.loadMiniChartCounters(con);
			
			// loads appedo constants; say loads appedoWhiteLabels, 
			Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
			
			//Log ui Services
			//Constants.loadELKID();
			
			//timerTaskELKInstaller = new ELKInstallationTimer();
			//timerELKInstaller.schedule(timerTaskELKInstaller, 150, Constants.ELK_TIMER_INTERVAL);
			
		} catch (Throwable th) {
			System.out.println("Exception in InitServlet.init: "+th.getMessage());
			th.printStackTrace();
			
			LogManager.errorLog(th);
		} finally {
			DataBaseManager.close(con);
			con = null;
			
			strConstantsFilePath = null;
			strLog4jFilePath = null;
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}

}
