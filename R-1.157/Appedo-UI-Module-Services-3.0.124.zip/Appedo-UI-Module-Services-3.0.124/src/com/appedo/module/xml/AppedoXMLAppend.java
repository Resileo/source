package com.appedo.module.xml;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.utils.UtilsFactory;

public class AppedoXMLAppend {

	public JSONArray getVariables(String strVariablesFilePath) throws Exception {
		
		JSONArray jaVariables = null;
		JSONObject joVariable = null;
		try {
			
			DocumentBuilderFactory mdbf = DocumentBuilderFactory.newInstance();
			mdbf.setValidating(false);
			DocumentBuilder mdb = mdbf.newDocumentBuilder();
			File f = new File(strVariablesFilePath);
			if(f.exists()){
				// Document mdoc = mdb.parse(new FileInputStream(new File(strVariablesFilePath)));
				String strXml = FileUtils.readFileToString(new File(strVariablesFilePath), "UTF-8");
			    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(strXml.getBytes("UTF-8"));
			    Document mdoc = mdb.parse(byteArrayInputStream);
				NodeList mentries = mdoc.getElementsByTagName("variable");
				int mnum = mentries.getLength();
				jaVariables =  new JSONArray();
				
				for (int i=0; i<mnum; i++) 
				{
					Element mnode = (Element) mentries.item(i);	
					if(mnode.getAttributes().getNamedItem("type").getNodeValue().equalsIgnoreCase("file")){
						joVariable = new JSONObject();
						joVariable.put("variable_name",mnode.getAttributes().getNamedItem("name").getNodeValue());
						joVariable.put("type",mnode.getAttributes().getNamedItem("type").getNodeValue());
						joVariable.put("policy",mnode.getAttributes().getNamedItem("policy").getNodeValue());
						joVariable.put("created_on",mnode.getAttributes().getNamedItem("modified").getNodeValue());
						joVariable.put("starts_from",mnode.getAttributes().getNamedItem("start").getNodeValue());
						String strContent = getVariableContent(joVariable.getString("variable_name"), strVariablesFilePath);
						joVariable.put("content", strContent.replaceAll("\n", "<br/>"));
						jaVariables.add(joVariable);
					}
					
				}
			}else{
				jaVariables = new JSONArray();
			}
			
		}catch(ParserConfigurationException e) {
			LogManager.errorLog(e);
			throw e;
		}catch(SAXException se) {
			LogManager.errorLog(se);
		}catch(IOException ioe) {
			LogManager.errorLog(ioe);
		}catch(Exception ioe) {
			LogManager.errorLog(ioe);
		}
		return jaVariables;
	}

	public JSONArray getLTVariables(String strVariablesFilePath, LoginUserBean loginUserBean) throws Exception {
		
		JSONArray jaVariables = null;
		JSONObject joVariable = null;
		try {
			
			DocumentBuilderFactory mdbf = DocumentBuilderFactory.newInstance();
			mdbf.setValidating(false);
			DocumentBuilder mdb = mdbf.newDocumentBuilder();
			File f = new File(strVariablesFilePath);
			if(f.exists()){
				// Document mdoc = mdb.parse(new FileInputStream(new File(strVariablesFilePath)));
				String strXml = FileUtils.readFileToString(new File(strVariablesFilePath), "UTF-8");
			    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(strXml.getBytes("UTF-8"));
			    Document mdoc = mdb.parse(byteArrayInputStream);
				NodeList mentries = mdoc.getElementsByTagName("variable");
				int mnum = mentries.getLength();
				jaVariables =  new JSONArray();
				JSONObject joVariable1 = null;
				JSONObject joCol_Value = null;
				
				for (int i=0; i<mnum; i++) 
				{
					Element mnode = (Element) mentries.item(i);	
					if(mnode.getAttributes().getNamedItem("type").getNodeValue().equalsIgnoreCase("file")){
						joVariable = new JSONObject();
						
						joVariable1 = new JSONObject();
						joCol_Value = new JSONObject();
						
						joVariable.put("variable_name",mnode.getAttributes().getNamedItem("name").getNodeValue());
						joVariable.put("type",mnode.getAttributes().getNamedItem("type").getNodeValue());
						joVariable.put("policy",mnode.getAttributes().getNamedItem("policy").getNodeValue());
						joVariable.put("created_on",mnode.getAttributes().getNamedItem("modified").getNodeValue());
						joVariable.put("starts_from",mnode.getAttributes().getNamedItem("start").getNodeValue());
						String strContent = getVariableContent(joVariable.getString("variable_name"), strVariablesFilePath);
						joVariable.put("content", strContent.replaceAll("\n", "<br/>"));
						//jaVariables.add(joVariable);
						
						//new UI Design
						joVariable1.put("var1", "is_delete");
						joVariable1.put("var2", "is_edit");
						joVariable1.put("var3", "");
						joVariable1.put("var4", "AppedoLT Variables");
						joCol_Value.put("col_1", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);
						
						joVariable1.put("var1", joVariable.getString("variable_name"));
						joVariable1.put("var2", "Added by "+loginUserBean.getFirstName()+" on ");
						joVariable1.put("var21", joVariable.getLong("created_on"));
						joCol_Value.put("col_2", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);

						joVariable1.put("var1",  joVariable.getString("policy"));
						joVariable1.put("var2",  joVariable.getString("starts_from"));
						joCol_Value.put("col_3", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);
						
						joVariable1.put("var1", "");
						joVariable1.put("var2", "");
						joCol_Value.put("col_4", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);
						
						joVariable1.put("var1", "");
						joVariable1.put("var2", "");
						joCol_Value.put("col_5", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);
						
						joVariable1.put("var1", "STATUS_LT");
						joVariable1.put("var2", "");
						joCol_Value.put("col_6", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);
						
						joVariable1.put("var1", "Mon_down");
						joCol_Value.put("col_7", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);
						
						joVariable1.put("var1", "Pro_up");
						joCol_Value.put("col_8", joVariable1);
						UtilsFactory.clearCollectionHieracy(joVariable1);
						
						joCol_Value.put("content", joVariable.getString("content"));
						
						jaVariables.add(joCol_Value);
					}
					
				}
			}else{
				jaVariables = new JSONArray();
			}
			
		}catch(ParserConfigurationException e) {
			LogManager.errorLog(e);
			throw e;
		}catch(SAXException se) {
			LogManager.errorLog(se);
		}catch(IOException ioe) {
			LogManager.errorLog(ioe);
		}catch(Exception ioe) {
			LogManager.errorLog(ioe);
		}
		return jaVariables;
	}

	
	public String getVariableContent(String strVariableName, String strVariablesFilePath) throws Exception {
		String strVariableContent = "";
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setValidating(false);
		DocumentBuilder db = dbf.newDocumentBuilder();
		// Document doc = db.parse(new FileInputStream(new File(strVariablesFilePath)));
		
		String strXml = FileUtils.readFileToString(new File(strVariablesFilePath), "UTF-8");
	    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(strXml.getBytes("UTF-8"));
	    Document doc = db.parse(byteArrayInputStream);
	    
		String expression = null;
		XPath varxPath =  XPathFactory.newInstance().newXPath();
		expression = "/variables/variable[@name='"+strVariableName+"']";
		
		NodeList recfiletypeList1 = (NodeList) varxPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
		Node nNode = recfiletypeList1.item(0);
		
		Element eElement = (Element) nNode;
		strVariableContent = eElement.getElementsByTagName("content").item(0).getTextContent();
		
		return strVariableContent;
	}
	
	/**
	 * sets default script settings
	 * 
	 * @param eleScriptSetting
	 */
	public static void setDefaultScriptSettings(Element eleScriptSetting) {
		eleScriptSetting.setAttribute("type", "1");
		eleScriptSetting.setAttribute("durationtime", "0;0;0");
		eleScriptSetting.setAttribute("incrementtime", "0;0;0");
		eleScriptSetting.setAttribute("iterations", "1");
		eleScriptSetting.setAttribute("maxuser", "1");
		eleScriptSetting.setAttribute("startuser", "1");
		eleScriptSetting.setAttribute("incrementuser", "1");
		eleScriptSetting.setAttribute("browsercache", "false");
		eleScriptSetting.setAttribute("startuserid", "0");
		eleScriptSetting.setAttribute("currentloadgenid", "1");
		eleScriptSetting.setAttribute("totalloadgen", "1");
		eleScriptSetting.setAttribute("durationmode", "1");
		eleScriptSetting.setAttribute("parallelconnections", Constants.DEFAULT_PARALLEL_CONNECTIONS);
	}
}
