package com.appedo.module.bean;

import net.sf.json.JSONObject;

public class CILicenseBean {

	private long lUserId;

	private String strModuleType;
	private String strStartDate;
	private String strEndDate;
	
	/* max agents is validated like user added total no. modules added in Application/Server/Database */
	private int nMaxRUMTests;
	
	/* below from `ci_config_parameters` */
	private String strLicInternalName;
	private String strLicExternalName;
	
	private boolean bEnableFilters;
	private boolean bEnableProfiles;
	private boolean bEnableNotificationEmail;
	private boolean bEnableNotificationSMS;
	
	private int nMaxEvents;
	private int nMaxProperties;
	
	private int nReportRetentionInDays;
	
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}

	public String getModuleType() {
		return strModuleType;
	}
	public void setModuleType(String strModuleType) {
		this.strModuleType = strModuleType;
	}

	public String getStartDate() {
		return strStartDate;
	}
	public void setStartDate(String strStartDate) {
		this.strStartDate = strStartDate;
	}

	public String getEndDate() {
		return strEndDate;
	}
	public void setEndDate(String strEndDate) {
		this.strEndDate = strEndDate;
	}

	public int getMaxRUMTests() {
		return nMaxRUMTests;
	}
	public void setMaxRUMTests(int nMaxRUMTests) {
		this.nMaxRUMTests = nMaxRUMTests;
	}

	public String getLicInternalName() {
		return strLicInternalName;
	}
	public void setLicInternalName(String strLicInternalName) {
		this.strLicInternalName = strLicInternalName;
	}

	public String getLicExternalName() {
		return strLicExternalName;
	}
	public void setLicExternalName(String strLicExternalName) {
		this.strLicExternalName = strLicExternalName;
	}

	public boolean isEnableFilters() {
		return bEnableFilters;
	}
	public void setEnableFilters(boolean bEnableFilters) {
		this.bEnableFilters = bEnableFilters;
	}

	public boolean isEnableProfiles() {
		return bEnableProfiles;
	}
	public void setEnableProfiles(boolean bEnableProfiles) {
		this.bEnableProfiles = bEnableProfiles;
	}

	public boolean isEnableNotificationEmail() {
		return bEnableNotificationEmail;
	}
	public void setEnableNotificationEmail(boolean bEnableNotificationEmail) {
		this.bEnableNotificationEmail = bEnableNotificationEmail;
	}

	public boolean isEnableNotificationSMS() {
		return bEnableNotificationSMS;
	}
	public void setEnableNotificationSMS(boolean bEnableNotificationSMS) {
		this.bEnableNotificationSMS = bEnableNotificationSMS;
	}

	public int getMaxEvents() {
		return nMaxEvents;
	}
	public void setMaxEvents(int nMaxEvents) {
		this.nMaxEvents = nMaxEvents;
	}

	public int getMaxProperties() {
		return nMaxProperties;
	}
	public void setMaxProperties(int nMaxProperties) {
		this.nMaxProperties = nMaxProperties;
	}

	public int getReportRetentionInDays() {
		return nReportRetentionInDays;
	}
	public void setReportRetentionInDays(int nReportRetentionInDays) {
		this.nReportRetentionInDays = nReportRetentionInDays;
	}


	public JSONObject toJSON() {
		JSONObject joCILicense = new JSONObject();

		/* below form table `userwise_lic_monthwise` */
		joCILicense.put("userId", this.lUserId);
		joCILicense.put("moduleType", this.strModuleType);
		joCILicense.put("startDate", this.strStartDate);
		joCILicense.put("endDate", this.strEndDate);
		joCILicense.put("maxRUMTests", this.nMaxRUMTests);
		
		/* below from `ci_config_parameters` */
		joCILicense.put("licInternalName", this.strLicInternalName);
		joCILicense.put("licExternalName", this.strLicExternalName);

		joCILicense.put("maxEvents", this.nMaxEvents);
		joCILicense.put("maxProperties", this.nMaxProperties);
		
		joCILicense.put("enableFilters", this.bEnableFilters);
		joCILicense.put("enableProfiles", this.bEnableProfiles);
		joCILicense.put("enableNotificationEmail", this.bEnableNotificationEmail);
		joCILicense.put("enableNotificationSMS", this.bEnableNotificationSMS);
		joCILicense.put("reportRetentionInDays", this.nReportRetentionInDays);
		
		return joCILicense;
	}
	
}
