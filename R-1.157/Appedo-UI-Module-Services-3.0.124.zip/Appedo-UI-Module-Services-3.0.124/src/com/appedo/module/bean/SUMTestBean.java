package com.appedo.module.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

import net.sf.json.JSONObject;

import com.appedo.module.utils.UtilsFactory;

/**
 * Bean replica for the database table `sum_test_master`
 * This keeps the parameters like Test id, name, URL/Transaction to be tested and etc...
 * 
 * @author Navin
 *
 */
public class SUMTestBean implements Comparable<SUMTestBean> {
	
	private long nTestId;
	private long lUserId;
	private String strTestName;
	private String startDate;
	private String endDate;
	private int nRunEveryMinute;
	private boolean bStatus;
	private String strTestType;
	private String strURL;
	private String strTransaction;
	private String strTestClassName;
	private String strSeleniumScriptPackages;
	
	// WPT parameters
	private int connectionId;
	private int downloadLimit;
	private int uploadLimit;
	private int latencyLimit;
	private int packetLoss;
	private boolean repeatView;
	private String dobIds;
	
	// Availability Monitor
	private boolean bAvailabilityMonitor = false;
	private int nMonitorAvailabilityEveryMinutes = 0;
	
	// SLA parameters
	private long lSLAId;
	private long lRmSLAId;
	private boolean smsAlert;
	private boolean emailAlert;
	private boolean responseAlert;
	private boolean changedStDate;
	private int warningLimit;
	private int errorLimit;
	private int rmMinBreachCount;
	private boolean downTimeAlert;
	
	private String strIPAddresses;
	
	private Date dateQueuedOn = null;
	
	private HashSet<String> hsTargetLocations = null;
	
	public SUMTestBean() {
		hsTargetLocations = new HashSet<String>();
	}
	
	public long getTestId() {
		return nTestId;
	}
	public void setTestId(long testId) {
		nTestId = testId;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long userId) {
		lUserId = userId;
	}
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public String getIPAddresses() {
		return strIPAddresses;
	}
	public void setIPAddresses(String strIPAddresses) {
		this.strIPAddresses = strIPAddresses;
	}
	
	public int getRunEveryMinute() {
		return nRunEveryMinute;
	}
	public void setRunEveryMinute(int nRunEveryMin) {
		this.nRunEveryMinute = nRunEveryMin;
	}
	
	public String getTestName() {
		return strTestName;
	}
	public void setTestName(String strTestName) {
		this.strTestName = strTestName;
	}
	
	public String getURL() {
		return strURL;
	}
	public void setURL(String strURL) {
		this.strURL = strURL;
	}
	
	public boolean isStatus() {
		return bStatus;
	}
	public void setStatus(boolean status) {
		bStatus = status;
	}
	
	public String getTransaction() {
		return strTransaction;
	}
	public void setTransaction(String strTransaction) {
		this.strTransaction = strTransaction;
	}
	
	public String getTestType() {
		return strTestType;
	}
	public void setTestType(String strTestType) {
		this.strTestType = strTestType;
	}
	
	public String getTestClassName() {
		return strTestClassName;
	}
	
	public void setTestClassName(String strTestClassName) {
		this.strTestClassName = strTestClassName;
	}
	
	public HashSet<String> getTargetLocations() {
		return hsTargetLocations;
	}
	public ArrayList<String> getTargetLocationsArrayList() {
		ArrayList<String> alTargetLocations = new ArrayList<String>();
		
		Iterator<String> iter = hsTargetLocations.iterator();
		while(iter.hasNext()) {
			alTargetLocations.add(iter.next());
		}
		return alTargetLocations;
	}
	public void setTargetLocations(HashSet<String> hsLocations) {
		UtilsFactory.clearCollectionHieracy(this.hsTargetLocations);
		this.hsTargetLocations = hsLocations;
	}
	public void addTargetLocation(String strTargetLocation) {
		this.hsTargetLocations.add(strTargetLocation);
	}
	
	public Date getQueuedOn() {
		return dateQueuedOn;
	}
	public void setQueuedOn(Date dateQueuedOn) {
		this.dateQueuedOn = dateQueuedOn;
	}

	public String getSeleniumScriptPackages() {
		return strSeleniumScriptPackages;
	}
	public void setSeleniumScriptPackages(String strSeleniumScriptPackages) {
		this.strSeleniumScriptPackages = strSeleniumScriptPackages;
	}

	public int getConnectionId() {
		return connectionId;
	}
	public void setConnectionId(int connectionId) {
		this.connectionId = connectionId;
	}

	public int getDownloadLimit() {
		return downloadLimit;
	}
	public void setDownloadLimit(int downloadLimit) {
		this.downloadLimit = downloadLimit;
	}
	public int getUploadLimit() {
		return uploadLimit;
	}

	public void setUploadLimit(int uploadLimit) {
		this.uploadLimit = uploadLimit;
	}

	public int getLatencyLimit() {
		return latencyLimit;
	}
	public void setLatencyLimit(int latencyLimit) {
		this.latencyLimit = latencyLimit;
	}

	public int getPacketLoss() {
		return packetLoss;
	}
	public void setPacketLoss(int packetLoss) {
		this.packetLoss = packetLoss;
	}
	
	public boolean isSmsAlert() {
		return smsAlert;
	}
	public void setSmsAlert(boolean smsAlert) {
		this.smsAlert = smsAlert;
	}

	public boolean isEmailAlert() {
		return emailAlert;
	}
	public void setEmailAlert(boolean emailAlert) {
		this.emailAlert = emailAlert;
	}

	public int getWarningLimit() {
		return warningLimit;
	}
	public void setWarningLimit(int warningLimit) {
		this.warningLimit = warningLimit;
	}

	public int getErrorLimit() {
		return errorLimit;
	}
	public void setErrorLimit(int errorLimit) {
		this.errorLimit = errorLimit;
	}

	public int getRmMinBreachCount() {
		return rmMinBreachCount;
	}
	public void setRmMinBreachCount(int rmMinBreachCount) {
		this.rmMinBreachCount = rmMinBreachCount;
	}

	public String getDobIds() {
		return dobIds;
	}
	public void setDobIds(String dobIds) {
		this.dobIds = dobIds;
	}
	
	public JSONObject toJSON() {
		JSONObject joBean = new JSONObject();
		
		joBean.put("test_id", nTestId);
		joBean.put("user_id", lUserId);
		joBean.put("test_name", strTestName);
		joBean.put("test_type", strTestType);
		joBean.put("url", strURL);
		joBean.put("transaction", strTransaction);
		joBean.put("run_every_minute", nRunEveryMinute);
		joBean.put("status", bStatus);
		joBean.put("ip_address", strIPAddresses);
		joBean.put("start_date", startDate);
		joBean.put("end_date", endDate);
		joBean.put("dateQueuedOn", dateQueuedOn);
		
		joBean.put("connection_id", connectionId);
		joBean.put("download_limit", downloadLimit);
		joBean.put("upload_limit", uploadLimit);
		joBean.put("latency_limit", latencyLimit);
		joBean.put("packet_loss", packetLoss);
		joBean.put("sms_alert", smsAlert);
		joBean.put("email_alert", emailAlert);
		joBean.put("warning_limit", warningLimit);
		joBean.put("error_limit", errorLimit);
		joBean.put("rm_min_breach_count", rmMinBreachCount);
		joBean.put("dob_ids", dobIds);
		
		// Availability Monitor
		joBean.put("availability_status", bAvailabilityMonitor);
		joBean.put("availability_run_every_minute", nMonitorAvailabilityEveryMinutes);

		return joBean;
	}
	
	@Override
	public String toString() {
		return Long.toString(nTestId);
	}
	
	@Override
	public int compareTo(SUMTestBean another) {
		// compareTo should return < 0 if this is supposed to be
        // less than other, > 0 if this is supposed to be greater than 
        // other and 0 if they are supposed to be equal
    	
    	return ((int) (dateQueuedOn.getTime() - another.getQueuedOn().getTime()));
	}

	public boolean isResponseAlert() {
		return responseAlert;
	}
	public void setResponseAlert(boolean responseAlert) {
		this.responseAlert = responseAlert;
	}

	public boolean isRepeatView() {
		return repeatView;
	}
	public void setRepeatView(boolean repeatView) {
		this.repeatView = repeatView;
	}

	public boolean isChangedStDate() {
		return changedStDate;
	}
	public void setChangedStDate(boolean changedStDate) {
		this.changedStDate = changedStDate;
	}

	public long getSLAId() {
		return lSLAId;
	}
	public void setSLAId(long lSLAId) {
		this.lSLAId = lSLAId;
	}

	public long getRmSLAId() {
		return lRmSLAId;
	}
	public void setRmSLAId(long lRmSLAId) {
		this.lRmSLAId = lRmSLAId;
	}

	public boolean isDownTimeAlert() {
		return downTimeAlert;
	}
	public void setDownTimeAlert(boolean downTimeAlert) {
		this.downTimeAlert = downTimeAlert;
	}
	
	public boolean isAvailabilityMonitorEnabled() {
		return bAvailabilityMonitor;
	}
	public void enableAvailabilityMonitor(boolean bMonitorAvailability) {
		this.bAvailabilityMonitor = bMonitorAvailability;
	}
	
	public int getAvailabilityMonitorFrequency() {
		return nMonitorAvailabilityEveryMinutes;
	}
	public void setAvailabilityMonitorFrequency(int nMonitorAvailabilityEveryMinutes) {
		this.nMonitorAvailabilityEveryMinutes = nMonitorAvailabilityEveryMinutes;
	}
}
