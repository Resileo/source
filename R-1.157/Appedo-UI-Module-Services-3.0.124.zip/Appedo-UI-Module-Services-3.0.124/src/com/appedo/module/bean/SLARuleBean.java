package com.appedo.module.bean;


public class SLARuleBean {
	
	private String strRuleName;
	private String strRuleDescription;
	//private boolean bPublic;
	private Long lactionId;
	private boolean isPublic;
	private Long lruleId;
	private Long lruleActionId;
	private String isFrom;
	
	/**
	 * @return the strRuleName
	 */
	public String getRuleName() {
		return strRuleName;
	}
	/**
	 * @param strRuleName the strRuleName to set
	 */
	public void setRuleName(String strRuleName) {
		this.strRuleName = strRuleName;
	}
	/**
	 * @return the strRuleDescription
	 */
	public String getRuleDescription() {
		return strRuleDescription;
	}
	/**
	 * @param strRuleDescription the strRuleDescription to set
	 */
	public void setRuleDescription(String strRuleDescription) {
		this.strRuleDescription = strRuleDescription;
	}
	/**
	 * @return the bPublic
	 */
	/*public boolean isPublic() {
		return bPublic;
	}*/
	/**
	 * @param bPublic the bPublic to set
	 */
	/*public void setPublic(boolean bPublic) {
		this.bPublic = bPublic;
	}*/
	/**
	 * @return the actionId
	 */
	public Long getActionId() {
		return lactionId;
	}
	/**
	 * @param actionId the lactionId to set
	 */
	public void setActionId(Long lactionId) {
		this.lactionId = lactionId;
	}
	/**
	 * @return the isPublic
	 */
	public boolean isPublic() {
		return isPublic;
	}
	/**
	 * @param isPublic the isPublic to set
	 */
	public void setPublic(boolean isPublic) {
		this.isPublic = isPublic;
	}
	/**
	 * @return the lruleId
	 */
	public Long getRuleId() {
		return lruleId;
	}
	/**
	 * @param lruleId the lruleId to set
	 */
	public void setRuleId(Long lruleId) {
		this.lruleId = lruleId;
	}
	/**
	 * @return the lruleActionId
	 */
	public Long getRuleActionId() {
		return lruleActionId;
	}
	/**
	 * @param lruleActionId the lruleActionId to set
	 */
	public void setRuleActionId(Long lruleActionId) {
		this.lruleActionId = lruleActionId;
	}
	/**
	 * @return the isFrom
	 */
	public String getIsFrom() {
		return isFrom;
	}
	/**
	 * @param isFrom the isFrom to set
	 */
	public void setIsFrom(String isFrom) {
		this.isFrom = isFrom;
	}
	/**
	 * @return the actionIds
	 */
	/*public List<Long> getActionIds() {
		return ActionIds;
	}*/
	
}
