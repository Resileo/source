package com.appedo.module.bean;

public class SLASUMBean {
	
	private long slaSumId;
	private long slaId;
	private long sumTestId;
	private boolean aboveThreashold;
	private boolean bEnableAlert;
	private String sumCounterName;
	private String sumType;
	private int warningLimit;
	private int errorLimit;
	private int minBreachCount;
	private int breachTypeId;
	
	
	public long getSlaSumId() {
		return slaSumId;
	}
	public void setSlaSumId(long slaSumId) {
		this.slaSumId = slaSumId;
	}
	
	public long getSlaId() {
		return slaId;
	}
	public void setSlaId(long slaId) {
		this.slaId = slaId;
	}
	
	public long getSumTestId() {
		return sumTestId;
	}
	public void setSumTestId(long sumTestId) {
		this.sumTestId = sumTestId;
	}
	
	public boolean isAboveThreashold() {
		return aboveThreashold;
	}
	public void setAboveThreashold(boolean aboveThreashold) {
		this.aboveThreashold = aboveThreashold;
	}
	
	public String getSumCounterName() {
		return sumCounterName;
	}
	public void setSumCounterName(String sumCounterName) {
		this.sumCounterName = sumCounterName;
	}
	
	public String getSumType() {
		return sumType;
	}
	public void setSumType(String sumType) {
		this.sumType = sumType;
	}
	
	public int getWarningLimit() {
		return warningLimit;
	}
	public void setWarningLimit(int warningLimit) {
		this.warningLimit = warningLimit;
	}
	
	public int getErrorLimit() {
		return errorLimit;
	}
	public void setErrorLimit(int errorLimit) {
		this.errorLimit = errorLimit;
	}
	
	public int getMinBreachCount() {
		return minBreachCount;
	}
	public void setMinBreachCount(int minBreachCount) {
		this.minBreachCount = minBreachCount;
	}
	
	public int getBreachTypeId() {
		return breachTypeId;
	}
	public void setBreachTypeId(int breachTypeId) {
		this.breachTypeId = breachTypeId;
	}

	public boolean isEnableAlert() {
		return bEnableAlert;
	}
	public void setEnableAlert(boolean bEnableResponseAlert) {
		this.bEnableAlert = bEnableResponseAlert;
	}
}
