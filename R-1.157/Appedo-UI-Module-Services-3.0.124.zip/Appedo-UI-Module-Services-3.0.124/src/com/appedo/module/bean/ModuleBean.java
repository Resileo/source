package com.appedo.module.bean;

/**
 * Module bean is replica for the module master table
 * @author Rama
 *
 */
public class ModuleBean {

	private long nModuleId;
	private boolean bActiveFlag;
	private long lUserId;
	private int nAgentVersionId;
	private String strModuleName;
	private String strDescription;
	private String strGuid;
	private String strModuleType;
	private String strCLRVersion;
	private String strOldModuleName;
	private String strEncryptedUserId;
	private String client_unique_id;
	
	public String getModuleType() {
		return strModuleType;
	}
	public void setModuleType(String strModuleType) {
		this.strModuleType = strModuleType;
	}
	
	public long getModuleId() {
		return nModuleId;
	}
	public void setModuleId(long nModuleId) {
		this.nModuleId = nModuleId;
	}
	
	public boolean isbActiveFlag() {
		return bActiveFlag;
	}
	public void setActiveFlag(boolean bActiveFlag) {
		this.bActiveFlag = bActiveFlag;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public int getAgentVersionId() {
		return nAgentVersionId;
	}
	public void setAgentVersionId(int nAgentVersionId) {
		this.nAgentVersionId = nAgentVersionId;
	}
	
	public String getModuleName() {
		return strModuleName;
	}
	public void setModuleName(String strModuleName) {
		this.strModuleName = strModuleName;
	}
	
	public String getDescription() {
		return strDescription;
	}
	public void setDescription(String strDescription) {
		this.strDescription = strDescription;
	}
	
	public String getGuid() {
		return strGuid;
	}
	public void setGuid(String strGuid) {
		this.strGuid = strGuid;
	}
	
	public String getCLRVersion() {
		return strCLRVersion;
	}
	public void setCLRVersion(String strCLRVersion) {
		this.strCLRVersion = strCLRVersion;
	}
	public String getOldModuleName() {
		return strOldModuleName;
	}
	public void setOldModuleName(String strOldModuleName) {
		this.strOldModuleName = strOldModuleName;
	}
	public String getEncryptedUserId() {
		return strEncryptedUserId;
	}
	public void setEncryptedUserId(String strEncryptedUserId) {
		this.strEncryptedUserId = strEncryptedUserId;
	}
	public String getClient_unique_id() {
		return client_unique_id;
	}
	public void setClient_unique_id(String client_unique_id) {
		this.client_unique_id = client_unique_id;
	}
}
