package com.appedo.module.bean;

public class SUMUserBean {

	private int nSUMUserId;
	private int nEncryptedId;
	private String strEmail;
	private String strName;
	private String strRegisteredLocation;
	private int nAccountId;
	private String strAccountType;
	private String strBankName;
	private String strIFSCCode;
	private String strAccountNumber;
	private String strBankAccountType;
	
	public int getSUMUserId() {
		return nSUMUserId;
	}
	public void setSUMUserId(int nSUMUserId) {
		this.nSUMUserId = nSUMUserId;
	}
	public int getEncryptedId() {
		return nEncryptedId;
	}
	public void setnEncryptedId(int nEncryptedId) {
		this.nEncryptedId = nEncryptedId;
	}
	public String getEmail() {
		return strEmail;
	}
	public void setStrEmail(String strEmail) {
		this.strEmail = strEmail;
	}
	public String getName() {
		return strName;
	}
	public void setStrName(String strName) {
		this.strName = strName;
	}
	public String getRegisteredLocation() {
		return strRegisteredLocation;
	}
	public void setStrRegisteredLocation(String strRegisteredLocation) {
		this.strRegisteredLocation = strRegisteredLocation;
	}
	public int getAccountId() {
		return nAccountId;
	}
	public void setnAccountId(int nAccountId) {
		this.nAccountId = nAccountId;
	}
	public String getAccountType() {
		return strAccountType;
	}
	public void setStrAccountType(String strAccountType) {
		this.strAccountType = strAccountType;
	}
	public String getBankName() {
		return strBankName;
	}
	public void setStrBankName(String strBankName) {
		this.strBankName = strBankName;
	}
	public String getIFSCCode() {
		return strIFSCCode;
	}
	public void setStrIFSCCode(String strIFSCCode) {
		this.strIFSCCode = strIFSCCode;
	}
	public String getAccountNumber() {
		return strAccountNumber;
	}
	public void setStrAccountNumber(String strAccountNumber) {
		this.strAccountNumber = strAccountNumber;
	}
	public String getBankAccountType() {
		return strBankAccountType;
	}
	public void setStrBankAccountType(String strBankAccountType) {
		this.strBankAccountType = strBankAccountType;
	}
	
}
