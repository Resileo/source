package com.appedo.module.bean;

public class SLAActionBean {

	private long lActionId;
	private long lUserId;
	private long lEnterpriseId;
	private long lUID;
	private long lCounterTemplateId;
	private Long lReferenceActionId;
	
	private String strActionName;
	private String strActionDescription;
	private String strOwner;
	private String strExecutionType;
	private String strScript;
	private String strParameterFormat;
	private String strParameterValues;
	private String strParameterHelp;
	private String strConnectionString;
	private String strConnectionDNS;
	
	private int nCounterId;
	private int nCounterTypeVersionId;
	private int nOSCounterTypeVersionId;
	
	private boolean bPublic;
	private boolean bDelete;
	
	
	public long getActionId() {
		return lActionId;
	}
	public void setActionId(long lActionId) {
		this.lActionId = lActionId;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public long getEnterpriseId() {
		return lEnterpriseId;
	}
	public void setEnterpriseId(long lEnterpriseId) {
		this.lEnterpriseId = lEnterpriseId;
	}
	
	public String getActionName() {
		return strActionName;
	}
	public void setActionName(String strActionName) {
		this.strActionName = strActionName;
	}
	
	public String getActionDescription() {
		return strActionDescription;
	}
	public void setActionDescription(String strActionDescription) {
		this.strActionDescription = strActionDescription;
	}
	
	public int getCounterTypeVersionId() {
		return nCounterTypeVersionId;
	}
	public void setCounterTypeVersionId(int nCounterTypeVersionId) {
		this.nCounterTypeVersionId = nCounterTypeVersionId;
	}
	
	public long getUID() {
		return lUID;
	}
	public void setUID(long lUID) {
		this.lUID = lUID;
	}
	
	public long getCounterTemplateId() {
		return lCounterTemplateId;
	}
	public void setCounterTemplateId(long lCounterTemplateId) {
		this.lCounterTemplateId = lCounterTemplateId;
	}
	
	public int getOSCounterTypeVersionId() {
		return nOSCounterTypeVersionId;
	}
	public void setOSCounterTypeVersionId(int nOSCounterTypeVersionId) {
		this.nOSCounterTypeVersionId = nOSCounterTypeVersionId;
	}
	
	public boolean isPublic() {
		return bPublic;
	}
	public void setPublic(boolean bPublic) {
		this.bPublic = bPublic;
	}
	
	public String getOwner() {
		return strOwner;
	}
	public void setOwner(String strOwner) {
		this.strOwner = strOwner;
	}
	
	public String getExecutionType() {
		return strExecutionType;
	}
	public void setExecutionType(String strExecutionType) {
		this.strExecutionType = strExecutionType;
	}
	
	public String getScript() {
		return strScript;
	}
	public void setScript(String strScript) {
		this.strScript = strScript;
	}
	
	public String getParameterFormat() {
		return strParameterFormat;
	}
	public void setParameterFormat(String strParameterFormat) {
		this.strParameterFormat = strParameterFormat;
	}
	
	public String getParameterValues() {
		return strParameterValues;
	}
	public void setParameterValues(String strParameterValues) {
		this.strParameterValues = strParameterValues;
	}
	
	public String getParameterHelp() {
		return strParameterHelp;
	}
	public void setParameterHelp(String strParameterHelp) {
		this.strParameterHelp = strParameterHelp;
	}
	
	public String getConnectionString() {
		return strConnectionString;
	}
	public void setConnectionString(String strConnectionString) {
		this.strConnectionString = strConnectionString;
	}
	
	public String getConnectionDNS() {
		return strConnectionDNS;
	}
	public void setConnectionDNS(String strConnectionDNS) {
		this.strConnectionDNS = strConnectionDNS;
	}
	
	public int getCounterId() {
		return nCounterId;
	}
	public void setCounterId(int nCounterId) {
		this.nCounterId = nCounterId;
	}
	
	public Long getReferenceActionId() {
		return lReferenceActionId;
	}
	public void setReferenceActionId(Long lReferenceActionId) {
		this.lReferenceActionId = lReferenceActionId;
	}

	public boolean isDelete() {
		return bDelete;
	}
	public void setDelete(boolean bDelete) {
		this.bDelete = bDelete;
	}
}
