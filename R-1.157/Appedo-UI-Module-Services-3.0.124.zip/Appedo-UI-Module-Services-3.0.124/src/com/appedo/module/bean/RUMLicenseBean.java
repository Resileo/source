package com.appedo.module.bean;

import net.sf.json.JSONObject;

public class RUMLicenseBean {

	private long lUserId;

	private String strModuleType;
	private String strStartDate;
	private String strEndDate;
	

	/* max agents is validated like user added total no. modules added in Application/Server/Database */
	private int nMaxRUMTests;
	

	/* below from `rum_config_parameters` */
	private String strLicInternalName;
	private String strLicExternalName;
	
	private boolean bEnableFilters;
	private int nReportRetentionInDays;
	

	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public String getModuleType() {
		return strModuleType;
	}
	public void setModuleType(String strModuleType) {
		this.strModuleType = strModuleType;
	}
	
	public String getStartDate() {
		return strStartDate;
	}
	public void setStartDate(String strStartDate) {
		this.strStartDate = strStartDate;
	}
	
	public String getEndDate() {
		return strEndDate;
	}
	public void setEndDate(String strEndDate) {
		this.strEndDate = strEndDate;
	}
	
	public int getMaxRUMTests() {
		return nMaxRUMTests;
	}
	public void setMaxRUMTests(int nMaxRUMTests) {
		this.nMaxRUMTests = nMaxRUMTests;
	}
	
	public String getLicInternalName() {
		return strLicInternalName;
	}
	public void setLicInternalName(String strLicInternalName) {
		this.strLicInternalName = strLicInternalName;
	}
	
	public String getLicExternalName() {
		return strLicExternalName;
	}
	public void setLicExternalName(String strLicExternalName) {
		this.strLicExternalName = strLicExternalName;
	}
	
	public boolean isbEnableFilters() {
		return bEnableFilters;
	}
	public void setEnableFilters(boolean bEnableFilters) {
		this.bEnableFilters = bEnableFilters;
	}
	
	public int getReportRetentionInDays() {
		return nReportRetentionInDays;
	}
	public void setReportRetentionInDays(int nReportRetentionInDays) {
		this.nReportRetentionInDays = nReportRetentionInDays;
	}
	

	public JSONObject toJSON() {
		JSONObject joRUMLicense = new JSONObject();

		/* below form table `userwise_lic_monthwise` */
		joRUMLicense.put("userId", this.lUserId);
		joRUMLicense.put("moduleType", this.strModuleType);
		joRUMLicense.put("startDate", this.strStartDate);
		joRUMLicense.put("endDate", this.strEndDate);
		joRUMLicense.put("maxRUMTests", this.nMaxRUMTests);

		
		/* below from `rum_config_parameters` */
		joRUMLicense.put("licInternalName", this.strLicInternalName);
		joRUMLicense.put("licExternalName", this.strLicExternalName);
		joRUMLicense.put("enableFilters", this.bEnableFilters);
		joRUMLicense.put("reportRetentionInDays", this.nReportRetentionInDays);
		
		return joRUMLicense;
	}
}
