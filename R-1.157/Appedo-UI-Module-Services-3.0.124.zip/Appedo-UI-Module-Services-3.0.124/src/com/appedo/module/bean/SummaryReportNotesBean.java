package com.appedo.module.bean;

import net.sf.json.JSONObject;

public class SummaryReportNotesBean {
	
	private long lNoteId;
	private long lRunId;
	private long lUserId;
	private String strCategory;
	private Long lScriptId;
	private String strNotes;
	
	
	public long getNoteId() {
		return lNoteId;
	}
	public void setNoteId(long lNoteId) {
		this.lNoteId = lNoteId;
	}
	
	public long getRunId() {
		return lRunId;
	}
	public void setRunId(long lRunId) {
		this.lRunId = lRunId;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public String getCategory() {
		return strCategory;
	}
	public void setCategory(String strCategory) {
		this.strCategory = strCategory;
	}
	
	public Long getScriptId() {
		return lScriptId;
	}
	public void setScriptId(Long lScriptId) {
		this.lScriptId = lScriptId;
	}
	
	public String getNotes() {
		return strNotes;
	}
	public void setNotes(String strNotes) {
		this.strNotes = strNotes;
	}
	
	public String toJSON() {
		JSONObject joCategoryNote = new JSONObject();
		
		joCategoryNote.put("id", lNoteId);
		joCategoryNote.put("runId", lRunId);
		joCategoryNote.put("category", strCategory);
		joCategoryNote.put("scriptId", lScriptId);
		joCategoryNote.put("notes", strNotes);
		
		return joCategoryNote.toString();
	}
}
