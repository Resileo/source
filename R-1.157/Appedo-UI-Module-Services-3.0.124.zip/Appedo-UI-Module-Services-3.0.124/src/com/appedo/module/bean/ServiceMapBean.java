package com.appedo.module.bean;

import java.util.ArrayList;

import net.sf.json.JSONObject;

public class ServiceMapBean {

	private long lServiceMapId, lUserId, lEnterpriseId;
	
	private String strName;
	private String strDescription;
	
	private ArrayList<JSONObject> alServiceMaps = null;
	
	private boolean bSystemGenerated = false;
	
	public ServiceMapBean() {
		alServiceMaps = new ArrayList<JSONObject>();
	}
	
	public long getServiceMapId() {
		return lServiceMapId;
	}
	public void setServiceMapId(long lServiceMapId) {
		this.lServiceMapId = lServiceMapId;
	}

	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}

	public long getEnterpriseId() {
		return lEnterpriseId;
	}
	public void setEnterpriseId(long lEnterpriseId) {
		this.lEnterpriseId = lEnterpriseId;
	}

	public String getName() {
		return strName;
	}
	public void setName(String strName) {
		this.strName = strName;
	}

	public String getDescription() {
		return strDescription;
	}
	public void setDescription(String strDescription) {
		this.strDescription = strDescription;
	}

	public ArrayList<JSONObject> getServiceMaps() {
		return alServiceMaps;
	}
	public void addServiceMap(JSONObject joMap) {
		this.alServiceMaps.add(joMap);
	}
	
	public boolean isSystemGenerated() {
		return bSystemGenerated;
	}
	public void setSystemGenerated(boolean bSystemGenerated) {
		this.bSystemGenerated = bSystemGenerated;
	}
}
