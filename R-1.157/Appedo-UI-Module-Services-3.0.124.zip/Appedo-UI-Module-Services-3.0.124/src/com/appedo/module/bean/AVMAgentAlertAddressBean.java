package com.appedo.module.bean;

import java.sql.Timestamp;

public class AVMAgentAlertAddressBean {
	
	private long lAgentAlertId;
	private long lUserId;
	private long lAgentId;
	private String strGUID;
	// alertType `EMAIL` or `SMS`
	private String strAlertType;
	private String strEmailMobile;
	private Timestamp tsVerifiedOn;
	private long lCreatedBy;
	private Timestamp tsCreatedOn;
	private long lModifedBy;
	private Timestamp tsModifedOn;
	
	
	public long getAgentAlertId() {
		return lAgentAlertId;
	}
	public void setAgentAlertId(long lAgentAlertId) {
		this.lAgentAlertId = lAgentAlertId;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}
	
	public long getAgentId() {
		return lAgentId;
	}
	public void setAgentId(long lAgentId) {
		this.lAgentId = lAgentId;
	}
	
	public String getGUID() {
		return strGUID;
	}
	public void setGUID(String strGUID) {
		this.strGUID = strGUID;
	}
	
	public String getAlertType() {
		return strAlertType;
	}
	public void setAlertType(String strAlertType) {
		this.strAlertType = strAlertType;
	}
	
	public String getEmailMobile() {
		return strEmailMobile;
	}
	public void setEmailMobile(String strEmailMobile) {
		this.strEmailMobile = strEmailMobile;
	}
	
	public Timestamp getVerifiedOn() {
		return tsVerifiedOn;
	}
	public void setVerifiedOn(Timestamp tsVerifiedOn) {
		this.tsVerifiedOn = tsVerifiedOn;
	}
	
	public long getCreatedBy() {
		return lCreatedBy;
	}
	public void setCreatedBy(long lCreatedBy) {
		this.lCreatedBy = lCreatedBy;
	}
	
	public Timestamp getCreatedOn() {
		return tsCreatedOn;
	}
	public void setCreatedOn(Timestamp tsCreatedOn) {
		this.tsCreatedOn = tsCreatedOn;
	}
	
	public long getModifedBy() {
		return lModifedBy;
	}
	public void setModifedBy(long lModifedBy) {
		this.lModifedBy = lModifedBy;
	}
	
	public Timestamp getModifedOn() {
		return tsModifedOn;
	}
	public void setModifedOn(Timestamp tsModifedOn) {
		this.tsModifedOn = tsModifedOn;
	}
}
