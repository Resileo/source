package com.appedo.module.bean;

import net.sf.json.JSONObject;

/**
 * Below bean used for details from `userwise_lic_monthwise` and `apm_config_parameters` tables
 * @author Navin
 *
 */
public class APMLicenseBean {


	/* below form table `userwise_lic_monthwise` */
	//private long lLicScheduleId;
	private long lUserId;
	
	private String strModuleType;
	private String strStartDate;
	private String strEndDate;
	
	/* max agents is validated like user added total no. modules added in Application/Server/Database */
	private int nMaxAgents;
	private int nMaxCounters;
	
	
	/* below from `apm_config_parameters` */
	private String strLicInternalName;
	private String strLicExternalName;
	
	private boolean bEnableSlider;
	private boolean bAllowPrivateCounters;
	
	private int nReportRetentionInDays;
	
	
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}

	/*public long getLicScheduleId() {
		return lLicScheduleId;
	}
	public void setLicScheduleId(long lLicScheduleId) {
		this.lLicScheduleId = lLicScheduleId;
	}*/

	public String getModuleType() {
		return strModuleType;
	}
	public void setModuleType(String strModuleType) {
		this.strModuleType = strModuleType;
	}

	public String getStartDate() {
		return strStartDate;
	}
	public void setStartDate(String strStartDate) {
		this.strStartDate = strStartDate;
	}
	public String getEndDate() {
		return strEndDate;
	}
	public void setEndDate(String strEndDate) {
		this.strEndDate = strEndDate;
	}

	public int getMaxAgents() {
		return nMaxAgents;
	}
	public void setMaxAgents(int nMaxAgents) {
		this.nMaxAgents = nMaxAgents;
	}

	public int getMaxCounters() {
		return nMaxCounters;
	}
	public void setMaxCounters(int nMaxCounters) {
		this.nMaxCounters = nMaxCounters;
	}

	public String getLicInternalName() {
		return strLicInternalName;
	}
	public void setLicInternalName(String strLicInternalName) {
		this.strLicInternalName = strLicInternalName;
	}
	
	public String getLicExternalName() {
		return strLicExternalName;
	}
	public void setLicExternalName(String strLicExternalName) {
		this.strLicExternalName = strLicExternalName;
	}
	
	public boolean isEnableSlider() {
		return bEnableSlider;
	}
	public void setEnableSlider(boolean bEnableSlider) {
		this.bEnableSlider = bEnableSlider;
	}

	public boolean isAllowPrivateCounters() {
		return bAllowPrivateCounters;
	}
	public void setAllowPrivateCounters(boolean bAllowPrivateCounters) {
		this.bAllowPrivateCounters = bAllowPrivateCounters;
	}

	public int getReportRetentionInDays() {
		return nReportRetentionInDays;
	}
	public void setReportRetentionInDays(int nReportRetentionInDays) {
		this.nReportRetentionInDays = nReportRetentionInDays;
	}
	
	
	public JSONObject toJSON() {
		JSONObject joAPMLicense = new JSONObject();

		/* below form table `userwise_lic_monthwise` */
		joAPMLicense.put("userId", this.lUserId);
		joAPMLicense.put("moduleType", this.strModuleType);
		joAPMLicense.put("startDate", this.strStartDate);
		joAPMLicense.put("endDate", this.strEndDate);
		joAPMLicense.put("maxAgents", this.nMaxAgents);
		joAPMLicense.put("maxCounters", this.nMaxCounters);

		
		/* below from `apm_config_parameters` */
		joAPMLicense.put("licInternalName", this.strLicInternalName);
		joAPMLicense.put("licExternalName", this.strLicExternalName);
		joAPMLicense.put("enableSlider", this.bEnableSlider);
		joAPMLicense.put("allowPrivateCounters", this.bAllowPrivateCounters);
		joAPMLicense.put("reportRetentionInDays", this.nReportRetentionInDays);
		
		return joAPMLicense;
	}
}
