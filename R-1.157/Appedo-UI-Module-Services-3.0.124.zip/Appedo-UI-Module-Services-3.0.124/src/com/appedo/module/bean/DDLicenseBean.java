package com.appedo.module.bean;

import net.sf.json.JSONObject;

/**
 * Below bean used for details from `userwise_lic_monthwise` and `apm_config_parameters` tables
 * @author Navin
 *
 */
public class DDLicenseBean { 


	/* below form table `userwise_lic_monthwise` */
	//private long lLicScheduleId;
	private long lUserId;
	
	private String strModuleType;
	private String strStartDate;
	private String strEndDate;

	private int nMaxProfilers;
	private int nMaxProfilersPerEnterprise;
	
	/* below from `apm_config_parameters` */
	private String strLicInternalName;
	private String strLicExternalName;
	
	
	private boolean bEnableDotNetProfiling;
	private boolean bEnableJavaProfiling;
	private boolean bEnableApplicationResponseTime;
	private boolean bEnableMostTimeConsumingTrans;
	private boolean bEnablePerformanceOfExtServices;
	private boolean bEnableTraceTransaction;
	private boolean bEnableTransBreakdown;
	private boolean bEnableStackTrace;
	private boolean bEnableSlowQuery;
	
	private int nReportRetentionInDays;
	
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}

	/*public long getLicScheduleId() {
		return lLicScheduleId;
	}
	public void setLicScheduleId(long lLicScheduleId) {
		this.lLicScheduleId = lLicScheduleId;
	}*/

	public String getModuleType() {
		return strModuleType;
	}
	public void setModuleType(String strModuleType) {
		this.strModuleType = strModuleType;
	}

	public String getStartDate() {
		return strStartDate;
	}
	public void setStartDate(String strStartDate) {
		this.strStartDate = strStartDate;
	}
	
	public String getEndDate() {
		return strEndDate;
	}
	public void setEndDate(String strEndDate) {
		this.strEndDate = strEndDate;
	}

	public String getLicInternalName() {
		return strLicInternalName;
	}
	public void setLicInternalName(String strLicInternalName) {
		this.strLicInternalName = strLicInternalName;
	}
	
	public String getLicExternalName() {
		return strLicExternalName;
	}
	public void setLicExternalName(String strLicExternalName) {
		this.strLicExternalName = strLicExternalName;
	}

	public int getReportRetentionInDays() {
		return nReportRetentionInDays;
	}
	public void setReportRetentionInDays(int nReportRetentionInDays) {
		this.nReportRetentionInDays = nReportRetentionInDays;
	}
	

	public int getMaxProfilers() {
		return nMaxProfilers;
	}
	public void setMaxProfilers(int nMaxProfilers) {
		this.nMaxProfilers = nMaxProfilers;
	}
	
	public int getMaxProfilersPerEnterprise() {
		return nMaxProfilersPerEnterprise;
	}
	public void setMaxProfilersPerEnterprise(int nMaxProfilersPerEnterprise) {
		this.nMaxProfilersPerEnterprise = nMaxProfilersPerEnterprise;
	}


	public boolean isEnableDotNetProfiling() {
		return bEnableDotNetProfiling;
	}
	public void setEnableDotNetProfiling(boolean bEnableDotNetProfiling) {
		this.bEnableDotNetProfiling = bEnableDotNetProfiling;
	}
	
	public boolean isEnableJavaProfiling() {
		return bEnableJavaProfiling;
	}
	public void setEnableJavaProfiling(boolean bEnableJavaProfiling) {
		this.bEnableJavaProfiling = bEnableJavaProfiling;
	}
	
	public boolean isEnableApplicationResponseTime() {
		return bEnableApplicationResponseTime;
	}
	public void setEnableApplicationResponseTime(boolean bEnableApplicationResponseTime) {
		this.bEnableApplicationResponseTime = bEnableApplicationResponseTime;
	}
	
	public boolean isEnableMostTimeConsumingTrans() {
		return bEnableMostTimeConsumingTrans;
	}
	public void setEnableMostTimeConsumingTrans(boolean bEnableMostTimeConsumingTrans) {
		this.bEnableMostTimeConsumingTrans = bEnableMostTimeConsumingTrans;
	}
	
	public boolean isEnablePerformanceOfExtServices() {
		return bEnablePerformanceOfExtServices;
	}
	public void setEnablePerformanceOfExtServices(boolean bEnablePerformanceOfExtServices) {
		this.bEnablePerformanceOfExtServices = bEnablePerformanceOfExtServices;
	}
	
	public boolean isEnableTraceTransaction() {
		return bEnableTraceTransaction;
	}
	public void setEnableTraceTransaction(boolean bEnableTraceTransaction) {
		this.bEnableTraceTransaction = bEnableTraceTransaction;
	}
	
	public boolean isEnableTransBreakdown() {
		return bEnableTransBreakdown;
	}
	public void setEnableTransBreakdown(boolean bEnableTransBreakdown) {
		this.bEnableTransBreakdown = bEnableTransBreakdown;
	}
	
	public boolean isEnableStackTrace() {
		return bEnableStackTrace;
	}
	public void setEnableStackTrace(boolean bEnableStackTrace) {
		this.bEnableStackTrace = bEnableStackTrace;
	}
	
	public boolean isEnableSlowQuery() {
		return bEnableSlowQuery;
	}
	public void setEnableSlowQuery(boolean bEnableSlowQuery) {
		this.bEnableSlowQuery = bEnableSlowQuery;
	}

	
	public JSONObject toJSON() {
		JSONObject joDDLicense = new JSONObject();

		/* below form table `userwise_lic_monthwise` */
		joDDLicense.put("userId", this.lUserId);
		joDDLicense.put("moduleType", this.strModuleType);
		joDDLicense.put("startDate", this.strStartDate);
		joDDLicense.put("endDate", this.strEndDate);
		joDDLicense.put("maxProfilers", this.nMaxProfilers);
		joDDLicense.put("maxProfilersPerEnterprise", this.nMaxProfilersPerEnterprise);
		
		/* below from `dd_config_parameters` */
		joDDLicense.put("licInternalName", this.strLicInternalName);
		joDDLicense.put("licExternalName", this.strLicExternalName);
		
		joDDLicense.put("enableDotNetProfiling", this.bEnableDotNetProfiling);
		joDDLicense.put("enableJavaProfiling", this.bEnableJavaProfiling);
		joDDLicense.put("enableApplicationResponseTime", this.bEnableApplicationResponseTime);
		joDDLicense.put("enableMostTimeConsumingTrans", this.bEnableMostTimeConsumingTrans);
		joDDLicense.put("enablePerformanceOfExtServices", this.bEnablePerformanceOfExtServices);
		joDDLicense.put("enableTraceTransaction", this.bEnableTraceTransaction);
		joDDLicense.put("enableTransBreakdown", this.bEnableTransBreakdown);
		joDDLicense.put("enableStackTrace", this.bEnableStackTrace);
		joDDLicense.put("enableSlowQuery", this.bEnableSlowQuery);

		joDDLicense.put("reportRetentionInDays", this.nReportRetentionInDays);
		
		return joDDLicense;
	}
}
