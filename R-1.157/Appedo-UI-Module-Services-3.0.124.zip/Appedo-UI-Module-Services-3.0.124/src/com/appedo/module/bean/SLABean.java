package com.appedo.module.bean;

import net.sf.json.JSONObject;

public class SLABean {

	private String strSLAName;
	private String strSLADescription;
	private String strSLAType;
	private String policySvrType;
	private boolean bIsPublic;
	private boolean bSystemGeneratedSLA = false;
	private long lSLAId;
	private int nMapRuleId;
	private JSONObject joSlaConfigServFormat;
	private boolean bActivePolicy = true;
	
	public String getPolicySvrType() {
		return policySvrType;
	}
	public void setPolicySvrType(String policySvrType) {
		this.policySvrType = policySvrType;
	}
	
	public JSONObject getJoSlaConfigServFormat() {
		return joSlaConfigServFormat;
	}
	public void setJoSlaConfigServFormat(JSONObject joSlaConfigServFormat) {
		this.joSlaConfigServFormat = joSlaConfigServFormat;
	}
	
	public int getMapRuleId() {
		return nMapRuleId;
	}
	public void setMapRuleId(int nSLAId) {
		this.nMapRuleId = nSLAId;
	}
	
	public long getSLAId() {
		return lSLAId;
	}
	public void setSLAId(long lSLAId) {
		this.lSLAId = lSLAId;
	}
	
	public String getSLAName() {
		return strSLAName;
	}
	public void setSLAName(String strSLAName) {
		this.strSLAName = strSLAName;
	}
	
	public String getSLADescription() {
		return strSLADescription;
	}
	public void setSLADescription(String strSLADescription) {
		this.strSLADescription = strSLADescription;
	}
	
	public String getSLAType() {
		return strSLAType;
	}
	public void setSLAType(String strSLAType) {
		this.strSLAType = strSLAType;
	}
	
	public boolean isbIsPublic() {
		return bIsPublic;
	}
	public void setbIsPublic(boolean bIsPublic) {
		this.bIsPublic = bIsPublic;
	}

	public boolean isSystemGeneratedSLA() {
		return bSystemGeneratedSLA;
	}
	public void setSystemGeneratedSLA(boolean bSystemGeneratedSLA) {
		this.bSystemGeneratedSLA = bSystemGeneratedSLA;
	}
	
	public boolean isActivePolicy() {
		return bActivePolicy;
	}
	public void setActivePolicy(boolean bActivePolicy) {
		this.bActivePolicy = bActivePolicy;
	}
}
