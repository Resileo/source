package com.appedo.module.bean;

import net.sf.json.JSONObject;

/**
 * Below bean used for details from `userwise_lic_monthwise` and `apm_config_parameters` tables
 * @author Navin
 *
 */
public class SUMLicenseBean {


	/* below form table `userwise_lic_monthwise` */
	//private long lLicScheduleId;
	private long lUserId;
	
	private String strModuleType;
	private String strStartDate;
	private String strEndDate;
	
	/* max agents is validated like user added total no. modules added in Application/Server/Database */
	private int nMaxDesktopMeasurements;
	private int nMaxMobileMeasurements;
	
	private int nMaxTest;
	private int nMaxLocation;
	
	/* below from `apm_config_parameters` */
	private String strLicInternalName;
	private String strLicExternalName;

	private boolean bAllowURL;
	private boolean bAllowTransaction;
	
	private int nReportRetentionInDays;
	
	
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long lUserId) {
		this.lUserId = lUserId;
	}

	/*public long getLicScheduleId() {
		return lLicScheduleId;
	}
	public void setLicScheduleId(long lLicScheduleId) {
		this.lLicScheduleId = lLicScheduleId;
	}*/

	public String getModuleType() {
		return strModuleType;
	}
	public void setModuleType(String strModuleType) {
		this.strModuleType = strModuleType;
	}

	public String getStartDate() {
		return strStartDate;
	}
	public void setStartDate(String strStartDate) {
		this.strStartDate = strStartDate;
	}
	public String getEndDate() {
		return strEndDate;
	}
	public void setEndDate(String strEndDate) {
		this.strEndDate = strEndDate;
	}

	public String getLicInternalName() {
		return strLicInternalName;
	}
	public void setLicInternalName(String strLicInternalName) {
		this.strLicInternalName = strLicInternalName;
	}
	
	public String getLicExternalName() {
		return strLicExternalName;
	}
	public void setLicExternalName(String strLicExternalName) {
		this.strLicExternalName = strLicExternalName;
	}
	
	public int getReportRetentionInDays() {
		return nReportRetentionInDays;
	}
	public void setReportRetentionInDays(int nReportRetentionInDays) {
		this.nReportRetentionInDays = nReportRetentionInDays;
	}
	

	public int getMaxDesktopMeasurements() {
		return nMaxDesktopMeasurements;
	}
	public void setMaxDesktopMeasurements(int nMaxDesktopMeasurements) {
		this.nMaxDesktopMeasurements = nMaxDesktopMeasurements;
	}
	
	public int getMaxMobileMeasurements() {
		return nMaxMobileMeasurements;
	}
	public void setMaxMobileMeasurements(int nMaxMobileMeasurements) {
		this.nMaxMobileMeasurements = nMaxMobileMeasurements;
	}
	
	public int getMaxTest() {
		return nMaxTest;
	}
	public void setMaxTest(int nSUMMAXTest) {
		this.nMaxTest = nSUMMAXTest;
	}
	
	public int getMaxLocation() {
		return nMaxLocation;
	}
	public void setMaxLocation(int nMAXLocation) {
		this.nMaxLocation = nMAXLocation;
	}
	
	public boolean isAllowURL() {
		return bAllowURL;
	}
	public void setAllowURL(boolean bAllowURL) {
		this.bAllowURL = bAllowURL;
	}
	
	public boolean isAllowTransaction() {
		return bAllowTransaction;
	}
	public void setAllowTransaction(boolean bAllowTransaction) {
		this.bAllowTransaction = bAllowTransaction;
	}
	
	
	public JSONObject toJSON() {
		JSONObject joSUMLicense = new JSONObject();

		/* below form table `userwise_lic_monthwise` */
		joSUMLicense.put("userId", this.lUserId);
		joSUMLicense.put("moduleType", this.strModuleType);
		joSUMLicense.put("startDate", this.strStartDate);
		joSUMLicense.put("endDate", this.strEndDate);
		joSUMLicense.put("max_measurement_per_day", this.nMaxDesktopMeasurements);
		joSUMLicense.put("maxMobileMeasurements", this.nMaxMobileMeasurements);
		
		/* below from `sum_config_parameters` */
		joSUMLicense.put("lic_internal_name", this.strLicInternalName);
		joSUMLicense.put("licExternalName", this.strLicExternalName);
		joSUMLicense.put("allow_url", this.bAllowURL);
		joSUMLicense.put("allow_transaction", this.bAllowTransaction);
		joSUMLicense.put("max_test", this.nMaxTest);
		joSUMLicense.put("max_location", this.nMaxLocation);
		joSUMLicense.put("max_retention_in_days", this.nReportRetentionInDays);
		
		return joSUMLicense;
	}
}
