package com.appedo.module.bean;

public class MapCounterBean {

	private int nBreachId;
	private int nCounterId;
	private String strCounterName;
	private int nCounterTemplateId;
	private int nCounterTypeVersionId;
	private String strGUID;
	private boolean bPercentage;
	private boolean bThresholdAbove;
	private int nMinBreachCount;
	private String strModuleName;
	private String strModuleDetailedValue;
	private long lWarningThresholdValue;
	private long lCriticalThresholdValue;
	private int UId;
	private long lSLAId;
	private String strCategory;
	private int nMapCounterId;
	private int nDenominatorCounterId;
	private boolean bPercentageCalculation;
	private String strPolicyName;
	private String strPolicyDesc;

	public int getMapCounterId() {
		return nMapCounterId;
	}
	public void setMapCounterId(int mapCounterId) {
		nMapCounterId = mapCounterId;
	}

	public String getCategory() {
		return strCategory;
	}
	public void setCategory(String category) {
		strCategory = category;
	}

	public long getSLAId() {
		return lSLAId;
	}
	public void setSLAId(long lSLAId) {
		this.lSLAId = lSLAId;
	}

	public int getBreachId() {
		return nBreachId;
	}
	public void setBreachId(int breachId) {
		nBreachId = breachId;
	}

	public int getCounterId() {
		return nCounterId;
	}
	public void setCounterId(int counterId) {
		nCounterId = counterId;
	}

	public String getCounterName() {
		return strCounterName;
	}
	public void setCounterName(String counterName) {
		strCounterName = counterName;
	}

	public int getCounterTemplateId() {
		return nCounterTemplateId;
	}
	public void setCounterTemplateId(int counterTemplateId) {
		nCounterTemplateId = counterTemplateId;
	}

	public int getCounterTypeVersionId() {
		return nCounterTypeVersionId;
	}
	public void setCounterTypeVersionId(int counterTemplateVersionId) {
		nCounterTypeVersionId = counterTemplateVersionId;
	}

	public String getGuid() {
		return strGUID;
	}
	public void setGuid(String guid) {
		strGUID = guid;
	}

	public boolean isInPercentage() {
		return bPercentage;
	}
	public void setInPercentage(boolean inPercentage) {
		bPercentage = inPercentage;
	}

	public boolean isIsThresholdAbove() {
		return bThresholdAbove;
	}
	public void setIsThresholdAbove(boolean isThresholdAbove) {
		bThresholdAbove = isThresholdAbove;
	}

	public int getMinBreachCount() {
		return nMinBreachCount;
	}
	public void setMinBreachCount(int minBreachCount) {
		nMinBreachCount = minBreachCount;
	}

	public String getModuleName() {
		return strModuleName;
	}
	public void setModuleName(String moduleName) {
		strModuleName = moduleName;
	}

	public String getModuleDetailedValue() {
		return strModuleDetailedValue;
	}
	public void setModuleDetailedValue(String moduleDetailedValue) {
		strModuleDetailedValue = moduleDetailedValue;
	}

	public int getUId() {
		return UId;
	}
	public void setUId(int uId) {
		UId = uId;
	}

	public long getWarningThresholdValue() {
		return lWarningThresholdValue;
	}
	public void setWarningThresholdValue(long warningThresholdValue) {
		lWarningThresholdValue = warningThresholdValue;
	}

	public long getCriticalThresholdValue() {
		return lCriticalThresholdValue;
	}
	public void setCriticalThresholdValue(long criticalThresholdValue) {
		lCriticalThresholdValue = criticalThresholdValue;
	}

	public long getDenominatorCounteId() {
		return nDenominatorCounterId;
	}
	public void setDenominatorCounteId(int denominatorCounterId) {
		this.nDenominatorCounterId = denominatorCounterId;
	}

	public boolean isPercentageCalculation() {
		return bPercentageCalculation;
	}
	public void setIsPercentageCalculation(boolean isPercentageCalculation) {
		bPercentageCalculation = isPercentageCalculation;
	}
	public String getPolicyName() {
		return strPolicyName;
	}
	public void setPolicyName(String strPolicyName) {
		this.strPolicyName = strPolicyName;
	}
	public String getPolicyDesc() {
		return strPolicyDesc;
	}
	public void setPolicyDesc(String strPolicyDesc) {
		this.strPolicyDesc = strPolicyDesc;
	}

}
