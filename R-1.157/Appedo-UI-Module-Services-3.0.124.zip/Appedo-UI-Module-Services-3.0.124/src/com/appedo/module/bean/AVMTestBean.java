package com.appedo.module.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.module.utils.UtilsFactory;

/**
 * 
 * Bean replica for the database table `sum_test_master`
 * This keeps the parameters like Test id, name, location to be tested and etc...
 * 
 */
public class AVMTestBean implements Comparable<AVMTestBean> {
	
	private long nTestId;
	private long lUserId;
	private String strTestName;
	private String strStartDate;
	private String strEndDate;
	private int nRunEveryMinute;
	private boolean bStatus;
	private String strURL;
	private String strRequestMethod;
	private boolean bTestHeadMethodFirst = true;
	private JSONArray jaRequestHeaders;
	private JSONArray jaRequestParameters;
	
	// SLA parameters
	private long lAmSLAId;
	private boolean changedStDate;
	private int avmMinBreachCount;
	private JSONObject joDays;
	
	private String strStartTime;
	private String strEndTime;
	private int ntimezone_offset;
	
	private Date dateQueuedOn = null;
	
	private HashSet<JSONObject> hsTargetLocations = null;
	
	public AVMTestBean() {
		hsTargetLocations = new HashSet<JSONObject>();
	}
	
	public long getTestId() {
		return nTestId;
	}
	public void setTestId(long testId) {
		nTestId = testId;
	}
	
	public long getUserId() {
		return lUserId;
	}
	public void setUserId(long userId) {
		lUserId = userId;
	}
	
	public String getStartDate() {
		return strStartDate;
	}
	public void setStartDate(String startDate) {
		strStartDate = startDate;
	}
	
	public String getEndDate() {
		return strEndDate;
	}
	public void setEndDate(String endDate) {
		strEndDate = endDate;
	}
	
	public int getRunEveryMinute() {
		return nRunEveryMinute;
	}
	public void setRunEveryMinute(int nRunEveryMin) {
		nRunEveryMinute = nRunEveryMin;
	}
	
	public String getTestName() {
		return strTestName;
	}
	public void setTestName(String strTestName) {
		this.strTestName = strTestName;
	}
	
	public String getURL() {
		return strURL;
	}
	public void setURL(String strURL) {
		this.strURL = strURL;
	}
	
	public String getRequestMethod() {
		return strRequestMethod;
	}
	public void setRequestMethod(String strRequestMethod) {
		this.strRequestMethod = strRequestMethod;
	}
	
	public boolean isTestHeadMethodFirst() {
		return bTestHeadMethodFirst;
	}
	public void setTestHeadMethodFirst(boolean bTestHeadFirst) {
		this.bTestHeadMethodFirst = bTestHeadFirst;
	}
	
	public JSONArray getRequestHeaders() {
		return jaRequestHeaders;
	}
	public void setRequestHeaders(JSONArray jaRequestHeaders) {
		this.jaRequestHeaders = jaRequestHeaders;
	}
	
	public JSONArray getRequestParameters() {
		return jaRequestParameters;
	}
	public void setRequestParameters(JSONArray jaRequestParameters) {
		this.jaRequestParameters = jaRequestParameters;
	}
	
	public boolean isStatus() {
		return bStatus;
	}
	public void setStatus(boolean status) {
		bStatus = status;
	}
	
	public HashSet<JSONObject> getTargetLocations() {
		return hsTargetLocations;
	}
	public ArrayList<JSONObject> getTargetLocationsArrayList() {
		ArrayList<JSONObject> alTargetLocations = new ArrayList<JSONObject>();
		
		Iterator<JSONObject> iter = hsTargetLocations.iterator();
		while(iter.hasNext()) {
			alTargetLocations.add(iter.next());
		}
		return alTargetLocations;
	}
	public void setTargetLocations(HashSet<JSONObject> hsLocations) {
		UtilsFactory.clearCollectionHieracy(this.hsTargetLocations);
		this.hsTargetLocations = hsLocations;
	}
	public void addTargetLocation(JSONObject strTargetLocation) {
		this.hsTargetLocations.add(strTargetLocation);
	}
	
	public Date getQueuedOn() {
		return dateQueuedOn;
	}
	public void setQueuedOn(Date dateQueuedOn) {
		this.dateQueuedOn = dateQueuedOn;
	}

	public int getAvmMinBreachCount() {
		return avmMinBreachCount;
	}
	public void setAvmMinBreachCount(int amMinBreachCount) {
		this.avmMinBreachCount = amMinBreachCount;
	}
	
	/*
	public JSONObject toJSON() {
		JSONObject joBean = new JSONObject();
		
		joBean.put("test_id", nTestId);
		joBean.put("user_id", lUserId);
		joBean.put("test_name", strTestName);
		joBean.put("url", strURL);
		joBean.put("run_every_minute", nRunEveryMinute);
		joBean.put("status", bStatus);
		joBean.put("start_date", strStartDate);
		joBean.put("end_date", strEndDate);
		joBean.put("dateQueuedOn", dateQueuedOn);
		joBean.put("am_min_breach_count", avmMinBreachCount);
		
		return joBean;
	} */
	
	public boolean isChangedStDate() {
		return changedStDate;
	}
	public void setChangedStDate(boolean changedStDate) {
		this.changedStDate = changedStDate;
	}

	public long getAmSLAId() {
		return lAmSLAId;
	}
	public void setAmSLAId(long lAmSLAId) {
		this.lAmSLAId = lAmSLAId;
	}
	
	public JSONObject getJoDays() {
		return joDays;
	}
	public void setJoDays(JSONObject joDays) {
		this.joDays = joDays;
	}
	
	public String getStartTime() {
		return strStartTime;
	}
	public void setStartTime(String strStartTime) {
		this.strStartTime = strStartTime;
	}

	public String getEndTime() {
		return strEndTime;
	}
	public void setEndTime(String strEndTime) {
		this.strEndTime = strEndTime;
	}
	
	public int getTimezone_offset() {
		return ntimezone_offset;
	}
	public void setTimezone_offset(int ntimezone_offset) {
		this.ntimezone_offset = ntimezone_offset;
	}
	
	@Override
	public String toString() {
		return Long.toString(nTestId);
	}
	
	@Override
	public int compareTo(AVMTestBean another) {
		// compareTo should return < 0 if this is supposed to be
        // less than other, > 0 if this is supposed to be greater than 
        // other and 0 if they are supposed to be equal
    	
    	return ((int) (dateQueuedOn.getTime() - another.getQueuedOn().getTime()));
	}
}
