package com.appedo.module.common;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.manager.AppedoConstants;
import com.appedo.manager.LogManager;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.utils.UtilsFactory;


/**
 * This class holds the application level variables which required through the application.
 * 
 * @author navin
 *
 */
public class Constants {
	
	//public final static String CONFIGFILEPATH = InitServlet.realPath+"/WEB-INF/classes/com/softsmith/floodgates/resource/config.properties";
	public static String CONSTANTS_FILE_PATH = "";
	
	public static String RESOURCE_PATH = "";
	
	public static String APPEDO_CONFIG_FILE_PATH = "";
	public static String APPEDO_SLA_CONFIG_FILE_PATH = "";
	public static String SMTP_MAIL_CONFIG_FILE_PATH = "";
	
	public static String PATH = ""; 
	public static String VUSCRIPTSPATH = "";
	public static String JMETERVUSCRIPTSFOLDERPATH = "";
	public static String JMETERVUSCRIPTSPATH = "";
	public static String FLOODGATESVUSCRIPTSPATH = "";
	public static String FLOODGATESSCENARIOXMLPATH = "";
	public static String FLOODGATESSCENARIOXMLFOLDERPATH = "";
	public static String JMETERSCENARIOXMLFOLDERPATH = "";
	public static String JMETERSCENARIOXMLPATH = "";
	public static String JMETERSCENARIOFOLDERPATH = "";
	public static String JMETERSCENARIOSPATH = "";
	public static String CSVFILE = "";
	public static String UPLOADPATH = "";
	public static String VARIABLEPATH = "";
	public static String SUMMARYREPORTPATH = "";
	public static String VARIABLEXMLPATH = "";
	public static String VARIABLEXMLFOLDERPATH = "";
	public static String JMETERTESTPATH = "";
	public static String JMETERTESTJTLPATH = "";
	public static String JMETERCSVPATH = "";
	public static String JMETERSUMMARYREPORTPATH="";
	public static String EMAIL_TEMPLATES_PATH = "";
	public static String DOWNLOADS = "";
	
	public static String SELENIUM_SCRIPT_CLASS_FILE_PATH = "";
	public static String FROMEMAILADDRESS = "";

	public static String FG_CONTROLLER_IP = "";
	public static String FG_CONTROLLER_PORT = "";
	public static String FG_CONTROLLER_PORT1 = "";
	public static String FG_APPLICATION_IP = "";
	
	public static String JM_CONTROLLER_IP= "";
	public static String JM_CONTROLLER_PORT = "";

	public static String APPEDO_URL = "";	
	public static String WEBSERVICE_HOST = "";
	public static String FLOODGATESVUSCRIPTSFOLDERPATH = "";
	public static String FLOODGATESVUSCRIPTSTEMPFOLDERPATH = "";
	public static String APPEDO_SCHEDULER = "";
	public static String LICENSEPATH = "";
	public static String LICENSEXMLPATH = "";
	public static String APPEDO_HARFILES = "";
	public static String HAR_REPOSITORY_URL = "";
	public static String APPEDO_COLLECTOR = "";	
	public static String APPEDO_UI_RUM_SERVICES = "";
	public static String APPEDO_UI_CREDENTIAL_SERVICES = null;
	public static String APPEDO_UI_MODULE_SERVICES = null;
	public static String APPEDO_UI_LT_SERVICES = null;
	public static String APPEDO_LT_EXECUTION_SERVICES = null;
	public static String APPEDO_UI_SUM_SERVICES = null;
	public static String APPEDO_UI_SLA_SERVICES = null;
	public static String FG_VUSCRIPTS_TEMP_PATH = "";
	
	public static String ACTION_LOG_FILE_FOLDER = "";
	public static String SLAVE_CONNECTION_PRIMARY_PORT = "";
	public static String SLAVE_CONNECTION_SECONDARY_PORT = "";
	// Since license 
	//public static String MAX_COUNTERS = "";
	
	public static HashMap<String, String> AGENT_LATEST_BUILD_VERSION = new HashMap<String, String>();
	
	
	// Limitation for Counter Charts time window
	public static int COUNTER_CHART_START_DELAY = 60;//62;
	public static int COUNTER_CHART_END_DELAY = 0;//2;
	public static int COUNTER_MINICHART_START_DELAY = 10;//12;
	public static int COUNTER_MINICHART_END_DELAY = 0;//2;
	
	// tried to append 0 for diff between the prev result time and current result time is > 1 min
	public static final int COUNTER_CHART_TIME_INTERVAL = 1*60*1000;
	public static final int COUNTER_CHART_ADD_0_FOR_EVERY = 3;
	
	public static String CLASS_EXPORT_URL;
	
	public static String SELENIUM_SCRIPT_PACKAGES;
	
	// UI-Service applications
	public static String RUM_UI_SERVICE_APPLICATION_NAME = null;
	public static String SLA_UI_SERVICE_APPLICATION_NAME = null;
	
	// RUM related variables, TODO remove below 2 commented lines later next builds
	//public static String RUM_JS_SCRIPT_FILES_URL = null;
	//public static String RUM_COLLECTOR_IP = null;
	
	//log4j properties file path
	public static String LOG4J_PROPERTIES_FILE = "";
	
	public static boolean IS_CAPTCHA_VALIDATION_ENABLE = true;
	
	public static HashMap<String, String[]> MINICHART_COUNTERS = new HashMap<String, String[]>();
	
	public static LinkedHashMap<String, LinkedHashMap<String, String>> COUNTER_TYPES_DOWNLOAD_FILE_PATH = new LinkedHashMap<String, LinkedHashMap<String, String>>();
	public static Map<String, Integer> SLA_BREACH_TYPES = new HashMap<String, Integer>();
	
	//
	/*public static String MONITOR_COLLECTOR_URL = "";
	public static String RUM_COLLECTOR_URL = "";
	public static String CI_COLLECTOR_URL = "";*/
	
	public static JSONObject MONITOR_COLLECTOR = null;
	public static JSONObject RUM_COLLECTOR = null;
	public static JSONObject CI_COLLECTOR = null;
	
	public static String HTTPS_CRT_NAME = null;
	
	// For APM license, to check total max modules added, so that to restrict ADD module for download agents
	public static String APM_GROUP = "";
	public static String MAX_LOADGEN_CREATION = "";
	public static String DELAY_SAMPLING = "";
	public static String UPLOAD_URL = "";
	
	public static final int ZERO_APPEND_FROM_LAST_MIN_TO_START = 60;
	
	public static int SLOW_QRY_LIMIT = 0;
	public static int TOP_PROCESS_LIMIT = 0;
	public static double CHART_LINE_WIDTH = 1;
	public static double CHART_CIRCLE_WIDTH = 1.5;
	public static double CHART_BAR_WIDTH = 10;
	public static String CHART_MODULE_APM = "APM";
	//public static String CRITWARN = "CRITWARN";
	public static String CWV = "CWV";
	public static String CWOV = "CWOV";
	public static String RUM_MODULE = "RUM";
	public static String SUM_MODULE = "SUM";
	public static String LOG_MODULE = "LOG";
	public static String CRITWARN = "CRITWARN";
	public static String CRITICAL = "CRITICAL";
	public static String WARNING = "WARNING";

	// To avoid more recursive method calls shown in the UI, limit child length.
	// This will prevent Browser from hang or invisible, due to more depth.
	public static int PROFILER_STACK_METHOD_CALL_LEVEL = 15;
	 
	
	// for SLA policy creation after moduleAdded, type & for policyName default string to append at Last
	public static final String SLA_AUTOGEN_DEFAULT_TYPE = "Alert";
	public static String SLA_AUTOGEN_DEFAULT_LASTNAME = " - SLA Policy - AutoGenerated";
	public static String SLA_AUTOGEN_MIN_BREACH_COUNT = "";
	
	public static String LT_QUEUE_IP = "";
	public static String LT_QUEUE_PORT = "";
	
	
	public static String SUMMARYREPORTPATH_SHIPPING="";
	public static String APPEDO_URL_FILE_TRANSFER = "";
	
	public static String LT_QUEUE_SERVICES = "";

	public static String VARIABLESFOLDERPATH = "";
	public static String MAX_COUNTERS = "";
	
	//log4j properties file path
	
	public static int LOADTESTSAMPLEDURATION = 5;
	public static String LOADTESTRUNCHARTQUERYDURATION = "15 Mins";
	
	public static long LT_COUNT_RESULT_LIMIT = 1000000;
	public static long LT_BATCH_EPOCH_VALUE = 1000;
	public static int LT_RUNTIME_CHECK_HOUR = 3;
	public static int LT_RUNTIME_CHECK_MINUTE = 1;

	// tried to append 0 for diff between the prev result time and current result time is > 1 min
	// tried to breakCounterSet, for 1 hour interval
	public static final int COUNTER_CHART_HOUR_INTERVAL = 1;
	
	
	public static String APPEDO_LT = "APPEDO_LT";
	public static String JMETER = "JMETER";
	
	public static String LOAD_TEST_COMPLETED = "Completed";
	public static String LOAD_TEST_RUNNING = "Running";
	public static String LOAD_TEST_FAILED = "Failed";

	public static String LOAD_TEST_CHART_HOUR = "Hours";
	public static String LOAD_TEST_CHART_MINS = "Mins";
	public static String LOAD_TEST_CHART_SECS = "Secs";
	
	public static String APPEDO_LT_USER_COUNT = "userCountChartData";
	public static String APPEDO_LT_REQUEST_RESPONSE = "requestResponseChartData";
	public static String APPEDO_LT_HIT_COUNT = "hitCountChartData";
	public static String APPEDO_LT_THROUGHPUT = "throughputChartData";
	public static String APPEDO_LT_ERROR_COUNT = "errorCountChartData";
	public static String APPEDO_LT_PAGE_RESPONSE = "pageResponseChartData";
	public static String APPEDO_LT_LOADGENS_AVG_REQ_RESPS = "loadgensAvgReqResps";
	public static String APPEDO_LT_LOADGENS_AVG_PAGE_RESPS = "loadgensAvgPageResps";
	public static String APPEDO_LT_HIT_COUNT_THROUGHPUT_REQUEST_RESPONSE = "combinedDataForRequestResponseHitCountChartAndThroughput";
	public static String QUERY_STRING_SEPARATOR = "#";

	public static long WORK_MEM_100_MB = 102400;
	public static long WORK_MEM_10_MB = 10240;

	public static String REQUEST_RESPONSE = "requestResponse";
	public static String CONTAINER_RESPONSE = "containerResponse";
	public static String TRANSACTION_RESPONSE = "transactionResponse";
	public static String ERROR_COUNT = "errorCount";
	public static String ERROR_DESCRIPTION = "errorDescription";
	public static String FILE_STRING_SEPARATOR = "/";

	public static String MANUAL_REPORT_PREPARATION_STARTED = "MANUAL REPORT PREPARATION STARTED";
	public static String MANUAL_REPORT_GENERATION_STARTED = "MANUAL REPORT GENERATION STARTED";
	public static String MANUAL_REPORT_GENERATION_COMPLETED = "MANUAL REPORT GENERATION COMPLETED";
	public static String MANUAL_REPORT_GENERATION_FAILED = "MANUAL REPORT GENERATION FAILED";
	public static long MANUAL_REPORT_START_TIME = 0;

	public static String AUTO_REPORT_PREPARATION_STARTED = "AUTO REPORT PREPARATION STARTED";
	public static String AUTO_REPORT_GENERATION_STARTED = "AUTO REPORT GENERATION STARTED";
	public static String AUTO_REPORT_GENERATION_COMPLETED = "AUTO REPORT GENERATION COMPLETED";
	public static String AUTO_REPORT_GENERATION_FAILED = "AUTO REPORT GENERATION FAILED";
	
	public static String COMPLETED = "COMPLETED";
	public static String REPORT_GENERATION_STARTED = "REPORT GENERATION STARTED";
	
	// for LT run, used the default parallel connections value
	public static String DEFAULT_PARALLEL_CONNECTIONS = "";
	
	
	public static String CONFIG_FILE_PATH = "";
	
	public static String SELENIUM_SCRIPT;
	public static String APPEDO_WPT_SCHEDULER = "";
	public static String WPT_CONTENT_BREAKDOWN = "";
	
	public static int SUM_WARNING_LIMIT = 10;
	public static int SUM_ERROR_LIMIT = 40;
	public static int SUM_DOWNLOAD_LIMIT = 30720;
	public static int SUM_UPLOAD_LIMIT = 30720;
	public static int SUM_LATENCY_LIMIT = 1300;
	public static int SUM_PACKET_LOSS_LIMIT = 100;

	public static int SUM_DEFAULT_WARNING_LIMIT = 5;
	public static int SUM_DEFAULT_ERROR_LIMIT = 20;
	public static int SUM_DEFAULT_MIN_BREACH_COUNT = 20;
	// Replace WPT-SERVER url by redirector_url
	public static JSONArray WPT_APPEDO_REDIRECTOR = null;

	//SLA Services
	
	public static String APPEDO_SLA_COLLECTOR = "";

	public static int SLA_SETTING_MAX_TRY_COUNT = 0;
	public static int SLA_SETTING_TRY_COUNT_DURATION_IN_MIN = 0;
	public static int SLA_SETTING_TRIGGER_ALERT_EVERY_IN_MIN = 0;

	
	/*public enum AGENT_TYPE {
	TOMCAT_7X("TOMCAT 7.X", "tomcat_performance_counter"), JBOSS("JBOSS", "jboss_performance_counter"), MSIIS("MSIIS", "msiis_performance_counter"), 
	JAVA_PROFILER("JAVA_PROFILER", "tomcat_profiler"), 
	LINUX("LINUX", "linux_performance_counter"), MSWINDOWS("MSWINDOWS", "windows_performance_counter"), 
	MYSQL("MYSQL", "mysql_performance_counter"), MSSQL("MSSQL", "mssql_performance_counter");
	
	private String strAgentType, strTableName;
	
	private AGENT_TYPE(String agentType, String tableName) {
		strAgentType = agentType;
		strTableName = tableName;
	}
	
	public void setMySQLVersion(String strVersionNo) {
		strAgentType = "MYSQL "+strVersionNo;
	}
	
	public String getTableName() {
		return strTableName;
	}
	
	@Override
	public String toString() {
		return strAgentType;
	}
}*/
	
	//Log ui Services constants
	public static String SHELL_FILE_PATH = "";
	public static String PEM_FILE_PATH = "";
	public static String APPEDO_PEM_FILE = "";
	public static String ELK_DOWNLOAD_URI = "";
	public static String ELK_DOWNLOAD_PATH = "";
	public static HashMap<Long, String> ELK_ID_VS_NAME = new HashMap<Long, String>();
	//log4j properties file path
	public static boolean IS_ELK_THREAD_RUNNING = false;
	public static Map<String,JSONArray> ELK_USER_VS_DATA = new HashMap<String,JSONArray>();
	public static final long ELK_TIMER_INTERVAL = 2*60*1000; //Hardcoded as 2 min
	
	public static String EMAIL_TO_ALERT_FOR_LOG_VIEW = "";
	
	
	public enum CHART_START_INTERVAL {
		_1("3 hours"), _2("24 hours"), _3("7 days"), _4("15 days"), _5("30 days");
		
		private String strInterval;
		
		private CHART_START_INTERVAL(String strInterval) {
			this.strInterval = strInterval;
		}
		
		public String getInterval() {
			return strInterval;
		}
	}

	
	public enum SUM_TYPE {
		AVAILABILITY_MONITORING("AVAILABILITY_MONITORING"), RESPONSE_MONITORING("RESPONSE_MONITORING");

		private String name;

		private SUM_TYPE(String strName) {
			name = strName;
		}

		public String getVendorName() {
			return name;
		}
	}
	
	
	
	/*public enum SUM_CHART_START_INTERVAL {
		_1("24 hours"), _2("7 days"), _3("15 days"), _4("30 days"), _5("60 days"), _6("120 days"), _7("180 days");
		
		private String strInterval;
		
		private SUM_CHART_START_INTERVAL(String strInterval) {
			this.strInterval = strInterval;
		}
		
		public String getInterval() {
			return strInterval;
		}
	}*/
	
	public enum ELK_TYPE {
		ES("Elasticsearch"), LS("Logstash"), KIBANA("Kibana"), NGINX("Nginx");
		
		private String name;
		
		private ELK_TYPE(String strName) {
			name = strName;
		}
		
		public String getVendorName() {
			return name;
		}
	}
	
	/**
	 * Loads constants properties 
	 * 
	 * @param srtConstantsPath
	 */
	public static void loadConstantsProperties(String srtConstantsPath) throws Exception {
    	Properties prop = new Properties();
    	InputStream is = null;
    	
        try {
        	is = new FileInputStream(srtConstantsPath);
    		prop.load(is);
    		
     		// Appedo application's resource directory path
     		RESOURCE_PATH = prop.getProperty("RESOURCE_PATH");
     		
     		APPEDO_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("APPEDO_CONFIG_FILE_PATH");
     		APPEDO_SLA_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("APPEDO_SLA_CONFIG_FILE_PATH");
     		PATH = RESOURCE_PATH+prop.getProperty("Path");
     		
     		FLOODGATESVUSCRIPTSFOLDERPATH = RESOURCE_PATH+prop.getProperty("floodgatesvuscriptsfolderpath");
			VARIABLESFOLDERPATH = RESOURCE_PATH+prop.getProperty("variablesfolderpath");
     		FLOODGATESVUSCRIPTSTEMPFOLDERPATH = RESOURCE_PATH+prop.getProperty("floodgatesvuscriptstempfolderpath");
     		VUSCRIPTSPATH = RESOURCE_PATH+prop.getProperty("VUScriptspath");
     		FLOODGATESVUSCRIPTSPATH = RESOURCE_PATH+prop.getProperty("floodgatesvuscriptspath");
     		JMETERVUSCRIPTSFOLDERPATH = RESOURCE_PATH+prop.getProperty("jmetervuscriptsfolderpath");
     		JMETERVUSCRIPTSPATH = RESOURCE_PATH+prop.getProperty("jmetervuscriptspath");
     		FLOODGATESSCENARIOXMLPATH = RESOURCE_PATH+prop.getProperty("floodgatesscenarioxmlpath");
     		FLOODGATESSCENARIOXMLFOLDERPATH = RESOURCE_PATH+prop.getProperty("floodgatesscenarioxmlfolderpath");
     		JMETERSCENARIOXMLPATH = RESOURCE_PATH+prop.getProperty("jmeterscenarioxmlpath");
     		JMETERSCENARIOXMLFOLDERPATH = RESOURCE_PATH+prop.getProperty("jmeterscenarioxmlfolderpath");
     		JMETERSCENARIOFOLDERPATH = RESOURCE_PATH+prop.getProperty("jmeterscenariofolderpath");
     		CSVFILE = RESOURCE_PATH+prop.getProperty("Csvfile");
     		UPLOADPATH = RESOURCE_PATH+prop.getProperty("Uploadpath");
     		VARIABLEPATH = RESOURCE_PATH+prop.getProperty("Variablepath");
     		SUMMARYREPORTPATH = RESOURCE_PATH+prop.getProperty("summaryreportpath");
			SUMMARYREPORTPATH_SHIPPING = prop.getProperty("summaryreportpath");
     		VARIABLEXMLPATH = RESOURCE_PATH+prop.getProperty("VariableXMLpath");
     		VARIABLEXMLFOLDERPATH = RESOURCE_PATH+prop.getProperty("VariableXMLFolderpath");
     		JMETERSCENARIOSPATH = RESOURCE_PATH+prop.getProperty("jmeterscenariospath");
     		JMETERTESTPATH = RESOURCE_PATH+prop.getProperty("jmetertestpath");
     		JMETERTESTJTLPATH = RESOURCE_PATH+prop.getProperty("jmetertestjtlpath");
     		DOWNLOADS = RESOURCE_PATH+prop.getProperty("downloads");
     		JMETERCSVPATH = RESOURCE_PATH+prop.getProperty("jmetercsvpath");
     		JMETERSUMMARYREPORTPATH = RESOURCE_PATH+prop.getProperty("jmetersummaryreportpath");
     		LICENSEPATH = RESOURCE_PATH+prop.getProperty("licensepath");
     		LICENSEXMLPATH = RESOURCE_PATH+prop.getProperty("licensexmlpath");
     		EMAIL_TEMPLATES_PATH = RESOURCE_PATH+prop.getProperty("EMAIL_TEMPLATES_PATH");
     		FG_VUSCRIPTS_TEMP_PATH = RESOURCE_PATH+prop.getProperty("FG_VUSCRIPTS_TEMP_PATH");
     		MAX_COUNTERS = prop.getProperty("max_counters");
     		APM_GROUP = prop.getProperty("APM_GROUP");
     		MAX_LOADGEN_CREATION = prop.getProperty("MAX_LOADGEN_CREATION");
     		DELAY_SAMPLING = prop.getProperty("DELAY_SAMPLING");
     		
     		// Mail configuration 
     		SMTP_MAIL_CONFIG_FILE_PATH = RESOURCE_PATH+prop.getProperty("SMTP_MAIL_CONFIG_FILE_PATH");
     		FROMEMAILADDRESS = prop.getProperty("FromEmailAddress");
     		
     		SELENIUM_SCRIPT_CLASS_FILE_PATH = Constants.RESOURCE_PATH+prop.getProperty("sumtransactionfilepath");
     		LOG4J_PROPERTIES_FILE = RESOURCE_PATH+prop.getProperty("LOG4J_CONFIG_FILE_PATH");
     		SELENIUM_SCRIPT_PACKAGES = prop.getProperty("seleniumscriptpackages");
     		ACTION_LOG_FILE_FOLDER = RESOURCE_PATH+prop.getProperty("ACTION_LOG_FILE_FOLDER");
    		SHELL_FILE_PATH = RESOURCE_PATH+prop.getProperty("SHELL_FILE_PATH");
    		PEM_FILE_PATH = RESOURCE_PATH+prop.getProperty("PEM_FILE_PATH");
    		ELK_DOWNLOAD_URI =  prop.getProperty("ELK_DOWNLOAD_URI");
    		
        } catch(Throwable th) {
        	System.out.println("Exception in loadConstantsProperties: "+th.getMessage());
			th.printStackTrace();
			LogManager.errorLog(th);
			
        	throw th;
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        }
	}
	
	/**
	 * Loads appedo config properties, from the system specifed path, 
	 * (Note.. loads other than db related)
	 *  
	 * @param strAppedoConfigPath
	 */
	public static void loadAppedoConfigProperties(String strAppedoConfigPath) throws Exception {
    	Properties prop = new Properties();
    	InputStream is = null;
    	JSONObject joAppedoCollector = null;
    	
        try {
    		is = new FileInputStream(strAppedoConfigPath);
    		prop.load(is);
    		
     		// Load Test configuration & LoadGen Agent details
    		FG_CONTROLLER_IP = prop.getProperty("FG_CONTROLLER_IP");
    		FG_CONTROLLER_PORT = prop.getProperty("FG_CONTROLLER_PORT");
    		FG_CONTROLLER_PORT1 = prop.getProperty("FG_CONTROLLER_PORT1");
    		FG_APPLICATION_IP = prop.getProperty("FG_APPLICATION_IP");

     		JM_CONTROLLER_IP = prop.getProperty("JM_CONTROLLER_IP");
     		JM_CONTROLLER_PORT = prop.getProperty("JM_CONTROLLER_PORT");
     		
     		// User's email address verification mail's URL link starter
     		APPEDO_URL = prop.getProperty("APPEDO_URL");
     		
     		// Url to delete har files from har repository
     		HAR_REPOSITORY_URL = prop.getProperty("HAR_REPOSITORY_URL");	
     		
     		// Webservice collector
     		WEBSERVICE_HOST = prop.getProperty("WEBSERVICE_HOST");
			// Webservice collector
     		APPEDO_WPT_SCHEDULER = prop.getProperty("APPEDO_WPT_SCHEDULER");
     		APPEDO_SCHEDULER = prop.getProperty("APPEDO_SCHEDULER");
     		APPEDO_HARFILES = prop.getProperty("APPEDO_HARFILES");
     		CLASS_EXPORT_URL = prop.getProperty("URL_TO_EXPORT_CLASS_FILE");
     		APPEDO_COLLECTOR = prop.getProperty("APPEDO_COLLECTOR");
     		APPEDO_SLA_COLLECTOR = prop.getProperty("APPEDO_SLA_COLLECTOR");
     		APPEDO_UI_CREDENTIAL_SERVICES = prop.getProperty("CREDENTIAL_UI_SERVICES");
     		APPEDO_UI_MODULE_SERVICES = prop.getProperty("MODULE_UI_SERVICES");
     		APPEDO_UI_RUM_SERVICES = prop.getProperty("RUM_UI_SERVICES");
     		APPEDO_UI_SUM_SERVICES = prop.getProperty("SUM_UI_SERVICES");
     		APPEDO_UI_LT_SERVICES = prop.getProperty("LT_UI_SERVICES");
     		APPEDO_LT_EXECUTION_SERVICES = prop.getProperty("LT_EXECUTION_SERVICES");
     		APPEDO_UI_SLA_SERVICES = prop.getProperty("SLA_UI_SERVICES");
			WPT_CONTENT_BREAKDOWN = prop.getProperty("WPT_CONTENT_BREAKDOWN");     		

			JM_CONTROLLER_IP = prop.getProperty("JM_CONTROLLER_IP");
			JM_CONTROLLER_PORT = prop.getProperty("JM_CONTROLLER_PORT");
			LT_QUEUE_IP = prop.getProperty("LT_QUEUE_IP");
			LT_QUEUE_PORT = prop.getProperty("LT_QUEUE_PORT");
			LT_QUEUE_SERVICES = prop.getProperty("LT_QUEUE_SERVICES");
     		
			IS_CAPTCHA_VALIDATION_ENABLE = Boolean.parseBoolean( UtilsFactory.replaceNull(prop.getProperty("IS_CAPTCHA_VALIDATION_ENABLE"), "true") );
     		
     		
     		// UI-Service applications
     		RUM_UI_SERVICE_APPLICATION_NAME = prop.getProperty("RUM_UI_SERVICE_APPLICATION_NAME");
     		SLA_UI_SERVICE_APPLICATION_NAME = prop.getProperty("SLA_UI_SERVICE_APPLICATION_NAME");
     		
     		
     		MONITOR_COLLECTOR = JSONObject.fromObject(prop.getProperty("MONITOR_COLLECTOR"));
     		RUM_COLLECTOR = JSONObject.fromObject(prop.getProperty("RUM_COLLECTOR"));
     		CI_COLLECTOR = JSONObject.fromObject(prop.getProperty("CI_COLLECTOR"));

     		SELENIUM_SCRIPT_PACKAGES = prop.getProperty("SELENIUM_SCRIPT_PACKAGES");
     		SELENIUM_SCRIPT = prop.getProperty("SELENIUM_SCRIPT");
     		HTTPS_CRT_NAME = prop.getProperty("HTTPS_CRT_NAME");

     		SUM_WARNING_LIMIT = Integer.parseInt(prop.getProperty("SUM_WARNING_LIMIT")==null?"10":prop.getProperty("SUM_WARNING_LIMIT"));
     		SUM_ERROR_LIMIT = Integer.parseInt(prop.getProperty("SUM_ERROR_LIMIT")==null?"40":prop.getProperty("SUM_ERROR_LIMIT"));
     		SUM_DOWNLOAD_LIMIT = Integer.parseInt(prop.getProperty("SUM_DOWNLOAD_LIMIT")==null?"30720":prop.getProperty("SUM_DOWNLOAD_LIMIT"));
     		SUM_UPLOAD_LIMIT = Integer.parseInt(prop.getProperty("SUM_UPLOAD_LIMIT")==null?"30720":prop.getProperty("SUM_UPLOAD_LIMIT"));
     		SUM_LATENCY_LIMIT = Integer.parseInt(prop.getProperty("SUM_LATENCY_LIMIT")==null?"30720":prop.getProperty("SUM_LATENCY_LIMIT"));
     		SUM_PACKET_LOSS_LIMIT = Integer.parseInt(prop.getProperty("SUM_PACKET_LOSS_LIMIT")==null?"30720":prop.getProperty("SUM_PACKET_LOSS_LIMIT"));
     		SUM_DEFAULT_WARNING_LIMIT= Integer.parseInt(prop.getProperty("SUM_DEFAULT_WARNING_LIMIT")==null?"5":prop.getProperty("SUM_DEFAULT_WARNING_LIMIT"));
     		SUM_DEFAULT_ERROR_LIMIT = Integer.parseInt(prop.getProperty("SUM_DEFAULT_ERROR_LIMIT")==null?"20":prop.getProperty("SUM_DEFAULT_ERROR_LIMIT"));
     		SUM_DEFAULT_MIN_BREACH_COUNT = Integer.parseInt(prop.getProperty("SUM_DEFAULT_MIN_BREACH_COUNT")==null?"1":prop.getProperty("SUM_DEFAULT_MIN_BREACH_COUNT"));
     		
     		WPT_APPEDO_REDIRECTOR = JSONArray.fromObject(prop.getProperty("WPT_APPEDO_REDIRECTOR"));
     		
     		UPLOAD_URL = prop.getProperty("UPLOAD_URL");

     		SLAVE_CONNECTION_PRIMARY_PORT = prop.getProperty("SLAVE_CONNECTION_PRIMARY_PORT");
     		SLAVE_CONNECTION_SECONDARY_PORT = prop.getProperty("SLAVE_CONNECTION_SECONDARY_PORT");
     		
     		SLOW_QRY_LIMIT = Integer.valueOf(prop.getProperty("SLOW_QRY_LIMIT"));
     		TOP_PROCESS_LIMIT = Integer.valueOf(prop.getProperty("TOP_PROCESS_LIMIT")==null?"3":prop.getProperty("TOP_PROCESS_LIMIT"));
     		
     		PROFILER_STACK_METHOD_CALL_LEVEL = Integer.valueOf(prop.getProperty("PROFILER_STACK_METHOD_CALL_LEVEL"));
     		
     		SLA_AUTOGEN_MIN_BREACH_COUNT = prop.getProperty("SLA_AUTOGEN_MIN_BREACH_COUNT");
     		
			LOADTESTSAMPLEDURATION = Integer.parseInt(prop.getProperty("LOADTESTSAMPLEDURATION")==null?"3":prop.getProperty("LOADTESTSAMPLEDURATION"));
			LT_COUNT_RESULT_LIMIT = Long.parseLong(prop.getProperty("LT_COUNT_RESULT_LIMIT")==null?"1000000":prop.getProperty("LT_COUNT_RESULT_LIMIT"));
			LT_BATCH_EPOCH_VALUE = Long.parseLong(prop.getProperty("LT_BATCH_EPOCH_VALUE")==null?"1000":prop.getProperty("LT_BATCH_EPOCH_VALUE"));
			LT_RUNTIME_CHECK_HOUR = Integer.parseInt(prop.getProperty("LT_RUNTIME_CHECK_HOUR")==null?"3":prop.getProperty("LT_RUNTIME_CHECK_HOUR"));
			LT_RUNTIME_CHECK_MINUTE = Integer.parseInt(prop.getProperty("LT_RUNTIME_CHECK_MINUTE")==null?"1":prop.getProperty("LT_RUNTIME_CHECK_MINUTE"));
			APPEDO_URL_FILE_TRANSFER = prop.getProperty("APPEDO_URL_FILE_TRANSFER");
			LOADTESTRUNCHARTQUERYDURATION = prop.getProperty("LOADTESTRUNCHARTQUERYDURATION")==null?"15 Mins":prop.getProperty("LOADTESTRUNCHARTQUERYDURATION");
			
     		// used the default parallel connections value
     		DEFAULT_PARALLEL_CONNECTIONS = prop.getProperty("DEFAULT_PARALLEL_CONNECTIONS");
     		
     		//Appedo Log ui Service
     		ELK_DOWNLOAD_PATH =prop.getProperty("APPEDO_URL")+ELK_DOWNLOAD_URI;
     		EMAIL_TO_ALERT_FOR_LOG_VIEW = prop.getProperty("EMAIL_TO_ALERT_FOR_LOG_VIEW");
     		// for default SLA settings for the user
     		SLA_SETTING_MAX_TRY_COUNT = Integer.parseInt( prop.getProperty("SLA_SETTING_MAX_TRY_COUNT") );
     		SLA_SETTING_TRY_COUNT_DURATION_IN_MIN = Integer.parseInt( prop.getProperty("SLA_SETTING_TRY_COUNT_DURATION_IN_MIN") );
     		SLA_SETTING_TRIGGER_ALERT_EVERY_IN_MIN = Integer.parseInt( prop.getProperty("SLA_SETTING_TRIGGER_ALERT_EVERY_IN_MIN") );
        } catch(Exception e) {
        	LogManager.errorLog(e);
        	throw e;
        } finally {
        	UtilsFactory.close(is);
        	is = null;
        	
        	UtilsFactory.clearCollectionHieracy(joAppedoCollector);
        	joAppedoCollector = null;
        }	
	}
	
	/**
	 * Collector in JSON format return as URL
	 * 
	 * @param joAppedoCollector
	 * @return
	 */
	public static String getAsURL(JSONObject joAppedoCollector) {
		return joAppedoCollector.getString("protocol") +"://"+ joAppedoCollector.getString("server") + 
				( joAppedoCollector.getString("port").length() > 0 ? ":"+joAppedoCollector.getString("port") : "" ) + 
				"/"+ joAppedoCollector.getString("application_name");
	}
	
	/**
	 * loads AppedoConstants, 
	 *   of loads Appedo whitelabels, replacement of word `Appedo` as configured in DB
	 *   
	 * @param strAppedoConfigPath
	 * @throws Exception
	 */
	public static void loadAppedoWhiteLabels(String strAppedoConfigPath) throws Exception {
		
		try {
			AppedoConstants.getAppedoConstants().loadAppedoConstants(strAppedoConfigPath);
		} catch (Exception e) {
			throw e;
		}
	}
	
	//LT Configuration
	public static String getLTStausStringForCompletedRuns() {
		
		StringBuilder statusBuild = new StringBuilder();
		statusBuild.append("'"+Constants.MANUAL_REPORT_GENERATION_COMPLETED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.MANUAL_REPORT_GENERATION_FAILED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.MANUAL_REPORT_GENERATION_STARTED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.MANUAL_REPORT_PREPARATION_STARTED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.AUTO_REPORT_GENERATION_COMPLETED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.AUTO_REPORT_GENERATION_FAILED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.AUTO_REPORT_GENERATION_STARTED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.AUTO_REPORT_PREPARATION_STARTED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.COMPLETED+"'");
		statusBuild.append(",");
		statusBuild.append("'"+Constants.REPORT_GENERATION_STARTED+"'");
		
		return statusBuild.toString();
	}
	
	public static void loadELKID() throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		StringBuilder sbQuery = new StringBuilder();
		try {
			con = DataBaseManager.giveConnection();
			sbQuery.append("SELECT * FROM elk_namelist");
			pstmt = con.prepareStatement(sbQuery.toString());
			rst = pstmt.executeQuery();
			while (rst.next()) {
				ELK_ID_VS_NAME.put(rst.getLong("elk_name_id"), rst.getString("elk_name"));
			}
			System.out.println("ELK_ID_VS_NAME" + ELK_ID_VS_NAME);
		} catch (Exception e) {
			LogManager.errorLog(e);
		} finally {
			DataBaseManager.close(rst);
			rst = null;
			DataBaseManager.close(pstmt);
			pstmt = null;
			sbQuery = null;
			DataBaseManager.close(con);
			con = null;
		}

	}
}
