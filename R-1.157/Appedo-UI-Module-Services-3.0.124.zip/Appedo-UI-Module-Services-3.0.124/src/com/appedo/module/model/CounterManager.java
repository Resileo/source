package com.appedo.module.model;

import java.sql.Connection;

import net.sf.json.JSONArray;

import com.appedo.manager.LogManager;
import com.appedo.module.dbi.CounterDBI;

public class CounterManager {

	/**
	 * Getting application categories
	 * 
	 * @param con
	 * @param nApplicationID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCategory(Connection con, int nID) throws Exception {
		
		CounterDBI counterDBI = null;
		JSONArray jaAPCategory = null;
		try {
			counterDBI = new CounterDBI();
			jaAPCategory = counterDBI.getCategory(con,  nID);
			counterDBI = null;	
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaAPCategory;
	}
	/**
	 * Getting application counters
	 * 
	 * @param con
	 * @param nApplicationId
	 * @param strCategory
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCounters(Connection con, long nId) throws Exception {
		CounterDBI counterDBI = null;
		JSONArray jaAPPCounters = null;
		try {
			counterDBI = new CounterDBI();
			jaAPPCounters = counterDBI.getCounters(con, nId);
			counterDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return jaAPPCounters;
	}
	/**
	 * Updating application counters
	 * 
	 * @param con
	 * @param strApplicationCounters
	 * @param nApplicationId
	 * @return
	 * @throws Exception
	 */
	/*public void updateCounters(Connection con, String strCounterIds, long lUId, LoginUserBean loginUserBean) throws Exception {
		CounterDBI counterDBI = null;
		//JSONArray jaDatabaseCounters = JSONArray.fromObject(strCounters);
		
		try {
			counterDBI = new CounterDBI();
			/*for(int i = 0; i < jaModuleCounters.size(); i++ ){
				JSONObject joCounter =  jaModuleCounters.getJSONObject(i);
				counterDBI.updateCounters(con,  nId, joCounter);
				joCounter = null;
			}* /
			
			counterDBI.updateCounters(con, strCounterIds, lUId, loginUserBean);
			
			counterDBI = null;
			//jaModuleCounters = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}*/
	
	public JSONArray getCounterVersions(Connection con, String strModuleType) throws Exception {
		
		CounterDBI counterDBI = null;
		JSONArray jaCounterVesrions = null;
		try{
			counterDBI = new CounterDBI();
			jaCounterVesrions = counterDBI.getCounterVersions(con, strModuleType);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			counterDBI = null;
		}
		return jaCounterVesrions;
	}
	
	public JSONArray getSelectedCounters(Connection con, long lUId) throws Exception {
		CounterDBI counterDBI = null;
		JSONArray jaCounters = null;
		
		try{
			counterDBI = new CounterDBI();
			jaCounters = counterDBI.getSelectedCounters(con, lUId);
		}catch(Exception e) {
			throw e;
		}finally{
			counterDBI = null;
		}
		return jaCounters;
	}
}
