package com.appedo.module.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.dbi.ChartDBI;
import com.appedo.module.dbi.ModuleCounterDBI;
import com.appedo.module.dbi.ModuleDBI;
import com.appedo.module.dbi.SLADBI;
import com.appedo.module.utils.UtilsFactory;

public class ModuleCounterManager {

	public JSONObject getModuleCountersChartData_v1(Connection con, long lUserId, String strGUID, String strCounters, Long lMaxTimeStamp, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, Boolean isAboveThreshold, boolean bStaticCounter, String strMaxValueCounterId, String query, String defaultYAxisKey) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		SLADBI slaDBI = null;
		
		JSONObject joRtnCountersData = null, joBreachedThresholdLimits = null, joStaticCountersData = null;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			slaDBI = new SLADBI();
			
			//if ( ! bStaticCounter ) {
				// gets chart data
				
				joRtnCountersData = moduleCounterDBI.getModuleCountersChartData_v1(con, strGUID, strCounters, strFromStartInterval, lStartDateTime, lEndDateTime, isAboveThreshold, query, defaultYAxisKey);
				
				//joBreachedThresholdLimits = slaDBI.getCounterBreachedThresholdLimits(con, lUserId, strGUID, strCounters, strFromStartInterval, lStartDateTime, lEndDateTime);
				//joRtnCountersData.put("sla_threshold_limits", joBreachedThresholdLimits);
			//	/
				// gets static counter data
			//	if ( strMaxValueCounterId != null ) {
					// gets static counter data, with counter master details 
			//		joStaticCountersData = getModuleStaticCountersData(con, strGUID, strMaxValueCounterId, lUserId, true);
					
			//		joRtnCountersData.put("static_counter_data", joStaticCountersData.getJSONObject("chartdata").getJSONObject(strMaxValueCounterId));
			//	}
			//} else {
				// gets static counter data
		//		joStaticCountersData = getModuleStaticCountersData(con, strGUID,  strCounters, lUserId, false);
			//	joRtnCountersData = joStaticCountersData;
		//	}
			
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnCountersData;
	}
	
	public JSONObject getModuleCountersChartData_v2(Connection con, long lUserId, long lUID, String strCounters, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, Long metricId, String xyLabel) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		ChartDBI chartDBI = null;
		JSONObject joRtnCountersData = null;
		
		String chartQuery = null;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			chartDBI = new ChartDBI();
			if (metricId == null) {
				throw new Exception("1");
			}
			chartQuery = chartDBI.getChartDataQuery(con, lUserId, metricId);			
			joRtnCountersData = moduleCounterDBI.getModuleCountersChartData_v2(con, lUID, strCounters, strFromStartInterval, lStartDateTime, lEndDateTime, chartQuery, xyLabel);
				
			moduleCounterDBI = null;
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnCountersData;
	}
	
	// To get LOG's chart data
	public JSONObject getLOGModuleCountersChartData_v1(Connection con, long lUserId, Long lUID, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, String query) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		JSONObject joRtnCountersData = null;
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			joRtnCountersData = moduleCounterDBI.getLOGModuleCountersChartData_v1(con, lUID, strFromStartInterval, lStartDateTime, lEndDateTime, query);
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
		return joRtnCountersData;
	}
	
	public JSONObject getLOGModuleCountersChartData_v2(Connection con, long lUserId, Long lUID, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, Long lMetricId, String xyLabel) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		ChartDBI chartDBI = null;
		JSONObject joRtnCountersData = null;
		String chartQuery = null;
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			chartDBI = new ChartDBI();
			
			if (lMetricId == null) {
				throw new Exception("1");
			}
			//long startTime = System.currentTimeMillis();
			chartQuery = chartDBI.getChartDataQuery(con, lUserId, lMetricId);
			//System.out.println("to Get chart query : "+ (System.currentTimeMillis()-startTime));
			joRtnCountersData = moduleCounterDBI.getLOGModuleCountersChartData_v2(con, lUID, strFromStartInterval, lStartDateTime, lEndDateTime, chartQuery, xyLabel);
			
			chartDBI = null;
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
		return joRtnCountersData;
	}
	
	public JSONObject getLOGTypes(Connection con, long lUserId, Long lUID) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		JSONObject joRtnCountersData = null;
		JSONArray jaReturnData = null;
		try {
			joRtnCountersData = new JSONObject();
			moduleCounterDBI = new ModuleCounterDBI();
			jaReturnData = moduleCounterDBI.getLOGTypes(con, lUID);
			joRtnCountersData.put("logType", jaReturnData);
			//joRtnCountersData.put("osName", jaReturnData.get(0).get("osName"));
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
		return joRtnCountersData;
	}
	
	public JSONArray getLogsData(Connection con, long lUserId, Long lUID, String strSearchText, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, String logName, String logTableName, String logLevel ) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		JSONArray jaReturnData = null;
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			if (logName.equals("TOMCAT_CATALINA")) {
				jaReturnData = moduleCounterDBI.getTomcatCatalinaLog(con, lUID, strSearchText, strFromStartInterval, lStartDateTime, lEndDateTime, logTableName, logLevel);
			} else if(logName.equals("TOMCAT_ACCESS")) {
				jaReturnData = moduleCounterDBI.getTomcatAccessLog(con, lUID, strSearchText, strFromStartInterval, lStartDateTime, lEndDateTime, logTableName, logLevel);
			} else if(logName.equals("LOG4J_ERROR")) {
				jaReturnData = moduleCounterDBI.getLOG4JErrorLog(con, lUID, strSearchText, strFromStartInterval, lStartDateTime, lEndDateTime, logTableName, logLevel);
			} else if(logName.equals("LINUX_SYSLOG")) {
				jaReturnData = moduleCounterDBI.getLinuxSysLog(con, lUID, strSearchText, strFromStartInterval, lStartDateTime, lEndDateTime, logTableName, logLevel);
			} else {
				jaReturnData = moduleCounterDBI.getGenericLog(con, lUID, strSearchText, strFromStartInterval, lStartDateTime, lEndDateTime, logTableName, logLevel);
			}
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
		return jaReturnData;
	}
	
	
	public JSONObject getModuleCountersChartData(Connection con, long lUserId, String strGUID, String strCounters, Long lMaxTimeStamp, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, boolean isPdf, Boolean isAboveThreshold, boolean bStaticCounter, String strMaxValueCounterId) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		SLADBI slaDBI = null;
		
		JSONObject joRtnCountersData = null, joBreachedThresholdLimits = null, joStaticCountersData = null;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			slaDBI = new SLADBI();
			
			if ( ! bStaticCounter ) {
				// gets chart data
				
				joRtnCountersData = moduleCounterDBI.getModuleCountersChartData(con, strGUID, strCounters, lMaxTimeStamp, strFromStartInterval, lStartDateTime, lEndDateTime, isPdf, isAboveThreshold);
				
				joBreachedThresholdLimits = slaDBI.getCounterBreachedThresholdLimits(con, lUserId, strGUID, strCounters, strFromStartInterval, lStartDateTime, lEndDateTime);
				joRtnCountersData.put("sla_threshold_limits", joBreachedThresholdLimits);
				
				// gets static counter data
				if ( strMaxValueCounterId != null ) {
					// gets static counter data, with counter master details 
					joStaticCountersData = getModuleStaticCountersData(con, strGUID, strMaxValueCounterId, lUserId, true);
					
					joRtnCountersData.put("static_counter_data", joStaticCountersData.getJSONObject("chartdata").getJSONObject(strMaxValueCounterId));
				}
			} else {
				// gets static counter data
				joStaticCountersData = getModuleStaticCountersData(con, strGUID,  strCounters, lUserId, false);
				joRtnCountersData = joStaticCountersData;
			}
			
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnCountersData;
	}
	
	/**
	 * gets static counter(s) data,
	 *   if `bHaveCounterMasterDetails` is true gets counter data with counter master details
	 *   
	 * @param con
	 * @param strGUID
	 * @param strCounters
	 * @param lUserId
	 * @param bHaveCounterMasterDetails
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModuleStaticCountersData(Connection con, String strGUID, String strCounters, long lUserId, boolean bHaveCounterMasterDetails) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		
		JSONObject joRtnStaticCounterData = null;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			
			joRtnStaticCounterData = moduleCounterDBI.getModuleStaticCountersData(con, strGUID, strCounters, bHaveCounterMasterDetails);
			
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnStaticCounterData;
	}
	
	/**
	 * Paramterized method to sort Map e.g. HashMap or Hashtable in Java throw
	 * NullPointerException if Map contains null key
	 * 
	 * @param <K>
	 * @param <V>
	 * @param map
	 * @return
	 */
	public static <K extends Comparable, V extends Comparable> Map<K, V> sortByKeys(
			Map<K, V> map) {
		List<K> keys = new LinkedList<K>(map.keySet());
		Collections.sort(keys);

		// LinkedHashMap will keep the keys in the order they are inserted
		// which is currently sorted on natural ordering
		Map<K, V> sortedMap = new LinkedHashMap<K, V>();
		for (K key : keys) {
			sortedMap.put(key, map.get(key));
		}

		return sortedMap;
	}

	/**
	 * Gets request transactions done in the application 
	 * 
	 * @param con
	 * @param strGUID
	 * @param profilerTrans 
	 * @return
	 * @throws Exception
	 */
	public JSONArray getProfilerTransactionTree(Connection con, String strGUID, String strCounterTypeName, String strFromStartInterval, boolean profilerTrans) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		JSONArray jaTransactions = null;
		
		try {
			modulesDBI = new ModuleCounterDBI();

			jaTransactions = modulesDBI.getProfilerTransactionTree(con, strGUID, strCounterTypeName, strFromStartInterval, profilerTrans);
			
			modulesDBI = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
		
		return jaTransactions;
	}
	
	public JSONArray getProfilerTransactionsWithDateRange(Connection con, String strGUID, String strCounterTypeName, String strFromStartInterval, String strToInterval, boolean profilerTrans) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		JSONArray jaTransactions = null;
		
		try {
			modulesDBI = new ModuleCounterDBI();

			jaTransactions = modulesDBI.getProfilerTransactionsWithDateRange(con, strGUID, strCounterTypeName, strFromStartInterval, strToInterval, profilerTrans);
			
			modulesDBI = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
		
		return jaTransactions;
	}

	/**
	 * Gets the selected transaction time taken
	 * 
	 * @param con
	 * @param strGUID
	 * @param strLocalhostNameIP
	 * @param strTransactionName
	 * @return
	 * @throws Exception
	 */
	public ArrayList getProfilerTransactionTimeTaken(Connection con, String strTransactionType, String strGUID, String strLocalhostNameIP, String strTransactionName, String strCounterTypeName, String strFromStartInterval) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		ArrayList alTransactions = null;

		try {
			modulesDBI = new ModuleCounterDBI();

			// jaTransactions =
			// tomcatCounterDBI.getProfilerTransactionTimeTaken(con, strGUID,
			// strTransactionName);
			alTransactions = modulesDBI.getProfilerTransactionTimeTaken(con, strTransactionType, strGUID, strLocalhostNameIP, strTransactionName, strCounterTypeName, strFromStartInterval);

			modulesDBI = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}

		// return jaTransactions;
		return alTransactions;
	}
	
	public ArrayList getProfilerTransactionTimeTakenWithDateRange(Connection con, String strGUID, String strLocalhostNameIP, String strTransactionType, String strTransactionName, String strCounterTypeName, String strFromStartInterval, String strToInterval) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		ArrayList alTransactions = null;

		try {
			modulesDBI = new ModuleCounterDBI();

			// jaTransactions =
			// tomcatCounterDBI.getProfilerTransactionTimeTaken(con, strGUID,
			// strTransactionName);
			alTransactions = modulesDBI.getProfilerTransactionTimeTakenWithDateRange(con, strGUID, strLocalhostNameIP, strTransactionType, strTransactionName, strCounterTypeName, strFromStartInterval, strToInterval);

			modulesDBI = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}

		// return jaTransactions;
		return alTransactions;
	}

	/*
	 * public JSONArray getProfilerTransactionTimeTaken(Connection con, String
	 * strGUID, String strTransactionName) throws Exception { TomcatCounterDBI
	 * tomcatCounterDBI = null;
	 * 
	 * JSONArray jaTransactions = null; ArrayList alTransactions = null;
	 * 
	 * try{ tomcatCounterDBI = new TomcatCounterDBI();
	 * 
	 * jaTransactions = tomcatCounterDBI.getProfilerTransactionTimeTaken(con,
	 * strGUID, strTransactionName); //alTransactions =
	 * tomcatCounterDBI.getProfilerTransactionTimeTaken(con, strGUID,
	 * strTransactionName);
	 * 
	 * } catch(Exception ex) {
	 * System.out.println("Exception in getProfilerTransactionTimeTaken: "
	 * +ex.getMessage()); throw ex; }
	 * 
	 * return jaTransactions; //return alTransactions; }
	 */
	
	/**
	 * Gets method trace for the time taken transaction
	 *  
	 * @param con
	 * @param strGUID
	 * @param strLocalNameIP
	 * @param strTransactionName
	 * @param strTimeStamp
	 * @param strDuration
	 * @return
	 * @throws Exception
	 */
	public ArrayList<LinkedHashMap<String, Object>> getProfilerMethodsTrace(Connection con, String strGUID, String strLocalNameIP, String strTransactionType, String strTransactionName, String strTimeStamp, String strDuration, String strCounterTypeName) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		ArrayList<LinkedHashMap<String, Object>> jaTransactions = null;

		try {
			modulesDBI = new ModuleCounterDBI();
			
			jaTransactions = modulesDBI.getProfilerMethodsTrace(con, strGUID, strLocalNameIP, strTransactionType, strTransactionName, strTimeStamp, strDuration, strCounterTypeName);

			modulesDBI = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}

		return jaTransactions;
	}

	/**
	 * Gets most expensive queries
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getExpensiveQueries(Connection con, String strGUID, String strFromStartInterval) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		JSONArray jaExpensiveQueries = null;

		try {
			modulesDBI = new ModuleCounterDBI();

			jaExpensiveQueries = modulesDBI.getExpensiveQueries(con, strGUID, strFromStartInterval);

			modulesDBI = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}

		return jaExpensiveQueries;
	}

	/**
	 * Gets dashboard data for the application
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public JSONObject getDashboardData(Connection con, String strGUID) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		JSONObject joDashboardData = new JSONObject(), joAvgRequestAndResponse = null, joWidget = null;

		try {
			modulesDBI = new ModuleCounterDBI();

			// Gets average requests
			joAvgRequestAndResponse = modulesDBI.getDashboardAvgRequestAndResponse(con, strGUID);

			// Gets average response
			joWidget = modulesDBI.getDashboardWidget(con, strGUID);

			joDashboardData.put("avgRequestAndResponse", joAvgRequestAndResponse);
			joDashboardData.put("widget", joWidget);
			
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);

			throw e;
		}

		return joDashboardData;
	}
	
	/**
	 * Returns the UID for the given GUID.
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSelectedCounterSummary(Connection con, String strGUID, String strAgentVersion) throws Exception {
		JSONArray jaCounterSummaries = new JSONArray();
		Long lUID = null;
		ModuleCounterDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleCounterDBI();
			lUID = modulesDBI.getUID(con, strGUID);
			
			if( lUID != null ){
				jaCounterSummaries = modulesDBI.getSelectedCounterSummary(con, lUID, strAgentVersion);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			modulesDBI = null;
		}
		
		return jaCounterSummaries;
	}
	
	/**
	 * gets counter ids for the given template ids from counter_master_<uid>
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounterTemplateIds
	 * @return
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getMiniChartCounterIds(Connection con, String strGUID, String strCounterTemplateIds) throws Exception {
		ModuleCounterDBI modulesDBI = null;
		
		LinkedHashMap<String, String> lhmRtnCounters = null;
		
		//COUNTER_TYPE_MINI_CHARTS counter_type_mini_charts = null;
		
		try {
			modulesDBI = new ModuleCounterDBI();
			
			/*// gets minichart counter names
			counter_type_mini_charts = COUNTER_TYPE_MINI_CHARTS.valueOf(strCounterType);
			strCounterNames = counter_type_mini_charts.getCounterNames();
			*/
			
			//strCounterIds = counterDBI.getCounterIds(con, lUID, strGUID, strCounterNames);
			lhmRtnCounters = modulesDBI.getCounterIds(con, strGUID, strCounterTemplateIds);
			
			modulesDBI = null;
		} catch (Exception e) {
			System.out.println("Exception in getMiniChartCounterIds: "+e.getMessage());
			throw e;
		}

		return lhmRtnCounters;
		//return strCounterIds;
	}
	

	/**
	 * gets minichart data, 
	 * the minichart data are sets ArrayList as its available order configured in database, 
	 *  say templateids 203(Active Session), 202(Request Count) and in ui also same order in database used
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounters
	 * @param lMaxTimeStamp
	 * @param strCounterTemplateIds
	 * @param lhmMapTemplateCounters
	 * @param bMiniChartRequest
	 * @return
	 * @throws Exception
	 * 
	 * NOT IN USE
	@SuppressWarnings("null")
	public JSONObject getMinichartCounters(Connection con, String strGUID, String strCounters, Long lMaxTimeStamp, String strCounterTemplateIds, LinkedHashMap<String, String> lhmMapTemplateCounters, boolean bMiniChartRequest) throws Exception {
		JSONObject joMiniChartCounters = null;
		JSONObject joCountersChartData = null;

		String[] saCounterTemplateIds = null;

		String strCounterTemplateId = "", strRtnCounterId = "";

		ArrayList alCountersChartData = new ArrayList();
		
		try {
			Long lStartDateTime = null, lEndDateTime = null;
			// gets chart data for minichart, interval is set to null
			joMiniChartCounters = getModuleCountersChartData(con, strGUID, strCounters, lMaxTimeStamp, "", lStartDateTime, lEndDateTime,  false, null);
			
			// adds the data to AL as its available order in DB, say templateids in 203,202. 
			joCountersChartData = (JSONObject) joMiniChartCounters.get("chartdata");
			saCounterTemplateIds = strCounterTemplateIds.split(",");
			for(int idx = 0; idx < saCounterTemplateIds.length; idx = idx + 1) {
				strCounterTemplateId = saCounterTemplateIds[idx].trim();
				strRtnCounterId = lhmMapTemplateCounters.get(strCounterTemplateId);
				if( strRtnCounterId != null ) {
					alCountersChartData.add( joCountersChartData.get(strRtnCounterId) );	
				} else {
					alCountersChartData.add(null);
				}
			}
			joMiniChartCounters.put("minichartdata", alCountersChartData);
			joMiniChartCounters.remove("chartdata");
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			saCounterTemplateIds = null;
			strCounterTemplateId = null;
			strRtnCounterId = null;
		}
		
		return joMiniChartCounters;
	} */
	
	/**
	 * gets primary counters data to show in dashboard
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public JSONObject getPrimaryCountersChartdata(Connection con, String strGUID) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmtPrimaryCounters = null;
		ResultSet rstPrimaryCounters = null;
		
		ModuleCounterDBI moduleCounterDBI = null;
		ModuleDBI moduleDBI = null;
		
		JSONArray jaPrimaryCountersChartdata = null;
		JSONObject joPrimaryCounterChartdata = null, joResult = new JSONObject();
		
		// interval is harcoded since last 1 hour data only to show
		String strFromStartInterval = "1 hour", strCounterId = "";
		
		long lUID = -1;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			moduleDBI = new ModuleDBI();
			
			jaPrimaryCountersChartdata = new JSONArray();
			
			lUID = moduleDBI.getUID(con, strGUID);

			stmtPrimaryCounters = con.createStatement();
			rstPrimaryCounters = moduleCounterDBI.getPrimaryCounters(stmtPrimaryCounters, lUID);
			while( rstPrimaryCounters.next() ) {
				joPrimaryCounterChartdata = new JSONObject();
				
				strCounterId = rstPrimaryCounters.getString("counter_id");
				
				joPrimaryCounterChartdata.put("counterId", strCounterId);
				joPrimaryCounterChartdata.put("category", rstPrimaryCounters.getString("category"));
				joPrimaryCounterChartdata.put("counterName", rstPrimaryCounters.getString("counter_name"));
				joPrimaryCounterChartdata.put("counter", rstPrimaryCounters.getString("counter_name").replaceAll("[!@#$%^&*]", ""));
				joPrimaryCounterChartdata.put("label", rstPrimaryCounters.getString("display_name"));
				joPrimaryCounterChartdata.put("unit", rstPrimaryCounters.getString("unit"));
				joPrimaryCounterChartdata.put("show_in_dashboard", rstPrimaryCounters.getBoolean("show_in_dashboard"));
				joPrimaryCounterChartdata.put("slaIdForAnalytics", rstPrimaryCounters.getLong("threshold_sla_id"));
				joPrimaryCounterChartdata.put("counter_description", rstPrimaryCounters.getString("counter_description"));
				joPrimaryCounterChartdata.put("is_above_threshold", rstPrimaryCounters.getBoolean("is_above_threshold"));
				
				// gets and sets counter's chart data sets into `joPrimaryCounterChartdata`
				getAndSetCounterChartDataInPrimaryCounter(con, strGUID, strCounterId, strFromStartInterval, joPrimaryCounterChartdata);
				
				jaPrimaryCountersChartdata.add(joPrimaryCounterChartdata);
			}
			joResult.put("guid", strGUID);
			joResult.put("chartdata", jaPrimaryCountersChartdata);
			
			moduleCounterDBI = null;
			moduleDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rstPrimaryCounters);
			rstPrimaryCounters = null;
			DataBaseManager.close(stmtPrimaryCounters);
			stmtPrimaryCounters = null;
			
			strCounterId = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		
		return joResult;
	}
	
	/**
	 * gets guid's counters data which has show in dashboard, which is shown in dashboard chart details page
	 * 
	 * @param con
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getPrimaryCountersForAllDetailsPage(Connection con, String strGUID, boolean bShowPrimaryCounters) throws Exception {
		Statement stmtPrimaryCounters = null;
		ResultSet rstPrimaryCounters = null;
		
		ModuleCounterDBI moduleCounterDBI = null;
		ModuleDBI moduleDBI = null;
		
		JSONArray jaDashboardCountersData = null;
		JSONObject jaDashboardCounterDetails = null, joRtnCounterData = null;
		
		// interval is harcoded since last 1 hour data only to show
		String strFromStartInterval = "1 hour", title = null;

		long lUID = -1;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			moduleDBI = new ModuleDBI();
			
			jaDashboardCountersData = new JSONArray();
			
			lUID = moduleDBI.getUID(con, strGUID);
			title = moduleDBI.getModuleName(con, strGUID);
			
			stmtPrimaryCounters = con.createStatement();
			rstPrimaryCounters = moduleCounterDBI.getPrimaryCountersForAllDetailsPage(stmtPrimaryCounters, lUID, bShowPrimaryCounters);
			while( rstPrimaryCounters.next() ) {
				jaDashboardCounterDetails = new JSONObject();
				jaDashboardCounterDetails.put("counter_id", rstPrimaryCounters.getString("counter_id"));
				jaDashboardCounterDetails.put("category", rstPrimaryCounters.getString("category"));
				jaDashboardCounterDetails.put("counterName", rstPrimaryCounters.getString("counter_name"));
				jaDashboardCounterDetails.put("display_name", rstPrimaryCounters.getString("display_name"));
				jaDashboardCounterDetails.put("counter", rstPrimaryCounters.getString("counter_name").replaceAll("[!@#$%^&*]", ""));
				jaDashboardCounterDetails.put("unit", rstPrimaryCounters.getString("unit"));
				jaDashboardCounterDetails.put("show_in_dashboard", rstPrimaryCounters.getBoolean("show_in_dashboard"));
				jaDashboardCounterDetails.put("show_in_primary", rstPrimaryCounters.getBoolean("show_in_primary"));
				jaDashboardCounterDetails.put("counter_description", rstPrimaryCounters.getString("counter_description"));
				jaDashboardCounterDetails.put("is_above_threshold", rstPrimaryCounters.getBoolean("is_above_threshold"));
				jaDashboardCounterDetails.put("title", title);

				Long lStartDateTime = null, lEndDateTime = null;
				// gets counter's chartdata, strMaxTimeStamp given as blank,
				boolean is_above_threshold = jaDashboardCounterDetails.getBoolean("is_above_threshold");
				joRtnCounterData = moduleCounterDBI.getModuleCountersChartData(con, strGUID, rstPrimaryCounters.getString("counter_id"), null, strFromStartInterval, lStartDateTime, lEndDateTime, false, is_above_threshold);
				
				jaDashboardCounterDetails.put("counterData", joRtnCounterData);

				jaDashboardCountersData.add(jaDashboardCounterDetails);
			}
			
			moduleCounterDBI = null;
			moduleDBI = null;
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rstPrimaryCounters);
			rstPrimaryCounters = null;
			DataBaseManager.close(stmtPrimaryCounters);
			stmtPrimaryCounters = null;
		}
		
		return jaDashboardCountersData;
	}

	public long updateChartStausForDashboard(Connection con, String strGUID, String nCounterId, Boolean status) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		
		long lChartId = -1;
		long lUID = -1;
		
		try {
			
			moduleCounterDBI = new ModuleCounterDBI();
			
			lUID = moduleCounterDBI.getUID(con, strGUID);
			
			lChartId = moduleCounterDBI.updateChartStausForDashboard(con,lUID,nCounterId,status);

			moduleCounterDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lChartId;
	}
	
	public JSONObject updateApmKeyTransaction(Connection con,String strGUID,String uri,String keyTransactionId,String keyTransactionName,String keyTransactionDescription,String status,long userId) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		
		long lKeyId = -1;
		long lUID = -1;
		JSONObject joResultString = null;
		JSONObject joRtn = null;
		try {
			
			moduleCounterDBI = new ModuleCounterDBI();
			
			lUID = moduleCounterDBI.getUID(con, strGUID);
			if(status.equalsIgnoreCase("insert")){
				if(!moduleCounterDBI.checkKeyNameWithUserExists(con, keyTransactionName, userId)){
					lKeyId = moduleCounterDBI.createApmKeyTransaction(con, strGUID, lUID, uri, keyTransactionId,keyTransactionName,keyTransactionDescription,userId);
					joResultString = new JSONObject();
					joResultString.put("successMessage", "Successfully added");
					joResultString.put("keyTransactionId", lKeyId);
					joResultString.put("keyTransactionName", keyTransactionName);
					joResultString.put("keyTransactionDescription", keyTransactionDescription);
					joRtn = UtilsFactory.getJSONSuccessReturn(joResultString);
				}else{
					joRtn = UtilsFactory.getJSONFailureReturn("Duplicate Key Name");
				}
			}else if(status.equalsIgnoreCase("delete")){
				lKeyId = moduleCounterDBI.updateApmKeyTransaction(con, keyTransactionId);
				joResultString = new JSONObject();
				joResultString.put("successMessage", "Successfully removed");
				joResultString.put("keyTransactionId", 0);
				joResultString.put("keyTransactionName", "");
				joResultString.put("keyTransactionDescription", "");
				joRtn = UtilsFactory.getJSONSuccessReturn(joResultString);
			}
//			lKeyId = moduleCounterDBI.updateApmKeyTransaction(con, strGUID, lUID, uri, keyTransactionId,keyTransactionName,keyTransactionDescription,status,userId);
			moduleCounterDBI = null;
		} catch(Exception e) {
			joRtn = UtilsFactory.getJSONFailureReturn("Unexpected error occur.");
			LogManager.errorLog(e);
			throw e;
		}
		
		return joRtn;
	}
	
	/**
	 * gets primaryCounters's chartdata and breaches data
	 * 
	 * @param con
	 * @param strGUID
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getPrimaryCountersChartdataWithBreaches(Connection con, String strGUID, long lUserId) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		Statement stmtPrimaryCounters = null;
		ResultSet rstPrimaryCounters = null;
		
		ModuleCounterDBI moduleCounterDBI = null;
		ModuleDBI moduleDBI = null;
		
		JSONArray jaPrimaryCountersChartdata = null;
		JSONObject joPrimaryCounterChartdata = null, joResult = new JSONObject();
		
		// interval is harcoded since last 1 hour data only to show
		String strFromStartInterval = "1 hour", strCounterId = "", strSLAIdForAnalytics = "";

		long lUID = -1;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			moduleDBI = new ModuleDBI();
			
			jaPrimaryCountersChartdata = new JSONArray();
			
			lUID = moduleDBI.getUID(con, strGUID);

			stmtPrimaryCounters = con.createStatement();
			rstPrimaryCounters = moduleCounterDBI.getPrimaryCounters(stmtPrimaryCounters, lUID);
			while( rstPrimaryCounters.next() ) {
				joPrimaryCounterChartdata = new JSONObject();
				
				strCounterId = rstPrimaryCounters.getString("counter_id");
				strSLAIdForAnalytics = rstPrimaryCounters.getString("threshold_sla_id");
				
				joPrimaryCounterChartdata.put("counterId", strCounterId);
				joPrimaryCounterChartdata.put("category", rstPrimaryCounters.getString("category"));
				joPrimaryCounterChartdata.put("counterName", rstPrimaryCounters.getString("counter_name"));
				joPrimaryCounterChartdata.put("label", rstPrimaryCounters.getString("display_name"));
				joPrimaryCounterChartdata.put("unit", rstPrimaryCounters.getString("unit"));
				joPrimaryCounterChartdata.put("show_in_dashboard", rstPrimaryCounters.getBoolean("show_in_dashboard"));
				joPrimaryCounterChartdata.put("slaIdForAnalytics", strSLAIdForAnalytics);
				joPrimaryCounterChartdata.put("counter_description", rstPrimaryCounters.getString("counter_description"));

				// gets and sets counter's chart data sets into `joPrimaryCounterChartdata`
				getAndSetCounterChartDataInPrimaryCounter(con, strGUID, strCounterId, strFromStartInterval, joPrimaryCounterChartdata);
				
				/*
				 * TODO: handle in a different way to show breach line, 
				 *  commented breach lines shown, since UI for a counter shown as breach but doesn't breach
				// gets and sets counter's breaches data sets into `joPrimaryCounterChartdata`
				getAndSetCounterBreachesInPrimaryCounter(con, strGUID, strSLAIdForAnalytics, strCounterId, lUserId, joPrimaryCounterChartdata);
				*/
				jaPrimaryCountersChartdata.add(joPrimaryCounterChartdata);
			}
			joResult.put("guid", strGUID);
			joResult.put("chartdata", jaPrimaryCountersChartdata);
			
			moduleCounterDBI = null;
			moduleDBI = null;
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rstPrimaryCounters);
			rstPrimaryCounters = null;
			DataBaseManager.close(stmtPrimaryCounters);
			stmtPrimaryCounters = null;
			
			strCounterId = null;
			
		    LogManager.logMethodEnd(dateLog);
		}
		
		return joResult;
	}

	/**
	 * gets counter's chart data and sets into `joPrimaryCounterChartdata`
	 *   DON'T use (joPrimaryCounterChartdata = null OR joPrimaryCounterChartdata = new JSONObject())   
	 * Note: strMaxTimeStamp is sets null
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounterId
	 * @param strFromStartInterval
	 * @param joPrimaryCounterChartdata
	 * @throws Exception
	 */
	public void getAndSetCounterChartDataInPrimaryCounter(Connection con, String strGUID, String strCounterId, String strFromStartInterval, JSONObject joPrimaryCounterChartdata) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		
		JSONObject joRtnCounterData = null, joRtnChartData = null, joRtnCounterException = null;

		ArrayList<JSONObject> alSampleFormat = new ArrayList<JSONObject>();
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();

			Long lStartDateTime = null, lEndDateTime = null;
			// gets counter's chartdata, strMaxTimeStamp given as null, 
			boolean isAboveThreshold =  joPrimaryCounterChartdata.getBoolean("is_above_threshold");
			joRtnCounterData = moduleCounterDBI.getModuleCountersChartData(con, strGUID, strCounterId, null, strFromStartInterval, lStartDateTime, lEndDateTime, false, isAboveThreshold);
			
			joRtnChartData = joRtnCounterData.getJSONObject("chartdata");
			joRtnCounterException = joRtnCounterData.getJSONObject("countersException");
			
			// since for single counter data
			//joPrimaryCounterChartdata.put("counterLastValue", dCounterValue);
			joPrimaryCounterChartdata.put("counterData", (joRtnChartData.size() > 0 ? joRtnChartData.getJSONArray(strCounterId) : alSampleFormat));
			// since no data in rst condition added for max_recieved_on 
			joPrimaryCounterChartdata.put("maxTimeStamp", joRtnCounterData.containsKey("max_recieved_on") ? joRtnCounterData.getString("max_recieved_on") : null);
			joPrimaryCounterChartdata.put("serverCurrentTime", joRtnCounterData.getLong("serverCurrentTime") );
			joPrimaryCounterChartdata.put("countersException", (joRtnCounterException.size() > 0 ? joRtnCounterException.getString(strCounterId) : ""));
			//joPrimaryCounterChartdata.put("agentException", joRtnCounterData.getString("agentException"));
			
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets counterId breaches mapped for SLA for analytics
	 *   DON'T use (joPrimaryCounterChartdata = null OR joPrimaryCounterChartdata = new JSONObject()) 
	 *
	 * @param con
	 * @param strGUID
	 * @param strSLAIdForAnalytics
	 * @param strCounterId
	 * @param lUserId
	 * @param joPrimaryCounterChartdata
	 * @throws Exception
	 */
	public void getAndSetCounterBreachesInPrimaryCounter(Connection con, String strGUID, String strSLAIdForAnalytics, String strCounterId, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, long lUserId, JSONObject joPrimaryCounterChartdata) throws Exception {
		SLAManager slaManager = null;
		
		JSONObject joRtnBreachesData = null, joRtnCountersBreaches = null;
		
		try {
			slaManager = new SLAManager();
			
			joRtnBreachesData = slaManager.getCountersBreaches(con, strGUID, strSLAIdForAnalytics, strCounterId, strFromStartInterval, lStartDateTime, lEndDateTime, lUserId);
			joRtnCountersBreaches = joRtnBreachesData.getJSONObject("countersBreaches");
			
			joPrimaryCounterChartdata.put("breaches", (joRtnCountersBreaches.containsKey(strCounterId) ? joRtnCountersBreaches.getJSONArray(strCounterId) : null ));
			
			slaManager = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * might use in future, As per Sriraman sir tried
	 * 
	 * @param con
	 * @param strGUID
	 * @param strCounterIds
	 * @param lMaxTimeStamp
	 * @param strFromStartInterval
	 * @throws Exception
	 */
	public void getSplitCounters(Connection con, String strGUID, String strCounterIds, Long lMaxTimeStamp, String strFromStartInterval) throws Exception {
		Statement stmt = null;
		ResultSet rstRtnCounter = null;

		ModuleCounterDBI moduleCounterDBI = null;
		ModuleDBI moduleDBI = null;
		UtilsChartData utilsChartData = null;

		ArrayList<ArrayList<JSONObject>> alCounterData = new ArrayList<ArrayList<JSONObject>>();
		ArrayList<JSONObject> alCounterSet = null;
		
		
		Calendar calendarNow = Calendar.getInstance();
		
		long lFromTimestamp = -1L, lToTimestamp = -1L, lUId = -1L;

		long lStartTime = 0L, lEndTime = 0L;
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			moduleDBI = new ModuleDBI();
			utilsChartData = new UtilsChartData();
			
			
			lUId = moduleDBI.getUID(con, strGUID);
			
			
			stmt = con.createStatement();
			
			// time from 1 hour before
			calendarNow.add(Calendar.MINUTE, -1 * 60);
			lStartTime = System.currentTimeMillis();
			for(int i = 0; i < 4; i = i + 1) {
				lFromTimestamp = calendarNow.getTimeInMillis();

				calendarNow.add(Calendar.MINUTE, 1 * 15);
				lToTimestamp = calendarNow.getTimeInMillis();
				
				//lTotalCount = moduleCounterDBI.getTotalCounterDataBetweenTime(con, lUId, strCounterIds, lFromTimestamp, lToTimestamp);
				rstRtnCounter = moduleCounterDBI.getCounterDataBetweenTime(stmt, lUId, strCounterIds, lFromTimestamp, lToTimestamp);
				
				alCounterSet = utilsChartData.getCounterSet(rstRtnCounter);
				
				
				if ( alCounterSet.size() < 42 ) {
					// TODO: split, put to method
					utilsChartData.breakCounterSet(alCounterSet, alCounterData);
				} else {
					alCounterData.add(alCounterSet);
				}
			}
			lEndTime = System.currentTimeMillis();
			
			System.out.println("Other logic time: "+ (lEndTime - lStartTime) + " milllis seconds ");
			
			
			moduleCounterDBI = null;
			moduleDBI = null;
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(rstRtnCounter);
			rstRtnCounter = null;
			DataBaseManager.close(stmt);
			stmt = null;
		}
	}

	/**
	 * gets profiler top 10 time taken methods
	 * 
	 * @param con
	 * @param strGUID
	 * @param strLocalNameIP
	 * @param strTransactionName
	 * @param strTimeStamp
	 * @param strDuration
	 * @param strCounterTypeName
	 * @return
	 * @throws Exception
	 */
	public JSONArray getProfilerTimeTakenMethods(Connection con, String strGUID, String strLocalNameIP, String strTransactionType, String strTransactionName, String strTimeStamp, String strDuration, String strCounterTypeName) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		ModuleCounterDBI modulesDBI = null;
		
		JSONArray jaTimetakenMethods = null;

		try {
			modulesDBI = new ModuleCounterDBI();

			jaTimetakenMethods = modulesDBI.getProfilerTimeTakenMethods(con, strGUID, strLocalNameIP, strTransactionType, strTransactionName, strTimeStamp, strDuration, strCounterTypeName);

			modulesDBI = null;
		} catch (Exception ex) {
			throw ex;
		} finally {
		    LogManager.logMethodEnd(dateLog);
		}

		return jaTimetakenMethods;
	}

	public JSONObject getCSVChartdata(Connection con, String strGUID, String strCounterId, String strInterval) throws Exception {
		
		ModuleCounterDBI moduleCounterDBI = null;
		ModuleDBI moduleDBI = null;
		Date dateLog = LogManager.logMethodStart();
		JSONArray jaRtn = null;
		JSONObject joRtn = null, joData = null;
		long lUid = -1l;
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			moduleDBI = new ModuleDBI();
			lUid = moduleDBI.getUID(con, strGUID);
			joRtn = new JSONObject();
			jaRtn = moduleCounterDBI.getCSVChartdata(con, lUid, Long.parseLong(strCounterId), strInterval);
			joData = moduleCounterDBI.getCounterUnits(con, lUid, Long.parseLong(strCounterId));
			joRtn.put("data", jaRtn);
			joRtn.put("units", joData.getString("units"));
			joRtn.put("module_name", joData.getString("module_name"));
			joRtn.put("module_code", joData.getString("module_code"));
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return joRtn;
	}

	public JSONObject getCSVChartdataWithDateRange(Connection con, String strGUID, String strCounterId, String strStartTime, String strEndTime) throws Exception {
		
		ModuleCounterDBI moduleCounterDBI = null;
		ModuleDBI moduleDBI = null;
		Date dateLog = LogManager.logMethodStart();
		JSONArray jaRtn = null;
		JSONObject joRtn = null, joData = null;
		long lUid = -1l;
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			moduleDBI = new ModuleDBI();
			lUid = moduleDBI.getUID(con, strGUID);
			joRtn = new JSONObject();
			jaRtn = moduleCounterDBI.getCSVChartdataWithDateRange(con, lUid, Long.parseLong(strCounterId), strStartTime, strEndTime);
			joData = moduleCounterDBI.getCounterUnits(con, lUid, Long.parseLong(strCounterId));
			joRtn.put("data", jaRtn);
			joRtn.put("units", joData.getString("units"));
			joRtn.put("module_name", joData.getString("module_name"));
			joRtn.put("module_code", joData.getString("module_code"));
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return joRtn;
	}
	
	public String getTopProcess(Connection con, String strUID, String strCounterId, String strCategory,String strSliderValue,String selectedTime) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		ModuleCounterDBI modulesDBI = null;
		
		String topProcess = null;

		try {
			modulesDBI = new ModuleCounterDBI();

			topProcess = modulesDBI.getTopProcess(con, strUID, strCounterId, strCategory, strSliderValue, selectedTime);

			modulesDBI = null;
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
		    LogManager.logMethodEnd(dateLog);
		}
		return topProcess;
	}
	
	/**
	 * gets user's breached counters,
	 *   gets respective breached counter's chartdata & breach data
	 *   
	 * @param con
	 * @param strFromStartInterval
	 * @param lStartDateTime
	 * @param lEndDateTime
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getBreachedCountersDataForHotspot(Connection con, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, long lUserId) throws Throwable {
		Date dateLog = LogManager.logMethodStart();
		
		JSONArray jaBreachedCounters = null, jaChartData = null;
		JSONObject joBreachedCounter = null, joRtnCounterData = null, joRtnBreachData = null, joRtnCounterBreaches = null, joChartData = null;
		
		//String breachedData = null;
		String strGUID = "", strCounterId = "", strCategory = "", strDisplayName = "", strUnit = "", strSLAId = "", strBreachedTimestamps = null;
		
		boolean bSLAIsAboveThreshold = false;
		
		SLAManager slaManager = null;
		
		/**
		 * 1. Get all the breached SLA_ID-UID-CounterId
		 * 2. Get the Counter details with the above received CounterId; from counter-template
		 * 3. Get the Module's details with the above received UID
		 * 4. Collect the last hour's minute aggregation.
		 * 5. Collect the SLA breached timelines.
		 * 
		 */
		try {
			slaManager = new SLAManager();
			
			jaBreachedCounters = new JSONArray();
			
			// Get all the breached SLA_ID-UID-CounterId
			jaBreachedCounters = slaManager.getBreachedCountersDataForHotspot(con, strFromStartInterval, lStartDateTime, lEndDateTime, lUserId);
			for( int i = 0; i < jaBreachedCounters.size(); i++ ) {
				joBreachedCounter = jaBreachedCounters.getJSONObject(i);
				
				jaChartData = new JSONArray();
				joChartData = new JSONObject();
				
				strGUID = joBreachedCounter.getString("guid");
				strCounterId = joBreachedCounter.getString("counter_id");
				strCategory = joBreachedCounter.getString("category");
				strDisplayName = joBreachedCounter.getString("display_name");
				strUnit = joBreachedCounter.getString("unit");
				strSLAId = joBreachedCounter.getString("sla_id");
				strBreachedTimestamps = joBreachedCounter.getString("breached_timestamps");
				bSLAIsAboveThreshold = joBreachedCounter.getBoolean("sla_is_above_threshold");
				
				// TODO: ASK, set param for `is_static_counter` to send 
				// TODO: set param for `max_value_counter_id` send 
				
				// gets chart data
				joRtnCounterData = getModuleCountersChartData(con, lUserId, strGUID, strCounterId, null, strFromStartInterval, lStartDateTime, lEndDateTime, false, bSLAIsAboveThreshold, false, null);
				joChartData.put("label", strDisplayName);
				joChartData.put("unit", strUnit);
				joChartData.put("category", strCategory);
				joChartData.put("data", "["+joRtnCounterData.getJSONObject("chartdata").get(strCounterId)+"]");
				joChartData.put("sla_threshold_limits", joRtnCounterData.getJSONObject("sla_threshold_limits"));
				joChartData.put("sla_is_above_threshold", bSLAIsAboveThreshold);
				
				
				/* Data to show vertical breach indicator, in hot-spots.
				 * Not required for now.
				 *
				// breached data
				joRtnBreachData = slaManager.getCounterBreaches(con, strGUID, strSLAId, strCounterId, strFromStartInterval, lStartDateTime, lEndDateTime, lUserId, strBreachedTimestamps);
				joRtnCounterBreaches = joRtnBreachData.getJSONObject("countersBreaches");
				if( joRtnCounterBreaches.containsKey(strCounterId) ) {
					joChartData.put("breaches", joRtnCounterBreaches.getJSONArray(strCounterId));
				} else {
					joChartData.put("breaches", "[]");
				}*/
				joChartData.put("breaches", "[]");
				
				jaChartData.add(joChartData);
				joBreachedCounter.put("chartData", jaChartData);
			}
		} catch (Throwable th) {
			throw th;
		} finally {
		    LogManager.logMethodEnd(dateLog);
		}
		
		return jaBreachedCounters;
	}
	
	/**
	 * gets all `WARNING` & `CRITICAL` breaches, of ASD counters, SUM tests & RUM modules, for hotspots
	 * 
	 * @param con
	 * @param strInterval
	 * @param lStartDateTimeInMills
	 * @param lEndDateTimeInMills
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	/*public JSONObject getBreachedCountersForHotspot(Connection con, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, LoginUserBean loginUserBean) throws Exception {
		ServiceManager serviceManager = null;
		
		JSONObject joRtnBreachedModules = null;
		
		try {
			serviceManager = new ServiceManager();
			
			// get all `WARNING` & `CRITICAL` breaches, of ASD counters, SUM tests & RUM modules 
			joRtnBreachedModules = serviceManager.getModuleCounters(con, -1, -1, "", "", strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean);
			
			serviceManager = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnBreachedModules;
	}*/
}
