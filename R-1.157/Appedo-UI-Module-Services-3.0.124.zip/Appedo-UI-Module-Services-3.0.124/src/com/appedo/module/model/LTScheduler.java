package com.appedo.module.model;

import java.util.HashMap;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;

import com.appedo.manager.LogManager;
import com.appedo.module.bean.LoadTestSchedulerBean;
import com.appedo.module.common.Constants;
import com.appedo.module.utils.UtilsFactory;

public class LTScheduler {
	
	public static String putTestInQueue(LoadTestSchedulerBean testBean) throws Exception {
		HttpClient client = null;
		PostMethod method = null;
		String responseStream = null;
		HashMap<String, String> hmResponse = new HashMap<String, String>();
		
		try{
			client = new HttpClient();
			// URLEncoder.encode(requestUrl,"UTF-8");
			method = new PostMethod(Constants.LT_QUEUE_SERVICES+"/ltQueue/putTestInQueue");
			method.addParameter("testBean", testBean.toJSON().toString());
			method.setRequestHeader("Connection", "close");
			int statusCode = client.executeMethod(method);
			// System.err.println("statusCode: "+statusCode);
			
			if (statusCode != HttpStatus.SC_OK) {
				LogManager.errorLog("Method failed: " + method.getStatusLine());
			}
			
			responseStream = method.getResponseBodyAsString();
			// System.out.println("responseJSONStream: "+responseStream);
		} catch(Throwable e) {
			e.printStackTrace();
			LogManager.errorLog("Exception in getConfigurations: "+e.getMessage());
			throw e;
		} finally {
			method.releaseConnection();
			method = null;
			UtilsFactory.clearCollectionHieracy( hmResponse );
		}
		
		return responseStream;
	}
	
	public static String getProcessingQueueDetails(String param) throws Throwable {
		
		HttpClient client = null;
		PostMethod method = null;
		
		String responseStream = null;
		HashMap<String, String> hmResponse = new HashMap<String, String>();
		
		try{
			client = new HttpClient();
			// URLEncoder.encode(requestUrl,"UTF-8");
			method = new PostMethod(Constants.LT_QUEUE_SERVICES+"/ltQueue/"+param);
			method.setRequestHeader("Connection", "close");
			int statusCode = client.executeMethod(method);
			// System.err.println("statusCode: "+statusCode);
			
			if (statusCode != HttpStatus.SC_OK) {
				LogManager.errorLog("Method failed: " + method.getStatusLine());
			}
			
			responseStream = method.getResponseBodyAsString();
			// System.out.println("responseJSONStream: "+responseStream);
		} catch(Throwable e) {
			e.printStackTrace();
			LogManager.errorLog("Exception in getProcessingQueueDetails: "+e.getMessage());
			throw e;
		} finally {
			method.releaseConnection();
			method = null;
			UtilsFactory.clearCollectionHieracy( hmResponse );
		}
		
		return responseStream;
	}
}
