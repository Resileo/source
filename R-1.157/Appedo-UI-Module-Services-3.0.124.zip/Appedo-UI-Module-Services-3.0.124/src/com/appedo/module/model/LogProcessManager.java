package com.appedo.module.model;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.commons.manager.AppedoMailer;
import com.appedo.commons.manager.AppedoMailer.MODULE_ID;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.LogViewBean;
import com.appedo.module.bean.ModuleBean;
import com.appedo.module.common.Constants;
import com.appedo.module.dbi.LogProcessDBI;
import com.appedo.module.utils.UtilsFactory;



public class LogProcessManager {
	
	/**
	 * 
	 * @param con
	 * @param moduleBean
	 * @throws Exception
	 */
	public void addLogMonitor(Connection con, ModuleBean moduleBean) throws Exception {
		LogProcessDBI logProcessDBI = null;
		long lModuleId, lUserId = 0;
		String strGuid = "";
		ServiceManager serviceManager = null;
		LoginUserBean loginUserBean = null;
		try {
			logProcessDBI = new LogProcessDBI();
			serviceManager = new ServiceManager();
			loginUserBean = new LoginUserBean();
			
			lUserId = logProcessDBI.getUserId(con, moduleBean.getEncryptedUserId());
			moduleBean.setUserId(lUserId);
			
			// check whether the client unique id has GUID
			boolean bExist = logProcessDBI.isClientUniqueIdExists(con, moduleBean);
			
			if(bExist){
				strGuid = logProcessDBI.getGUID(con, moduleBean);
				if (strGuid.equals("")){
					String message = logProcessDBI.getNameFromUUID(con, moduleBean);
					strGuid = "UUID already exist, Please contact "+message;
				}
				moduleBean.setGuid(strGuid);
			}else{
				String StrModuleName = "LOG_MONITOR_"+new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
				
				moduleBean.setModuleName(StrModuleName);
				//moduleBean.setDescription(StrModuleName+" description");
				moduleBean.setAgentVersionId(-1);
				moduleBean.setModuleType("LOG");
				moduleBean.setGuid(UUID.randomUUID().toString());
				
				// add to module_master.
				lModuleId = logProcessDBI.addLogMonitor(con, moduleBean);
				
				loginUserBean.setUserId(moduleBean.getUserId());
				serviceManager.v1_addToServiceMap(con, Constants.LOG_MODULE, lModuleId, loginUserBean);
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			loginUserBean = null;
			logProcessDBI = null;
			serviceManager = null;
		}
	}

	/**
	 * to get log view details
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLogTypes(Connection con) throws Exception {
		LogProcessDBI logProcessDBI = null;
		JSONArray jaLogTypes = null;
		try {
			logProcessDBI = new LogProcessDBI();
			jaLogTypes = logProcessDBI.getLogTypes(con);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return jaLogTypes;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean getLogViewLicenseDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		LogProcessDBI logProcessDBI = null;
		boolean isLicenseValidForLog = false;

		try {
			logProcessDBI = new LogProcessDBI();
			// gets license details from month wise table
			isLicenseValidForLog = logProcessDBI.getLogViewLicenseDetails(con, loginUserBean);

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return isLicenseValidForLog;
	}

	/**
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isUserMappingExists(Connection con, long lUserId) throws Exception {
		LogProcessDBI logProcessDBI = null;

		boolean bUserMappingExists = false;
		try {
			logProcessDBI = new LogProcessDBI();

			bUserMappingExists = logProcessDBI.isUserMappingExists(con, lUserId);

			logProcessDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bUserMappingExists;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param clientLogName
	 * @return
	 * @throws Exception
	 */
	public boolean validateLogViewName(Connection con, LoginUserBean loginUserBean, String clientLogName) throws Exception {
		LogProcessDBI logProcessDBI = null;
		boolean bExists = false;

		try {
			logProcessDBI = new LogProcessDBI();

			bExists = logProcessDBI.validateLogViewName(con, loginUserBean, clientLogName);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bExists;
	}

	/**
	 * 
	 * @param con
	 * @param userid
	 * @param logViewBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject saveLogDetails(Connection con, String userid, LogViewBean logViewBean) throws Exception {
		LogProcessDBI logProcessDBI = null;
		JSONObject joElkCompleteDetails = null;
		boolean isUserMappingExists = false;
		try {
			logProcessDBI = new LogProcessDBI();
			// Check in elk_user_mapping and add it.
			// Check user mapping exists
			isUserMappingExists = isUserMappingExists(con, Long.parseLong(userid));
			// Save log details
			joElkCompleteDetails = logProcessDBI.saveLogDetails(con, userid, isUserMappingExists, logViewBean);

			if (!isUserMappingExists) {
				sendAlertsDevOps(con, joElkCompleteDetails);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return joElkCompleteDetails;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserLogViews(Connection con, LoginUserBean loginUserBean) throws Exception {
		LogProcessDBI logProcessDBI = null;
		JSONArray jaUserLogViews = null;

		try {
			logProcessDBI = new LogProcessDBI();
			jaUserLogViews = logProcessDBI.getUserLogViews(con, loginUserBean);
			logProcessDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaUserLogViews;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getUserIpAndPort(Connection con, LoginUserBean loginUserBean) throws Exception {
		LogProcessDBI logProcessDBI = null;
		JSONObject joUserIpAndPort = null;

		try {
			logProcessDBI = new LogProcessDBI();
			joUserIpAndPort = logProcessDBI.getUserIpAndPort(con, loginUserBean);
			logProcessDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return joUserIpAndPort;
	}

	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param lLogViewId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getUserLsIpAndPort(Connection con, LoginUserBean loginUserBean, long lLogViewId) throws Exception {
		LogProcessDBI logProcessDBI = null;
		JSONObject joUserLsIpAndPort = null;

		try {
			logProcessDBI = new LogProcessDBI();
			joUserLsIpAndPort = logProcessDBI.getUserLsIpAndPort(con, loginUserBean, lLogViewId);
			logProcessDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return joUserLsIpAndPort;
	}

	/**
	 * 
	 * @param con
	 * @param lLogViewId
	 * @param lUserId
	 * @throws Exception
	 */
	public void deleteLogView(Connection con, long lLogViewId, long lUserId) throws Exception {
		LogProcessDBI logProcessDBI = null;

		try {
			logProcessDBI = new LogProcessDBI();
			// delete
			logProcessDBI.deleteLogView(con, lLogViewId, lUserId);
			logProcessDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}

	/**
	 * 
	 * @param con
	 * @param joElkCompleteDetails
	 * @throws Exception
	 */
	public void sendAlertsDevOps(Connection con, JSONObject joElkCompleteDetails) throws Exception {

		HashMap<String, Object> hmMailDetails = null;
		boolean bMailSent = false;
		AppedoMailer appedoMailer = null;
		StringBuilder mailContent = new StringBuilder();

		try {
			appedoMailer = new AppedoMailer( Constants.EMAIL_TEMPLATES_PATH );
			hmMailDetails = new HashMap<String, Object>();

			hmMailDetails.put("email_id", joElkCompleteDetails.getString("email_id"));
			hmMailDetails.put("mobile_no", joElkCompleteDetails.getString("mobile_no"));
			hmMailDetails.put("elk_name", joElkCompleteDetails.getString("elk_client_name"));
			hmMailDetails.put("log_type", joElkCompleteDetails.getString("log_type"));
			hmMailDetails.put("elastic_search", joElkCompleteDetails.getString("elasticsearch"));
			hmMailDetails.put("logstash", joElkCompleteDetails.getString("logstash"));
			hmMailDetails.put("kibana", joElkCompleteDetails.getString("kibana"));
			hmMailDetails.put("nginx", joElkCompleteDetails.getString("nginx"));

			String emailsToAlert = Constants.EMAIL_TO_ALERT_FOR_LOG_VIEW;
			//commented below line for error removal, this function is not in use.
		//	bMailSent = appedoMailer.sendMail(MODULE_ID.LOG_SERVICE_REQUEST, hmMailDetails, emailsToAlert.split(","), "");
			if (bMailSent) {
				LogManager.infoLog("Is mail sent to devops/admin " + bMailSent);
			} else {
				LogManager.infoLog("Error sending mail to devops/admin " + bMailSent);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(mailContent);
		}
	}

}