package com.appedo.module.model;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.dbi.ChartDBI;
import com.appedo.module.dbi.ModuleDBI;
import com.appedo.module.utils.UtilsFactory;


public class ChartManager {
	
	public long addChartView(Connection con, JSONObject joChartDetails, LoginUserBean loginUserBean) throws Exception {
		ChartDBI chartDBI = null;

		long lChartViewId = -1L;

		boolean bChartViewExists = false;
		
		try {
			chartDBI = new ChartDBI();		
			// checks charview isExists, , "-1" hardcoding since its a new insert
			bChartViewExists = chartDBI.isChartViewExists(con, joChartDetails.getString("chartName"), -1, loginUserBean.getUserId());
			
			if ( bChartViewExists ) {
				throw new Exception("Chart name already exists");
			} else {
				// inserts
				lChartViewId = chartDBI.insertChartView(con, joChartDetails, loginUserBean);
				
					chartDBI.insertChartViewDetails(con, lChartViewId, joChartDetails);
				
			}
			
			chartDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lChartViewId;
	}
	
	public long updateChartView(Connection con, JSONObject joChartDetails, LoginUserBean loginUserBean) throws Exception {
		ChartDBI chartDBI = null;

		long lChartViewId = -1L;
		try {
			chartDBI = new ChartDBI();
			boolean bChartViewExists = false;

			bChartViewExists = chartDBI.isChartViewExists(con, joChartDetails.getString("chartName"), joChartDetails.getLong("chartViewId"), loginUserBean.getUserId());
			if ( bChartViewExists ) {
				throw new Exception("Chart name already exists");
			} else {
				// update
				lChartViewId = chartDBI.updateChartView(con, joChartDetails, loginUserBean);
				chartDBI.insertChartViewDetails(con, lChartViewId, joChartDetails);
				chartDBI = null;
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lChartViewId;
	}

	public boolean isChartNameExists(Connection con, String strChartName, long lChartViewId, long lUserId) throws Exception {
		ChartDBI chartDBI = null;
		
		boolean bChartNameExists = false;
		try {
			chartDBI = new ChartDBI();

			bChartNameExists = chartDBI.isChartViewExists(con, strChartName, lChartViewId, lUserId);
			
			chartDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bChartNameExists;
	}
	
	public String getUserChartViewsWithCounterDetails(Connection con, LoginUserBean loginUserBean, long chartId) throws Exception {
		ChartDBI chartDBI = null;
		
		String jaUserChartViews = null;
		
		try {
			chartDBI = new ChartDBI();

			jaUserChartViews = chartDBI.getUserChartViewsWithCounterDetails(con, loginUserBean, chartId);
			
			chartDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaUserChartViews;
	}
	
	public JSONArray getModuleTypesDetails(Connection con, long lServiceMapId, LoginUserBean loginUserBean) throws Exception {
		ChartDBI chartDBI = null;
		ModuleDBI moduleDBI = null;
		
		String strModule = "";
		// since to have the resp in respective order, the order is specified 
		String[] saASDRModules = {"APPLICATION", "SERVER", "DATABASE", "RUM"};
		
		// ASDR refers Application/Server/Database/RUM
		LinkedHashMap<String, ArrayList<JSONObject>> lhmRtnASDRModulesDetails = null;
		
		JSONArray jaRtnSUMTests = null, jaAPMModulesDetails = new JSONArray();
		JSONObject joModuleDetails = null, EmptyData = null;
		// Application/Server/Database/SUM
		//JSONObject joModuleTypesDetails = null;
		
		try {
			chartDBI = new ChartDBI();
			moduleDBI = new ModuleDBI();
			
			//joModuleTypesDetails = new JSONObject();
			
			// gets Application/Server/Database/RUM
			lhmRtnASDRModulesDetails = moduleDBI.getUserAllModules(con, lServiceMapId, loginUserBean.getUserId(), EmptyData);
			
			// gets SUM tests
			jaRtnSUMTests = chartDBI.getSUMTests(con, lServiceMapId, loginUserBean.getUserId());
			
			//joModuleTypesDetails.putAll(lhmRtnModulesDetails);
			//joModuleTypesDetails.put("SUM", jaRtnSUMTests);
			
			
			// adds the module into JSONArray, as necessary format
			for(int i = 0; i < saASDRModules.length; i = i + 1) {
				strModule = saASDRModules[i];
				
				if ( lhmRtnASDRModulesDetails.containsKey(strModule) ) {
					joModuleDetails = new JSONObject();
					joModuleDetails.put("serviceType", strModule);
					// respective modules ArrayList pair.getValue()
					joModuleDetails.put("modules", lhmRtnASDRModulesDetails.get(strModule));
					
					jaAPMModulesDetails.add(joModuleDetails);
				}
			}
			// adding SUM to JSONArray
			if( jaRtnSUMTests != null && jaRtnSUMTests.size() > 0 ) {
				joModuleDetails = new JSONObject();
				joModuleDetails.put("serviceType", "SUM");
				joModuleDetails.put("modules", jaRtnSUMTests);
				jaAPMModulesDetails.add(joModuleDetails);	
			}
			
			chartDBI = null;
			moduleDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaAPMModulesDetails;
	}
	
    public JSONArray getAgentAllCategoryWiseCounters(Connection con, long lUId, String module_name) throws Exception {
        JSONArray jaCategoriesCounters = null;
        JSONObject joCategoryCounters = null;
        
        HashMap<String, ArrayList<JSONObject>> hmCategoryWiseCouters = null;
        ArrayList<JSONObject> alCounters = null;
        Iterator<Map.Entry<String, ArrayList<JSONObject>>> itCategoryWiseCouters = null;
        
        String strCategory = "";
        
        ChartDBI chartDBI = null;
        
    	try {
            jaCategoriesCounters = new JSONArray();
            chartDBI = new ChartDBI();
            
            hmCategoryWiseCouters = chartDBI.getAgentAllCategoryWiseCounters(con, lUId);
            
            itCategoryWiseCouters = hmCategoryWiseCouters.entrySet().iterator();
            while( itCategoryWiseCouters.hasNext() ) {
            	Map.Entry<String, ArrayList<JSONObject>> pairs = (Map.Entry<String, ArrayList<JSONObject>>) itCategoryWiseCouters.next();
            	
            	strCategory = pairs.getKey();
            	alCounters = pairs.getValue();
            	
            	joCategoryCounters = new JSONObject();
            	joCategoryCounters.put("category", strCategory);
            	joCategoryCounters.put("counters", alCounters);
            	jaCategoriesCounters.add(joCategoryCounters);
            	
            	UtilsFactory.clearCollectionHieracy(alCounters);
            	alCounters = null;
            }
            
            chartDBI = null;
		} catch (Exception e) {
            throw e;
		} finally {
        	UtilsFactory.clearCollectionHieracy(hmCategoryWiseCouters);
        	hmCategoryWiseCouters = null;
		}
    	
        return jaCategoriesCounters;
    }
    
    public String getChartMultiLine(Connection con, JSONObject joDetails, String strInterval, String loc, Long lStartDateTime, Long lEndDateTime) throws Exception {
		ChartDBI chartDBI = null;
		
		JSONObject joChartData = null;
		
		try {
			chartDBI = new ChartDBI();
			
			joChartData = chartDBI.getChartMultiLine(con, joDetails, strInterval, loc, lStartDateTime, lEndDateTime);
			
			chartDBI = null;
		} catch(Exception e) {
			throw e;
		}
		
		return joChartData.toString();
	}
    
    /**
     * gets MyChart data for configured,
     *   for ASD chart data, breaks counter's chart data into sets, 
     *    to have gap between lines, for agent not sent data
     *   
     * @param con
     * @param joDetails
     * @param strLocation
     * @param strInterval
     * @param lStartDateTime
     * @param lEndDateTime
     * @return
     * @throws Exception
     */
    public String getMyChartData(Connection con, JSONObject joDetails, String strLocation, String strInterval, Long lStartDateTime, Long lEndDateTime) throws Exception {
    	ChartDBI chartDBI = null;
    	
		JSONObject joChartData = null;
		
    	try {
			chartDBI = new ChartDBI();
			
			if ( ! joDetails.getString("module_name").equals("SUM") && ! joDetails.getString("module_name").equals("RUM") ) {
				// for ASD chart data
				joChartData = chartDBI.getASDCounterChartData(con, joDetails, strInterval, lStartDateTime, lEndDateTime);
			} else {
				// SUM, RUM chart data
				joChartData = chartDBI.getChartMultiLine(con, joDetails, strInterval, strLocation, lStartDateTime, lEndDateTime);
			}
			
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		}
    	
    	return joChartData.toString();
    }
    
    public String getSUMLocations(Connection con, long testId) throws Exception {
		ChartDBI chartDBI = null;
		
		String locations = null;
		
		try {
			chartDBI = new ChartDBI();

			locations = chartDBI.getSUMLocations(con, testId);
			
			chartDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return locations;
	}
    
	public void deleteChartView(Connection con, long lChartViewId, long lUserId) throws Exception {
		ChartDBI chartDBI = null;

		try {
			chartDBI = new ChartDBI();
			
			// delete 
			chartDBI.deleteChartView(con, lChartViewId, lUserId);
			
			chartDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	
	public JSONArray getChartVisualizerData_v1(Connection con, long lUserId, long lRefId, String strCounterId, String moduleType, Long counterTemplateId, String strModuleName, Long secRefId, String secRefName, String category, String strInterval, Long lStartDate, Long lEndDate) throws Exception {
		ChartDBI chartDBI = null;
		
		//JSONArray jaChartVisualDatas = null;
		JSONArray jaChartRawDatas = null;
		try {
			
			chartDBI = new ChartDBI();
			if (moduleType.equals(Constants.RUM_MODULE)) {
				jaChartRawDatas = chartDBI.getChartVisualizerRUMData_v1(con, lUserId, lRefId, moduleType);
			} else if (moduleType.equals(Constants.SUM_MODULE)) {
				jaChartRawDatas = chartDBI.getChartVisualizerSUMData_v1(con, lUserId, lRefId, moduleType, secRefName, category);
			} else if (moduleType.equals(Constants.LOG_MODULE)) {
				jaChartRawDatas = chartDBI.getChartVisualizerLOGData_v1(con, lUserId, lRefId, moduleType, secRefId, secRefName);
			}else {
				jaChartRawDatas = chartDBI.getChartVisualizerOADData_v1(con, lUserId, lRefId, strCounterId, moduleType, counterTemplateId, strInterval, lStartDate, lEndDate);
			}
			
						
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		} 		
		return jaChartRawDatas;
	}
	
	public JSONArray getAllMyCharts(Connection con, long lUserId, long lEID) throws Exception {
		ChartDBI chartDBI = null;
		
		//JSONArray jaChartVisualDatas = null;
		JSONArray jaChartRawDatas = null;
		try {
			
			chartDBI = new ChartDBI();
			jaChartRawDatas = chartDBI.getAllMyChart(con, lUserId, lEID);
						
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		} 		
		return jaChartRawDatas;
	}
	
	public void addToMyChart(Connection con, long lUserId, long lChartId, String strChartName, String strModuleType, long lRefId, boolean isNewChart, boolean isMyChartExist, long lEID) throws Exception {
		ChartDBI chartDBI = null;
		boolean isExist = false;
		try {
			
			chartDBI = new ChartDBI();
			if (isMyChartExist){
				isExist = chartDBI.isMyChartExists(con, lUserId, strChartName, lEID);
			}
			//System.out.println("isExist :"+isExist);

			if (isNewChart && isExist) {
				throw new Exception("1");
			}
			chartDBI.addToMyChart(con, lUserId, lChartId, lRefId, strChartName, strModuleType, lEID);
						
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		} 		
	}
	
	public void removeFromMyChart(Connection con, long lUserId, long lChartId, String strChartName, long lEID) throws Exception {
		ChartDBI chartDBI = null;
		try {
			
			chartDBI = new ChartDBI();
			
			chartDBI.removeFromMyChart(con, lUserId, lChartId, strChartName, lEID);
						
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		} 		
	}
	
	public JSONArray getMyChartIds(Connection con, long lUserId, String strMyChartName, long lEID) throws Exception {
		ChartDBI chartDBI = null;
		
		JSONArray jaChartRawDatas = null;
		try {
			
			chartDBI = new ChartDBI();
			jaChartRawDatas = chartDBI.getMyChartIds(con, lUserId, strMyChartName, lEID);
						
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		} 		
		return jaChartRawDatas;
	}
	
	public JSONObject getMyChartVisualizerWithChartId(Connection con, long lUserId, long lChartId) throws Exception {
		ChartDBI chartDBI = null;
		
		JSONObject joChartData = null;
		try {
			
			chartDBI = new ChartDBI();
			joChartData = chartDBI.getChartVisualizerDataWithChartId(con, lUserId, lChartId);
			chartDBI = null;
		} catch (Exception e) {
			throw e;
		} 		
		return joChartData;
	}
	
	public JSONObject getChartDataPoint(Connection con, long lUserId, long lRefId, long lMetricId, String strSliderValue, Long lStartDate, Long lEndDate, String strCounterId, String strModuleType, String strXYaxisLabel, String strLocation, String strRumType) throws Exception {
		//ChartDBI chartDBI = null;
		RUMManager rumManager =null;
		SUMManager sumManager = null;
		ModuleCounterManager moduleCounterManager = null;
		JSONObject joChartData = null;
		try {
			rumManager = new RUMManager();
			sumManager = new SUMManager();
			moduleCounterManager = new ModuleCounterManager();
			if (strModuleType.equals(Constants.RUM_MODULE)) {
				joChartData = rumManager.getDailyVisitorsCount_v2(con, lUserId, lRefId, strSliderValue, lStartDate, lEndDate, lMetricId, strXYaxisLabel, strRumType);
			} else if(strModuleType.equals(Constants.SUM_MODULE)) {
				joChartData = sumManager.getSUMChartData_v1(con, lRefId, null, null, strSliderValue, lStartDate, lEndDate, lUserId, lMetricId, strLocation);
			} else if (strModuleType.equals(Constants.LOG_MODULE)) {
				joChartData = moduleCounterManager.getLOGModuleCountersChartData_v2(con, lUserId, lRefId, strSliderValue, lStartDate, lEndDate, lMetricId, strXYaxisLabel);
			} else {
				joChartData = moduleCounterManager.getModuleCountersChartData_v2(con, lUserId, lRefId, strCounterId, strSliderValue, lStartDate, lEndDate, lMetricId, strXYaxisLabel);
			}
			
			rumManager = null;
			sumManager = null;
			moduleCounterManager = null;
		} catch (Exception e) {
			throw e;
		} 		
		return joChartData;
	}
	
}
