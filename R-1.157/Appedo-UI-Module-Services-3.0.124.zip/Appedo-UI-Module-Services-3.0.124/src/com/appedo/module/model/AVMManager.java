package com.appedo.module.model;

import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.commons.manager.AppedoMailer;
import com.appedo.commons.manager.AppedoMailer.MODULE_ID;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.AVMAgentAlertAddressBean;
import com.appedo.module.bean.AVMAgentBean;
import com.appedo.module.bean.AVMTestBean;
import com.appedo.module.common.Constants;
import com.appedo.module.common.Constants.SUM_TYPE;
import com.appedo.module.dbi.AVMDBI;
import com.appedo.module.utils.UtilsFactory;


public class AVMManager {
	
	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAVMTests(Connection con, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		AVMDBI amdbi = null;

		JSONArray jaAVMTests = null;

		try {
			amdbi = new AVMDBI();

			//jaAVMTests = amdbi.getAVMTests(con, loginUserBean);
			jaAVMTests = amdbi.getAVMTests_v1(con, loginUserBean, joEnt);
			amdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaAVMTests;
	}
	
	/**
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getEditAVMTests(Connection con, LoginUserBean loginUserBean, AVMTestBean testBean) throws Exception {
		AVMDBI amdbi = null;

		//JSONArray jaAVMTests = null;
		JSONObject jaAVMTests = null;

		try {
			amdbi = new AVMDBI();

			jaAVMTests = amdbi.getAVMTests(con, loginUserBean, testBean);
			amdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaAVMTests;
	}
	/**
	 * 
	 * @param con
	 * @param lTestId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAVMAgents(Connection con, long lTestId, long lUserId, JSONObject joEnt) throws Exception {
		AVMDBI amdbi = null;
		JSONArray jaNodes = null;

		try {
			amdbi = new AVMDBI();
			jaNodes = amdbi.getAVMAgents(con, lTestId, lUserId, joEnt);
			amdbi = null;
		} catch (Exception e) {
			throw e;
		}

		return jaNodes;
	}
	
	/**
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isAVMTestExist(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		AVMDBI aumDbi = null;
		boolean bExists = false;
		
		try {
			aumDbi = new AVMDBI();
			
			// While adding new AVM test , test is hardcoded as "-1", since its a new insert.
			bExists = aumDbi.isAVMTestExist(con, testBean.getTestName(), testBean.getTestId(), loginUserBean);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bExists;
	}
	
	/**
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @return
	 * @throws Throwable
	 */
	public long addAVMTest(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Throwable {
		AVMDBI aumDbi = null;
		SUM_TYPE sumType = null;
		boolean bExist = false;

		long lTestId = -1l;
		try {
			aumDbi = new AVMDBI();
			
			
			bExist = isAVMTestExist(con, testBean, loginUserBean);

			if (bExist) {
				// Unable to add. Name already exist.
				throw new Exception("5");
			} else {
				lTestId = aumDbi.addAVMTest(con, testBean, loginUserBean, joEnt);

				testBean.setTestId(lTestId);
				// Commented for testing purpose.. 

				// Test gets run for the URL in the given regions
				// if Availability Monitor is disabled then,
				// no need to fetch existing AVM-Locations
				if (lTestId != -1 && testBean.isStatus()) {
					// To add mapping in "avm_test_agent_mapping"
					 aumDbi.addAvmAgentMapping(con, lTestId, testBean.getTargetLocations());
					 
					// Configure AVM test to SLA for alerts - Availability monitor
					sumType = SUM_TYPE.AVAILABILITY_MONITORING;
					configureSLAPolicyMapToAVMTest(testBean, loginUserBean, sumType, joEnt);

					// Update the availability's Sla id's in sum test master while adding.
					aumDbi.updateSlaIdInAVMTestMaster(con, testBean, loginUserBean, sumType);
				}
			}

			aumDbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return lTestId;
	}
	
	/**
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @throws Throwable
	 */
	public void updateAVMTest(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Throwable {
		AVMDBI aumDbi = null;
		boolean bExist = false;

		try {
			aumDbi = new AVMDBI();
			
			bExist = isAVMTestExist(con, testBean, loginUserBean);

			if (bExist) {
				// Unable to add. Name already exist.
				throw new Exception("5");
			} else {
				aumDbi.updateAVMTest(con, testBean, loginUserBean);

				// If Availability Monitor is disabled then,
				// No need to update AVM-Locations
				if (testBean.isStatus()) {
					// To add mapping in "avm_test_agent_mapping" ( delete the existing locations and insert the new locations)
					 aumDbi.deleteAvmAgentMapping(con, testBean.getTestId());
					 
					 aumDbi.addAvmAgentMapping(con, testBean.getTestId(), testBean.getTargetLocations());
				}
			}

			// Configure SLA Alerts, add/update SLA references - Availability monitor
			configureSLAPolicyMapToAVMTest(testBean, loginUserBean, SUM_TYPE.AVAILABILITY_MONITORING, joEnt);

			aumDbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

	}
	
	/**
	 * 
	 * @param testBean
	 * @param loginUserBean
	 * @param sumType
	 * @throws Exception
	 */
	public void configureSLAPolicyMapToAVMTest(AVMTestBean testBean, LoginUserBean loginUserBean, SUM_TYPE sumType, JSONObject joEnt) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			
			if(sumType == SUM_TYPE.AVAILABILITY_MONITORING){
				wsm.addParameter("policyName", testBean.getTestName()+ " SUM AVAILABILITY SLA Policy");
				wsm.addParameter("enable_alert", testBean.isStatus()+"");
				wsm.addParameter("min_breach_count", testBean.getAvmMinBreachCount()+"");
			}

			wsm.addParameter("policyDesc", testBean.getTestName() + Constants.SLA_AUTOGEN_DEFAULT_LASTNAME);
			//wsm.addParameter("policySvrType", sumTestBean.getTestName()+" SLA Policy");
			wsm.addParameter("alertType", Constants.SLA_AUTOGEN_DEFAULT_TYPE);
			
			// map AVM test thresholds to SLA policy
			//wsm.addParameter("sla_id", sumTestBean.getSLAId());
			wsm.addParameter("sum_test_id", testBean.getTestId()+"");
			wsm.addParameter("is_above_threashold", true+"");
			wsm.addParameter("sum_counter_name", "pageloadtime");
			wsm.addParameter("sum_type", sumType.toString());
			
			// add Enterprise Details
			wsm.addParameter("EnterpriseDetails", joEnt.toString());

			// web service request
			/*wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES + "/sla/configureSLAToSUMTestForThresholdBreach");*/
			wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES + "/sla/configureSLAToSUMTestForThresholdBreach");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());

				if (joResp.getBoolean("success")) {
					
					if (joResp.containsKey("slaId")) {
						if (sumType == SUM_TYPE.AVAILABILITY_MONITORING) {
							testBean.setAmSLAId(joResp.getLong("slaId"));
						}
					}
				}

			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
				LogManager.infoLog("SLA policy added and mapped to AVM test.");
			} else {
				// exception in SLA
				throw new Exception("Unable to add SLA policy & map to AVM test.");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	/**
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @param strAppedoScheduler
	 * @param request
	 * @throws Exception
	 */
	public void deleteAVMTest(Connection con, AVMTestBean testBean, LoginUserBean loginUserBean, HttpServletRequest request) throws Exception {
		AVMDBI aumDbi = null;
		try {
			aumDbi = new AVMDBI();

			// Delete the test details from avm_test_master and sum_heartbeat_log_<uid>
			aumDbi.deleteAVMTest(con, testBean, loginUserBean);

			// Delete the user mapped locations. 
			aumDbi.deleteAvmAgentMapping(con, testBean.getTestId());

			deleteAVMTestForSlaPolicy(testBean,request);

			aumDbi = null;
		} catch (Exception e) {
			throw e;
		} 
	}
	
	/**
	 * 
	 * @param testBean
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public boolean deleteAVMTestForSlaPolicy(AVMTestBean testBean,HttpServletRequest request) throws Exception {
		boolean bReturn = false;
		WebServiceManager wsm = null;

		try{
			// Test gets run for the URL in the given regions
			if(testBean.getTestId() != -1) {
				request.setAttribute("avm_test_id", testBean.getTestId());

				wsm = new WebServiceManager();
				wsm.sendRequest (Constants.APPEDO_UI_SLA_SERVICES+"/sla/deleteSlaAvm", request);
				int statusCode = wsm.getStatusCode();
				if( statusCode != HttpStatus.SC_OK ) {
					throw new Exception("Exception in Deleting Sla AVM): "+wsm.getResponse());
				}else{
					bReturn = false;
				}
			}
		} catch (Throwable th) {
			LogManager.errorLog(th);
			bReturn = false;
		} finally {
			wsm = null;
		}
		
		return bReturn;
	}
	
	/**
	 * gets user's availability monitor summary
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getAVMUserDashboardSummary(Connection con, LoginUserBean loginUserBean) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONObject joAVMUserSummary = null;
		
		try {
			avmdbi = new AVMDBI();
			
			joAVMUserSummary = avmdbi.getAVMUserDashboardSummary(con, loginUserBean.getUserId());
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joAVMUserSummary;
	}
	
	/**
	 * gets user's down locations status,
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserDownLocationsStatus(Connection con, LoginUserBean loginUserBean, long lLimit, long lOffSet) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONArray jaDownLocationsStatus = null;
		
		try {
			avmdbi = new AVMDBI();
			
			jaDownLocationsStatus = avmdbi.getUserDownLocationsStatus(con, loginUserBean.getUserId(), lLimit, lOffSet);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaDownLocationsStatus;
	}
	
	/**
	 * gets user's down locations status,
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUrlDownLocationsStatus(Connection con, LoginUserBean loginUserBean) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONArray jaDownLocationsStatus = null;
		
		try {
			avmdbi = new AVMDBI();
			
			jaDownLocationsStatus = avmdbi.getUrlDownLocationsStatus(con, loginUserBean.getUserId());
			//jaDownLocationsStatus = avmdbi.getUserDownLocationsStatus(con, loginUserBean.getUserId(), lLimit, lOffSet);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaDownLocationsStatus;
	}
	
	/**
	 * gets user's applications status 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserApplicationsStatus(Connection con, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONArray jaApplicationsStatus = null;
		
		try {
			avmdbi = new AVMDBI();
			
			jaApplicationsStatus = avmdbi.getUserApplicationsStatus(con, loginUserBean.getUserId(), joEnt);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaApplicationsStatus;
	}
	
	/**
	 * add user's AVM agent 
	 * 
	 * @param con
	 * @param avmAgentBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long addAVMAgent(Connection con, AVMAgentBean avmAgentBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		AVMDBI avmdbi = null;
		
		long lAgentId = -1L;
		
		//boolean bUserAgentLocationExists = false;
		
		try {
			avmdbi = new AVMDBI();
			
			// check user's location already exists, "-1" hardcoding since its a new insert 
			//bUserAgentLocationExists = isUserAgentLocationExists(con, avmAgentBean.getCountry(), avmAgentBean.getState(), avmAgentBean.getCity(), avmAgentBean.getRegion(), avmAgentBean.getZone(), -1, loginUserBean.getUserId());
			//if ( bUserAgentLocationExists ) {
				// throw exception, user's location already exists
			//	throw new Exception("1");
			//}
			
			// add user's location 
			lAgentId = avmdbi.insertAVMAgent(con, avmAgentBean, loginUserBean.getUserId(), joEnt);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return lAgentId;
	}
	
	/**
	 * update's user's AVM agent location for status `Just Added`
	 * 
	 * @param con
	 * @param avmAgentBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateAgentLocation(Connection con, AVMAgentBean avmAgentBean, LoginUserBean loginUserBean) throws Exception {
		AVMDBI avmdbi = null;
		
		boolean bUserAgentLocationExists = false;
		
		AVMAgentBean avmAgentStatusBean = null;
		
		try {
			avmdbi = new AVMDBI();
			
			// checks user's agent location already exists 
			bUserAgentLocationExists = isUserAgentLocationExists(con, avmAgentBean.getCountry(), avmAgentBean.getState(), avmAgentBean.getCity(), avmAgentBean.getRegion(), avmAgentBean.getZone(), avmAgentBean.getAgentId(), loginUserBean.getUserId());
			if ( bUserAgentLocationExists ) {
				// throw exception, user's location already exists
				throw new Exception("1");
			}
			
			// get status for the update agent_id 
			avmAgentStatusBean = getAgentLocation(con, avmAgentBean.getAgentId(), loginUserBean.getUserId());
			if ( ! avmAgentStatusBean.getStatus().equals("JUST_ADDED") ) {
				// throw exception, to update only for status is in `JUST_ADDED`
				throw new Exception("2");
			}
			
			// update agent's location 
			avmdbi.updateAgentLocation(con, avmAgentBean, loginUserBean.getUserId());
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets user's locations
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserLocations(Connection con, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONArray jaUserLocations = null;
		
		try {
			avmdbi = new AVMDBI();
			
			jaUserLocations = avmdbi.getUserLocations(con, loginUserBean.getUserId(), joEnt);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaUserLocations;
	}
	
	/**
	 * gets user's locations
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public void deleteAVMUserLocations(Connection con, LoginUserBean loginUserBean, AVMAgentBean avmAgentBean) throws Exception {
		AVMDBI avmdbi = null;
		
		String strUserLocations = null;
		
		try {
			avmdbi = new AVMDBI();
			
			strUserLocations = avmdbi.deleteAVMUserLocations(con, loginUserBean, avmAgentBean);
			
			if(strUserLocations.equals("AGENT_IN_USE")) {
				throw new Exception("5");
			}
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		
	}
	
	
	/**
	 * checks user's location already exists 
	 * 
	 * @param con
	 * @param strCountry
	 * @param strState
	 * @param strCity
	 * @param strRegion
	 * @param strZone
	 * @param lAgentId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public boolean isUserAgentLocationExists(Connection con, String strCountry, String strState, String strCity, String strRegion, String strZone, long lAgentId, long lUserId) throws Exception {
		AVMDBI avmdbi = null;
		
		boolean bUserAgentLocationExists = false;
		
		try {
			avmdbi = new AVMDBI();
			
			// checks user's location already exists 
			bUserAgentLocationExists = avmdbi.isUserAgentLocationExists(con, strCountry, strState, strCity, strRegion, strZone, lAgentId, lUserId);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return bUserAgentLocationExists;
	}
	
	/**
	 * gets particular agent's details
	 * 
	 * @param con
	 * @param lAgentId
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public AVMAgentBean getAgentLocation(Connection con, long lAgentId, long lUserId) throws Exception {
		AVMDBI avmdbi = null;
		
		AVMAgentBean avmAgentBean = null;
		
		try {
			avmdbi = new AVMDBI();
			
			avmAgentBean = avmdbi.getAgentLocation(con, lAgentId, lUserId);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return avmAgentBean;
	}
	
	/**
	 * adds AVM agent's alert address 
	 * 
	 * @param con
	 * @param agentAlertAddressBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean addLocationAlertAddress(Connection con, AVMAgentAlertAddressBean agentAlertAddressBean, LoginUserBean loginUserBean ,long lUser_id) throws Exception {
		HashMap<String, Object> hmMailDetails = null;
		
		String strSubject = "";
		
		boolean bLocAlertAddressAlreadyExists = false, bAddressAlreadyVerified = false, bEmailSent = false;
		
		long lAgentAlertId = -1L;
		
		AVMDBI avmdbi = null;
		AppedoMailer appedoMailer = null;
		
		try {
			avmdbi = new AVMDBI();
			appedoMailer = new AppedoMailer( Constants.EMAIL_TEMPLATES_PATH );
			
			// checks email or mobile already added for the agent 
			bLocAlertAddressAlreadyExists = avmdbi.isLocAlertAddressAlreadyExists(con, agentAlertAddressBean.getAgentId(), agentAlertAddressBean.getEmailMobile(), /*loginUserBean.getUserId()*/ lUser_id);
			if ( bLocAlertAddressAlreadyExists ) {
				// throws exception, email_mobile already added for the agent 
				throw new Exception("1");
			}
			
			// checks email_mobile already verified; for SMS default verify as `TRUE`
			if ( agentAlertAddressBean.getAlertType().equals("SMS") ) {
				// for mobile/SMS, default verify as `TRUE`; TODO: later verification SMS
				bAddressAlreadyVerified = true;
			} else {
				// checks `email` already verified 
				bAddressAlreadyVerified = avmdbi.isEmailAlreadyVerified(con, agentAlertAddressBean.getEmailMobile(), /*loginUserBean.getUserId()*/ lUser_id);	
			}
			
			// adds alert address 
			lAgentAlertId = avmdbi.insertLocationAlertAddress(con, agentAlertAddressBean, /*loginUserBean.getUserId()*/ lUser_id, bAddressAlreadyVerified);
			
			// sends email for verification 
			if ( ! bAddressAlreadyVerified && agentAlertAddressBean.getAlertType().equals("EMAIL") ) {
				hmMailDetails = new HashMap<String, Object>();
				hmMailDetails.put("USERNAME", loginUserBean.getFirstName());
				hmMailDetails.put("TYPE", "AVM");
				hmMailDetails.put("LINK", Constants.APPEDO_URL+"avm/verifyAlertEmailAddress?_aid="+CryptManager.encryptEncodeURL(lAgentAlertId+""));
				strSubject = "Appedo: Accept AVM Alerts";
				bEmailSent = appedoMailer.sendMail(MODULE_ID.SLA_VERIFY_EMAIL, hmMailDetails, agentAlertAddressBean.getEmailMobile().split(","), strSubject);
				
				UtilsFactory.clearCollectionHieracy(hmMailDetails);
			}
			
			avmdbi = null;
			strSubject = null;
		} catch (Exception e) {
			throw e;
		}
		
		return bEmailSent;
	}
	
	/**
	 * gets location's added alert addresses
	 * 
	 * @param con
	 * @param lAgentId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getLocationAlertAddresses(Connection con, long lAgentId, /*LoginUserBean loginUserBean,*/ long luser_id) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONArray jaAlertAddresses = null;
		
		try {
			avmdbi = new AVMDBI();
			
			// gets location's added alert address 
			jaAlertAddresses = avmdbi.getLocationAlertAddresses(con, lAgentId, /*loginUserBean.getUserId()*/ luser_id);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaAlertAddresses;
	}
	
	/**
	 * deletes AVM agent's alert address
	 * 
	 * @param con
	 * @param lAgentAlertId
	 * @param lAgentId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteLocationAlertAddress(Connection con, long lAgentAlertId, long lAgentId, /*LoginUserBean loginUserBean*/ long luser_id) throws Exception {
		AVMDBI avmdbi = null;
		
		try {
			avmdbi = new AVMDBI();
			
			// 
			avmdbi.deleteLocationAlertAddress(con, lAgentAlertId, lAgentId, /*loginUserBean.getUserId()*/luser_id);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * updates email address verification, 
	 *  in `SLA`, `AVM`, for address is not verified in `so_alert`, `avm_agent_alert_mapping`
	 * 
	 * @param con
	 * @param lAgentAlertId
	 * @throws Exception
	 */
	public void verifyAlertEmailAddress(Connection con, long lAgentAlertId) throws Exception {
		AVMDBI avmdbi = null;
		
		try {
			avmdbi = new AVMDBI();
			
			// 
			avmdbi.updateAlertVerificationAddress(con, lAgentAlertId);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets test's locations status 
	 * 
	 * @param con
	 * @param lTestId
	 * @param lLimit
	 * @param lOffSet
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getTestLocationsStatus(Connection con, long lTestId, long lLimit, long lOffSet, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONArray jaLocationStatus = null;
		
		try {
			avmdbi = new AVMDBI();
			
			// gets test's locations status
			jaLocationStatus = avmdbi.getTestLocationsStatus(con, lTestId, lLimit, lOffSet, loginUserBean.getUserId(), joEnt);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaLocationStatus;
	}
	
	/**
	 * get user's test summary 
	 * 
	 * @param con
	 * @param lTestId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getUserTestSummary(Connection con, long lTestId, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		AVMDBI avmdbi = null;
		
		JSONObject joUserTestSummary = null;
		
		try {
			avmdbi = new AVMDBI();
			
			joUserTestSummary = avmdbi.getUserTestSummary(con, lTestId, loginUserBean.getUserId(), joEnt);
			
			avmdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joUserTestSummary;
	}
}
