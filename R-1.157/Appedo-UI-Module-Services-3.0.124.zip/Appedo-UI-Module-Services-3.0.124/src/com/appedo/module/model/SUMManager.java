package com.appedo.module.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.SUMLicenseBean;
import com.appedo.module.bean.SUMTestBean;
import com.appedo.module.common.Constants;
import com.appedo.module.common.Constants.SUM_TYPE;
import com.appedo.module.compiler.DynamicCompilation;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.dbi.ChartDBI;
import com.appedo.module.dbi.SUMDBI;
import com.appedo.module.dbi.ServiceDBI;
import com.appedo.module.utils.UtilsFactory;

public class SUMManager {

	/**
	 * to get sum test details
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMTests(Connection con, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaSUMTests = null;

		try {
			sumdbi = new SUMDBI();

			jaSUMTests = sumdbi.getSUMTests(con, loginUserBean);
			sumdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaSUMTests;
	}

	public JSONArray getNewSUMTests(Connection con, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaSUMTests = null;

		try {
			sumdbi = new SUMDBI();

			jaSUMTests = sumdbi.getNewSUMTests(con, loginUserBean);
			sumdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaSUMTests;
	}

	/**
	 * To get the list of cities under selected country
	 * 
	 * @param con
	 * @param strCountry
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserCities(Connection con, String strCountry) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaData = new JSONArray();
		try {
			sumdbi = new SUMDBI();

			jaData = sumdbi.getUserCities(con, strCountry);
			sumdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaData;
	}
	public JSONObject getLicenseSUMDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumdbi = null;

		JSONObject jaSUMTests = null;

		try {
			sumdbi = new SUMDBI();
			jaSUMTests = sumdbi.getLicenseSUMDetails(con, loginUserBean);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			sumdbi = null;
		}
		
		return jaSUMTests;
	}
	
	public int getResponseCode(String urlString) throws MalformedURLException, IOException {
	    URL u = new URL(urlString); 
	    HttpURLConnection huc =  (HttpURLConnection)  u.openConnection(); 
	    huc.setRequestMethod("GET"); 
	    huc.connect(); 
	    return huc.getResponseCode();
	}
	
	public int getMaxTestCount(Connection con, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumDBI = null;
	
		int nUserTotalRuncount = 0;
		
		try {
			sumDBI = new SUMDBI();
			nUserTotalRuncount = sumDBI.getMaxTestCount(con, loginUserBean);
			sumDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return nUserTotalRuncount;
	}
	
	public int getMaxNodeCount(Connection con, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumDBI = null;
	
		int nUserTotalRuncount = 0;
		
		try {
			sumDBI = new SUMDBI();
			nUserTotalRuncount = sumDBI.getMaxMeasuermentCountForUser(con, loginUserBean);
			sumDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return nUserTotalRuncount;
	}
	
	/**
	 * to add the sum test details
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @param maxMeasurementPerMonth 
	 * @param strCities
	 * @throws Throwable
	 */
	public JSONObject addSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean) throws Throwable {
		SUMDBI sumdbi = null;
		
		long lTestId = -1l;
		SUMLicenseBean sumLicenseBean = null;
		JSONObject joReturn = null;
		try {
			sumdbi = new SUMDBI();
			
			sumLicenseBean = getSUMUserLicenseDetails(con, loginUserBean);
			
			if (sumLicenseBean == null) {
				// License expired for user
				throw new Exception("4");
			} else {				
				boolean bExist = sumdbi.isSUMTestExist(con, testBean, loginUserBean);

				if ( bExist ) {
					//joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. Name already exist.");
					throw new Exception("5");
				} else {
					lTestId = sumdbi.addSUMTest(con, testBean, loginUserBean);
					
					testBean.setTestId(lTestId);
					//joRtn = UtilsFactory.getJSONSuccessReturn("SUMTest added.");
					
					if( testBean.getTestType().toUpperCase().equals("TRANSACTION") ) {
						testBean.setTestClassName("sum_test_"+loginUserBean.getUserId()+"_"+lTestId);
						
						// to create dynamic java file for test
						joReturn = (new DynamicCompilation()).makeFile(testBean.getSeleniumScriptPackages(), testBean.getTransaction(), testBean.getTestClassName());
						
						if(joReturn.getBoolean("success")){
							// export class file to scheduler
							exportClassFile(Constants.SELENIUM_SCRIPT_CLASS_FILE_PATH+testBean.getTestClassName()+".class",testBean.getTestClassName()+".class");
							
							// update file name in sum master table 
							sumdbi.updateSUMTestFileName(con, testBean, loginUserBean);
							
							//sumdbi.addClusters(con, lTestId, testBean.getTargetLocations());
							
							// Test gets run for the URL in the given regions
							if(lTestId != -1) {
								sumdbi.addClusters(con, lTestId, testBean.getTargetLocations());
							}
						}
					}else{
						
						// update file name in sum master table 
						sumdbi.updateSUMTestFileName(con, testBean, loginUserBean);
						
						// Test gets run for the URL in the given regions
						if(lTestId != -1) {
							sumdbi.addClusters(con, lTestId, testBean.getTargetLocations());
						}
						joReturn = UtilsFactory.getJSONSuccessReturn("");
					}
					joReturn.put("sum_test_id", lTestId);
				}
			}
			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joReturn;
	}
	
	public JSONObject addNewSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Throwable {
		SUMDBI sumdbi = null;
		SUM_TYPE sumType = null;

		long lTestId = -1l;
		SUMLicenseBean sumLicenseBean = null;
		JSONObject joReturn = null;
		try {
			sumdbi = new SUMDBI();

			sumLicenseBean = getSUMUserLicenseDetails(con, loginUserBean);

			if (sumLicenseBean == null) {
				// License expired for user
				throw new Exception("4");
			} else {
				boolean bExist = sumdbi.isSUMTestExist(con, testBean, loginUserBean);

				if (bExist) {
					// joRtn = UtilsFactory.getJSONFailureReturn("Unable to add. Name already exist.");
					throw new Exception("5");
				} else {
					lTestId = sumdbi.addNewSUMTest(con, testBean, loginUserBean, joEnterprise);

					testBean.setTestId(lTestId);
					// joRtn = UtilsFactory.getJSONSuccessReturn("SUMTest added.");

					if (testBean.getTestType().toUpperCase().equals("TRANSACTION")) {
						testBean.setTestClassName("sum_test_"+ loginUserBean.getUserId() + "_" + lTestId);

						// to create dynamic java file for test
						joReturn = (new DynamicCompilation()).makeFile(testBean.getSeleniumScriptPackages(), testBean.getTransaction(), testBean.getTestClassName());
						
						if (joReturn.getBoolean("success")) {
							// export class file to scheduler
							exportClassFile(Constants.SELENIUM_SCRIPT_CLASS_FILE_PATH+ testBean.getTestClassName()+ ".class",testBean.getTestClassName() + ".class");
							
							// update file name in sum master table
							sumdbi.updateSUMTestFileName(con, testBean, loginUserBean);

							// sumdbi.addClusters(con, lTestId, testBean.getTargetLocations());

							// Test gets run for the URL in the given regions
							// if Response Monitor is disabled then, no need to fetch existing SUM-Locations
							if (lTestId != -1 && testBean.isStatus()) {
								sumdbi.addClusters(con, lTestId, testBean.getTargetLocations());
							}
						}
					} else {
						// update file name in sum master table
						sumdbi.updateSUMTestFileName(con, testBean, loginUserBean);

						// Test gets run for the URL in the given regions
						// if Response Monitor is disabled then,
						//  no need to fetch existing SUM-Locations
						if (lTestId != -1 && testBean.isStatus()) {
							sumdbi.addClusters(con, lTestId, testBean.getTargetLocations());
						}
						joReturn = UtilsFactory.getJSONSuccessReturn("");
					}
					if (lTestId != -1) {
						sumdbi.addBrowserToSUMTest(con, lTestId, testBean.getDobIds());

						// Map the added SUM test, to system Service Map
						mapSUMTestToSystemServiceMap(con, testBean, loginUserBean);

						// Configure SUM test to SLA for alerts - Response Monitor
						if (testBean.isResponseAlert()) {
							sumType = SUM_TYPE.RESPONSE_MONITORING;
							configureSLAPolicyMapToSUMTest(testBean, loginUserBean, sumType, joEnterprise);

							// Update the response_monitor's Sla id's in sum test master while adding.
							sumdbi.updateSlaIdInSumTestMaster(con, testBean, loginUserBean);
						}
					}
					
					//Insert chart data query to chart visualization table
					if (lTestId > 0 && testBean.getTestType().toUpperCase().equals("URL"))
					{
						sumdbi.insertChartVisualizationDataSUM(con, testBean, loginUserBean, UtilsFactory.generateSUMChartVisualizationQuery(lTestId));
					}

					joReturn.put("sum_test_id", lTestId);
				}
			}
			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}

		return joReturn;
	}

	public JSONObject ishavingSUMURLTest(Connection con, String strUrl, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumDBI = null;

		JSONObject joSUMURLTest = null;
		
		try{
			sumDBI = new SUMDBI();
			
			joSUMURLTest = sumDBI.ishavingSUMURLTest(con, strUrl, loginUserBean.getUserId());
			
			sumDBI = null;
		}catch(Exception e){
			throw e;
		}
		
		return joSUMURLTest;
	}
	
	public boolean sendTestToScheduler(SUMTestBean testBean, boolean deleteStatus) throws Exception {
		boolean bReturn = false;
		
		WebServiceManager wsm = null;
		
		try{
			// Test gets run for the URL in the given regions
			if(testBean.getTestId() != -1) {
				wsm = new WebServiceManager();
				if(testBean.getTestType().equalsIgnoreCase("URL")){
					wsm.sendRequest (Constants.APPEDO_WPT_SCHEDULER+"addEditEnterprise?testid="+testBean.getTestId()+"&status="+testBean.isStatus()+(deleteStatus?"&delStatus=deleted":""), null);
				}else{
					wsm.sendRequest (Constants.APPEDO_WPT_SCHEDULER+"addEditEnterprise?testid="+testBean.getTestId()+"&status="+testBean.isStatus()+(deleteStatus?"&delStatus=deleted":""), null);
				}
				
				int statusCode = wsm.getStatusCode();
				
				if( statusCode != HttpStatus.SC_OK ) {
					throw new Exception("Exception in Scheduler: "+wsm.getResponse());	// TODO Inform that Service has problem
				}
			}
			
			bReturn = true;
		} catch (Throwable th) {
			LogManager.errorLog(th);
			bReturn = false;
		} finally {
			wsm = null;
		}
		
		return bReturn;
	}
	
	/**
	 * adds SLA policy and map to SUM test,
	 * Note: only one SLA can configured for a SUM test, in other sense we can't have a SUM test  for multiple SLAs 
	 *   (i.e. sum_test_id is unique in `so_sla_sum`)
	 * 
	 * @param sumTestBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void configureSLAPolicyMapToSUMTest(SUMTestBean sumTestBean, LoginUserBean loginUserBean, SUM_TYPE sumType, JSONObject joEnt) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			
			// add SLA policy
			System.out.println(sumTestBean.toJSON());

			wsm.addParameter("policyName", sumTestBean.getTestName()+ " SUM SLA Policy");
			wsm.addParameter("enable_alert", (sumTestBean.isStatus() && sumTestBean.isResponseAlert())+"");
			wsm.addParameter("min_breach_count", sumTestBean.getRmMinBreachCount()+"");

			wsm.addParameter("policyDesc", sumTestBean.getTestName() + Constants.SLA_AUTOGEN_DEFAULT_LASTNAME);
			//wsm.addParameter("policySvrType", sumTestBean.getTestName()+" SLA Policy");
			wsm.addParameter("alertType", Constants.SLA_AUTOGEN_DEFAULT_TYPE);
			
			// map SUM test thresholds to SLA policy
			//wsm.addParameter("sla_id", sumTestBean.getSLAId());
			wsm.addParameter("sum_test_id", sumTestBean.getTestId()+"");
			wsm.addParameter("is_above_threashold", true+"");
			wsm.addParameter("sum_counter_name", "pageloadtime");
			wsm.addParameter("warning_limit", sumTestBean.getWarningLimit()+"");
			wsm.addParameter("error_limit", sumTestBean.getErrorLimit()+"");
			wsm.addParameter("sum_type", sumType.toString());
			
			// add Enterprise Details
			wsm.addParameter("EnterpriseDetails", joEnt.toString());
			
			// web service request
			//wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES + "/sla/configureSLAToSUMTestForThresholdBreach");
			wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES + "/sla/configureSLAToSUMTestForThresholdBreach");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());

				if (joResp.getBoolean("success")) {

					if (joResp.containsKey("slaId")) {
						sumTestBean.setRmSLAId(joResp.getLong("slaId"));
					}
				}

			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
				LogManager.infoLog("SLA policy added and mapped to SUM test.");
			} else {
				// exception in SLA
				throw new Exception("Unable to add SLA policy & map to SUM test.");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	public void updateSLAPolicyMapToSUMTest(SUMTestBean sumTestBean, LoginUserBean loginUserBean) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			
			// add SLA policy
			wsm.addParameter("policyName", sumTestBean.getTestName()+" SUM SLA Policy");
			wsm.addParameter("policyDesc", sumTestBean.getTestName() + Constants.SLA_AUTOGEN_DEFAULT_LASTNAME);
			//wsm.addParameter("policySvrType", sumTestBean.getTestName()+" SLA Policy");
			wsm.addParameter("alertType", Constants.SLA_AUTOGEN_DEFAULT_TYPE);
			
			// map SUM test thresholds to SLA policy
			wsm.addParameter("sla_id", sumTestBean.getSLAId()+"");
			wsm.addParameter("sum_test_id", sumTestBean.getTestId()+"");
			wsm.addParameter("is_above_threashold", true+"");
			wsm.addParameter("sum_counter_name", "pageloadtime");
			wsm.addParameter("warning_limit", sumTestBean.getWarningLimit()+"");
			wsm.addParameter("error_limit", sumTestBean.getErrorLimit()+"");
			wsm.addParameter("min_breach_count", sumTestBean.getRmMinBreachCount()+"");
			
			// web service request
			wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES + "/sla/updateSLAPolicyMapToSUMTestForThresholdBreach");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());
			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
				LogManager.infoLog("SLA policy and map SUM test updated .");
			} else {
				// exception in SLA
				throw new Exception("Unable to update SLA policy & map SUM test.");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	public boolean deleteSUMTestForSlaPolicy(SUMTestBean testBean,HttpServletRequest request) throws Exception {
		boolean bReturn = false;
		WebServiceManager wsm = null;
		
		try{
			// Test gets run for the URL in the given regions
			if(testBean.getTestId() != -1) {
				request.setAttribute("sum_test_id", testBean.getTestId());
				
				wsm = new WebServiceManager();
				wsm.sendRequest (Constants.APPEDO_UI_SLA_SERVICES+"/sla/deleteSlaSum", request);
				int statusCode = wsm.getStatusCode();
				if( statusCode != HttpStatus.SC_OK ) {
					throw new Exception("Exception in Deleting Service Map in SLA(deleteSlaSum): "+wsm.getResponse());	// TODO Inform that Service has problem
				}else{
					bReturn = false;
				}
			}
		} catch (Throwable th) {
			LogManager.errorLog(th);
			bReturn = false;
		} finally {
			wsm = null;
		}
		
		return bReturn;
	}
	
	/**
	 * maps added SUM test, to the user's system generated Service Map 
	 * 
	 * @param testBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	/*public boolean mapSUMTestToSystemServiceMap(SUMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		WebServiceManager wsm = null;
		
		boolean bModuleMapped = false;
		
		JSONObject joResp = null;
		
		try {
			//wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			wsm.addParameter("moduleDetails", "{\"module_master\":{\"module_code\":\"SUM\",\"test_id\":"+testBean.getTestId()+"}}");
			wsm.sendRequest (Constants.MODULE_UI_SERVICES+"/service/mapModuleToSystemServiceMap");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());
			} else {
				throw new Exception("Problem with Module Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
				bModuleMapped = true;
			} else {
				// exception in Module Services 
				throw new Exception("Unable to map the test to system Service Map.");
			}
			
		} catch (Exception e) {
			bModuleMapped = false;
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
		
		return bModuleMapped;
	}*/
	
	public void mapSUMTestToSystemServiceMap(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean) throws Exception {
		ServiceManager serviceManager = null;
		
		try {
			serviceManager = new ServiceManager();
			serviceManager.mapModuleToSystemServiceMap(con, JSONObject.fromObject("{\"module_master\":{\"module_code\":\""+Constants.SUM_MODULE+"\",\"test_id\":"+testBean.getTestId()+"}}"), loginUserBean);
		} catch (Exception e) {
			throw e;
		} finally {
			serviceManager = null;
		}
	}

	/**
	 * To export the har file to ftp
	 * @param filePath
	 * @param strTargetHarFile
	 * @throws Throwable
	 */
	
	public JSONObject exportClassFile(String filePath,String strClassFileName)  {
		
		
		int BUFFER_SIZE = 4096;
		FileInputStream inputStream = null;
		OutputStream outputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader reader = null;
		JSONObject joResponse = new JSONObject();
		 
		 try {
			 
			 joResponse.put("success", true);
			 
			// takes file path from input parameter
			File uploadFile = new File(filePath);
			 
			String UPLOAD_URL = Constants.CLASS_EXPORT_URL;
			// creates a HTTP connection
	       URL url = new URL(UPLOAD_URL);
	       HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
	       httpConn.setUseCaches(false);
	       httpConn.setDoOutput(true);
	       httpConn.setRequestMethod("POST");
	       // sets file name as a HTTP header	       
	       httpConn.setRequestProperty("command", "UPLOAD");
	       httpConn.setRequestProperty("class-name", strClassFileName);
	       
	       // opens output stream of the HTTP connection for writing data
	       outputStream = httpConn.getOutputStream();
	       
	       // Opens input stream of the file for reading data
	       inputStream = new FileInputStream(uploadFile);
	       
	       byte[] buffer = new byte[BUFFER_SIZE];
	       int bytesRead = -1;
	       
	       LogManager.infoLog("Upload started...");
	       
	       while ((bytesRead = inputStream.read(buffer)) != -1) {
		            outputStream.write(buffer, 0, bytesRead);
		        }
	       
	       LogManager.infoLog("Upload succeded.");
	       
	       
	       // always check HTTP response code from server
	       int responseCode = httpConn.getResponseCode();
	       
	       if (responseCode == HttpURLConnection.HTTP_OK) {
	    	   // reads server's response
	    	   	inputStreamReader = new InputStreamReader(httpConn.getInputStream());
				reader = new BufferedReader(inputStreamReader);
				   
		    } else {
		            LogManager.infoLog("Server returned non-OK code: " + responseCode);
		            joResponse.put("success", false);
		    }
		 }catch(Throwable t) {
			 LogManager.errorLog(t);
			 joResponse.put("success", false);
		 }finally {

			 UtilsFactory.close(outputStream);
			 outputStream = null;
			 UtilsFactory.close(inputStream);
			 inputStream = null;
			 UtilsFactory.close(reader);
			 reader = null;
			 UtilsFactory.close(inputStreamReader);
			 inputStreamReader = null;
		 }
		 
		 return joResponse;
	}
	/**
	 * to update sum test details
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @param saCities
	 * @throws Throwable 
	 */
	public JSONObject updateSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean, String strAppedoScheduler) throws Throwable {
		SUMDBI sumdbi = null;
		
		SUMLicenseBean sumLicenseBean = null;
		JSONObject joReturn = null;
		try {
			sumdbi = new SUMDBI();
			

			sumLicenseBean = getSUMUserLicenseDetails(con, loginUserBean);
			
			if (sumLicenseBean == null) {
				// License expired for user
				throw new Exception("4");
			} else {
				boolean bExist = sumdbi.isSUMTestExist(con, testBean, loginUserBean,true);
				
				if(bExist){
					// Unable to Update. Name already exist.
					throw new Exception("5");
				} else {
					sumdbi.updateSUMTest(con, testBean, loginUserBean);
					//joRtn = UtilsFactory.getJSONSuccessReturn("SUMTest updated.");
					

					if( testBean.getTestType().toUpperCase().equals("TRANSACTION") ) {
						testBean.setTestClassName("sum_test_"+loginUserBean.getUserId()+"_"+testBean.getTestId());
						
						// to create dynamic java file for test
						joReturn = (new DynamicCompilation()).makeFile(testBean.getSeleniumScriptPackages(), testBean.getTransaction(), testBean.getTestClassName());
						LogManager.infoLog("joReturn"+joReturn.toString());
						if(joReturn.getBoolean("success")){
							// export class file to scheduler
							exportClassFile(Constants.SELENIUM_SCRIPT_CLASS_FILE_PATH+testBean.getTestClassName()+".class",testBean.getTestClassName()+".class");
							
							// update file name in sum master table 
							sumdbi.updateSUMTestFileName(con, testBean, loginUserBean);
							
							sumdbi.updateClusters(con, testBean.getTestId(), testBean.getTargetLocations());
						}
					}else{
						
						// update file name in sum master table 
						sumdbi.updateSUMTestFileName(con, testBean, loginUserBean);
						
						sumdbi.updateClusters(con, testBean.getTestId(), testBean.getTargetLocations());
						
						joReturn = UtilsFactory.getJSONSuccessReturn("");
					}
					
				}
			}

			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return joReturn;
	}

	public JSONObject updateNewSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean, String strAppedoScheduler, HttpServletRequest request, JSONObject joEnt) throws Throwable {
		SUMDBI sumdbi = null;

		SUMLicenseBean sumLicenseBean = null;
		JSONObject joReturn = null;
		String oldTestName = null;
		try {
			sumdbi = new SUMDBI();

			// Verify License
			sumLicenseBean = getSUMUserLicenseDetails(con, loginUserBean);

			// License expired for user
			if (sumLicenseBean == null) {
				throw new Exception("4");
			}

			// Verify for duplicate SUM Test Name.
			boolean bExist = sumdbi.isSUMTestExist(con, testBean, loginUserBean, true);
			if (bExist) {
				throw new Exception("5");
			}
			//Get previous test name of SUM
			oldTestName = sumdbi.getPreviousTestName(con, testBean.getTestId());
			
			// Update the SUM-Master table
			sumdbi.updateNewSUMTest(con, testBean, loginUserBean);

			// Compile the Transaction code
			if (testBean.getTestType().toUpperCase().equals("TRANSACTION")) {
				testBean.setTestClassName("sum_test_"+ loginUserBean.getUserId() + "_" + testBean.getTestId());

				// to create dynamic java file for test
				joReturn = (new DynamicCompilation()).makeFile(testBean.getSeleniumScriptPackages(), testBean.getTransaction(), testBean.getTestClassName());

				// export class file to scheduler
				if (joReturn.getBoolean("success")) {
					exportClassFile(Constants.SELENIUM_SCRIPT_CLASS_FILE_PATH+ testBean.getTestClassName() + ".class", testBean.getTestClassName() + ".class");
				}
			}

			// Proceed further, if Test is URL (or) Transaction's compilation is fine
			if (joReturn == null || joReturn.getBoolean("success")) {
				// update Class's file name in sum master table
				sumdbi.updateSUMTestFileName(con, testBean, loginUserBean);

				// Update Locations, if Response Monitor is enabled
				if (testBean.isStatus()) {
					sumdbi.updateClusters(con, testBean.getTestId(), testBean.getTargetLocations());
				}

				// Update Browsers list
				sumdbi.updateBrowserToSUMTest(con, testBean.getTestId(), testBean.getDobIds());

				// Configure SLA Alerts, add/update SLA references - Response Monitor
				configureSLAPolicyMapToSUMTest(testBean, loginUserBean, SUM_TYPE.RESPONSE_MONITORING, joEnt);
				
				if ( testBean.getTestType().toUpperCase().equals("URL") ) {
					sumdbi.updateChartVisualizationDataSUM(con, testBean, loginUserBean);
					if (!oldTestName.equalsIgnoreCase(testBean.getTestName())) {
						sumdbi.updateChartVisualizationDataSUMTestName(con, testBean, loginUserBean, oldTestName);
					}
				}

				joReturn = UtilsFactory.getJSONSuccessReturn("");
			}
		} catch (Exception e) {
			throw e;
		}

		return joReturn;
	}

	public SUMLicenseBean getSUMUserLicenseDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumdbi = null;

		SUMLicenseBean sumLicenseBean = null;
		
		try {
			sumdbi = new SUMDBI();
			
			// gets license details from month wise table
			sumLicenseBean = sumdbi.getSUMUserWiseLicenseMonthWise(con, loginUserBean);
			
			if(sumLicenseBean != null) {
				// get license details from `sum config params`
				SUMLicenseBean sumLicenseBeanConfigParams = sumdbi.getSUMLicenseConfigParameters(con, loginUserBean);

				sumLicenseBean.setLicInternalName(sumLicenseBeanConfigParams.getLicInternalName());
				sumLicenseBean.setLicExternalName(sumLicenseBeanConfigParams.getLicExternalName());
				sumLicenseBean.setMaxTest(sumLicenseBeanConfigParams.getMaxTest());
				sumLicenseBean.setAllowTransaction(sumLicenseBeanConfigParams.isAllowTransaction());
				sumLicenseBean.setAllowURL(sumLicenseBeanConfigParams.isAllowURL());
				sumLicenseBean.setMaxLocation(sumLicenseBeanConfigParams.getMaxLocation());
				sumLicenseBean.setReportRetentionInDays(sumLicenseBeanConfigParams.getReportRetentionInDays());
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return sumLicenseBean;
	}
	/**
	 * to get list of countries which is available in the master table
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserCountries(Connection con) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaData = new JSONArray();
		try {
			sumdbi = new SUMDBI();

			jaData = sumdbi.getUserCountries(con);
			
			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaData;
	}
	
	/**
	 * to get list of countries which is available in the master
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getNodes(Connection con, long lTestid) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaData = null;
		
		try {
			sumdbi = new SUMDBI();

			jaData = sumdbi.getNodes(con, lTestid);

			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaData;
	}
	
	/**
	 * to delete test from the table
	 * 
	 * @param con
	 * @param testBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteSUMTest(Connection con, SUMTestBean testBean, LoginUserBean loginUserBean, String strAppedoScheduler,HttpServletRequest request) throws Exception {
		SUMDBI sumdbi = null;
		ServiceDBI serviceMapDBI = null;
		try {
			sumdbi = new SUMDBI();
			serviceMapDBI = new ServiceDBI();

			// deletes the SUM test's which is mapped from service map(s)
			serviceMapDBI.deleteMappedModuleReferences(con, "SUM", testBean.getTestId(), loginUserBean.getUserId());
			
			sumdbi.deleteSUMTest(con, testBean, loginUserBean);
			
			// Delete My charts details view 
			sumdbi.deleteMyChartDetails(con, testBean.getTestId(), loginUserBean.getUserId());
			
			deleteSUMTestForSlaPolicy(testBean,request);
			
			sumdbi = null;
			serviceMapDBI = null;
		} catch (Exception e) {
			throw e;
		} finally {
			sumdbi = null;
		}
	}
	
	public  void deleteHarRepo(String strTestId) throws IOException  {
		InputStreamReader inputStreamReader = null;
		BufferedReader reader = null;
		
		try {
			// creates a HTTP connection
	        URL url = new URL(Constants.HAR_REPOSITORY_URL);
	        HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
	        httpConn.setUseCaches(false);
	        httpConn.setDoOutput(true);
	        httpConn.setRequestMethod("POST");
	        
	        httpConn.setRequestProperty("test_id", strTestId);
	        
	        httpConn.connect();
	        
	       // always check HTTP response code from server
	        int responseCode = httpConn.getResponseCode();
	        
	        if (responseCode == HttpURLConnection.HTTP_OK) {
	        	// reads server's response
	        	inputStreamReader = new InputStreamReader(httpConn.getInputStream());
	        	reader = new BufferedReader(inputStreamReader);
	        	
		            
		    } else {
		            LogManager.infoLog("Server returned non-OK code: " + responseCode);
		    }
		 }catch(Exception t) {
			 LogManager.infoLog("Exception in uploadFile() :"+t.getMessage());
		 }finally {
			 UtilsFactory.close(reader);
			 reader = null;
			 UtilsFactory.close(inputStreamReader);
			 inputStreamReader = null;
		 }
	}
	public JSONArray getSUMMultiDropDown(Connection con, long userId) throws Exception{
        SUMDBI sumdbi = null;
        JSONArray json = null;

        try {
                sumdbi = new SUMDBI();
                json = sumdbi.getSUMMultiDropDown(con,userId);
                sumdbi = null;
        } catch (Exception e) {
                LogManager.errorLog(e);
                throw e;
        }
        return json;
	}
	
	public JSONObject getSUMMultiLine(Connection con, String strTestId, String strPageId, String strPageName, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, LoginUserBean loginUserBean) throws Exception {
        SUMDBI sumdbi = null;
        
        JSONArray jaChartData = null;
        JSONObject joBreachedThresholdLimits = null, joResult = new JSONObject();
        
        try {
            sumdbi = new SUMDBI();
            
            // gets chart data
            jaChartData = sumdbi.getSUMMultiLine(con, strTestId, strPageId, strPageName, strInterval, lStartDateTimeInMills, lEndDateTimeInMills);
            
            // gets test's breached threshold limit
            joBreachedThresholdLimits = sumdbi.getTestBreachedThresholdLimits(con, Long.parseLong(strTestId), strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
            
            joResult.put("chartData", jaChartData);
            joResult.put("sla_threshold_limits", joBreachedThresholdLimits);
            
            sumdbi = null;
        } catch (Exception e) {
            throw e;
        }
		return joResult;
	}

	public JSONObject getSUMChartData_v1(Connection con, long lTestId, String strPageId, String strPageName, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, long lUserId, Long lMetricId, String location) throws Exception {
        SUMDBI sumdbi = null;
        ChartDBI chartDBI = null;
        
        JSONObject joSUMData = null, joResult = new JSONObject();
        String chartQuery = null;
        
        try {
            sumdbi = new SUMDBI();
            chartDBI = new ChartDBI();
            if (lMetricId == null) {
            	throw new Exception("1");
            }
            chartQuery = chartDBI.getChartDataQuery(con, lUserId, lMetricId);
            // gets chart data
            joSUMData = sumdbi.getSUMChartData_v1(con, lTestId, strPageId, strPageName, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, chartQuery, location);
            
            joResult.put("chartdata", joSUMData);
            
            chartDBI = null;
            sumdbi = null;
        } catch (Exception e) {
            throw e;
        }
		return joResult;
	}
	
	public JSONObject getSUMMultiLineWithLocationBrowserConnection(Connection con, String strTestId, String strPageId, String strPageName, String strInterval) throws Exception {
        SUMDBI sumdbi = null;
        JSONObject json = null;

        try {
            sumdbi = new SUMDBI();
            json = sumdbi.getSUMMultiLineWithLocationBrowserConnection(con, strTestId, strPageId, strPageName, strInterval);
            sumdbi = null;
        } catch (Exception e) {
            LogManager.errorLog(e);
            throw e;
        }
		return json;
	}

	public JSONObject getSUMMultiLineWithDateRange(Connection con, String strTestId, String strPageId, String strPageName, String strStartDate, String strEndDate) throws Exception {
        SUMDBI sumdbi = null;
        JSONObject json = null;

        try {
            sumdbi = new SUMDBI();
            json = sumdbi.getSUMMultiLineWithDateRange(con, strTestId, strPageId, strPageName, strStartDate, strEndDate);
            sumdbi = null;
        } catch (Exception e) {
            LogManager.errorLog(e);
            throw e;
        }
		return json;
	}

	public boolean isResultAvailable(Connection con, String strTestId) throws Exception {
		SUMDBI sumdbi = null;
        boolean is_exist = false;

        try {
            sumdbi = new SUMDBI();
            is_exist = sumdbi.isResultAvailable(con, Long.valueOf(strTestId));
            sumdbi = null;
        } catch (Exception e) {
            LogManager.errorLog(e);
            throw e;
        }
		return is_exist;
	}
	public JSONArray getSumLicense(Connection con, long userId) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray json = null;

		try {
			sumdbi = new SUMDBI();
			json = sumdbi.getSumLicense(con, userId);
			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return json;
	}

	public JSONArray getSumSummary(Connection con, long lUserId, String strModuleCode) throws Exception {
		SUMDBI sumdbi = null;
		
		JSONArray jaSummary = null;

		try {
			sumdbi = new SUMDBI();

			switch (strModuleCode) {
				case "TestType":
					jaSummary = sumdbi.getSUMSummaryBasedOnType(con, lUserId, strModuleCode);
					break;
				case "TestStatus":
					jaSummary = sumdbi.getSUMSummaryBasedOnStatus(con, lUserId, strModuleCode);
					break;
				case "Mst":
					jaSummary = sumdbi.getSUMSummaryBasedOnMeasurement(con, lUserId, strModuleCode);
					break;
			}
			
			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaSummary;
	}
	
	public JSONArray getSUMDetailsDropDown(Connection con, long userId, JSONObject joEnt) throws Exception {
		SUMDBI sumdbi = null;
		JSONArray json = null;

		try {
			sumdbi = new SUMDBI();
			json = sumdbi.getSUMDetailsDropDown(con, userId, joEnt);
			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return json;
	}

	public JSONArray getSUMWorldMap(Connection con, long userId) throws Exception {
		SUMDBI sumdbi = null;
		JSONArray json = null;

		try {
			sumdbi = new SUMDBI();
			json = sumdbi.getSUMWorldMap(con, userId);
			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return json;
	}

	public static void main(String[] args) {
		System.out.println(String.valueOf(219l));
	}
	
	public boolean validateSUMTestName(Connection con, SUMTestBean sumBean, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumdbi = null;
		boolean bExists = false;
		
		try {
			sumdbi = new SUMDBI();
			
			// as new insert checks user's sum test already exists, "-1" hardcoding since its a new insert
			bExists = sumdbi.validateSUMTestName(con, sumBean.getTestName(), sumBean.getTestId(), loginUserBean);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bExists;
	}


	public JSONArray getSUMTestsResults(Connection con, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaSUMTests = null;

		try {
			sumdbi = new SUMDBI();

			jaSUMTests = sumdbi.getSUMTestsResults(con, loginUserBean);
			
			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaSUMTests;
	}
	
	public String getSumAvgPageLoadTimeDonutCount(Connection con, LoginUserBean loginUserBean,String interval) throws Exception {
		SUMDBI sumdbi = null;

		String donutCount = null;

		try {
			sumdbi = new SUMDBI();

			donutCount = sumdbi.getSumAvgPageLoadTimeDonutCount(con, loginUserBean,interval);
			
			sumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return donutCount;
	}
	
	/**
	 * to get the sum test result page names which is available in the table
	 * 
	 * @param con
	 * @param lTestId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMTestPages(Connection con, Long lTestId) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaSUMTests = null;

		try {
			sumdbi = new SUMDBI();

			jaSUMTests = sumdbi.getSUMTestPages(con, lTestId);
			sumdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jaSUMTests;
	}
	
	/**
	 * gets available SUM nodes, private nodes configured by a user also retrieved
	 * 
	 * @param con
	 * @param lTestId
	 * @param lUserId
	 * @param dobId 
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSUMNodes(Connection con, long lTestId, long lUserId, String dobId) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaNodes = null;
		
		try {
			sumdbi = new SUMDBI();

			jaNodes = sumdbi.getSUMNodes(con, lTestId, lUserId, dobId);

			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}

		return jaNodes;
	}
	
	public void saveQuickSUMDetails(Connection con, HashMap<String, String> joQuickSUMDetails) throws Exception {
		
		SUMDBI sumdbi = null;

		try {
			sumdbi = new SUMDBI();

			sumdbi.saveQuickSUMDetails(con, joQuickSUMDetails);

			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	public JSONArray getQuickSUMNodes(Connection con, String strDeviceType) throws Exception {
		SUMDBI sumdbi = null;

		JSONArray jaNodes = null;

		try {
			sumdbi = new SUMDBI();

			jaNodes = sumdbi.getQuickSUMNodes(con, strDeviceType);

			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}

		return jaNodes;
	}

	public String getSUMConnectivity(Connection con) throws Exception {
		SUMDBI sumdbi = null;
		String jsonString = null;
		try {
			sumdbi = new SUMDBI();

			jsonString = sumdbi.getSUMConnectivity(con);

			sumdbi = null;
		} catch (Exception e) {
			jsonString = null;
			throw e;
		}

		return jsonString;
	}

	public String getSUMDeviceTypes(Connection con) throws Exception {
		SUMDBI sumdbi = null;
		String jsonString = null;
		try {
			sumdbi = new SUMDBI();

			jsonString = sumdbi.getSUMDeviceTypes(con);

			sumdbi = null;
		} catch (Exception e) {
			jsonString = null;
			throw e;
		}

		return jsonString;
	}

	public String getSUMOsNames(Connection con,String deviceType) throws Exception {
		SUMDBI sumdbi = null;
		String jsonString = null;
		try {
			sumdbi = new SUMDBI();

			jsonString = sumdbi.getSUMOsNames(con,deviceType);

			sumdbi = null;
		} catch (Exception e) {
			jsonString = null;
			throw e;
		}

		return jsonString;
	}

	public String getSUMBrowserNames(Connection con,String deviceType,String osName) throws Exception {
		SUMDBI sumdbi = null;
		String jsonString = null;
		try {
			sumdbi = new SUMDBI();

			jsonString = sumdbi.getSUMBrowserNames(con,deviceType,osName);

			sumdbi = null;
		} catch (Exception e) {
			jsonString = null;
			throw e;
		}

		return jsonString;
	}

	public JSONObject getSUMTestDetails(Connection con, long lSUMTestId, LoginUserBean loginUserBean) throws Exception {
		SUMDBI sumdbi = null;
		
		JSONObject joSUMTestDetails = null;
		
		try {
			sumdbi = new SUMDBI();
			
			joSUMTestDetails = sumdbi.getSUMTestDetails(con, lSUMTestId, loginUserBean);
			
			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joSUMTestDetails;
	}
	
	public JSONArray getFirstByte(Connection con, long lharId) throws Exception {
		SUMDBI sumdbi = null;
		
		JSONArray jaFirstByte = null;
		
		try {
			sumdbi = new SUMDBI();
			
			jaFirstByte = sumdbi.getFirstByte(con, lharId);
			
			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaFirstByte;
	}
	
	/**
	 * To fetch WPT urls for `Content Breakdown` and `domain Breakdown`
	 * 
	 * @param con
	 * @param lharId
	 * @return
	 * @throws Exception
	 */
	public JSONObject fetchScreen(Connection con, long lharId) throws Exception {
		SUMDBI sumdbi = null;
		JSONObject jaScreens = null;
		ResultSet rst = null;
		try {
			sumdbi = new SUMDBI();
			rst = sumdbi.fetchScreenRst(con, lharId);
			
			// `WPT SERVER` is restricted for the public access, only node machines and Appedo-UI instance can access it,
			// Hence, to avoid exposing the WPT's DNS in UI, WPT's url is replaced with the redirector url like below. 
			// Ex: Replace `https://wpt.appedo.com/` as `https://apm.appedo.com/appedo/wpt/`
			// Now `Content  Breakdown` and `Domains Breakdown` screens from WPT SERVER were rendered in APPEDO-UI through redirection.
			
			if (rst.next()) {
				jaScreens = new JSONObject();
				
				jaScreens.put("fSnapshot", replaceWptUrlWithRedirector(rst.getString("fView_Screen")));
				jaScreens.put("rSnapshot", replaceWptUrlWithRedirector(rst.getString("rView_Screen")));
				jaScreens.put("breakdown", replaceWptUrlWithRedirector(rst.getString("breakdown")));
				jaScreens.put("domains", replaceWptUrlWithRedirector(rst.getString("domains")));
			}
			sumdbi = null;
		} catch (Exception e) {
			throw e;
		}finally {
			DataBaseManager.close(rst);
			rst = null;

		}
		return jaScreens;
	}
	
	/**
	 * Get the Failure records of the given SUM Test.
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param strTestId
	 * @param strLocation
	 * @param strInterval
	 * @param strStartDate
	 * @param strEndDate
	 * @return
	 * @throws Throwable
	 */
	public JSONArray[] getSUMTestUnavailability(Connection con, LoginUserBean loginUserBean, String strTestId, String strInterval, String strStartDate, String strEndDate) throws Throwable {
		SUMDBI sumdbi = null;
		JSONArray[] jaSUMHeartBeatresults = null;
		
		try {
			sumdbi = new SUMDBI();
			jaSUMHeartBeatresults = sumdbi.getSUMTestUnavailability(con, loginUserBean, strTestId, strInterval, strStartDate, strEndDate);
		} catch (Throwable th) {
			throw th;
		}
		
		return jaSUMHeartBeatresults;
	}
	
	public String replaceWptUrlWithRedirector(String url) {
		JSONArray wptAppedoRedirector = null;
		
		if (url != null) {
			wptAppedoRedirector = Constants.WPT_APPEDO_REDIRECTOR;
			for (int i = 0; i < wptAppedoRedirector.size(); i++) {
				url = url.replace(wptAppedoRedirector.getJSONObject(i).getString("wpt_server_url"), 
						wptAppedoRedirector.getJSONObject(i).getString("redirector_url"));
			}
		}
		
		return url;
	}
}