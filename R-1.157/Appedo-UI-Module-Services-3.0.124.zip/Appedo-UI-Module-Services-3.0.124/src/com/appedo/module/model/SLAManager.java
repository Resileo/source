package com.appedo.module.model;

import java.sql.Connection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpStatus;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.commons.manager.AppedoMailer;
import com.appedo.commons.manager.AppedoMailer.MODULE_ID;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.MapCounterBean;
import com.appedo.module.bean.ModuleBean;
import com.appedo.module.bean.RUMSLABean;
import com.appedo.module.bean.SLAActionBean;
import com.appedo.module.bean.SLABean;
import com.appedo.module.bean.SLARuleBean;
import com.appedo.module.bean.SLASUMBean;
import com.appedo.module.common.Constants;
import com.appedo.module.dbi.ModuleCounterDBI;
import com.appedo.module.dbi.ModuleDBI;
import com.appedo.module.dbi.SLADBI;
import com.appedo.module.utils.UtilsFactory;

public class SLAManager {
	
	/**
	 * gets breaches for the respective SLA id mapped with counter
	 * @param con
	 * @param strGUID
	 * @param strSLAIdsForAnalytics
	 * @param strCounters
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getCountersBreaches(Connection con, String strGUID, String strSLAIdsForAnalytics, String strCounters, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, long lUserId) throws Exception {
		SLADBI sladbi = null;
		
		JSONObject joRtnCountersBreaches = null;
		
		try {
			sladbi = new SLADBI();
			
			joRtnCountersBreaches = sladbi.getCountersBreaches(con, strGUID, strSLAIdsForAnalytics, strCounters, strFromStartInterval, lStartDateTime, lEndDateTime, lUserId);
			
		} catch (Exception e) {
			throw e; 
		}
		
		return joRtnCountersBreaches;
	}
	
	/**
	 * gets breaches for the respective SLA id mapped with counter
	 * 
	 * @param con
	 * @param strGUID
	 * @param strSLAIdsForAnalytics
	 * @param strCounters
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getCounterBreaches(Connection con, String strGUID, String strSLAIdsForAnalytics, String strCounters, String strFromStartInterval, Long lStartDateTime, Long lEndDateTime, long lUserId, String strAlertedTimestamps) throws Exception {
		SLADBI sladbi = null;
		
		JSONObject joRtnCountersBreaches = null, joData = null, joNextData = null;
		JSONArray jaBreachedData = null, jaAggregatedBreachedData = null;
		long lBreachedTimestamp = 0;
		double dBreachedValue = 0, dAverage = 0;
		long lNextBreachedTimeStamp = 0;
		DecimalFormat df = new DecimalFormat("#.###");
		
		ArrayList<Double> alBreachedValues = new ArrayList<Double>();;
		
		String[] saAlertedTimestamps = null;
		long lAlertedTimestamp = 0;
		int i = 0;
		
		try {
			sladbi = new SLADBI();
			
			joRtnCountersBreaches = sladbi.getCounterBreaches(con, strGUID, strSLAIdsForAnalytics, strCounters, strFromStartInterval, lStartDateTime, lEndDateTime, lUserId);
			
			// Breached & Alerted timestamps are JOINed using "Merging Sort Algorithm"
			// Refer the following URLs for the algorithm definition:
			// http://tanmayonrun.blogspot.in/2011/08/how-to-merge-two-sorted-arrays-merging.html
			// http://www.algolist.net/Algorithms/Merge/Sorted_arrays
			if( strAlertedTimestamps != null && joRtnCountersBreaches.getJSONObject("countersBreaches").containsKey(strCounters) ) {
				jaBreachedData = joRtnCountersBreaches.getJSONObject("countersBreaches").getJSONArray(strCounters).getJSONObject(0).getJSONArray("data");	
				
				saAlertedTimestamps = strAlertedTimestamps.split(",");
				
				for(String strAlertedTimestamp: saAlertedTimestamps) {
					/*
					Loop each one and omit the non-actual breaches in-terms of "Min. Breach Count"
					*/
					lAlertedTimestamp = Long.parseLong(strAlertedTimestamp);
					
					for( ; i < jaBreachedData.size(); i++ ) {
						lBreachedTimestamp = jaBreachedData.getJSONObject(i).getLong("T");
						
						// check whether `Alert` happen between `Breached` time & 5 seconds
						if( ! ( lAlertedTimestamp >= lBreachedTimestamp && lAlertedTimestamp <= lBreachedTimestamp + 5000 ) ) {
							jaBreachedData.remove(i);
							i--;	// To neglect `i++`, which will happen in this FOR loop
						}
						// Alert happened within 5 seconds of the breach. So loop to next Alert data.
						else {
							i++;	// As the loop is being breaked, need to increment the pointer.
							break;
						}
					}
				}
				
				// do GROUP BY on breached-on-in-minute; and calculate AVG & COUNT
				if( jaBreachedData.size() > 0 ) {
					jaBreachedData = joRtnCountersBreaches.getJSONObject("countersBreaches").getJSONArray(strCounters).getJSONObject(0).getJSONArray("data");	
					jaAggregatedBreachedData = new JSONArray();
					
					for( i = 0; i < jaBreachedData.size(); i++ ) {
						if( i+1 < jaBreachedData.size() ) {
							// Initialize the Next-Variables to avoid the functionality to happen for the first time.
							lNextBreachedTimeStamp = jaBreachedData.getJSONObject(i+1).getLong("T");
							joNextData = jaBreachedData.getJSONObject(i+1);
						}
						
						joData = jaBreachedData.getJSONObject(i);
						lBreachedTimestamp = joData.getLong("T");
						dBreachedValue = joData.getDouble("received_value");
						
						// Do the aggregation process, if this & next are in different minute (or) if this is last object of the array.
						if( lBreachedTimestamp / 60000 != lNextBreachedTimeStamp / 60000 || i == jaBreachedData.size()-1 ) {
							// if it is the last point then, include it for the averaging and do the aggregation process.
							if( i == jaBreachedData.size()-1 ) {
								alBreachedValues.add(dBreachedValue);
							}
							
							dAverage = UtilsFactory.roundOff(UtilsFactory.average(alBreachedValues), 3);
							
							joData.put("T", lBreachedTimestamp / 60000 * 60000);	// Dividing by 60000 & multiplying with 60000 will truncate the TimeStamp before Minute.
							joData.put("Count", alBreachedValues.size());
							joData.put("V", dAverage);
							joData.put("Avg", dAverage);
							
							jaAggregatedBreachedData.add(joData);
							
							// clear the array data holder
							UtilsFactory.clearCollectionHieracy(alBreachedValues);
							alBreachedValues = new ArrayList<Double>();
						} else {
							alBreachedValues.add(dBreachedValue);
						}
					}
					
					// re-assign the aggregated array as `data` array
					joRtnCountersBreaches.getJSONObject("countersBreaches").getJSONArray(strCounters).getJSONObject(0).put("data", jaAggregatedBreachedData);
					
					// clear older array
					UtilsFactory.clearCollectionHieracy(jaBreachedData);
				}
			}
		} catch (Exception e) {
			throw e; 
		}
		
		return joRtnCountersBreaches;
	}
	
	/**
	 * gets user's breached counters,
	 *   gets respective breached counter's chartdata & breach data
	 *   
	 * @param con
	 * @param strFromStartInterval
	 * @param lStartDateTime
	 * @param lEndDateTime
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getBreachedCountersDataForHotspot(Connection con, String strSliderValue, Long lStartDateTime, Long lEndDateTime, Long lUserID) throws Throwable {
		SLADBI slaDBI = null;
		ModuleCounterDBI moduleCounterDBI = null;
		ModuleDBI moduleDBI = null;
		
		JSONArray jaBreachedCounters = new JSONArray();
		JSONObject joBreachedCounter = null;
		
		HashMap<String, HashMap<String, String> > hmCounters = null;
		HashMap<String, String> hmCounter = null;
		HashMap<String, HashMap<String, String> > hmModules = null;
		HashMap<String, String> hmModule = null;
		
		StringBuilder sbCounterTemplateIds = new StringBuilder(), sbUIDs = new StringBuilder();
		
		try {
			slaDBI = new SLADBI();
			moduleCounterDBI = new ModuleCounterDBI();
			moduleDBI = new ModuleDBI();

			/**
			 * 1. Get all the breached SLA_ID-UID-CounterId
			 * 2. Get the Counter details with the above received CounterId; from counter-template
			 * 3. Get the Module's details with the above received UID
			 * 
			 */
			
			// 1. Get all the breached SLA_ID-UID-CounterId
			jaBreachedCounters = slaDBI.getBreachedCountersList(con, strSliderValue, lStartDateTime, lEndDateTime, lUserID);

			if( jaBreachedCounters.size() > 0 ) {
				for( int i = 0; i < jaBreachedCounters.size(); i++ ) {
					joBreachedCounter = jaBreachedCounters.getJSONObject(i);
					
					sbCounterTemplateIds.append(joBreachedCounter.getString("counter_template_id") ).append(",");
					sbUIDs.append(joBreachedCounter.getString("uid") ).append(",");
				}
				
				// remove last comma; which was appended in the loop
				if( jaBreachedCounters.size() > 0 ) {
					sbCounterTemplateIds.delete(sbCounterTemplateIds.length()-1, sbCounterTemplateIds.length());
					sbUIDs.delete(sbUIDs.length()-1, sbUIDs.length());
				}
				
				// 2. Get the Counter details with the above received CounterId; from counter-template
				hmCounters = moduleCounterDBI.getCounterTemplateDetails(con, sbCounterTemplateIds);
				
				
				// 3. Get the Module's details with the above received UID
				hmModules = moduleDBI.getModuleDetails(con, sbUIDs);
				
				
				// Append all the data
				for( int i = 0; i < jaBreachedCounters.size(); i++ ) {
					joBreachedCounter = jaBreachedCounters.getJSONObject(i);
					
					hmCounter = hmCounters.get( joBreachedCounter.getString("counter_template_id") );
					joBreachedCounter.put("category", hmCounter.get("category"));
					joBreachedCounter.put("counter_name", hmCounter.get("category"));
					joBreachedCounter.put("display_name", hmCounter.get("display_name"));
					joBreachedCounter.put("unit", hmCounter.get("unit"));
					
					hmModule = hmModules.get( joBreachedCounter.getString("uid") );
					joBreachedCounter.put("guid", hmModule.get("guid"));
					joBreachedCounter.put("module_name", hmModule.get("module_name"));
					joBreachedCounter.put("module_code", hmModule.get("module_code"));
				}
			}
		} catch (Throwable th) {
			throw th;
		}
		
		return jaBreachedCounters;
	}
	
	/**
	 * adds SLA policies for the primary counter of `Threshold Breach`, `Error` & `Warning`
	 * 
	 * @param con
	 * @param moduleBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addSLAPoliciesMapToCounters(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		ModuleCounterDBI moduleCounterDBI = null;
		
		ArrayList<HashMap<String, String>> alPrimaryCounters = null;
		HashMap<String, String> hmPrimaryCounter = null;
		
		StringBuilder sbQryCountersWithSLAId = new StringBuilder();
		
		try {
			moduleCounterDBI = new ModuleCounterDBI();
			
			// creates SLAs for the primary counters
			alPrimaryCounters = moduleCounterDBI.getPrimaryCountersWithTemplateDetails(con, moduleBean.getModuleId());
			for(int i = 0; i < alPrimaryCounters.size(); i = i + 1) {
				hmPrimaryCounter = alPrimaryCounters.get(i);
				
				// for Threshold Breach
				addSLAPolicyMapToCounter(con, moduleBean, hmPrimaryCounter, "Threshold Breach", "/sla/addSLAPolicyMapToCounterForThresholdBreach", loginUserBean, joEnt);
			}
			
			moduleCounterDBI = null;
		} catch (Exception e) {
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(alPrimaryCounters);
			alPrimaryCounters = null;
			
			UtilsFactory.clearCollectionHieracy(sbQryCountersWithSLAId);
			sbQryCountersWithSLAId = null;
		}
	}
	
	/**
	 * counter's, adds SLA Policy and map to sla_counter with threshold limit, 
	 * 
	 * @param con
	 * @param moduleBean
	 * @param hmPrimaryCounter
	 * @param strBreachType
	 * @param strURL
	 * @param strThresholdVale
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addSLAPolicyMapToCounter(Connection con, ModuleBean moduleBean, HashMap<String, String> hmPrimaryCounter, String strBreachType, String strURL, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		String strPolicyName = "";
		
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		//new Form
		SLABean slaBean = null;
		MapCounterBean mapCounterBean = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			
			strPolicyName = hmPrimaryCounter.get("moduleCode")+" - "+moduleBean.getModuleName()+" - "+hmPrimaryCounter.get("displayName")+" - "+strBreachType;
			
			// add SLA policy
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			wsm.addParameter("policyName", strPolicyName);
			wsm.addParameter("policyDesc", strPolicyName+Constants.SLA_AUTOGEN_DEFAULT_LASTNAME);
			wsm.addParameter("alertType", Constants.SLA_AUTOGEN_DEFAULT_TYPE);
			
			// add Enterprise Details
			wsm.addParameter("EnterpriseDetails", joEnt.toString());
			// map counter details to SLA policy
			wsm.addParameter("counterId", hmPrimaryCounter.get("counterId"));
			wsm.addParameter("ctId", hmPrimaryCounter.get("counterTemplateId"));
			wsm.addParameter("category", hmPrimaryCounter.get("category"));
			wsm.addParameter("counterName", hmPrimaryCounter.get("counterName"));
			wsm.addParameter("warning_threshold_value", hmPrimaryCounter.get("warning_threshold_value"));
			wsm.addParameter("critical_threshold_value", hmPrimaryCounter.get("critical_threshold_value"));
			wsm.addParameter("inPercentage", hmPrimaryCounter.get("isPercentage"));
			wsm.addParameter("isThresholdAbove", hmPrimaryCounter.get("isAboveThreshold"));
			
			wsm.addParameter("minBreachCount", Constants.SLA_AUTOGEN_MIN_BREACH_COUNT);
			
			wsm.addParameter("uid", moduleBean.getModuleId()+"");
			wsm.addParameter("moduleName", moduleBean.getModuleType());
			wsm.addParameter("moduleValue", moduleBean.getModuleName());
			wsm.addParameter("guid", moduleBean.getGuid());
			// AgentVersionId as CounterTypeVersionId
			wsm.addParameter("ctvId", moduleBean.getAgentVersionId()+"");
			
			// web service request
			//wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES + strURL);
			wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES + strURL);
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());
			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
			} else {
				// exception in SLA
				throw new Exception("Unable to add SLA Policy Map To Counter.");
			}
			
/*			//New UI Implemeted.
			strPolicyName = hmPrimaryCounter.get("moduleCode")+" - "+moduleBean.getModuleName()+" - "+hmPrimaryCounter.get("displayName")+" - "+strBreachType;
			// add SLA Policy 
			slaBean = new SLABean();
			slaBean.setSLAName(strPolicyName);
			slaBean.setSLADescription(strPolicyName+Constants.SLA_AUTOGEN_DEFAULT_LASTNAME);
			slaBean.setSLAType(Constants.SLA_AUTOGEN_DEFAULT_TYPE);
			slaBean.setSystemGeneratedSLA(true);
			slaBean.setActivePolicy(true);
			// TODO: ASK, delete `Alert` type SLA ids mapped to rule `so_sla_rule` 
			// since rule not to map for `Alert` type added -1; rule is for heal
			slaBean.setMapRuleId(-1);
			
			// map counter to created SLA Policy
			mapCounterBean = new MapCounterBean();
			mapCounterBean.setBreachId( Constants.SLA_BREACH_TYPES.get("Threshold Breach") );

			mapCounterBean.setCounterId(Integer.parseInt(hmPrimaryCounter.get("counterId")));
			mapCounterBean.setCounterTemplateId(Integer.parseInt(hmPrimaryCounter.get("counterTemplateId")));
			mapCounterBean.setCategory(hmPrimaryCounter.get("category"));
			mapCounterBean.setCounterName(hmPrimaryCounter.get("counterName"));
			mapCounterBean.setWarningThresholdValue(Long.parseLong(hmPrimaryCounter.get("warning_threshold_value")));
			mapCounterBean.setCriticalThresholdValue(Long.parseLong(hmPrimaryCounter.get("critical_threshold_value")));
			mapCounterBean.setInPercentage(Boolean.parseBoolean(hmPrimaryCounter.get("inPercentage")));
			mapCounterBean.setIsThresholdAbove(Boolean.parseBoolean(hmPrimaryCounter.get("isAboveThreshold")));
			
			mapCounterBean.setMinBreachCount(Integer.parseInt(Constants.SLA_AUTOGEN_MIN_BREACH_COUNT));
			
			mapCounterBean.setUId((int)moduleBean.getModuleId());
			mapCounterBean.setModuleName(moduleBean.getModuleType());
			mapCounterBean.setModuleDetailedValue( moduleBean.getModuleName());
			mapCounterBean.setGuid(moduleBean.getGuid());
			mapCounterBean.setCounterTypeVersionId(moduleBean.getAgentVersionId());
			
			// add SLA policy, map module's/uid's counter to the created policy & update sla_id in `counter_master_<uid>` 
			addSLAPolicyMapToCounterForThresholdBreach(con, slaBean, mapCounterBean, loginUserBean);*/
			
		} catch(Exception e) {
			throw e;
			
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
			
			strPolicyName = null;
		}
	}
	
	/**
	 * add/updates SLA policy & mapped RUM module/uid's thresholds
	 * 
	 * @param rumslaBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void configureSLAToRUMModule(RUMSLABean rumslaBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			
			// add SLA policy
			wsm.addParameter("policyName", rumslaBean.getModuleName()+" - RUM SLA Policy");
			wsm.addParameter("policyDesc", rumslaBean.getModuleName()+" - RUM"+Constants.SLA_AUTOGEN_DEFAULT_LASTNAME);
			//wsm.addParameter("policySvrType", sumTestBean.getTestName()+" SLA Policy");
			wsm.addParameter("alertType", Constants.SLA_AUTOGEN_DEFAULT_TYPE);
			wsm.addParameter("enable_response_alert", rumslaBean.isEnableResponseAlert()+"");
			
			// map SUM test thresholds to SLA policy
			//wsm.addParameter("sla_id", sumTestBean.getSLAId());
			wsm.addParameter("is_above_threashold", true+"");
			wsm.addParameter("warning_threshold_value", rumslaBean.getWarningThresholdValue()+"");
			wsm.addParameter("critical_threshold_value", rumslaBean.getCriticalThresholdValue()+"");
			wsm.addParameter("min_breach_count", rumslaBean.getMinBreachCount()+"");
			
			wsm.addParameter("uid", rumslaBean.getUId()+"");
			wsm.addParameter("moduleName", rumslaBean.getModuleName());
			wsm.addParameter("guid", rumslaBean.getGUID());
			
			// add Enterprise Details
			wsm.addParameter("EnterpriseDetails", joEnt.toString());
						
			// web service request
			//wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES + "/sla/configureSLAToRUMModule");
			wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES + "/sla/configureSLAToRUMModule");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());
			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
				LogManager.infoLog("SLA policy added and mapped to RUM.");
			} else {
				// exception in SLA
				throw new Exception("Unable to add SLA policy & map to RUM.");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	//SLA Manager In SLA Services
	

	
	public JSONArray getSLAActions(Connection con, LoginUserBean loginBean) throws Exception {
		
		SLADBI slaDBI = null;
		JSONArray jaActions = null;
		
		try{
			slaDBI = new SLADBI();
			jaActions = slaDBI.getSLAActions(con, loginBean);
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaActions;
	}
	
	public JSONArray getSLARules(Connection con, LoginUserBean loginBean) throws Exception {
			
		SLADBI slaDBI = null;
		JSONArray jaRules = null;
		
		try{
			slaDBI = new SLADBI();
			jaRules = slaDBI.getSLARules(con, loginBean);
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaRules;
	}
	
	/**
	 * gets SLAs either User added OR System generated OR SUM's, based respective boolean
	 * 
	 * @param con
	 * @param bSystemGenerated
	 * @param bSUM
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSLAs(Connection con, boolean bSystemGenerated, String strModuleCode, LoginUserBean loginBean, JSONObject joEnt) throws Exception {
		SLADBI slaDBI = null;
		JSONArray jaSLAs = null;
		
		try {
			slaDBI = new SLADBI();
			
			if ( strModuleCode.equals("ASD") ) {
				// gets ASD's SLAs
				jaSLAs = slaDBI.getASDSLAs(con, bSystemGenerated, loginBean, joEnt);	
			} else if (strModuleCode.equals("SUM")) {
				// gets SUM's SLAs
				jaSLAs = slaDBI.getSUMSLAs(con, bSystemGenerated, loginBean, joEnt);
			} else if (strModuleCode.equals("RUM")) {
				// get RUM's SLAs
				jaSLAs = slaDBI.getRUMSLAs(con, bSystemGenerated, loginBean, joEnt);
			}
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
		
		return jaSLAs;
	}
	
	/**
	 * This is to get the slave status 
	 * @param con
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSlaSlaveStatusCardLayout(Connection con, LoginUserBean loginBean) throws Exception {
		
		SLADBI slaDBI = null;
		JSONArray jaSlaSlaveStatusCardLayouts = null;
		
		try{
			slaDBI = new SLADBI();
			jaSlaSlaveStatusCardLayouts = slaDBI.getSlaSlaveStatusCardLayout(con, loginBean);
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaSlaSlaveStatusCardLayouts;
	}
	
	/**
	 * This is to get the sla alert log for card layout 
	 * @param con
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getSlaAlertCardLayout(Connection con, /*LoginUserBean loginBean*/ long lUser_id, long lSlaId, long lLimt, long lOffSet) throws Exception {
		
		SLADBI slaDBI = null;
		JSONObject joRtn = null;
		try{
			slaDBI = new SLADBI();
			joRtn = slaDBI.getSlaAlertCardLayout(con, /*loginBean*/ lUser_id, lSlaId, lLimt, lOffSet);
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return joRtn;
	}
	
	/**
	 * This is to get the sla Heal log for card layout 
	 * @param con
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getSlaHealCardLayout(Connection con, LoginUserBean loginBean, long lSlaId) throws Exception {
		
		SLADBI slaDBI = null;
		JSONArray jaSlaHealCardLayouts = null;
		
		try{
			slaDBI = new SLADBI();
			jaSlaHealCardLayouts = slaDBI.getSlaHealCardLayout(con, loginBean, lSlaId);
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaSlaHealCardLayouts;
	}
	
	/**
	 * Saves sla action details
	 * 
	 * @param con
	 * @param actionBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addAction(Connection con, SLAActionBean actionBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI sladbi = null;
		
		boolean bActionExists = false;
		
		try {
			sladbi = new SLADBI();
			
			// as new insert checks user's action already exists, "-1" hardcoding since its a new insert
			bActionExists = sladbi.isActionExists(con, actionBean.getActionName(), -1, loginUserBean);
			if( bActionExists ) {
				throw new Exception("1");
			} else {
				sladbi.addAction(con, actionBean, loginUserBean);
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	/**
	 * get user added public actions 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getActions(Connection con, LoginUserBean loginBean) throws Exception {
		SLADBI sladbi = null;

		JSONArray jaUserPublicActions = null;
		
		try {
			sladbi = new SLADBI();
			jaUserPublicActions = sladbi.getActions(con, loginBean);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaUserPublicActions;
	}
	
	
	/**
	 * get user added rules 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getRules(Connection con, /*LoginUserBean loginBean*/ long lUser_id) throws Exception {
		SLADBI sladbi = null;

		JSONArray jaUserRules = null;
		
		try {
			sladbi = new SLADBI();
			jaUserRules = sladbi.getRules(con, /*loginBean*/ lUser_id);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaUserRules;
	}
	
	
	/**
	 * updates action
	 * @param con
	 * @param actionBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateAction(Connection con, SLAActionBean actionBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI sladbi = null;

		boolean bActionRuleExists = false, bActionExists = false; //, bActionReferredExists = false;
		
		try {
			sladbi = new SLADBI();
			
			// checks other than user's respective actionId to update 
			bActionExists = sladbi.isActionExists(con, actionBean.getActionName(), actionBean.getActionId(), loginUserBean);
			if( bActionExists ) {
				throw new Exception("1");
			} else {
				// checks, to update action when if an action is not mapped to rules
				bActionRuleExists = sladbi.isActionMappedToRule(con, actionBean.getActionId(), loginUserBean);
				if( bActionRuleExists ) {
					throw new Exception("2");
				} else {
					// TODO: check an action is referred
					//bActionReferredExists = sladbi.isActionReferred(con, actionBean.getActionId());
					//if(bActionReferredExists) {
						//throw new Exception("3");
					//} else {
						sladbi.updateAction(con, actionBean, loginUserBean);	
					//}	
				}
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	/**
	 * delete action
	 * @param con
	 * @param lActionId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteAction(Connection con, long lActionId, LoginUserBean loginUserBean) throws Exception {
		SLADBI sladbi = null;

		boolean bActionRuleExists = false; //, bActionReferredExists = false;
		
		try {
			sladbi = new SLADBI();

			// checks, to delete an action when if an action is not mapped to rules
			bActionRuleExists = sladbi.isActionMappedToRule(con, lActionId, loginUserBean);
			if( bActionRuleExists ) {
				throw new Exception("1");
			} else {
				// TODO: check an action is referred
				//bActionReferredExists = sladbi.isActionReferred(con, lActionId);
				//if(bActionReferredExists) {
					//throw new Exception("2");
				//} else {
					sladbi.deleteAction(con, lActionId, loginUserBean);
				//}
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	/**
	 * delete SUM test's SLA refs
	 * 
	 * @param con
	 * @param lSUMTestId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteSUMSLA(Connection con, long lSUMTestId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.deleteSUMSLA(con, lSUMTestId, loginUserBean.getUserId());
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	/**
	 *  To delete the AVM test's sla policy.
	 * @param con
	 * @param lAVMTestId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteAVMSLA(Connection con, long lAVMTestId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;

		try {
			slaDBI = new SLADBI();

			slaDBI.deleteAVMSLA(con, lAVMTestId, loginUserBean.getUserId());

			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}

	public void deleteRUMSLA(Connection con, long lUId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.deleteRUMSLA(con, lUId, loginUserBean.getUserId());
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	/**
	 * saves SLA Rule 
	 * @param con
	 * @param actionBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public JSONObject addRule(Connection con, SLARuleBean ruleBean, LoginUserBean loginUserBean, JSONArray jaActionIds) throws Exception {
		SLADBI sladbi = null;
		long lSLARuleId = -1L;
		JSONObject joRtn = null;
		try {
			sladbi = new SLADBI();
			boolean isRuleExists = false;
			
			isRuleExists = sladbi.checkForRuleExists(con, ruleBean, loginUserBean);
			if (isRuleExists) {
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to add rule. Rule name already exist.");
			} else {
				lSLARuleId = sladbi.addSLARule(con, ruleBean, loginUserBean);
				if(lSLARuleId > 0) {
					
					for(int i=0; i<jaActionIds.size(); i++) {
						
						JSONObject joActionId = JSONObject.fromObject(jaActionIds.get(i));
						sladbi.addSLARuleAction(con, ruleBean, lSLARuleId, loginUserBean, Long.valueOf(joActionId.getLong("actionId")));
						
					}
					//for (String actionId: actionIds) {
						//sladbi.addSLARuleAction(con, ruleBean, lSLARuleId, loginUserBean, Long.valueOf(actionId));
					//}
				}
				joRtn = UtilsFactory.getJSONSuccessReturn("Rule added successfully.");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joRtn;
	}
	
	/**
	 * updates SlaRule
	 * 
	 * @param con
	 * @param ruleBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public JSONObject updateSlaRule(Connection con, SLARuleBean ruleBean, LoginUserBean loginUserBean, JSONArray jaActionIds) throws Exception {
		
		SLADBI slaDBI = null;

		boolean bRuleExists = false;
		JSONObject joRtn = null;
		
		try {
			slaDBI = new SLADBI();
			
			bRuleExists = slaDBI.isRuleExists(con, ruleBean.getRuleName(), ruleBean.getRuleId(), loginUserBean);
			if( bRuleExists ) {
				joRtn = UtilsFactory.getJSONFailureReturn("Unable to update rule. Rule name already exist.");
			} else {
				
				//update rule actions
				slaDBI.deleteRuleActions(con, ruleBean.getRuleId());
				for(int i=0; i<jaActionIds.size(); i++) {
					
					JSONObject joActionId = JSONObject.fromObject(jaActionIds.get(i));
					slaDBI.addSLARuleAction(con, ruleBean, ruleBean.getRuleId(), loginUserBean, Long.valueOf(joActionId.getLong("actionId")));
					
				}
				//update rule
				slaDBI.updateSlaRule(con, ruleBean, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Rule updated successfully.");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return joRtn;
	}

	/**
	 * delete rule
	 * 
	 * @param con
	 * @param ruleId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public JSONObject deleteRule(Connection con, long ruleId, LoginUserBean loginUserBean) throws Exception {
		SLADBI sladbi = null;
		JSONObject joRtn = null;
		//JSONArray jaRuleAssociation = null;
		
		try {
			sladbi = new SLADBI();

			// checks, rule association
			//jaRuleAssociation = sladbi.getAssociatedRules(con, ruleId, loginUserBean);
			//if( jaRuleAssociation.size() > 0 ) {
				//joRtn = UtilsFactory.getJSONSuccessReturn(jaRuleAssociation);
				//throw new Exception("1");
			//} else {
				sladbi.deleteRule(con, ruleId, loginUserBean);
				joRtn = UtilsFactory.getJSONSuccessReturn("Rule deleted successfully.");
			//}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joRtn;
	}
	
	
	/**
	 * Save SLA Record 
	 * @param con
	 * @param strSLADetails
	 * @param strCounters
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long addSla(Connection con, SLABean slaBean, LoginUserBean loginBean, JSONObject joEnt) throws Exception {
		long lSLAId = -1L;
		boolean bExist = false;
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			// as new insert checks user's SLA already exists, "-1" hardcoding since its a new insert
			bExist = slaDBI.isSLANameExist(con, slaBean.getSLAName(), -1, loginBean.getUserId());
			if ( ! bExist ) {
				lSLAId = slaDBI.addSla(con, slaBean, loginBean, joEnt);
				slaBean.setSLAId(lSLAId);
				// TODO: on SLA add, rule also mapped for the created SLA, since condition != -1, add condition > 0, rule mapping for HEAL 
				if(slaBean.getMapRuleId() != -1){
					slaDBI.saveRule(con, lSLAId, slaBean.getMapRuleId(), loginBean.getUserId());
				}
			} else {
				return -1l;
			}
			// adds SLA id into beans
			slaBean.setSLAId(lSLAId);
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
		return lSLAId;
	}
	
	public long addSUMSla(Connection con, SLABean slaBean, LoginUserBean loginBean) throws Exception {
		
		long lSLAId = -1L;
		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();	
			lSLAId = slaDBI.isSLASUMNameExist(con, slaBean.getSLAName(), slaBean.getSLAId(), loginBean);
			if(lSLAId == -1){
				//lSLAId = slaDBI.addSla(con, slaBean, loginBean);
			}
			// adds SLA id into beans
			slaBean.setSLAId(lSLAId);
			
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return lSLAId;
	}
	
	public long addSlaSum(Connection con, SLASUMBean slaSumBean, LoginUserBean loginBean) throws Exception {
		long lSLAId = -1L;
		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();	
			lSLAId = slaDBI.addSlaSum(con, slaSumBean, loginBean);
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return lSLAId;
	}
	
	/**
	 * Getting Types of modules
	 * @param con
	 * @param strType
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleTypeValues(Connection con, String strType, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		
		JSONArray jaModuleValues = null;
		SLADBI slaDBI = null;
		try{
			slaDBI = new SLADBI();
			jaModuleValues = slaDBI.getModuleTypeValues(con, strType, loginUserBean, joEnt);
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaModuleValues;
	}
	
	/**
	 * Getting available  categories
	 * 
	 * @param con
	 * @param nApplicationID
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCategory(Connection con, int nID) throws Exception {
		
		SLADBI slaDBI = null;
		JSONArray jaAPCategory = null;
		try {
			slaDBI = new SLADBI();
			jaAPCategory = slaDBI.getCategory(con,  nID);
			slaDBI = null;	
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaAPCategory;
	}
	
	/**
	 * Getting counters
	 * 
	 * @param con
	 * @param nApplicationId
	 * @param strCategory
	 * @return
	 * @throws Exception
	 */
	public JSONArray getCounters(Connection con, long lUID) throws Exception {
		SLADBI slaDBI = null;
		JSONArray jaAPPCounters = null;
		try {
			slaDBI = new SLADBI();
			jaAPPCounters = slaDBI.getCounters(con, lUID);			
			slaDBI = null;	
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return jaAPPCounters;
	}
	
	/**
	 * Adding a map counter
	 * 
	 * @param con
	 * @param mapCounterBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addMapCounter(Connection con, MapCounterBean mapCounterBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		boolean bCounterExist = false;
		JSONObject joMaxValueCounterIdDetail = null;

		try{
			slaDBI = new SLADBI();
			bCounterExist = slaDBI.isCounterExist(con, mapCounterBean, loginUserBean);
			if( bCounterExist ){
//				slaDBI.deleteMapCounter(con, (int)lCounterId);

				// err, the module's/uid's counter is already mapped to the policy
				throw new Exception("1");
			} else {
				if (mapCounterBean.isPercentageCalculation()) {
					joMaxValueCounterIdDetail = slaDBI.getMaxValueCounterIdDetail(con, mapCounterBean.getUId(), mapCounterBean.getDenominatorCounteId());

					if (joMaxValueCounterIdDetail != null && !joMaxValueCounterIdDetail.getBoolean("isSelected")) {
						throw new Exception("2", new Exception(joMaxValueCounterIdDetail.getString("displayName")));
					}
				}
				slaDBI.addMapCounter(con, mapCounterBean, loginUserBean);
			}

			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	public void mapToAlert(Connection con, MapCounterBean mapCounterBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		boolean bCounterExist = false;
		//JSONObject joMaxValueCounterIdDetail = null;
		ModuleDBI moduleDBI = null;
		try{
			moduleDBI = new ModuleDBI();
			slaDBI = new SLADBI();
			
			if (mapCounterBean.getGuid() == null ){
				mapCounterBean.setGuid(moduleDBI.getGUID(con, Long.valueOf(mapCounterBean.getUId())));
			}
			
			bCounterExist = slaDBI.isCounterExist(con, mapCounterBean, loginUserBean);
			if( bCounterExist ){
//				slaDBI.deleteMapCounter(con, (int)lCounterId);

				// err, the module's/uid's counter is already mapped to the policy
				throw new Exception("1");
			} else {
				/*if (mapCounterBean.isPercentageCalculation()) {
					joMaxValueCounterIdDetail = slaDBI.getMaxValueCounterIdDetail(con, mapCounterBean.getUId(), mapCounterBean.getDenominatorCounteId());

					if (joMaxValueCounterIdDetail != null && !joMaxValueCounterIdDetail.getBoolean("isSelected")) {
						throw new Exception("2", new Exception(joMaxValueCounterIdDetail.getString("displayName")));
					}
				}*/
				slaDBI.mapToAlert(con, mapCounterBean, loginUserBean);
			}

			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	public void addAlertAddCounter(Connection con, MapCounterBean mapCounterBean, LoginUserBean loginUserBean, int nSlaMapRuleId, JSONObject joEnt) throws Exception {
		SLADBI slaDBI = null;
		SLABean slaBean = null;
		long lSlaId= 0;
		ModuleDBI moduleDBI  = null;
		try{
			slaDBI = new SLADBI();
			slaBean = new SLABean();
			moduleDBI = new ModuleDBI();
			
			if (mapCounterBean.getGuid() == null ){
				mapCounterBean.setGuid(moduleDBI.getGUID(con, Long.valueOf(mapCounterBean.getUId())));
			}
			
			slaBean.setActivePolicy(true);
			slaBean.setSystemGeneratedSLA(false);
			slaBean.setSLAName(mapCounterBean.getPolicyName());
			slaBean.setSLADescription(mapCounterBean.getPolicyDesc());
			slaBean.setSLAType("Alert");
			slaBean.setMapRuleId(nSlaMapRuleId);
			
			lSlaId = addSla(con, slaBean, loginUserBean, joEnt);
			
			mapCounterBean.setSLAId(lSlaId);
			
			slaDBI.mapToAlert(con, mapCounterBean, loginUserBean);
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	/**
	 * To send updated counters to collector
	 *  
	 * @param con
	 * @param bean
	 */
	public void sendGUIDsActiveSLAsToCollector(String strGUIDs) throws Exception {
		JSONObject joGUIDWiseSLAs = null;
		
		WebServiceManager wsm = null;
		
		try {
			// gets GUID(s) active SLA(s) counters,
			joGUIDWiseSLAs = getActiveSLAsCounters(strGUIDs);
			
			// sends SLA(s) to collector, to update agent's request
			wsm = new WebServiceManager();
			wsm.addParameter("guid", strGUIDs);
			wsm.addParameter("CounterSet", joGUIDWiseSLAs.toString());
			wsm.addParameter("command", "SlaCounterSet");
			// web service request
			wsm.sendRequest(Constants.APPEDO_COLLECTOR);
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				LogManager.infoLog("GUID(s)'s active SLA(s) counter(s) are sent to collector.");
			} else {
				throw new Exception("Problem with Collector");
			}
		} catch(Exception e) {
			throw e;
		} finally {
			if ( wsm != null ) {
				wsm.destory();
			}
			wsm = null;
		}
	}
	
	public JSONObject getActiveSLAsCounters(String strGUIDs) throws Exception {
		SLADBI slaCollectorDBI = null;
		
		HashMap<String, Object> hmGUIDsMappedToSLAs = null;
		ArrayList<JSONObject> alBlank = new ArrayList<JSONObject>();

		String[] saGUIDs = null;
		String strFormattedGUIDs = "";
		
		JSONObject joGUIDWiseSLAs = null;
		
		try {
			slaCollectorDBI = new SLADBI();
			
			// format adds quote
			strFormattedGUIDs = "'"+strGUIDs.replaceAll(",", "','")+"'";
			
			// ASK, return as JSONObject 
			hmGUIDsMappedToSLAs = slaCollectorDBI.getActiveSLAsCounters(strFormattedGUIDs);

			// adds empty [] for guid(s) doesn't has SLA(s)
			saGUIDs = strGUIDs.split(",");
			for (String strGUID : saGUIDs) {
				
				if ( ! hmGUIDsMappedToSLAs.containsKey(strGUID) ) {
					hmGUIDsMappedToSLAs.put(strGUID, alBlank);
				}
			}
			
			joGUIDWiseSLAs = JSONObject.fromObject(hmGUIDsMappedToSLAs);
		} catch(Exception e){
			throw e;
		} finally {
			UtilsFactory.clearCollectionHieracy(hmGUIDsMappedToSLAs);
			hmGUIDsMappedToSLAs = null;
			
			strFormattedGUIDs = null;
			slaCollectorDBI = null;
		}
		
		return joGUIDWiseSLAs;
	}
	
	/**
	 *  Check whether a counters's max_value_counter_id is selected
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getMaxCounterDetail(Connection con, long lUID, long lCounterId) throws Exception {

		JSONObject joMaxValueCounterIdDetail = null;
		SLADBI slaDBI = null;
		try {
			slaDBI = new SLADBI();
			joMaxValueCounterIdDetail = slaDBI.getMaxValueCounterIdDetail(con, lUID, lCounterId);
			slaDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return joMaxValueCounterIdDetail;
	}
	
	/** 
	 * Getting map counters
	 * 
	 * @param con
	 * @param nSLAId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getMapCounters(Connection con, long lSLAId, /*LoginUserBean loginUserBean*/ long lUser_id) throws Exception {
		JSONArray jaMapCounters = null;
		SLADBI slaDBI = null;
		try{
			slaDBI = new SLADBI();
			jaMapCounters = slaDBI.getMapCounters(con, lSLAId, /*loginUserBean*/ lUser_id);
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaMapCounters;
	}
	
	public JSONArray getCounterMappedAlerts(Connection con, long lUID, long lCounterId) throws Exception {
		JSONArray jaMapCounters = null;
		SLADBI slaDBI = null;
		try{
			slaDBI = new SLADBI();
			jaMapCounters = slaDBI.getCounterMappedAlerts(con, lUID, lCounterId);
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaMapCounters;
	}
	
	/**
	 * updating SLA Settings
	 * @param con
	 * @param nMaxTryCount
	 * @param nTryCountDuration
	 * @param nTriggerAlertDuration
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void slaSettings(Connection con, int nMaxTryCount, int nTryCountDuration, int nTriggerAlertDuration, LoginUserBean loginUserBean) throws Exception {
		
		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();
			slaDBI.slaSettings(con, nMaxTryCount, nTryCountDuration, nTriggerAlertDuration, loginUserBean);
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	/**
	 * add SLA Settings for the user
	 * 
	 * @param con
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void insertSLASettings(Connection con, long lUserId) throws Exception {
		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();
			
			slaDBI.insertSLASettings(con, lUserId);
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * Getting SLA Settings
	 * @param con
	 * @param bean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getSLASettings(Connection con, LoginUserBean bean) throws Exception {
		
		JSONObject joSetting = null;
		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();
			joSetting = slaDBI.getSLASettings(con, bean);
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return joSetting;
	}
	
	/**
	 * inserting SLA Alert
	 * 
	 * @param con
	 * @param jaSLAAlerts
	 * @param loginUserBean
	 * @throws Exception
	 */
	public boolean addAlertAddress(Connection con, String strType, String strMobileOrEmail, int nTelephoneCode, long lUserID, LoginUserBean loginUserBean, boolean bDoEmailMobileVerification) throws Exception {
		SLADBI slaDBI = null;
		AppedoMailer appedoMailer = null;
		
		HashMap<String, Object> hmMailDetails = null;
		
		String strSubject = null;
		
		boolean bEmailExist = false, bAddressAlreadyVerified = false, bEmailSent = false;
		//int nReturn = 0;
		long lSLASettingId = -1L;
		
		try {
			slaDBI = new SLADBI();
			appedoMailer = new AppedoMailer( Constants.EMAIL_TEMPLATES_PATH );
			
			// check email is exist or not 
			bEmailExist = slaDBI.isEmailExist(con, strType, strMobileOrEmail, lUserID);
			
			if( bEmailExist ) {
				//nReturn = 2;
				
				// throws exception, email/mobile already exists 
				throw new Exception("1");
			} else {
				// checks email_mobile already verified; for SMS default verify as `TRUE`
				if ( strType.equals("SMS") ) {
					// for mobile/SMS, default verify as `TRUE`; TODO: later verification SMS
					bAddressAlreadyVerified = true;
				} else {
					// checks `email` already verified 
					bAddressAlreadyVerified = slaDBI.isEmailAlreadyVerified(con, strMobileOrEmail, lUserID);
				}
				
				// adds alert address 
				lSLASettingId = slaDBI.insertSLAAlertAddress(con, strType, strMobileOrEmail, nTelephoneCode, lUserID, bAddressAlreadyVerified);
				
				
				// Send Verification mail for the EMail-Id, for address not verified, 
				// Verification is not required; if the request is coming from User SignUp
				if( ! bAddressAlreadyVerified && bDoEmailMobileVerification && strType.equalsIgnoreCase("Email") ) {
					hmMailDetails = new HashMap<String, Object>();
					hmMailDetails.put("USERNAME", loginUserBean.getFirstName());
					hmMailDetails.put("TYPE", "SLA");
					hmMailDetails.put("LINK", Constants.APPEDO_URL+"verifySLAEmailAddress?lSLASettingId="+CryptManager.encryptEncodeURL(lSLASettingId+""));
					hmMailDetails.put("IS_NON_LOGIN_USER", !(loginUserBean.getEmailId().equalsIgnoreCase(strMobileOrEmail)) );
					strSubject = "Appedo: Accept SLA Alerts";
					bEmailSent = appedoMailer.sendMail(MODULE_ID.SLA_VERIFY_EMAIL, hmMailDetails, strMobileOrEmail.split(","), strSubject);
					
					UtilsFactory.clearCollectionHieracy(hmMailDetails);
				}
				
				//nReturn = 1;
			}
			
			slaDBI = null;
			appedoMailer = null;
			hmMailDetails = null;
			strSubject = null;
			strType = null;
			strMobileOrEmail = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		
		return bEmailSent;
	}
	
	/**
	 * Getting SLA Alert Records
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAlertsSettings(Connection con, LoginUserBean loginUserBean) throws Exception {

		SLADBI slaDBI = null;
		
		JSONArray jaSLARecords = null;
		try{
			slaDBI = new SLADBI();
			jaSLARecords = slaDBI.getAlertsSettings(con, loginUserBean);
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return jaSLARecords;
	}
	
	/**
	 * Deleting map counter
	 * 
	 * @param con
	 * @param lMapCounterId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteMapCounter(Connection con, long lSlaId, long lMapCounterId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.deleteMapCounter(con, lSlaId, lMapCounterId);
			
			// TODO: the SLA's counter's data to delete from `so_threshold_breach_<user_id>`
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	/**
	 * Get available Breach types
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getBrechTypes(Connection con, LoginUserBean loginUserBean) throws Exception {
		
		JSONArray jaBrechTypes = null;
		SLADBI slaDBI = null;
		try{
			slaDBI = new SLADBI();
			jaBrechTypes = slaDBI.getBrechTypes(con, loginUserBean);
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return jaBrechTypes;
	}
	
	public JSONObject getSlaMenuBadge(Connection con, LoginUserBean loginUserBean) throws Exception {
		
		JSONObject joSlaMenuBadge = null;
		SLADBI slaDBI = null;
		try{
			slaDBI = new SLADBI();
			joSlaMenuBadge = slaDBI.getSlaMenuBadge(con, loginUserBean);
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return joSlaMenuBadge;
	}
	
	
	/**
	 * Deleting SLA Alert Record
	 * 
	 * @param con
	 * @param nSLASettingId
	 * @throws Exception
	 */
	public void deleteSLARecord(Connection con, int nSLASettingId) throws Exception {

		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();
			slaDBI.deleteSLARecord(con, nSLASettingId);
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	public JSONArray getMappedRuleActions(Connection con, String strRuleId, LoginUserBean loginUserBean) throws Exception {
		
		SLADBI slaDBI = null;
		JSONArray jaRuleActions = null;
		try{
			
			slaDBI = new SLADBI();
			
			jaRuleActions = slaDBI.getMappedRuleActions(con, Long.parseLong(strRuleId), loginUserBean);
			slaDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return jaRuleActions;
	}
	
	/**
	 * Verifying SLA ALert email
	 * @param con
	 * @param lSLASettingId
	 * @throws Exception
	 */
	public void verifySLAEmailAddress(Connection con, long lSLASettingId) throws Exception {

		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();
			slaDBI.verifySLAEmailAddress(con, lSLASettingId);
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * verify SLA email address based on user_id and email_id
	 * 
	 * @param con
	 * @param lUserId
	 * @param strEmailId
	 * @throws Exception
	 */
	public void verifySLAEmailAddress(Connection con, long lUserId, String strEmailId) throws Exception {

		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();
			
			slaDBI.verifySLAEmailAddress(con, lUserId, strEmailId);
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * Update SLA
	 * @param con
	 * @param slaBean
	 * @param strCounters
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public void updateSLA(Connection con, SLABean slaBean, /*LoginUserBean loginBean*/ long lUser_id) throws Exception {
		SLADBI slaDBI = null;
		
		boolean bExist = false;
		
		try {
			slaDBI = new SLADBI();
			
			bExist = slaDBI.isSLANameExist(con, slaBean.getSLAName(), slaBean.getSLAId(), lUser_id);
			if( bExist ){
				// err, SLA Name already Exist
				throw new Exception("1");
			} else {
				slaDBI.updateSLA(con, slaBean, lUser_id);
				if( slaBean.getMapRuleId() != -1 ){
					slaDBI.saveRule(con, slaBean.getSLAId(), slaBean.getMapRuleId(), lUser_id);	
				}
			}
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	/**
	 * Remove SLA Record, 
	 *   send guid(s)'s SLA(s) counters to Collector, to update in agent,
	 *   
	 * @param conhttp://docs.oracle.com/javase/7/docs/api/java/lang/Long.html#valueOf%28long%29
	 * @param lSLAId
	 * @throws Exception
	 */
	public void removeSLARecord(Connection con, long lSLAId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try{
			slaDBI = new SLADBI();
			
			// removes records
			slaDBI.removeAssociatedRule(con, lSLAId);
			slaDBI.removeMapCounters(con, lSLAId);
			slaDBI.removeSLARecord(con, lSLAId);
			slaDBI.deleteSlaSumBySlaId(con,Long.valueOf(lSLAId));
			
			// TODO: delete SLA records in `so_threshold_breach_<user_id>`, `sla_alert_log` & `sla_log`
			
			slaDBI = null;
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * gets guid(s) mapped to the SLA
	 * 
	 * @param con
	 * @param lSLAId
	 * @return
	 * @throws Exception
	 */
	public String getSLAMappedGUIDs(Connection con, long lSLAId) throws Exception {
		SLADBI slaDBI = null;
		
		String strSLAMappedGUIDs = ""; 
		
		try {
			slaDBI = new SLADBI();
			
			strSLAMappedGUIDs = slaDBI.getSLAMappedActiveGUIDs(con, lSLAId);
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
		
		return strSLAMappedGUIDs;
	}
	
	/**
	 * Update Map counter
	 * @param con
	 * @param bean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateMapCounter(Connection con, MapCounterBean bean, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			// update SLA counter
			slaDBI.updateMapCounter(con, bean, loginUserBean);
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	public JSONArray getAllSLAAlert(Connection con, long lUserId, long lEID, String strModuleType, long lUID, long lCounterId) throws Exception {
		SLADBI slaDBI = null;
		JSONArray jaAllAlerts = null;
		try {
			slaDBI = new SLADBI();
			
			// update SLA counter
			jaAllAlerts = slaDBI.getAllSLAAlert(con, lUserId, lEID, strModuleType, lUID, lCounterId);
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
		return jaAllAlerts;
	}

	public boolean isValidActionName(Connection con, SLAActionBean actionBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI sladbi = null;
		boolean bActionExists = false;
		
		try {
			sladbi = new SLADBI();
			
			// as new insert checks user's action already exists, "-1" hardcoding since its a new insert
			bActionExists = sladbi.isActionExists(con, actionBean.getActionName(), actionBean.getActionId(), loginUserBean);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bActionExists;
	}
	public boolean isValidRuleName(Connection con, SLARuleBean ruleBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI sladbi = null;
		boolean bRuleExists = false;
		
		try {
			sladbi = new SLADBI();
			
			// as new insert checks user's rule already exists, "-1" hardcoding since its a new insert
			bRuleExists = sladbi.isRuleExists(con, ruleBean.getRuleName(), ruleBean.getRuleId(), loginUserBean);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bRuleExists;
	}
	
	public boolean isValidPolicyName(Connection con, SLABean slaBean, /*LoginUserBean loginUserBean*/ long lUser_id) throws Exception {
		SLADBI sladbi = null;
		boolean bPolicyExists = false;
		
		try {
			sladbi = new SLADBI();
			
			// as new insert checks user's policy already exists, "-1" hardcoding since its a new insert
			bPolicyExists = sladbi.isSLANameExist(con, slaBean.getSLAName(), slaBean.getSLAId(), /*loginUserBean*/ lUser_id);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bPolicyExists;
	}
	
	/**
	 * update in counter_master_<uid> table, 
	 *  for the created counter's which added with SLA policy & map counter of Threshold Breach Type
	 * @param con
	 * @param lUId
	 * @param lSLAId
	 * @param lCounterId
	 * @throws Exception
	 */
	public void updateMappedSLAIdWithCounterForThresholdBreach(Connection con, long lUId, long lSLAId, long lCounterId) throws Exception {
		SLADBI sladbi = null;
		
		try {
			sladbi = new SLADBI();

			sladbi.updateMappedSLAIdWithCounterForThresholdBreach(con, lUId, lSLAId, lCounterId);
		} catch (Exception e) {
			throw e;
		} finally {
			sladbi = null;
		}
	}
	
	/**
	 * update in counter_master_<uid> table, 
	 *  for the created counter's which added with SLA policy & map counter of Warning Type
	 *  
	 *  future USE, added for uid's counter's to map with Warning breach type
	 *  
	 * @param con
	 * @param lUId
	 * @param lSLAId
	 * @param lCounterId
	 * @throws Exception
	 */
	public void updateMappedSLAIdWithCounterForWarningType(Connection con, long lUId, long lSLAId, long lCounterId) throws Exception {
		SLADBI sladbi = null;
		
		try {
			sladbi = new SLADBI();
			
			sladbi.updateMappedSLAIdWithCounterForWarningType(con, lUId, lSLAId, lCounterId);
		} catch (Exception e) {
			throw e;
		} finally {
			sladbi = null;
		}
	}
	
	public JSONArray getAllModuleSLABreachStatus(Connection con, long lUserId) throws Throwable {
		SLADBI sladbi = null;
		JSONArray jaAllModuleSLABreachStatus = new JSONArray(); 
		
		try {
			sladbi = new SLADBI();
			
			jaAllModuleSLABreachStatus = sladbi.getAllModuleSLABreachStatus(con, lUserId);
		} catch (Exception e) {
			throw e;
		} finally {
			sladbi = null;
		}
		
		return jaAllModuleSLABreachStatus;
	}
	
	/**
	 * Create the all module's SLA breach history tables for the given User_Id.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void createSLABreachPartitionTable(Connection con, long lUserId) throws Exception {
		SLADBI sladbi = null;
		
		try {
			sladbi = new SLADBI();
			
			// Create the ASD module's SLA breach partition tables
			sladbi.createSLABreachPartitionTable(con, lUserId);
			
			// Create the SUM module's SLA breach partition tables
			sladbi.createSUMThresholdBreahTable(con, lUserId);
			
			// Create the RUM module's SLA breach partition tables
			sladbi.createRUMThresholdBreahTable(con, lUserId);
		} catch (Throwable th) {
			throw th;
		} finally {
			sladbi = null;
		}
	}
	
	/**
	 * add SLA policy, 
	 * map module's/uid's counter to the created policy, 
	 * update sla_id in `counter_master_<uid>` 
	 * 
	 * @param con
	 * @param slaBean
	 * @param mapCounterBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addSLAPolicyMapToCounterForThresholdBreach(Connection con, SLABean slaBean, MapCounterBean mapCounterBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		long lSLAId = -1l;
		
		try {
			// add SLA policy 
			lSLAId = addSla(con, slaBean, loginUserBean, joEnt);
			if( lSLAId == -1l ) {
				// SLA policy already exists for the user
				throw new Exception("1");
			}
			mapCounterBean.setSLAId( slaBean.getSLAId() );
			
			// TODO: thinks, ASK to throw using user defined exception example, 
			// handle try catch, since to avoid, throw same exception message `1`
			try {
				// map counter to added SLA
				addMapCounter(con, mapCounterBean, loginUserBean);
			} catch(Exception e) {
				if ( e.getMessage().equals("1") ) {
					// err, module's/uid's counter name
					throw new Exception("2");
				}
			}
			
			// update in counter_master_<uid>, added SLA policy id to which the counter has been mapped 
			updateMappedSLAIdWithCounterForThresholdBreach(con, mapCounterBean.getUId(), slaBean.getSLAId(), mapCounterBean.getCounterId());
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets particular module's/uid's SLA policy details,
	 * (ie.. SLAs which are added after ASD add)
	 * 
	 * @param con
	 * @param lUId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleAutogeneratedSLAs(Connection con, long lUId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		JSONArray jaModuleAutogeneratedSLAs = null;
		
		try {
			slaDBI = new SLADBI();
			
			jaModuleAutogeneratedSLAs = slaDBI.getModuleAutogeneratedSLAs(con, lUId, loginUserBean.getUserId());
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaModuleAutogeneratedSLAs;
	}
	
	/**
	 * configure SLA alerts to a SUM test
	 * Note: In `so_sla_sum`, sla_id and sum_test_id is unique, 
	 *   (i.e. Multiple SLAs can't map for a SUM test 
	 *      and a same sla_id can't map for different SUM tests)
	 *  
	 * @param con
	 * @param slaBean
	 * @param slasumBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void configureSLAToSUMTestForThresholdBreach(Connection con, SLABean slaBean, SLASUMBean slasumBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		Long lSLAIdToMappedToSUM = null;

		try {
			// gets SLA for SUM test
			lSLAIdToMappedToSUM = getSLAMappedForSUMTest(con, slasumBean, loginUserBean);

			// add or update SLA policy 
			if ( lSLAIdToMappedToSUM == null && slasumBean.isEnableAlert() ) {
				// add SLA policy and map to SUM test; adds if SUM alert isEnabled
				addSLAPolicyMapToSUMTest(con, slaBean, slasumBean, loginUserBean, joEnt);
			} else if ( lSLAIdToMappedToSUM != null  ) {
				// mapped SLA id for SUM test; update if already added
				slaBean.setSLAId(lSLAIdToMappedToSUM);
				slasumBean.setSlaId(lSLAIdToMappedToSUM);

				// update SLA policy and SUM alert config.
				updateSLAPolicyMapToSUMTest(con, slaBean, slasumBean, loginUserBean);
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * adds SLA policy and map to SUM test
	 * 
	 * @param con
	 * @param slaBean
	 * @param slasumBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addSLAPolicyMapToSUMTest(Connection con, SLABean slaBean, SLASUMBean slasumBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		long lSLAId = -1l;
		
		try {
			// add SLA policy, (i.e. The SUM test is not mapped to SLA)
			lSLAId = addSla(con, slaBean, loginUserBean, joEnt);
			if( lSLAId == -1l ) {
				// SLA policy already exists for the user
				throw new Exception("1");
			}
			// adds SLA id into beans
			slasumBean.setSlaId(slaBean.getSLAId());
			
			// map SUM test to SLA policy
			addSlaSum(con, slasumBean, loginUserBean);
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * updates SLA policy & SUM alert configs.
	 * 
	 * @param con
	 * @param slaBean
	 * @param slasumBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSLAPolicyMapToSUMTest(Connection con, SLABean slaBean, SLASUMBean slasumBean, LoginUserBean loginUserBean) throws Exception {
		try {
			// update SLA policy
			updateSLA(con, slaBean, loginUserBean.getUserId());
			
			// update SUM thresholds for the SLA
			updateSlaSum(con, slasumBean, loginUserBean);
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets SLA mapped for SUM test,
	 * Note: only one SLA can configured for a SUM test, in other sense we can't have a SUM test for multiple SLAs
	 *   (i.e. sum_test_id is unique in `so_sla_sum`)
	 *   
	 * @param con
	 * @param lSUMTestId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public Long getSLAMappedForSUMTest(Connection con, SLASUMBean slasumBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;

		Long lSLAId = null;

		try {
			slaDBI = new SLADBI();

			// gets SLA for SUM test
			lSLAId = slaDBI.getSLAMappedForSUMTest(con, slasumBean, loginUserBean.getUserId());

			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}

		return lSLAId;
	}
	
	/**
	 * configure SLA alerts to a RUM module 
	 * Note: In `so_sla_rum`, sla_id and uid is unique, 
	 *   (i.e. Multiple SLAs can't map for a RUM module/uid AND a same sla_id can't map for multiple RUM module/uid)
	 *      
	 * @param con
	 * @param slaBean
	 * @param rumslaBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void configureSLAToRUMModule(Connection con, SLABean slaBean, RUMSLABean rumslaBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		Long lRUMModuleSLAId = null;
		
		try {
			// gets SLA for RUM module 
			lRUMModuleSLAId = getRUMModuleSLAId(con, rumslaBean.getUId(), loginUserBean);
			
			// add or update SLA policy 
			if ( lRUMModuleSLAId == null && rumslaBean.isEnableResponseAlert() ) {
				// add SLA policy and map to RUM module/uid; adds if RUM alert isEnabled 
				addSLARUMModule(con, slaBean, rumslaBean, loginUserBean, joEnt);
			} else if ( lRUMModuleSLAId != null  ) {
				// mapped SLA id for RUM module/uid; update if already added 
				slaBean.setSLAId(lRUMModuleSLAId);
				rumslaBean.setSlaId(lRUMModuleSLAId);
				
				// update SLA policy and RUM alert config. 
				updateSLARUMModule(con, slaBean, rumslaBean, loginUserBean);
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * add SLA policy and map the SLA to RUM module, with the threshold input 
	 * 
	 * @param con
	 * @param slaBean
	 * @param rumslaBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void addSLARUMModule(Connection con, SLABean slaBean, RUMSLABean rumslaBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		long lSLAId = -1l;
		
		try {
			// add SLA policy, for the RUM module
			lSLAId = addSla(con, slaBean, loginUserBean, joEnt);
			if( lSLAId == -1l ) {
				// SLA policy already exists for the user
				throw new Exception("1");
			}
			// adds SLA id into beans
			rumslaBean.setSlaId(slaBean.getSLAId());
			
			// map RUM module to SLA policy
			addSLARUMThreshold(con, rumslaBean, loginUserBean);
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * updates SLA Policy and update mapped RUM module/uid's threshold, if response alert is enabled
	 * 
	 * @param con
	 * @param slaBean
	 * @param rumslaBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSLARUMModule(Connection con, SLABean slaBean, RUMSLABean rumslaBean, LoginUserBean loginUserBean) throws Exception {
		
		try {
			// update SLA policy
			updateSLA(con, slaBean, loginUserBean.getUserId());
			
			if ( rumslaBean.isEnableResponseAlert() ) {
				// update RUM module's thresholds for the SLA, if Response Alert is enabled
				updateSLARUMThreshold(con, rumslaBean, loginUserBean);	
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * update RUM module/uid threshold limits 
	 * 
	 * @param con
	 * @param rumslaBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSLARUMThreshold(Connection con, RUMSLABean rumslaBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.updateSLARUMModule(con, rumslaBean, loginUserBean);
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets `sla_id` mapped for the RUM module/uid
	 * 
	 * @param con
	 * @param lUId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public Long getRUMModuleSLAId(Connection con, long lUId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		Long lSLAId = null;
		
		try {
			slaDBI = new SLADBI();
			
			// gets mapped `sla_id`, for the RUM module
			lSLAId = slaDBI.getRUMModuleSLAId(con, lUId, loginUserBean.getUserId());
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return lSLAId;
	}
	
	/**
	 * add RUM uid's threshold limits 
	 * 
	 * @param con
	 * @param rumslaBean
	 * @param loginBean
	 * @return
	 * @throws Exception
	 */
	public long addSLARUMThreshold(Connection con, RUMSLABean rumslaBean, LoginUserBean loginBean) throws Exception {
		long lSLARUMId = -1L;
		
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();	
			
			lSLARUMId = slaDBI.addSLARUMThreshold(con, rumslaBean, loginBean);
			
			slaDBI = null;
		} catch(Exception e) {
			throw e;
		}
		
		return lSLARUMId;
	}
	
	/**
	 * update SUM alert configs.
	 * 
	 * @param con
	 * @param slasumBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSlaSum(Connection con, SLASUMBean slasumBean, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.updateSlaSum(con, slasumBean, loginUserBean);
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	public String getSLAMappedActiveGUIDs(Connection con, long lSLAId) throws Exception {
		SLADBI slaDBI = null;
		
		String strSLAMappedGUIDs = "";
		
		try {
			slaDBI = new SLADBI();
			
			strSLAMappedGUIDs = slaDBI.getSLAMappedActiveGUIDs(con, lSLAId);
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return strSLAMappedGUIDs;
	}
	
	/**
	 * delete SLA logically
	 * 
	 * @param con
	 * @param lSLAId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void logicallyDeleteSLAs(Connection con, long lSLAId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.logicallyDeleteSLAs(con, lSLAId, loginUserBean.getUserId());
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * delete SLA's, mapped references
	 * 
	 * @param con
	 * @param lSLAId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteSLAs(Connection con, long lSLAId, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.deleteSLAs(con, lSLAId, loginUserBean.getUserId());
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * enable or disable SLA policy
	 * 
	 * @param con
	 * @param lSLAId
	 * @param bActivePolicy
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void enableOrDisableSLA(Connection con, long lSLAId, boolean bActivePolicy, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		try {
			slaDBI = new SLADBI();
			
			slaDBI.enableOrDisableSLA(con, lSLAId, bActivePolicy, loginUserBean.getUserId());
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	  
	/**
	 * deletes SLA(s) which are mapped with the GUID,
	 * disable SLA(s) which has the GUID of delete and another GUID mapped
	 * 
	 * @param con
	 * @param strGUID
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public Object[] deleteASDSLAs(Connection con, String strGUID, LoginUserBean loginUserBean) throws Exception {
		SLADBI slaDBI = null;
		
		HashMap<String, ArrayList<HashMap<String, Object>>> hmDeleteSLAs = null;
		HashMap<String, Object> hmSLA = null;
		
		ArrayList<HashMap<String, Object>> alSLAs = null;
		//ArrayList<HashMap<String, String>> alDifferentGUIDSLAs = null;
		
		HashSet<String> hsDisableSLAGUIDs = null;
		
		String strSLAIds = "", strDisableSLAGUIDs = "";
		String[] saMappedGUIDs = null;
		
		boolean bRtnNewGUID = false;
		
		//int idx = 0;
		
		try {
			slaDBI = new SLADBI();
			
			// gets SLA(s) which are mapped with delete of GUID AND SLA(s) has GUID of delete and another GUID(s) mapped
			hmDeleteSLAs = slaDBI.getGUIDMappedSLAs(con, strGUID, loginUserBean.getUserId());
			
			// delete SLAs, which are mapped with the GUID
			alSLAs = hmDeleteSLAs.get("single_guid_mapped_with_slas");
			for (int i = 0; i < alSLAs.size(); i = i + 1) {
				hmSLA = alSLAs.get(i);
				deleteSLAs(con, (Long) hmSLA.get("sla_id"), loginUserBean);
			}
			
			// disable SLAs, the GUID's for delete SLA(s) has different GUID(s) mapped to the SLA
			alSLAs = hmDeleteSLAs.get("different_guid_mapped_with_slas");
			if ( alSLAs.size() > 0 ) {
				hsDisableSLAGUIDs = new HashSet<String>();
				
				for (int i = 0; i < alSLAs.size(); i = i + 1) {
					hmSLA = alSLAs.get(i);
					saMappedGUIDs = ((String) hmSLA.get("mapped_guids")).split(",");
					
					// disable SLA(s),
					if ( i != 0 ) {
						strSLAIds += ",";
					}
					strSLAIds += hmSLA.get("sla_id");
					
					/*
					 * collect the GUID(s) of SLA(s) to disable, since has to update in Collector for running agent,
					 * the SLA(s) has the GUID of delete AND another GUID(s) had mapped to the SLA(s)
					 */
					for(String strMappedGUID : saMappedGUIDs) {
						// other than that the delete of GUID(s)
						if ( ! strMappedGUID.equals(strGUID) ) {
							bRtnNewGUID = hsDisableSLAGUIDs.add(strMappedGUID);
							if ( bRtnNewGUID ) {
								if ( hsDisableSLAGUIDs.size() > 1 ) {
									strDisableSLAGUIDs += ",";
								}
								strDisableSLAGUIDs += strMappedGUID;
							}
						}
					}
				}
				
				// disable the SLA(s); delete the counter(s) from `so_sla_counter` mapped with `strGUID`,   
				slaDBI.disableSLAHasDifferentGUIDMapped(con, strGUID, strSLAIds, loginUserBean.getUserId());
			}
			
			slaDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return new Object[]{hmDeleteSLAs, strDisableSLAGUIDs};
	}

}
