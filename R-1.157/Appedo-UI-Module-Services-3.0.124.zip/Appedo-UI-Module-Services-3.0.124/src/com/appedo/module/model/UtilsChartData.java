package com.appedo.module.model;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import com.appedo.module.common.Constants;

import net.sf.json.JSONObject;

/**
 * Might use in future, as per Sriraman sir tried, 
 * @author Navin
 *
 */
public class UtilsChartData {

	public ArrayList<JSONObject> getCounterSet(ResultSet rst) throws Exception {
		ResultSetMetaData rstmd = null;

		int nColCnt = 0;
		
		ArrayList<JSONObject> alCounterSet = null;

		JSONObject joDatum = null;

		try {
			alCounterSet = new ArrayList<JSONObject>();

			System.out.println("111111111111133333333333333333");
			rstmd = rst.getMetaData();
			nColCnt = rstmd.getColumnCount();
			while(rst.next()) {
				// 1 for (x-axis) ColumnName must be `T`  &  2 is (y-axis) ColumnName must be `V`
				joDatum = new JSONObject();
				joDatum.put(rstmd.getColumnName(1).toUpperCase(), rst.getString(1));
				joDatum.put(rstmd.getColumnName(2).toUpperCase(), rst.getString(2));

				alCounterSet.add(joDatum);
			}

			System.out.println("alCounterSet: "+alCounterSet);
		} catch (Exception e) {
			throw e;
		} finally {
			rstmd = null;
		}
		
		return alCounterSet;
	}
	
	
	public void breakCounterSet(ArrayList<JSONObject> alCounterSet, ArrayList<ArrayList<JSONObject>> alCounterData) {
		JSONObject joDatum = null;

		long lTime = -1L;
		long lPrevTime = -1L, lDuration = -1L;

		ArrayList<JSONObject> alNewCounterSet = new ArrayList<JSONObject>();

		for(int i = 0; i < alCounterSet.size(); i++) {
			joDatum = alCounterSet.get(i);
			//System.out.println("joDatum: "+joDatum);
			lTime = joDatum.getLong("T");
			
			if ( i != 0 ) {
				lDuration = lTime - lPrevTime;
				
				// If there the time difference between current & previous is more than 1 minute, then store the datum in a new Array
				if( lDuration > Constants.COUNTER_CHART_TIME_INTERVAL ) {
					alNewCounterSet = new ArrayList<JSONObject>();
					alCounterData.add(alNewCounterSet);
				}
			} else {
				//alNewCounterSet = new ArrayList<JSONObject>();
				alCounterData.add(alNewCounterSet);
			}
			
			alNewCounterSet.add(joDatum);
			
			
			lPrevTime = lTime;
		}
	}
}
