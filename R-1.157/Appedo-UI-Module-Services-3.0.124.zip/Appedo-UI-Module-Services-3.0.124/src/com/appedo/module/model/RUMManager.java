package com.appedo.module.model;

import java.sql.Connection;
import java.util.Date;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.dbi.ChartDBI;
import com.appedo.module.dbi.RUMDBI;

public class RUMManager {

	/*
	public JSONArray getRUMTests(Connection con,long lUID) throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRUMTests = null;
		
		try{
			rumDBI = new RUMDBI();
			
			jaRUMTests = rumDBI.getRUMTests(con, lUID);
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaRUMTests;
	}
	
	/**
	 * get
	 * @param con
	 * @param lUID
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getPagesLoadTime(Connection con, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean) throws Exception {
		RUMDBI rumDBI = null;
		
		JSONArray jaRtnPagesLoadTime = null;
		
		try {
			rumDBI = new RUMDBI();
			
			jaRtnPagesLoadTime = rumDBI.getPagesLoadTime(con, lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			
			rumDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return jaRtnPagesLoadTime;
	}
	
	public JSONArray getPagesLoadTimeWithDateRange(Connection con, long lUID, String strFromStartInterval, String strToInterval) throws Exception {
		RUMDBI rumDBI = null;
		
		JSONArray jaRtnPagesLoadTime = null;
		
		try {
			rumDBI = new RUMDBI();
			
			jaRtnPagesLoadTime = rumDBI.getPagesLoadTimeWithDateRange(con, lUID, strFromStartInterval, strToInterval);
			
			rumDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return jaRtnPagesLoadTime;
	}

	/**
	 * gets page loaded times
	 * 
	 * @param con
	 * @param strUid
	 * @param strFromStartInterval
	 * @param strURL
	 * @return
	 * @throws Exception
	 */
	public JSONArray getPageLoadTimeChartData(Connection con, String strUid, String strFromStartInterval, String strURL, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean) throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaPageLoadTimes = null;
		
		try {
			rumDBI = new RUMDBI();
			
			jaPageLoadTimes = rumDBI.getPageLoadTimeChartData(con, Long.parseLong(strUid), strFromStartInterval, strURL, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			
			rumDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return jaPageLoadTimes;
	}
	
	public JSONArray getPageLoadTimeChartDataWithDateRange(Connection con, String strUid, String strFromStartInterval, String strToInterval, String strURL) throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaPageLoadTimes = null;
		
		try {
			rumDBI = new RUMDBI();
			
			jaPageLoadTimes = rumDBI.getPageLoadTimeChartDataWithDateRange(con, Long.parseLong(strUid), strFromStartInterval, strToInterval, strURL);
			
			rumDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return jaPageLoadTimes;
	}
	
	public JSONObject getPageBreakDownDetails(Connection con, long lUId, long lRUMId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		RUMDBI rumDBI = null;
		
		JSONObject joPageBreakDownDetails = null;
		
		try {
			rumDBI = new RUMDBI();
			
			joPageBreakDownDetails = rumDBI.getPageBreakDownDetails(con, lUId, lRUMId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills);
			
//			for(int i=0; i<jaRtn.size(); i++){
//				JSONObject jo = jaRtn.getJSONObject(i);
//				if(lMax<jo.getLong("time")){
//					lMax = jo.getLong("time");
//				}
//			}
//			
//			for(int i=0; i<jaRtn.size(); i++){
//				JSONObject jo = jaRtn.getJSONObject(i);
//				jo.put("percentage",(jo.getLong("time")*100)/lMax != 0 ? jo.getLong("time")*100/lMax : 1 ); //fPercentagAvgLoadTime != 0 ? fPercentagAvgLoadTime : 1
//				jaChartData.add(jo);
//			}
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}
		
		return joPageBreakDownDetails;
	}

	public JSONArray getPageBreakDownDetailsWithDateRange(Connection con, String strUid, String strFromStartInterval, String strToInterval, String strRUMId) throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		
		try {
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getPageBreakDownDetailsWithDateRange(con, Long.parseLong(strUid), Long.parseLong(strRUMId), strFromStartInterval, strToInterval);
			
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaRtn;
	}

	public JSONArray getBrowserChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean)  throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getBrowserChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}
	
	
	/*public JSONObject getRumAllCharts_v1(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean, String legendText, String chartQuery)  throws Exception {
		RUMDBI rumDBI = null;
		JSONObject joRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			joRtn = rumDBI.getRumAllCharts_v1(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId(), legendText, chartQuery);
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return joRtn;
	}*/
	
	public JSONArray getBrowserChartdataWithDateRange(Connection con, String strUid, String strFromStartInterval, String strToInterval)  throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getBrowserChartdataWithDateRange(con, Long.parseLong(strUid), strFromStartInterval, strToInterval);
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}
	
	public JSONArray getOSChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean)  throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try {
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getOSChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}
	
	public JSONArray getOSChartdataWithDateRange(Connection con, String strUid, String strFromStartInterval, String strToInterval)  throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try {
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getOSChartdataWithDateRange(con, Long.parseLong(strUid), strFromStartInterval, strToInterval);
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}
	
	public JSONArray getDeviceTypeChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean)  throws Exception {
		
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getDeviceTypeChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}
	
	public JSONArray getDeviceTypeChartdataWithDateRange(Connection con, String strUid, String strFromStartInterval, String strToInterval)  throws Exception {
		
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getDeviceTypeChartdataWithDateRange(con, Long.parseLong(strUid), strFromStartInterval, strToInterval);
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}

	public JSONArray getDeviceNamesChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean)  throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getDeviceNamesChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}	
	
	public JSONArray getLocationChartdata(Connection con, long lUId, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean)  throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getLocationChartdata(con, lUId, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}
	
	public String getLocationChartdataForWorldMap(Connection con, String strUid, String strFromStartInterval)  throws Exception {
		RUMDBI rumDBI = null;
		String jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getLocationChartdataForWorldMap(con, Long.parseLong(strUid), strFromStartInterval);
			rumDBI = null;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}

	public JSONArray getRUMLocationChartDataWithDateRange(Connection con, String strUid, String strFromStartInterval, String strToInterval)  throws Exception {
		RUMDBI rumDBI = null;
		JSONArray jaRtn = null;
		Date dateLog = LogManager.logMethodStart();
		try{
			rumDBI = new RUMDBI();
			
			jaRtn = rumDBI.getRUMLocationChartDataWithDateRange(con, Long.parseLong(strUid), strFromStartInterval, strToInterval);
			rumDBI = null;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
		    LogManager.logMethodEnd(dateLog);
		}
		return jaRtn;
	}
	
	public long getUID(Connection con, String strGUID) throws Exception {
		
		RUMDBI rumDBI = null;
		long lUID = -1L;
		try{
			
			rumDBI = new RUMDBI();
			
			lUID = rumDBI.getUID(con, strGUID);
			rumDBI = null;
		}catch(Exception e){
			throw e;
		}
		return lUID;
	}
	
	/**
	 * Gets Total Visitors count for the particular User's UID,
	 * for the given time interval.
	 * 
	 * @param con
	 * @param lUID
	 * @throws Exception
	 */
	public JSONObject getVisitorsCount(Connection con, long lUID, String strFromStartInterval) throws Exception {
		Date dateLog = LogManager.logMethodStart();
		
		RUMDBI rumdbi = null;
		
		JSONObject joVisitorsCount = null;

		try {
			rumdbi = new RUMDBI();
			
			joVisitorsCount = rumdbi.getVisitorsCount(con, lUID, strFromStartInterval);
			
		} catch (Exception e) {
			System.out.println("Exception in getVisitorsCount: "+e.getMessage());
			throw e;
		} finally {
			LogManager.logMethodEnd(dateLog);
		}
		
		return joVisitorsCount;
	}
	
	/**
	 * gets daily visitors count chart data for the particular user's uid
	 * 
	 * @param con
	 * @param lUID
	 * @throws Exception
	 */
	public JSONObject getDailyVisitorsCount(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode) throws Throwable {
		RUMDBI rumdbi = null;
		
		JSONObject joDailyVisitorsCount = null;
		
		try {
			rumdbi = new RUMDBI();
			
			joDailyVisitorsCount = rumdbi.getDailyVisitorsCount(con, lUserId, lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode);
			
			rumdbi = null;
		} catch (Throwable th) {
			throw th;
		}
		
		return joDailyVisitorsCount;
	}
	
	public JSONObject getDailyVisitorsCount_v1(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, String query) throws Throwable {
		RUMDBI rumdbi = null;
		
		JSONObject joDailyVisitorsCount = null;
		
		try {
			rumdbi = new RUMDBI();
			
			joDailyVisitorsCount = rumdbi.getDailyVisitorsCount_v2(con, lUserId, lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, query);
			
			rumdbi = null;
		} catch (Throwable th) {
			throw th;
		}
		
		return joDailyVisitorsCount;
	}
	
	public JSONObject getDailyVisitorsCount_v2(Connection con, long lUserId, long lUID, String strFromStartInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, Long lMetricId, String strXYLabel, String strRumType) throws Exception {
		RUMDBI rumDBI = null;
		ChartDBI chartDBI = null;
		
		JSONObject joRUMChartData = null;
		String chartQuery = null;
		try {
			rumDBI = new RUMDBI();
			chartDBI = new ChartDBI();
			if (lMetricId == null) {
				throw new Exception("1");
			}
			
			chartQuery = chartDBI.getChartDataQuery(con, lUserId, lMetricId);
			
			if (strRumType != null) {
				joRUMChartData = rumDBI.getRumAllCharts_v1(con, lUserId, lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, chartQuery, strXYLabel);
			} else {
				joRUMChartData = rumDBI.getDailyVisitorsCount_v4(con, lUserId, lUID, strFromStartInterval, lStartDateTimeInMills, lEndDateTimeInMills, chartQuery, strXYLabel);
			}
			
			rumDBI = null;
		} catch (Exception ex) {
			throw ex;
		}
		
		return joRUMChartData;
	}
	
	public JSONArray getRUMCards(Connection con, long lUserId, JSONObject joEnt) throws Throwable {
		RUMDBI rumDBI = null;
		
		JSONArray jaRUMCardsData = null;
		
		try {
			rumDBI = new RUMDBI();
			jaRUMCardsData = rumDBI.getRUMCards(con, lUserId, joEnt);
			
			rumDBI = null;
		} catch (Throwable th) {
			throw th;
		}
		
		return jaRUMCardsData;
	}
	
	
	public JSONArray getRUMFilterValues(Connection con, long lUID, String filterType, String sliderInterval, long lStartDate, long lEndDate ) throws Throwable {
		RUMDBI rumDBI = null;
		
		JSONArray jaRUMFiltersData = null;
		
		try {
			rumDBI = new RUMDBI();
			jaRUMFiltersData = rumDBI.getRUMFilterValues(con, lUID, filterType, sliderInterval, lStartDate, lEndDate);
			
			rumDBI = null;
		} catch (Throwable th) {
			throw th;
		}
		
		return jaRUMFiltersData;
	} 
	public JSONArray getRUMDatas(Connection con, long lUID, String strSearchText, String filterType, String filterValue, String sliderInterval, long lStartDate, long lEndDate ) throws Throwable {
		RUMDBI rumDBI = null;
		
		JSONArray jaRUMDatas = null;
		
		try {
			rumDBI = new RUMDBI();
			jaRUMDatas = rumDBI.getRUMDatas(con, lUID, strSearchText, filterType, filterValue, sliderInterval, lStartDate, lEndDate);
			
			rumDBI = null;
		} catch (Throwable th) {
			throw th;
		}
		
		return jaRUMDatas;
	}
	
	public JSONObject getDailyVisitorsCountWithDateRange(Connection con, long lUID, String strFromStartInterval, String strToInterval) throws Exception {
		RUMDBI rumdbi = null;
		
		JSONObject joDailyVisitorsCount = null;

		try {
			rumdbi = new RUMDBI();
			
			joDailyVisitorsCount = rumdbi.getDailyVisitorsCountWithDateRange(con, lUID, strFromStartInterval,strToInterval);
			
			rumdbi = null;
		} catch (Exception e) {
			
			throw e;
		}
		
		return joDailyVisitorsCount;
	}
	
	public JSONArray getRUMSiteDetails(Connection con, LoginUserBean loginBean) throws Exception {
		RUMDBI rumdbi = null;
		JSONArray json = null;

		try {
			rumdbi = new RUMDBI();
			
			json = rumdbi.getRUMSiteDetails(con, loginBean);
		} catch (Exception e) {
			System.out.println("Exception in getRUMSiteDetails: "+e.getMessage());
			throw e;
		}finally{
			rumdbi = null;
		}
		return json;
	}
	public JSONArray getRUMSiteTransDetails(Connection con, long lUID,String type, JSONObject joEnterprise) throws Exception {
		RUMDBI rumdbi = null;
		JSONArray json = null;
		try {
			rumdbi = new RUMDBI();
			
			json = rumdbi.getRUMSiteTransDetails(con, lUID, type, joEnterprise);
		} catch (Exception e) {
			System.out.println("Exception in getRUMSiteDetails: "+e.getMessage());
			throw e;
		}finally{
			rumdbi = null;
		}
		return json;
	}
	public JSONArray getRUMAgentStatus(Connection con, long lUID) throws Exception {
		RUMDBI rumdbi = null;
		JSONArray json = null;
		try {
			rumdbi = new RUMDBI();
			
			json = rumdbi.getRUMAgentStatus(con, lUID);
		} catch (Exception e) {
			System.out.println("Exception in getRUMAgentStatus: "+e.getMessage());
			throw e;
		}finally{
			rumdbi = null;
		}
		return json;
	}
	public JSONArray getRUMDashDonut(Connection con,String interval, String moduleType, String uid) throws Exception{
		RUMDBI rumdbi = null;
		JSONArray json = null;
		try {
			rumdbi = new RUMDBI();
			
			json = rumdbi.getRUMDashDonut(con, interval,moduleType,uid);
		} catch (Exception e) {
			System.out.println("Exception in getRUMAgentStatus: "+e.getMessage());
			throw e;
		}finally{
			rumdbi = null;
		}
		return json;	
	}
	public JSONArray getRUMDashArea(Connection con, String interval, String uid) throws Exception{
		RUMDBI rumdbi = null;
		JSONArray json = null;
		try {
			rumdbi = new RUMDBI();
			
			json = rumdbi.getRUMDashArea(con, interval,uid);
		} catch (Exception e) {
			System.out.println("Exception in getRUMAgentStatus: "+e.getMessage());
			throw e;
		}finally{
			rumdbi = null;
		}
		return json;	
	}
	
	/**
	 * gets lastReceivedOn for particular RUM moduleName
	 * 
	 * @param con
	 * @param lUID
	 * @return
	 * @throws Exception
	 */
	public long getRUMLastReceivedOn(Connection con, long lUID) throws Exception {
		RUMDBI rumdbi = null;
		
		long lLastReceivedOn = 0L;
		
		try {
			rumdbi = new RUMDBI();
			
			lLastReceivedOn = rumdbi.getRUMLastReceivedOn(con, lUID);
			
			rumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lLastReceivedOn;
	}
	
	public String getRumAvgPageLoadTimeDonutCount(Connection con, LoginUserBean loginUserBean,String interval) throws Exception {
		RUMDBI rumdbi = null;

		String donutCount = null;

		try {
			rumdbi = new RUMDBI();

			donutCount = rumdbi.getRumAvgPageLoadTimeDonutCount(con, loginUserBean,interval);
			
			rumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return donutCount;
	}

	public String getRumUrlWisePageView(Connection con, LoginUserBean loginUserBean,String interval) throws Exception {
		RUMDBI rumdbi = null;

		String barChart = null;

		try {
			rumdbi = new RUMDBI();

			barChart = rumdbi.getRumUrlWisePageView(con, loginUserBean,interval);
			
			rumdbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return barChart;
	}
	
	/**
	 * gets RUM's most time taken responses, based on Browser, City, Device or Os
	 * 
	 * @param con
	 * @param lUId
	 * @param strType
	 * @param strTypeValue
	 * @param strInterval
	 * @param lStartDateTimeInMills
	 * @param lEndDateTimeInMills
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getTopRUMResponses(Connection con, long lUId, String strType, String strTypeValue, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, String strHealthCode, LoginUserBean loginUserBean) throws Exception {
		RUMDBI rumdbi = null;
		
		JSONArray jaTopRUMResponses = null;
		
		try {
			rumdbi = new RUMDBI();
			
			jaTopRUMResponses = rumdbi.getTopRUMResponses(con, lUId, strType, strTypeValue, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode, loginUserBean.getUserId());
			
			rumdbi = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaTopRUMResponses;
	}
}
