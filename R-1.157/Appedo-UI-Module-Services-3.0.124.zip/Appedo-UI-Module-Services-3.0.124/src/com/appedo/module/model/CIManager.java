package com.appedo.module.model;

import java.sql.Connection;
import java.util.LinkedHashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.manager.LogManager;
import com.appedo.module.bean.CILicenseBean;
import com.appedo.module.dbi.CIDBI;
import com.appedo.module.utils.UtilsFactory;

public class CIManager {

	public JSONArray getEventsSummary(Connection con, long lUID, String strFromStartInterval, String strAgentType, String strEnvironmnet, long lUserId, String strRUMLicLevel) throws Exception {
		CIDBI cidbi = null;
		
		CILicenseBean ciLicenseBean = null;
		
		JSONArray jaEventSummaries = null;
		
		try {
			cidbi = new CIDBI();
			
			ciLicenseBean = getCIUserLicenseDetails(con, lUserId, strRUMLicLevel);
			if ( ciLicenseBean == null ) {
				throw new Exception("1");
			}
			
			jaEventSummaries = cidbi.getEventsSummary(con, lUID, strFromStartInterval, ciLicenseBean.getMaxEvents(), strAgentType, strEnvironmnet);

			cidbi = null;
			ciLicenseBean = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaEventSummaries;
	}
	
	public JSONArray getEventsSummaryWithDateRange(Connection con, long lUID, String strFromStartInterval, String strToInterval, String strAgentType, String strEnvironmnet, long lUserId, String strRUMLicLevel) throws Exception {
		CIDBI cidbi = null;
		
		CILicenseBean ciLicenseBean = null;
		
		JSONArray jaEventSummaries = null;
		
		try {
			cidbi = new CIDBI();
			
			ciLicenseBean = getCIUserLicenseDetails(con, lUserId, strRUMLicLevel);
			if ( ciLicenseBean == null ) {
				throw new Exception("1");
			}
			
			jaEventSummaries = cidbi.getEventsSummaryWithDateRange(con, lUID, strFromStartInterval, strToInterval, ciLicenseBean.getMaxEvents(), strAgentType, strEnvironmnet);

			cidbi = null;
			ciLicenseBean = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaEventSummaries;
	}
	
	public JSONObject getEventLoadTime(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONObject joEventLoadTime = null;
		
		try {
			cidbi = new CIDBI();
			
			joEventLoadTime = cidbi.getEventLoadTime(con, lUID, lEventId, strFromStartInterval);
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joEventLoadTime;
	}
	
	public JSONObject getEventLoadTimeWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONObject joEventLoadTime = null;
		
		try {
			cidbi = new CIDBI();
			
			joEventLoadTime = cidbi.getEventLoadTimeWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joEventLoadTime;
	}
	
	public JSONArray getBrowserWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaBrowserShareData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaBrowserShareData = cidbi.getBrowserWiseData(con, lUID, lEventId, strFromStartInterval);
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaBrowserShareData;
	}
	
	public JSONArray getBrowserWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaBrowserShareData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaBrowserShareData = cidbi.getBrowserWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaBrowserShareData;
	}

	public JSONArray getDeviceTypeWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceTypeWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceTypeWiseData = cidbi.getDeviceTypeWiseData(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceTypeWiseData;
	}
	
	public JSONArray getDeviceTypeWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceTypeWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceTypeWiseData = cidbi.getDeviceTypeWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceTypeWiseData;
	}
	
	public JSONArray getOSWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaOSWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaOSWiseData = cidbi.getOSWiseData(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaOSWiseData;
	}
	
	public JSONArray getOSWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaOSWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaOSWiseData = cidbi.getOSWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaOSWiseData;
	}
	
	public JSONArray getDeviceNameWiseData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceNameWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceNameWiseData = cidbi.getDeviceNameWiseData(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceNameWiseData;
	}
	
	public JSONArray getDeviceNameWiseDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceNameWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceNameWiseData = cidbi.getDeviceNameWiseDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceNameWiseData;
	}
	
	public JSONObject getDailyVisitorsCount(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONObject joDailyVisitorsCount = null;

		try {
			cidbi = new CIDBI();
			
			joDailyVisitorsCount = cidbi.getDailyVisitorsCount(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getDailyVisitorsCount: "+e.getMessage());
			throw e;
		}
		
		return joDailyVisitorsCount;
	}
	
	public JSONObject getDailyVisitorsCountWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONObject joDailyVisitorsCount = null;

		try {
			cidbi = new CIDBI();
			
			joDailyVisitorsCount = cidbi.getDailyVisitorsCountWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getDailyVisitorsCountWithDateRange: "+e.getMessage());
			throw e;
		}
		
		return joDailyVisitorsCount;
	}

	public JSONArray getEventProperties(Connection con, long lUID, long lEventId, long lUserId, String strRUMLicLevel) throws Exception {
		CIDBI cidbi = null;

		CILicenseBean ciLicenseBean = null;
		
		JSONArray jaEventProperties = null;
		
		try {
			cidbi = new CIDBI();

			ciLicenseBean = getCIUserLicenseDetails(con, lUserId, strRUMLicLevel);
			if ( ciLicenseBean == null ) {
				throw new Exception("1");
			}
			
			jaEventProperties = cidbi.getEventProperties(con, lUID, lEventId, ciLicenseBean.getMaxProperties());
			
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getEventProperties: "+e.getMessage());
			throw e;
		}
		
		return jaEventProperties;
	}

	public JSONArray getEventPropertyValues(Connection con, long lUID, long lEventId, long lEvtPropId) throws Exception {
		CIDBI cidbi = null;
		
		String strPropertyColumnName = "";
		
		JSONArray jaEventPropertyValues = null;
		
		//ArrayList<String> alPropertyValues = null;

		try {
			cidbi = new CIDBI();

			
			strPropertyColumnName = cidbi.getEventPropertyColumnName(con, lUID, lEvtPropId);

			//
			jaEventPropertyValues = cidbi.getEventPropertyValues(con, lUID, lEventId, strPropertyColumnName);
			//alPropertyValues =  cidbi.getEventPropertyValues(con, lUID, lEventId, strPropertyColumnName);

			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getEventPropertyValues: "+e.getMessage());
			throw e;
		}
		
		return jaEventPropertyValues;
	}
	
	/**
	 * gets respective event's transactions of particular given columns
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param lEvtPropId
	 * @param strPropertyValue
	 * @return
	 * @throws Exception
	 */
	public JSONArray getEventTransactions(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyValue, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;

		String strPropertyColumnName = "";
		
		JSONArray jaEventTransactions = null;

		try {
			cidbi = new CIDBI();
			
			// for `ALL` values to show, avoided to get respective property's column name
			if( lEvtPropId != -1 ) {
				strPropertyColumnName = cidbi.getEventPropertyColumnName(con, lUID, lEvtPropId);
			}
			
			jaEventTransactions = cidbi.getEventTransactionsSelectedColumns(con, lUID, lEventId, lEvtPropId, strPropertyColumnName, strPropertyValue, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getEventTransactionDetails: "+e.getMessage());
			throw e;
		}
		
		return jaEventTransactions;
	}
	
	public JSONArray getEventTransactionsWithDateRange(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyValue, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;

		String strPropertyColumnName = "";
		
		JSONArray jaEventTransactions = null;

		try {
			cidbi = new CIDBI();
			
			// for `ALL` values to show, avoided to get respective property's column name
			if( lEvtPropId != -1 ) {
				strPropertyColumnName = cidbi.getEventPropertyColumnName(con, lUID, lEvtPropId);
			}
			
			jaEventTransactions = cidbi.getEventTransactionsSelectedColumnsWithDateRange(con, lUID, lEventId, lEvtPropId, strPropertyColumnName, strPropertyValue, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getEventTransactionDetails: "+e.getMessage());
			throw e;
		}
		
		return jaEventTransactions;
	}

	public JSONObject getEventTransaction(Connection con, long lUID, long lEventId, long lEvtTransId, long lUserId, String strRUMLicLevel) throws Exception {
		CIDBI cidbi = null;
		
		LinkedHashMap<String, String> lhmEventColumnWisePropertyName = null; 

		CILicenseBean ciLicenseBean = null;
		
		JSONObject joEventTransaction = null;

		try {
			cidbi = new CIDBI();

			ciLicenseBean = getCIUserLicenseDetails(con, lUserId, strRUMLicLevel);
			if ( ciLicenseBean == null ) {
				throw new Exception("1");
			}
			
			// gets event's dynamic column name mapped with respective property
			lhmEventColumnWisePropertyName = cidbi.getEventColumnNameMappedWithProperty(con, lUID, lEventId, ciLicenseBean.getMaxProperties());
			
			joEventTransaction = cidbi.getEventTransaction(con, lUID, lEventId, lEvtTransId, lhmEventColumnWisePropertyName);
			
			UtilsFactory.clearCollectionHieracy(lhmEventColumnWisePropertyName);
			
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getEventTransactionDetails: "+e.getMessage());
			throw e;
		}
		
		return joEventTransaction;
	}
	
	/**
	 * gets respective event's transactions of all available columns 
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param lEvtPropId
	 * @param strPropertyValue
	 * @return
	 * @throws Exception
	 */
	public JSONObject getEventDetailedTransactions(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyValue, String strFromStartInterval, long lUserId, String strRUMLicLevel, String strLimit, String strOffset) throws Exception {
		CIDBI cidbi = null;

		String strPropertyColumnName = "";

		LinkedHashMap<String, String> lhmEventColumnWisePropertyName = null; 
		
		CILicenseBean ciLicenseBean = null;
		
		JSONObject joRtnEventTransactions = null;

		try {
			cidbi = new CIDBI();

			ciLicenseBean = getCIUserLicenseDetails(con, lUserId, strRUMLicLevel);
			if ( ciLicenseBean == null ) {
				throw new Exception("1");
			}
			
			// for `ALL` values to show, avoided to get respective property's column name
			if( lEvtPropId != -1 ) {
				strPropertyColumnName = cidbi.getEventPropertyColumnName(con, lUID, lEvtPropId);
			}
			
			// gets event's dynamic column name mapped with respective property
			lhmEventColumnWisePropertyName = cidbi.getEventColumnNameMappedWithProperty(con, lUID, lEventId, ciLicenseBean.getMaxProperties());
			
			joRtnEventTransactions = cidbi.getEventDetailedTransactions(con, lUID, lEventId, lEvtPropId, strPropertyColumnName, strPropertyValue, lhmEventColumnWisePropertyName, strFromStartInterval, strLimit, strOffset);

			
			UtilsFactory.clearCollectionHieracy(lhmEventColumnWisePropertyName);
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getEventTransactionDetails: "+e.getMessage());
			throw e;
		}
		
		return joRtnEventTransactions;
	}
	
	public JSONObject getEventDetailedTransactionsWithDateRange(Connection con, long lUID, long lEventId, long lEvtPropId, String strPropertyValue, String strFromStartInterval, String strToInterval, long lUserId, String strRUMLicLevel, String strLimit, String strOffset) throws Exception {
		CIDBI cidbi = null;

		String strPropertyColumnName = "";

		LinkedHashMap<String, String> lhmEventColumnWisePropertyName = null; 
		
		CILicenseBean ciLicenseBean = null;
		
		JSONObject joRtnEventTransactions = null;

		try {
			cidbi = new CIDBI();

			ciLicenseBean = getCIUserLicenseDetails(con, lUserId, strRUMLicLevel);
			if ( ciLicenseBean == null ) {
				throw new Exception("1");
			}
			
			// for `ALL` values to show, avoided to get respective property's column name
			if( lEvtPropId != -1 ) {
				strPropertyColumnName = cidbi.getEventPropertyColumnName(con, lUID, lEvtPropId);
			}
			
			// gets event's dynamic column name mapped with respective property
			lhmEventColumnWisePropertyName = cidbi.getEventColumnNameMappedWithProperty(con, lUID, lEventId, ciLicenseBean.getMaxProperties());
			
			joRtnEventTransactions = cidbi.getEventDetailedTransactionsWithDateRange(con, lUID, lEventId, lEvtPropId, strPropertyColumnName, strPropertyValue, lhmEventColumnWisePropertyName, strFromStartInterval, strToInterval, strLimit, strOffset);

			
			UtilsFactory.clearCollectionHieracy(lhmEventColumnWisePropertyName);
			cidbi = null;
		} catch (Exception e) {
			System.out.println("Exception in getEventTransactionDetails: "+e.getMessage());
			throw e;
		}
		
		return joRtnEventTransactions;
	}

	/**
	 * gets ci license config params for a particular level 
	 * since RUM/CI used rum license level 
	 * 
	 * @param con
	 * @param strRUMLicLevel
	 * @return
	 * @throws Exception
	 */
	/*public CILicenseBean getCILicenseConfigParameters(Connection con, String strRUMLicLevel) throws Exception {
		CIDBI cidbi = null;
		
		CILicenseBean ciLicenseBean = null;
		
		try {
			cidbi = new CIDBI();
			
			ciLicenseBean = cidbi.getCILicenseConfigParameters(con, strRUMLicLevel);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return ciLicenseBean;
	}*/
	
	/**
	 * gets CI user license details
	 * 
	 * @param con
	 * @param lUserId
	 * @param strRUMLicLevel
	 * @return
	 * @throws Exception
	 */
	public CILicenseBean getCIUserLicenseDetails(Connection con, long lUserId, String strRUMLicLevel) throws Exception {
		CIDBI cidbi = null;

		CILicenseBean ciLicenseBean = null;
		
		try {
			cidbi = new CIDBI();
			
			// gets license details from month wise table
			ciLicenseBean = cidbi.getCIUserWiseLicenseMonthWise(con, lUserId, strRUMLicLevel);
			
			if(ciLicenseBean != null) {
				// get license details from `rum config parameters`
				CILicenseBean ciLicenseBeanConfigParams = cidbi.getCILicenseConfigParameters(con, strRUMLicLevel);

				ciLicenseBean.setLicInternalName(ciLicenseBeanConfigParams.getLicInternalName());
				ciLicenseBean.setLicExternalName(ciLicenseBeanConfigParams.getLicExternalName());
				
				ciLicenseBean.setReportRetentionInDays(ciLicenseBeanConfigParams.getReportRetentionInDays());
				
				ciLicenseBean.setEnableProfiles(ciLicenseBeanConfigParams.isEnableProfiles());
				ciLicenseBean.setEnableFilters(ciLicenseBeanConfigParams.isEnableFilters());
				ciLicenseBean.setEnableNotificationEmail(ciLicenseBeanConfigParams.isEnableNotificationEmail());
				ciLicenseBean.setEnableNotificationSMS(ciLicenseBeanConfigParams.isEnableNotificationSMS());
			}
			
			/*
			// get license details from `rum config parameters`
			CILicenseBean ciLicenseBeanConfigParams = cidbi.getCILicenseConfigParameters(con, strRUMLicLevel);
			
			// if license is expired for user, to show max event and max properties from config params
			if(ciLicenseBean == null) {
				ciLicenseBean = new CILicenseBean();
				ciLicenseBean.setMaxEvents(ciLicenseBeanConfigParams.getMaxEvents());
				ciLicenseBean.setMaxProperties(ciLicenseBeanConfigParams.getMaxProperties());
			}
			
			ciLicenseBean.setLicInternalName(ciLicenseBeanConfigParams.getLicInternalName());
			ciLicenseBean.setLicExternalName(ciLicenseBeanConfigParams.getLicExternalName());
			
			ciLicenseBean.setReportRetentionInDays(ciLicenseBeanConfigParams.getReportRetentionInDays());
			
			ciLicenseBean.setEnableProfiles(ciLicenseBeanConfigParams.isEnableProfiles());
			ciLicenseBean.setEnableFilters(ciLicenseBeanConfigParams.isEnableFilters());
			ciLicenseBean.setEnableNotificationEmail(ciLicenseBeanConfigParams.isEnableNotificationEmail());
			ciLicenseBean.setEnableNotificationSMS(ciLicenseBeanConfigParams.isEnableNotificationSMS());*/
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return ciLicenseBean;
	}
	
	/**
	 * gets browser wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getBrowserWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaBrowserShareData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaBrowserShareData = cidbi.getBrowserWiseDonutData(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaBrowserShareData;
	}
	
	public JSONArray getBrowserWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaBrowserShareData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaBrowserShareData = cidbi.getBrowserWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaBrowserShareData;
	}
	
	/**
	 * gets DeviceType wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getDeviceTypeWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceTypeWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceTypeWiseData = cidbi.getDeviceTypeWiseDonutData(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceTypeWiseData;
	}
	
	public JSONArray getDeviceTypeWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceTypeWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceTypeWiseData = cidbi.getDeviceTypeWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceTypeWiseData;
	}
	
	/**
	 * gets OSWise wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getOSWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaOSWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaOSWiseData = cidbi.getOSWiseDonutData(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaOSWiseData;
	}
	
	public JSONArray getOSWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaOSWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaOSWiseData = cidbi.getOSWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaOSWiseData;
	}
	
	/**
	 * gets DeviceName wise donut data, with top3 and all in others
	 * 
	 * @param con
	 * @param lUID
	 * @param lEventId
	 * @param strFromStartInterval
	 * @return
	 * @throws Exception
	 */
	public JSONArray getDeviceNameWiseDonutData(Connection con, long lUID, long lEventId, String strFromStartInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceNameWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceNameWiseData = cidbi.getDeviceNameWiseDonutData(con, lUID, lEventId, strFromStartInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceNameWiseData;
	}
	
	public JSONArray getDeviceNameWiseDonutDataWithDateRange(Connection con, long lUID, long lEventId, String strFromStartInterval, String strToInterval) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaDeviceNameWiseData = null;
		
		try {
			cidbi = new CIDBI();
			
			jaDeviceNameWiseData = cidbi.getDeviceNameWiseDonutDataWithDateRange(con, lUID, lEventId, strFromStartInterval, strToInterval);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaDeviceNameWiseData;
	}
	
	public JSONArray getModuleAgentTypes(Connection con, long lUID) throws Exception {
		CIDBI cidbi = null;

		JSONArray jaAgentTypes = null;
		
		try {
			cidbi = new CIDBI();
			
			jaAgentTypes = cidbi.getModuleAgentTypes(con, lUID);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaAgentTypes;
	}
	
	
	public JSONArray getModuleEnvironments(Connection con, long lUID) throws Exception {
		CIDBI cidbi = null;

		JSONArray jaEnvironments = null;
		
		try {
			cidbi = new CIDBI();

			jaEnvironments = cidbi.getModuleEnvironments(con, lUID); 
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaEnvironments;
	}
	
	public long getEventLastReceivedOn(Connection con, long lUID, long lEventId) throws Exception {
		CIDBI cidbi = null;

		long lLastReceivedOn = 0L;
		
		try {
			cidbi = new CIDBI();

			lLastReceivedOn = cidbi.getEventLastReceivedOn(con, lUID, lEventId); 
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lLastReceivedOn;
	}
	
	public JSONObject getUserEventsVisitorsCount(Connection con, long lUserId, String strAgentType, String strEnvironment) throws Exception {
		CIDBI cidbi = null;
		
		JSONObject joUserEventsVisitorsCount = null;
		
		try {
			cidbi = new CIDBI();
			
			joUserEventsVisitorsCount = cidbi.getUserEventsVisitorsCount(con, lUserId, strAgentType, strEnvironment);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joUserEventsVisitorsCount;
	}
	
	public JSONArray getUserEventsDistinctEnvironments(Connection con, long lUserId) throws Exception {
		CIDBI cidbi = null;
		
		JSONArray jaEventsDistinctEnvironments = null;
		
		try {
			cidbi = new CIDBI();
			
			jaEventsDistinctEnvironments = cidbi.getUserEventsDistinctEnvironments(con, lUserId);
			
			cidbi = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaEventsDistinctEnvironments;
	}
}
