package com.appedo.module.model;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.ServiceMapBean;
import com.appedo.module.common.Constants;
import com.appedo.module.dbi.ModuleDBI;
import com.appedo.module.dbi.ServiceDBI;

public class ServiceManager {

	
	public long addServiceMap(Connection con, ServiceMapBean serviceMapBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		ServiceDBI serviceDBI = null;

		long lServiceMapId = -1L;

		boolean bServiceNameExists = false;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// checks servicename isExists, , "-1" hardcoding since its a new insert
			bServiceNameExists = isServiceNameExists(con, serviceMapBean.getName(), -1, loginUserBean.getUserId());
			
			if ( bServiceNameExists ) {
				// service name already exists
				throw new Exception("1");
			} else {
				// inserts
				lServiceMapId = serviceDBI.insertServiceMap(con, serviceMapBean, loginUserBean.getUserId(), loginUserBean.getUserId(), joEnt);
				serviceMapBean.setServiceMapId(lServiceMapId);
				
				// map modules to the ServiceMap 
				insertServiceMapDetails(con, serviceMapBean, loginUserBean);
			}
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return lServiceMapId;
	}
	
	public void v1_addToServiceMap(Connection con, String moduleCode, Long lUid, LoginUserBean loginUserBean) throws Exception {
		try {
			
			mapModuleToSystemServiceMap(con, JSONObject.fromObject("{\"module_master\":{\"module_code\":\""+moduleCode+"\",\"uid\":"+lUid+"}}"), loginUserBean);
			
		} catch (Exception e) {
			throw e;
		}
		
	}
	
	public JSONArray getModuleTypesDetails(Connection con, long lServiceMapId, /*LoginUserBean loginUserBean*/ long lUser_id, JSONObject joEnt) throws Exception {
		ServiceDBI serviceDBI = null;
		ModuleDBI moduleDBI = null;
		
		
		String strModule = "";
		// since to have the resp in respective order, the order is specified 
		String[] saASDRModules = {"APPLICATION", "SERVER", "DATABASE", "RUM" , "LOG"};
		
		// ASDR refers Application/Server/Database/RUM
		LinkedHashMap<String, ArrayList<JSONObject>> lhmRtnASDRModulesDetails = null;
		
		JSONArray jaRtnSUMTests = null, jaAPMModulesDetails = new JSONArray();
		JSONObject joModuleDetails = null;
		// Application/Server/Database/SUM
		//JSONObject joModuleTypesDetails = null;
		
		try {
			serviceDBI = new ServiceDBI();
			moduleDBI = new ModuleDBI();
			
			//joModuleTypesDetails = new JSONObject();
			
			// gets Application/Server/Database/RUM
			lhmRtnASDRModulesDetails = moduleDBI.getUserAllModules(con, lServiceMapId, /*loginUserBean.getUserId()*/ lUser_id, joEnt);
			
			// gets SUM tests
			jaRtnSUMTests = serviceDBI.getSUMTests(con, lServiceMapId, /*loginUserBean.getUserId()*/lUser_id, joEnt);
			
			//joModuleTypesDetails.putAll(lhmRtnModulesDetails);
			//joModuleTypesDetails.put("SUM", jaRtnSUMTests);
			
			
			// adds the module into JSONArray, as necessary format
			for(int i = 0; i < saASDRModules.length; i = i + 1) {
				strModule = saASDRModules[i];
				
				if ( lhmRtnASDRModulesDetails.containsKey(strModule) ) {
					joModuleDetails = new JSONObject();
					joModuleDetails.put("serviceType", strModule);
					// respective modules ArrayList pair.getValue()
					joModuleDetails.put("modules", lhmRtnASDRModulesDetails.get(strModule));
					
					jaAPMModulesDetails.add(joModuleDetails);
				}
			}
			// adding SUM to JSONArray
			if( jaRtnSUMTests != null && jaRtnSUMTests.size() > 0 ) {
				joModuleDetails = new JSONObject();
				joModuleDetails.put("serviceType", "SUM");
				joModuleDetails.put("modules", jaRtnSUMTests);
				jaAPMModulesDetails.add(joModuleDetails);	
			}
			
			//TODO: AVM add in service Map
			
			serviceDBI = null;
			moduleDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaAPMModulesDetails;
	}
	
	public boolean isServiceNameExists(Connection con, String strServiceName, long lServiceMapId, long lUserId) throws Exception {
		ServiceDBI serviceDBI = null;
		
		boolean bServiceNameExists = false;
		
		try {
			serviceDBI = new ServiceDBI();

			bServiceNameExists = serviceDBI.isServiceNameExists(con, strServiceName, lServiceMapId, lUserId);
			
			serviceDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return bServiceNameExists;
	}
	
	public JSONArray getUserServiceMapsWithMapCountDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray jaUserServiceMaps = null;
		
		try {
			serviceDBI = new ServiceDBI();

			jaUserServiceMaps = serviceDBI.getUserServiceMapsWithMapCountDetails(con, loginUserBean);
			
			serviceDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaUserServiceMaps;
	}

	public JSONArray getUserServiceMapsWithMapCountDetails_v1(Connection con, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray jaUserServiceMaps = null;
		
		try {
			serviceDBI = new ServiceDBI();

			jaUserServiceMaps = serviceDBI.getUserServiceMapsWithMapCountDetails_v1(con, loginUserBean, joEnt);
			
			serviceDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaUserServiceMaps;
	}
	
	public void updateServiceMap(Connection con, ServiceMapBean serviceMapBean, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;

		boolean bServiceNameExists = false;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// 
			bServiceNameExists = isServiceNameExists(con, serviceMapBean.getName(), serviceMapBean.getServiceMapId(), loginUserBean.getUserId());
			
			if ( bServiceNameExists ) {
				// service name already exists
				throw new Exception("1");
			} else {
				// update
				serviceDBI.updateServiceMap(con, serviceMapBean, loginUserBean.getUserId());
				
				// TODO: deleted ids, newly adds ids to pass, instead of delete all rows and insert all is much costly operation
				
				// delete 
				serviceDBI.deleteServiceMapDetails(con, serviceMapBean.getServiceMapId(), loginUserBean.getUserId());
				
				// map modules to the ServiceMap 
				insertServiceMapDetails(con, serviceMapBean, loginUserBean);
			}
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void updateServiceMap_v1(Connection con, ServiceMapBean serviceMapBean, LoginUserBean loginUserBean, long lUser_id, Boolean updateServiceMapDetails) throws Exception {
		ServiceDBI serviceDBI = null;

		boolean bServiceNameExists = false;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// 
			bServiceNameExists = isServiceNameExists(con, serviceMapBean.getName(), serviceMapBean.getServiceMapId(), /*loginUserBean.getUserId()*/ lUser_id);
			
			if ( bServiceNameExists ) {
				// service name already exists
				throw new Exception("1");
			} else {
				// update
				serviceDBI.updateServiceMap(con, serviceMapBean, /*loginUserBean*/ lUser_id);
				
				// TODO: deleted ids, newly adds ids to pass, instead of delete all rows and insert all is much costly operation
				
				if(updateServiceMapDetails) {
				// delete 
				serviceDBI.deleteServiceMapDetails(con, serviceMapBean.getServiceMapId(), /*loginUserBean.getUserId()*/ lUser_id);
				
				// map modules to the ServiceMap 
				insertServiceMapDetails(con, serviceMapBean, loginUserBean);
				}
			}
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}

	
	/**
	 * maps modules to the ServiceMap
	 * 
	 * @param con
	 * @param serviceMapBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void insertServiceMapDetails(Connection con, ServiceMapBean serviceMapBean, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONObject joMappedModule = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// inserts mapped jo
			for(int i = 0; i < serviceMapBean.getServiceMaps().size(); i = i + 1) {
				joMappedModule = serviceMapBean.getServiceMaps().get(i);
				
				serviceDBI.insertServiceMapDetails(con, serviceMapBean.getServiceMapId(), joMappedModule);
			}
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}

	public void deleteServiceMap(Connection con, long lServiceMapId, long lUserId) throws Exception {
		ServiceDBI serviceDBI = null;

		try {
			serviceDBI = new ServiceDBI();

			// deletes mapped service
			serviceDBI.deleteServiceMapDetails(con, lServiceMapId, lUserId);
			
			// delete 
			serviceDBI.deleteServiceMap(con, lServiceMapId, lUserId);
			
			serviceDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}

	/**
	 * gets service map JSON counters data which has show in Service Map Dashboard
	 * 
	 * @param con
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapData(Connection con, long userId) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray joArr = null;

		try {
			serviceDBI = new ServiceDBI();
			
			joArr = serviceDBI.getServiceMapData(con,userId);
			
			serviceDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joArr;
	}
	
	public JSONArray getUserServiceMaps(Connection con, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray jaUserServiceMaps = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			jaUserServiceMaps = serviceDBI.getUserServiceMaps(con, loginUserBean);
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaUserServiceMaps;
	}
	
	public JSONObject getServiceMapMappedModules(Connection con, long lServiceMapId, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONObject joRtnServiceMapMappedModules = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			joRtnServiceMapMappedModules = serviceDBI.getServiceMapMappedModules(con, lServiceMapId, loginUserBean);
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnServiceMapMappedModules;
	}
	
	/**
	 * gets service map's mapped module's,
	 *   say APPLICATION's OR SERVER's OR ..., module's mapped `uid/test_id`s summaries
	 *   
	 * @param con
	 * @param lServiceMapId
	 * @param strModuleCode
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapMappedModuleSummaries(Connection con, long lServiceMapId, String strModuleCode, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray jaMappedModuleSummaries = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			jaMappedModuleSummaries = serviceDBI.getServiceMapMappedModuleSummaries(con, lServiceMapId, strModuleCode, loginUserBean.getUserId());
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaMappedModuleSummaries;
	}
	
	/**
	 * gets Service Maps overall health
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getServiceMapsHealth(Connection con, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray jaServiceMapsHealth = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// gets Service Maps health
			jaServiceMapsHealth = serviceDBI.getServiceMapsHealth(con, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaServiceMapsHealth;
	}
	public JSONArray getServiceMaps_v1(Connection con, long lEID, long lUserId) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray jaServiceMapsHealth = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// gets Service Maps health
			jaServiceMapsHealth = serviceDBI.getServiceMaps_v1(con, lEID, lUserId);
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaServiceMapsHealth;
	}
	/**
	 * gets Service Map's mapped modules, module code wise health
	 * 
	 * @param con
	 * @param lServiceMapId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModuleCodeWiseHealth(Connection con, long lServiceMapId, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONObject joModuleCodesHealth = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// gets Service Map's mapped modules, module code wise health
			joModuleCodesHealth = serviceDBI.getModuleCodeWiseHealth(con, lServiceMapId, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joModuleCodesHealth;
	}
	
	/**
	 * gets Service Map's mapped modules, each module's selected counters statuses,
	 * with filter based on,
	 *   either given moduleCode (`APPLICATION`/`SERVER`/`DATABASE`) OR
	 *          given healCode (`WARNING`/`CRITICAL`) OR
	 *   with both moduleCode & healCode given, 
	 *   moduleCode & healCode given as `''` to get all mapped modules counters status
	 * 
	 * @param con
	 * @param lServiceMapId
	 * @param strModuleCode
	 * @param strHealthCode
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModulesCountersWiseHealth(Connection con, long lServiceMapId, String strModuleCode, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONArray jaModulesCountersStatuses = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// gets Service Map's mapped modules, each module's selected counters statuses
			jaModulesCountersStatuses = serviceDBI.getModulesCountersWiseHealth(con, lServiceMapId, strModuleCode, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jaModulesCountersStatuses;
	}
	
	/**
	 * adds user's system generated Service Map, 
	 *   maps user's, on add of ASD, RUM, SUM `uid/test_id`'s maps, to the this created Service Map
	 *  
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public long addUserSystemServiceMap(Connection con, long lUserId) throws Exception {
		ServiceDBI serviceDBI = null;
		
		ServiceMapBean serviceMapBean = null;
		
		long lServiceMapId = -1L;
		
		JSONObject empty = null;
		
		try {
			serviceDBI = new ServiceDBI();
			// sets value
			serviceMapBean = new ServiceMapBean();
			serviceMapBean.setName("-- All --");
			serviceMapBean.setDescription("Auto-generated; to view all Services");
			serviceMapBean.setSystemGenerated(true);
			
			// add user's default system generate ServiceMap; on add of ASD, RUM & SUM, the added `uid/test_id` is mapped to this Service Map
			// `1` is used as created_by, since this entry is a auto-generated.
			lServiceMapId = serviceDBI.insertServiceMap(con, serviceMapBean, lUserId, 1, empty);
			
			serviceDBI = null;
			serviceMapBean = null;
		} catch (Exception e) {
			throw e;
		}
		return lServiceMapId;
	}
	
	/**
	 * add User Set as Default Module To View the Dash board and Card Layout.
	 */
	public void addUserSetAsDefault(Connection con, long lUserId, long lServiceMapId) throws Exception{
		ServiceDBI serviceDBI = null;
		try{
			serviceDBI = new ServiceDBI();
			serviceDBI.insertSetAsDefault(con, lUserId, lServiceMapId);
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * maps user's ASD, SUM, RUM `uid/test_id`, to the system generated Service Map
	 * 
	 * @param con
	 * @param joModule
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void mapModuleToSystemServiceMap(Connection con, JSONObject joModule, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		ServiceMapBean serviceMapBean = null;
		
		long lServiceMapId = -1L;
		
		try {
			serviceDBI = new ServiceDBI();
			// sets value
			serviceMapBean = new ServiceMapBean();
			
			// gets user's System generated Service Map
			lServiceMapId = serviceDBI.getUserSystemServiceMapId(con, loginUserBean.getUserId());
			
			serviceMapBean.setServiceMapId(lServiceMapId);
			// adds module
			serviceMapBean.addServiceMap(joModule);
			
			// map the module to System generated ServiceMap
			insertServiceMapDetails(con, serviceMapBean, loginUserBean);
			
			serviceDBI = null;
			serviceMapBean = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets all module's breached of either `WARNING/CRITICAL` counters OR 
	 *   module's all selected counters or module's breached counters based given healthCode (`WARNING/CRITICAL`) OR
	 *   moduleCode's, say `APPLICATION`'s, breached of either `WARNING/CRITICAL` counters 
	 *   
	 * @param con
	 * @param lUId
	 * @param strHealthCode
	 * @param strInterval
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	/*public JSONObject getModuleCounters(Connection con, long lServiceMapId, long lReferenceId, String strModuleCode, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills, LoginUserBean loginUserBean) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONObject joRtnMappedModulesDetails = new JSONObject();
		JSONArray jaCounters = null, jaTests = null, jaRUMModules = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// TODO: filter service map id's mapped uid(s) filter of WARNING & CRITICAL,
			
			// lReferenceId is `uid` for moduleCode IN (A, S, D), `test_id` for moduleCode `SUM`
			if ( ! strModuleCode.equals("SUM") && ! strModuleCode.equals("RUM") ) {
				jaCounters = serviceDBI.getModuleCounters(con, lServiceMapId, lReferenceId, strModuleCode, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
				joRtnMappedModulesDetails.put("ASD", jaCounters);
			}
			
			// gets service Map's mapped SUM tests details, TODO: get SUM test for WARNING & CRITICAL 
			if ( strModuleCode.length() == 0 || strModuleCode.equals("SUM") ) {
				jaTests = serviceDBI.getServiceMapSUMTests(con, lServiceMapId, lReferenceId, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
				joRtnMappedModulesDetails.put("SUM", jaTests);
			}
			
			if ( strModuleCode.length() == 0 || strModuleCode.equals("RUM") ) {
				jaRUMModules = serviceDBI.getServiceMapRUMSites(con, lServiceMapId, lReferenceId, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
				joRtnMappedModulesDetails.put("RUM", jaRUMModules);
			}
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnMappedModulesDetails;
	}*/
	
	public JSONObject getModuleCounters_v1(Connection con, long lEID, long lUserId, long lServiceMapId, long lReferenceId, String strModuleCode, String strHealthCode, String strInterval, Long lStartDateTimeInMills, Long lEndDateTimeInMills) throws Exception {
		ServiceDBI serviceDBI = null;
		
		JSONObject joRtnMappedModulesDetails = new JSONObject();
		JSONArray jaCounters = null, jaTests = null, jaRUMModules = null, jaLogCounters = null;
		
		try {
			serviceDBI = new ServiceDBI();
			
			// TODO: filter service map id's mapped uid(s) filter of WARNING & CRITICAL,
			
			// lReferenceId is `uid` for moduleCode IN (A, S, D), `test_id` for moduleCode `SUM`
			//if ( ! strModuleCode.equals("SUM") && ! strModuleCode.equals("RUM") && ! strModuleCode.equals("LOG") ) {
			
			
			if (strHealthCode != null && (strHealthCode.equals(Constants.CWV) || (strHealthCode.equals(Constants.CWOV)))){
				jaCounters = serviceDBI.getActiveCounters_v1(con, lServiceMapId, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, lUserId);
				jaTests = serviceDBI.getServiceMapAllSUMTest(con, lUserId, lServiceMapId, strInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				jaRUMModules = serviceDBI.getServiceMapAllRUMSites(con, lServiceMapId, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, lUserId);
				jaLogCounters = serviceDBI.getLogCounters(con, lServiceMapId, lUserId, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode);
			} else {
				jaCounters = serviceDBI.getModuleCounters(con, lEID, lUserId, lServiceMapId, lReferenceId, strModuleCode, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				jaTests = serviceDBI.getServiceMapSUMTests(con, lEID, lUserId, lServiceMapId, lReferenceId, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				jaRUMModules = serviceDBI.getServiceMapRUMSites(con, lEID, lUserId, lServiceMapId, lReferenceId, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills);
				jaLogCounters = new JSONArray();
			}
			
			joRtnMappedModulesDetails.put("ASD", jaCounters);
			joRtnMappedModulesDetails.put("SUM", jaTests);
			joRtnMappedModulesDetails.put("RUM", jaRUMModules);
			joRtnMappedModulesDetails.put("LOG", jaLogCounters);
		
			//	}
			
			// gets service Map's mapped SUM tests details, TODO: get SUM test for WARNING & CRITICAL 
		//	if ( strModuleCode.length() == 0 || strModuleCode.equals("SUM") ) {
			//	if (strHealthCode.equals(Constants.CWV)) {
					//jaTests = serviceDBI.getServiceMapAllSUMTest(con, loginUserBean.getUserId(), lServiceMapId, strInterval, lStartDateTimeInMills, lEndDateTimeInMills);
			//	} else if (strHealthCode.equals(Constants.CRITICAL) || strHealthCode.equals(Constants.CRITWARN)) {
				//	jaTests = serviceDBI.getServiceMapSUMTests(con, lServiceMapId, lReferenceId, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
			//	}
				//joRtnMappedModulesDetails.put("SUM", jaTests);
		//	}
			
		//	if ( strModuleCode.length() == 0 || strModuleCode.equals("RUM") ) {
			//	if (strHealthCode.equals(Constants.CWV)) { 
					//jaRUMModules = serviceDBI.getServiceMapAllRUMSites(con, lServiceMapId, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
			//	} else if (strHealthCode.equals(Constants.CRITICAL) || strHealthCode.equals(Constants.CRITWARN)) {
				//	jaRUMModules = serviceDBI.getServiceMapRUMSites(con, lServiceMapId, lReferenceId, strHealthCode, strInterval, lStartDateTimeInMills, lEndDateTimeInMills, loginUserBean.getUserId());
			//	} 
				//joRtnMappedModulesDetails.put("RUM", jaRUMModules);
		//	}
			
		//	if (strModuleCode.length() == 0 || strModuleCode.equals("LOG")) {
			//	jaLogCounters = serviceDBI.getLogCounters(con, lServiceMapId, loginUserBean.getUserId(), strInterval, lStartDateTimeInMills, lEndDateTimeInMills, strHealthCode);
			//	joRtnMappedModulesDetails.put("LOG", jaLogCounters);
		//	}
			
			serviceDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joRtnMappedModulesDetails;
	}
}
