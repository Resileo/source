package com.appedo.module.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.LTLicenseBean;
import com.appedo.module.bean.LoadTestSchedulerBean;
import com.appedo.module.bean.SummaryReportNotesBean;
import com.appedo.module.common.Constants;
import com.appedo.module.dbi.LTDBI;
import com.appedo.module.utils.UtilsFactory;

public class LTManager {

	/**
	 * to get sum test details
	 * 
	 * @param con
	 * @param loginUserBean
	 * @param strTestType 
	 * @return
	 * @throws Exception
	 */
	public JSONArray getVUScripts(Connection con, LoginUserBean loginUserBean, String strTestType) throws Exception {
		LTDBI ltdbi = null;
		HashMap<Integer, String> hmScenarioNames = null;
		JSONArray jaScripts = null;

		try {
			ltdbi = new LTDBI();

			jaScripts = ltdbi.getVUScripts(con, loginUserBean, strTestType);
			for ( int i = 0; i < jaScripts.size(); i++ ){
				JSONObject joScript = jaScripts.getJSONObject(i);
				hmScenarioNames = ltdbi.getScenarioNames(con, joScript.getLong("script_id"), loginUserBean.getUserId());
				if( hmScenarioNames.size() > 0 ){
					for( Map.Entry<Integer, String> e:hmScenarioNames.entrySet() ){
						joScript.put("mapped_scenarios", e.getKey());
						joScript.put("scenarioName", e.getValue());
					}
				} else {
					joScript.put("mapped_scenarios", 0);
					joScript.put("scenarioName", "");
				}
				hmScenarioNames = null;
			}
			ltdbi = null;
		}catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltdbi = null;
		}

		return jaScripts;
	}
	
	public JSONArray getLTScripts(Connection con, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltdbi = null;
		HashMap<Integer, String> hmScenarioNames = null;
		JSONArray jaScripts = null;
		JSONArray jaResult = new JSONArray();

		JSONObject joVariable = null;
		JSONObject joCol_Value = null;
		
		String strDeleteIdx = null, strEditIdx = null, strConfigIdx = null, strTitle = "";
		
		try {
			ltdbi = new LTDBI();

			joVariable = new JSONObject();
			joCol_Value = new JSONObject();
			
			jaScripts = ltdbi.getLTScripts(con, loginUserBean);
			for ( int i = 0; i < jaScripts.size(); i++ ){
				// Reset loop variables
				strDeleteIdx = null;
				strEditIdx = null;
				strConfigIdx = null;
				strTitle = null;
				
				JSONObject joScript = jaScripts.getJSONObject(i);
				hmScenarioNames = ltdbi.getScenarioNames(con, joScript.getLong("script_id"), loginUserBean.getUserId());
				if( hmScenarioNames.size() > 0 ){
					for( Map.Entry<Integer, String> e:hmScenarioNames.entrySet() ){
						joScript.put("mapped_scenarios", e.getKey());
						joScript.put("scenarioName", e.getValue());
					}
				} else {
					joScript.put("mapped_scenarios", 0);
					joScript.put("scenarioName", "");
				}
				hmScenarioNames = null;
				
				// new UI Design
				if( joScript.getString("script_type").equals("APPEDO_LT") ) {
					strDeleteIdx = "is_delete";
					strTitle = "AppedoLT Script";
				} else if( joScript.getString("script_type").equals("JMETER") ) {
					strDeleteIdx = "";
					strTitle = "JMeter Script";
				}
				
				joVariable.put("var1", strDeleteIdx);
				joVariable.put("var2", "");
				joVariable.put("var3", "");
				joVariable.put("var4", strTitle);
				joCol_Value.put("col_1", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", joScript.getString("scriptName"));
				joVariable.put("var2", "Added by "+loginUserBean.getFirstName()+" on ");
				joVariable.put("var21", joScript.getString("created_on"));
				joCol_Value.put("col_2", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);

				joVariable.put("var1", "Mapped Scenario Name");
				joVariable.put("var2", joScript.getString("scenarioName"));
				joCol_Value.put("col_3", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Scenarios");
				joVariable.put("var2", joScript.getString("mapped_scenarios"));
				joCol_Value.put("col_4", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "");
				joVariable.put("var2", "");
				joCol_Value.put("col_5", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "STATUS_Live");
				joVariable.put("var2", "");
				joCol_Value.put("col_6", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joCol_Value.put("script_type", joScript.getString("script_type"));
				joCol_Value.put("script_id", joScript.getString("script_id"));
				
				jaResult.add(joCol_Value);

			}
			
			ltdbi = null;
		}catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltdbi = null;
		}

		//return jaScripts;
		return jaResult;
	}

	public String getLTScriptStatus(Connection con, long lScriptId) throws Exception {
		LTDBI ltdbi = null;
		String strLTScripStatus = null;
		try {
			ltdbi = new LTDBI();
			strLTScripStatus = ltdbi.getScriptStatus(con, lScriptId);
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally {
			ltdbi = null;
		}
		return strLTScripStatus;
	}
	
	public JSONArray getVUScenarios(Connection con, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltdbi = null;
		
		JSONObject hmScenarioStatus = null;
		JSONArray jaScenarios = null;
		
		HashMap<String, Long> hmScenarioRuns = null;
		
		try {
			ltdbi = new LTDBI();

			jaScenarios = ltdbi.getVUScenarios(con, loginUserBean);
			for (int i = 0; i<jaScenarios.size(); i++ ){
				JSONObject joScenario = jaScenarios.getJSONObject(i);
				JSONObject jo = ltdbi.getMappedScriptNames(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId());
				if(jo != null){
					joScenario.put("mappedo_scripts", jo.get("mappedScenarios"));
					joScenario.put("script_names", jo.get("script_name"));
					joScenario.put("runType", jo.get("runType"));
					joScenario.put("maxusers", jo.get("maxusers"));
				}
				// joScenario.put("mappedo_scripts", ltdbi.getMappedScripts(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId()));
				
				// gets runs for the scenario
				hmScenarioRuns = ltdbi.getScenarioRuns(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId());
				joScenario.put("total_runs", hmScenarioRuns.get("total_runs"));
				joScenario.put("completed_runs", hmScenarioRuns.get("total_runs_completed"));
				
				hmScenarioStatus = ltdbi.getScenarioRunStatus(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId());
				if( hmScenarioStatus != null ){
					joScenario.put("run_id", hmScenarioStatus.getLong("runid"));
					joScenario.put("run_status", hmScenarioStatus.getBoolean("is_active"));
					joScenario.put("status", hmScenarioStatus.getString("status"));
					joScenario.put("grafanaReportURL", hmScenarioStatus.getString("grafana_report_url"));
				} else {
					joScenario.put("run_id", 0);
					joScenario.put("run_status", false);
					joScenario.put("status", "COMPLETED");
					joScenario.put("grafanaReportURL", "");
				}
				hmScenarioStatus = null;
			}
			ltdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltdbi = null;
		}

		return jaScenarios;
	}
	
	public JSONArray getLTScenarios(Connection con, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltdbi = null;
		
		JSONObject hmScenarioStatus = null;
		JSONArray jaScenarios = null;
		JSONArray jaResult = null;
		JSONObject joVariable = null;
		JSONObject joCol_Value = null;
		
		HashMap<String, Long> hmScenarioRuns = null;
		
		String strDeleteIdx = null, strEditIdx = null, strConfigIdx = null, strTitle = "";
		
		try {
			ltdbi = new LTDBI();
			joVariable = new JSONObject();
			joCol_Value = new JSONObject();
			jaResult = new JSONArray();

			jaScenarios = ltdbi.getVUScenarios(con, loginUserBean);
			for (int i = 0; i<jaScenarios.size(); i++ ){
				// Reset loop variables
				strDeleteIdx = null;
				strEditIdx = null;
				strConfigIdx = null;
				strTitle = null;
				
				JSONObject joScenario = jaScenarios.getJSONObject(i);
				JSONObject jo = ltdbi.getMappedScriptNames(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId());
				if(jo != null){
					joScenario.put("mappedo_scripts", jo.get("mappedScenarios"));
					joScenario.put("script_names", jo.get("script_name"));
					joScenario.put("runType", jo.get("runType"));
					joScenario.put("maxusers", jo.get("maxusers"));
				}
				// joScenario.put("mappedo_scripts", ltdbi.getMappedScripts(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId()));
				
				// gets runs for the scenario
				hmScenarioRuns = ltdbi.getScenarioRuns(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId());
				joScenario.put("total_runs", hmScenarioRuns.get("total_runs"));
				joScenario.put("completed_runs", hmScenarioRuns.get("total_runs_completed"));
				
				hmScenarioStatus = ltdbi.getScenarioRunStatus(con, joScenario.getLong("scenario_id"), loginUserBean.getUserId());
				if( hmScenarioStatus != null ){
					joScenario.put("run_id", hmScenarioStatus.getLong("runid"));
					joScenario.put("run_status", hmScenarioStatus.getBoolean("is_active"));
					joScenario.put("status", hmScenarioStatus.getString("status"));
				} else {
					joScenario.put("run_id", 0);
					joScenario.put("run_status", false);
					joScenario.put("status", "COMPLETED");
				}
				hmScenarioStatus = null;
				

				// new UI Design
				if( joScenario.getString("scenario_type").equals("APPEDO_LT") ) {
					strDeleteIdx = "is_delete";
					strEditIdx = "is_edit";
					strConfigIdx = "is_config";
					strTitle = "AppedoLT Scenario";
				} else if( joScenario.getString("scenario_type").equals("JMETER") ) {
					strDeleteIdx = "";
					strEditIdx = "";
					strConfigIdx = "";
					strTitle = "JMeter Scenario";
				}
				
				joVariable.put("var1", strDeleteIdx);
				joVariable.put("var2", strEditIdx);
				joVariable.put("var3", strConfigIdx);
				joVariable.put("var4", strTitle);
				joCol_Value.put("col_1", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", joScenario.getString("scenarioName"));
				joVariable.put("var2", "Added by "+loginUserBean.getFirstName()+" on ");
				joVariable.put("var21", joScenario.getString("created_on"));
				joCol_Value.put("col_2", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);

				joVariable.put("var1", "Mapped Script Name");
				joVariable.put("var2", joScenario.getString("script_names"));
				joCol_Value.put("col_3", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Mapped Scripts");
				joVariable.put("var2", joScenario.getString("mappedo_scripts"));
				joCol_Value.put("col_4", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "Vusers(L Run)");
				joVariable.put("var2", joScenario.getString("virtual_users"));
				joCol_Value.put("col_5", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joVariable.put("var1", "STATUS_Live");
				joVariable.put("var2", joScenario.getString("completed_runs")+" Completed");
				joCol_Value.put("col_6", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);

				joVariable.put("var1", "LT_Mon_stat_down");
				joCol_Value.put("col_7", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);

				joVariable.put("var1", "Pro_doc");
				joCol_Value.put("col_8", joVariable);
				UtilsFactory.clearCollectionHieracy(joVariable);
				
				joCol_Value.put("type", joScenario.getString("scenario_type"));
				joCol_Value.put("loadTestType", joScenario.getString("scenario_type"));
				joCol_Value.put("scenario_id", joScenario.getLong("scenario_id"));
				joCol_Value.put("mappedo_scripts", joScenario.getLong("mappedo_scripts"));
				joCol_Value.put("run_status", joScenario.getBoolean("run_status"));
				joCol_Value.put("run_id", joScenario.getLong("run_id"));
				joCol_Value.put("total_runs", joScenario.getLong("total_runs"));
				joCol_Value.put("virtual_users",joScenario.getLong("virtual_users"));
				joCol_Value.put("runType",joScenario.getString("runType"));
				joCol_Value.put("scenarioName",joScenario.getString("scenarioName"));
				jaResult.add(joCol_Value);
		
			}
			ltdbi = null;

		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltdbi = null;
		}

		//return jaScenarios;
		return jaResult;
	}
	
	public JSONObject getRunningScriptData(Connection con, long runId, long userId, String strTestType) throws Exception{
		
		LTDBI ltDBI = null;
		JSONArray jaRunningScripts = null;
		JSONObject joRunDetails = null;
		try {
			ltDBI = new LTDBI();
			joRunDetails = ltDBI.getRunDetails(con, runId, userId, strTestType);
			if ( joRunDetails != null ){
				joRunDetails = ltDBI.getRunStatus(con, runId, joRunDetails);
				jaRunningScripts = ltDBI.getRunningScriptData(con, runId);
				joRunDetails.put("scripts", jaRunningScripts);
				jaRunningScripts = null;
			}
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return joRunDetails;
	}
	
	public JSONObject getRunningScriptDataForChart(Connection con, long runId) throws Exception{
		LTDBI ltDBI = null;
		JSONObject joRunDetails = null;
		String outputString=null;
		try {
			ltDBI = new LTDBI();
			joRunDetails = new JSONObject();
			outputString = ltDBI.getUserRampUp(con, runId);
			if(outputString!=null){
				joRunDetails.put("userRampUp", outputString);
			}else{
				joRunDetails.put("userRampUp", "[]");
			}
			outputString = null;
			outputString = ltDBI.getRunChartDataForThroughputHitCounts(con, runId, Constants.LOADTESTRUNCHARTQUERYDURATION);
			if(outputString!=null){
				joRunDetails.put("tPutAndHitsCounts", outputString);
			}else{
				joRunDetails.put("tPutAndHitsCounts", "[]");
			}
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return joRunDetails;
	}
	
	public void updateReportMaster(Connection con, long lRunId, String status ) throws Exception {
    	LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			ltDBI.updateReportMaster(con, lRunId, status);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
	}
	
	public void updateManualReportRuntime(Connection con, long lRunId, long reportRunTime ) throws Exception {
    	LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			ltDBI.updateManualReportRuntime(con, lRunId, reportRunTime);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
	}
	
	public Boolean manualReportPreparation(Connection con, long lRunId)throws Throwable {
		LTDBI ltDBI = null;
		Boolean status = false;
		try {
			ltDBI = new LTDBI();
			if(ltDBI.manualSummaryReportPreparationScriptwiseContainerwiseResponse(con, lRunId)){
				if(ltDBI.manualSummaryReportPreparationTransactionError(con, lRunId)){
					if(ltDBI.manualSummaryReportPreparationRequestwise(con, lRunId)){
						status = true;
						updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_STARTED );
					}else{
						status = false;
						updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_FAILED );
						LogManager.errorLog("Manual Report Preparation :: Failed in manualSummaryReportPreparationRequestwise");
					}
				}else{
					status = false;
					updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_FAILED );
					LogManager.errorLog("Manual Report Preparation :: Failed in manualSummaryReportPreparationRequestwise");
				}
			}else{
				status = false;
				updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_FAILED );
				LogManager.errorLog("Manual Report Preparation :: Failed in manualSummaryReportPreparationRequestwise");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		}
		return status;
	}
	
	public Boolean manualReportGeneration(Connection con, long lRunId)throws Throwable {
		LTDBI ltDBI = null;
		Boolean status = false;
		try {
			ltDBI = new LTDBI();
			if(ltDBI.manualSummaryReportGenerationScriptwiseContainerwiseResponse(con, lRunId)){
				if(ltDBI.manualSummaryReportGenerationTransactionError(con, lRunId)){
					if(ltDBI.manualSummaryReportGenerationRequestwise(con, lRunId)){
						status = true;
						updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_COMPLETED );
					}else{
						status = false;
						updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_FAILED );
						LogManager.errorLog("Manual Report Generation :: Failed in manualSummaryReportGenerationRequestwise");
					}
				}else{
					status = false;
					updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_FAILED );
					LogManager.errorLog("Manual Report Generation :: Failed in manualSummaryReportGenerationTransactionError");
				}
			}else{
				status = false;
				updateReportMaster(con, lRunId, Constants.MANUAL_REPORT_GENERATION_FAILED );
				LogManager.errorLog("Manual Report Generation :: Failed in manualSummaryReportGenerationScriptwiseContainerwiseResponse");
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			status = false;
		}
		return status;
	}

	public String getLTScenarioReports(Connection con, String scenarioId, String strTestType, long userId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getLTScenarioReports(con, scenarioId, strTestType,userId);
			
			ltDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return jsonString;
	}
	
	public String getselectedReportRunStartAndEndTime(Connection con, long runid, String strTestType, long userId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getselectedReportRunStartAndEndTime(con, runid, strTestType,userId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

	public String getselectedReportGuid(Connection con, long runid, String strTestType, long userId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getselectedReportGuid(con, runid, strTestType,userId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

	public String getMasterSummaryReport(Connection con, long runId, long userId, String strTestType) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getMasterSummaryReport(con, runId, userId, strTestType);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}
	
	public String getSummaryDataForRequestResponse(Connection con, String runId, String strTestType,String scriptId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getSummaryDataForRequestResponse(con, runId, strTestType,scriptId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}
	
	public String getScriptSummaryReport(Connection con, String runId, String strTestType,String scriptId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getScriptSummaryReport(con, runId, strTestType,scriptId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}
	
	public String getSummaryDataForContainerResponse(Connection con, String runId, String strTestType,String scriptId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getSummaryDataForContainerResponse(con, runId, strTestType,scriptId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

	public String getSummaryDataForErrorCount(Connection con, String runId, String strTestType,String scriptId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getSummaryDataForErrorCount(con, runId, strTestType,scriptId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}
	
	public String getSummaryDataForErrorDescription(Connection con, String runId, String strTestType,String scriptId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getSummaryDataForErrorDescription(con, runId, strTestType,scriptId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}


	public String getSummaryDataForTransactionResponse(Connection con, String runId, String strTestType,String scriptId) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getSummaryDataForTransactionResponse(con, runId, strTestType,scriptId);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}
	
	/**
	 * gets user's load test type all reports OR scenario reports
	 * 
	 * @param con
	 * @param lScenarioId
	 * @param strLoadTestType
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getScenarioReports(Connection con, Long lScenarioId, String strLoadTestType, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jaReports = null;
		
		try {
			ltDBI = new LTDBI();
			
			jaReports = ltDBI.getScenarioReports(con, lScenarioId, strLoadTestType, loginUserBean);
			
			ltDBI = null;
		} catch(Exception e) {
			throw e;
		}
		
		return jaReports;
	}
	
	public JSONArray getLogReports(Connection con, long runId) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jaResults = null;
		
		try {
			jaResults = new JSONArray();
			ltDBI = new LTDBI();
			
			jaResults = ltDBI.getLogReports(con, runId);
			ltDBI = null;
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return jaResults;
	}
	
	public JSONArray getErrorReports(Connection con, long runId) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jaResults = null;
		
		try {
			jaResults = new JSONArray();
			ltDBI = new LTDBI();
			
			jaResults = ltDBI.getErrorReports(con, runId);
			ltDBI = null;
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return jaResults;
	}
	
	public JSONArray getRegions(Connection con, LoginUserBean loginUserBean, String osType) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jaRtnRegionss = null;
		
		try {
			ltDBI = new LTDBI();
			jaRtnRegionss = ltDBI.getRegions(con, loginUserBean, osType);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jaRtnRegionss;
	}
	
	public JSONObject getReportDetails(Connection con, long runId) throws Exception {
		JSONObject joReportDetails = null;

		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			
			joReportDetails = ltDBI.getReportDetails(con, runId);
			ltDBI = null;
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return joReportDetails;
	}
	
	public String generateReport(JSONObject joReportDetails, String strXMLFilePath, String strXSLTFilePath, String strGenerateHTMLFilePath) throws Exception {
		String strHTMLFileName = "", strHTMLFileFullPath = "";
		
		File fileXML = null, fileXSLT = null;
		
		try {

			fileXML = new File(strXMLFilePath);
			fileXSLT = new File(strXSLTFilePath);
				
			if( fileXML.exists() && fileXSLT.exists() ) {
				// XML parsing to add the report name 
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document doc = builder.parse(new InputSource(strXMLFilePath));
				
				// xml root node
				Node rootNode = doc.getFirstChild();
				Element rootElement = (Element) rootNode;
				rootElement.setAttribute("reportname", joReportDetails.getString("reportname"));
				
				TransformerFactory tFactory = TransformerFactory.newInstance();
				
				// Saves the xml setted attribute 
				DOMSource domSource = new DOMSource(doc);
				Transformer transformerXML = tFactory.newTransformer();
				transformerXML.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
				transformerXML.setOutputProperty(OutputKeys.METHOD, "xml");
				transformerXML.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
				transformerXML.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
				transformerXML.setOutputProperty(OutputKeys.INDENT, "yes");
				StreamResult result = new StreamResult(strXMLFilePath);
				transformerXML.transform(domSource, result);
				
				strHTMLFileName = joReportDetails.getString("runid")+".html";
				strHTMLFileFullPath = strGenerateHTMLFilePath + strHTMLFileName;
				
				Transformer transformer = tFactory.newTransformer(new StreamSource(fileXSLT));
				transformer.transform(new StreamSource(fileXML), new StreamResult(new FileOutputStream(strHTMLFileFullPath)));
			} else {
				strHTMLFileName = "na.html";
				strHTMLFileFullPath = strGenerateHTMLFilePath + strHTMLFileName;
			}
			    
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return strHTMLFileFullPath;
	}
	
	public void writeFileInResponse(String strFileName, PrintWriter out) throws Exception {
		FileInputStream fileInputStream = null;
		BufferedReader bufferedReader = null;
		InputStreamReader inputStreamReader = null;
		
		String strLine = null;
		
		try{
			fileInputStream = new FileInputStream(strFileName);
			inputStreamReader = new InputStreamReader(fileInputStream);
			bufferedReader = new BufferedReader( inputStreamReader );
			
			while( (strLine = bufferedReader.readLine()) != null ) {
				//System.out.println("strLine: "+strLine);
				out.println(strLine);
			}
			
		} catch (Exception ex){
			throw ex;
		} finally {
			if(bufferedReader != null) {
				bufferedReader.close();
			}
			bufferedReader = null;
			
			if(inputStreamReader != null) {
				inputStreamReader.close();
			}
			inputStreamReader = null;
			
			if(fileInputStream != null) {
				fileInputStream.close();
			}
			fileInputStream = null;
		}
	}
	
	public void mappingScripts(Connection con, LoginUserBean loginUserBean, String strTestType, String scenarioName, JSONArray scriptIds, long scenarioId) throws Exception {
		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			ltDBI.deleteMappingScripts(con, scenarioId, loginUserBean);
			if ( scenarioId > 0 && scriptIds != null){
				ltDBI.insertMappingScripts(con, scenarioId, strTestType, loginUserBean, scriptIds);
				ltDBI.updateVuser(con, loginUserBean, strTestType, scenarioId);
			}
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
	}
	
	public long insertScenarioName(Connection con, String scenarioName, String strTestType, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		long scenarioId = 0;
		LTLicenseBean ltLicBean = null;
		try {
			ltDBI = new LTDBI();
			ltLicBean = getLTLicenseDetails(con, loginUserBean);
			if( strTestType.equalsIgnoreCase("APPEDO_LT") ){
				scenarioId = ltDBI.insertScenarioName(con, scenarioName, strTestType, ltLicBean, loginUserBean);
			} else {
				scenarioId = ltDBI.insertJmeterScenarioName(con, scenarioName, strTestType, ltLicBean, loginUserBean);
			}
			
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return scenarioId;
	}
	public LTLicenseBean getLTLicenseDetails(Connection con, LoginUserBean loginBean) throws Exception {
		LTLicenseBean ltLicBean = null;
		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			
			// gets license details from month wise table
			ltLicBean = ltDBI.getLTUserWiseLicenseMonthWise(con, loginBean);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return ltLicBean;
	}
	public JSONObject getScenarioDetails(Connection con, long scenarioId, String testTypeScript, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jaResults = null;
		JSONObject joScenario = null;
		try {
			jaResults = new JSONArray();
			ltDBI = new LTDBI();
			joScenario = ltDBI.getScenarioName(con, scenarioId, testTypeScript, loginUserBean);
			jaResults = ltDBI.getScenarioDetails(con, scenarioId, testTypeScript, loginUserBean);
			joScenario.put("script", jaResults);
			jaResults = null;
			ltDBI = null;
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
			jaResults = null;
		}
		return joScenario;
	}
	
	public void updateScenarios(Connection con, LoginUserBean loginUserBean, String strTestType, String scenarioName, long scenarioId, JSONArray scriptIds) throws Exception {
		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			ltDBI.updateScenarioName(con, scenarioName, strTestType, scenarioId, loginUserBean);
			ltDBI.deleteMappingScripts(con, scenarioId, loginUserBean);
			if ( scriptIds.size() > 0){
				ltDBI.insertMappingScripts(con, scenarioId, strTestType, loginUserBean, scriptIds);
				ltDBI.updateVuser(con, loginUserBean, strTestType, scenarioId);
			}
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
	}
	
	public void deleteScenarios(Connection con, LoginUserBean loginUserBean, String strTestType, long scenarioId) throws Exception {
		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			ltDBI.deleteMappingScripts(con, scenarioId, loginUserBean);
			ltDBI.deleteScenarios(con, scenarioId, strTestType, loginUserBean);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
	}
	
	public JSONArray mappingAgent(Connection con, LoginUserBean loginUserBean, String strTestType, String apmGroup, String scenarioId) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jaAgents = null, jaMonitors = null;
		JSONObject joAgent = null;
		try {
			ltDBI = new LTDBI();
			jaMonitors = new JSONArray();
			for ( String apm:apmGroup.split(",")){
				joAgent = new JSONObject();
				jaAgents = ltDBI.mappingAgent(con, loginUserBean, strTestType, apm, scenarioId);
				joAgent.put("apm", apm);
				joAgent.put("agents", jaAgents);
				jaMonitors.add(joAgent);
				jaAgents = null;
				joAgent = null;
			}
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
			jaAgents = null;
			joAgent = null;
		}
		
		return jaMonitors;
	}

	public JSONArray getLTDashDonut(Connection con, long userid,String type,String runid) throws Exception{
		LTDBI ltDBI = null;
		JSONArray jaAgents = null;
		try {
			ltDBI = new LTDBI();
			jaAgents = ltDBI.getLTDashDonut(con, userid,type,runid);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return jaAgents;
	}
	
	public JSONArray getScenarioSettings(Connection con, long userid, String type, long scenarioId) throws Exception{
		LTDBI ltDBI = null;
		JSONArray jaScenario = null;
		try {
			ltDBI = new LTDBI();
			jaScenario = ltDBI.getScenarioSettings(con, userid, type, scenarioId);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return jaScenario;
	}
	
	public void updateScenarioSettings(Connection con, LoginUserBean loginUserBean, String strTestType, String scenarioSettings, long scenarioId, String scriptIds) throws Exception {
		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			if ( scriptIds.length() > 0){
				ltDBI.updateScenarioSettings(con, loginUserBean, strTestType, scenarioSettings, scenarioId, scriptIds);
				ltDBI.updateVuser(con, loginUserBean, strTestType, scenarioId);
			}
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
	}
	
	public  void saveXmlDoc(Document mdoc, String xmlfilePath)throws Throwable {
		
		TransformerFactory transformerFactory = null;
		Transformer transformer = null;
		DOMSource source = null;
		StreamResult result = null;
		try {
			// write the content into xml file
			 transformerFactory = TransformerFactory.newInstance();
			 transformer = transformerFactory.newTransformer();
			 source = new DOMSource(mdoc);
			 result = new StreamResult(new File(xmlfilePath));
			 // Output to console for testing
			 transformer.transform(source, result);
			 LogManager.infoLog("File saved!");
		}catch(Throwable t)	{
			LogManager.errorLog(t);
			throw t;
		}finally {
			transformerFactory = null;
			transformer = null;
			source = null;
			result = null;
		}
	}

	public JSONArray getLTLicense(Connection con, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		JSONArray json = null;
		try {
			ltDBI = new LTDBI();
			json = ltDBI.getLTLicense(con, loginUserBean);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return json;
	}
	
    public JSONArray getDashResponseArea(Connection con, LoginUserBean loginUserBean,long runid) throws Exception {
    	LTDBI ltDBI = null;
		JSONArray json = null;
		try {
			ltDBI = new LTDBI();
			json = ltDBI.getDashResponseArea(con, loginUserBean,runid);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return json;
    }
    
    public JSONArray getDashVUsersArea(Connection con, LoginUserBean loginUserBean,long runid, String scenarioName) throws Exception {
    	LTDBI ltDBI = null;
		JSONArray json = null;
		try {
			ltDBI = new LTDBI();
			json = ltDBI.getDashVUsersArea(con, loginUserBean, runid, scenarioName);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return json;
    }

    public JSONObject getReportsChart(Connection con, String strReportId, String strReportType, String startTime) throws Exception {
    	LTDBI ltDBI = null;
    	JSONObject jaResults = null;
		
		try {
			jaResults = new JSONObject();
			ltDBI = new LTDBI();
			
			jaResults = ltDBI.getReportsChart(con, strReportId, strReportType, startTime);
			ltDBI = null;
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return jaResults;
    }

    public String getChartDataForAppdeoLTUserCounts(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getChartDataForAppdeoLTUserCounts(con, strReportId, strReportType, startTime, queryDuration , selectedTime , status, runTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

    public Boolean checkEndTimeFormatForExistingTest(Connection con, String strReportId) throws Exception {
    	LTDBI ltDBI = null;
		Boolean outputStatus = false;
		try {
			ltDBI = new LTDBI();
			
			outputStatus = ltDBI.checkEndTimeFormatForExistingTest(con, strReportId);
			ltDBI = null;
			
		} catch (Exception e) {
			outputStatus = false;
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return outputStatus;
	}
    
    public Boolean runEndTimeFormatForExistingTest(Connection con, String strReportId) throws Exception {
    	LTDBI ltDBI = null;
		Boolean outputStatus = false;
		try {
			ltDBI = new LTDBI();
			
			outputStatus = ltDBI.runEndTimeFormatForExistingTest(con, strReportId);
			ltDBI = null;
			
		} catch (Exception e) {
			outputStatus = false;
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return outputStatus;
	}

    public String getChartDataForAppdeoLTThroughputHitCountsAndReqResponse(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getChartDataForAppdeoLTThroughputHitCountsAndReqResponse(con, strReportId, strReportType, startTime, queryDuration , selectedTime , status, runTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

    public String getChartDataForAppdeoLTErrorCounts(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getChartDataForAppdeoLTErrorCounts(con, strReportId, strReportType, startTime, queryDuration , selectedTime , status, runTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

    public String getChartDataForAppdeoLTPageResponse(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getChartDataForAppdeoLTPageResponse(con, strReportId, strReportType, startTime, queryDuration , selectedTime , status, runTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

    public JSONArray getLoadgensAvgReqResp(Connection con, String strReportId, String strReportType, String startTime) throws Exception {
    	LTDBI ltDBI = null;
		JSONArray jsonArray = new JSONArray();
		try {
			ltDBI = new LTDBI();
			
			jsonArray = ltDBI.getLoadgensAvgReqResp(con, strReportId, strReportType, startTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonArray;
	}
    
    public String getLoadgensAvgReqResp(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status, String runTime) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getLoadgensAvgReqResp(con, strReportId, strReportType, startTime, queryDuration , selectedTime , status, runTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

	public JSONArray getLoadgensAvgPageResp(Connection con, String strReportId, String strReportType, String startTime) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jsonArray = new JSONArray();
		
		try {
			ltDBI = new LTDBI();
			
			jsonArray = ltDBI.getLoadgensAvgPageResp(con, strReportId, strReportType, startTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonArray;
	}

    public String getLoadgensAvgPageResp(Connection con, String strReportId, String strReportType, String startTime , String queryDuration ,String selectedTime ,String status,String runTime) throws Exception {
    	LTDBI ltDBI = null;
		String jsonString = null;
		try {
			ltDBI = new LTDBI();
			
			jsonString = ltDBI.getLoadgensAvgPageResp(con, strReportId, strReportType, startTime, queryDuration , selectedTime , status, runTime);
			ltDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		
		return jsonString;
	}

	public JSONObject loadLoadTestLicenseDetails(Connection con, LoginUserBean userBean) {
		
		LTDBI ltDBI = null;
		JSONObject joRtn = null;
		try {
			ltDBI = new LTDBI();
			joRtn = ltDBI.loadLoadTestLicenseDetails(con, userBean);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
		}finally{
			ltDBI = null;
		}
		return joRtn;
	}
	
	public long insertJmeterScriptName(Connection con, String scriptName, String strTestType, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		long scenarioId = 0;
		try {
			ltDBI = new LTDBI();
			scenarioId = ltDBI.insertJmeterScriptName(con, scriptName, strTestType, loginUserBean);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return scenarioId;
	}
	
	public JSONObject getCountersForLoadTest(Connection con, String strGUID, String strCounters, String strMaxTimeStamp, String strFromStartInterval ,String strStartTime, String strEndTime, String runTime, boolean bMiniChartRequest) throws Exception {
		LTDBI ltDBI = null;
		
		JSONObject joRtnCountersData = null;
		
		try {
			ltDBI = new LTDBI();

			// 
			joRtnCountersData = ltDBI.getCountersForLoadTest(con, strGUID, strCounters, strMaxTimeStamp, strFromStartInterval, strStartTime, strEndTime, runTime, bMiniChartRequest);

			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return joRtnCountersData;
	}

	public String getCountersForLoadTest(Connection con, String strGUID, String strCounters, String startTime, String endTime ,String runTime, String queryDuration, String selectedTime, String status) throws Exception {
		LTDBI ltDBI = null;
		
		String jsonString = null;
		
		try {
			ltDBI = new LTDBI();

			jsonString = ltDBI.getCountersForLoadTest(con, strGUID, strCounters,startTime, endTime, runTime,queryDuration,selectedTime,status);

			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}

		return jsonString;
	}
	
	public JSONArray getScriptDetails(Connection con, long scenarioId) throws Throwable {
		LTDBI ltDBI = null;
	
		JSONArray jaScript = null;
		try {
			ltDBI = new LTDBI();
			jaScript = ltDBI.getScriptDetails(con, scenarioId);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaScript;
	}

	public int getUserMaxRunCount(Connection con, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
	
		int nUserTotalRuncount = 0;
		
		try {
			ltDBI = new LTDBI();
			nUserTotalRuncount = ltDBI.getUserMaxRunCount(con, loginUserBean);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return nUserTotalRuncount;
	}
	
	public int getUserMaxRunCountPerDay(Connection con, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
	
		int nUserTotalRuncountPerDay = 0;
		
		try {
			ltDBI = new LTDBI();
			nUserTotalRuncountPerDay = ltDBI.getUserMaxRunCountPerDay(con, loginUserBean);
//			runDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return nUserTotalRuncountPerDay;
	}
	public JSONObject isUserRunningScenario(Connection con, LoginUserBean loginUserBean, String strTestType ) throws Exception {
		LTDBI ltDBI = null;
	
		JSONObject joRtnUserRunningScenario = null;
		try {
			ltDBI = new LTDBI();
			joRtnUserRunningScenario = ltDBI.isUserRunningScenario(con, loginUserBean, strTestType);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return joRtnUserRunningScenario;
	}
	
	public long  insertIntoReportMaster(Connection con, LoadTestSchedulerBean schedulerBean, LoginUserBean loginUserBean) throws Throwable {
		LTDBI ltDbi = new LTDBI();
		long lRunId = -1L;
		boolean bExist = false;
		LTLicenseBean ltLicBean = null;
		
		try	{
			bExist = ltDbi.isReportNameExist(con, schedulerBean);
			if(bExist) {
				throw new Exception("ReportNameExist");
			} else {
				ltLicBean = getLTLicenseDetails(con, loginUserBean);
				lRunId = ltDbi.insertIntoReportMaster(con, ltLicBean, schedulerBean);
			}
		} catch(Throwable t) {
			LogManager.errorLog(t);
			throw t;
		}
		
		return lRunId;
	}
	
	public void updatePrivateCounters(Connection con, String columnName, long queueValue) throws Exception {
		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			ltDBI.updatePrivateCounters(con, columnName, queueValue);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
	}
	
	public void insertAgentMapping(Connection con, String guids, long runId) throws Throwable {
		
		LTDBI ltDbi = new LTDBI();
		try	{
			ltDbi.insertAgentMapping(con, guids, runId);
		}
		catch(Throwable t) {
			LogManager.errorLog(t);
			throw t;
		}
	}
	
	public void updateProcessServiceFailed(Connection con, String status, long runId) throws Exception{
		
		LTDBI ltDBI = null;
		try {
			ltDBI = new LTDBI();
			ltDBI.updateProcessServiceFailed(con, status, runId);
			ltDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	public String getIPStatus(String strControllerIP , int nPort) throws Throwable {
		// Members 
		Socket socketConn = null;
		OutputStream oStream = null;
		InputStream inStream = null;
		
		byte[] bOperation = null;
		byte[] bytes = null;
		
		String strOperation = null , strReqHeader = null , strReceivedStremContent = null;		
		int nResponseStreamLength = 0 , nReadCount = 0;
		String strStatus = "inactive";
		try {
			
			socketConn = new Socket(strControllerIP, nPort);
			// connection success
			oStream = socketConn.getOutputStream();
			
			// Make operation format
			strOperation = "TEST: 0\r\n\r\n";
			
			bOperation = strOperation.getBytes();
			oStream.write(bOperation, 0, bOperation.length);
			
			// get response from controller
			inStream = socketConn.getInputStream();
			strReqHeader = readHeader(inStream);
			
			String[] reqtokens = strReqHeader.trim().split(": ");
			nResponseStreamLength = Integer.parseInt(reqtokens[1].toString().split("\r\n")[0]);
			
			bytes = new byte[nResponseStreamLength];
			
			if(nResponseStreamLength>0)	{		 
				 
				 while (nReadCount < nResponseStreamLength)	{
					 nReadCount+= inStream.read(bytes, nReadCount, nResponseStreamLength-nReadCount);
					 LogManager.infoLog("byte read"+nReadCount);
				}
			 }
			 // response content
			 strReceivedStremContent = new String(bytes);
			 if(strReqHeader.contains("OK")) {
				 // return sucess status
				 strStatus = "active";
			 }
			 
			 LogManager.infoLog("received"+strReceivedStremContent);
		}catch(Throwable t) {
			LogManager.errorLog(t);
			//throw t;
			strStatus = "inactive";
			
		}finally {
			
			if(inStream!= null) {
				inStream.close();				
			}
			inStream = null;
			
			if(oStream!= null) {
				oStream.close();
			}
			oStream = null;
			if(socketConn!= null) {
				socketConn.close();
			}
			socketConn = null;
			
			strOperation = null;
			strReqHeader = null;
			strReceivedStremContent = null;
			bOperation = null;
			bytes = null;
		}
		return strStatus;
	}
	
	public String readHeader(InputStream stream) throws Throwable {
		StringBuffer instr = null;
		int c;
		try	{
			instr = new StringBuffer();
			while (true ) {
				c=stream.read();
				instr.append( (char) c);
				if(instr.toString().endsWith("\r\n\r\n") )
					break;
			}
		}catch(Throwable t)	{
			LogManager.errorLog(t);
			throw t;
		}
		return instr.toString();
	}
	
	public Long scenarioReferenceFromReportMaster(Connection con, long userId, long scenarioId) throws Throwable{
		LTDBI ltDBI = null;
		Long completedRuns = 0L;
		try {
			ltDBI = new LTDBI();
			completedRuns = ltDBI.scenarioReferenceFromReportMaster(con, scenarioId, userId );
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return completedRuns;
	}
	
	public JSONArray getUserAgentDetails(Connection con) throws Exception {
		LTDBI ltDBI = null;
		JSONArray jaUserAgent = null;
		
		try {
			jaUserAgent = new JSONArray();
			ltDBI = new LTDBI();
			
			jaUserAgent = ltDBI.getUserAgentDetails(con);
			ltDBI = null;
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return jaUserAgent;
	}
	
	public JSONArray getRunSettings(Connection con, long userid, long runId, long scriptId) throws Exception{
		LTDBI ltDBI = null;
		JSONArray jaScenario = null;
		try {
			ltDBI = new LTDBI();
			jaScenario = ltDBI.getRunSettings(con, userid, runId, scriptId);
			ltDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally{
			ltDBI = null;
		}
		return jaScenario;
	}
	
	/**
	 * gets notes for the runid's category OR runid's category script_id's
	 * 
	 * @param con
	 * @param lRunId
	 * @param strCategory
	 * @param lScriptId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public SummaryReportNotesBean getSummaryReportCategoryNote(Connection con, long lRunId, String strCategory, Long lScriptId, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		
		SummaryReportNotesBean notesBean = null;
		
		try {
			ltDBI = new LTDBI();
			
			// gets notes for the run's category
			notesBean = ltDBI.getSummaryReportCategoryNote(con, lRunId, strCategory, lScriptId, loginUserBean);
			
			ltDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return notesBean;
	}
	
	/**
	 * inserts summary report notes for the user's LT run_id,
	 * adds run's summary report notes for the category, 
	 *   if category based on script wise script_id is added else script_id = `-1`
	 *   
	 * @param con
	 * @param notesBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void insertSummaryReportCategoryNote(Connection con, SummaryReportNotesBean notesBean, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		
		boolean bUserRun = false;
		
		try {
			ltDBI = new LTDBI();
			
			// check the run_id belongs to login user; for security 
			bUserRun = ltDBI.isRunOwner(con, notesBean.getRunId(), loginUserBean.getUserId());
			if ( ! bUserRun ) {
				throw new Exception("1");
			}
			
			// inserts notes for the user
			ltDBI.insertSummaryReportCategoryNote(con, notesBean, loginUserBean.getUserId());
			
			ltDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * update notes for the id
	 * 
	 * @param con
	 * @param notesBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateSummaryReportCategoryNote(Connection con, SummaryReportNotesBean notesBean, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		
		try {
			ltDBI = new LTDBI();
			
			ltDBI.updateSummaryReportCategoryNote(con, notesBean, loginUserBean.getUserId());
			
			ltDBI = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * gets run_id's category wise notes,
	 * 
	 * @param con
	 * @param lRunId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> getRunSummaryReportNotes(Connection con, long lRunId, LoginUserBean loginUserBean) throws Exception {
		LTDBI ltDBI = null;
		
		HashMap<String, Object> hmCategoryWiseNotes = null;
		
		try {
			ltDBI = new LTDBI();
			
			hmCategoryWiseNotes = ltDBI.getRunSummaryReportNotes(con, lRunId, loginUserBean.getUserId());
			
			ltDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return hmCategoryWiseNotes;
	}
}