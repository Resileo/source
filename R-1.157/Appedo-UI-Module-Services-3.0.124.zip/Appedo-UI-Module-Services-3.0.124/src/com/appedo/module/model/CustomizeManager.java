package com.appedo.module.model;

import java.sql.Connection;

import net.sf.json.JSONArray;

import com.appedo.module.dbi.CustomizeDBI;

public class CustomizeManager {
	
	public JSONArray getCountryCodeDetails(Connection con) throws Exception {
		CustomizeDBI customizeDBI = null;
		
		JSONArray jaCountryCodes = null;
		
		try {
			customizeDBI = new CustomizeDBI();
			
			jaCountryCodes = customizeDBI.getCountryCodeDetails(con);
			
			customizeDBI = null; 
		} catch (Exception e) {
			throw e;
		}
		
		return jaCountryCodes;
	}
	
}
