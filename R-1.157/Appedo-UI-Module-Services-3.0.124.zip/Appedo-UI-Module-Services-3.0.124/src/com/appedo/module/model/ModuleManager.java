package com.appedo.module.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.RandomStringUtils;

import com.appedo.commons.bean.LoginUserBean;
import com.appedo.commons.manager.AppedoMailer;
import com.appedo.commons.manager.AppedoMailer.MODULE_ID;
import com.appedo.manager.LogManager;
import com.appedo.module.bean.APMLicenseBean;
import com.appedo.module.bean.DDLicenseBean;
import com.appedo.module.bean.ModuleBean;
import com.appedo.module.bean.RUMLicenseBean;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.dbi.ChartDBI;
import com.appedo.module.dbi.ModuleDBI;
import com.appedo.module.dbi.ServiceDBI;
import com.appedo.module.utils.UtilsFactory;

public class ModuleManager {
	
	private JSONObject joDeletedGUIDSLAs = null;
	
	
	/**
	 * add's new module(Application/Server/Database/RUM)
	 * creates respective table partitions
	 * 
	 * @param con
	 * @param moduleBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public void addModule(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, JSONObject joEnt) throws Exception {
		APMLicenseBean apmLicenseBean = null;
		RUMLicenseBean rumLicenseBean = null;
		
		ServiceManager serviceManager = null;
		
		long lModuleId = -1L;
		
		try {
			serviceManager = new ServiceManager();
			
			// Note user defined Exceptions thrown in below methods for APM and RUM, handled both exceptions means same meaning,
			if( ! moduleBean.getModuleType().equals("RUM") ){
				// for APPLICATION/SERVER/DATABASE
				
				// gets license details from `userwise_lic_monthwise` and `apm_config_param` tables
				apmLicenseBean = getAPMUserLicenseDetails(con, loginUserBean);
				
				// for Application/Server/Database
				lModuleId = insertAPMModuleAndCreateUidTablePartitions(con, moduleBean, apmLicenseBean, loginUserBean, joEnt);
				
				// for adding chart_visual_data
				if (lModuleId != -1L) {
					//insertChartVisualData(con, moduleBean, loginUserBean, lModuleId);
					insertChartVisualizationData(con, moduleBean, loginUserBean, lModuleId);
				}
				
			} else {
				// for RUM
				
				// gets license details from `userwise_lic_monthwise` and `rum_config_param` tables
				rumLicenseBean = getRUMUserLicenseDetails(con, loginUserBean);
				
				// for RUM
				lModuleId = insertRUMModuleAndCreateUidTablePartitions(con, moduleBean, rumLicenseBean, loginUserBean, joEnt);
				// To insert chart visual data
				if (lModuleId != -1L) {
					insertChartVisualizationDataRUM(con, loginUserBean, lModuleId);
				}
			}
			
			// 
			createAllModuleLastCounterView(con, loginUserBean.getUserId());
			
			// map the added module to system generated Service Map 
			serviceManager.mapModuleToSystemServiceMap(con, JSONObject.fromObject("{\"module_master\":{\"module_code\":\""+moduleBean.getModuleType()+"\",\"uid\":"+lModuleId+"}}"), loginUserBean);
			
			serviceManager = null;
			apmLicenseBean = null;
			rumLicenseBean = null;
		} catch(Exception e) {
			throw e;
		}
		
		//return lModuleId;
	}
	
	/**
	 * 
	 * 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @throws Exception
	 */
	public long addEnterprise(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean ) throws Exception {
		long lEnterpriseId = -1L, lTotalEnterprise, lMaxEnterprise;
		ModuleDBI modulesDBI = null;
		
		try{
			modulesDBI = new ModuleDBI();
			
			lMaxEnterprise = modulesDBI.getMaxEnterprise(con, loginUserBean);
			
			lTotalEnterprise = modulesDBI.getTotalEnterprise(con, loginUserBean);
			
			if(lMaxEnterprise <= lTotalEnterprise){
				throw new Exception("1");
			}else{
				lEnterpriseId = modulesDBI.addEnterprise(con, moduleBean, loginUserBean);
				// enterprise Mapping with user
				userEnterpriseMapping(con, lEnterpriseId, loginUserBean.getUserId(), loginUserBean.getEmailId(), loginUserBean);
			}
						
			
		}catch(Exception e) {
			throw e;
		}finally{
			modulesDBI = null;
		}
		return lEnterpriseId;
	}
	
	public void userEnterpriseMapping(Connection con, long lEnterpriseId, long lUser_id, String strEmail_id, LoginUserBean loginUserBean) throws Exception {
		long lTotalEnterpriseMapping, lMaxEnterpriseMapping;
		ModuleDBI modulesDBI = null;
		
		try{
			modulesDBI = new ModuleDBI();
			
			lMaxEnterpriseMapping = modulesDBI.getMaxUserEnterpriseMapping(con, loginUserBean);
			
			lTotalEnterpriseMapping = modulesDBI.getTotalEnterpriseMapping(con, lEnterpriseId);
			
			if(lMaxEnterpriseMapping <= lTotalEnterpriseMapping){
				throw new Exception("2");
			}else{
				// enterprise Mapping with user
				modulesDBI.userEnterpriseMapping(con, lEnterpriseId, lUser_id, strEmail_id);
			}
		}catch(Exception e) {
			throw e;
		}finally{
			modulesDBI = null;
		}
	}

	public void addUserEnterpriseMapping(Connection con, JSONObject joEntUserDetails, long lEnterpriseId, LoginUserBean loginUserBean, String strEntName ) throws Exception {
	
		ModuleDBI modulesDBI = null;
		boolean isNewUser = false;
		long lUserId, lVerificationHistoryId = -1L;
		String strPassword = null;
		
		try{
			modulesDBI = new ModuleDBI();
			
			lUserId = modulesDBI.isExistUser(con, joEntUserDetails);
			joEntUserDetails.put("enterpriseName", strEntName);
			if(lUserId != -1){
				// enterprise Mapping with user
				userEnterpriseMapping(con, lEnterpriseId, lUserId, joEntUserDetails.getString("emailId"), loginUserBean);
			} else {
				isNewUser = true;
				strPassword = RandomStringUtils.randomAlphanumeric(15).toUpperCase();
				joEntUserDetails.put("password", strPassword);
				//joEntUserDetails.put("telephoneCode", );
				lUserId = createUserAndMapEnterprise(con, joEntUserDetails, lEnterpriseId, loginUserBean, strEntName);
				if (lUserId > 0) {
					joEntUserDetails.put("userId", lUserId);
					userEnterpriseMapping(con, lEnterpriseId, lUserId, joEntUserDetails.getString("emailId"), loginUserBean);
					
					lVerificationHistoryId = modulesDBI.insertEmailVerificationHistory(con, lUserId);
					
				} else {
					throw new Exception("1");
				}

			}
			
			sendVerificationMail(lVerificationHistoryId, joEntUserDetails, loginUserBean, isNewUser);
			
		}catch(Exception e) {
			throw e;
		}
	}

	public long createUserAndMapEnterprise(Connection con, JSONObject joEntUserDetails, long lEnterpriseId, LoginUserBean loginUserBean, String strEntName) throws Exception {
		
		HttpClient client = null;
		String responseJSONStream = null;
		JSONObject joResponse = null, joUserBean = null;
		long lmappedNewUserId = -1L;
		
		try{
			
			client = new HttpClient();
			
			PostMethod method = new PostMethod(Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/userSignup");
			
			method.setRequestHeader("Connection", "close");
			method.setParameter("user_email_id", joEntUserDetails.getString("emailId"));
			method.setParameter("user_password", joEntUserDetails.getString("password"));
			method.setParameter("user_first_name", joEntUserDetails.getString("firstName"));
			method.setParameter("user_last_name", joEntUserDetails.getString("lastName"));
			if (joEntUserDetails.containsKey("mobile") && joEntUserDetails.getString("mobile") != null) {
				method.setParameter("user_mobileno",  joEntUserDetails.getString("mobile"));
				method.setParameter("user_telephone_code", "91");
			} else {
				method.setParameter("user_mobileno",  "");
				method.setParameter("user_telephone_code", "");
			}
			method.setParameter("addedVia", "ENTERPRISE");
			
			int statusCode = client.executeMethod(method);
			
			if (statusCode != HttpStatus.SC_OK) {
				LogManager.infoLog("HTTP Failed for "+Constants.APPEDO_UI_CREDENTIAL_SERVICES+"/credentials/userSignup <> "+joEntUserDetails.getString("emailId")+" <> StatusCode: "+statusCode+" <> StatusLine: "+method.getStatusLine());
			} else {
				responseJSONStream = method.getResponseBodyAsString();
				
				if( responseJSONStream.trim().startsWith("{") && responseJSONStream.trim().endsWith("}")) {
					joResponse = JSONObject.fromObject(responseJSONStream);
					
					if( joResponse.getBoolean("success") ) {
						if( joResponse.containsKey("userBean") ) {
							joUserBean = joResponse.getJSONObject("userBean");
							
							lmappedNewUserId = joUserBean.getLong("userId");
							
						} else {
							throw new Exception("1");	// TODO Inform that Service has problem
						}
					} else {
						if( joResponse.containsKey("errorMessage") ) {
							throw new Exception( joResponse.getString("errorMessage") );
						} else {
							throw new Exception("1");	// TODO Inform that Service has problem
						}
					}
				}
			}
		} catch(Exception e) {
			throw e;
		}
		return lmappedNewUserId;
	}
	
	/**
	 * send verification mail for the user
	 * 
	 * @param strAppedourl
	 * @param userBean
	 * @throws Exception
	 */
	public void sendVerificationMail(long lVerificationHistoryId, JSONObject joEntUserDetails, LoginUserBean loginBean, boolean isNewUser) throws Exception {
		AppedoMailer appedoMailer = null;
		
		HashMap<String, Object> hmMailDetails = null;
		
		String strSubject = "";
		
		try {
			appedoMailer = new AppedoMailer( Constants.EMAIL_TEMPLATES_PATH );
			
			if (!isNewUser) {
				//calling sendmail method(module)
				hmMailDetails = new HashMap<String, Object>();
				hmMailDetails.put("USERNAME", joEntUserDetails.getString("firstName"));
				hmMailDetails.put("fullEntName", joEntUserDetails.getString("enterpriseName"));
				hmMailDetails.put("entOwnerEmailId", loginBean.getEmailId());
				hmMailDetails.put("APPEDO_URL", Constants.APPEDO_URL);
				hmMailDetails.put("LINK", Constants.APPEDO_URL);
				strSubject = "{{ appln_heading }} Enterprise Invitation";
				appedoMailer.sendMail(MODULE_ID.ENTERPRISE_INVITATION, hmMailDetails, joEntUserDetails.getString("emailId").split(","), strSubject);
			} else {
				hmMailDetails = new HashMap<String, Object>();
				hmMailDetails.put("USERNAME", joEntUserDetails.getString("firstName"));
				hmMailDetails.put("fullEntName", joEntUserDetails.getString("enterpriseName"));
				hmMailDetails.put("email_id", joEntUserDetails.getString("emailId"));
				hmMailDetails.put("password", joEntUserDetails.getString("password"));
				hmMailDetails.put("entOwnerEmailId", loginBean.getEmailId());
				hmMailDetails.put("LINK", Constants.APPEDO_URL+"verifyEmailAddress?uid="+CryptManager.encryptEncodeURL(joEntUserDetails.getString("userId"))+"&vh_id="+CryptManager.encryptEncodeURL(lVerificationHistoryId+"")+"&email="+joEntUserDetails.getString("emailId"));
				strSubject = "{{ appln_heading }} Enterprise Invitation";
				appedoMailer.sendMail(MODULE_ID.ENTERPRISE_SIGNUP_INVITATION, hmMailDetails, joEntUserDetails.getString("emailId").split(","), strSubject);
			} 
			UtilsFactory.clearCollectionHieracy(hmMailDetails);
		} catch (Exception e) {
			throw e;
		} finally {
			appedoMailer = null;
			strSubject = null;
		}
	}
	
	
	/**
	 * checks user's limit to add module(Application/Server/Database) based on license
	 * creates respective table partitions
	 * 
	 * @param con
	 * @param moduleBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public boolean isModuleLimitExceded(Connection con, LoginUserBean loginUserBean ) throws Exception {
		APMLicenseBean apmLicenseBean = null;

		long lTotalUserModulesCount = 0;
		boolean isLimitExceeded = false;
		
		try {
			// only for APPLICATION/SERVER/DATABASE
			
			// gets license details from `userwise_lic_monthwise` and `apm_config_param` tables
			apmLicenseBean = getAPMUserLicenseDetails(con, loginUserBean);
			
			if(apmLicenseBean == null) {
				// License expired for user
				throw new Exception("1");
			} else {
				// gets user added total no. of modules in APPLICATION/SERVER/DATABASE 
				lTotalUserModulesCount = getUserAddedModulesCount(con, Constants.APM_GROUP, loginUserBean);
				
				// max Agents means for Max modules added in APPLICATION/SERVER/DATABASE 
				if( apmLicenseBean.getMaxAgents() <= lTotalUserModulesCount && apmLicenseBean.getMaxAgents() != -1 ) {
					// User max modules count exceeds
					isLimitExceeded = true;
				}
			}
			apmLicenseBean = null;
		} catch(Exception e) {
			throw e;
		}
		
		return isLimitExceeded;
	}
	
	/**
	 * gets user APM license details 
	 * 
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public APMLicenseBean getAPMUserLicenseDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;

		APMLicenseBean apmLicenseBean = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			// gets license details from month wise table
			apmLicenseBean = modulesDBI.getAPMUserWiseLicenseMonthWise(con, loginUserBean);
			
			if(apmLicenseBean != null) {
				// get license details from `apm config params`
				APMLicenseBean apmLicenseBeanConfigParams = modulesDBI.getAPMLicenseConfigParameters(con, loginUserBean);

				apmLicenseBean.setLicInternalName(apmLicenseBeanConfigParams.getLicInternalName());
				apmLicenseBean.setLicExternalName(apmLicenseBeanConfigParams.getLicExternalName());
				apmLicenseBean.setAllowPrivateCounters(apmLicenseBeanConfigParams.isAllowPrivateCounters());
				apmLicenseBean.setEnableSlider(apmLicenseBeanConfigParams.isEnableSlider());
				apmLicenseBean.setReportRetentionInDays(apmLicenseBeanConfigParams.getReportRetentionInDays());
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return apmLicenseBean;
	}
	public JSONObject getAPMModules(Connection con, LoginUserBean loginBean, String strModuleType, String strLimit, String strOffset) throws Exception {
		JSONObject joAPMModule = null;
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			joAPMModule = apmDBI.getAPMModules(con, loginBean, strModuleType, strLimit, strOffset);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			apmDBI = null;
		}
		return joAPMModule;
		
	}
	
	public JSONObject getAPMModules01(Connection con, LoginUserBean loginBean, String strModuleType, String strLimit, String strOffset, JSONObject joEnt) throws Exception {
		JSONObject joAPMModule = new JSONObject();
		//JSONObject joSUMModule = new JSONObject();
		JSONArray joAPMCardDatas = null;
		JSONArray joAPMCardStatus = null, joRUMCardStatus = null;
		ModuleDBI apmDBI = null;
		
		try {
			apmDBI = new ModuleDBI();
			//joAPMModule = apmDBI.getAPMModules1(con, loginBean, strModuleType, strLimit, strOffset);
			joAPMCardDatas = apmDBI.getAPMModules01(con, loginBean, strModuleType, strLimit, strOffset, joEnt);
			joAPMModule.put("moduleData", joAPMCardDatas);
			if(strModuleType.equalsIgnoreCase("'RUM'")){
				joRUMCardStatus = apmDBI.getRUMCardStatus(con, loginBean, joEnt);
				joAPMModule.put("moduleRUMStatus", joRUMCardStatus);
			} else if(strModuleType != "'LOG'") {
				joAPMCardStatus = apmDBI.getAPMCardStatus(con, loginBean, joEnt);
				joAPMModule.put("moduleStatus", joAPMCardStatus);
			}
			
			
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			apmDBI = null;
		}
		
		return joAPMModule;
		
	}
	public JSONObject getAPMModulesData(Connection con, LoginUserBean loginBean, String strUid) throws Exception {
		JSONObject joAPMModule = null;
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			joAPMModule = apmDBI.getAPMModules2(con, loginBean, strUid);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			apmDBI = null;
		}
		return joAPMModule;
		
	}
	
	public void setAsDefaultInCard(Connection con, LoginUserBean loginBean, String strModuleType) throws Exception {
		
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			apmDBI.setAsDefaultInCard(con, loginBean, strModuleType);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			apmDBI = null;
		}
	}
	
	public void setAsDefaultDashboard(Connection con, LoginUserBean loginBean, String strHealthCode, Long lServiceMapId) throws Exception {
		
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			apmDBI.setAsDefaultDashboard(con, loginBean, strHealthCode, lServiceMapId);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			apmDBI = null;
		}
	}
	
	public JSONObject getLogRunningStatus(Connection con, LoginUserBean loginBean, String strUid) throws Exception {
		JSONObject joAPMModule = null;
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			joAPMModule = apmDBI.getLogRunningStatus(con, loginBean, strUid);
		}catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}finally {
			apmDBI = null;
		}
		return joAPMModule;
		
	}
	
	public JSONObject getSUMModule(Connection con, LoginUserBean loginBean, JSONObject joEnt) throws Exception {
		JSONObject joResult = new JSONObject();
		JSONArray joSUMModule = null;
		ModuleDBI sumDBI = new ModuleDBI();
		try {
			joSUMModule = sumDBI.getSUMModules(con, loginBean, joEnt);
			joResult.put("moduleData", joSUMModule);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			sumDBI = null;
		}
		//return joSUMModule;
		
		return joResult;
	}
	
	public JSONObject getEnterpriseModule(Connection con, LoginUserBean loginBean) throws Exception {
		JSONObject joResult = new JSONObject();
		JSONArray joSUMModule = null;
		ModuleDBI sumDBI = new ModuleDBI();
		try {
			joSUMModule = sumDBI.getEnterpriseModules(con, loginBean);
			joResult.put("moduleData", joSUMModule);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			sumDBI = null;
		}
		//return joSUMModule;
		
		return joResult;
	}
	
	public JSONObject getEditSUMModules(Connection con, long testid) throws Exception {
		JSONArray joEditSUMModule = null;
		JSONObject joResult = new JSONObject();
		ModuleDBI sumDBI = new ModuleDBI();
		try {
			//joEditSUMModule = sumDBI.getEditSUMModules(con, testid);
			//joResult.put("moduleData", joEditSUMModule);
			
			joResult = sumDBI.getEditSUMModules(con, testid);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			sumDBI = null;
		}
		
		return joResult;
	}
	/**
	 * Insert module into table `module_master` for APPLICATION/SERVER/DATABASE
	 * Creates table partitions for respective added module's counterType/agent, 
	 *   say counter_master_<uid>, collector_<uid> and respective profiler partitions table
	 * 
	 * @param con
	 * @param moduleBean
	 * @param apmLicenseBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long insertAPMModuleAndCreateUidTablePartitions(Connection con, ModuleBean moduleBean, APMLicenseBean apmLicenseBean, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception {
		ModuleDBI modulesDBI = null;

		long lModuleId = -1L;
		// total modules default `0`, since `-1` means user can add with no limits 
		long lTotalUserModulesCount = 0;
		
		try {
			modulesDBI = new ModuleDBI();
			
//			As per appedo pricing agents are unlimited. (Might be used in future)
			
			if(apmLicenseBean == null) {
				// License expired for user
				throw new Exception("1");
			} else {
				// gets user added total no. of modules in APPLICATION/SERVER/DATABASE 
				lTotalUserModulesCount = getUserAddedModulesCount(con, Constants.APM_GROUP, loginUserBean);
				
				// As per appedo pricing agents are unlimited.
				// max Agents means for Max modules added in APPLICATION/SERVER/DATABASE 
				if( apmLicenseBean.getMaxAgents() <= lTotalUserModulesCount && apmLicenseBean.getMaxAgents() != -1 ) {
					// User max modules count exceeds
					throw new Exception("2");
				} else {

					boolean bExist = modulesDBI.isModuleExist(con, moduleBean, loginUserBean);
					if (bExist) {
						// Unable to add. Module Name already exists.
						throw new Exception("3");
					} else {
						// Inserts
						lModuleId = modulesDBI.insertModule(con, moduleBean, loginUserBean, joEnterprise);
						moduleBean.setModuleId(lModuleId);
					
						// creates counter and collector tables for `APPLICATION/SERVER/DATABASE` moduleType 
						modulesDBI.createModuleCounterTablePartitions(con, lModuleId, moduleBean, loginUserBean);
					}
				}
			}

			modulesDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lModuleId;
	}
	
	public void insertChartVisualData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, Long lModuleId) throws Exception {
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			// Inserts
			modulesDBI.insertChartVisualData(con, moduleBean, loginUserBean, UtilsFactory.generateOADChartQuery(lModuleId));
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	public void insertChartVisualizationData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, Long lModuleId) throws Exception {
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			// Inserts
			modulesDBI.insertChartVisualizationData(con, moduleBean, loginUserBean, UtilsFactory.generateOADChartVisualizerQuery(lModuleId));
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	public void insertChartVisualDataRUM(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, Long lModuleId) throws Exception {
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			// Inserts
			modulesDBI.insertChartVisualDataRUM(con, moduleBean, loginUserBean, UtilsFactory.generateRUMChartQuery(loginUserBean.getUserId(), lModuleId));
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	//generateRUMChartVisualizationQuery
	
	public void insertChartVisualizationDataRUM(Connection con, LoginUserBean loginUserBean, Long lModuleId) throws Exception {
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			// Inserts
			//modulesDBI.insertChartVisualizationDataRUM(con, moduleBean, loginUserBean, UtilsFactory.generateRUMChartVisualizationQuery(loginUserBean.getUserId(), lModuleId));
			modulesDBI.insertChartVisualizationDataRUM(con, lModuleId, loginUserBean);
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	/**
	 * Insert module into table `module_master` for RUM
	 * Creates table partitions for RUM & CI
	 * `RUM` module used for both RUM & CI
	 * 
	 * @param con
	 * @param moduleBean
	 * @param rumLicenseBean
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long insertRUMModuleAndCreateUidTablePartitions(Connection con, ModuleBean moduleBean, RUMLicenseBean rumLicenseBean, LoginUserBean loginUserBean, JSONObject joEnterprise) throws Exception {
		ModuleDBI modulesDBI = null;
		
		long lModuleId = -1L;
		// total modules default `0`, since `-1` means user can add with no limits 
		long lTotalUserModulesCount = 0;
		
		try {
			modulesDBI = new ModuleDBI();
			
//			As per appedo pricing agents are unlimited ( Might be used in future)
//			if(rumLicenseBean == null) {
//				// License expired for user
//				throw new Exception("1");
//			} else {
//				// gets user added total no. of modules, moduleBean.getModuleType() must be equals to RUM
//				lTotalUserModulesCount = getUserAddedModulesCount(con, "\'RUM\'", loginUserBean);
//				
//				// max RUMTests means for Max modules added in `RUM` moduleType
//				if( ! (rumLicenseBean.getMaxRUMTests() > lTotalUserModulesCount) && rumLicenseBean.getMaxRUMTests() != -1 ) {
//					// User max modules count exceeds
//					throw new Exception("2");
//				} else {
					boolean bExist = modulesDBI.isModuleExist(con, moduleBean, loginUserBean);
					if (bExist) {
						// Unable to add. Module Name already exists.
						throw new Exception("3");
					} else {
						// inserts
						lModuleId = modulesDBI.insertModule(con, moduleBean, loginUserBean, joEnterprise);
						moduleBean.setModuleId(lModuleId);
						
						// create collector table for RUM module
						modulesDBI.createRUMCollectorTablePartitions(con, lModuleId);
						
						// create collector table for CI module
						modulesDBI.createCICollectorTablePartitions(con, lModuleId);
					}
//				}
//			}
			
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lModuleId;
	}
	
	/**
	 * Getting available modules based on module type
	 * @param con
	 * @param strModuleType
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModules(Connection con, String strModuleType, String strLimit, String strOffset, LoginUserBean loginUserBean) throws Exception {

		ModuleDBI modulesDBI = null;
		
		JSONObject joRtnModules = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			joRtnModules = modulesDBI.getModules(con, strModuleType, strLimit, strOffset, loginUserBean);
			
			modulesDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} 
		
		return joRtnModules;
	}
	
	public void updateEnterpriseModule(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception {
		
		ModuleDBI modulesDBI = null;
		try {
			modulesDBI = new ModuleDBI();
			boolean bEnterpriseExists = modulesDBI.isEntNameExist(con, moduleBean.getModuleName(), moduleBean.getModuleId());
			if (bEnterpriseExists) {
				// Unable to update. Module Name already exists.
				throw new Exception("1");
			} else {
				//moduleBean.setOldModuleName(modulesDBI.getOldModuleName(con, moduleBean.getModuleId()));
				modulesDBI.updateModule(con, moduleBean, loginUserBean);
			}
			
			modulesDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} 
	}
	
	
	public void updateModule(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean) throws Exception {
		
		ModuleDBI modulesDBI = null;
		try {
			modulesDBI = new ModuleDBI();
			boolean bExist = modulesDBI.isModuleExist(con, moduleBean, loginUserBean, true);
			if (bExist) {
				// Unable to update. Module Name already exists.
				throw new Exception("1");
			} else {
				moduleBean.setOldModuleName(modulesDBI.getOldModuleName(con, moduleBean.getModuleId()));
				modulesDBI.updateModule(con, moduleBean, loginUserBean);
				//update chart_visual data
				//modulesDBI.updateChartVisualModuleData(con, moduleBean, loginUserBean);
				if (moduleBean.getModuleType().equals(Constants.RUM_MODULE) || moduleBean.getModuleType().equals(Constants.LOG_MODULE)) {
					modulesDBI.updateChartVisualizationData(con, moduleBean, loginUserBean);
				} else {
					modulesDBI.updateChartVisualizationOADData(con, moduleBean, loginUserBean);
				}
				
			}
			
			modulesDBI = null;
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} 
	}
	
	/**
	 * Gets available agent for the module type 
	 * 
	 * @param con
	 * @param strModuleName
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleTypeAgents(Connection con, String strModuleName)throws Exception {
		JSONArray jaAgents = null;
		ModuleDBI modulesDBI = null;
		try {
			modulesDBI = new ModuleDBI();
			
			jaAgents = modulesDBI.getModuleAgents(con, strModuleName);
			
			modulesDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaAgents;
	}
	
	/**
	 * Gets agent status whether running or not
	 * 
	 * @param con
	 * @param strguid
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getModuleAgentStatus(Connection con, String strGUIDs, LoginUserBean loginUserBean) throws Exception {
		
		ModuleDBI modulesDBI = null;
		JSONObject joStatus = null;
		try{
			modulesDBI = new ModuleDBI();
			joStatus = modulesDBI.getModuleAgentStatus(con, strGUIDs.split(","), loginUserBean);
		}catch(Exception e){
			LogManager.errorLog(e);
		}
		return joStatus;
	}
	
//	/**
//	 * Updates module details
//	 * 
//	 * @param con
//	 * @param moduleBean
//	 * @param loginUserBean
//	 * @throws Exception
//	 */
//	public void updateModule(Connection con, ModuleBean moduleBean,  String strCounterIds, LoginUserBean loginUserBean) throws Exception {
//		APMLicenseBean apmLicenseBean = null;
//		RUMLicenseBean rumLicenseBean = null;
//		
//		try {
//			
//			// Note user defined Exceptions thrown in below methods for APM and RUM, handled both exceptions means same meaning,
//			if( ! moduleBean.getModuleType().equals("RUM") ){
//				// for APPLICATION/SERVER/DATABASE
//				
//				// gets license details from `userwise_lic_monthwise` and `apm_config_param` tables
//				apmLicenseBean = getAPMUserLicenseDetails(con, loginUserBean);
//				
//				// for Application/Server/Database
//				updateAPMModuleAndCounters(con, moduleBean, apmLicenseBean, strCounterIds, loginUserBean);
//			} else {
//				// for RUM
//				
//				// gets license details from `userwise_lic_monthwise` and `rum_config_param` tables
//				rumLicenseBean = getRUMUserLicenseDetails(con, loginUserBean);
//
//				// for RUM
//				updateRUMModule(con, moduleBean, rumLicenseBean, loginUserBean);
//			}
//			
//		} catch(Exception e) {
//			LogManager.errorLog(e);
//			throw e;
//		}
//	}
	
//	/**
//	 * Update module `APPLICATION/SERVER/DATABASE` 
//	 * updates selected counters
//	 * 
//	 * @param con
//	 * @param moduleBean
//	 * @param apmLicenseBean
//	 * @param strModuleCounters
//	 * @param loginUserBean
//	 * @throws Exception
//	 */
//	public void updateAPMModuleAndCounters(Connection con, ModuleBean moduleBean, APMLicenseBean apmLicenseBean, String strCounterIds, LoginUserBean loginUserBean) throws Exception {
//		ModuleDBI modulesDBI = null;
//		CounterManager counterManager = null;
//
//		//JSONObject joModuleCounter = null;
//		JSONArray jaSelectedMasterCounters = null;;
//
//		HttpClient client = null;
//		PostMethod method = null;
//
//		//int nTotalCounters = 0;
//		
//		String[] saCounterIds = null;
//		
//		try {
//			modulesDBI = new ModuleDBI();
//			counterManager = new CounterManager();
//
//			if(apmLicenseBean == null) {
//				// License expired for user
//				throw new Exception("1");
//			} else {
//				boolean bExist = modulesDBI.isModuleExist(con, moduleBean, loginUserBean, true);
//
//				if(bExist){
//					// Unable to update. Name already exist.
//					throw new Exception("2");
//				} else {
//					modulesDBI.updateModule(con, moduleBean, loginUserBean);
//					
//					// 
//					saCounterIds = strCounterIds.split(",");
//
//					// Validation max counters selected by user wheather exceeds limit for user's license
//					if( ! (apmLicenseBean.getMaxCounters() >= saCounterIds.length) && apmLicenseBean.getMaxCounters() != -1 ) {
//						// max counters exceeds 
//						throw new Exception("3");
//					} else {
//						// updates selected counters
//						updateCounters(con, strCounterIds, moduleBean.getModuleId(), loginUserBean);
//						
//						
//						/*
//						// Validation max counters selected by user
//						jaModuleCounters = JSONArray.fromObject(strModuleCounters);
//						for (int i = 0; i < jaModuleCounters.size(); i++) {
//							joModuleCounter = jaModuleCounters.getJSONObject(i);
//							
//							if( joModuleCounter.getBoolean("isSelected") ) {
//								nTotalCounters = nTotalCounters + 1;
//								
//								if( ! (apmLicenseBean.getMaxCounters() >= nTotalCounters) && apmLicenseBean.getMaxCounters() != -1) {
//									// max counters exceeds 
//									throw new Exception("3");
//								}
//							}
//						}
//						
//						
//						// Update counters for APPLICATION/SERVER/DATABASE module
//						if(strModuleCounters != null) {
//							counterManager.updateCounters(con, jaModuleCounters, (int)moduleBean.getModuleId());
//						}*/
//						
//						jaSelectedMasterCounters = counterManager.getSelectedCounters(con, (int)moduleBean.getModuleId());
//						if(jaSelectedMasterCounters.size()>0)
//						{
//							method = new PostMethod(Constants.APPEDO_COLLECTOR);
//							method.setParameter("guid", moduleBean.getGuid());
//							method.setParameter("CounterSet", jaSelectedMasterCounters.toString());
//							method.setParameter("command", "MonitorCounterSet");
//							client = new HttpClient();
//							int statusCode = client.executeMethod(method);
//							
//							LogManager.infoLog("statusCode:: "+ statusCode);
//						}
//					}
//				}
//			}
//			
//
//			modulesDBI = null;
//			counterManager = null;
//			client = null;
//			saCounterIds = null;
//			
//			UtilsFactory.clearCollectionHieracy(jaSelectedMasterCounters);
//			jaSelectedMasterCounters = null;
//		} catch (Exception e) {
//			LogManager.errorLog(e);
//			throw e;
//		} finally {
//			if( method != null ) {
//				method.releaseConnection();
//				method = null;
//			}
//		}
//	}
	
//	public void updateRUMModule(Connection con, ModuleBean moduleBean, RUMLicenseBean rumLicenseBean, LoginUserBean loginUserBean) throws Exception {
//		ModuleDBI modulesDBI = null;
//		
//		try {
//			modulesDBI = new ModuleDBI();
//			
//
//			if(rumLicenseBean == null) {
//				// License expired for user
//				throw new Exception("1");
//			} else {
//				boolean bExist = modulesDBI.isModuleExist(con, moduleBean, loginUserBean, true);
//
//				if(bExist){
//					// Unable to update. Name already exist.
//					throw new Exception("2");
//				} else {
//					modulesDBI.updateModule(con, moduleBean, loginUserBean);
//				}
//			}
//		} catch (Exception e) {
//			LogManager.errorLog(e);
//			throw e;
//		}
//	}
	
	/**
	 * Deleting module (Physical delete)
	 * 
	 * @param con
	 * @param applicationBean
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteModule(Connection con, long lModuleId, String strGUID, String strModuleType, LoginUserBean loginUserBean, long lEID) throws Exception {
		ModuleDBI modulesDBI = null;

		ServiceDBI serviceDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			serviceDBI = new ServiceDBI();

			// drop user view
			dropAllModuleLastCounterView(con, loginUserBean.getUserId());
			
			// deletes the module's which is mapped from service map(s)
			serviceDBI.deleteMappedModuleReferences(con, strModuleType, lModuleId, loginUserBean.getUserId());
			
			// drops partitions tables
			if(strModuleType.equals("LOG")) {
				//delete log table's
				modulesDBI.dropLogsTables(con, lModuleId);
				
			}else if( ! strModuleType.equals("RUM")) {
				// delete the ASD/GUID's SLA(s)
				deleteASDSLAs(strGUID, loginUserBean);
				// drops APPLICATION/SERVER/DATABASE module type collector and counter tables
				modulesDBI.deleteModuleCounterTablePartitions(con, lModuleId, loginUserBean.getUserId());

			}else {
				// deletes RUM uid's SLA refrences 
				deleteRUMSLA(lModuleId, loginUserBean);
				
				// drops RUM module collector table
				modulesDBI.dropRUMCollectorTablePartitions(con, lModuleId, loginUserBean.getUserId());
				
				// drop CI module collector tables
				modulesDBI.dropCICollectorTablePartitions(con, lModuleId, loginUserBean.getUserId());
			}
			// To delete chart Visual data
			//modulesDBI.deleteChartVisualData(con, lModuleId, loginUserBean.getUserId(), strModuleType);
			modulesDBI.deleteChartVisualizationData(con, lModuleId, loginUserBean.getUserId(), strModuleType);
			
			//delete my chart data
			modulesDBI.removeMyChart(con, loginUserBean.getUserId(), lEID, lModuleId, strModuleType);
			
			// deletes the module from `module_master`		
			modulesDBI.deleteModule(con, lModuleId, loginUserBean.getUserId());
						
			if(! strModuleType.equals("LOG")) {
				// Delete My Chart details table for that module id
				modulesDBI.deleteMyChartDetails(con, lModuleId, loginUserBean.getUserId());	

				// create user view
				createAllModuleLastCounterView(con, loginUserBean.getUserId());
			}
			
			modulesDBI = null;
			serviceDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	/**
	 * deletes SLA(s) which are mapped with the GUID,
	 * disable SLA(s) which has the GUID of delete and another GUID mapped
	 * 
	 * @param strGUID
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void deleteASDSLAs(String strGUID, LoginUserBean loginUserBean) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			wsm.addParameter("guid", strGUID);
			
			// web service request
			//wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES+"/sla/deleteASDSLAs");
			wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES+"/sla/deleteASDSLAs");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());
				
				// set the response, gets in Contoller
				setDeletedGUIDSLAs(joResp);
			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
				LogManager.infoLog("GUID's SLA(s) are delete, other than the SLA(s) has the `strGUID` & different GUID(s)");
			} else {
				// exception in SLA
				throw new Exception("Unable to delete mapped SLA(s).");
			}
		} catch (Exception e) {
			throw e;
		}
	}
	

	public void deleteRUMSLA(long lUId, LoginUserBean loginUserBean) throws Exception {
		WebServiceManager wsm = null;
		
		JSONObject joResp = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("login_user_bean", loginUserBean.toJSON());
			wsm.addParameter("uid", lUId+"");
			
			// web service request
			//wsm.sendRequest(Constants.APPEDO_UI_SLA_SERVICES+"/sla/deleteRUMSLA");
			wsm.sendRequest(Constants.APPEDO_UI_MODULE_SERVICES+"/sla/deleteRUMSLA");
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				// success
				joResp = JSONObject.fromObject(wsm.getResponse());
			} else {
				throw new Exception("Problem with SLA Services");
			}
			
			// web service response
			if( joResp.getBoolean("success") ) {
				// success
				LogManager.infoLog("RUM module's SLA refrences are deleted.");
			} else {
				// exception in SLA
				throw new Exception("Unable to delete mapped SLA(s).");
			}
		} catch (Exception e) {
			throw e;
		}
	}
	
	
	/**
	 * Gets dashboard chart for the particular module type guid 
	 * 
	 * @param con
	 * @param strGUID
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleTypeDashboardCharts(Connection con, String strGUID, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;
		JSONArray jaRtnModulesCharts = null;
		
		try {
			modulesDBI = new ModuleDBI();
			jaRtnModulesCharts = modulesDBI.getModuleTypeDashboardCharts(con, strGUID, loginUserBean);
			modulesDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaRtnModulesCharts;
	}
	
	/**
	 * gets chart template for the counter type, say Tomcat, 
	 * 
	 * @param con
	 * @param lUID
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getTemplateCounterTypeCharts(Connection con, long lUID, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;

		Statement stmtCounterType = null;
		ResultSet rstCounterType = null;
		
		JSONObject joCounterType = new JSONObject();
		
		LinkedHashMap<String, LinkedHashMap> lhmCounterType = new LinkedHashMap<String, LinkedHashMap>();
		LinkedHashMap<String, Object> lhmCounterTypeContents = new LinkedHashMap<>();

		ArrayList<Object> alCTTabs = null;
		LinkedHashMap<String, LinkedHashMap> lhmCTTabs = new LinkedHashMap<String, LinkedHashMap>();
		LinkedHashMap<String, Object> lhmCTTabContents = null;
		//JSONObject joTabContents = null;
		JSONArray jaTabs = new JSONArray();
		
		ArrayList<Object> alCTTabCharts = null;
		JSONObject joChartContents = null;
		
		// CounterTypeName is agent name, say Tomcat, MSIIS; category is tabName, say Web Activity, Memory;
		String strCounterTypeName = "", strCategory = "";
		
		try {
			modulesDBI = new ModuleDBI();

			// tried, created for chart req., chart config options, empty data for to be informat [[]]
			ArrayList<ArrayList> alCounterValues = new ArrayList<ArrayList>(1);
			ArrayList alData = new ArrayList(0);
			alCounterValues.add(alData);
			
			// default for the agent
			lhmCounterTypeContents = new LinkedHashMap<String, Object>();
			lhmCounterTypeContents.put("showTab", false);
			// TODO: minichart
			lhmCounterTypeContents.put("minicharts", "");
			lhmCounterTypeContents.put("tabs", "");
			
			// 
			rstCounterType = modulesDBI.getTemplateCounterTypeCharts(con, lUID, loginUserBean);
			stmtCounterType = rstCounterType.getStatement();
			
			// TODO: Below logic has to change, to form template for multiple counters. 
			
			while(rstCounterType.next()) {
				strCounterTypeName = rstCounterType.getString("counter_type_name").toUpperCase();
				strCategory = rstCounterType.getString("category");
				
				// chart config
				joChartContents = new JSONObject();
				//joChartContents.put("counterCode", rst.getString("counter_name"));
				joChartContents.put("counterCode", rstCounterType.getString("counter_id"));
				joChartContents.put("displayName", rstCounterType.getString("counter_name"));
				joChartContents.put("counterId", rstCounterType.getLong("counter_id"));
				joChartContents.put("uid", lUID);
				joChartContents.put("chartData", alCounterValues);
				joChartContents.put("maxTimeStamp", null);
				//joChartContents.put("maxTimeStamp", "");
				joChartContents.put("exception", "");
				// TODO: chart units and color from DB
				//joChartContents.put("color", "[\"#31C0BE\"]");
				//joChartContents.put("valueType", "MB");
				joChartContents.put("open", true);
				joChartContents.put("showDashboardSwitch", false);
				joChartContents.put("hasDashboard", false);
				
				if( lhmCTTabs.containsKey(strCategory) ) {
					lhmCTTabContents = lhmCTTabs.get(strCategory);
					alCTTabCharts = (ArrayList) lhmCTTabContents.get("charts");
					alCTTabCharts.add(joChartContents);
				} else {
					alCTTabCharts = new ArrayList<Object>();
					
					lhmCTTabContents = new LinkedHashMap<>();
					lhmCTTabContents.put("tabName", strCategory);
					lhmCTTabContents.put("activeTab", false);
					
					// added chart content 
					alCTTabCharts.add(joChartContents);
				}
				lhmCTTabContents.put("charts", alCTTabCharts);
				lhmCTTabs.put(strCategory, lhmCTTabContents);
			}
			/*
			 * since for the single counter type, say Tomcat, 
			 *  a tab's respective chart contents were formed above
			 */
			Iterator it = lhmCTTabs.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, LinkedHashMap> pairs = (Map.Entry)it.next();
				//
				lhmCTTabContents = pairs.getValue();
				
				jaTabs.add(lhmCTTabContents);
			}
			lhmCounterTypeContents.put("tabs", jaTabs);
			
			lhmCounterType.put(strCounterTypeName, lhmCounterTypeContents);
			
			joCounterType.accumulateAll(lhmCounterType);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} finally {
			DataBaseManager.close(rstCounterType);
			rstCounterType = null;
			DataBaseManager.close(stmtCounterType);
			stmtCounterType = null;
		}
		
		return joCounterType;
	}
	
	
	/**
	 * gets all available agents from different modules Application/Server/Database
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getAllAgents(Connection con) throws Exception {
		JSONArray jaAgents = null;
		
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			jaAgents = modulesDBI.getAllAgents(con);
			
		} catch (Exception e) {
			
			throw e;
		}
		
		return jaAgents;
	}
	
	/**
	 * Gets module details for the given moduleCode(Application/Server/Database) 
	 * 
	 * @param con
	 * @param strModuleCode
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONArray getUserModuleDetails(Connection con, String strModuleCode, int nCounterTypeVersionId, LoginUserBean loginUserBean) throws Exception {
		JSONArray jaModuleDetails = null;
		
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			jaModuleDetails = modulesDBI.getUserModuleDetails(con, strModuleCode, nCounterTypeVersionId, loginUserBean);
			
		} catch (Exception e) {
			System.out.println("Exception in getUserModuleDetails: "+e.getMessage());
			throw e;
		}
		
		return jaModuleDetails;
	}
	
	
	public JSONObject getUserUIDCategoryWiseCounters(Connection con, String strUId, LoginUserBean loginUserBean) throws Exception {
		JSONObject joCategoryWiseCounters = null;
		
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			joCategoryWiseCounters = modulesDBI.getUserUIDCategoryWiseCounters(con, strUId, loginUserBean);
			
		} catch (Exception e) {
			System.out.println("Exception in getUserModuleCountersDetails: "+e.getMessage());
			throw e;
		}
		
		return joCategoryWiseCounters;
	}

	public JSONArray getModuleCounterTypes(Connection con, String strModuleName) throws Exception {
		JSONArray jaModuleCounterTypes = null;

		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			jaModuleCounterTypes = modulesDBI.getModuleCounterTypes(con, strModuleName);
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaModuleCounterTypes;
	}
	

	public JSONArray getModuleCounterTypeVersions(Connection con, int nCounterTypeId) throws Exception {
		JSONArray jaModuleCounterTypes = null;

		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			jaModuleCounterTypes = modulesDBI.getModuleCounterTypeVersions(con, nCounterTypeId);
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaModuleCounterTypes;
	}

	/**
	 * gets execution types for SLA action from lookups
	 * 
	 * @param con
	 * @return
	 * @throws Exception
	 */
	public JSONArray getExecutionTypes(Connection con) throws Exception {
		JSONArray jaExecutionTypes = null;

		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			jaExecutionTypes = modulesDBI.getExecutionTypes(con);
			
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return jaExecutionTypes;
	}
	
	/**
	 * gets agent download files for a agent, say Tomcat, etc.,
	 * 
	 * @param con
	 * @param strCounterTypeName
	 * @return
	 * @throws Exception
	 */
	public LinkedHashMap<String, String> getAgentDownloadFilePath(Connection con, String strCounterTypeName) throws Exception {
		ModuleDBI modulesDBI = null;
		
		LinkedHashMap<String, String> lhmAgentFiles = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			lhmAgentFiles = modulesDBI.getAgentDownloadFilePath(con, strCounterTypeName);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lhmAgentFiles;
	}
	
	public JSONObject getModule(Connection con, long lUID) throws Exception {
		ModuleDBI modulesDBI = null;
		
		JSONObject joModule = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			joModule = modulesDBI.getModule(con, lUID);
			
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} 
		
		return joModule;
	}
	
	public JSONArray getDashboardModuleData(Connection con, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;
		
		JSONArray jaModules = null;
		try {
			modulesDBI = new ModuleDBI();
			
			jaModules = modulesDBI.getDashboardModuleData(con, loginUserBean);
			
			modulesDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		} 
		
		return jaModules;
	}
	
	public boolean isSLAConfigured(Connection con, String strGUID, String strCounterId) throws Exception {
		
		ModuleDBI modulesDBI = null;
		boolean bExist = false;
		try{
			
			modulesDBI = new ModuleDBI();
			bExist = modulesDBI.isSLAConfigured(con, strGUID, Long.parseLong(strCounterId));
			
			modulesDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}
		return bExist;
	}
	

	
	/**
	 * gets user added total no. of modules
	 * 
	 * @param con
	 * @param strModuleName
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public long getUserAddedModulesCount(Connection con, String strModuleName, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;
		
		// total modules default `0`, since `-1` means user can add with no limits 
		long lTotalUserModulesCount = 0;
				
		try {
			modulesDBI = new ModuleDBI();
			
			lTotalUserModulesCount = modulesDBI.getUserAddedModulesCount(con, strModuleName, loginUserBean);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lTotalUserModulesCount;
	}
	
	public long getUserAddedCounterTypeCountersCount(Connection con, long lUID, int nCounterTypeId, LoginUserBean loginUserBean) throws Exception {
		long lTotalUserCounterTypeCounters = -1;

		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			lTotalUserCounterTypeCounters = modulesDBI.getUserAddedCounterTypeCountersCount(con, lUID, nCounterTypeId, loginUserBean);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return lTotalUserCounterTypeCounters;
	}
	

	public RUMLicenseBean getRUMUserLicenseDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;

		RUMLicenseBean rumLicenseBean = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			// gets license details from month wise table
			rumLicenseBean = modulesDBI.getRUMUserWiseLicenseMonthWise(con, loginUserBean);
			
			if(rumLicenseBean != null) {
				// get license details from `rum config parameters`
				RUMLicenseBean rumLicenseBeanConfigParams = modulesDBI.getRUMLicenseConfigParameters(con, loginUserBean);

				rumLicenseBean.setLicInternalName(rumLicenseBeanConfigParams.getLicInternalName());
				rumLicenseBean.setLicExternalName(rumLicenseBeanConfigParams.getLicExternalName());
				rumLicenseBean.setMaxRUMTests(rumLicenseBeanConfigParams.getMaxRUMTests());
				rumLicenseBean.setReportRetentionInDays(rumLicenseBeanConfigParams.getReportRetentionInDays());
			}
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return rumLicenseBean;
	}
	
	/**
	 * Updates selected counters for the user
	 * 
	 * @param con
	 * @param strCounterIds
	 * @param lUId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateCounters(Connection con, String strCounterIds, long lUId, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			modulesDBI.updateCounters(con, strCounterIds, lUId, loginUserBean);;
			
			modulesDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	public void updateChartData(Connection con, ModuleBean moduleBean, LoginUserBean loginUserBean, String strCounterIds) throws Exception {
		ModuleDBI modulesDBI = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			modulesDBI.updateChartData(con, moduleBean, loginUserBean, strCounterIds);
			
			modulesDBI = null;
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	/**
	 * gets user deep dive license details
	 * @param con
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public DDLicenseBean getDDUserLicenseDetails(Connection con, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;

		DDLicenseBean ddLicenseBean = null;
		
		try {
			modulesDBI = new ModuleDBI();
			
			// gets license details from month wise table
			ddLicenseBean = modulesDBI.getDDUserWiseLicenseMonthWise(con, loginUserBean);
			
			if(ddLicenseBean != null) {
				// get license details from `dd config params`
				DDLicenseBean ddLicenseBeanConfigParams = modulesDBI.getDDLicenseConfigParameters(con, loginUserBean);

				ddLicenseBean.setLicInternalName(ddLicenseBeanConfigParams.getLicInternalName());
				ddLicenseBean.setLicExternalName(ddLicenseBeanConfigParams.getLicExternalName());
				ddLicenseBean.setEnableApplicationResponseTime(ddLicenseBeanConfigParams.isEnableApplicationResponseTime());
				ddLicenseBean.setEnableDotNetProfiling(ddLicenseBeanConfigParams.isEnableDotNetProfiling());
				ddLicenseBean.setEnableJavaProfiling(ddLicenseBeanConfigParams.isEnableJavaProfiling());
				ddLicenseBean.setEnableMostTimeConsumingTrans(ddLicenseBeanConfigParams.isEnableMostTimeConsumingTrans());
				ddLicenseBean.setEnablePerformanceOfExtServices(ddLicenseBeanConfigParams.isEnablePerformanceOfExtServices());
				ddLicenseBean.setEnableSlowQuery(ddLicenseBeanConfigParams.isEnableSlowQuery());
				ddLicenseBean.setEnableStackTrace(ddLicenseBeanConfigParams.isEnableStackTrace());
				ddLicenseBean.setEnableTraceTransaction(ddLicenseBeanConfigParams.isEnableTraceTransaction());
				ddLicenseBean.setEnableTransBreakdown(ddLicenseBeanConfigParams.isEnableTransBreakdown());
			}
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return ddLicenseBean;
	}
	
	public boolean isProfilerEnabled(Connection con, String strGUID, int nMaxProfiler, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI modulesDBI = null;
		
		boolean bProfilerEnabled = false;

		try {
			modulesDBI = new ModuleDBI();
			
			bProfilerEnabled = modulesDBI.isProfilerEnabled(con, strGUID, nMaxProfiler, loginUserBean);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		
		return bProfilerEnabled;
	}
	
	/**
	 * Getting 
	 * @param con
	 * @param strModuleType versions
	 * @return
	 * @throws Exception
	 */
	public JSONArray getModuleTypeVersions(Connection con, String strModuleType) throws Exception {
		
		ModuleDBI moduleDBI = null;
		JSONArray jaModuleTypeVersions = null;
		try {
			moduleDBI = new ModuleDBI();
			
			jaModuleTypeVersions = moduleDBI.getModuleTypeVersions(con, strModuleType);
			
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return jaModuleTypeVersions;
	}

	public JSONArray getMapUsers(Connection con, Integer e_Id, long lUser_id) throws Exception {
		JSONArray jaMapUsers = null;
		ModuleDBI moduleDBI = null;
		try{
			moduleDBI = new ModuleDBI();
			jaMapUsers = moduleDBI.getMapUsers(con, e_Id, lUser_id);
			moduleDBI = null;
		}catch(Exception e){
			throw e;
		}
		return jaMapUsers;
	}
	
	public void deleteMapUser(Connection con, Integer e_Id, String strUserName) throws Exception {
		ModuleDBI moduleDBI = null;
		
		try {
			moduleDBI = new ModuleDBI();
			
			moduleDBI.deleteMapUser(con, e_Id, strUserName);
						
			moduleDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	public void deleteEnterprise(Connection con, Integer e_Id) throws Exception {
		ModuleDBI moduleDBI = null;
		
		try {
			moduleDBI = new ModuleDBI();
			
			moduleDBI.deleteEnterprise(con, e_Id);
						
			moduleDBI = null;
		} catch(Exception e) {
			throw e;
		}
	}
	
	public boolean isValidEnterpriseName(Connection con, String strEnterpriseName) throws Exception {
		ModuleDBI moduleDBI = null;
		boolean bEnterpriseExists = false;
		
		try {
			moduleDBI = new ModuleDBI();
			
			// as new insert checks user's policy already exists, "-1" hardcoding since its a new insert
			bEnterpriseExists = moduleDBI.isEnterpriseNameExist(con, strEnterpriseName);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return bEnterpriseExists;
	}
	
	public JSONArray getAppDropDown(Connection con, long lUserId, String strModuleName) throws Exception {
		JSONArray jaModules = null;
		ModuleDBI modulesDBI = null;
		try {
			modulesDBI = new ModuleDBI();
			jaModules = modulesDBI.getAppDropDown(con, lUserId, strModuleName);
		} catch (Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
		return jaModules;
	}
	
	/**
	 * gets all ASD modules active agents
	 * 
	 * @param con
	 * @param lUserId
	 * @return
	 * @throws Exception
	 */
	public JSONObject getAllASDModulesActiveAgents(Connection con, long lUserId) throws Exception {
		ModuleDBI moduleDBI = null;
		
		JSONObject joModuleTypesActiveAgents = null;
		
		try {
			moduleDBI = new ModuleDBI();
			
			joModuleTypesActiveAgents = moduleDBI.getAllASDModulesActiveAgents(con, lUserId);
			
			moduleDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joModuleTypesActiveAgents;
	}
	
    public JSONArray getAppSummary(Connection con, long lUserId, String strModuleName) throws Exception {
        JSONArray jaModules = null;
        ModuleDBI modulesDBI = null;
        try {
                modulesDBI = new ModuleDBI();
                jaModules = modulesDBI.getAppSummary(con, lUserId, strModuleName);
        } catch (Exception e) {
                LogManager.errorLog(e);
                throw e;
        }finally{
        	modulesDBI = null;
        }
        return jaModules;
    }

    public JSONArray getAppLicense(Connection con, long lUserId) throws Exception {
        JSONArray jaModules = null;
        ModuleDBI modulesDBI = null;
        try {
                modulesDBI = new ModuleDBI();
                jaModules = modulesDBI.getAppLicense(con, lUserId);
        } catch (Exception e) {
                LogManager.errorLog(e);
                throw e;
        }finally{
        	modulesDBI = null;
        }
        return jaModules;
    }
    
    public JSONArray getCategories(Connection con, long uid) throws Exception {
        JSONArray jaModules = null;
        ModuleDBI modulesDBI = null;
        try {
                modulesDBI = new ModuleDBI();
                jaModules = modulesDBI.getCategories(con, uid);
        } catch (Exception e) {
                LogManager.errorLog(e);
                throw e;
        }
        return jaModules;
    }
    
    public JSONArray getAgentAllCategoryWiseCounters(Connection con, long lUId, String strAgentVersion) throws Exception {
        JSONArray jaCategoriesCounters = null;
        JSONObject joCategoryCounters = null;
        
        LinkedHashMap<String, ArrayList<JSONObject>> hmCategoryWiseCouters = null;
        ArrayList<JSONObject> alCounters = null;
        Iterator<Map.Entry<String, ArrayList<JSONObject>>> itCategoryWiseCouters = null;
        
        String strCategory = "";
        
        ModuleDBI moduleDBI = null;
        
    	try {
            jaCategoriesCounters = new JSONArray();
            moduleDBI = new ModuleDBI();
            
            hmCategoryWiseCouters = moduleDBI.getAgentAllCategoryWiseCounters(con, lUId, strAgentVersion);
            
            itCategoryWiseCouters = hmCategoryWiseCouters.entrySet().iterator();
            while( itCategoryWiseCouters.hasNext() ) {
            	Map.Entry<String, ArrayList<JSONObject>> pairs = (Map.Entry<String, ArrayList<JSONObject>>) itCategoryWiseCouters.next();
            	
            	strCategory = pairs.getKey();
            	alCounters = pairs.getValue();
            	
            	joCategoryCounters = new JSONObject();
            	joCategoryCounters.put("category", strCategory);
            	joCategoryCounters.put("counters", alCounters);
            	jaCategoriesCounters.add(joCategoryCounters);
            	
            	UtilsFactory.clearCollectionHieracy(alCounters);
            	alCounters = null;
            }
            
            moduleDBI = null;
		} catch (Exception e) {
            throw e;
		} finally {
        	UtilsFactory.clearCollectionHieracy(hmCategoryWiseCouters);
        	hmCategoryWiseCouters = null;
		}
    	
        return jaCategoriesCounters;
    }
    
    /**
	 * Update module `APPLICATION/SERVER/DATABASE` 
	 * updates selected counters
	 * 
	 * @param con
	 * @param moduleBean
	 * @param apmLicenseBean
	 * @param strModuleCounters
	 * @param loginUserBean
	 * @throws Exception
	 */
	public void updateAPMModuleAndCounters(Connection con, ModuleBean moduleBean, APMLicenseBean apmLicenseBean, String strCounterIds, LoginUserBean loginUserBean) throws Exception {
		//JSONObject joModuleCounter = null;
		
		//int nTotalCounters = 0;
		String strCounterName = null;
		String[] saCounterIds = null;
		JSONArray jaMaxCounterIds = null;

		try {
			saCounterIds = strCounterIds.split(",");

			// Validation max counters selected by user wheather exceeds limit for user's license
			if( ! (apmLicenseBean.getMaxCounters() >= saCounterIds.length) && apmLicenseBean.getMaxCounters() != -1 ) {
				// max counters exceeds 
				throw new Exception("3");
			} else {
				// Check whether the counter ids which having the max counter id value is mapped with sla
				jaMaxCounterIds = validateMaxCounterIdMapping(con, strCounterIds, moduleBean.getModuleId(), loginUserBean);

				if (jaMaxCounterIds != null) {
					// Sla is mapped for a counter which has max counter id.
					strCounterName = jaMaxCounterIds.toString().replace("[","").replace("]", "");
					throw new Exception("4", new Exception(strCounterName));
				}

				// updates selected counters
				updateCounters(con, strCounterIds, moduleBean.getModuleId(), loginUserBean);
			}

			saCounterIds = null;
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * update selected counters to Collector,
	 *   collector will update in running agent
	 * 
	 * @param con
	 * @param moduleBean
	 * @throws Exception
	 */
	public void updateSelectedCountersToCollector(Connection con, String strGUID) throws Exception {
		WebServiceManager wsm = null;
		
		try {
			wsm = new WebServiceManager();
			wsm.addParameter("guid", strGUID);
			wsm.addParameter("cn", "");
			wsm.addParameter("command", "updateMonitorCounterSet");
			
			wsm.sendRequest(Constants.APPEDO_COLLECTOR);
			if( wsm.getStatusCode() != null && wsm.getStatusCode() == HttpStatus.SC_OK ) {
				LogManager.infoLog("Selected metrics are sent to Collector; guid: "+strGUID);
			} else {
				LogManager.infoLog("Unable to send selected metrics to Collector; guid: "+strGUID);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if ( wsm != null) {
				wsm.destory();
				wsm = null;
			}
		} 
	}
	
	public JSONArray validateMaxCounterIdMapping(Connection con, String strCounterIds, long lUId, LoginUserBean loginUserBean) throws Exception{
		JSONArray jaMaxCounterIds = null;
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			jaMaxCounterIds = apmDBI.validateMaxCounterIdMapping(con, strCounterIds, lUId, loginUserBean);
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return jaMaxCounterIds;
	}

	public JSONObject getSlowQuery(Connection con, String strFromStartInterval, String strGUID) throws Exception {
		
		JSONObject joRtn = null;
		JSONArray jaSlowQueries = null;
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			jaSlowQueries = moduleDBI.getSlowQuery(con, strFromStartInterval, strGUID);
			joRtn = UtilsFactory.getJSONSuccessReturn(jaSlowQueries);
			jaSlowQueries = null;
			moduleDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
        	moduleDBI = null;
        }
		return joRtn;
	}
	
	public JSONObject getSlowQueryWithDateRange(Connection con, String strFromStartInterval, String strToInterval, String strGUID) throws Exception {
		
		JSONObject joRtn = null;
		JSONArray jaSlowQueries = null;
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			jaSlowQueries = moduleDBI.getSlowQueryWithDateRange(con, strFromStartInterval, strToInterval, strGUID);
			joRtn = UtilsFactory.getJSONSuccessReturn(jaSlowQueries);
			jaSlowQueries = null;
			moduleDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
        	moduleDBI = null;
        }
		return joRtn;
	}
	
    public JSONArray getSecCounter(Connection con, long lUserId, String strModuleCode, String guid) throws Exception {
        JSONArray jaModules = null;
        ModuleDBI modulesDBI = null;
        try {
                modulesDBI = new ModuleDBI();
                jaModules = modulesDBI.getSecCounter(con, lUserId,strModuleCode,guid);
        } catch (Exception e) {
                LogManager.errorLog(e);
                throw e;
        }finally{
        	modulesDBI = null;
        }
        return jaModules;
    }

    public JSONObject getAPMModuleCounters(Connection con, LoginUserBean loginBean, JSONArray joModuleCounter) throws Exception {
    	JSONObject joGUIDWiseData = null;
		ModuleDBI apmDBI = null;
		
		try {
			apmDBI = new ModuleDBI();
			joGUIDWiseData = apmDBI.getAPMModuleCounters(con, loginBean, joModuleCounter);
			
		}catch(Exception e) {
			throw e;
		}finally {
			apmDBI = null;
		}
		
		return joGUIDWiseData;	
	}
    				  
	public JSONArray getSecCounterValues(Connection con, long userId, String strModuleCode, String guid, String counterId) throws Exception{
		JSONArray jaAPMModule = null;
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			jaAPMModule = apmDBI.getSecCounterValues(con,userId,strModuleCode, guid, counterId);
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			apmDBI = null;
		}
		return jaAPMModule;
	}

	public void updateExecutionServiceFailedStatus(Connection con) {
		ModuleDBI apmDBI = null;
		try {
			apmDBI = new ModuleDBI();
			apmDBI.updateExecutionServiceFailedStatus(con);
			apmDBI = null;
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
	}
	
	public JSONObject getPostgresSlowQuery(Connection con, String strFromStartInterval, String strGUID,int SLOW_QRY_LIMIT) throws Exception {
		
		JSONObject joRtn = null;
		JSONArray jaSlowQueries = null;
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			jaSlowQueries = moduleDBI.getPostgresSlowQuery(con, strFromStartInterval, strGUID, SLOW_QRY_LIMIT);
			joRtn = UtilsFactory.getJSONSuccessReturn(jaSlowQueries);
			jaSlowQueries = null;
			moduleDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
        	moduleDBI = null;
        }
		return joRtn;
	}

	public JSONObject getDatabaseSlowQuery(Connection con, String strFromStartInterval, String strGUID,int SLOW_QRY_LIMIT,String strDatabaseType) throws Exception {
		
		JSONObject joRtn = null;
		JSONArray jaSlowQueries = null;
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			jaSlowQueries = moduleDBI.getDatabaseSlowQuery(con, strFromStartInterval, strGUID, SLOW_QRY_LIMIT,strDatabaseType);
			joRtn = UtilsFactory.getJSONSuccessReturn(jaSlowQueries);
			jaSlowQueries = null;
			moduleDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
        	moduleDBI = null;
        }
		return joRtn;
	}
	
	public JSONObject getDatabaseSlowQueryWithDateRange(Connection con, String strFromStartInterval, String strToInterval, String strGUID, int SLOW_QRY_LIMIT,String strDatabaseType) throws Exception {
		
		JSONObject joRtn = null;
		JSONArray jaSlowQueries = null;
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			jaSlowQueries = moduleDBI.getDatabaseSlowQueryWithDateRange(con, strFromStartInterval, strToInterval, strGUID, SLOW_QRY_LIMIT,strDatabaseType);
			joRtn = UtilsFactory.getJSONSuccessReturn(jaSlowQueries);
			jaSlowQueries = null;
			moduleDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
        	moduleDBI = null;
        }
		return joRtn;
	}
	
	public JSONObject getDatabaseSlowProcedure(Connection con, String strFromStartInterval, String strGUID,int SLOW_QRY_LIMIT,String strDatabaseType) throws Exception {
		
		JSONObject joRtn = null;
		JSONArray jaSlowQueries = null;
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			jaSlowQueries = moduleDBI.getDatabaseSlowProcedure(con, strFromStartInterval, strGUID, SLOW_QRY_LIMIT,strDatabaseType);
			joRtn = UtilsFactory.getJSONSuccessReturn(jaSlowQueries);
			jaSlowQueries = null;
			moduleDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
        	moduleDBI = null;
        }
		return joRtn;
	}
	
	public JSONObject getDatabaseSlowProcedureWithDateRange(Connection con, String strFromStartInterval, String strToInterval, String strGUID, int SLOW_QRY_LIMIT,String strDatabaseType) throws Exception {
		
		JSONObject joRtn = null;
		JSONArray jaSlowQueries = null;
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			jaSlowQueries = moduleDBI.getDatabaseSlowProcedureWithDateRange(con, strFromStartInterval, strToInterval, strGUID, SLOW_QRY_LIMIT,strDatabaseType);
			joRtn = UtilsFactory.getJSONSuccessReturn(jaSlowQueries);
			jaSlowQueries = null;
			moduleDBI = null;
		}catch(Exception e){
			LogManager.errorLog(e);
			throw e;
		}finally{
        	moduleDBI = null;
        }
		return joRtn;
	}
	
	/**
	 * Create the view "v_user_last_counter_<userId>, which is last counter received for all the Modules of the user.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void createAllModuleLastCounterView(Connection con, long lUserId) throws Exception {
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			
			moduleDBI.createAllModuleLastCounterView(con, lUserId);
		}catch(Exception e){
			throw e;
		}finally{
        	moduleDBI = null;
        }
	}
	
	/**
	 * Drop the view "v_user_last_counter_<userId>, which is last counter received for all the Modules of the user.
	 * 
	 * @param con
	 * @param lUserId
	 * @throws Exception
	 */
	public void dropAllModuleLastCounterView(Connection con, long lUserId) throws Exception {
		
		ModuleDBI moduleDBI = null;
		
		try{
			moduleDBI = new ModuleDBI();
			
			moduleDBI.dropAllModuleLastCounterView(con, lUserId);
		}catch(Exception e){
			throw e;
		}finally{
        	moduleDBI = null;
        }
	}
	
	/**
	 * update the counter to FALSE for particular guid/uid, 
	 *   to remove counter from monitor
	 * 
	 * @param con
	 * @param lUID
	 * @param lCounterId
	 * @param loginUserBean
	 * @throws Exception
	 */
	public String removeCounterFromMonitor(Connection con, Long lUID, Long lCounterId, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI moduleDBI = null;
		ChartDBI chartDBI = null;
		String strGUID = null;
		
		try {
			moduleDBI = new ModuleDBI();
			chartDBI = new ChartDBI();
			
			strGUID = moduleDBI.getGUID(con, lUID);
			// update the counter to FALSE; to remove counter from monitor
			moduleDBI.unSelectCounter(con, strGUID, lUID, lCounterId, loginUserBean.getUserId());
			//update is_active to ensure the chart is not active
			chartDBI.updateChartVisualOnCounterRemove(con, lCounterId, lUID, loginUserBean.getUserId());
			
			chartDBI = null;
			moduleDBI = null;
		} catch (Exception e) {
			throw e;
		}
		return strGUID;
	}
	
	/**
	 * gets particular RUM uid's details, with configured threshold 
	 * 
	 * @param con
	 * @param lUId
	 * @param loginUserBean
	 * @return
	 * @throws Exception
	 */
	public JSONObject getRUMModuleDetails(Connection con, long lUId, LoginUserBean loginUserBean) throws Exception {
		ModuleDBI moduleDBI = null;
		
		JSONObject joModule = null;
		
		try {
			moduleDBI = new ModuleDBI();
			
			joModule = moduleDBI.getRUMModuleDetails(con, lUId, loginUserBean.getUserId());
			
			moduleDBI = null;
		} catch (Exception e) {
			throw e;
		}
		
		return joModule;
	}
	
	public JSONObject getDeletedGUIDSLAs() {
		return joDeletedGUIDSLAs;
	}
	private void setDeletedGUIDSLAs(JSONObject joDeletedGUIDSLAs) {
		this.joDeletedGUIDSLAs = joDeletedGUIDSLAs;
	}
}
