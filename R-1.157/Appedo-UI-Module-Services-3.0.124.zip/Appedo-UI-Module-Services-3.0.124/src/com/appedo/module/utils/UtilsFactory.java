package com.appedo.module.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.postgresql.util.PGobject;

import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;

/**
 * Class which do some utilization operation.
 * 
 * @author Ramkumar R
 *
 */
public class UtilsFactory {
	
	public final static long FREQUENCY_ONE_DAY = 1000 * 60 * 60 * 24;
	public final static long FREQUENCY_ONE_HOUR = 1000 * 60 * 60;
	public final static long FREQUENCY_TEN_MINUTES = 1000 * 60 * 10;
	public final static long FREQUENCY_FOUR_HOUR = 1000 * 60 * 60 * 4;
	public final static long FREQUENCY_ONE_MINUTE = 1000 * 60 ;
	
	public static HashMap<String, JSONObject> HM_VENDOR_COUNTERS = new HashMap<String, JSONObject>();
	
	/**
	 * Returns the given yyyy-MM-dd HH:mm:ss format date-time in long value.
	 * 
	 * @param strTimeStamp
	 * @return
	 */
	public static Long formatTimestampToLong(String strTimeStamp){
		Long opDate = 0l;
		try{
			DateFormat ipFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			opDate = ipFormatter.parse(strTimeStamp).getTime();
			ipFormatter = null;
		}catch(Exception e){
			LogManager.errorLog(e);
		}
		return opDate;
	}
	
	public static Long formatTimestampToLong_yyyMMMddHHmmss(String strTimeStamp){
		Long opDate = 0l;
		try{
			DateFormat ipFormatter = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
			opDate = ipFormatter.parse(strTimeStamp).getTime();
			ipFormatter = null;
		}catch(Exception e){
			LogManager.errorLog(e);
		}
		return opDate;
	}
	
	/**
	 * Returns the given date-time in yyyy-MM-dd HH:mm:ss.S format.
	 * 
	 * @param lTime
	 * @return
	 */
	public static String formatDateToTimestamp(Long lTime){
		String opDate = "";
		try{
			DateFormat opFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
			opDate = opFormatter.format(new Date(lTime));
			opFormatter = null;
		}catch(Exception e){
			LogManager.errorLog(e);
		}
		return opDate;
	}
	
	/**
	 * Returns the given date-time in yyyy-MM-dd HH:mm:ss format.
	 * 
	 * @param lTime
	 * @return
	 */
	public static String formatTimeToyyyyMMDDHHmmss(Long lTime){
		String opDate = "";
		try{
			DateFormat opFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			opDate = opFormatter.format(new Date(lTime));
			opFormatter = null;
		}catch(Exception e){
			LogManager.errorLog(e);
		}
		return opDate;
	}
	
	/**
	 * Returns 'val2' if 'val1' is null; else return 'val1'
	 * 
	 * @param val1 
	 * @param val2 
	 * @return String
	 */
	public static String replaceNull(Object val1, String val2) {
		if (val1 == null)
			return val2;
		else
			return val1.toString();
	}
	
	/**
	 * Returns 'val2' if 'val1' is null or if blank; else return 'val1' AS respective object
	 * @param val1
	 * @param val2
	 * @return
	 */
	public static Object replaceNull(Object val1, Object val2) {
		if (val1 == null)
			return val2;
		else
			return val1;
	}
	
	/**
	 * Create new array without Blanks and Nulls in the given array. 
	 * 
	 * @param strArray
	 * @return
	 */
	public static String[] cleanArray(String[] strArray) {
		String[] saCleaned = null;
		
		int nTotalRecipient = strArray.length;
		saCleaned = new String[nTotalRecipient];
		
		for (int i=0, x=0; i < strArray.length; i++) {
			String strRecp = strArray[i];
			if( strRecp != null && strRecp.length() > 0 ){
				saCleaned[x++] = strRecp;
				strRecp = null;
			}
		}
		
		return saCleaned;
	}
	
	/**
	 * Converts the given input string of given input format to Date object.
	 * 
	 * @param stDate
	 * @param strInputFormat
	 * @return Date
	 */
	public static Date toDate(String stDate, String strInputFormat){
		Date date = null;
		DateFormat opFormatter = new SimpleDateFormat(strInputFormat);
		
		try {
			if( stDate != null ){
				date = opFormatter.parse(stDate);//(Date)formatter.parse(opFormatter.format(stDate));
			}
		}catch (Exception e){
			LogManager.errorLog(e);
			date = null;
		}
		return date;
	}
	
	/**
	 * Returns 'val2' if 'val1' is null or if blank; else return 'val1'
	 * 
	 * @param val1
	 * @param val2
	 * @return
	 */
	public static String replaceNullBlank(String val1, String val2) {
		if ( val1 == null || val1.length() == 0 )
			return val2;
		else
			return val1.toString();
	}
	
	/**
	 * Returns a JSONObject which can be used for a request's successful response, with the given message.
	 * 
	 * @param strMessage
	 * @return
	 */
	public static JSONObject getJSONSuccessReturn( String strMessage ){
		JSONObject joReturn = new JSONObject();
		
		joReturn.put("success", true);
		joReturn.put("failure", false);
		joReturn.put("message", strMessage);
		
		return joReturn;
	}
	
	/**
	 * Returns a JSONObject which can be used for a request's successful response, with the given message & successful db inserted counts
	 * 
	 * @param strMessage
	 * @param nInsertedCount
	 * @return
	 */
	public static JSONObject getJSONSuccessReturn( String strMessage, int nInsertedCount ){
		JSONObject joReturn = new JSONObject();
		
		joReturn.put("success", true);
		joReturn.put("failure", false);
		
		joReturn.put("message", strMessage);
		joReturn.put("inserted", nInsertedCount);
		
		return joReturn;
	}
	
	/**
	 * Returns a JSONObject which can be used for a request's successful response, with the given key-value pairs as message.
	 * 
	 * @param jo
	 * @return
	 */
	public static JSONObject getJSONSuccessReturn( JSONObject jo ){
		JSONObject joReturn = new JSONObject();
		
		joReturn.put("success", true);
		joReturn.put("failure", false);
		joReturn.put("message", jo);
		
		return joReturn;
	}
	
	/**
	 * Returns a JSONObject which can be used for a request's successful response, with the given JSONArray as message.
	 * 
	 * @param ja
	 * @return
	 */
	public static JSONObject getJSONSuccessReturn( JSONArray ja ){
		JSONObject joReturn = new JSONObject();
		
		joReturn.put("success", true);
		joReturn.put("failure", false);
		joReturn.put("message", ja);
		
		return joReturn;
	}
	
	/**
	 * Returns a JSONObject which can be used for a request's failure response with a message.
	 * 
	 * @param strMessage
	 * @return
	 */
	public static JSONObject getJSONFailureReturn( JSONObject jo ){
		JSONObject joReturn = new JSONObject(); 
		
		joReturn.put("success", false);
		joReturn.put("failure", true);
		joReturn.put("errorMessage", jo);
		
		return joReturn;
	}
	
	/**
	 * Returns a JSONObject which can be used for a request's failure response with a message.
	 * 
	 * @param strMessage
	 * @return
	 */
	public static JSONObject getJSONFailureReturn( String strMessage ){
		JSONObject joReturn = new JSONObject(); 
		
		joReturn.put("success", false);
		joReturn.put("failure", true);
		joReturn.put("errorMessage", (""+strMessage).replaceAll("\"","\\\""));
		
		return joReturn;
	}
	
	public static JSONObject getJSONSuccessReturn( JSONArray[] jaArrays ){
		JSONObject joReturn = new JSONObject();
		JSONArray jaReturn = new JSONArray();
		
		joReturn.put("success", true);
		joReturn.put("failure", false);
		
		for( JSONArray jaArray: jaArrays){
			jaReturn.add(jaArray);
		}
		joReturn.put("message", jaReturn);
		
		return joReturn;
	}
	
	/**
	 * Returns a JSONObject which can be used for a request's failure response with a message, and next focus-to field.
	 * 
	 * @param strMessage
	 * @param strFocusTo
	 * @return
	 */
	public static JSONObject getJSONFailureReturn( String strMessage, String strFocusTo){
		JSONObject joReturn = new JSONObject(); 
		
		joReturn.put("success", false);
		joReturn.put("failure", true);
		joReturn.put("errorMessage", ""+strMessage.replaceAll("\"","\\\""));
		joReturn.put("focusTo", strFocusTo);
		
		return joReturn;
	}
	
	/**
	 * Returns the input string as comfortable for SQL operations.
	 * 
	 * @param str
	 * @return
	 */
	public static String makeValidVarchar(String str) {
		StringBuilder sbValue = new StringBuilder();
		
		if( str == null )
			sbValue.append("null");
		else
			sbValue.append("'").append(str.replaceAll("'","''")).append("'");
		
		return sbValue.toString();
	}
	
	/**
	 * Close the given InputStream
	 * 
	 * @param is
	 * @return
	 */
	public static boolean close(InputStream is){
		try{
			if(is != null){
				is.close();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			return false;
		}
		return true;
	}
	
	/**
	 * Close the given InputStreamReader
	 * 
	 * @param isr
	 * @return
	 */
	public static boolean close(InputStreamReader isr){
		try{
			if(isr != null){
				isr.close();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			return false;
		}
		return true;
	}
	
	/**
	 * Close the given BufferedReader
	 * 
	 * @param reader
	 * @return
	 */
	public static boolean close(BufferedReader reader){
		try{
			if(reader != null){
				reader.close();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			return false;
		}
		return true;
	}
	
	/**
	 * Close the given OutputStream
	 * 
	 * @param outputStream
	 * @return
	 */
	public static boolean close(OutputStream outputStream){
		try{
			if(outputStream != null){
				outputStream.close();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			return false;
		}
		return true;
	}

	/**
	 * Close the given PrintWriter
	 * 
	 * @param printWriter
	 * @return
	 */
	public static boolean close(PrintWriter printWriter){
		try{
			if(printWriter != null){
				printWriter.close();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			return false;
		}
		return true;
	}

	/**
	 * Close the given StringWriter
	 * 
	 * @param stringWriter
	 * @return
	 */
	public static boolean close(StringWriter stringWriter){
		try{
			if(stringWriter != null){
				stringWriter.close();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			return false;
		}
		return true;
	}

	public static boolean close(Writer writer){
		try{
			if(writer != null){
				writer.close();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
			return false;
		}
		return true;
	}
	
	/**
	 * Closes the nested collection variable.
	 * 
	 * @param objCollection
	 */
	public static void clearCollectionHieracy(Object objCollection){
		try{
			if( objCollection == null ){
				
			}else if( objCollection instanceof JSONObject ) {
				JSONObject joCollection = (JSONObject)objCollection;
				Iterator it = joCollection.keySet().iterator();
				while( it.hasNext() ){
					Object str = it.next();
					clearCollectionHieracy( joCollection.get(str) );
				}
				joCollection.clear();
				joCollection = null;
			}else if( objCollection instanceof JSONArray ) {
				JSONArray jaCollection = (JSONArray)objCollection;
				for( int i=0; i < jaCollection.size(); i++ ){
					clearCollectionHieracy( jaCollection.get(i) );
				}
				jaCollection.clear();
				jaCollection = null;
			}else if( objCollection instanceof Map ) {
				Map mapCollection = (Map)objCollection;
				Iterator it = mapCollection.keySet().iterator();
				while( it.hasNext() ){
					Object str = it.next();
					clearCollectionHieracy( mapCollection.get(str) );
				}
				mapCollection.clear();
				mapCollection = null;
			}else if( objCollection instanceof List ) {
				List listCollection = (List)objCollection;
				for( int i=0; i < listCollection.size(); i++ ){
					clearCollectionHieracy( listCollection.get(i) );
				}
				listCollection.clear();
				listCollection = null;
			}else if( objCollection instanceof StringBuilder ) {
				StringBuilder sbCollection = (StringBuilder)objCollection;
				sbCollection.setLength(0);
			}else if( objCollection instanceof StringBuffer ) {
				StringBuffer sbCollection = (StringBuffer)objCollection;
				sbCollection.setLength(0);
			}else if( objCollection instanceof Set ) {
				Set setCollection = (Set)objCollection;
				Object[] objSetCollections = setCollection.toArray();
				for( int i = 0; i < objSetCollections.length; i++ ){
					clearCollectionHieracy( objSetCollections[i] );
				}
				setCollection.clear();
				setCollection = null;
			}
			
			objCollection = null;
		}catch(Throwable t){
			LogManager.errorLog(t);
		}
	}
	
	/**
	 * Return 'val2' if 'val1' is null; else return 'val1' 
	 * This function should be used when db_column definition is "NOT NULL DEFAULT ''"
	 * 
	 * @param val1 
	 * @param val2 
	 * @return String
	 */
	public static String replaceNullWithQuote(Object val1, String val2) {
		if (val1 == null)
			return "'" + val2 +"'";
		else
			return "'" + val1.toString() + "'";
	}
	
	/**
	 * Parameterized method to sort Map e.g. HashMap or Hashtable in Java throw
	 * NullPointerException if Map contains null key
	 * 
	 * @param <K>
	 * @param <V>
	 * @param map
	 * @return
	 */
	public static <K extends Comparable, V extends Comparable> Map<K, V> sortByKeys(Map<K, V> map) {
		List<K> keys = new LinkedList<K>(map.keySet());
		Collections.sort(keys);

		// LinkedHashMap will keep the keys in the order they are inserted
		// which is currently sorted on natural ordering
		Map<K, V> sortedMap = new LinkedHashMap<K, V>();
		for (K key : keys) {
			sortedMap.put(key, map.get(key));
		}

		return sortedMap;
	}
	
	public static boolean contains(String[] saArray, String strValue) {
		for (int i = 0; i < saArray.length; i++) {
			if (saArray[i].equals(strValue)) return true;
		}
		
		return false;
	}
	
	public static <T> boolean contains(final T[] array, final T v) {
		for (final T e : array)
			if (e == v || v != null && v.equals(e)) return true;
		
	    return false;
	}

	public static boolean checkFileExistsForShipping(String filePath) throws Exception {
		HttpClient client = null;
		PostMethod method = null;
		boolean bool = false;
		String responseStream = null;
		try{
			client = new HttpClient();
			method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"checkFileExists");
			method.addParameter("file_path", filePath);
			method.setRequestHeader("Connection", "close");
			
			int statusCode = client.executeMethod(method);
			LogManager.infoLog(Constants.APPEDO_URL_FILE_TRANSFER+"checkFileExists"+" <> "+"statusCode: "+statusCode);
			
			responseStream = method.getResponseBodyAsString();
			
			if (statusCode != HttpStatus.SC_OK) {
				LogManager.errorLog("URL failed: "+Constants.APPEDO_URL_FILE_TRANSFER+"checkFileExists"+" <> "+method.getStatusLine());
				LogManager.errorLog("Response: "+responseStream);
			}
			
			if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
				JSONObject joResponse = JSONObject.fromObject(responseStream);
				if( joResponse.getBoolean("success") ) {
					bool = true;
				} else {
					if( joResponse.containsKey("errorMessage") ) {
						throw new Exception( joResponse.getString("errorMessage") );
					}
				}
			}
		} catch(Exception e) {
			bool = false;
			LogManager.errorLog("Exception in checkFileExistsForShipping for: "+filePath);
			LogManager.errorLog(e);
		} finally {
			method.releaseConnection();
			method = null;
		}
		
		return bool;
	}

	public static void createParentDirectory(String destPath) throws Exception {
		File f = null;
		try{
			f = new File(destPath);
			
			if(!f.exists()){
				f.mkdirs();
			}
		}catch(Exception e){
			LogManager.errorLog(e);
		}
	}
	
	public static boolean removeFolderForShipping(String filePath) throws Exception {
		HttpClient client = null;
		PostMethod method = null;
		boolean bool = false;
		String responseStream = null;
		try{
			client = new HttpClient();
			method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"removeFolder");
			method.addParameter("file_path", filePath);
			method.setRequestHeader("Connection", "close");
			
			int statusCode = client.executeMethod(method);
			LogManager.infoLog(Constants.APPEDO_URL_FILE_TRANSFER+"removeFolder"+" <> "+"statusCode: "+statusCode);
			
			responseStream = method.getResponseBodyAsString();
			
			if (statusCode != HttpStatus.SC_OK) {
				LogManager.errorLog("URL failed: "+Constants.APPEDO_URL_FILE_TRANSFER+"removeFolder"+" <> "+method.getStatusLine());
				LogManager.errorLog("Response: "+responseStream);
			}
			
			if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
				JSONObject joResponse = JSONObject.fromObject(responseStream);
				if( joResponse.getBoolean("success") ) {
					bool = true;
				} else {
					if( joResponse.containsKey("errorMessage") ) {
						throw new Exception( joResponse.getString("errorMessage") );
					}
				}
			}
		} catch(Exception e) {
			bool = false;
			LogManager.errorLog("Exception in removeFolderForShipping for: "+filePath);
			LogManager.errorLog(e);
		} finally {
			method.releaseConnection();
			method = null;
		}
		return bool;
	}

	public static boolean removeFile(String destPath) throws Exception {
		
		boolean bool = false;
		File f = null;
		try{
			//strJmeterScriptPath="C:/Appedo/resource/vuscripts/jmeter/vuscripts1.xml";	
			// create new files
			f = new File(destPath);
			
			if( f.exists() ) {
				f.delete();
			}

			bool = true;
			
		}catch(Exception e){
			LogManager.errorLog(e);
			bool = false;
		}
		
		return bool;
	}

	
	/**
	 * returns the index of element in array
	 * 
	 * @param saArray
	 * @param strValue
	 * @return
	 */
	public static int indexOf(String[] saArray, String strValue) {
		for (int i = 0; i < saArray.length; i++) {
			if (saArray[i].equals(strValue)) return i;
		}
		
		return -1;
	}
	
	public static boolean createFileForShipping( String dataFile, String overwrite, String filePath) throws Exception {
		
		HttpClient client = null;
		PostMethod method = null;
		boolean bFileSaved = false;
		String responseStream = null;
		try{
			client = new HttpClient();
			method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"writeFile");
			method.addParameter("file_path", filePath);
			method.addParameter("file_content", dataFile);
			method.addParameter("overwrite", overwrite);
			method.setRequestHeader("Connection", "close");
			
			int statusCode = client.executeMethod(method);
			LogManager.infoLog(Constants.APPEDO_URL_FILE_TRANSFER+"writeFile"+" <> "+"statusCode: "+statusCode);
			
			responseStream = method.getResponseBodyAsString();
			
			if (statusCode != HttpStatus.SC_OK) {
				LogManager.errorLog("URL failed: "+Constants.APPEDO_URL_FILE_TRANSFER+"writeFile"+" <> "+method.getStatusLine());
				LogManager.errorLog("Response: "+responseStream);
			}
			
			if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
				JSONObject joResponse = JSONObject.fromObject(responseStream);
				
				if( joResponse.getBoolean("success") ) {
					bFileSaved = true;
				} else {
					if( joResponse.containsKey("errorMessage") ) {
						throw new Exception( joResponse.getString("errorMessage") );
					}
				}
			}
		} catch(Exception e) {
			bFileSaved = false;
			LogManager.errorLog("Exception in createFileForShipping for: "+filePath);
			LogManager.errorLog(e);
		} finally {
			method.releaseConnection();
			method = null;
		}
		
		return bFileSaved;
	}

	public static PGobject getPgObject(String value){
		PGobject jsonObject = new PGobject();
		try {
			jsonObject.setType("json");
			jsonObject.setValue(value);
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
		return jsonObject;
	}
	
	public static boolean checkTotalCountGreaterThanLimit(long totalCount){
		return totalCount > Constants.LT_COUNT_RESULT_LIMIT ? true : false;
	}
	
	public static long getValueForLoop(long totalCount){
		return Math.round( (totalCount / Constants.LT_COUNT_RESULT_LIMIT) );
	}
	
	public static long getDividedEpochTime(long divisableValue,long runTime){
		return Math.round((runTime / divisableValue));
	}
	
	public static long getDividedEpochTime(long divisableValue,String runTime){
		return getDividedEpochTime(divisableValue,Long.parseLong(runTime));
	}
	
	public static boolean checkRunTimeLessThanGivenHour(int hour,long runTime){
		return (FREQUENCY_ONE_HOUR * hour) > runTime ? true : false;
	}
	
	public static boolean checkRunTimeLessThanGivenHour(int hour,String runTime){
		return checkRunTimeLessThanGivenHour(hour,Long.parseLong(runTime));
	}
	
	public static boolean checkRunTimeLessThanGivenMinute(int minute,long runTime){
		return (FREQUENCY_ONE_MINUTE * minute) > runTime ? true : false;
	}

	public static boolean checkRunTimeLessThanGivenMinute(int minute,String runTime){
		return checkRunTimeLessThanGivenMinute(minute,Long.parseLong(runTime));
	}
	
	public static Long convertMilliSecondsToSeconds(Long milliSeconds){
		return milliSeconds / 1000;
	}
	
	/**
	 * calculate difference between two time in millseconds
	 * @param lTime1
	 * @param lTime2
	 * @throws Exception
	 */
	public static HashMap<String, Long> calcDateDiffInMilliSeconds(long lTime1, long lTime2) throws Exception {
		HashMap<String, Long> hmDateDiff = null;
		
		try {
			hmDateDiff = new HashMap<String, Long>();

			long lDiff = lTime2 - lTime1;
 
			long lDiffSeconds = lDiff / 1000 % 60;
			long lDiffMinutes = lDiff / (60 * 1000) % 60;
			long lDiffHours = lDiff / (60 * 60 * 1000) % 24;
			long lDiffDays = lDiff / (24 * 60 * 60 * 1000);
			
			
			hmDateDiff.put("SECONDS", lDiffSeconds);
			hmDateDiff.put("MINUTES", lDiffMinutes);
			hmDateDiff.put("HOURS", lDiffHours);
			hmDateDiff.put("DAYS", lDiffDays);
		} catch (Exception e) {
			LogManager.errorLog(e);
		}
		
		return hmDateDiff;
	}
	
	@SuppressWarnings("unchecked")
	public static String convertStringtoJSON(String masterJSONString,String childJSONString) throws ParseException{
		String outputJSONString = null;
		if((masterJSONString == null)&&(childJSONString != null)){
			outputJSONString = childJSONString;
		}else if((masterJSONString != null)&&(childJSONString == null)){
			outputJSONString = masterJSONString;
		}else if((masterJSONString != null)&&(childJSONString != null)){
			JSONParser jsonParser=new JSONParser();
			org.json.simple.JSONArray masterJSONArray = (org.json.simple.JSONArray)jsonParser.parse(masterJSONString);
			org.json.simple.JSONArray childJSONArray = (org.json.simple.JSONArray)jsonParser.parse(childJSONString);
			masterJSONArray.addAll(childJSONArray);
			outputJSONString = masterJSONArray.toString();
		}
		return outputJSONString;
	}
	
	public static boolean createFile(byte[] dataBytes,int length, String destinationPath) {
        FileOutputStream fos = null;
        boolean bFileSaved = false;
        
        try {
            fos=new FileOutputStream(new File(destinationPath));
            fos.write(dataBytes, 0, length);
            //fos.close();
            
            bFileSaved = true;
        } catch(FileNotFoundException fnfe) {
        	LogManager.errorLog(fnfe);
        	bFileSaved = false;
        } catch(IOException ioe) {
        	LogManager.errorLog(ioe);
        	bFileSaved = false;
        } finally {
        	close(fos);
        	fos = null;
        }
        return bFileSaved;
    }

	
	public static String readFileForShipping(String filePath) throws Exception {
		
		HttpClient client = null;
		PostMethod method = null;
		
		String responseStream = null, responseRtn = "";
		try{
			client = new HttpClient();
			method = new PostMethod(Constants.APPEDO_URL_FILE_TRANSFER+"readFile");
			method.addParameter("file_path", filePath);
			method.setRequestHeader("Connection", "close");
			
			int statusCode = client.executeMethod(method);
			LogManager.infoLog(Constants.APPEDO_URL_FILE_TRANSFER+"readFile"+" <> "+"statusCode: "+statusCode);
			
			responseStream = method.getResponseBodyAsString();
			
			if (statusCode != HttpStatus.SC_OK) {
				LogManager.errorLog("URL failed: "+Constants.APPEDO_URL_FILE_TRANSFER+"readFile"+" <> "+method.getStatusLine());
				LogManager.errorLog("Response: "+responseStream);
			}
			
			if( responseStream.startsWith("{") && responseStream.endsWith("}") ) {
				JSONObject joResponse = JSONObject.fromObject(responseStream);
				
				if( joResponse.getBoolean("success") ) {
					if( joResponse.containsKey("message") ) {
						responseRtn = joResponse.get("message").toString();
					} else {
						throw new Exception("1");	// TODO Inform that Service has problem
					}
				} else {
					if( joResponse.containsKey("errorMessage") ) {
						throw new Exception( joResponse.getString("errorMessage") );
					}
				}
			}
		} catch(Exception e) {
			LogManager.errorLog("Exception in readFileForShipping for: "+filePath);
			LogManager.errorLog(e);
			throw e;
		} finally {
			method.releaseConnection();
			method = null;
		}
		
		return responseRtn;
	}

	
	/**
	 * Zero's to append from last one hour, 
	 * 
	 * @param lhsReceivedInMinutes
	 * @param alChartValues
	 *
	public static void appendZeros(LinkedHashSet<Long> lhsReceivedInMinutes, ArrayList<ArrayList<Long>> alChartValues) {
		int nIndex = 0;
		
		LinkedHashSet<Long> lhsLast1HourInMinutes = new LinkedHashSet<Long>();
		
		Iterator<Long> itLast1HourInMinutes = null;
		
		ArrayList<Long> alZeroAppendXYValue = null, alDatumXY = null;
		
		long lZeroAppendMinute = 0L, lChartTimeInMinuteX = 0L;
		
		try {
			Calendar cal = Calendar.getInstance();

			// time from 1 hour before
			cal.add(Calendar.MINUTE, -1 * Constants.ZERO_APPEND_FROM_LAST_MIN_TO_START);
			for (int i = 1; i <= Constants.ZERO_APPEND_FROM_LAST_MIN_TO_START; i++) {
				cal.add(Calendar.MINUTE, 1);
				
				lhsLast1HourInMinutes.add(TimeUnit.MILLISECONDS.toMinutes(cal.getTimeInMillis()));
			}
			
			
			itLast1HourInMinutes = lhsLast1HourInMinutes.iterator();
			while( itLast1HourInMinutes.hasNext() ) {
				lZeroAppendMinute = (long) itLast1HourInMinutes.next();
				
				if( ! lhsReceivedInMinutes.contains(lZeroAppendMinute) ) {
					// array index calculated based on zero to append at specific position 
					if ( nIndex < alChartValues.size() ) {
						do {
							alDatumXY = alChartValues.get(nIndex);
							lChartTimeInMinuteX = TimeUnit.MILLISECONDS.toMinutes(alDatumXY.get(0));
							
							if ( lZeroAppendMinute < lChartTimeInMinuteX ) {
								break;
							} else {
								nIndex = nIndex + 1;
							}
							
						} while( nIndex < alChartValues.size() );
					}
					
					alZeroAppendXYValue = new ArrayList<Long>(2);
					alZeroAppendXYValue.add(lZeroAppendMinute*60*1000);
					alZeroAppendXYValue.add(0L);
					
					// append to incoming param
					alChartValues.add(nIndex, alZeroAppendXYValue);
				}
			}
			
		} catch (Exception e) {
			System.out.println("Exception in appendZero: "+e.getMessage());
			e.printStackTrace();
		} finally {
			clearCollectionHieracy(lhsLast1HourInMinutes);
			lhsLast1HourInMinutes = null;
			/*
			clearCollectionHieracy(alZeroAppendXYValue);
			alZeroAppendXYValue = null;
			 *
			itLast1HourInMinutes = null; 
		}
	}*/
	
	/**
	 * Calculate the average for the given values in the List.
	 * 
	 * @param lValues
	 * @return
	 */
	public static double average(List<Double> lValues) {
	    double sum = 0;
	    for (double value : lValues) {
	        sum += value;
	    }
	    return sum / lValues.size();
	}
	
	/**
	 * Round-Off the given value, for the given decimal precision.
	 * 
	 * @param value
	 * @param position
	 * @return
	 */
	public static double roundOff(double value, int position) {
		double a = value, temp = Math.pow(10.0, position);
        a *= temp;
        a = Math.round(a);
        return (a / (double)temp);
    }
	
	public static String generateOADChartQuery(Long lUid) {
		StringBuilder sbQuery = new StringBuilder();
					 
		 sbQuery.append(" SELECT extract('epoch' from gs.start_from)*1000 as T, (COALESCE(min,0)) AS Min, (COALESCE(max,0)) AS Max, ")
		 		.append(" (COALESCE(avg,0)) AS Avg FROM  ( @dateFilter_1@) AS gs LEFT JOIN ( SELECT date_trunc('@truncData@', appedo_received_on) as start_from, ")
		 		.append(" counter_type, Round(min(counter_value), 3) as min, Round(avg(counter_value), 3) as avg, Round(max(counter_value), 3) AS max ")
		 		.append(" FROM collector_").append(lUid).append("  WHERE @dateFilter_2@ AND counter_type =@counterId@ GROUP BY start_from, counter_type ) ")
		 		.append(" AS c ON  gs.start_from = c.start_from WHERE ( date_trunc('@truncData@', now()) = gs.start_from AND ")
		 		.append(" c.start_from IS NULL ) = FALSE ORDER BY gs.start_from ASC ");
		
		return sbQuery.toString();
	}
	
	public static String generateOADChartVisualizerQuery(Long lUid) {
		StringBuilder sbQuery = new StringBuilder();
					 
		 sbQuery.append(" SELECT extract('epoch' from gs.start_from)*1000 as T, (COALESCE(cnt,0)) AS count, (COALESCE(min,0)) AS min, (COALESCE(max,0)) AS max, ")
		 		.append(" (COALESCE(avg,0)) AS avg, (COALESCE(ssc.critical,0)) as critical, (COALESCE(ssc.warning,0)) as warning ")
		 		.append(" FROM ( @dateFilter_1@) AS gs LEFT JOIN ( SELECT date_trunc('@truncData@', appedo_received_on) as start_from, ")
		 		.append(" counter_type AS counter,  count(counter_type) AS cnt, Round(min(counter_value), 3) as min, Round(avg(counter_value), 3) as avg, Round(max(counter_value), 3) AS max ")
		 		.append(" FROM collector_").append(lUid).append("  WHERE @dateFilter_2@ AND counter_type =@counterId@ GROUP BY start_from, counter_type ) ")
		 		.append(" AS col ON  gs.start_from = col.start_from LEFT JOIN ( SELECT ss1.counter_id, ss1.uid, ")
		 		.append(" CASE WHEN cm1.is_above_threshold then max(ss1.critical_threshold_value) ELSE min(ss1.critical_threshold_value) END AS critical, ")
		 		.append(" CASE WHEN cm1.is_above_threshold THEN max(ss1.warning_threshold_value) ELSE min(ss1.warning_threshold_value) END AS warning ")
		 		.append(" FROM so_sla_counter ss1 JOIN counter_master_").append(lUid).append(" cm1 ON ss1.counter_id = cm1.counter_id ")
		 		.append(" WHERE ss1.counter_id = @counterId@ AND ss1.uid=").append(lUid).append(" GROUP BY  ")
		 		.append(" ss1.counter_id, ss1.uid, cm1.is_above_threshold ) as ssc on ")
		 		//commented below condition to bring the static value
		 		//.append(" col.counter = ssc.counter_id ")
		 		.append(" 1=1 ")
		 		.append(" WHERE ( date_trunc('@truncData@', now()) = gs.start_from AND ")
		 		.append(" col.start_from IS NULL ) = FALSE ORDER BY gs.start_from ASC ");
		
		return sbQuery.toString();
	}
	
	public static String generateRUMChartQuery(Long lUserId, Long lUid) {
		StringBuilder sbQuery = new StringBuilder();
		
		 sbQuery.append(" SELECT @appedoReceivedOn@  AS appedo_received_on_formatted, count(*) AS daily_visitor_count, ")
		 		.append(" count(CASE WHEN rtb.rum_id IS NULL THEN 1 ELSE NULL END) AS ok_cnt,  ")
		 		.append(" count(CASE WHEN rtb.breached_severity = 'WARNING' THEN 1 ELSE NULL END) AS warning_cnt, ")
		 		.append(" count(CASE WHEN rtb.breached_severity = 'CRITICAL' THEN 1 ELSE NULL END) AS critical_cnt  ")
		 		.append(" FROM rum_collector_").append(lUid).append(" rc LEFT JOIN so_rum_threshold_breach_").append(lUserId).append(" rtb ON ")
		 		.append(" rc.uid = rtb.uid AND rc.rum_id = rtb.rum_id WHERE (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0)  ")
		 		.append(" @healthCode@  @dateFilter@ GROUP BY appedo_received_on_formatted ORDER BY appedo_received_on_formatted");
		
		return sbQuery.toString();
	}
	
	public static String generateRUMChartVisualizationQuery(Long lUserId, Long lUid) {
		StringBuilder sbQuery = new StringBuilder();
		
		 /*sbQuery.append(" SELECT @appedoReceivedOn@  AS appedo_received_on_formatted, count(*) AS count, ")
		 		.append(" count(CASE WHEN rtb.rum_id IS NULL THEN 1 ELSE NULL END) AS ok_cnt,  ")
		 		.append(" count(CASE WHEN rtb.breached_severity = 'WARNING' THEN 1 ELSE NULL END) AS warning, ")
		 		.append(" count(CASE WHEN rtb.breached_severity = 'CRITICAL' THEN 1 ELSE NULL END) AS critical  ")
		 		.append(" FROM rum_collector_").append(lUid).append(" rc LEFT JOIN so_rum_threshold_breach_").append(lUserId).append(" rtb ON ")
		 		.append(" rc.uid = rtb.uid AND rc.rum_id = rtb.rum_id WHERE (rc.nt_domcomp <> 0 AND rc.nt_nav_st <> 0)  ")
		 		.append(" @healthCode@  @dateFilter@ GROUP BY appedo_received_on_formatted ORDER BY appedo_received_on_formatted");*/
		//modified generic query
		sbQuery.append(" SELECT extract(epoch from gs.start_from)*1000 AS datetime, COALESCE(graph.count,0) AS count, 0 AS min, 0 AS avg, 0 AS max, ")
				.append(" COALESCE(crit.critical,0) AS critical, COALESCE(warn.warning,0) AS warning FROM @dateFilter@ LEFT JOIN ")
				.append(" (SELECT date_trunc('@dateTrunc@', appedo_received_on) AS datetime, count(rum_id) AS count FROM ")
				.append(" rum_collector_").append(lUid).append(" WHERE uid= ").append(lUid).append(" GROUP BY datetime) AS graph ")
				.append(" ON gs.start_from = graph.datetime ")
				.append(" LEFT JOIN (SELECT date_trunc('@dateTrunc@' , received_on) AS datetime, count(so_rum_tb_id) AS critical ")
				.append(" FROM so_rum_threshold_breach_").append(lUserId).append(" WHERE uid=").append(lUid).append(" AND breached_severity='CRITICAL' GROUP BY datetime)")
				.append(" AS crit on crit.datetime=gs.start_from ")
				.append(" LEFT JOIN (SELECT date_trunc('@dateTrunc@', received_on) AS datetime, count(so_rum_tb_id) AS warning FROM ")
				.append(" so_rum_threshold_breach_").append(lUserId).append(" WHERE uid=").append(lUid).append(" AND breached_severity='WARNING' GROUP BY datetime) ")
				.append(" AS warn ON warn.datetime=gs.start_from ");
					
		return sbQuery.toString();
	}
	
	public static String generateSUMChartVisualizationQuery(Long lTestId) {
		StringBuilder sbQuery = new StringBuilder();
		
		 sbQuery.append(" SELECT EXTRACT(epoch from hf.received_on)*1000 datetime,  ")
		 		.append(" 0 AS count, hf.pageloadtime AS min, hf.pageloadtime AS max, hf.pageloadtime AS avg, COALESCE(sss.warning_limit,0) AS warning,  ")
		 		.append(" COALESCE(sss.error_limit,0) AS critical FROM sum_har_test_results hf LEFT JOIN so_sla_sum sss ON sss.sum_test_id = test_id AND ")
		 		.append(" sum_type = 'RESPONSE_MONITORING' WHERE  hf.test_id =  ").append(lTestId).append(" AND location = '@location@' ")
		 		.append(" AND @dateFilter@ ");
		
		return sbQuery.toString();
	}
	
	public static String makeValidPath(String str) {
		StringBuilder sbValue = new StringBuilder();
		
		if( str == null )
			sbValue.append("null");
		else
			sbValue.append("'").append(str.replaceAll("/","\\\\/")).append("'");
		return sbValue.toString();
	}
	
}

