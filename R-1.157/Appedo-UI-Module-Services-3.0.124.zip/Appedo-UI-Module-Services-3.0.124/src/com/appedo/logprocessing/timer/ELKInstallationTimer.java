package com.appedo.logprocessing.timer;

import java.sql.Connection;
import java.util.Map.Entry;
import java.util.TimerTask;

import net.sf.json.JSONArray;

import com.appedo.manager.LogManager;
import com.appedo.module.common.Constants;
import com.appedo.module.connect.DataBaseManager;
import com.appedo.module.dbi.LogProcessDBI;

public class ELKInstallationTimer extends TimerTask {

	@Override
	public void run() {
		Connection con = null;
		try {
			if (Constants.IS_ELK_THREAD_RUNNING == false) {
				if (Constants.ELK_USER_VS_DATA.size() > 0) {
					Constants.IS_ELK_THREAD_RUNNING = true; // add a synchr block to avoid threading issue
				}
				con = DataBaseManager.giveConnection();
				for (Entry<String, JSONArray> entry : Constants.ELK_USER_VS_DATA.entrySet()) {
					String userid = entry.getKey();
					JSONArray jarr = entry.getValue();
					LogProcessDBI dbi = new LogProcessDBI();
					System.out.println("userId : " + userid);
					System.out.println("json array : " + jarr);

					dbi.createELKDir(con, jarr, userid);
					DataBaseManager.commitConnection(con);
					Constants.ELK_USER_VS_DATA.remove(userid);
					break;
				}
			}
		} catch (Exception e) {
			DataBaseManager.rollbackConnection(con);
			LogManager.errorLog("Something went wrong in ELKInstallationTimer : "+ e.getMessage());
			e.printStackTrace();
		} finally {
			DataBaseManager.close(con);
		}
	}

}
