package com.appedo.lt.servlet;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appedo.lt.common.Constants;
import com.appedo.lt.connect.DataBaseManager;
import com.appedo.manager.LogManager;

/**
 * Servlet to handle one operation for the whole application
 * 
 * @author navin
 * 
 */
public class RUMCollectorInitServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public static String realPath = null;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public void init() {
		// declare Servlet context
		ServletContext context = getServletContext();
		realPath = context.getRealPath("//");
		
		try{
			String strConstantsFilePath = context.getInitParameter("CONSTANTS_PROPERTIES_FILE_PATH");
			String strLog4jFilePath = context.getInitParameter("LOG4J_PROPERTIES_FILE_PATH");
			
			Constants.CONSTANTS_FILE_PATH = RUMCollectorInitServlet.realPath + strConstantsFilePath;
			Constants.LOG4J_PROPERTIES_FILE = RUMCollectorInitServlet.realPath + strLog4jFilePath;
			
			// Loads log4j configuration properties
			LogManager.initializePropertyConfigurator(Constants.LOG4J_PROPERTIES_FILE);
			
			// Loads Constant properties
			Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);
			
			// Loads Appedo config properties from the system path
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Loads db config
			DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
			
			
			// loads appedo constants; say loads appedoWhiteLabels, 
			Constants.loadAppedoWhiteLabels(Constants.APPEDO_CONFIG_FILE_PATH);
			
			/*
			 * CI JS `application_ci.js`, replaces appedo whitelabels from file and saves in another file `<download_appln_name_lowercase>_ci.js`
			 * Note: after loaded appedowhitelabels, replaced file 
			 */
			Constants.replaceCIJSAppedoWhiteLabels();
			
		} catch(Throwable th) {
			System.out.println("Exception in Init.load: "+th.getMessage());
			th.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
