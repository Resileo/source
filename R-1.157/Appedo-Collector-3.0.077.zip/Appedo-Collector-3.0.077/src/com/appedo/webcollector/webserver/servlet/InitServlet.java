package com.appedo.webcollector.webserver.servlet;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.appedo.webcollector.webserver.connect.DataBaseManager;
import com.appedo.webcollector.webserver.controller.BeatsThreadController;
import com.appedo.webcollector.webserver.controller.CollectorThreadController;
import com.appedo.webcollector.webserver.controller.DotNetProfilerThreadController;
import com.appedo.webcollector.webserver.controller.JavaProfilerThreadController;
import com.appedo.webcollector.webserver.controller.MSSQLProcedureThreadController;
import com.appedo.webcollector.webserver.controller.MSSQLSlowQueryThreadController;
import com.appedo.webcollector.webserver.controller.MySQLSlowQueryThreadController;
import com.appedo.webcollector.webserver.controller.OracleSlowQueryThreadController;
import com.appedo.webcollector.webserver.controller.PGSlowQueryThreadController;
import com.appedo.webcollector.webserver.manager.AWSJavaMail;
import com.appedo.webcollector.webserver.manager.BackupTimer;
import com.appedo.manager.LogManager;
import com.appedo.webcollector.webserver.util.Constants;

/**
 * This class does the initialization operation for this application
 * 
 * @author Ramkumar R
 *
 */
public class InitServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	public static String version = null;
	public static String realPath = null;
	
	public static TimerTask ttBackup = null;
	public static Timer timerBackup = null;
	public static TimerTask timerUpgradeModule = null;
	public static Timer timerUpgrade = new Timer();
	/**
	 * Do the initialization operation of this application like:
	 * - Get the configuration data from configuration files.
	 * - Schedule & Start all the counter class timers.
	 * 
	 */
	public void init() {
		//super();
   	 	System.out.println("Initializing Appedo Collector Web App...");
		
		// declare servlet context
		ServletContext context = getServletContext();
		
		realPath = context.getRealPath("//");
		version = (String) context.getInitParameter("version");
		
		try{
			String strConstantsFilePath = context.getInitParameter("CONFIG_PROPERTIES_FILE_PATH");
			String strLog4jFilePath = context.getInitParameter("LOG4J_PROPERTIES_FILE_PATH");
			
			Constants.CONSTANTS_FILE_PATH = InitServlet.realPath+strConstantsFilePath;
			Constants.LOG4J_PROPERTIES_FILE = InitServlet.realPath+strLog4jFilePath;
			
			// Loads log4j configuration properties
			LogManager.initializePropertyConfigurator( Constants.LOG4J_PROPERTIES_FILE );
			// Loads Constant properties 
			Constants.loadConstantsProperties(Constants.CONSTANTS_FILE_PATH);
			
			// Loads Appedo config properties from the system path
			Constants.loadAppedoConfigProperties(Constants.APPEDO_CONFIG_FILE_PATH);
			// Loads db config
			DataBaseManager.doConnectionSetupIfRequired(Constants.APPEDO_CONFIG_FILE_PATH);
			
			// Loads mail config
			AWSJavaMail.getManager().loadPropertyFileConstants(Constants.SMTP_MAIL_CONFIG_FILE_PATH);
			
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		try{
			for( int i=0; i<Constants.MODULE_CONTROLLER_THREADS; i++ ) {
				(new CollectorThreadController()).start();
			}
			
			for( int i=0; i<Constants.JAVA_PROFILER_CONTROLLER_THREADS; i++ ) {
				(new JavaProfilerThreadController()).start();
			}
			
			// DotNet Profiler: Compute the Method Stack Trace, which is already saved in dotnet_profiler_method_trace_<UID>
			for( int i=0; i<Constants.DOTNET_PROFILER_STACKTRACE_COMPUTE_THREADS; i++ ) {
				(new DotNetProfilerThreadController("STACKTRACE_COMPUTE")).start();
			}
			
			// DotNet Profiler: Insert the computed datum, which are available in the HashTable & Stack
			for( int i=0; i<Constants.DOTNET_PROFILER_STACKTRACE_INSERT_THREADS; i++ ) {
				(new DotNetProfilerThreadController("STACKTRACE_INSERT")).start();
			}
			
			for( int i=0; i<Constants.PG_PROFILER_CONTROLLER_THREADS; i++ ) {
				(new PGSlowQueryThreadController()).start();
			}
			
			for( int i=0; i<Constants.MSSQL_PROFILER_CONTROLLER_THREADS; i++ ) {
				(new MSSQLSlowQueryThreadController()).start();
			}
			
			for( int i=0; i<Constants.MSSQL_PROCEDURE_CONTROLLER_THREADS; i++ ) {
				(new MSSQLProcedureThreadController()).start();
			}
			
			for( int i=0; i<Constants.MYSQL_PROCEDURE_CONTROLLER_THREADS; i++ ) {
				(new MySQLSlowQueryThreadController()).start();
			}
			for( int i=0; i<Constants.ORACLE_PROFILER_CONTROLLER_THREADS; i++ ) {
				(new OracleSlowQueryThreadController()).start();
			}
			for( int i=0; i<Constants.BEATS_CONTROLLER_THREADS; i++ ) {
				(new BeatsThreadController()).start();
			}
			// To Check & upgrade monitor agent
			//timerUpgradeModule = new UpgradeTimerTask();
			//timerUpgrade.schedule(timerUpgradeModule, 500, Constants.UPGRADE_CHECK_INTERVAL * 1000);
			
			// ----- BACKUP -----
			// Start perf.counter db insert after told time
			ttBackup = new BackupTimer();
			timerBackup = new Timer();
			
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
}
