package com.appedo.webcollector.webserver.manager;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.PriorityBlockingQueue;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;

import com.appedo.manager.LogManager;
import com.appedo.webcollector.webserver.DBI.CollectorDBI;
import com.appedo.webcollector.webserver.DBI.JavaProfilerDBI;
import com.appedo.webcollector.webserver.bean.CollectorBean;
import com.appedo.webcollector.webserver.connect.DataBaseManager;
import com.appedo.webcollector.webserver.util.Constants;
import com.appedo.webcollector.webserver.util.UtilsFactory;

/**
 * Manager which holds the queues, of all the performance counters
 * Singleton class. So no objects can be created.
 * 
 * @author Ramkumar
 *
 */
public class CollectorManager{
	
	// Singleton object, used globally with static getCollectorManager().
	private static CollectorManager collectorManager = new CollectorManager();
	
	// Queue to store performance counter data of agents
	private PriorityBlockingQueue<CollectorBean> pqModulePerformanceCounters = new PriorityBlockingQueue<CollectorBean>();
	
	private PriorityBlockingQueue<String> pqJavaProfiler = null;
	private PriorityBlockingQueue<String> pqDotNetProfiler = null;
	private PriorityBlockingQueue<String> pqPGSlowQueries = null;
	private PriorityBlockingQueue<String> mssqlSlowQueries = null;
	private PriorityBlockingQueue<String> mssqlProcedures = null;
	private PriorityBlockingQueue<String> mysqlSlowQueries = null;
	private PriorityBlockingQueue<String> oracleSlowQueries = null;
	private PriorityBlockingQueue<String> beatIds = null;
	
	private HashMap<String, Object[]> hmLatestCounters = null;
	
	private static HashMap<String,Object>  hmCountersBean = new HashMap<String,Object>();
	private static HashMap<String,Object>  hmSlaCountersBean = new HashMap<String,Object>();
	public static HashMap<String,Object>  hmUpgradeAgentBean = new HashMap<String,Object>();
	
	public Object[] getLatestCounters(String strKey) {
		return hmLatestCounters.get(strKey);
	}
	public boolean isLatestCountersContains(String strKey) {
		return hmLatestCounters.containsKey(strKey);
	}
	public void addLatestCounter(String strKey, Object[] objArr) {
		this.hmLatestCounters.put(strKey, objArr);
	}
	
	

	/**
	 * @return the hmCountersBean
	 */
	public static JSONArray getCounters(String strGUID) {		
		return (JSONArray) hmCountersBean.get(strGUID);
	}
	
	/**
	 * @return the hmCountersBean
	 */
	public static JSONArray getSlaCounters(String strGUID) {
		return (JSONArray) hmSlaCountersBean.get(strGUID);
	}

	/**
	 * @param hmCountersBean the hmCountersBean to set
	 */
	public static void setCounters(String strGUID, JSONArray jaNewCounterSet) {
		
		CollectorManager.hmCountersBean.put(strGUID, jaNewCounterSet);
	}
	
	/**
	 * @param hmCountersBean the hmCountersBean to set
	 */
	public static void setSlaCounters(String strGUID, JSONArray jaNewCounterSet) {
		
		CollectorManager.hmSlaCountersBean.put(strGUID, jaNewCounterSet);
	}
	/**
	 * to remove the counter set from hashmap table
	 * @param strGUID
	 */
	public static void removeCounterSet(String strGUID) {
		if(CollectorManager.hmCountersBean.containsKey(strGUID)) {
			CollectorManager.hmCountersBean.remove(strGUID);
		}
		
	}

	/**
	 * to remove the counter set from hashmap table
	 * @param strGUID
	 */
	public static void removeSlaCounterSet(String strGUID) {
		if(CollectorManager.hmSlaCountersBean.containsKey(strGUID)) {
			CollectorManager.hmSlaCountersBean.remove(strGUID);
		}
		
	}
	/**
	 * Avoid multiple object creation, by Singleton
	 */
	private CollectorManager() {
		
		try{
			// initialize all required queue in this private constructor.
			pqModulePerformanceCounters = new PriorityBlockingQueue<CollectorBean>();
			pqJavaProfiler = new PriorityBlockingQueue<String>();
			pqDotNetProfiler = new PriorityBlockingQueue<String>();
			pqPGSlowQueries = new PriorityBlockingQueue<String>();
			mssqlSlowQueries = new PriorityBlockingQueue<String>();
			mssqlProcedures = new PriorityBlockingQueue<String>();
			mysqlSlowQueries = new PriorityBlockingQueue<String>();
			oracleSlowQueries = new PriorityBlockingQueue<String>();
			beatIds = new PriorityBlockingQueue<String>();
			
			hmLatestCounters = new HashMap<String, Object[]>();
			
		} catch(Exception ex) {
			LogManager.errorLog(ex);
		}
	}
	
	/**
	 * Access the only[singleton] CollectorManager object.
	 * 
	 * @return CollectorManager
	 */
	public static CollectorManager getCollectorManager(){
		return collectorManager;
	}
	
	/*
	public StringBuilder initalizeAgentTransaction(String strGUID, String StrAgentType) throws Exception {
		Connection con = null;
		
		long lLastThreadId = 0l;
		String strEncryptedUID = null;
		StringBuilder sbReturn = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			DataBaseManager.doConnectionSetupIfRequired( InitServlet.CONSTANTS_PATH );
			con = DataBaseManager.giveConnection();
			
			CollectorDBI collectorDBI = new CollectorDBI();
			strEncryptedUID = collectorDBI.initalizeAgentTransaction(con, strGUID, StrAgentType);
			
			if( strEncryptedUID != null ){
				if( StrAgentType.equals("PROFILER") ){
					lLastThreadId = collectorDBI.getLastThreadId(con, strGUID);
				}
				
				hmKeyValues = new HashMap<String, Object>();
				hmKeyValues.put("uid", strEncryptedUID);
				hmKeyValues.put("lastThreadId", new Long(lLastThreadId));
				
				sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
			}
		} catch (Exception ex) {
			System.out.println("Exception in initalizeAgentTransaction: "+ex.getMessage());
			ex.printStackTrace();
			throw ex;
		} finally {
			DataBaseManager.close(con);
			con = null;
		}
		
		return sbReturn;
	}
	*/
	
	/** Commented as UID-Concept is removed
	 * 
	 * Returns the application agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 *
	public StringBuilder getModuleConfigurations(String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		String strEncryptedUID = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			CollectorDBI collectorDBI = new CollectorDBI();
			strEncryptedUID = collectorDBI.getEncryptedModuleUID(con, strGUID);
			
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("uid", strEncryptedUID);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
		
		strEncryptedUID = null;
		UtilsFactory.clearCollectionHieracy(hmKeyValues);
		hmKeyValues = null;
		
		return sbReturn;
	}*/
	
	/**
	 * Returns the application agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 *
	public StringBuilder getApplicationConfigurations(String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		String strEncryptedUID = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			CollectorDBI collectorDBI = new CollectorDBI();
			strEncryptedUID = collectorDBI.getEncryptedApplicationUID(con, strGUID);
			
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("uid", strEncryptedUID);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			System.out.println("Exception in getApplicationUID: "+ex.getMessage());
			throw ex;
		}
		
		return sbReturn;
	}
	
	/**
	 * Returns the server agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 *
	public StringBuilder getServerConfigurations(String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		String strEncryptedUID = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			CollectorDBI collectorDBI = new CollectorDBI();
			strEncryptedUID = collectorDBI.getEncryptedServerUID(con, strGUID);
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("uid", strEncryptedUID);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			System.out.println("Exception in getServerUID: "+ex.getMessage());
			throw ex;
		}
		
		return sbReturn;
	}
	
	/**
	 * Returns the database agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 *
	public StringBuilder getDatabaseConfigurations(String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		String strEncryptedUID = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			CollectorDBI collectorDBI = new CollectorDBI();
			strEncryptedUID = collectorDBI.getEncryptedDatabaseUID(con, strGUID);
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("uid", strEncryptedUID);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			System.out.println("Exception in getDatabaseUID: "+ex.getMessage());
			throw ex;
		}
		
		return sbReturn;
	}
	
	
	public StringBuilder getNetworkConfigurations(String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		String strEncryptedUID = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			CollectorDBI collectorDBI = new CollectorDBI();
			strEncryptedUID = collectorDBI.getEncryptedNetworkUID(con, strGUID);
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("uid", strEncryptedUID);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			System.out.println("Exception in getNetworkUID: "+ex.getMessage());
			throw ex;
		}
		
		return sbReturn;
	}*/
	
	/**
	 * Returns the application profiler agent's configuration details such as UID & last ThreadId used for this GUID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public StringBuilder getProfilerConfigurations(Connection con, String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		long lLastThreadId = 0l, lUID = 0l;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			CollectorDBI collectorDBI = new CollectorDBI();
			
			lUID = collectorDBI.getApplicationUID(con, strGUID);
			
			JavaProfilerDBI javaProfilerDBI = new JavaProfilerDBI();
			lLastThreadId = javaProfilerDBI.getLastThreadId(con, lUID);
			
			hmKeyValues = new HashMap<String, Object>();
			// Commented as UID-Concept is removed
			// hmKeyValues.put("uid", strEncryptedUID);
			
			hmKeyValues.put("lastThreadId", new Long(lLastThreadId));
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally {
			//strEncryptedUID = null;
			lLastThreadId = 0l;
			lUID = 0l;
			UtilsFactory.clearCollectionHieracy(hmKeyValues);
			hmKeyValues = null;
		}
		
		return sbReturn;
	}
	
	/**
	 * TODO enable_backup
	 *
	public void backupTables(){
		
		try{
			//System.out.println("Starting DBBackup timer thread(db insert): "+(new Date()));
			
			CollectorDBI collectorDBI = new CollectorDBI();
			collectorDBI.backupPreviousDayRecords(conBackup);
			
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
	}*/
	
	/**
	 * Queue the given Counter CollectorBean into the asked Family queue.
	 * 
	 * @param strCounterParams
	 * @return
	 * @throws Exception
	 */
	public boolean collectPerformanceCounters(String strCounterParams) throws Exception {
		CollectorBean collBean = null;
		
		try {
			collBean = new CollectorBean();
			collBean.setCounterParams(strCounterParams);
			collBean.setReceivedOn(new Date());
			
			return pqModulePerformanceCounters.add(collBean);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	/**
	 * Poll the top Counter CollectorBean from the asked Family queue.
	 * 
	 * @param agent_family
	 * @param nIndex
	 * @return
	 */
	public CollectorBean pollCounter(){
		CollectorBean cbCounterEntry = null;
		
		try {
			cbCounterEntry = pqModulePerformanceCounters.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return cbCounterEntry;
	}
	/**
	 * Get the size of the asked Family queue.
	 * 
	 * @return int
	 */
	public int getCounterLength(){
		return pqModulePerformanceCounters.size();
	}
	
	
	/**
	 * Collect and add the Java's profiled data into MySQL queue.
	 * 
	 * @param strCounterParams
	 * @return
	 * @throws Exception
	 */
	public boolean collectJavaProfiler(String strCounterParams) throws Exception {
		
		try {
			return pqJavaProfiler.add(strCounterParams);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	/**
	 * Get the top counter data from the java profile data queue.
	 * 
	 * @return Counter JSON data in String format
	 */
	public String pollJavaProfiler(){
		String strCounterEntry = null;
		
		try {
			strCounterEntry = pqJavaProfiler.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	/**
	 * Get the size of Java profile entries queue.
	 * 
	 * @return int
	 */
	public int getJavaProfilerLength(){
		return pqJavaProfiler.size();
	}
	
	/**
	 * Collect and add the DOTNET's profiled data into MySQL queue.
	 * 
	 * @param strCounterParams
	 * @return
	 * @throws Exception
	 */
	public boolean collectDotNetProfiler(String strCounterParams) throws Exception {
		
		try {
			return pqDotNetProfiler.add(strCounterParams);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	/**
	 * Collect and add the POSTGRES's slow queries data into postgres queue.
	 * 
	 * @param strCounterParams
	 * @return
	 * @throws Exception
	 */

	public boolean collectPGSlowQueries(String strCounterParams) throws Exception {
		
		try {
			return pqPGSlowQueries.add(strCounterParams);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	/**
	 * Collect and add the MSSQL's slow queries data into MSSQL queue.
	 * 
	 * @param strCounterParams
	 * @return
	 * @throws Exception
	 */

	public boolean collectMSSQLSlowQueries(String strCounterParams) throws Exception {
		
		try {
			return mssqlSlowQueries.add(strCounterParams);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	/**
	 * Collect and add the MSSQL's procedures data into MSSQL queue.
	 * 
	 * @param strCounterParams
	 * @return
	 * @throws Exception
	 */
	
	
public boolean collectMSSQLProcedures(String strCounterParams) throws Exception {
		
		try {
			return mssqlProcedures.add(strCounterParams);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}

/**
 * Collect and add the MSSQL's slow queries data into MSSQL queue.
 * 
 * @param strCounterParams
 * @return
 * @throws Exception
 */

public boolean collectMySQLSlowQueries(String strCounterParams) throws Exception {
	
	try {
		return mysqlSlowQueries.add(strCounterParams);
	} catch(Exception e) {
		LogManager.errorLog(e);
		throw e;
	}
}

/**
 * Collect and add the Oracle's slow queries data into Oracle queue.
 * 
 * @param strCounterParams
 * @return
 * @throws Exception
 */
public boolean collectOracleSlowQueries(String strCounterParams) throws Exception {
	
	try {
		return oracleSlowQueries.add(strCounterParams);
	} catch(Exception e) {
		LogManager.errorLog(e);
		throw e;
	}
}
	/**
	 * Get the top counter data from the POSTGRES data queue.
	 * 
	 * @return Counter JSON data in String format
	 */
	public String pollPGSlowQueries(){
		String strCounterEntry = null;
		
		try {
			strCounterEntry = pqPGSlowQueries.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	/**
	 * Get the top counter data from the MYSQL data queue.
	 * 
	 * @return Counter JSON data in String format
	 */
	public String pollMssqlSlowQueries(){
		String strCounterEntry = null;
		
		try {
			strCounterEntry = mssqlSlowQueries.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	/**
	 * Get the top counter data from the MSSQL data queue.
	 * 
	 * @return Counter JSON data in String format
	 */
	public String pollMssqlProcedures(){
		String strCounterEntry = null;
		
		try {
			strCounterEntry = mssqlProcedures.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	/**
	 * Get the top counter data from the DOTNET profile data queue.
	 * 
	 * @return Counter JSON data in String format
	 */
	public String pollDotNetProfiler(){
		String strCounterEntry = null;
		
		try {
			strCounterEntry = pqDotNetProfiler.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	
	/**
	 * Get the top counter data from the MYSQL data queue.
	 * 
	 * @return Counter JSON data in String format
	 */
	public String pollMysqlSlowQueries(){
		String strCounterEntry = null;
		
		try {
			strCounterEntry = mysqlSlowQueries.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	
	/**
	 * Get the slow queries data from the Oracle data queue.
	 * 
	 * @return Counter JSON data in String format
	 */
	public String pollOracleSlowQueries(){
		String strCounterEntry = null;
		
		try {
			strCounterEntry = oracleSlowQueries.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	
	/**
	 * Get the size of Postgres Slow Queries entries queue.
	 * 
	 * @return int
	 */
	public int getPGSlowQueriesLength(){
		return pqPGSlowQueries.size();
		
	}
	/**
	 * Get the size of MSSQL Slow Queries entries queue.
	 * 
	 * @return int
	 */
	public int getMSSQLSlowQueriesLength(){
		return mssqlSlowQueries.size();
		
	}
	/**
	 * Get the size of MSSQL procedures entries queue.
	 * 
	 * @return int
	 */
	public int getMSSQLProcedureLength(){
		return mssqlProcedures.size();
		
	}
	/**
	 * Get the size of DOTNET profile entries queue.
	 * 
	 * @return int
	 */
	public int getDotNetProfilerLength(){
		return pqDotNetProfiler.size();
	}
	
	/**
	 * Get the size of MYSQL Slow Queries entries queue.
	 * 
	 * @return int
	 */
	public int getMySQLSlowQueriesLength(){
		return mysqlSlowQueries.size();
		
	}
	
	/**
	 * Get the size of Postgres Slow Queries entries queue.
	 * 
	 * @return int
	 */
	public int getOracleSlowQueriesLength(){
		return oracleSlowQueries.size();
		
	}
	
	/**
	 * Returns the application agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> getModuleConfigCounters(Connection con, String strGUID) throws Exception {
		HashMap<String, Object> hmKeyValues = new HashMap<String, Object>();
		JSONArray jaCounters = null;
		JSONObject joLicense = null, joUserLic = null;
	
		JSONArray jaSlaCounters = null;
		
		try{
			CollectorDBI collectorDBI = new CollectorDBI(); 
			// TODO get the new Counter-set to be collected
			
			long lUID = collectorDBI.getModuleUID(con, strGUID);
			if( lUID == -1l ) {
				hmKeyValues.put("KILL", true);		
			} else {
				// get UserId and License level
				joUserLic = collectorDBI.getUserLicense(con, strGUID);
				
				// get APM License details
				joLicense = collectorDBI.getLicenseAPMDetails(con, joUserLic);
				
				// get user selected counter for monitor
				if( joLicense != null){
					jaCounters = collectorDBI.getConfigCounters(con, lUID, joLicense);
					
					hmKeyValues.put("MonitorCounterSet", jaCounters);
				}else {
					hmKeyValues.put("MonitorCounterSet", jaCounters);	
				}
				
				// get user mapped counters for sla
				jaSlaCounters = getSlaConfigCounters(strGUID);
				//System.out.println("jaSlaCounters " + jaSlaCounters.toString());
				if(jaSlaCounters!=null) {
					//System.out.println("INSIDE IF ");
					hmKeyValues.put("SlaCounterSet", jaSlaCounters);
				}else  {
					//System.out.println("INSIDE else ");
					jaSlaCounters = new JSONArray();
				}
				
				// remove GUID from master object
				CollectorManager.hmCountersBean.remove(strGUID);
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		} finally{
			joLicense = null;
			joUserLic = null;
		}
		
		return hmKeyValues;
	}
	
	public JSONArray getSlaConfigCounters(String strGUID) {
		PostMethod method = null;
		HttpClient client = null;
		
		String responseJSONStream = null;
		
		JSONObject joGUIDWiseSLAs = null;
		JSONArray jaSLAs = null;
		
		try {
			method = new PostMethod(Constants.APPEDO_SLA_COLLECTOR_URL);
			method.setParameter("guid", strGUID);
			method.setParameter("command", "AgentFirstRequest");
			client = new HttpClient();
			int statusCode = client.executeMethod(method);
			method.setRequestHeader("Connection", "close");
			if (statusCode != HttpStatus.SC_OK) {
				System.err.println("Method failed: " + method.getStatusLine());
			} else {
				responseJSONStream = method.getResponseBodyAsString();
				
				//System.out.println("Sla Counters :" +responseJSONStream);
				if( responseJSONStream.startsWith("{") && responseJSONStream.endsWith("}")) {
					JSONObject joResp = JSONObject.fromObject(responseJSONStream);
					
					if( joResp.getBoolean("success") ){
						if(joResp.getString("message") != null && joResp.getString("message").startsWith("{") && joResp.getString("message").endsWith("}")) {
							joGUIDWiseSLAs = joResp.getJSONObject("message");
							
							jaSLAs = joGUIDWiseSLAs.getJSONArray(strGUID);
						}
					}
				}
			}
		} catch(Exception e) {			
			LogManager.errorLog(e);
		}
		
		return jaSLAs;
	}
	/**
	 * Returns the application agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public StringBuilder getModuleConfigurations(String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		HashMap<String, Object> hmKeyValues = null;
		JSONArray jaCounters = null;
		
		try{
			// TODO get the new Counter-set to be collected
			jaCounters = CollectorManager.getCounters(strGUID);
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("MonitorCounterSet", jaCounters);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
			// remove guid from master
			
			CollectorManager.removeCounterSet(strGUID);
		} catch (Exception ex) {
			ex.printStackTrace();
			LogManager.errorLog(ex);
			throw ex;
		}
		
		return sbReturn;
	}
	/**
	 * Returns the application agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public StringBuilder setModuleConfigurations(String strGUID, String strnewCounterSet) throws Exception {
		StringBuilder sbReturn = null;
		
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			LogManager.infoLog("strnewCounterSet :"+strnewCounterSet);
			CollectorManager.setCounters( strGUID, JSONArray.fromObject(strnewCounterSet));
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("guid", strGUID);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
		
		return sbReturn;
	}
	
	public StringBuilder queueNewMonitorCounterSet(Connection con, String strGUID) throws Exception {
		StringBuilder sbReturn = null;
		JSONArray jaCounters = null, jaSLACounters = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			collectorManager = CollectorManager.getCollectorManager();
			hmKeyValues = collectorManager.getModuleConfigCounters(con, strGUID);
			
			if( hmKeyValues.containsKey("KILL") ) {
				sbReturn = UtilsFactory.getJSONSuccessReturn("kill");
			} else if( hmKeyValues.size() > 0 ) {
				jaCounters = (JSONArray)hmKeyValues.get("MonitorCounterSet");
				CollectorManager.setCounters( strGUID, jaCounters);
				
				jaSLACounters = (JSONArray)hmKeyValues.get("SlaCounterSet");
				CollectorManager.setSlaCounters(strGUID, jaSLACounters);
			} else {
				sbReturn = UtilsFactory.getJSONFailureReturn("Unable to get UID. Try again later.");
			}
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
		
		return sbReturn;
	}
	/**
	 * Returns the application agent's configuration details such as UID.
	 * 
	 * @param strGUID
	 * @return
	 * @throws Exception
	 */
	public StringBuilder setSlaModuleConfigurations(String strGUID, JSONArray jaGUIDNewSLAs) throws Exception {
		StringBuilder sbReturn = null;
		HashMap<String, Object> hmKeyValues = null;
		
		try{
			CollectorManager.setSlaCounters(strGUID, jaGUIDNewSLAs);
			
			hmKeyValues = new HashMap<String, Object>();
			hmKeyValues.put("guid", strGUID);
			
			sbReturn = UtilsFactory.getJSONSuccessReturn(hmKeyValues);
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
		
		return sbReturn;
	}

	
	public  void updateStatusOfCounterMaster(Connection con, String strGUID) {
		CollectorDBI collectorDBI = null;
		
		try{
			collectorDBI = new CollectorDBI();
			collectorDBI.updateStatusOfCounterMaster(con, strGUID);
		} catch (Exception ex) {
			LogManager.errorLog(ex);
		} finally {
			collectorDBI = null;
		}
		
	}
	
	
	public StringBuilder updateChildCounters(Connection con, String strGUID, JSONObject joRecChildCounters) {
		StringBuilder sbReturn = null;
		CollectorDBI collectorDBI = null;
		
		JSONArray jaAry = new JSONArray();
		JSONObject joParentCounterDetails = new JSONObject(), joAppChildCounter = null, joChild = null;
		
		try{
			collectorDBI = new CollectorDBI();
			
			long lUID = collectorDBI.getModuleUID(con, strGUID);
			if( lUID == -1l ) {
				sbReturn = UtilsFactory.getJSONSuccessReturn("kill");
				//throw new Exception("Given GUID is not matching: "+strGUID);				
			} else {
				jaAry = joRecChildCounters.getJSONArray("parentcounter");
				for(int i=0; i<jaAry.size(); i++){
					joChild = jaAry.getJSONObject(i);
					
					int nParentCounterId = joChild.getInt("parentcounterid");
					
					// get the parent counter instance, category and counter-name
					joParentCounterDetails = collectorDBI.getParentCounterDetails(con, lUID, nParentCounterId );
					
					if( joParentCounterDetails != null ) {
						collectorDBI.updateParentCounter(con, joParentCounterDetails);				
					}
					
					JSONArray jaChild = joChild.getJSONArray("childcounterdetail");
					
					for(int j=0; j<jaChild.size(); j++) {
						JSONObject joChildDetails = jaChild.getJSONObject(j);
						String strInstanceName = joChildDetails.getString("instancename");
						String strCounterName = joChildDetails.getString("countername");
						String strQuery = joChildDetails.getString("query");
						String strCategory = joChildDetails.getString("category");
						
						// If CounterName-InstanceName is same as Parent's then,
						// it is the Parent Counter, which is reported in the Children list.
						// So, that can be ignored.
						if( ! strInstanceName.equalsIgnoreCase( joParentCounterDetails.getString("instance_name") ) 
							&& ! strCounterName.equalsIgnoreCase( joParentCounterDetails.getString("counter_name") ) 
						) {
							joAppChildCounter = new JSONObject();
							joAppChildCounter.put("guid", strGUID);
							joAppChildCounter.put("queryString", strQuery);
							joAppChildCounter.put("executionType", "");
							joAppChildCounter.put("category", strCategory);
							joAppChildCounter.put("instance_name", strInstanceName);
							joAppChildCounter.put("counterName", strCounterName);
							joAppChildCounter.put("is_selected", false);
							joAppChildCounter.put("is_enabled", true);
							joAppChildCounter.put("has_instance", false);
							
							// If InstanceName is suffixed in CounterName then,
							// append the InstanceName in child's CounterName.
							if( ! strCounterName.endsWith("-"+strInstanceName) ) {
								joAppChildCounter.put("display_name", strCounterName+"-"+strInstanceName);
							} else {
								joAppChildCounter.put("display_name", strCounterName);
							}
							
							collectorDBI.insertCounterMasterTable(con,joAppChildCounter,lUID,nParentCounterId);
						}
						
						UtilsFactory.clearCollectionHieracy(joAppChildCounter);
						UtilsFactory.clearCollectionHieracy(joChildDetails);
						joChildDetails = null;
						strInstanceName = null;
						strCounterName = null;
						strQuery = null;
					}
				}
				
				sbReturn = UtilsFactory.getJSONSuccessReturn("Updated");
			}
		} catch (Exception ex) {
			LogManager.errorLog(ex);
			sbReturn = UtilsFactory.getJSONFailureReturn("Unable to update child counters. Try again later.");
		} finally {
			UtilsFactory.clearCollectionHieracy(joParentCounterDetails);
			UtilsFactory.clearCollectionHieracy(jaAry);
			
			collectorDBI = null;
		}
		
		return sbReturn;
	}
	
	/**
	 * to collect the list of upgrade module agent's guids
	 * @param strGUID
	 * @param joUpgradeDetails
	 */
	public void collectUpgradeGUID(Connection con) {
		CollectorDBI collectDBI = null;
		ResultSet rst = null;
		JSONObject joUpgradeGUID = null;
		
		try {
			hmUpgradeAgentBean.clear();
			collectDBI = new CollectorDBI();
			rst = collectDBI.collectUpgradeGUID(con);
			while (rst.next()) {
				joUpgradeGUID = new JSONObject();
				joUpgradeGUID.put("guid", rst.getString("guid"));
				//joUpgradeGUID.put("download_url", rst.getString("download_url"));
				hmUpgradeAgentBean.put(rst.getString("guid"), joUpgradeGUID);				
			}
			System.out.println("hmUpgradeAgentBean : " + hmUpgradeAgentBean.size());
		}catch(Exception e) {
			LogManager.errorLog(e);
		}finally {
			if(rst!=null) {
				DataBaseManager.close(rst);
				rst = null;
			}			
			collectDBI = null; 
		}
	}
	
	public boolean collectBeatData(String strGUID) throws Exception {
		try {
			return beatIds.add(strGUID);
		} catch(Exception e) {
			LogManager.errorLog(e);
			throw e;
		}
	}
	
	public String pollBeatData(){
		String strCounterEntry = null;
		try {
			strCounterEntry = beatIds.poll();
		} catch(Throwable e) {
			LogManager.errorLog(e);
		}
		
		return strCounterEntry;
	}
	
	public int getBeatDataLength(){
		return beatIds.size();
		
	}
	
	@Override
	/**
	 * Before destroying clear the objects. To prevent from MemoryLeak.
	 */
	protected void finalize() throws Throwable {
		UtilsFactory.clearCollectionHieracy(pqModulePerformanceCounters);
		
		super.finalize();
	}
}
