package com.appedo.webcollector.webserver.DBI;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.appedo.manager.LogManager;
import com.appedo.webcollector.webserver.connect.DataBaseManager;
import com.appedo.webcollector.webserver.util.UtilsFactory;

/**
 * Abstract class which should be extended by all module DBI classes.
 * This class has the basic operations like insertion into response table & counter table as batch.
 * 
 * Child class must define initalizeInsertBatch(), with the Insert query for target table.
 * 
 * @author Ramkumar R
 * 
 */
public class CollectorParentDBI {
	
	protected String strPerformanceCounter = null;
	
//	protected HashMap<String, Statement> hmStmtPerformanceCounter =  new HashMap<String, Statement>();
	
	protected Statement stmtPerformanceCounter = null;
	
	protected PreparedStatement pstmtPartitionTables = null;
	
	protected Statement stmtAgentResponseInMin = null;
	protected Statement stmtPerformanceCounterInMin = null;
	
	private String strUID = "";
	
	/**
	 * Constructor which gets the db connection object to be used for the counters insert operations.
	 * What kind of agent is also defined in this.
	 * 
	 * @param con
	 * @param nIndex
	 *
	public CollectorParentDBI(int nIndex) {
		this.nIndex = nIndex;
	}*/
	
	/** ## This CollectorParentDBI was used as Parent for ApplicationPerformanceCounterDBI , ServerPerformanceCounterDBI etc ##
	 *  ## this method was overridden there; now added in this Class itself ##
	 *  
	 * Child class must define initalizeInsertBatch(), with the Insert query for target table.
	 * 
	 * @throws Exception
	 *
	public abstract void initializeInsertBatch() throws Exception;
	*/
	
	/**
	 * Initializes the prepared statement which has insert queries for the response table and the counter table.
	 * 
	 * @throws Exception
	 */
	public void initializeInsertBatch(Connection con) throws Exception {
		
		try{
			// For each counter in the received agent response; with a reference for above entry.
			strPerformanceCounter = "INSERT INTO collector_@KEY@ (uid, received_on, appedo_received_on, agent_version, counter_type, counter_value, exception, top_process, is_first) VALUES ";
			
			stmtPerformanceCounter = con.createStatement();
			
			pstmtPartitionTables = con.prepareStatement("SELECT create_asd_daily_partition_tables(?, ?)");
			
			/* TODO table partitioning
			// Agent Response once in a min
			psAgentResponseInMin = con.prepareStatement("INSERT INTO application_agent_response_1_min (uid, received_on, appedo_received_on, agent_version, exception) VALUES (?, ?, ?, ?, ?) ", Statement.RETURN_GENERATED_KEYS);
			
			// Counter insert - Average Counter value once in a min
			psPerformanceCounterInMin = con.prepareStatement("INSERT INTO application_performance_counter_1_min (agent_response_id, counter_type, counter_value, exception) VALUES (?,?,?,?) ");
			*/
		} catch(Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
	}
	
	/**
	 * Queues the given counter code-value pair into the table defined in the initalizeInsertBatch(). 
	 * The batch will be executed when executeCounterBatch() is called.
	 * 
	 * @param lAgentResponseId
	 * @param nCounterCode
	 * @param dCounterValue
	 * @throws Exception
	 */
	public void addCounterBatch(long lUID, Timestamp timestampAgent, Timestamp timestampAppedo, String strAgentVersion, int nCounterCode, Double dCounterValue, String strCounterError, String strTopProcValue, boolean is_first) throws Exception {
		StringBuilder sbQuery = new StringBuilder();
		String strPartitionKey;
		
		this.strUID = Long.toString(lUID);
		strPartitionKey = UtilsFactory.formatYYYYMMDD( timestampAppedo.getTime() );
		
		try{
			strPartitionKey = CollectorDBI.createDailyPartition(pstmtPartitionTables, lUID, strPartitionKey);
			
			sbQuery.append(strPerformanceCounter.replaceAll("@KEY@", strPartitionKey)).append("(")
					.append(strUID).append(", ")
					.append(UtilsFactory.makeValidVarchar(UtilsFactory.formatTimeStampToyyyyMMddHHmmssS(timestampAgent.getTime()))).append("::timestamp, ")
					.append(UtilsFactory.makeValidVarchar(UtilsFactory.formatTimeStampToyyyyMMddHHmmssS(timestampAppedo.getTime()))).append("::timestamp, ")
					.append(UtilsFactory.makeValidVarchar(strAgentVersion)).append(", ")
					.append(nCounterCode).append(", ")
					.append(dCounterValue).append(", ")
					.append(UtilsFactory.makeValidVarchar(strCounterError))
					.append(", '")
					.append(strTopProcValue).append("', ")
					.append(is_first)
					.append(")");

//			synchronized ( stmtPerformanceCounter ) {
				stmtPerformanceCounter.addBatch(sbQuery.toString());
//			}
		} catch(Exception ex) {
			LogManager.errorLog(ex);
			SQLException sqlExcpNext = null;
			if( ex instanceof SQLException ) {
				while( (sqlExcpNext = ((SQLException)ex).getNextException()) != null) {
					LogManager.errorLog(sqlExcpNext);
					sqlExcpNext.printStackTrace();
				}
			}
			
			throw ex;
		} finally {
			strPartitionKey = null;
		}
	}
	
	/**
	 * Insert a row in the respective response table for a min (taking average) to represent a counter-set is received.
	 * 
	 * @param lUID
	 * @param timestampAgent
	 * @param timestampAppedo
	 * @param strAgentVersion
	 * @param strAgentError
	 * @return
	 * @throws Exception
	 *
	public long insertAgentResponseInMin(long lUID, Timestamp timestampAgent, Timestamp timestampAppedo, String strAgentVersion, String strAgentError) throws Exception {
		long lReturn = 0;
		
		try{
			psAgentResponseInMin.setLong(1, lUID);
			psAgentResponseInMin.setTimestamp(2, timestampAgent);
			psAgentResponseInMin.setTimestamp(3, timestampAppedo);
			psAgentResponseInMin.setString(4, strAgentVersion);
			psAgentResponseInMin.setString(5, strAgentError);
			
			lReturn = DataBaseManager.insertAndReturnKey(psAgentResponseInMin, "response_id");
			
		} catch(Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
		
		return lReturn;
	}
	
	/**
	 * 
	 * 
	 * @param lAgentResponseId
	 * @param nCounterCode
	 * @param dCounterValue
	 * @param strCounterError
	 * @throws Exception
	 *
	public void addCounterBatchInMin(long lAgentResponseId, int nCounterCode, Double dCounterValue, String strCounterError) throws Exception {
		
		try{
			// params:	agent_response_id, counter_type, counter_value
			psPerformanceCounterInMin.setLong(1, lAgentResponseId);
			psPerformanceCounterInMin.setInt(2, nCounterCode);
			psPerformanceCounterInMin.setDouble(3, dCounterValue);
			psPerformanceCounterInMin.setString(4, strCounterError);
			psPerformanceCounterInMin.addBatch();
			
		} catch(Exception ex) {
			LogManager.errorLog(ex);
			throw ex;
		}
	}
	
	/**
	 * Insert the counters available in the batch into the table defined in the initalizeInsertBatch().
	 * 
	 * @throws Exception
	 */
	public void executeCounterBatch(long lThisThreadId) throws Exception {
//		Iterator<String> iterKeys = null;
//		Statement stmtPerformanceCounter = null;
//		String strPartitionKey = null;
		int ins[], nInserted = 0;
		
		try{
//			iterKeys = hmStmtPerformanceCounter.keySet().iterator();
//			
//			while( iterKeys.hasNext() ){
//				strPartitionKey = iterKeys.next();
//				stmtPerformanceCounter = hmStmtPerformanceCounter.get(strPartitionKey);
//				synchronized ( stmtPerformanceCounter ) {
					// execute the batch for the looping UID_YEAR
					ins = stmtPerformanceCounter.executeBatch();
					/* TODO remove the prepared statement through Thread
					// once the batch is inserted the PreparedStatement should be closed.
					DataBaseManager.close(psPerformanceCounter);
					
					// remove the PreparedStatement; if required it will be added in next queuing 
					hmPreStmtPerformanceCounter.remove(strPartitionKey);
					*/
					// keep track of inserted count
					nInserted += ins.length;
//				}
//			}
			if( nInserted > 0 ) {
				LogManager.logDBInserts("PerfCounter thread "+lThisThreadId+" inserted: "+nInserted+" <> UID: "+strUID);
			}
			
			/*
			 * Insert 1 minute aggregations
			 */
			// TODO enable_1min int insForMin[] = psPerformanceCounterInMin.executeBatch();
			
//			if( insForMin.length > 0 ) {
//				System.out.println(this_agent+"-PerfCounterInMin inserted: "+insForMin.length);
//			}
			/*
			for(int i=0; i<ins.length; i++)	System.out.print(ins[i]+", ");
			System.out.println();
			*/
		} catch(Exception ex) {
			LogManager.errorLog(ex);
			
			SQLException sqlExcpNext = null;
			if( ex instanceof SQLException ) {
				while( (sqlExcpNext = ((SQLException)ex).getNextException()) != null) {
					if( ! sqlExcpNext.getMessage().contains("collector_0_2014") ) {
						LogManager.errorLog(sqlExcpNext);
					}
				}
			}
			
			throw ex;
		} finally {
			DataBaseManager.close(stmtPerformanceCounter);
			stmtPerformanceCounter = null;
			
			DataBaseManager.close(pstmtPartitionTables);
			pstmtPartitionTables = null;
			
//			strPartitionKey = null;
//			iterKeys = null;
			ins = null;
			nInserted = 0;
		}
	}
	
	/**
	 * update `module_master` for uid's last appedo received on 
	 * 
	 * @param con
	 * @param lUID
	 * @param tsAppedoReceivedOn
	 * @throws Exception
	 */
	public void updateModuleLastAppedoReceivedOn(Connection con, long lUID, long lAppedoReceivedOn) throws Exception {
		Statement stmt = null;
		
		StringBuilder sbQuery = new StringBuilder();
		
		try {
			sbQuery	.append("UPDATE module_master SET ")
					.append("  last_appedo_received_on = ").append(UtilsFactory.makeValidVarchar(UtilsFactory.formatTimeStampToyyyyMMddHHmmssS(lAppedoReceivedOn))).append("::timestamp ")
					.append("WHERE uid = ").append(lUID);
			
			stmt = con.createStatement();
			stmt.executeUpdate(sbQuery.toString());
			
		} catch (Exception e) {
			throw e;
		} finally {
			DataBaseManager.close(stmt);
			stmt = null;
		}
	}
	
	/**
	 * Clear all the Prepared Statement created
	 *
	public void clearAllPreparedStatements() {
		
		try {
			Iterator<String> iterPreStmt = hmStmtPerformanceCounter.keySet().iterator();
			
			while( iterPreStmt.hasNext() ) {
				String strUID = iterPreStmt.next();
				DataBaseManager.close( hmStmtPerformanceCounter.get(strUID) );
				hmStmtPerformanceCounter.remove(strUID);
			}
		} catch(Throwable th) {
			LogManager.errorLog(th);
		}
	}
	*/
	
	/*
	@Override
	protected void finalize() throws Throwable {
		
		clearAllPreparedStatements();
		
		DataBaseManager.close(psAgentResponseInMin);
		psAgentResponseInMin = null;
		
		DataBaseManager.close(psPerformanceCounterInMin);
		psPerformanceCounterInMin = null;
		
		DataBaseManager.close(con);
		con = null;
		
		UtilsFactory.clearCollectionHieracy(hmPreStmtPerformanceCounter);
		
		super.finalize();
	}
	*/
}
