package com.appedo.webcollector.webserver.controller;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.Router;

import com.appedo.manager.LogManager;
import com.appedo.webcollector.webserver.resource.PCCollectorResource;
import com.appedo.webcollector.webserver.resource.ProfilerCollectorResource;
import com.appedo.webcollector.webserver.resource.TransactionSetupResource;

/**
 * Class which receives the HTTP request and routes the said resource class.
 * 
 * @author Ramkumar R
 *
 */
public class AppedoCollector_WebApplication extends Application {

	// set log access
	//private static final Category log = Category.getInstance(SPCG_WebApplication.class.getName());
	
	/**
	 * Creates a root Restlet that will receive all incoming calls.
	 */
	@Override
	public synchronized Restlet createRoot() {
		// Create a router Restlet that routes each call to a
		// specific resources based on a given URI pattern.
		Router router = new Router(getContext());
		
		LogManager.infoLog("Appedo Collector webservice");
		
		// Attach default route
		//router.attachDefault(HelloResource.class);
		
		
		// URI pattern: (POST) This service will recieve all the counter data and pass it to respective Manager.
		// Sent by various SSProfiler agents.
		router.attach("/getConfigurations", TransactionSetupResource.class);
			//.extractQuery("guid", "guid", true)
			//.extractQuery("agent_type", "agent_type", true);
		
		
		// URI pattern: (POST) This service will recieve all the counter data and pass it to respective Manager.
		// Sent by various SSProfiler agents.
		router.attach("/collectCounters", PCCollectorResource.class);
		
		
		// URI pattern: (POST) This service will recieve all the counter data and pass it to respective Manager.
		// Sent by various SSProfiler agents.
		router.attach("/collectProfilerStack", ProfilerCollectorResource.class);
			//.extractQuery("agent_type", "agent_type", true)
			//.extractQuery("counter_params_json", "counter_params_json", true);
		
		/*
		// URI pattern: (POST) This service will recieve all the counter data and pass it to respective Manager.
		// Sent by various SSProfiler agents.
		router.attach("/getTransactionTree", ProfilerTransactionTreeResource.class);
			//.extractQuery("guid", "guid", true);

		
		// URI pattern: (POST) This service will recieve all the counter data and pass it to respective Manager.
		// Sent by various SSProfiler agents.
		router.attach("/getTransactionStack", ProfilerTransactionStackResource.class);
			//.extractQuery("guid", "guid", true);
		*/
		
		return router;
	}
}
